# مجوزهای طرف سوم

## Fluent Emoji (آیکون‌های سه‌بعدی)

آیکون‌های سه‌بعدی زیر `res/drawable-nodpi/ic3d_*.webp` از مجموعهٔ
[Microsoft Fluent Emoji](https://github.com/microsoft/fluentui-emoji) گرفته شده‌اند
و تحت مجوز MIT منتشر شده‌اند. از نسخهٔ ۲.۷.۶ همین رندرها جای ایموجی پیش‌فرض
اندروید را در ری‌اکشن‌ها، متن پیام‌ها، پنل ایموجی چت، فلش‌کارت‌ها، گروه‌های مطالعه
و صفحهٔ گزارش گرفته‌اند. فهرست و ساخت فایل‌ها با `tools/fetch_3d_icons.py` انجام
می‌شود (WebP با کیفیت ۸۰، حدود ۲٫۶ مگابایت).

متن مجوز طبق شرط MIT عیناً آورده می‌شود:

```
MIT License

Copyright (c) Microsoft Corporation.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

این فایل را حذف نکن؛ ذکر متن مجوز شرط لازم MIT است.

### چرا این و نه ایموجی اپل

فونت `AppleColorEmoji` اختصاصی اپل است و لایسنسش فقط روی سخت‌افزار خود اپل
اجازهٔ استفاده می‌دهد. قرار دادنش داخل APK نقض کپی‌رایت است و می‌تواند به
حذف اپ از فروشگاه منجر شود.

## Billing integration update (Studying 2.7.0)

- Myket In-app Billing SDK 2.2 (`ir.myket:billing:2.2`), Apache License 2.0 according to its published POM. Official sample: https://github.com/myketstore/billing-sample-android
- Kotlin standard library 2.2.0, Apache License 2.0.
- OkHttp 5.3.0, Apache License 2.0.

These entries describe the billing/toolchain updates; the project's existing third-party notices remain applicable.

## اتاق سه‌بعدی «هفت‌خانِ تمرکز» (Studying 2.8.0)

فایل‌های زیر `app/src/main/assets/room3d/`:

- `three.min.js` — [three.js](https://github.com/mrdoob/three.js) نسخهٔ r159، مجوز MIT.
  Copyright © 2010-2023 three.js authors. متن کامل همان متن MIT بالاست
  (با جایگزینی نام صاحب حق نشر)؛ سرآیند مجوز داخل خود فایل حفظ شده است.
- `fonts.css` — زیرمجموعهٔ فارسی/لاتین فونت [Vazirmatn](https://github.com/rastikerdar/vazirmatn)
  (Copyright 2015 The Vazirmatn Project Authors)، تحت SIL Open Font License 1.1
  (https://openfontlicense.org). زیرمجموعه‌سازی طبق OFL یک «نسخهٔ تغییریافته» است که با همان
  مجوز منتشر می‌شود؛ فونت جداگانه فروخته نمی‌شود و فقط برای نمایش متن صحنه درون اپ جاسازی شده است.

بقیهٔ فایل‌های این پوشه (مدل‌ها، صداها، بافت‌ها و رابط) کد خود این پروژه‌اند و
همه‌چیز در زمان اجرا با کد ساخته می‌شود؛ هیچ تصویر یا صدای بیرونی استفاده نشده است.
