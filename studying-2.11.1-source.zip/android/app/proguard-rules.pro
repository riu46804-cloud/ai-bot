# R8 rules for the release build.
#
# Only rules that are actually needed are listed. A file full of defensive
# "keep everything" lines is the same as not shrinking at all, and it hides the
# one class that really does get stripped.

# --- Crash reports -----------------------------------------------------------
# Without this, every stack trace from a release build is unreadable.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod

# --- Warnings from optional back-ends that never exist on Android ------------
-dontwarn kotlinx.coroutines.**
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn androidx.media3.**

# --- App classes reached only by the framework -------------------------------
# These are named in AndroidManifest.xml or in XML resources, so R8 cannot see
# any reference to them from Kotlin code.
-keep class ir.studying.app.App { *; }
-keep class ir.studying.app.MainActivity { *; }
-keep class ir.studying.app.widget.StudyWidget { *; }
-keep class ir.studying.app.notify.StudyTileService { *; }
-keep class ir.studying.app.notify.StudyActionReceiver { *; }
-keep class ir.studying.app.notify.ReminderReceiver { *; }
-keep class ir.studying.app.notify.DaySummaryReceiver { *; }
-keep class ir.studying.app.notify.BootReceiver { *; }
-keep class ir.studying.app.player.PlaybackService { *; }

# WorkManager instantiates workers by class name through reflection.
-keep class * extends androidx.work.ListenableWorker { public <init>(...); }

# --- JSON --------------------------------------------------------------------
# Parsing is hand-written with org.json, with no reflection-based mapping, so
# no model class needs keeping. This note exists so nobody adds blanket keeps
# for ir.studying.app.data.** "just in case" later.

# Official Myket Billing2.2 proxy activities, AIDL, reflection and model callbacks.
-keep class ir.myket.billingclient.** { *; }
-keep interface ir.myket.billingclient.** { *; }
-keep class com.android.vending.billing.** { *; }

# --- اتاق سه‌بعدی (WebView) --------------------------------------------------
# صفحهٔ assets/room3d فقط با همین متد علامت‌خورده با اپ حرف می‌زند.
-keepclassmembers class ir.studying.app.ui.study.room.Room3DBridge {
    @android.webkit.JavascriptInterface <methods>;
}
