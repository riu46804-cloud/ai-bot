/* هفت‌خانِ تمرکز — جلوه‌های صوتی کاملاً مصنوعی با WebAudio (بدون فایل صوتی). */
(function () {
  'use strict';
  var R3 = window.R3;
  var ctx = null, master = null, noiseBuf = null, last = {};

  function ensure() {
    if (ctx) return ctx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.42;
      var comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -16; comp.ratio.value = 4;
      master.connect(comp); comp.connect(ctx.destination);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0);
      for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    } catch (e) { ctx = null; }
    return ctx;
  }

  function tone(type, f0, f1, t0, dur, vol, opts) {
    opts = opts || {};
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur * (opts.sweep || 1));
    if (opts.vib) {
      var l = ctx.createOscillator(), lg = ctx.createGain();
      l.frequency.value = opts.vib; lg.gain.value = opts.vibDepth || 8;
      l.connect(lg); lg.connect(o.frequency); l.start(t0); l.stop(t0 + dur + 0.05);
    }
    var a = opts.attack || 0.005;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    var node = o;
    if (opts.lp) { var f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = opts.lp; o.connect(f); node = f; }
    node.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  function noise(t0, dur, vol, type, freq, q) {
    var s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noiseBuf;
    f.type = type || 'lowpass'; f.frequency.value = freq || 800; f.Q.value = q || 0.8;
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t0); s.stop(t0 + dur + 0.02);
  }

  var N = { C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392, A4: 440, B4: 493.88, C5: 523.25, D5: 587.33, E5: 659.25, G5: 783.99, A5: 880, C6: 1046.5, E6: 1318.5 };

  var SFX = {
    tap: function (t) { tone('sine', 660, 520, t, 0.06, 0.12); },
    orb: function (t) { tone('sine', 700 + Math.random() * 200, 1300, t, 0.14, 0.05); },
    hit: function (t, o) {
      var big = o && o.big;
      tone('sine', big ? 150 : 190, 60, t, big ? 0.22 : 0.14, big ? 0.32 : 0.16);
      noise(t, big ? 0.16 : 0.08, big ? 0.22 : 0.09, 'lowpass', big ? 900 : 1400);
    },
    combo: function (t) {
      [N.C5, N.E5, N.G5, N.C6].forEach(function (f, i) { tone('triangle', f, f, t + i * 0.07, 0.25, 0.16); });
      noise(t, 0.35, 0.06, 'highpass', 3000);
    },
    drop: function (t) { tone('sine', 220, 70, t, 0.25, 0.3); noise(t, 0.2, 0.15, 'lowpass', 600); tone('sine', N.E6, N.E6, t + 0.12, 0.3, 0.06); },
    shake: function (t) { for (var i = 0; i < 4; i++) noise(t + i * 0.09, 0.06, 0.12, 'bandpass', 1800 + i * 300, 3); },
    open: function (t, o) {
      noise(t, 0.5, 0.2, 'highpass', 1200);
      var seq = o && o.rarity === 'epic' ? [N.C5, N.E5, N.G5, N.C6, N.E6] : (o && o.rarity === 'rare' ? [N.D5, N.G5, N.A5, N.D5 * 2] : [N.E5, N.G5, N.C6]);
      seq.forEach(function (f, i) { tone('triangle', f, f, t + 0.05 + i * 0.075, 0.4, 0.15); tone('sine', f * 2, f * 2, t + 0.05 + i * 0.075, 0.25, 0.04); });
    },
    coin: function (t) { tone('square', 1320, 1320, t, 0.06, 0.05, { lp: 4000 }); tone('square', 1760, 1760, t + 0.06, 0.16, 0.05, { lp: 4000 }); },
    victory: function (t) {
      var ch = [[N.C4, N.E4, N.G4], [N.F4, N.A4, N.C5], [N.G4, N.B4, N.D5], [N.C5, N.E5, N.G5, N.C6]];
      ch.forEach(function (c, i) {
        c.forEach(function (f) { tone('triangle', f, f, t + i * 0.22, i === 3 ? 1.2 : 0.3, 0.09); tone('sawtooth', f, f, t + i * 0.22, i === 3 ? 0.9 : 0.25, 0.018, { lp: 2200 }); });
      });
      noise(t + 0.66, 0.9, 0.08, 'highpass', 5000);
    },
    roar: function (t) {
      tone('sawtooth', 95, 70, t, 0.9, 0.13, { vib: 18, vibDepth: 14, lp: 700, attack: 0.08 });
      noise(t, 0.8, 0.1, 'lowpass', 500);
    },
    levelup: function (t) {
      tone('sine', 400, 1600, t, 0.5, 0.12, { sweep: 0.9 });
      [N.C5, N.E5, N.G5, N.C6, N.E6].forEach(function (f, i) { tone('triangle', f, f, t + 0.3 + i * 0.06, 0.5, 0.11); });
    },
    cheer: function (t) { tone('sine', 900, 500, t, 0.12, 0.16); tone('sine', 1300, 800, t + 0.08, 0.14, 0.1); },
    start: function (t) { [N.G4, N.D5].forEach(function (f, i) { tone('sine', f, f, t + i * 0.12, 1.1, 0.13); tone('sine', f * 3, f * 3, t + i * 0.12, 0.5, 0.02); }); },
    pause: function (t) { tone('sine', N.D5, N.G4, t, 0.35, 0.1); },
    error: function (t) { tone('square', 160, 120, t, 0.2, 0.06, { lp: 900 }); },
    spawn: function (t) { tone('sawtooth', 60, 180, t, 1.0, 0.08, { lp: 600, attack: 0.3 }); noise(t, 1.0, 0.07, 'lowpass', 400); },
    whoosh: function (t) { noise(t, 0.35, 0.12, 'bandpass', 1200, 0.7); }
  };

  R3.sfx = {
    enabled: true,
    unlock: function () {
      if (!R3.sfx.enabled) return;
      var c = ensure();
      if (c && c.state === 'suspended') c.resume();
    },
    suspend: function () { if (ctx && ctx.state === 'running') ctx.suspend(); },
    play: function (name, opts) {
      if (!R3.sfx.enabled || document.hidden) return;
      var c = ensure();
      if (!c || c.state !== 'running' || !SFX[name]) return;
      var nowMs = Date.now();
      var gap = name === 'hit' ? 90 : (name === 'orb' ? 120 : (name === 'coin' ? 70 : 30));
      if (last[name] && nowMs - last[name] < gap) return;
      last[name] = nowMs;
      try { SFX[name](c.currentTime + 0.01, opts); } catch (e) { }
    }
  };
  ['pointerdown', 'touchstart'].forEach(function (ev) {
    window.addEventListener(ev, function () { R3.sfx.unlock(); }, { passive: true });
  });
})();
