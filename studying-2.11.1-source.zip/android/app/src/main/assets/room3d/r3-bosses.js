/* هفت‌خانِ تمرکز — هفت خانِ رستم، همه رویه‌ای. هر خان یک ریگ ساده دارد:
   بدن، سر، دو دست (+ بال یا فک) تا انیمیشن‌ها برای همه یکسان کار کنند. */
(function () {
  'use strict';
  var R3 = window.R3, T = THREE, M = R3.models, tr = M.tr, B = M.Builder, PI = Math.PI;

  function pivot(parent, x, y, z) { var g = new T.Group(); g.position.set(x, y, z); parent.add(g); return g; }
  function part(parent, b, mat, ow) { var m = M.mesh(b.build(), mat, ow); parent.add(m); return m; }
  function glowEyes(parent, pts, sx, color) {
    var b = new B();
    pts.forEach(function (p) { b.add(M.sphere(10), color, tr(p, p[3] ? [0, 0, p[3]] : null, sx)); });
    var mat = M.basic(color);
    var m = new T.Mesh(b.build(), mat); parent.add(m);
    var glows = pts.map(function (p) {
      var s = new T.Sprite(new T.SpriteMaterial({ map: M.glowTex, color: color, transparent: true, opacity: 0.85, blending: T.AdditiveBlending, depthWrite: false }));
      s.scale.setScalar(0.75); s.position.set(p[0], p[1], p[2] + 0.06); parent.add(s); return s;
    });
    return { mesh: m, mat: mat, glows: glows };
  }
  function claws(b, x, y, z, n, color, s) {
    s = s || 1;
    for (var i = 0; i < n; i++) b.add(M.cone(8), color, tr([x + (i - (n - 1) / 2) * 0.14 * s, y, z], [PI / 2 + 0.4, 0, 0], [0.05 * s, 0.16 * s, 0.05 * s]));
  }
  function spots(b, rnd, n, cx, cy, cz, rx, ry, rz, color, size) {
    for (var i = 0; i < n; i++) {
      var a = rnd() * PI * 1.2 - PI * 0.6, h = rnd() * 2 - 1;
      b.add(M.sphere(8), color, tr([cx + Math.sin(a) * rx, cy + h * ry, cz + Math.cos(a) * rz], [rnd(), rnd(), 0], [size * (0.6 + rnd() * 0.6), size * (0.4 + rnd() * 0.5), size * 0.35]));
    }
  }

  var BUILD = {};

  /* ---------------------------------------------------------- خان ۱: شیر */
  BUILD.lion = function (r, mat) {
    var gold = 0xE7A93B, light = 0xF8D98E, maneA = 0xA0521D, maneB = 0xC9702A, dark = 0x3B2A25;
    var b = new B();
    b.add(M.sphere(18), gold, tr([0, 1.75, 0], null, [1.12, 1.25, 0.95]));
    b.add(M.sphere(16), light, tr([0, 1.62, 0.52], null, [0.74, 0.88, 0.5]));
    [-1, 1].forEach(function (s) {
      b.add(M.sphere(14), gold, tr([s * 0.78, 0.58, 0.05], null, [0.55, 0.52, 0.78]));
      b.add(M.sphere(12), light, tr([s * 0.82, 0.14, 0.78], null, [0.36, 0.16, 0.46]));
      claws(b, s * 0.82, 0.12, 1.2, 3, 0xFFF7E6, 0.9);
    });
    M.chain(b, [[0.7, 0.35, -0.75], [1.2, 0.5, -0.95], [1.6, 0.9, -0.9], [1.75, 1.4, -0.7], [1.7, 1.8, -0.55]], 0.13, 0.11, gold);
    b.add(M.sphere(12), maneA, tr([1.68, 2.02, -0.5], null, [0.26, 0.3, 0.26]));
    part(r.body, b, mat, 0.045);

    var h = new B(), i;
    h.add(M.sphere(16), maneA, tr([0, 0.02, -0.28], null, [1.1, 1.12, 0.66]));
    for (i = 0; i < 16; i++) {
      var a = i / 16 * PI * 2;
      h.add(M.sphere(10), i % 2 ? maneA : maneB, tr([Math.sin(a) * 0.92, Math.cos(a) * 0.92 + 0.02, -0.05], [0, 0, -a], [0.4, 0.5, 0.42]));
    }
    h.add(M.sphere(18), gold, tr([0, 0, 0.18], null, [0.78, 0.74, 0.7]));
    h.add(M.sphere(14), 0xFBE7BD, tr([0, -0.27, 0.66], null, [0.44, 0.3, 0.34]));
    h.add(M.sphere(10), dark, tr([0, -0.1, 0.95], null, [0.16, 0.1, 0.09]));
    h.add(M.sphere(12), 0x7F1D1D, tr([0, -0.5, 0.62], null, [0.3, 0.13, 0.24]));
    [-1, 1].forEach(function (s) {
      h.add(M.cone(8), 0xFFFFFF, tr([s * 0.13, -0.42, 0.84], [PI, 0, 0], [0.05, 0.14, 0.05]));
      h.add(M.sphere(10), gold, tr([s * 0.55, 0.6, 0.05], null, [0.2, 0.21, 0.1]));
      h.add(M.sphere(8), 0x9A5A20, tr([s * 0.55, 0.6, 0.1], null, [0.11, 0.12, 0.05]));
      h.add(M.rbox(0.34, 0.07, 0.07, 0.03), dark, tr([s * 0.27, 0.24, 0.8], [0, 0, s * -0.42]));
    });
    part(r.head, h, mat, 0.04);
    r.eyes = glowEyes(r.head, [[-0.27, 0.1, 0.81], [0.27, 0.1, 0.81]], [0.13, 0.1, 0.07], 0xFFE34D);
    var lp = new B(); [-1, 1].forEach(function (s) { lp.add(M.sphere(8), 0x1F1206, tr([s * 0.27, 0.1, 0.875], null, [0.035, 0.085, 0.02])); }); part(r.head, lp, mat, 0);

    [r.armL, r.armR].forEach(function (p, k) {
      var s = k ? 1 : -1, a = new B();
      a.add(M.capsule(0.27, 1.1), gold, tr([0, -0.75, 0.1]));
      a.add(M.sphere(12), light, tr([0, -1.5, 0.28], null, [0.36, 0.24, 0.44]));
      claws(a, 0, -1.55, 0.7, 3, 0xFFF7E6, 1);
      part(p, a, mat, 0.04);
      p.position.set(s * 0.82, 2.25, 0.4);
    });
    r.head.position.set(0, 2.9, 0.35);
    return { aura: 'dust', auraColor: 0xFFD27A, eye: 0xFFE34D, height: 3.9, idle: 'sway' };
  };

  /* ---------------------------------------------------------- خان ۲: غول تشنگی */
  BUILD.desert = function (r, mat) {
    var sand = 0xD9A95B, sandD = 0xB9863F, sandL = 0xEBC783, crack = 0xFF7A1A;
    var b = new B(), rnd = R3.rng(22);
    b.add(M.ico(1), sand, tr([0, 1.85, 0], [0.2, 0.4, 0], [1.2, 1.1, 0.95]));
    b.add(M.ico(1), sandL, tr([0, 1.55, 0.6], [0.5, 0.1, 0], [0.7, 0.6, 0.4]));
    [-1, 1].forEach(function (s) {
      b.add(M.ico(1), sandD, tr([s * 1.0, 2.55, -0.05], [rnd(), rnd(), rnd()], 0.58));
      b.add(M.ico(1), sand, tr([s * 0.55, 0.55, 0], [rnd(), rnd(), 0], [0.5, 0.62, 0.52]));
      b.add(M.ico(0), sandD, tr([s * 0.6, 0.1, 0.25], [0, rnd(), 0], [0.5, 0.2, 0.6]));
    });
    for (var i = 0; i < 9; i++) b.add(M.ico(0), i % 2 ? sandD : sandL, tr([(rnd() - 0.5) * 1.8, 1.2 + rnd() * 1.4, -0.55 - rnd() * 0.3], [rnd() * 3, rnd() * 3, 0], 0.18 + rnd() * 0.2));
    // کاکتوس کوچک روی شانه
    b.add(M.capsule(0.1, 0.32), 0x3F9B4C, tr([-1.05, 3.15, 0]));
    b.add(M.capsule(0.06, 0.12), 0x3F9B4C, tr([-0.92, 3.12, 0], [0, 0, -0.9]));
    b.add(M.sphere(8), 0xF472B6, tr([-1.05, 3.45, 0], null, 0.07));
    part(r.body, b, mat, 0.045);
    // ترک‌های گداخته
    var c = new B();
    [[0.2, 2.1, 0.92, 0.5], [-0.35, 1.7, 0.95, -0.7], [0.45, 1.35, 0.82, 1.1], [-0.1, 2.5, 0.75, 0.2]].forEach(function (q) {
      c.add(M.box(), crack, tr([q[0], q[1], q[2]], [0, 0, q[3]], [0.42, 0.05, 0.05]));
    });
    var cm = new T.Mesh(c.build(), M.basic(crack)); r.body.add(cm); r.glowParts.push(cm);

    var h = new B();
    h.add(M.ico(1), sand, tr([0, 0, 0], [0.3, 0.2, 0], [0.66, 0.58, 0.62]));
    h.add(M.ico(1), sandD, tr([0, -0.38, 0.28], [0, 0, 0], [0.5, 0.2, 0.36]));
    h.add(M.rbox(0.62, 0.1, 0.12, 0.04), 0x4A2E14, tr([0, -0.3, 0.6]));
    [-1, 1].forEach(function (s) {
      M.horn(h, [s * 0.45, 0.35, 0], [s, 0.4, 0], [s * 0.2, 1, 0], 0.5, 0.12, 4, sandD, 0x7C5A2B);
      h.add(M.rbox(0.3, 0.08, 0.08, 0.03), 0x4A2E14, tr([s * 0.22, 0.2, 0.55], [0, 0, s * -0.35]));
    });
    part(r.head, h, mat, 0.04);
    r.eyes = glowEyes(r.head, [[-0.22, 0.06, 0.62, 0.2], [0.22, 0.06, 0.62, -0.2]], [0.14, 0.06, 0.06], 0xFF5A1F);

    [r.armL, r.armR].forEach(function (p, k) {
      var s = k ? 1 : -1, a = new B(), rr = R3.rng(5 + k);
      M.chain(a, [[0, -0.1, 0], [s * 0.15, -0.6, 0.12], [s * 0.2, -1.1, 0.22]], 0.34, 0.3, function (t) { return t > 0.5 ? sandD : sand; });
      a.add(M.ico(1), sandD, tr([s * 0.22, -1.65, 0.3], [rr(), rr(), 0], 0.48));
      part(p, a, mat, 0.04);
      p.position.set(s * 1.3, 2.45, 0.05);
    });
    r.head.position.set(0, 3.15, 0.1);
    return { aura: 'dust', auraColor: 0xE8C27A, eye: 0xFF5A1F, height: 3.9, idle: 'sway' };
  };

  /* ---------------------------------------------------------- خان ۳: اژدها */
  BUILD.dragon = function (r, mat) {
    var green = 0x2F9E6E, greenD = 0x1F7A55, belly = 0xF1DC7A, spine = 0xE4572E, bone = 0xF5E9CC;
    var b = new B();
    var path = [[-1.9, 0.25, -1.3], [-1.2, 0.35, -1.6], [-0.2, 0.45, -1.5], [0.8, 0.55, -1.1], [1.2, 0.75, -0.3], [0.8, 1.05, 0.3], [0.2, 1.45, 0.45], [0, 1.95, 0.4], [0, 2.45, 0.35], [0.05, 2.9, 0.4]];
    // منحنی نرم با نمونه‌برداری
    var curve = new T.CatmullRomCurve3(path.map(function (p) { return new T.Vector3(p[0], p[1], p[2]); }));
    var pts = curve.getPoints(26), i;
    for (i = 0; i < pts.length; i++) {
      var t = i / (pts.length - 1), rad = 0.14 + Math.sin(Math.min(1, t * 1.25) * PI * 0.62) * 0.55;
      b.add(M.sphere(12), (function (front) { return function (lp) { return lp.z > 0.55 && front ? belly : (lp.y > 0.7 ? greenD : green); }; })(i > 8), tr([pts[i].x, pts[i].y, pts[i].z], null, rad));
      if (i % 2 === 0 && i > 2) b.add(M.cone(6), spine, tr([pts[i].x, pts[i].y + rad * 0.75, pts[i].z - rad * 0.55], [-0.6, 0, 0], [rad * 0.28, rad * 0.75, rad * 0.28]));
    }
    // پاهای جلو
    [-1, 1].forEach(function (s) {
      b.add(M.capsule(0.15, 0.55), green, tr([s * 0.62, 1.55, 0.72], [0.9, 0, s * 0.5]));
      b.add(M.sphere(10), greenD, tr([s * 0.8, 1.25, 1.05], null, [0.22, 0.14, 0.26]));
      claws(b, s * 0.8, 1.2, 1.3, 3, bone, 0.8);
    });
    part(r.body, b, mat, 0.04);

    var h = new B();
    h.add(M.sphere(16), green, tr([0, 0.05, 0], null, [0.6, 0.52, 0.72]));
    h.add(M.sphere(14), green, tr([0, -0.05, 0.62], null, [0.42, 0.3, 0.55]));
    h.add(M.sphere(10), greenD, tr([0, 0.18, 0.7], null, [0.36, 0.12, 0.4]));
    [-1, 1].forEach(function (s) {
      h.add(M.sphere(8), 0x13261C, tr([s * 0.14, 0.05, 1.12], null, [0.05, 0.04, 0.03]));
      M.horn(h, [s * 0.3, 0.35, -0.2], [s * 0.35, 0.45, -1], [s * 0.1, 1, -0.4], 1.0, 0.11, 5, bone, 0x6B5B3A);
      h.add(M.cone(8), spine, tr([s * 0.55, 0.0, -0.1], [0, 0, s * -1.4], [0.12, 0.4, 0.06]));
      h.add(M.rbox(0.3, 0.07, 0.08, 0.03), 0x13261C, tr([s * 0.22, 0.3, 0.58], [0, 0, s * -0.4]));
    });
    part(r.head, h, mat, 0.035);
    r.jaw = pivot(r.head, 0, -0.18, 0.12);
    var j = new B();
    j.add(M.sphere(12), green, tr([0, -0.1, 0.45], null, [0.36, 0.13, 0.55]));
    j.add(M.sphere(10), 0x8B1E2F, tr([0, 0.0, 0.48], null, [0.28, 0.06, 0.45]));
    [-1, 1].forEach(function (s) { for (var k = 0; k < 3; k++) j.add(M.cone(6), 0xFFFFFF, tr([s * (0.2 - k * 0.04), 0.06, 0.7 + k * 0.15], null, [0.035, 0.1, 0.035])); });
    part(r.jaw, j, mat, 0.03);
    r.eyes = glowEyes(r.head, [[-0.3, 0.15, 0.6, 0.3], [0.3, 0.15, 0.6, -0.3]], [0.12, 0.08, 0.06], 0xFFB703);

    // بال‌ها
    r.wings = [];
    [-1, 1].forEach(function (s) {
      var p = pivot(r.body, s * 0.45, 2.35, -0.25), w = new B();
      var bones = [[1.5, 1.3], [1.9, 0.5], [1.7, -0.3], [1.1, -0.8]];
      var prev = null;
      bones.forEach(function (bn, idx) {
        var x = s * bn[0], y = bn[1];
        var len = Math.sqrt(x * x + y * y), ang = Math.atan2(y, x);
        w.add(M.cyl(0.04, 0.06, 6), 0x5B1A2B, tr([x / 2, y / 2, 0], [0, 0, ang - PI / 2], [1, len, 1]));
        if (prev) {
          var m = new T.Matrix4(), g = M.tri();
          // پرده بین دو استخوان: مثلث (۰،۰) → استخوان قبلی → این استخوان
          m.set(prev[0], x, 0, 0, prev[1], y, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
          w.add(g, idx % 2 ? 0x9F2B47 : 0x8B1E3F, m);
        }
        prev = [x, y];
      });
      w.add(M.cyl(0.06, 0.08, 6), 0x5B1A2B, tr([s * 0.75, 0.65, 0], [0, 0, Math.atan2(1.3, s * 1.5) - PI / 2], [1, 0.4, 1]));
      var wm = M.mesh(w.build(), mat, 0); p.add(wm);
      wm.material = mat; p.rotation.y = s * -0.35;
      r.wings.push(p);
    });
    r.armL.position.set(-0.6, 1.6, 0.7); r.armR.position.set(0.6, 1.6, 0.7);
    r.head.position.set(0, 3.25, 0.62);
    return { aura: 'embers', auraColor: 0xFF8A3D, eye: 0xFFB703, height: 4.0, idle: 'coil' };
  };

  /* ---------------------------------------------------------- خان ۴: زن جادو */
  BUILD.witch = function (r, mat) {
    var robe = 0x5B21B6, robeD = 0x3B0F80, skin = 0x9AD08B, hair = 0x1F1B2E, gold = 0xF5B800;
    var b = new B();
    b.add(M.cone(18), function (lp) { return lp.y < -0.38 ? robeD : robe; }, tr([0, 1.35, 0], null, [1.15, 2.7, 1.0]));
    b.add(M.torus(0.52, 0.06, 0, 6, 22), gold, tr([0, 1.95, 0], [PI / 2, 0, 0], [1, 0.9, 1]));
    b.add(M.sphere(12), robeD, tr([0, 2.5, -0.05], null, [0.55, 0.32, 0.45]));
    b.add(M.cone(10), 0x7C3AED, tr([0, 2.55, 0], [PI, 0, 0], [0.6, 0.3, 0.5]));
    b.add(M.octa(), 0xF0ABFC, tr([0, 2.38, 0.42], null, [0.1, 0.14, 0.05]));
    part(r.body, b, mat, 0.04);

    var h = new B();
    h.add(M.sphere(16), hair, tr([0, -0.2, -0.2], null, [0.6, 0.85, 0.45]));
    h.add(M.sphere(16), skin, tr([0, 0, 0.05], null, [0.46, 0.53, 0.46]));
    h.add(M.cone(10), skin, tr([0, -0.03, 0.62], [PI / 2 - 0.25, 0, 0], [0.07, 0.36, 0.07]));
    h.add(M.sphere(8), 0x5E8F52, tr([0.05, 0.05, 0.75], null, 0.03));
    h.add(M.rbox(0.24, 0.05, 0.05, 0.02), 0x6B1E3A, tr([0, -0.27, 0.43], [0, 0, 0]));
    [-1, 1].forEach(function (s) { h.add(M.rbox(0.22, 0.05, 0.06, 0.02), hair, tr([s * 0.17, 0.2, 0.43], [0, 0, s * -0.35])); });
    h.add(M.cyl(1, 1, 22), 0x2E1065, tr([0, 0.4, 0], [-0.08, 0, 0], [0.95, 0.05, 0.95]));
    h.add(M.cone(14), 0x2E1065, tr([0, 0.95, -0.15], [-0.3, 0, 0.12], [0.42, 1.15, 0.42]));
    h.add(M.cone(10), 0x2E1065, tr([0.25, 1.55, -0.55], [-1.2, 0, 0.5], [0.15, 0.45, 0.15]));
    h.add(M.torus(0.4, 0.05, 0, 6, 20), gold, tr([0, 0.5, -0.04], [PI / 2 - 0.08, 0, 0]));
    part(r.head, h, mat, 0.035);
    r.eyes = glowEyes(r.head, [[-0.17, 0.06, 0.47], [0.17, 0.06, 0.47]], [0.085, 0.065, 0.04], 0xF0ABFC);

    [r.armL, r.armR].forEach(function (p, k) {
      var s = k ? 1 : -1, a = new B();
      a.add(M.cone(12), robe, tr([s * 0.05, -0.55, 0.12], [0.25, 0, s * -0.25], [0.28, 1.15, 0.28]));
      a.add(M.sphere(10), skin, tr([s * 0.18, -1.15, 0.32], null, 0.13));
      if (k) {
        a.add(M.cyl(0.05, 0.06, 8), 0x6B4226, tr([0.2, -0.95, 0.38], null, [1, 2.9, 1]));
        a.add(M.ico(0), 0xC4B5FD, tr([0.2, 0.55, 0.38], [0.3, 0.5, 0], 0.18));
      }
      part(p, a, mat, 0.035);
      p.position.set(s * 0.55, 2.4, 0.05);
      if (k) {
        var orb = new T.Sprite(new T.SpriteMaterial({ map: M.glowTex, color: 0xC084FC, transparent: true, opacity: 0.95, blending: T.AdditiveBlending, depthWrite: false }));
        orb.scale.setScalar(1.1); orb.position.set(0.2, 0.55, 0.38); p.add(orb); r.glowSprites.push(orb);
      }
    });
    r.head.position.set(0, 2.95, 0.05);
    return { aura: 'magic', auraColor: 0xC084FC, eye: 0xF0ABFC, height: 4.3, idle: 'hover' };
  };

  /* ---------------------------------------------------------- خان ۵: اولاد مرزبان */
  BUILD.olad = function (r, mat) {
    var steel = 0x8C9BAD, steelD = 0x5F6E80, red = 0xB91C1C, leather = 0x5B3A29, skin = 0xE0AC7E, beard = 0x1F1A17, gold = 0xD4A017;
    var b = new B();
    b.add(M.rbox(1.45, 1.35, 0.85, 0.3), steel, tr([0, 2.25, 0]));
    b.add(M.rbox(1.0, 0.5, 0.06, 0.04), steelD, tr([0, 2.35, 0.44]));
    b.add(M.cyl(0.62, 0.95, 16), red, tr([0, 1.15, 0], null, [1, 0.9, 0.9]));
    b.add(M.torus(0.68, 0.07, 0, 6, 22), gold, tr([0, 1.6, 0], [PI / 2, 0, 0], [1, 0.75, 1]));
    b.add(M.rbox(0.22, 0.18, 0.08, 0.03), gold, tr([0, 1.6, 0.52]));
    [-1, 1].forEach(function (s) {
      b.add(M.capsule(0.2, 0.55), leather, tr([s * 0.35, 0.5, 0]));
      b.add(M.rbox(0.36, 0.22, 0.52, 0.08), 0x3A261B, tr([s * 0.35, 0.11, 0.08]));
      b.add(M.sphere(12), steelD, tr([s * 0.82, 2.75, 0], null, [0.42, 0.3, 0.42]));
    });
    part(r.body, b, mat, 0.045);

    var h = new B();
    h.add(M.sphere(16), skin, tr([0, 0, 0.05], null, [0.45, 0.5, 0.45]));
    h.add(M.sphere(14), beard, tr([0, -0.32, 0.22], null, [0.46, 0.42, 0.34]));
    h.add(M.sphere(10), beard, tr([0, -0.62, 0.3], null, [0.24, 0.28, 0.2]));
    [-1, 1].forEach(function (s) {
      h.add(M.capsule(0.05, 0.26), beard, tr([s * 0.17, -0.12, 0.45], [0, 0, s * 1.2]));
      h.add(M.rbox(0.22, 0.07, 0.07, 0.03), beard, tr([s * 0.16, 0.2, 0.42], [0, 0, s * -0.3]));
    });
    h.add(M.sphere(10), 0xC98D63, tr([0, 0.03, 0.5], null, [0.08, 0.1, 0.07]));
    h.add(M.hemi(18), steel, tr([0, 0.12, 0], null, [0.52, 0.5, 0.52]));
    h.add(M.torus(0.52, 0.05, 0, 6, 22), gold, tr([0, 0.13, 0], [PI / 2, 0, 0]));
    h.add(M.cone(10), gold, tr([0, 0.8, 0], null, [0.07, 0.3, 0.07]));
    h.add(M.rbox(0.08, 0.32, 0.06, 0.02), steelD, tr([0, 0.0, 0.5]));
    M.chain(h, [[0, 0.95, 0], [0, 1.1, -0.2], [0, 1.08, -0.45], [0, 0.9, -0.62]], 0.1, 0.07, red);
    part(r.head, h, mat, 0.035);
    r.eyes = glowEyes(r.head, [[-0.16, 0.05, 0.465], [0.16, 0.05, 0.465]], [0.075, 0.055, 0.035], 0xFFC857);

    [r.armL, r.armR].forEach(function (p, k) {
      var s = k ? 1 : -1, a = new B();
      a.add(M.capsule(0.2, 0.8), steel, tr([0, -0.55, 0.1]));
      a.add(M.sphere(10), skin, tr([0, -1.15, 0.22], null, 0.18));
      if (!k) {
        a.add(M.cyl(0.62, 0.62, 22), red, tr([-0.25, -0.75, 0.42], [PI / 2, 0, 0.1], [1, 0.1, 1]));
        a.add(M.torus(0.6, 0.05, 0, 6, 24), gold, tr([-0.25, -0.75, 0.48], [0, 0.1, 0]));
        a.add(M.sphere(12), gold, tr([-0.25, -0.75, 0.5], null, [0.17, 0.17, 0.1]));
        for (var i = 0; i < 8; i++) { var an = i / 8 * PI * 2; a.add(M.sphere(6), gold, tr([-0.25 + Math.sin(an) * 0.4, -0.75 + Math.cos(an) * 0.4, 0.49], null, 0.045)); }
      } else {
        a.add(M.cyl(0.045, 0.05, 8), 0x6B4226, tr([0.05, -0.6, 0.3], null, [1, 3.6, 1]));
        a.add(M.cone(8), 0xD8DEE6, tr([0.05, 1.4, 0.3], null, [0.12, 0.4, 0.12]));
        a.add(M.sphere(8), red, tr([0.05, 1.12, 0.3], null, [0.1, 0.14, 0.1]));
      }
      part(p, a, mat, 0.035);
      p.position.set(s * 0.95, 2.7, 0.05);
    });
    r.head.position.set(0, 3.35, 0.02);
    return { aura: 'sparks', auraColor: 0xFFD166, eye: 0xFFC857, height: 4.2, idle: 'sway' };
  };

  /* ---------------------------------------------------------- خان ۶/۷: دیوها */
  function div(r, mat, o) {
    var b = new B(), rnd = R3.rng(o.seed);
    b.add(M.sphere(18), o.skin, tr([0, 2.05, 0], null, [1.25, 1.15, 0.92]));
    b.add(M.sphere(16), o.belly, tr([0, 1.7, 0.45], null, [0.85, 0.75, 0.55]));
    [-1, 1].forEach(function (s) {
      b.add(M.sphere(14), o.skin, tr([s * 0.55, 2.55, 0.55], null, [0.48, 0.32, 0.3]));
      b.add(M.capsule(0.3, 0.6), o.skin, tr([s * 0.48, 0.62, 0]));
      b.add(M.sphere(12), o.skinD, tr([s * 0.5, 0.14, 0.12], null, [0.38, 0.17, 0.48]));
      claws(b, s * 0.5, 0.12, 0.55, 3, 0xF8F1E0, 0.9);
    });
    b.add(M.cyl(1.05, 1.15, 16), o.cloth, tr([0, 1.15, 0], null, [1, 0.45, 0.85]));
    spots(b, rnd, 10, 0, 1.6, 0.86, 1.15, 0.45, 0.86, o.cloth2, 0.16);
    spots(b, rnd, o.spots, 0, 2.1, 0, 1.25, 0.9, 0.9, o.spot, 0.2);
    part(r.body, b, mat, 0.05);

    var h = new B();
    h.add(M.sphere(18), o.skin, tr([0, 0, 0], null, [0.75, 0.7, 0.7]));
    h.add(M.sphere(14), o.skinD, tr([0, -0.3, 0.45], null, [0.5, 0.25, 0.32]));
    h.add(M.sphere(12), 0x3A0E12, tr([0, -0.33, 0.62], null, [0.38, 0.1, 0.18]));
    [-1, 1].forEach(function (s) {
      M.horn(h, [s * 0.5, 0.4, -0.05], [s, 0.25, 0], [s * 0.25, 1, 0.1], o.hornLen, 0.14, 6, o.horn, o.hornTip);
      h.add(M.cone(8), 0xFFFBEB, tr([s * 0.25, -0.18, 0.72], [-0.15, 0, s * -0.15], [0.07, 0.26, 0.07]));
      h.add(M.cone(8), o.skin, tr([s * 0.75, 0.05, -0.05], [0, 0, s * -1.25], [0.12, 0.38, 0.07]));
      h.add(M.rbox(0.4, 0.1, 0.1, 0.04), o.brow, tr([s * 0.28, 0.27, 0.6], [0, 0, s * -0.4]));
    });
    if (o.hair) M.chain(h, [[0, 0.55, -0.2], [0, 0.35, -0.6], [0, -0.1, -0.75], [0, -0.6, -0.7]], 0.32, 0.2, o.hair);
    part(r.head, h, mat, 0.045);
    r.eyes = glowEyes(r.head, [[-0.27, 0.1, 0.665, 0.25], [0.27, 0.1, 0.665, -0.25]], [0.14, 0.09, 0.06], o.eye);

    [r.armL, r.armR].forEach(function (p, k) {
      var s = k ? 1 : -1, a = new B();
      M.chain(a, [[0, 0, 0], [s * 0.2, -0.5, 0.1], [s * 0.28, -1.0, 0.2]], 0.36, 0.3, o.skin);
      a.add(M.sphere(14), o.skinD, tr([s * 0.3, -1.5, 0.3], null, [0.42, 0.4, 0.42]));
      if (k && o.club) {
        a.add(M.cyl(0.24, 0.09, 10), 0x6B4226, tr([s * 0.32, -0.6, 0.62], [0.35, 0, 0], [1, 2.2, 1]));
        for (var i = 0; i < 6; i++) { var an = i / 6 * PI * 2; a.add(M.cone(6), 0xD1D5DB, tr([s * 0.32 + Math.sin(an) * 0.22, 0.25, 0.95 + Math.cos(an) * 0.22], [Math.cos(an) * 1.4, 0, -Math.sin(an) * 1.4], [0.06, 0.18, 0.06])); }
      }
      if (o.chain) { for (var c = 0; c < 4; c++) a.add(M.torus(0.1, 0.03, 0, 6, 12), 0x9CA3AF, tr([s * 0.3, -1.95 - c * 0.17, 0.3], [0, c % 2 ? PI / 2 : 0, 0])); }
      part(p, a, mat, 0.045);
      p.position.set(s * 1.25, 2.7, 0.05);
    });
    r.head.position.set(0, 3.45, 0.15);
  }
  BUILD.arzhang = function (r, mat) {
    div(r, mat, { seed: 6, skin: 0xB4442F, skinD: 0x8E2F1F, belly: 0xCF6A4C, cloth: 0x7C5A2B, cloth2: 0x3B2A1A, spot: 0x8E2F1F, spots: 8,
      horn: 0xF5E9CC, hornTip: 0x3F3F46, hornLen: 0.75, brow: 0x2A0F0A, eye: 0xFFD60A, club: true });
    return { aura: 'embers', auraColor: 0xFF5A3D, eye: 0xFFD60A, height: 4.3, idle: 'sway' };
  };
  BUILD.white = function (r, mat) {
    div(r, mat, { seed: 7, skin: 0xEEF2F7, skinD: 0xC9D3DF, belly: 0xFFFFFF, cloth: 0x334155, cloth2: 0x94A3B8, spot: 0x9FB3C8, spots: 16,
      horn: 0x1F2937, hornTip: 0x7DD3FC, hornLen: 1.0, brow: 0x64748B, eye: 0x38BDF8, hair: 0xDDE6F0, chain: true });
    return { aura: 'snow', auraColor: 0xBAE6FD, eye: 0x38BDF8, height: 4.5, idle: 'sway', scale: 1.22 };
  };

  R3.bosses = {
    KEYS: ['lion', 'desert', 'dragon', 'witch', 'olad', 'arzhang', 'white'],
    EMOJI: { lion: '🦁', desert: '🏜️', dragon: '🐉', witch: '🧙', olad: '🛡️', arzhang: '👺', white: '👹' },
    build: function (key) {
      if (!BUILD[key]) key = 'lion';
      var root = new T.Group(), mat = M.toon();
      mat.emissive = new T.Color(0x000000);
      var r = { key: key, root: root, mat: mat, glowParts: [], glowSprites: [], wings: null, jaw: null };
      r.body = pivot(root, 0, 0, 0);
      r.head = pivot(r.body, 0, 3, 0);
      r.armL = pivot(r.body, -1, 2.5, 0);
      r.armR = pivot(r.body, 1, 2.5, 0);
      var cfg = BUILD[key](r, mat);
      r.cfg = cfg;
      r.scale = cfg.scale || 1;
      root.scale.setScalar(r.scale);
      r.height = cfg.height * r.scale;
      r.rest = {
        head: r.head.position.clone(), armL: r.armL.rotation.clone(), armR: r.armR.rotation.clone(),
        wings: r.wings ? r.wings.map(function (w) { return w.rotation.clone(); }) : null
      };
      root.traverse(function (o) { if (o.isMesh && !o.userData.outline) o.userData.pick = { type: 'boss' }; });
      return r;
    },
    dispose: function (r) {
      if (!r) return;
      r.root.traverse(function (o) {
        if (o.isMesh && o.geometry && !o.userData.outline) o.geometry.dispose();
        if (o.isSprite && o.material) o.material.dispose();
      });
      if (r.mat) r.mat.dispose();
      if (r.eyes && r.eyes.mat) r.eyes.mat.dispose();
      if (r.root.parent) r.root.parent.remove(r.root);
    }
  };
})();
