/* هفت‌خانِ تمرکز — سرور خیالی برای پیش‌نمایش در مرورگر.
   داخل اپ اندروید شیء AndroidR3 وجود دارد و این فایل هیچ کاری نمی‌کند.
   پارامترهای آدرس برای آزمایش: speed, scene, theme, night, n, boss, help=0, open, coins */
(function () {
  'use strict';
  var R3 = window.R3, B = R3.bridge;
  if (B.native || window.AndroidR3) return;

  var Q = {};
  String(location.search || '').replace(/^\?/, '').split('&').forEach(function (kv) {
    if (!kv) return;
    var i = kv.indexOf('=');
    Q[decodeURIComponent(i < 0 ? kv : kv.slice(0, i))] = i < 0 ? '1' : decodeURIComponent(kv.slice(i + 1));
  });
  var SPEED = Math.max(1, Math.min(300, +Q.speed || 1));
  var SCENE = Q.scene || 'default';
  if (Q.help === '0') R3.store.set('onboarded', 1);

  var BOSSES = [
    { stage: 1, key: 'lion', title: 'شیرِ بیشه', khan: 'خان یکم', emoji: '🦁' },
    { stage: 2, key: 'desert', title: 'غولِ تشنگی', khan: 'خان دوم', emoji: '🏜️' },
    { stage: 3, key: 'dragon', title: 'اژدهای کوهستان', khan: 'خان سوم', emoji: '🐉' },
    { stage: 4, key: 'witch', title: 'زنِ جادو', khan: 'خان چهارم', emoji: '🧙' },
    { stage: 5, key: 'olad', title: 'اولادِ مرزبان', khan: 'خان پنجم', emoji: '🛡️' },
    { stage: 6, key: 'arzhang', title: 'ارژنگ دیو', khan: 'خان ششم', emoji: '👺' },
    { stage: 7, key: 'white', title: 'دیو سپید', khan: 'خان هفتم', emoji: '👹' }
  ];
  var HATS = [
    { key: 'hat_cap', title: 'کلاه فارغ‌التحصیلی', emoji: '🎓', cost: 300, chest: true, boss: 0 },
    { key: 'hat_headphones', title: 'هدفون تمرکز', emoji: '🎧', cost: 500, chest: true, boss: 0 },
    { key: 'hat_wizard', title: 'کلاه جادوگر', emoji: '🧙', cost: 900, chest: true, boss: 0 },
    { key: 'hat_halo', title: 'هالهٔ نور', emoji: '😇', cost: 1500, chest: true, boss: 0 },
    { key: 'hat_helmet', title: 'کلاه‌خود پهلوانی', emoji: '⛑️', cost: 1800, chest: true, boss: 0 },
    { key: 'hat_crown', title: 'تاج کیانی', emoji: '👑', cost: 2500, chest: true, boss: 0 },
    { key: 'hat_simorgh', title: 'پرِ سیمرغ', emoji: '🪶', cost: 0, chest: true, boss: 0 },
    { key: 'hat_div', title: 'کلاه‌خود دیو سپید', emoji: '👹', cost: 0, chest: false, boss: 7 }
  ];
  var HAT_BY = {}; HATS.forEach(function (h) { HAT_BY[h.key] = h; });
  var TIER_AT = [0, 600, 1500, 3000, 5400], MULT = [1, 1.5, 2, 3, 4];
  function tier(run) { var t = 0; for (var i = 1; i < 5; i++) if (run >= TIER_AT[i]) t = i; return t; }
  function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function nowS() { return Math.floor(Date.now() / 1000); }

  /* ------------------------------------------------------------ وضعیت */
  var NAMES = ['مریم', 'علی', 'نگار', 'امیرحسین', 'زهرا', 'پویا', 'فاطمه', 'کیان', 'ستاره', 'محمدرضا', 'هستی'];
  var KINDS = ['owl', 'dog', 'rabbit', 'fox', 'panda', 'bear', 'cat'];
  var HAT_POOL = ['', 'hat_cap', '', 'hat_headphones', 'hat_wizard', '', 'hat_crown', 'hat_halo', '', 'hat_simorgh', 'hat_helmet'];
  var N = Q.n !== undefined ? Math.max(0, Math.min(11, +Q.n || 0)) : 8;
  var others = [];
  for (var i = 0; i < N; i++) {
    others.push({
      user_id: 2000 + i, username: NAMES[i], character: KINDS[i % KINDS.length], hat: HAT_POOL[i],
      state: i === 6 ? 'sleeping' : (i % 4 === 3 ? 'idle' : 'studying'), min: 15 + (i * 37) % 160,
      run: (i * 977) % 4200, gap: 0, left: 40 + (i * 53) % 400
    });
  }
  var me = {
    username: Q.name || 'سارا', character: Q.me || 'cat', level: 7, level_title: 'کوشا', level_emoji: '📘',
    xp: 1830, level_start_xp: 1500, next_level_xp: 2200, coins: Q.coins !== undefined ? +Q.coins : 1240,
    streak: 5, today_minutes: 47, desk: {}
  };
  var room = { online: 0, theme: Q.theme || 'library', night: Q.night === '1', error: '' };
  var P = {
    run: 0, gap: 9999, rest: false, focus: 47 * 60, damage: 1430, best: 1260, cheers: 1, opened: 0, bits: 0,
    earned: 1, chests: { common: 1, rare: 0, epic: 0 }, hat: '', hats: []
  };
  var tm = {
    phase: 'idle', running: false, remaining: 1500, total: 1500, completed: 0, work_min: 25, break_min: 5, long_min: 15,
    pending_min: 0, chrono_running: false, chrono_sec: 0
  };
  var raid = null, lastDefeat = null, rewards = [], events = [], evId = 900, snap = 0, inbox = [], lastCheers = [], nextRaid = 300;
  var QUESTS = [
    { key: 'focus', bit: 1, emoji: '📚', metric: 'focus', goal: 2700, title: '45 دقیقه در اتاق تمرکز کن', reward: 28, unit: 'sec' },
    { key: 'combo', bit: 2, emoji: '🔥', metric: 'best', goal: 1500, title: 'به آتش ×۲ برس (۲۵ دقیقهٔ پیوسته)', reward: 20, unit: 'sec' },
    { key: 'cheer', bit: 4, emoji: '👏', metric: 'cheers', goal: 3, title: '۳ هم‌اتاقی را تشویق کن', reward: 15, unit: 'count' }
  ];

  function spawn(stage, cycle) {
    var b = BOSSES[stage - 1], mul = [1, 1.1, 1.2, 1.3, 1.45, 1.6, 1.9][stage - 1] * (1 + 0.1 * Math.min(10, cycle - 1));
    raid = { id: ++nextRaid, stage: stage, cycle: cycle, key: b.key, title: b.title, khan: b.khan, emoji: b.emoji,
      hp_max: Math.round(5400 * mul), damage: 0, started_at: nowS(), hits: {} };
  }
  function hit(who, d) { raid.damage += d; raid.hits[who] = (raid.hits[who] || 0) + d; }
  function byId(id) { for (var i = 0; i < others.length; i++) if (String(others[i].user_id) === String(id)) return others[i]; return null; }
  function studyingNow() { return (tm.phase === 'work' && tm.running) || tm.chrono_running; }
  function event(kind, who, value) {
    var o = who === 'me' ? null : byId(who);
    events.push({ id: ++evId, kind: kind, value: value, user: o ? o.username : me.username, character: o ? o.character : me.character, is_me: who === 'me' ? 1 : 0, at: Date.now() });
    if (events.length > 30) events.shift();
  }
  function rollRarity(t) {
    var x = Math.random() * 100, epic = [2, 4, 7, 11, 16][t], rare = [18, 24, 30, 36, 42][t];
    return x < epic ? 'epic' : (x < epic + rare ? 'rare' : 'common');
  }

  /* ------------------------------------------------------------ صحنه‌های آزمایشی */
  var stageOf = { lion: 1, desert: 2, dragon: 3, witch: 4, olad: 5, arzhang: 6, white: 7 };
  spawn(stageOf[Q.boss] || (SCENE === 'white' ? 7 : 3), 1);
  raid.damage = Math.round(raid.hp_max * 0.38);
  raid.hits = { me: 1430, 2000: 1650, 2001: 980, 2002: 760, 2004: 420 };
  function work(rem) { tm.phase = 'work'; tm.running = true; tm.total = 1500; tm.remaining = rem; }
  if (SCENE === 'fight' || SCENE === 'rage' || SCENE === 'kill' || SCENE === 'white') {
    work(754); P.run = SCENE === 'rage' ? 5640 : (SCENE === 'kill' ? 1620 : 3120); P.gap = 0; P.best = P.run;
    P.chests = { common: 2, rare: 1, epic: 0 };
  }
  if (SCENE === 'rest') { tm.phase = 'break'; tm.running = true; tm.total = 300; tm.remaining = 212; tm.completed = 1; P.run = 1640; P.best = 1640; P.gap = 88; }
  if (SCENE === 'loot') {
    P.chests = { common: 2, rare: 1, epic: 1 }; P.focus = 2900; P.best = 1700;
    rewards.push({ raid_id: 299, stage: 2, cycle: 1, title: 'غولِ تشنگی', khan: 'خان دوم', damage: 2140, mvp: true, reward: 20 + 10 + 14 + 40, unlock: '' });
    lastDefeat = { id: 299, stage: 2, cycle: 1, title: 'غولِ تشنگی', defeated_at: nowS() - 1500, ago: 1500, mvp: me.username };
  }
  if (SCENE === 'kill') { raid.damage = raid.hp_max - 45; others.forEach(function (o, i) { if (i < 6) o.state = 'studying'; }); }
  if (Q.hat) { P.hats.push(Q.hat); P.hat = Q.hat; }

  /* ------------------------------------------------------------ نمای سرور */
  function questView() {
    var m = { focus: P.focus, best: P.best, cheers: P.cheers }, all = true;
    var list = QUESTS.map(function (q) {
      var pr = Math.floor(m[q.metric]), done = pr >= q.goal;
      if (!done) all = false;
      return { key: q.key, emoji: q.emoji, title: q.title, goal: q.goal, progress: Math.min(pr, q.goal), unit: q.unit, reward: q.reward, done: done, claimed: (P.bits & q.bit) !== 0 };
    });
    return { list: list, bonus: { reward: 25, chest: 'rare', ready: all, claimed: (P.bits & 8) !== 0 } };
  }
  function payload(withCat) {
    var t = tier(P.run);
    var top = Object.keys(raid.hits).map(function (k) {
      var o = k === 'me' ? null : byId(k);
      return { username: o ? o.username : me.username, character: o ? o.character : me.character, hat: o ? o.hat : P.hat, damage: Math.round(raid.hits[k]), is_me: k === 'me' ? 1 : 0 };
    }).sort(function (a, b) { return b.damage - a.damage; }).slice(0, 5);
    var fighters = (studyingNow() ? 1 : 0) + others.filter(function (o) { return o.state === 'studying'; }).length;
    var cut = Date.now() - 600000;
    var out = {
      v: 1, now: nowS(),
      raid: { id: raid.id, stage: raid.stage, cycle: raid.cycle, key: raid.key, title: raid.title, khan: raid.khan, emoji: raid.emoji,
        hp_max: raid.hp_max, damage: Math.min(raid.hp_max, Math.round(raid.damage)), started_at: raid.started_at,
        fighters: fighters, my_damage: Math.round(raid.hits.me || 0), top: top },
      last_defeat: lastDefeat ? Object.assign({}, lastDefeat, { ago: Math.max(0, nowS() - lastDefeat.defeated_at) }) : null,
      rewards: rewards.slice(),
      me: {
        run_sec: Math.floor(P.run), tier: t, mult: MULT[t], focus_today: Math.floor(P.focus), damage_today: Math.round(P.damage),
        best_run_today: Math.floor(P.best), chest_sec: 1500, next_chest_sec: P.earned >= 16 ? 0 : 1500 - Math.floor(P.focus) % 1500,
        chests: { common: P.chests.common, rare: P.chests.rare, epic: P.chests.epic },
        chest_total: P.chests.common + P.chests.rare + P.chests.epic, hat: P.hat, hats: P.hats.slice()
      },
      quests: questView(),
      events: events.filter(function (e) { return e.at >= cut; }).slice(-12).map(function (e) {
        return { id: e.id, kind: e.kind, value: e.value, user: e.user, character: e.character, is_me: e.is_me };
      }),
      ev_last: evId
    };
    if (withCat) { out.hats_catalog = HATS; out.bosses = BOSSES.map(function (b) { return { stage: b.stage, key: b.key, title: b.title, khan: b.khan }; }); }
    return out;
  }
  var sentCat = false;
  function pushState(newSnap) {
    if (newSnap) { snap++; lastCheers = inbox.splice(0, inbox.length); }
    room.online = others.filter(function (o) { return o.state !== 'sleeping' || true; }).length + 1;
    var st = {
      t: 'state', snap_seq: snap, cheers: lastCheers, server_r3: true, r3: payload(!sentCat),
      me: Object.assign({}, me, { today_minutes: Math.floor(me.today_minutes) }),
      room: Object.assign({}, room),
      others: others.map(function (o) {
        return { user_id: o.user_id, username: o.username, character: o.character, state: o.state, minutes_today: Math.floor(o.min), hat: o.hat, combo: o.state === 'studying' ? tier(o.run) : 0, ago: 4 };
      })
    };
    sentCat = true;
    R3.push(st);
  }
  function pushTimer() {
    R3.push({ t: 'timer', phase: tm.phase, running: tm.running, remaining: Math.max(0, Math.ceil(tm.remaining)), total: tm.total, completed: tm.completed,
      work_min: tm.work_min, break_min: tm.break_min, long_min: tm.long_min, pending_min: tm.pending_min,
      chrono_running: tm.chrono_running, chrono_sec: Math.floor(tm.chrono_sec) });
  }
  function reply(rid, ok, dataOrErr) {
    var m = { t: 'result', rid: rid, ok: !!ok };
    if (ok) m.data = dataOrErr || {}; else m.error = dataOrErr;
    setTimeout(function () { R3.push(m); setTimeout(function () { pushState(false); }, 30); }, 260 + Math.random() * 300);
  }
  function toast(text, kind) { R3.push({ t: 'toast', text: text, kind: kind || '' }); }

  /* ------------------------------------------------------------ تایمر */
  function toBreak(done) {
    if (done) { tm.completed++; tm.pending_min += tm.work_min; me.today_minutes += tm.work_min; me.xp += tm.work_min * 2; }
    var long = done && tm.completed % 4 === 0;
    tm.phase = long ? 'long_break' : 'break'; tm.total = tm.remaining = (long ? tm.long_min : tm.break_min) * 60; tm.running = true;
  }
  function toIdle() { tm.phase = 'idle'; tm.running = false; tm.total = tm.remaining = tm.work_min * 60; }

  /* ------------------------------------------------------------ شبیه‌سازی */
  var acc = 0, beatAcc = 0, last = performance.now();
  function step(dt) {
    if (tm.running) {
      tm.remaining -= dt;
      if (tm.remaining <= 0) { if (tm.phase === 'work') toBreak(true); else toIdle(); }
    }
    if (tm.chrono_running) tm.chrono_sec += dt;
    P.rest = tm.phase === 'break' || tm.phase === 'long_break';
    if (studyingNow()) {
      var before = tier(P.run);
      P.run += dt; P.gap = 0; P.focus += dt; P.best = Math.max(P.best, P.run);
      var d = dt * MULT[tier(P.run)];
      hit('me', d); P.damage += d;
      if (tier(P.run) > before && tier(P.run) >= 2) event('combo', 'me', tier(P.run));
      var earned = Math.floor(P.focus / 1500);
      if (earned > P.earned && P.earned < 16) { P.earned = earned; P.chests[rollRarity(tier(P.run))]++; }
      if (!tm.chrono_running) { /* دقیقه‌ها با پایان پومودورو ثبت می‌شوند */ } else me.today_minutes += dt / 60;
    } else if (P.run > 0) {
      P.gap += dt;
      if (P.gap > (P.rest ? 1800 : 180)) P.run = 0;
    }
    others.forEach(function (o) {
      o.left -= dt;
      if (o.left <= 0) {
        var r = Math.random();
        if (o.state === 'studying') { o.state = r < 0.15 ? 'sleeping' : 'idle'; o.left = rnd(40, 240); if (r > 0.9) event('epic', o.user_id, rnd(60, 120)); }
        else { o.state = 'studying'; o.left = rnd(300, 1800); if (o.gap > 180) o.run = 0; o.gap = 0; }
      }
      if (o.state === 'studying') {
        var b = tier(o.run);
        o.run += dt; o.min += dt / 60;
        hit(o.user_id, dt * MULT[tier(o.run)]);
        if (tier(o.run) > b && tier(o.run) >= 2) event('combo', o.user_id, tier(o.run));
      } else o.gap += dt;
    });
    if (raid.damage >= raid.hp_max) defeat();
  }
  function defeat() {
    var mvp = null, best = -1;
    Object.keys(raid.hits).forEach(function (k) { if (raid.hits[k] > best) { best = raid.hits[k]; mvp = k; } });
    var o = mvp === 'me' ? null : byId(mvp), mine = Math.round(raid.hits.me || 0);
    lastDefeat = { id: raid.id, stage: raid.stage, cycle: raid.cycle, title: raid.title, defeated_at: nowS(), ago: 0, mvp: o ? o.username : me.username };
    if (mine >= 300) {
      rewards.push({ raid_id: raid.id, stage: raid.stage, cycle: raid.cycle, title: raid.title, khan: raid.khan, damage: mine, mvp: mvp === 'me',
        reward: 20 + 5 * raid.stage + Math.min(80, Math.floor(mine / 300) * 2) + (mvp === 'me' ? 40 : 0), unlock: raid.stage === 7 ? 'hat_div' : '' });
    }
    var ns = raid.stage % 7 + 1, nc = raid.cycle + (raid.stage === 7 ? 1 : 0);
    spawn(ns, nc);
    pushState(true);
  }
  function loop() {
    var t = performance.now(), dt = Math.min(1, (t - last) / 1000); last = t;
    step(dt * SPEED);
    acc += dt; beatAcc += dt;
    if (acc >= 1) { acc = 0; pushTimer(); }
    if (beatAcc >= 4) {
      beatAcc = 0;
      if (studyingNow() && Math.random() < 0.12 && others.length) {
        var o = others[rnd(0, others.length - 1)];
        inbox.push({ emoji: ['👏', '🔥', '💪', '⭐'][rnd(0, 3)], from: o.username });
      }
      pushState(true);
    }
  }

  /* ------------------------------------------------------------ فرمان‌ها */
  var ok = function (rid, data) { reply(rid, true, data); };
  var no = function (rid, err) { reply(rid, false, err); };
  var cmd = {
    ready: function () {
      pushState(true); pushTimer();
      setInterval(loop, 250);
      if (Q.open) setTimeout(autoOpen, 1600);
    },
    focus_toggle: function (d) {
      if (d.mode === 'chrono') { tm.chrono_running = !tm.chrono_running; if (tm.running && tm.phase === 'work') tm.running = false; }
      else if (tm.phase === 'idle') { tm.phase = 'work'; tm.total = tm.remaining = tm.work_min * 60; tm.running = true; }
      else tm.running = !tm.running;
      pushTimer();
    },
    timer_reset: function (d) {
      if (d.mode === 'chrono') {
        var m = Math.floor(tm.chrono_sec / 60); tm.chrono_running = false; tm.chrono_sec = 0;
        if (m > 0) toast('⏲️ ' + R3.fa(m) + ' دقیقه ثبت شد', 'gold');
      } else toIdle();
      pushTimer();
    },
    timer_skip: function () { if (tm.phase === 'work') toBreak(false); else if (tm.phase !== 'idle') toIdle(); pushTimer(); },
    log: function () {
      if (tm.pending_min > 0) { toast('✅ ' + R3.fa(tm.pending_min) + ' دقیقه در کارنامه ثبت شد', 'gold'); tm.pending_min = 0; me.xp += 20; pushTimer(); pushState(false); }
      else toast('هنوز دقیقهٔ تازه‌ای برای ثبت نداری؛ یک پومودورو تمام کن', 'err');
    },
    claim: function (d) {
      if (d.kind === 'raid') {
        var idx = -1; rewards.forEach(function (x, i) { if (x.raid_id === d.raid_id) idx = i; });
        if (idx < 0) return no(d.rid, 'این غنیمت قبلاً دریافت شده');
        var rw = rewards.splice(idx, 1)[0];
        me.coins += rw.reward;
        if (rw.unlock && P.hats.indexOf(rw.unlock) < 0) P.hats.push(rw.unlock);
        return ok(d.rid, { claim: { kind: 'raid', coins: rw.reward, unlock: rw.unlock, mvp: rw.mvp }, r3: payload(false) });
      }
      var v = questView();
      if (d.key === 'bonus') {
        if (!v.bonus.ready) return no(d.rid, 'اول هر سه مأموریت را کامل کن');
        if (v.bonus.claimed) return no(d.rid, 'این جایزه قبلاً دریافت شده');
        P.bits |= 8; me.coins += 25; P.chests.rare++; event('quests', 'me', 3);
        return ok(d.rid, { claim: { kind: 'quest', key: 'bonus', coins: 25, chest: 'rare' }, r3: payload(false) });
      }
      var q = null; v.list.forEach(function (x) { if (x.key === d.key) q = x; });
      if (!q) return no(d.rid, 'مأموریت نامعتبر');
      if (!q.done) return no(d.rid, 'این مأموریت هنوز کامل نشده');
      if (q.claimed) return no(d.rid, 'این جایزه قبلاً دریافت شده');
      QUESTS.forEach(function (x) { if (x.key === q.key) P.bits |= x.bit; });
      me.coins += q.reward;
      ok(d.rid, { claim: { kind: 'quest', key: q.key, coins: q.reward, chest: '' }, r3: payload(false) });
    },
    chest_open: function (d) {
      var r = d.rarity;
      if (!(P.chests[r] > 0)) return no(d.rid, 'صندوقی برای باز کردن نداری');
      P.chests[r]--; P.opened++;
      var kind = 'coins', value = 0, item = '';
      if (r === 'epic' && Math.random() < (Q.hatdrop === '1' ? 1 : 0.35)) {
        var pool = HATS.filter(function (h) { return h.chest && P.hats.indexOf(h.key) < 0; });
        if (pool.length) { kind = 'hat'; item = pool[rnd(0, pool.length - 1)].key; P.hats.push(item); }
      }
      if (kind === 'coins') { value = r === 'epic' ? rnd(60, 120) : (r === 'rare' ? rnd(18, 35) : rnd(5, 12)); me.coins += value; }
      if (r === 'epic') event(kind === 'hat' ? 'hat' : 'epic', 'me', value);
      ok(d.rid, { chest: { rarity: r, kind: kind, value: value, item: item, title: item ? HAT_BY[item].title : '', emoji: item ? HAT_BY[item].emoji : '🪙' }, r3: payload(false) });
    },
    hat: function (d) {
      var h = d.hat || '';
      if (h && !HAT_BY[h]) return no(d.rid, 'کلاه نامعتبر');
      if (h && P.hats.indexOf(h) < 0) return no(d.rid, 'این کلاه را هنوز نداری');
      P.hat = h;
      ok(d.rid, { hat: h, r3: payload(false) });
    },
    buy: function (d) {
      var h = HAT_BY[d.item];
      if (!h || !(h.cost > 0)) return no(d.rid, 'این کالا فروشی نیست');
      if (P.hats.indexOf(h.key) >= 0) return no(d.rid, 'این را قبلاً خریده‌ای');
      if (me.coins < h.cost) return no(d.rid, 'سکه کافی نداری؛ با تمرکز سکه جمع کن 🙂');
      me.coins -= h.cost; P.hats.push(h.key); if (d.equip) P.hat = h.key;
      ok(d.rid, { coins: me.coins, r3: payload(false) });
    },
    cheer: function (d) {
      P.cheers++;
      var o = byId(d.user_id);
      if (o && Math.random() < 0.5) setTimeout(function () { inbox.push({ emoji: '🙏', from: o.username }); }, 5000);
    },
    night: function (d) { room.night = !!d.on; pushState(false); },
    open: function (d) {
      if (d.sheet === 'theme') {
        var list = ['library', 'ancient_iran', 'rasht', 'white_nights', 'japanese'];
        room.theme = list[(list.indexOf(room.theme) + 1) % list.length];
        pushState(false);
        toast('🎨 تم: ' + room.theme + ' (پیش‌نمایش)', '');
        return;
      }
      toast('در اپ اصلی بخش «' + d.sheet + '» باز می‌شود (پیش‌نمایش)', '');
    },
    haptic: function (d) { try { if (navigator.vibrate && navigator.userActivation && navigator.userActivation.hasBeenActive) navigator.vibrate(d.kind === 'heavy' ? 40 : (d.kind === 'medium' ? 20 : 8)); } catch (e) { } },
    back_unhandled: function () { toast('(پیش‌نمایش) اپ به صفحهٔ قبل برمی‌گشت', ''); }
  };
  B.mock = function (type, data) {
    var f = cmd[type];
    if (f) f(data || {});
    else if (window.console) console.log('[r3-demo]', type, JSON.stringify(data || {}));
  };

  /* ------------------------------------------------------------ باز کردن خودکار برای عکس‌برداری */
  function autoOpen() {
    var H = R3.hud, G = R3.game, what = Q.open;
    if (what === 'quests') H.openQuests();
    else if (what === 'chests') H.openChests();
    else if (what === 'wardrobe') H.openWardrobe();
    else if (what === 'battle') H.openBattle();
    else if (what === 'menu') H.openMenu();
    else if (what === 'help') H.openHelp(false);
    else if (what === 'person') { var p = R3.world.person(String(2000)); if (p) H.openPerson(p); }
    else if (what.indexOf('chest:') === 0) {
      var rar = what.slice(6);
      G.openChest(rar);
      var n = 0, iv = setInterval(function () {
        var st = document.getElementById('chest-stage');
        if (!st || ++n > 3) { clearInterval(iv); return; }
        st.click();
      }, 450);
    }
  }
})();
