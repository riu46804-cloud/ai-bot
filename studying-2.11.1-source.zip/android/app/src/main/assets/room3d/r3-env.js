/* هفت‌خانِ تمرکز — محیط هر تم: جزیرهٔ معلق، کف، فرش، سکوی خان، دکور پس‌زمینه،
   آسمان و آب‌وهوا. هر تم یک بار ساخته و همه‌چیزِ ثابتش در یک هندسه ادغام می‌شود. */
(function () {
  'use strict';
  var R3 = window.R3, T = THREE, M = R3.models, tr = M.tr, B = M.Builder, PI = Math.PI;
  var E = R3.env = {};
  E.CENTER_Z = -2; E.RADIUS = 9.6; E.BOSS_Z = -7.7; E.PLAT_R = 2.3; E.PLAT_H = 0.5;

  /* ---------------------------------------------------------- بافت‌های بوم */
  function canvasTex(w, h, draw, rep) {
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    var t = new T.CanvasTexture(c);
    t.colorSpace = T.SRGBColorSpace; t.anisotropy = 4;
    if (rep) { t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(rep, rep); }
    return t;
  }
  function hex(c) { return '#' + ('000000' + c.toString(16)).slice(-6); }
  function shade(c, k) {
    var r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
    r = R3.clamp(Math.round(r * k), 0, 255); g = R3.clamp(Math.round(g * k), 0, 255); b = R3.clamp(Math.round(b * k), 0, 255);
    return (r << 16) | (g << 8) | b;
  }
  function planks(g, w, h, rnd, base, opts) {
    opts = opts || {};
    var rows = 8, ph = h / rows;
    for (var r = 0; r < rows; r++) {
      var x = -rnd() * w * 0.5;
      while (x < w) {
        var len = w * (0.35 + rnd() * 0.45), k = 0.86 + rnd() * 0.24;
        g.fillStyle = hex(shade(base, k)); g.fillRect(x, r * ph, len, ph);
        g.globalAlpha = 0.16; g.strokeStyle = hex(shade(base, 0.6));
        for (var l = 0; l < 4; l++) {
          g.beginPath(); var yy = r * ph + 6 + rnd() * (ph - 12);
          g.moveTo(x, yy); g.bezierCurveTo(x + len * 0.3, yy + (rnd() - 0.5) * 8, x + len * 0.6, yy + (rnd() - 0.5) * 8, x + len, yy); g.stroke();
        }
        g.globalAlpha = 1; g.fillStyle = hex(shade(base, 0.45)); g.fillRect(x, r * ph, 3, ph);
        x += len;
      }
      g.fillStyle = hex(shade(base, 0.42)); g.fillRect(0, r * ph, w, 3);
    }
    if (opts.moss) {
      for (var m = 0; m < 14; m++) {
        var mx = rnd() * w, my = rnd() * h, mr = 20 + rnd() * 40, gr = g.createRadialGradient(mx, my, 0, mx, my, mr);
        gr.addColorStop(0, 'rgba(92,140,70,.55)'); gr.addColorStop(1, 'rgba(92,140,70,0)'); g.fillStyle = gr; g.fillRect(mx - mr, my - mr, mr * 2, mr * 2);
      }
      g.globalAlpha = 0.18; g.fillStyle = '#dff4ff';
      for (var s = 0; s < 18; s++) g.fillRect(rnd() * w, rnd() * h, 30 + rnd() * 60, 2);
      g.globalAlpha = 1;
    }
  }
  var FLOOR = {
    library: function (g, w, h, rnd) { planks(g, w, h, rnd, 0xB07A48); },
    rasht: function (g, w, h, rnd) { planks(g, w, h, rnd, 0x7A5B3E, { moss: true }); },
    ancient_iran: function (g, w, h, rnd) {
      var n = 4, s = w / n;
      for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) {
        g.fillStyle = hex(shade(0xD8C39A, 0.9 + rnd() * 0.16)); g.fillRect(i * s, j * s, s, s);
        g.globalAlpha = 0.12; g.fillStyle = '#8a6d45';
        for (var d = 0; d < 20; d++) g.fillRect(i * s + rnd() * s, j * s + rnd() * s, 2 + rnd() * 3, 2 + rnd() * 3);
        g.globalAlpha = 1;
        if ((i + j) % 2 === 0) {
          var cx = i * s + s / 2, cy = j * s + s / 2;
          g.fillStyle = '#2F8F9D'; star8(g, cx, cy, s * 0.26, s * 0.13);
          g.fillStyle = '#F2E3BF'; star8(g, cx, cy, s * 0.12, s * 0.06);
        } else {
          g.strokeStyle = '#B89A68'; g.lineWidth = 3; g.strokeRect(i * s + 14, j * s + 14, s - 28, s - 28);
        }
        g.fillStyle = '#9C7F55'; g.fillRect(i * s, j * s, s, 3); g.fillRect(i * s, j * s, 3, s);
      }
    },
    white_nights: function (g, w, h, rnd) {
      g.fillStyle = '#DCE6F0'; g.fillRect(0, 0, w, h);
      for (var i = 0; i < 40; i++) {
        var x = rnd() * w, y = rnd() * h, r = 20 + rnd() * 60, gr = g.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, 'rgba(176,198,224,.35)'); gr.addColorStop(1, 'rgba(176,198,224,0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
      }
      g.fillStyle = '#ffffff';
      for (var k = 0; k < 220; k++) g.fillRect(rnd() * w, rnd() * h, 2, 2);
    },
    japanese: function (g, w, h, rnd) {
      // تاتامی: هر حصیر ۲×۱، چیدمان چرخشی
      var u = w / 4;
      var mats = [[0, 0, 2, 1], [2, 0, 1, 2], [3, 0, 1, 2], [0, 1, 1, 2], [1, 1, 1, 2], [2, 2, 2, 1], [0, 3, 2, 1], [2, 3, 2, 1]];
      mats.forEach(function (m) {
        var x = m[0] * u, y = m[1] * u, mw = m[2] * u, mh = m[3] * u;
        g.fillStyle = hex(shade(0xCFC58E, 0.94 + rnd() * 0.1)); g.fillRect(x, y, mw, mh);
        g.globalAlpha = 0.13; g.fillStyle = '#7d7444';
        var vert = mh > mw;
        for (var l = 0; l < (vert ? mw : mh); l += 5) { if (vert) g.fillRect(x + l, y, 1.4, mh); else g.fillRect(x, y + l, mw, 1.4); }
        g.globalAlpha = 1; g.fillStyle = '#26332A';
        if (vert) { g.fillRect(x, y, 7, mh); g.fillRect(x + mw - 7, y, 7, mh); } else { g.fillRect(x, y, mw, 7); g.fillRect(x, y + mh - 7, mw, 7); }
      });
    }
  };
  function star8(g, cx, cy, R, r) {
    g.beginPath();
    for (var i = 0; i < 16; i++) { var a = i * PI / 8 - PI / 2, rr = i % 2 ? r : R; g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); }
    g.closePath(); g.fill();
  }
  function rugTex(field, border) {
    return canvasTex(256, 384, function (g, w, h) {
      g.fillStyle = hex(border); g.fillRect(0, 0, w, h);
      g.fillStyle = '#E9D8A6'; g.fillRect(10, 10, w - 20, h - 20);
      g.fillStyle = hex(border); g.fillRect(16, 16, w - 32, h - 32);
      g.fillStyle = '#E9D8A6';
      for (var i = 0; i < 14; i++) { star8(g, 30 + i * 15.2, 26, 5, 2.5); star8(g, 30 + i * 15.2, h - 26, 5, 2.5); }
      for (var j = 0; j < 22; j++) { star8(g, 26, 40 + j * 14.5, 5, 2.5); star8(g, w - 26, 40 + j * 14.5, 5, 2.5); }
      g.fillStyle = hex(field); g.fillRect(36, 36, w - 72, h - 72);
      g.save(); g.translate(w / 2, h / 2);
      g.fillStyle = hex(border); g.beginPath(); g.moveTo(0, -120); g.lineTo(70, 0); g.lineTo(0, 120); g.lineTo(-70, 0); g.closePath(); g.fill();
      g.fillStyle = '#E9D8A6'; g.beginPath(); g.moveTo(0, -96); g.lineTo(52, 0); g.lineTo(0, 96); g.lineTo(-52, 0); g.closePath(); g.fill();
      g.fillStyle = hex(field); star8(g, 0, 0, 42, 22);
      g.fillStyle = '#F5B800'; star8(g, 0, 0, 16, 8);
      g.restore();
      g.fillStyle = 'rgba(233,216,166,.85)';
      [[60, 60], [w - 60, 60], [60, h - 60], [w - 60, h - 60]].forEach(function (p) { g.beginPath(); g.arc(p[0], p[1], 14, 0, PI * 2); g.fill(); });
      g.fillStyle = 'rgba(255,255,255,.25)';
      for (var f = 0; f < w; f += 6) { g.fillRect(f, 0, 2, 6); g.fillRect(f, h - 6, 2, 6); }
    });
  }

  /* ---------------------------------------------------------- ذره‌های آب‌وهوا (روی GPU) */
  var CELL = { dot: [0, 0.5], star: [0.5, 0.5], petal: [0, 0], square: [0.5, 0] };
  E.weather = function (o) {
    var n = o.count, seeds = new Float32Array(n * 3), rnd = R3.rng(o.seed || 9), pos = new Float32Array(n * 3);
    for (var i = 0; i < n * 3; i++) seeds[i] = rnd();
    var g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(pos, 3));
    g.setAttribute('aSeed', new T.BufferAttribute(seeds, 3));
    var box = o.box, mat = new T.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 }, uMin: { value: new T.Vector3(box[0], box[2], box[4]) },
        uSize: { value: new T.Vector3(box[1] - box[0], box[3] - box[2], box[5] - box[4]) },
        uVel: { value: new T.Vector3(o.vel[0], o.vel[1], o.vel[2]) }, uSway: { value: o.sway || 0 },
        uPx: { value: 400 }, uScale: { value: o.size || 0.2 }, uTex: { value: M.atlas },
        uCell: { value: new T.Vector2(CELL[o.cell || 'dot'][0], CELL[o.cell || 'dot'][1]) },
        uColor: { value: new T.Color(o.color || 0xffffff) }, uOpacity: { value: o.opacity === undefined ? 0.9 : o.opacity },
        uTw: { value: o.twinkle ? 1 : 0 }
      },
      vertexShader: [
        'attribute vec3 aSeed; uniform float uTime, uSway, uPx, uScale, uTw; uniform vec3 uMin, uSize, uVel;',
        'varying float vA; varying float vRot;',
        'void main(){',
        '  vec3 p = uMin + aSeed * uSize + uVel * uTime * (0.7 + 0.6 * aSeed.y);',
        '  p = uMin + mod(p - uMin, uSize);',
        '  p.x += sin(uTime * 0.7 + aSeed.z * 20.0) * uSway;',
        '  p.z += cos(uTime * 0.6 + aSeed.x * 20.0) * uSway;',
        '  vec4 mv = modelViewMatrix * vec4(p, 1.0);',
        '  gl_Position = projectionMatrix * mv;',
        '  gl_PointSize = uScale * (0.6 + 0.8 * aSeed.x) * uPx / max(0.5, -mv.z);',
        '  float hy = (p.y - uMin.y) / uSize.y;',
        '  vA = smoothstep(0.0, 0.08, hy) * smoothstep(1.0, 0.85, hy);',
        '  vA *= mix(1.0, 0.45 + 0.55 * sin(uTime * (1.5 + aSeed.y * 3.0) + aSeed.z * 30.0), uTw);',
        '  vRot = uTime * (aSeed.y - 0.5) * 3.0 + aSeed.z * 6.28;',
        '}'].join('\n'),
      fragmentShader: [
        'uniform sampler2D uTex; uniform vec2 uCell; uniform vec3 uColor; uniform float uOpacity;',
        'varying float vA; varying float vRot;',
        'void main(){',
        '  vec2 c = gl_PointCoord - 0.5; float s = sin(vRot), co = cos(vRot);',
        '  c = mat2(co, -s, s, co) * c * 1.15 + 0.5;',
        '  if (c.x < 0.0 || c.y < 0.0 || c.x > 1.0 || c.y > 1.0) discard;',
        '  vec4 t = texture2D(uTex, uCell + vec2(c.x, 1.0 - c.y) * 0.5);',
        '  float a = t.a * uOpacity * vA; if (a < 0.01) discard;',
        '  gl_FragColor = vec4(uColor, a);',
        '}'].join('\n'),
      transparent: true, depthWrite: false, blending: o.additive ? T.AdditiveBlending : T.NormalBlending
    });
    var pts = new T.Points(g, mat);
    pts.frustumCulled = false;
    pts.userData.weather = true;
    return pts;
  };
  /** باران: پاره‌خط‌های کشیده با همان ترفند چرخشی. */
  E.rain = function (n, box) {
    var pos = new Float32Array(n * 6), seed = new Float32Array(n * 6), end = new Float32Array(n * 2), rnd = R3.rng(31);
    for (var i = 0; i < n; i++) {
      var a = rnd(), b = rnd(), c = rnd();
      for (var k = 0; k < 2; k++) { seed[i * 6 + k * 3] = a; seed[i * 6 + k * 3 + 1] = b; seed[i * 6 + k * 3 + 2] = c; end[i * 2 + k] = k; }
    }
    var g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(pos, 3));
    g.setAttribute('aSeed', new T.BufferAttribute(seed, 3));
    g.setAttribute('aEnd', new T.BufferAttribute(end, 1));
    var mat = new T.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uMin: { value: new T.Vector3(box[0], box[2], box[4]) }, uSize: { value: new T.Vector3(box[1] - box[0], box[3] - box[2], box[5] - box[4]) }, uColor: { value: new T.Color(0xCFE6F2) } },
      vertexShader: [
        'attribute vec3 aSeed; attribute float aEnd; uniform float uTime; uniform vec3 uMin, uSize; varying float vA;',
        'void main(){',
        '  vec3 v = vec3(-0.6, -14.0, 0.0) * (0.85 + 0.3 * aSeed.y);',
        '  vec3 p = uMin + aSeed * uSize + v * uTime;',
        '  p = uMin + mod(p - uMin, uSize);',
        '  p += normalize(v) * aEnd * 0.42;',
        '  vA = (0.25 + 0.35 * aEnd) * smoothstep(0.0, 0.1, (p.y - uMin.y) / uSize.y);',
        '  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);',
        '}'].join('\n'),
      fragmentShader: 'uniform vec3 uColor; varying float vA; void main(){ gl_FragColor = vec4(uColor, vA); }',
      transparent: true, depthWrite: false
    });
    var l = new T.LineSegments(g, mat);
    l.frustumCulled = false; l.userData.weather = true;
    return l;
  };

  /* ---------------------------------------------------------- آسمان */
  function skyDome(top, hor, bot) {
    var mat = new T.ShaderMaterial({
      uniforms: { uTop: { value: new T.Color(top) }, uHor: { value: new T.Color(hor) }, uBot: { value: new T.Color(bot) } },
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: [
        'uniform vec3 uTop, uHor, uBot; varying vec3 vD;',
        'void main(){ float y = vD.y; vec3 c = y > 0.0 ? mix(uHor, uTop, pow(smoothstep(0.0, 0.75, y), 0.8)) : mix(uHor, uBot, smoothstep(0.0, -0.45, y));',
        '  gl_FragColor = vec4(c, 1.0);',
        '#include <colorspace_fragment>',
        '}'].join('\n'),
      side: T.BackSide, depthWrite: false, fog: false
    });
    var m = new T.Mesh(new T.SphereGeometry(90, 24, 16), mat);
    m.renderOrder = -10; m.frustumCulled = false;
    return m;
  }
  function stars(n) {
    var pos = new Float32Array(n * 3), seeds = new Float32Array(n * 3), rnd = R3.rng(77);
    for (var i = 0; i < n; i++) {
      var th = rnd() * PI * 2, ph = Math.acos(0.15 + rnd() * 0.85), r = 80;
      pos[i * 3] = Math.sin(ph) * Math.cos(th) * r; pos[i * 3 + 1] = Math.cos(ph) * r; pos[i * 3 + 2] = Math.sin(ph) * Math.sin(th) * r;
      seeds[i * 3] = rnd(); seeds[i * 3 + 1] = rnd(); seeds[i * 3 + 2] = rnd();
    }
    var g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(pos, 3));
    g.setAttribute('aSeed', new T.BufferAttribute(seeds, 3));
    var mat = new T.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uPx: { value: 400 }, uTex: { value: M.atlas } },
      vertexShader: 'attribute vec3 aSeed; uniform float uTime, uPx; varying float vA; void main(){ vA = 0.35 + 0.65 * (0.5 + 0.5 * sin(uTime * (0.6 + aSeed.y * 2.0) + aSeed.z * 40.0)); vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv; gl_PointSize = (0.6 + aSeed.x * 1.6) * uPx * 0.0026; }',
      fragmentShader: 'uniform sampler2D uTex; varying float vA; void main(){ vec4 t = texture2D(uTex, vec2(0.5, 0.5) + vec2(gl_PointCoord.x, 1.0 - gl_PointCoord.y) * 0.5); gl_FragColor = vec4(1.0, 0.98, 0.9, t.a * vA); }',
      transparent: true, depthWrite: false, blending: T.AdditiveBlending, fog: false
    });
    var p = new T.Points(g, mat); p.frustumCulled = false; p.renderOrder = -9; p.userData.weather = true;
    return p;
  }
  function glowSprite(color, size, opacity) {
    var s = new T.Sprite(new T.SpriteMaterial({ map: M.glowTex, color: color, transparent: true, opacity: opacity === undefined ? 0.8 : opacity, blending: T.AdditiveBlending, depthWrite: false }));
    s.scale.setScalar(size);
    return s;
  }
  E.glowSprite = glowSprite;
  function cloudGeo(rnd, color) {
    var b = new B(), n = 4 + Math.floor(rnd() * 3);
    for (var i = 0; i < n; i++) b.add(M.sphere(10), color, tr([(i - n / 2) * 0.9 + rnd() * 0.4, rnd() * 0.5, rnd() * 0.6], null, [0.9 + rnd() * 0.6, 0.7 + rnd() * 0.4, 0.8]));
    return b.build();
  }

  /* ---------------------------------------------------------- جزیره و سکو */
  function island(b, theme, w, rnd) {
    var R = E.RADIUS, cz = E.CENTER_Z;
    var rim = { library: 0x7C4A2A, ancient_iran: 0xBFA172, rasht: 0x5A4330, white_nights: 0xD7E2EE, japanese: 0x5A3A2A }[theme];
    var dirt = { library: 0x8B6B4A, ancient_iran: 0xC9A677, rasht: 0x5E4A36, white_nights: 0xC9D6E6, japanese: 0x7A5A43 }[theme];
    var rock = { library: 0x6B5B53, ancient_iran: 0xA88462, rasht: 0x4E5A4E, white_nights: 0x8FA2B8, japanese: 0x6E625C }[theme];
    var top = { library: 0x5E9E4B, ancient_iran: 0xD9B98A, rasht: 0x3F8A4A, white_nights: 0xFFFFFF, japanese: 0x6FA35A }[theme];
    b.add(M.cyl(1, 1, 48, true), rim, tr([0, -0.18, cz], null, [R, 0.36, R]));
    b.add(M.torus(1, 0.035, 0, 6, 64), shade(rim, 0.7), tr([0, -0.02, cz], [PI / 2, 0, 0], [R, R, 1]));
    b.add(M.cyl(1, 1, 40, true), top, tr([0, -0.48, cz], null, [R * 1.01, 0.24, R * 1.01]));
    // زیر جزیره: مخروط صخره‌ای ناهموار
    var cone = new T.ConeGeometry(R, 7.5, 18, 4, true);
    var P = cone.attributes.position, v = new T.Vector3();
    for (var i = 0; i < P.count; i++) {
      v.fromBufferAttribute(P, i);
      var k = 1 + (Math.sin(v.x * 1.3 + v.z * 0.7) * 0.07 + Math.cos(v.z * 1.9 + v.y) * 0.06) * (v.y < 3.7 ? 1 : 0);
      P.setXYZ(i, v.x * k, v.y, v.z * k);
    }
    cone.computeVertexNormals();
    b.add(cone, function (lp) { return lp.y > 2.9 ? dirt : (lp.y > 0.5 ? rock : shade(rock, 0.8)); }, tr([0, -0.6 - 3.75, cz], [PI, 0, 0]));
  }
  function platform(b, theme, w) {
    var pz = E.BOSS_Z, R = E.PLAT_R, H = E.PLAT_H;
    var stone = { library: 0x6D4C3A, ancient_iran: 0xC8AE84, rasht: 0x5D6B60, white_nights: 0xAFC3D9, japanese: 0x7D7470 }[theme];
    var trim = { library: 0xC98E55, ancient_iran: 0x2F8F9D, rasht: 0x8D6E4E, white_nights: 0xEAF2FA, japanese: 0xB73A2E }[theme];
    b.add(M.cyl(1, 1.05, 32), stone, tr([0, H / 2, pz], null, [R, H, R]));
    b.add(M.cyl(1, 1, 32), trim, tr([0, H + 0.02, pz], null, [R * 0.97, 0.05, R * 0.97]));
    b.add(M.cyl(1, 1, 32), shade(stone, 1.12), tr([0, H + 0.05, pz], null, [R * 0.86, 0.04, R * 0.86]));
    b.add(M.rbox(1.6, 0.18, 0.6, 0.05), stone, tr([0, 0.09, pz + R + 0.1]));
    b.add(M.rbox(1.6, 0.18, 0.4, 0.05), trim, tr([0, 0.27, pz + R - 0.05]));
  }
  function runeRing() {
    var g = new T.Group();
    var ring = new T.Mesh(new T.RingGeometry(1.55, 1.85, 48), M.basic(0xFFFFFF, { transparent: true, opacity: 0.55, additive: true, depthWrite: false, side: T.DoubleSide }));
    ring.rotation.x = -PI / 2; g.add(ring);
    var ring2 = new T.Mesh(new T.RingGeometry(1.98, 2.04, 48), M.basic(0xFFFFFF, { transparent: true, opacity: 0.5, additive: true, depthWrite: false, side: T.DoubleSide }));
    ring2.rotation.x = -PI / 2; g.add(ring2);
    var tex = canvasTex(256, 32, function (c, w, h) {
      c.fillStyle = '#fff'; c.font = '900 22px Vaz, sans-serif'; c.textBaseline = 'middle';
      var s = '۷ ۶ ۵ ۴ ۳ ۲ ۱ ✦ ', x = 0; while (x < w) { c.fillText(s, x, h / 2); x += c.measureText(s).width; }
    });
    tex.wrapS = T.RepeatWrapping; tex.repeat.set(3, 1);
    var band = new T.Mesh(new T.CylinderGeometry(1.7, 1.7, 0.16, 48, 1, true), new T.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.75, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide }));
    band.position.y = 0.12; g.add(band);
    g.userData.ring = ring; g.userData.band = band; g.userData.ring2 = ring2;
    return g;
  }

  /* ---------------------------------------------------------- کمک‌های دکور */
  function arc(theta, r) { var t = theta * PI / 180; return { x: Math.sin(t) * r, z: E.CENTER_Z - Math.cos(t) * r, ry: -t }; }
  function place(m, x, y, z, ry, s) {
    var base = tr([x, y, z], [0, ry || 0, 0], s || 1);
    return base;
  }
  function addAt(b, geo, color, base, local) { var m = new T.Matrix4().multiplyMatrices(base, local || new T.Matrix4()); b.add(geo, color, m); }
  function tree(b, base, rnd, leaf, trunk, size) {
    size = size || 1;
    addAt(b, M.cyl(0.14, 0.2, 8), trunk, base, tr([0, 0.8 * size, 0], null, [size, 1.6 * size, size]));
    for (var i = 0; i < 5; i++) {
      var a = rnd() * PI * 2, r = (i ? 0.55 : 0) * size;
      addAt(b, M.ico(1), i % 2 ? leaf : shade(leaf, 1.12), base, tr([Math.sin(a) * r, (1.9 + rnd() * 0.7) * size, Math.cos(a) * r], [rnd(), rnd(), 0], (0.75 + rnd() * 0.35) * size));
    }
  }
  function pine(b, base, rnd, snow, size) {
    size = size || 1;
    addAt(b, M.cyl(0.12, 0.16, 7), 0x5B3A29, base, tr([0, 0.4 * size, 0], null, [size, 0.8 * size, size]));
    for (var i = 0; i < 4; i++) {
      var y = (0.7 + i * 0.75) * size, r = (1.25 - i * 0.26) * size;
      addAt(b, M.cone(9), 0x1F5C45, base, tr([0, y + 0.45 * size, 0], [0, i, 0], [r, 1.1 * size, r]));
      if (snow) addAt(b, M.cone(9), 0xF4F8FC, base, tr([0, y + 0.72 * size, 0], [0, i, 0], [r * 0.72, 0.6 * size, r * 0.72]));
    }
  }

  /* ---------------------------------------------------------- تم‌ها */
  var THEMES = {};

  THEMES.library = function (ctx) {
    var b = ctx.b, rnd = ctx.rnd, i, j;
    var spines = [0xB91C1C, 0x1D4ED8, 0x047857, 0x7C3AED, 0xC2410C, 0x0F766E, 0xA16207, 0x9D174D, 0x334155, 0xF5F0E1];
    [-64, -42, -21, 21, 42, 64, 0].forEach(function (deg) {
      var a = arc(deg, 8.9), base = place(null, a.x, 0, a.z, a.ry);
      var W = 2.6, H = deg === 0 ? 2.6 : 4.7, D = 0.7, shelves = deg === 0 ? 3 : 6;
      addAt(b, M.rbox(W, H, 0.1, 0.03), 0x4A2C1A, base, tr([0, H / 2, -D / 2 + 0.05]));
      [-1, 1].forEach(function (s) { addAt(b, M.rbox(0.14, H + 0.1, D, 0.03), 0x6B3E22, base, tr([s * W / 2, H / 2, 0])); });
      addAt(b, M.rbox(W + 0.3, 0.16, D + 0.12, 0.04), 0x6B3E22, base, tr([0, H + 0.05, 0]));
      var sh = H / shelves;
      for (i = 0; i < shelves; i++) {
        var y = i * sh;
        addAt(b, M.rbox(W, 0.07, D, 0.02), 0x7C4A2A, base, tr([0, y + 0.035, 0]));
        var x = -W / 2 + 0.12;
        while (x < W / 2 - 0.2) {
          var bw = 0.07 + rnd() * 0.09, bh = sh * (0.55 + rnd() * 0.33), tilt = rnd() < 0.08 ? 0.25 : 0;
          if (rnd() < 0.06) { x += 0.2; continue; }
          addAt(b, M.box(), spines[Math.floor(rnd() * spines.length)], base, tr([x + bw / 2, y + 0.07 + bh / 2, 0.02], [0, 0, tilt], [bw, bh, D * 0.78]));
          x += bw + 0.008;
        }
      }
      if (deg === 0) {
        addAt(b, M.ico(1), 0x2563EB, base, tr([-0.7, H + 0.6, 0], null, 0.42));
        addAt(b, M.torus(0.5, 0.03, PI, 6, 18), 0xD4A017, base, tr([-0.7, H + 0.6, 0], [0, 0, 0.4]));
        addAt(b, M.cyl(0.05, 0.05, 6), 0x6B3E22, base, tr([-0.7, H + 0.2, 0], null, [1, 0.3, 1]));
        addAt(b, M.cyl(0.18, 0.13, 10), 0xC2410C, base, tr([0.75, H + 0.3, 0], null, [1, 0.4, 1]));
        addAt(b, M.ico(1), 0x16A34A, base, tr([0.75, H + 0.7, 0], null, [0.38, 0.45, 0.38]));
      }
    });
    // نردبان کتابخانه
    var la = arc(-31, 8.2), lb = place(null, la.x, 0, la.z, la.ry);
    [-0.3, 0.3].forEach(function (x) { addAt(b, M.rbox(0.08, 4.4, 0.08, 0.02), 0x8B5A2B, lb, tr([x, 2.1, 0.2], [-0.2, 0, 0])); });
    for (i = 0; i < 9; i++) addAt(b, M.rbox(0.6, 0.06, 0.06, 0.02), 0x8B5A2B, lb, tr([0, 0.3 + i * 0.45, 0.2 + 0.09 - i * 0.09 + 0.38], [-0.2, 0, 0]));
    // پنجرهٔ گرد بالای قفسهٔ وسط
    var wz = E.CENTER_Z - 8.95;
    b.add(M.rbox(5.4, 7.4, 0.3, 0.05), 0xE9D8B8, tr([0, 3.7, wz - 0.32]));
    b.add(M.rbox(5.6, 0.3, 0.42, 0.05), 0x6B3E22, tr([0, 7.45, wz - 0.3]));
    b.add(M.torus(1.75, 0.16, 0, 8, 40), 0x6B3E22, tr([0, 4.9, wz + 0.06]));
    b.add(M.rbox(3.4, 0.12, 0.12, 0.03), 0x6B3E22, tr([0, 4.9, wz + 0.08]));
    b.add(M.rbox(0.12, 3.4, 0.12, 0.03), 0x6B3E22, tr([0, 4.9, wz + 0.08]));
    var glass = new T.Mesh(new T.CircleGeometry(1.72, 40), M.basic(ctx.night ? 0x1E3A8A : 0xFFF1C1, { fog: false }));
    glass.position.set(0, 4.9, wz); ctx.group.add(glass);
    if (ctx.night) {
      var moon = new T.Mesh(new T.CircleGeometry(0.42, 24), M.basic(0xFFF8DC, { fog: false })); moon.position.set(0.6, 5.35, wz + 0.02); ctx.group.add(moon);
      var mg = glowSprite(0xFFF3C4, 2.2, 0.55); mg.position.set(0.6, 5.35, wz + 0.1); ctx.group.add(mg);
    } else {
      // پرتوهای نور
      var rayTex = canvasTex(64, 256, function (g, w, h) { var gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(255,240,200,.9)'); gr.addColorStop(1, 'rgba(255,240,200,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
      for (j = 0; j < 3; j++) {
        var ray = new T.Mesh(new T.PlaneGeometry(1.1, 9), new T.MeshBasicMaterial({ map: rayTex, transparent: true, opacity: 0.13, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide, fog: false }));
        ray.position.set(-0.8 + j * 0.8, 2.6, wz + 3.2); ray.rotation.set(-0.62, 0, 0.12 - j * 0.12); ctx.group.add(ray); ctx.anim.push({ kind: 'ray', m: ray, ph: j });
      }
    }
    // کره و گیاه‌ها کنار
    var gp = arc(-58, 7.0), gb = place(null, gp.x, 0, gp.z, gp.ry);
    addAt(b, M.cyl(0.35, 0.45, 10), 0x6B3E22, gb, tr([0, 0.1, 0], null, [1, 0.2, 1]));
    addAt(b, M.cyl(0.06, 0.06, 6), 0x6B3E22, gb, tr([0, 0.7, 0], null, [1, 1.1, 1]));
    addAt(b, M.sphere(16), function (lp) { return Math.sin(lp.x * 6) + Math.cos(lp.y * 5 + lp.z * 3) > 0.6 ? 0x16A34A : 0x2563EB; }, gb, tr([0, 1.6, 0], null, 0.55));
    addAt(b, M.torus(0.62, 0.03, PI * 1.2, 6, 20), 0xD4A017, gb, tr([0, 1.6, 0], [0, 0, 0.4]));
    [[-6.3, -0.5], [6.3, -0.5], [6.6, -4.5], [-6.6, -4.5]].forEach(function (p, k) {
      var pb = place(null, p[0], 0, p[1], 0);
      addAt(b, M.cyl(0.32, 0.24, 12), k % 2 ? 0xC2410C : 0x1E3A8A, pb, tr([0, 0.32, 0], null, [1, 0.64, 1]));
      for (var l = 0; l < 6; l++) { var an = l / 6 * PI * 2; addAt(b, M.sphere(8), 0x15803D, pb, tr([Math.sin(an) * 0.25, 0.95 + (l % 2) * 0.2, Math.cos(an) * 0.25], [0.6, an, 0], [0.32, 0.08, 0.16])); }
    });
    // شمع‌های شناور (شب) / غبار نور (روز)
    if (ctx.night) {
      var cands = new B(), flames = [];
      for (i = 0; i < 9; i++) {
        var cx = (rnd() - 0.5) * 10, cy = 3.6 + rnd() * 2.2, cz2 = -8 + rnd() * 7;
        cands.add(M.cyl(0.06, 0.06, 8), 0xFFF7E6, tr([cx, cy, cz2], null, [1, 0.35, 1]));
        flames.push([cx, cy + 0.26, cz2]);
      }
      var cm = M.mesh(cands.build(), null, 0); ctx.group.add(cm); ctx.anim.push({ kind: 'float', m: cm });
      flames.forEach(function (f, k) { var s = glowSprite(0xFFC46B, 0.9, 0.95); s.position.set(f[0], f[1], f[2]); ctx.group.add(s); ctx.anim.push({ kind: 'flame', m: s, ph: k, base: 0.9, y: f[1] }); });
    }
    ctx.weather.push(E.weather({ count: ctx.q > 0 ? 70 : 35, box: [-6, 6, 0.3, 6.5, -9, 3], vel: [0.05, 0.12, 0], sway: 0.4, size: 0.09, color: ctx.night ? 0xFFD58A : 0xFFF0C8, opacity: 0.7, additive: true, twinkle: true }));
    ctx.rug = rugTex(0x9B2C2C, 0x1E3A5F);
  };

  THEMES.ancient_iran = function (ctx) {
    var b = ctx.b, rnd = ctx.rnd, i;
    // دیوارهٔ پلکان آپادانا با کاشی فیروزه‌ای و کنگره
    for (var deg = -70; deg <= 70; deg += 14) {
      var a = arc(deg, 9.0), base = place(null, a.x, 0, a.z, a.ry);
      addAt(b, M.box(), 0xD2B98E, base, tr([0, 1.25, 0], null, [1.62, 2.5, 0.6]));
      addAt(b, M.box(), 0x2F8F9D, base, tr([0, 1.7, 0.31], null, [1.62, 0.32, 0.04]));
      addAt(b, M.box(), 0x1E3A8A, base, tr([0, 1.25, 0.31], null, [1.62, 0.12, 0.04]));
      for (var k = 0; k < 4; k++) {
        addAt(b, M.box(), 0xF2E3BF, base, tr([-0.6 + k * 0.4, 1.7, 0.335], [0, 0, PI / 4], [0.12, 0.12, 0.02]));
        addAt(b, M.box(), 0xC8AE84, base, tr([-0.6 + k * 0.4, 2.72, 0], null, [0.22, 0.44, 0.5]));
        addAt(b, M.box(), 0xC8AE84, base, tr([-0.6 + k * 0.4, 3.0, 0], null, [0.12, 0.2, 0.4]));
      }
      // نقش‌برجستهٔ سربازان
      for (var s = 0; s < 3; s++) {
        addAt(b, M.capsule(0.07, 0.45), 0xB89A68, base, tr([-0.5 + s * 0.5, 0.75, 0.31], null, 1));
        addAt(b, M.sphere(8), 0xB89A68, base, tr([-0.5 + s * 0.5, 1.12, 0.31], null, [0.09, 0.1, 0.05]));
      }
    }
    // ستون‌ها با سرستون گاو دوسر
    [-56, -30, 30, 56, -78, 78].forEach(function (deg) {
      var a = arc(deg, 8.0), base = place(null, a.x, 0, a.z, a.ry);
      addAt(b, M.cyl(0.62, 0.7, 14), 0xC8AE84, base, tr([0, 0.2, 0], null, [1, 0.4, 1]));
      addAt(b, M.cyl(0.5, 0.58, 14), 0xD8C39A, base, tr([0, 0.55, 0], null, [1, 0.3, 1]));
      addAt(b, M.cyl(0.34, 0.38, 16), function (lp) { return Math.sin(Math.atan2(lp.x, lp.z) * 8) > 0 ? 0xE2CFA6 : 0xC8AE84; }, base, tr([0, 3.6, 0], null, [1, 5.8, 1]));
      addAt(b, M.cyl(0.55, 0.36, 12), 0xD8C39A, base, tr([0, 6.65, 0], null, [1, 0.3, 1]));
      addAt(b, M.rbox(1.9, 0.5, 0.7, 0.1), 0xC8AE84, base, tr([0, 7.05, 0]));
      [-1, 1].forEach(function (sd) {
        addAt(b, M.sphere(10), 0xD2B98E, base, tr([sd * 0.8, 7.05, 0.28], null, [0.32, 0.3, 0.36]));
        addAt(b, M.cone(6), 0xF2E3BF, base, tr([sd * 0.95, 7.38, 0.28], [0, 0, sd * -0.5], [0.06, 0.25, 0.06]));
      });
    });
    // آتشدان‌ها کنار سکوی خان
    [-1, 1].forEach(function (sd) {
      var x = sd * 3.15, z = E.BOSS_Z + 0.4;
      b.add(M.box(), 0xC8AE84, tr([x, 0.35, z], null, [0.9, 0.7, 0.9]));
      b.add(M.box(), 0xB89A68, tr([x, 0.85, z], null, [0.6, 0.3, 0.6]));
      b.add(M.cyl(0.5, 0.32, 12), 0x8C6A3F, tr([x, 1.15, z], null, [1, 0.3, 1]));
      for (var f = 0; f < 3; f++) {
        var fl = glowSprite(f ? 0xFF8C1A : 0xFFD54F, f ? 1.3 : 0.9, 0.9);
        fl.position.set(x + (f - 1) * 0.12, 1.55 + (f === 0 ? 0.15 : 0), z); ctx.group.add(fl);
        ctx.anim.push({ kind: 'flame', m: fl, ph: f + sd * 3, base: fl.scale.x, y: fl.position.y });
      }
      ctx.weather.push(E.weather({ count: 24, box: [x - 0.35, x + 0.35, 1.4, 3.6, z - 0.35, z + 0.35], vel: [0, 1.1, 0], sway: 0.12, size: 0.12, color: 0xFFA64D, opacity: 0.95, additive: true, seed: 40 + sd }));
    });
    // کوه‌های دور
    var mb = new B();
    for (i = 0; i < 9; i++) mb.add(M.cone(5), i % 2 ? 0x9C6B7E : 0x7E5670, tr([-40 + i * 10 + rnd() * 4, 3, -42 - rnd() * 6], [0, rnd(), 0], [7 + rnd() * 4, 9 + rnd() * 6, 6]));
    var mm = new T.Mesh(mb.build(), M.sharedToon()); ctx.group.add(mm);
    ctx.weather.push(E.weather({ count: ctx.q > 0 ? 50 : 25, box: [-7, 7, 0.3, 6, -9, 3], vel: [0.25, 0.05, 0], sway: 0.3, size: 0.08, color: 0xFFE7B0, opacity: 0.6, additive: true, twinkle: true }));
    ctx.rug = rugTex(0x7F1D1D, 0x14325C);
  };

  THEMES.rasht = function (ctx) {
    var b = ctx.b, rnd = ctx.rnd, i;
    // ساختمان شهرداری رشت با برج ساعت
    var z0 = E.CENTER_Z - 9.0;
    b.add(M.rbox(6.2, 3.2, 1.6, 0.05), 0xF3EEE6, tr([0, 1.6, z0]));
    b.add(M.rbox(6.5, 0.25, 1.8, 0.05), 0xB8452F, tr([0, 3.3, z0]));
    for (i = -2; i <= 2; i++) {
      if (i === 0) continue;
      b.add(M.rbox(0.62, 1.1, 0.06, 0.25), 0x334155, tr([i * 1.15, 1.75, z0 + 0.81]));
      b.add(M.rbox(0.76, 0.12, 0.12, 0.03), 0xD6CFC3, tr([i * 1.15, 1.15, z0 + 0.84]));
    }
    b.add(M.rbox(1.8, 6.6, 1.8, 0.05), 0xF8F4EC, tr([0, 3.3, z0 + 0.1]));
    b.add(M.rbox(2.0, 0.2, 2.0, 0.05), 0xD6CFC3, tr([0, 6.65, z0 + 0.1]));
    b.add(M.rbox(1.3, 1.6, 1.3, 0.05), 0xF8F4EC, tr([0, 7.5, z0 + 0.1]));
    b.add(M.hemi(16), 0x2F6B5E, tr([0, 8.3, z0 + 0.1], null, [0.85, 1.0, 0.85]));
    b.add(M.cone(8), 0xD4A017, tr([0, 9.6, z0 + 0.1], null, [0.09, 0.7, 0.09]));
    b.add(M.cyl(1, 1, 24), 0xF5F0E1, tr([0, 5.4, z0 + 1.0], [PI / 2, 0, 0], [0.62, 0.06, 0.62]));
    b.add(M.torus(0.63, 0.06, 0, 6, 28), 0x1F2937, tr([0, 5.4, z0 + 1.03]));
    b.add(M.box(), 0x111827, tr([0, 5.58, z0 + 1.06], null, [0.05, 0.4, 0.02]));
    b.add(M.box(), 0x111827, tr([0.12, 5.4, z0 + 1.06], [0, 0, -1.2], [0.05, 0.28, 0.02]));
    b.add(M.rbox(0.7, 1.5, 0.06, 0.3), 0x334155, tr([0, 3.6, z0 + 1.01]));
    if (ctx.night) {
      var cg = glowSprite(0xFFF3C4, 2.2, 0.5); cg.position.set(0, 5.4, z0 + 1.15); ctx.group.add(cg);
      var lit = new B();
      [-2, -1, 1, 2].forEach(function (k) { lit.add(M.rbox(0.5, 0.9, 0.02, 0.2), 0xFFD58A, tr([k * 1.15, 1.75, z0 + 0.85])); });
      lit.add(M.rbox(0.56, 1.3, 0.02, 0.25), 0xFFD58A, tr([0, 3.6, z0 + 1.05]));
      ctx.group.add(new T.Mesh(lit.build(), M.basic(0xFFFFFF, { vertexColors: true })));
    }
    // خانه‌های گیلانی با سفال سرخ و ایوان چوبی
    [[-46, 8.4, 1], [46, 8.4, -1], [-70, 8.2, 1], [70, 8.2, -1]].forEach(function (h, k) {
      var a = arc(h[0], h[1]), base = place(null, a.x, 0, a.z, a.ry);
      addAt(b, M.rbox(2.6, 2.0, 2.0, 0.04), k % 2 ? 0xEFE7D8 : 0xE8DCC6, base, tr([0, 1.4, 0]));
      addAt(b, M.rbox(2.9, 0.12, 2.3, 0.03), 0x6E5238, base, tr([0, 0.4, 0.15]));
      for (var p = -1; p <= 1; p++) addAt(b, M.rbox(0.1, 2.0, 0.1, 0.02), 0x6E5238, base, tr([p * 1.3, 1.4, 1.15]));
      addAt(b, M.rbox(2.8, 0.08, 0.08, 0.02), 0x6E5238, base, tr([0, 1.0, 1.15]));
      var roof = new T.Matrix4().multiplyMatrices(base, tr([0, 2.4, 0], [0, PI / 4, 0], [2.3, 1.7, 2.3]));
      b.add(M.cone(4), 0xB8452F, roof);
      addAt(b, M.rbox(0.5, 0.7, 0.04, 0.03), ctx.night ? 0xFFD58A : 0x334155, base, tr([0.6, 1.5, 1.01]));
      addAt(b, M.rbox(0.5, 1.1, 0.04, 0.03), 0x6E5238, base, tr([-0.5, 1.0, 1.01]));
    });
    for (i = 0; i < 7; i++) {
      var deg = [-84, -60, -32, 32, 60, 84, -18][i], a2 = arc(deg + (rnd() - 0.5) * 6, 9.6 + rnd() * 0.8);
      tree(b, place(null, a2.x, 0, a2.z, 0), rnd, 0x2E7D4F, 0x5B3A29, 1.3 + rnd() * 0.5);
    }
    // چاله‌های آب
    var pud = new B();
    [[-4.6, 1.8, 0.8], [4.4, -3.0, 0.6], [-3.6, -6.2, 0.7], [3.9, 2.6, 0.5]].forEach(function (p) { pud.add(M.cyl(1, 1, 20), 0xA9C7D6, tr([p[0], 0.012, p[1]], null, [p[2] * 1.4, 0.005, p[2]])); });
    var pm = new T.Mesh(pud.build(), M.basic(0xFFFFFF, { vertexColors: true, transparent: true, opacity: 0.6 })); ctx.group.add(pm);
    ctx.weather.push(E.rain(ctx.q > 0 ? 420 : 200, [-9, 9, -0.2, 12, -12, 6]));
    ctx.rug = rugTex(0x2F5D50, 0x7F1D1D);
  };

  THEMES.white_nights = function (ctx) {
    var b = ctx.b, rnd = ctx.rnd, i;
    for (i = 0; i < 12; i++) {
      var deg = -84 + i * 15.3 + (rnd() - 0.5) * 5, a = arc(deg, 8.6 + rnd() * 1.2);
      pine(b, place(null, a.x, 0, a.z, rnd() * 3), rnd, true, 1.1 + rnd() * 0.7);
    }
    // تپه‌های برف و بلورهای یخ
    for (i = 0; i < 9; i++) {
      var a2 = arc(-80 + i * 20, 7.6 + rnd()), base = place(null, a2.x, 0, a2.z, 0);
      addAt(b, M.hemi(12), 0xFFFFFF, base, tr([0, 0, 0], null, [1.1 + rnd(), 0.5 + rnd() * 0.3, 0.9]));
      if (i % 2) addAt(b, M.octa(), 0x8FD3FF, base, tr([0.4, 0.6, 0.2], [0.2, rnd(), 0.3], [0.22, 0.7, 0.22]));
    }
    // آدم‌برفی
    var sm = place(null, -4.9, 0, -5.9, 0.5);
    addAt(b, M.sphere(14), 0xFFFFFF, sm, tr([0, 0.5, 0], null, 0.55));
    addAt(b, M.sphere(14), 0xFFFFFF, sm, tr([0, 1.25, 0], null, 0.4));
    addAt(b, M.sphere(14), 0xFFFFFF, sm, tr([0, 1.85, 0], null, 0.3));
    addAt(b, M.cone(8), 0xF97316, sm, tr([0, 1.85, 0.36], [PI / 2, 0, 0], [0.06, 0.25, 0.06]));
    [-1, 1].forEach(function (s) { addAt(b, M.sphere(6), 0x111827, sm, tr([s * 0.1, 1.95, 0.26], null, 0.035)); });
    addAt(b, M.cyl(0.33, 0.33, 14), 0xDC2626, sm, tr([0, 1.6, 0], null, [1, 0.1, 1]));
    addAt(b, M.cyl(0.18, 0.2, 12), 0x1F2937, sm, tr([0, 2.2, 0], null, [1, 0.3, 1]));
    // تیر چراغ
    [[-5.6, 1.5], [5.6, 1.5], [5.3, -5.6]].forEach(function (p) {
      var lb = place(null, p[0], 0, p[1], 0);
      addAt(b, M.cyl(0.06, 0.08, 8), 0x1F2937, lb, tr([0, 1.4, 0], null, [1, 2.8, 1]));
      addAt(b, M.rbox(0.36, 0.42, 0.36, 0.06), 0x1F2937, lb, tr([0, 2.95, 0]));
      addAt(b, M.rbox(0.26, 0.3, 0.37, 0.04), 0xFFE7A8, lb, tr([0, 2.95, 0]));
      addAt(b, M.cone(8), 0x1F2937, lb, tr([0, 3.3, 0], null, [0.26, 0.25, 0.26]));
      var g = glowSprite(0xFFD58A, ctx.night ? 2.2 : 1.0, ctx.night ? 0.85 : 0.4); g.position.set(p[0], 2.95, p[1]); ctx.group.add(g);
    });
    // شفق قطبی
    var aur = new T.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uA: { value: ctx.night ? 0.85 : 0.3 } },
      vertexShader: 'varying vec2 vUv; uniform float uTime; void main(){ vUv = uv; vec3 p = position; p.z += sin(p.x * 0.18 + uTime * 0.35) * 3.0; p.y += sin(p.x * 0.11 - uTime * 0.25) * 1.2; gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0); }',
      fragmentShader: 'varying vec2 vUv; uniform float uTime, uA; void main(){ float w = sin(vUv.x * 40.0 + uTime * 0.8) * 0.5 + 0.5; float a = smoothstep(0.0, 0.35, vUv.y) * (1.0 - smoothstep(0.45, 1.0, vUv.y)); vec3 c = mix(vec3(0.15, 1.0, 0.6), vec3(0.65, 0.35, 1.0), vUv.y); gl_FragColor = vec4(c, a * (0.45 + 0.55 * w) * uA); }',
      transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide, fog: false
    });
    for (i = 0; i < 2; i++) {
      var ap = new T.Mesh(new T.PlaneGeometry(70, 9, 60, 1), aur);
      ap.position.set(i * 8 - 4, 15 + i * 3, -42 + i * 4); ap.rotation.x = 0.25; ctx.group.add(ap);
    }
    ctx.anim.push({ kind: 'uniform', mat: aur });
    var lake = new T.Mesh(new T.CircleGeometry(30, 32), M.basic(ctx.night ? 0x1C3550 : 0xBFD8EE, { fog: true }));
    lake.rotation.x = -PI / 2; lake.position.set(0, -6, -30); ctx.group.add(lake);
    ctx.weather.push(E.weather({ count: ctx.q > 0 ? 260 : 120, box: [-9, 9, -0.3, 11, -12, 6], vel: [0.25, -0.9, 0.1], sway: 0.5, size: 0.13, color: 0xFFFFFF, opacity: 0.9, cell: 'dot' }));
    ctx.rug = null;
    ctx.fur = true;
  };

  THEMES.japanese = function (ctx) {
    var b = ctx.b, rnd = ctx.rnd, i;
    var red = 0xC0392B, z0 = E.CENTER_Z - 8.9;
    // دروازهٔ توری
    [-1, 1].forEach(function (s) {
      b.add(M.cyl(0.24, 0.28, 14), red, tr([s * 2.5, 3.0, z0], null, [1, 6.0, 1]));
      b.add(M.cyl(0.34, 0.34, 14), 0x1F2937, tr([s * 2.5, 0.25, z0], null, [1, 0.5, 1]));
    });
    b.add(M.rbox(6.2, 0.36, 0.5, 0.06), red, tr([0, 5.4, z0]));
    b.add(M.rbox(7.4, 0.3, 0.62, 0.06), 0x1F2937, tr([0, 6.15, z0]));
    [-1, 1].forEach(function (s) { b.add(M.rbox(1.0, 0.3, 0.62, 0.06), 0x1F2937, tr([s * 3.85, 6.28, z0], [0, 0, s * 0.18])); });
    b.add(M.rbox(7.0, 0.32, 0.56, 0.06), red, tr([0, 5.85, z0]));
    b.add(M.rbox(0.9, 1.0, 0.12, 0.04), 0x1F2937, tr([0, 5.0, z0 + 0.3]));
    b.add(M.rbox(0.7, 0.8, 0.02, 0.02), 0xD4A017, tr([0, 5.0, z0 + 0.37]));
    // درخت‌های شکوفهٔ گیلاس
    [[-50, 8.2], [50, 8.2], [-76, 8.0], [76, 8.0], [-25, 9.6], [25, 9.6]].forEach(function (t, k) {
      var a = arc(t[0], t[1]), base = place(null, a.x, 0, a.z, rnd() * 3), sz = 1.2 + rnd() * 0.5;
      addAt(b, M.cyl(0.13, 0.22, 8), 0x4A3428, base, tr([0, 1.0 * sz, 0], [0, 0, 0.12], [1, 2.0 * sz, 1]));
      addAt(b, M.cyl(0.07, 0.11, 6), 0x4A3428, base, tr([0.45 * sz, 2.0 * sz, 0], [0, 0, -0.9], [1, 1.0 * sz, 1]));
      for (var l = 0; l < 7; l++) {
        var an = rnd() * PI * 2, rr = rnd() * 1.1 * sz;
        addAt(b, M.ico(1), l % 3 ? 0xF9A8C8 : 0xFBCFE0, base, tr([Math.sin(an) * rr, (2.3 + rnd() * 0.9) * sz, Math.cos(an) * rr * 0.7], [rnd(), rnd(), 0], (0.55 + rnd() * 0.35) * sz));
      }
    });
    // فانوس سنگی کنار سکو
    [-1, 1].forEach(function (s) {
      var x = s * 3.1, z = E.BOSS_Z + 0.5;
      b.add(M.cyl(0.32, 0.4, 8), 0x8A8580, tr([x, 0.15, z], null, [1, 0.3, 1]));
      b.add(M.cyl(0.12, 0.14, 8), 0x8A8580, tr([x, 0.75, z], null, [1, 0.9, 1]));
      b.add(M.rbox(0.62, 0.1, 0.62, 0.03), 0x8A8580, tr([x, 1.25, z]));
      b.add(M.rbox(0.42, 0.42, 0.42, 0.04), 0x9A958F, tr([x, 1.52, z]));
      b.add(M.rbox(0.3, 0.26, 0.44, 0.02), 0xFFE7A8, tr([x, 1.52, z]));
      b.add(M.cone(6), 0x8A8580, tr([x, 1.98, z], [0, PI / 6, 0], [0.55, 0.42, 0.55]));
      b.add(M.sphere(8), 0x8A8580, tr([x, 2.25, z], null, 0.08));
      var g = glowSprite(0xFFC46B, ctx.night ? 1.8 : 0.8, ctx.night ? 0.9 : 0.35); g.position.set(x, 1.52, z + 0.05); ctx.group.add(g);
      ctx.anim.push({ kind: 'flame', m: g, ph: s * 2, base: g.scale.x, y: 1.52, small: true });
    });
    // بامبو
    [[-6.6, 0.5], [6.6, 0.0], [-6.2, -3.6], [6.3, -4.2]].forEach(function (p) {
      for (var k = 0; k < 4; k++) {
        var x = p[0] + (rnd() - 0.5) * 0.8, z = p[1] + (rnd() - 0.5) * 0.8, h = 3 + rnd() * 2;
        for (var sg = 0; sg < 5; sg++) b.add(M.cyl(0.07, 0.07, 6), sg % 2 ? 0x4D9A3A : 0x5DAE47, tr([x, h * (sg + 0.5) / 5, z], null, [1, h / 5 - 0.03, 1]));
        b.add(M.sphere(6), 0x3F8A35, tr([x + 0.2, h, z], [0, 0, 0.6], [0.35, 0.08, 0.12]));
      }
    });
    // فوجی دوردست
    var fb = new B();
    fb.add(M.cone(14), 0x6C7FA8, tr([8, 2, -55], null, [22, 16, 22]));
    fb.add(M.cone(14), 0xF8FAFC, tr([8, 7.1, -55], null, [7.9, 5.8, 7.9]));
    ctx.group.add(new T.Mesh(fb.build(), M.sharedToon()));
    if (ctx.night) { var moon = glowSprite(0xFFF8DC, 7, 0.75); moon.position.set(-12, 16, -48); ctx.group.add(moon); var md = new T.Mesh(new T.CircleGeometry(1.4, 24), M.basic(0xFFF8E7, { fog: false })); md.position.set(-12, 16, -47.9); ctx.group.add(md); }
    ctx.weather.push(E.weather({ count: ctx.q > 0 ? 110 : 55, box: [-9, 9, -0.2, 9, -12, 5], vel: [0.5, -0.55, 0.15], sway: 0.6, size: 0.22, color: 0xFFB7D0, opacity: 0.95, cell: 'petal', seed: 12 }));
    ctx.rug = null;
  };

  var SKY = {
    library: { day: [0x7EC3F0, 0xFFE9C2, 0xF6D7A7], night: [0x0B1433, 0x2A2F5E, 0x1A1838], fog: [0xF3DDB8, 0x232650] },
    ancient_iran: { day: [0x5FA8DE, 0xFFD39A, 0xF2B880], night: [0x0B1026, 0x3B2A5A, 0x24183A], fog: [0xF5CF9C, 0x2E2148] },
    rasht: { day: [0x8FA8AE, 0xD5DEDA, 0xB9C8C2], night: [0x0B1620, 0x24363F, 0x111C24], fog: [0xC4D0CB, 0x1C2B33] },
    white_nights: { day: [0x8FB9E6, 0xF6D6E2, 0xDDE7F3], night: [0x050D20, 0x163052, 0x0A1528], fog: [0xEADFEA, 0x10243E] },
    japanese: { day: [0x8EC9F2, 0xFFE0E6, 0xFCE7EF], night: [0x0D0F2E, 0x3A2E5C, 0x1B163A], fog: [0xFAE1E8, 0x2A2350] }
  };
  E.THEMES = Object.keys(THEMES);

  /** ساخت کامل محیط. q: سطح کیفیت ۰..۲ */
  E.build = function (theme, night, q) {
    if (!THEMES[theme]) theme = 'library';
    var group = new T.Group(), b = new B(), rnd = R3.rng(R3.hash(theme)), w = M.THEME_WOOD[theme];
    var ctx = { b: b, rnd: rnd, group: group, night: !!night, q: q, anim: [], weather: [], rug: null };
    island(b, theme, w, rnd);
    platform(b, theme, w);
    THEMES[theme](ctx);
    var stat = M.mesh(b.build(), M.sharedToon(), q > 0 ? 0.03 : 0);
    group.add(stat);

    // کف
    var floorTex = canvasTex(512, 512, function (g, W, H) { FLOOR[theme](g, W, H, R3.rng(5)); }, theme === 'japanese' ? 3 : (theme === 'ancient_iran' ? 3 : 4));
    var floorMat = new T.MeshToonMaterial({ map: floorTex, gradientMap: M.sharedToon().gradientMap });
    var floor = new T.Mesh(new T.CircleGeometry(E.RADIUS, 64), floorMat);
    floor.rotation.x = -PI / 2; floor.position.set(0, 0, E.CENTER_Z);
    floor.userData.pick = { type: 'floor' };
    group.add(floor);
    if (ctx.rug) {
      var rug = new T.Mesh(new T.PlaneGeometry(8.2, 9.2), new T.MeshToonMaterial({ map: ctx.rug, gradientMap: M.sharedToon().gradientMap }));
      rug.rotation.x = -PI / 2; rug.position.set(0, 0.01, -0.95); group.add(rug);
    } else if (ctx.fur) {
      var fur = new T.Mesh(new T.CircleGeometry(4.4, 40), M.toon({ vertexColors: false, color: 0xDCE6F2 }));
      fur.rotation.x = -PI / 2; fur.scale.set(1, 1.15, 1); fur.position.set(0, 0.012, -1.1); group.add(fur);
    }
    var runes = runeRing(); runes.position.set(0, E.PLAT_H + 0.08, E.BOSS_Z); group.add(runes);

    var sk = SKY[theme], col = night ? sk.night : sk.day;
    var sky = skyDome(col[0], col[1], col[2]); group.add(sky);
    if (night) { var st = stars(q > 0 ? 420 : 220); group.add(st); ctx.weather.push(st); }
    else {
      var clouds = new T.Group(), cr = R3.rng(3), cloudCol = theme === 'rasht' ? 0xDCE3E2 : 0xFFFFFF;
      for (var i = 0; i < (theme === 'rasht' ? 12 : 8); i++) {
        var cm = new T.Mesh(cloudGeo(cr, cloudCol), M.sharedToon()), an = cr() * PI * 2, rr = 15 + cr() * 9;
        cm.position.set(Math.sin(an) * rr, -3 + cr() * 7, E.CENTER_Z + Math.cos(an) * rr - 4); cm.scale.setScalar(1.2 + cr() * 1.2);
        clouds.add(cm);
      }
      group.add(clouds); ctx.anim.push({ kind: 'spin', m: clouds, speed: 0.006 });
    }
    ctx.weather.forEach(function (wx) { group.add(wx); });

    var light = night
      ? { hemi: [0x9DB4FF, 0x2A2236, 1.25], sun: [0xB9C8FF, 1.15, [-6, 12, 6]], amb: 0.35 }
      : { hemi: [0xFFFFFF, 0x8C7A6B, 1.7], sun: [0xFFF1D6, 2.3, [6, 14, 8]], amb: 0.25 };
    if (theme === 'rasht' && !night) { light.hemi[2] = 1.9; light.sun[1] = 1.4; }
    if (theme === 'white_nights' && !night) { light.hemi[2] = 1.3; light.sun[1] = 1.75; light.hemi[1] = 0x7D8CA3; }

    return {
      theme: theme, night: !!night, group: group, runes: runes,
      fog: [night ? sk.fog[1] : sk.fog[0], theme === 'rasht' ? 16 : 22, theme === 'rasht' ? 52 : 70],
      light: light,
      update: function (t, dt, px) {
        for (var i = 0; i < ctx.weather.length; i++) {
          var u = ctx.weather[i].material.uniforms;
          u.uTime.value = t;
          if (u.uPx) u.uPx.value = px;
        }
        for (var j = 0; j < ctx.anim.length; j++) {
          var a = ctx.anim[j];
          if (a.kind === 'flame') { var f = 1 + Math.sin(t * 9 + a.ph * 1.7) * 0.1 + Math.sin(t * 23 + a.ph) * 0.06; a.m.scale.setScalar(a.base * f); a.m.position.y = a.y + Math.sin(t * 6 + a.ph) * (a.small ? 0.01 : 0.04); }
          else if (a.kind === 'spin') a.m.rotation.y += dt * a.speed;
          else if (a.kind === 'float') a.m.position.y = Math.sin(t * 0.8) * 0.12;
          else if (a.kind === 'ray') a.m.material.opacity = 0.09 + Math.sin(t * 0.6 + a.ph) * 0.04;
          else if (a.kind === 'uniform') a.mat.uniforms.uTime.value = t;
        }
        runes.rotation.y = t * 0.15;
        runes.userData.band.rotation.y = -t * 0.35;
      },
      dispose: function () {
        group.traverse(function (o) {
          if (o.geometry && !o.userData.outline && !o.isSprite) o.geometry.dispose();
          if (o.material && o.material !== M.shared.toon && !o.userData.outline) {
            var mp = o.material.map;
            if (mp && mp !== M.glowTex && mp !== M.atlas) mp.dispose();
            o.material.dispose();
          }
        });
      }
    };
  };
})();
