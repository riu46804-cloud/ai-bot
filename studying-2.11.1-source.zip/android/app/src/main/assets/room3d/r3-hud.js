/* هفت‌خانِ تمرکز — رابط کاربری روی صحنه: نوارها، دکمه‌ها، اعلان‌ها و پنجره‌ها.
   همهٔ متن‌های کاربرساز با textContent نوشته می‌شوند. */
(function () {
  'use strict';
  var R3 = window.R3, $ = R3.$, el = R3.el, kids = R3.kids, tap = R3.tap;
  var H = R3.hud = {};
  var G = function () { return R3.game; };

  H.TIER_NAME = ['جرقه', 'شعله', 'آتش', 'آتش آبی', 'خشم رستم'];
  H.TIER_FLAME = ['✨', '🔥', '🔥', '💙', '⚡'];
  H.TIER_AT = [0, 600, 1500, 3000, 5400];
  H.RARITY = { common: { fa: 'صندوق چوبی', e: '📦' }, rare: { fa: 'صندوق آبی', e: '🎁' }, epic: { fa: 'صندوق حماسی', e: '💎' } };
  H.KHAN_EMOJI = ['🦁', '🏜️', '🐉', '🧙', '🛡️', '👺', '👹'];

  /* ---------------------------------------------------------- نوار بالا */
  var coinShown = null, coinAnim = 0;
  H.top = function (me) {
    if (!me) return;
    $('lvl-num').textContent = R3.fa(me.level || 1);
    $('lvl-title').textContent = me.level_title || '';
    $('lvl-emoji').textContent = me.level_emoji || '🌱';
    var span = Math.max(1, (me.next_level_xp || 100) - (me.level_start_xp || 0));
    var p = R3.clamp(((me.xp || 0) - (me.level_start_xp || 0)) / span, 0, 1), C = 2 * Math.PI * 16;
    var ring = $('lvl-ring'); ring.style.strokeDasharray = C.toFixed(1); ring.style.strokeDashoffset = (C * (1 - p)).toFixed(1);
    $('streak-num').textContent = R3.fa(me.streak || 0);
    H.coins(me.coins || 0);
    H.layout();
  };
  /** چیدمان افقی: نوار خان بین تراشه‌های بالا جا می‌گیرد تا صحنه بزرگ‌تر بماند. */
  var layoutRaf = 0;
  H.layout = function () {
    if (layoutRaf) return;
    layoutRaf = requestAnimationFrame(function () {
      layoutRaf = 0;
      var w = window.innerWidth, h = window.innerHeight, land = w > h && h <= 560;
      document.body.classList.toggle('land', land);
      var boss = $('boss'), note = $('server-note');
      [boss, note].forEach(function (n) { n.style.left = ''; n.style.right = ''; });
      document.body.classList.remove('land-boss-low');
      if (!land) return;
      var a = $('online').getBoundingClientRect(), b = $('streak').getBoundingClientRect();
      var L = Math.round(a.right + 10), R = Math.round(w - b.left + 10);
      if (w - L - R < 220) { document.body.classList.add('land-boss-low'); return; }
      [boss, note].forEach(function (n) { n.style.left = L + 'px'; n.style.right = R + 'px'; });
    });
  };
  H.coins = function (v) {
    var node = $('coins-num');
    if (coinShown === null) { coinShown = v; node.textContent = R3.num(v); return; }
    if (v === coinShown) return;
    var from = coinShown, t0 = performance.now(); coinShown = v;
    cancelAnimationFrame(coinAnim);
    var chip = $('coins'); chip.classList.remove('bump'); void chip.offsetWidth; chip.classList.add('bump');
    (function step(now) {
      var k = Math.min(1, (now - t0) / 900);
      node.textContent = R3.num(Math.round(from + (v - from) * R3.ease.outCubic(k)));
      if (k < 1) coinAnim = requestAnimationFrame(step);
    })(t0);
  };
  H.online = function (n) { $('online-num').textContent = R3.fa(n || 0); };

  /* ---------------------------------------------------------- نوار خان */
  var lastHitFlash = 0;
  H.boss = function (raid, shownDamage) {
    var b = $('boss');
    if (!raid) { b.classList.add('hidden'); return; }
    b.classList.remove('hidden');
    $('boss-khan').textContent = raid.khan + (raid.cycle > 1 ? ' · دور ' + R3.fa(raid.cycle) : '');
    $('boss-name').textContent = (raid.emoji || '') + ' ' + raid.title;
    $('boss-fighters').textContent = raid.fighters ? '⚔️ ' + R3.fa(raid.fighters) + ' نفر' : '';
    var max = Math.max(1, raid.hp_max), left = Math.max(0, max - shownDamage), pct = R3.clamp(left / max * 100, 0, 100);
    $('hp-fill').style.width = pct.toFixed(2) + '%';
    $('hp-ghost').style.width = pct.toFixed(2) + '%';
    $('hp-text').textContent = '❤️ ' + R3.num(left) + ' از ' + R3.num(max);
    $('hp').classList.toggle('low', pct < 25);
  };
  H.bossFlash = function () {
    var now = performance.now();
    if (now - lastHitFlash < 260) return;
    lastHitFlash = now;
    var b = $('boss'); b.classList.add('hitflash');
    setTimeout(function () { b.classList.remove('hitflash'); }, 160);
  };
  H.serverNote = function (text) {
    var n = $('server-note');
    if (!text) { n.classList.add('hidden'); return; }
    n.textContent = text; n.classList.remove('hidden');
  };

  /* ---------------------------------------------------------- کمبو */
  H.combo = function (c) {
    var box = $('combo'), tier = c.tier | 0;
    box.className = 't' + tier + (c.studying ? ' live' : '');
    $('combo-flame').textContent = c.studying || c.live > 0 ? H.TIER_FLAME[tier] : '💤';
    $('combo-mult').textContent = R3.mult(R3.world.MULT[tier]);
    $('combo-name').textContent = H.TIER_NAME[tier];
    var a = H.TIER_AT[tier], b = H.TIER_AT[tier + 1] || a, p = tier >= 4 ? 1 : R3.clamp((c.live - a) / Math.max(1, b - a), 0, 1);
    $('combo-bar').style.width = (p * 100).toFixed(1) + '%';
    var next;
    if (c.studying) next = tier >= 4 ? 'بیشترین قدرت!' : R3.dur(b - c.live) + ' تا ' + R3.mult(R3.world.MULT[tier + 1]);
    else if (c.resting && c.live > 0) next = '☕ کمبو حفظ است · ' + R3.clock(c.gapLeft);
    else if (c.live > 0 && c.gapLeft > 0) next = '⏳ ' + R3.clock(c.gapLeft) + ' تا خاموشی';
    else next = 'تمرکز کن تا شعله روشن شود';
    $('combo-next').textContent = next;
  };
  H.comboBurst = function () { var b = $('combo'); b.classList.remove('burst'); void b.offsetWidth; b.classList.add('burst'); };

  /* ---------------------------------------------------------- دکمهٔ تمرکز */
  var FC = 2 * Math.PI * 45;
  H.focus = function (tm, studying, resting) {
    var f = $('focus'), time = $('focus-time'), label = $('focus-label'), ring = $('focus-ring');
    ring.style.strokeDasharray = FC.toFixed(1);
    var cls = '', txt = '', t = '', p = 0;
    if (!tm) { time.textContent = '—'; label.textContent = 'در حال آماده‌سازی'; return; }
    if (tm.mode === 'chrono') {
      t = R3.clock(tm.chrono_sec || 0); p = ((tm.chrono_sec || 0) % 3600) / 3600;
      if (tm.chrono_running) { cls = 'run'; txt = 'در حال تمرکز'; }
      else if (tm.chrono_sec > 0) { cls = 'paused'; txt = 'ادامه'; }
      else txt = 'شروع تمرکز';
    } else {
      var total = Math.max(1, tm.total || (tm.work_min || 25) * 60);
      var rem = tm.phase === 'idle' ? (tm.work_min || 25) * 60 : tm.remaining;
      t = R3.clock(rem); p = tm.phase === 'idle' ? 0 : 1 - rem / total;
      if (tm.phase === 'work') { cls = tm.running ? 'run' : 'paused'; txt = tm.running ? 'در حال تمرکز' : 'ادامه'; }
      else if (tm.phase === 'break' || tm.phase === 'long_break') { cls = 'rest' + (tm.running ? '' : ' paused'); txt = tm.running ? (tm.phase === 'long_break' ? 'استراحت بلند ☕' : 'استراحت ☕') : 'ادامهٔ استراحت'; }
      else txt = 'شروع تمرکز';
    }
    f.className = cls; time.textContent = t; label.textContent = txt;
    ring.style.strokeDashoffset = (FC * (1 - p)).toFixed(1);
    $('btn-skip').classList.toggle('hidden', !(tm.mode !== 'chrono' && (tm.phase === 'break' || tm.phase === 'long_break')));
    $('btn-mode').textContent = tm.mode === 'chrono' ? '⏲️ کرنومتر' : '⏱️ پومودورو';
    var pend = Math.floor(tm.pending_min || 0);
    var lg = $('btn-log');
    lg.textContent = pend > 0 ? '✅ ثبت ' + R3.fa(pend) + ' دقیقه' : '✅ ثبت مطالعه';
    lg.style.background = pend > 0 ? 'var(--gold)' : '';
  };

  /* ---------------------------------------------------------- داک */
  H.dock = function (d) {
    var cb = $('chest-badge');
    cb.textContent = R3.fa(d.chests || 0); cb.classList.toggle('hidden', !d.chests);
    var C = 2 * Math.PI * 17, ring = $('chest-ring');
    ring.style.strokeDasharray = C.toFixed(1); ring.style.strokeDashoffset = (C * (1 - R3.clamp(d.chestP || 0, 0, 1))).toFixed(1);
    $('quest-badge').classList.toggle('hidden', !d.quest);
    $('hat-badge').classList.toggle('hidden', !d.hat);
    $('battle-badge').classList.toggle('hidden', !d.battle);
  };

  /* ---------------------------------------------------------- اعلان‌ها */
  H.toast = function (text, cls, ms) {
    var feed = $('feed');
    while (feed.children.length >= 4) feed.removeChild(feed.firstChild);
    var t = el('div', 'toast ' + (cls || ''), text);
    feed.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 420); }, ms || 4200);
  };
  var bq = [], bBusy = false;
  H.banner = function (big, sm, cls, ms) { bq.push([big, sm, cls, ms]); if (!bBusy) nextBanner(); };
  function nextBanner() {
    var item = bq.shift();
    if (!item) { bBusy = false; $('banner').classList.add('hidden'); return; }
    bBusy = true;
    var box = $('banner'); box.classList.remove('hidden'); box.textContent = '';
    var bn = el('div', 'bn ' + (item[2] || ''));
    kids(bn, el('div', 'big', item[0]), item[1] ? el('div', 'sm', item[1]) : null);
    box.appendChild(bn);
    setTimeout(function () { bn.classList.add('out'); setTimeout(nextBanner, 480); }, item[3] || 2500);
  }
  H.coinFly = function (fromX, fromY, n) {
    var chip = $('coins').getBoundingClientRect(), fx = $('fxdom');
    n = Math.min(12, n || 6);
    for (var i = 0; i < n; i++) {
      (function (k) {
        var c = el('div', 'coinfly', '🪙');
        c.style.transform = 'translate(' + (fromX + (Math.random() - 0.5) * 60) + 'px,' + (fromY + (Math.random() - 0.5) * 40) + 'px)';
        fx.appendChild(c);
        setTimeout(function () { c.style.transform = 'translate(' + (chip.left + 8) + 'px,' + (chip.top + 6) + 'px) scale(.7)'; c.style.opacity = '0.3'; }, 30 + k * 60);
        setTimeout(function () { if (c.parentNode) c.parentNode.removeChild(c); if (k === 0) R3.sfx.play('coin'); }, 820 + k * 60);
      })(i);
    }
  };

  /* ---------------------------------------------------------- غنیمت‌ها */
  H.loot = function (rewards) {
    var box = $('loot'); box.textContent = '';
    if (!rewards || !rewards.length) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden');
    rewards.slice(0, 3).forEach(function (r) {
      var b = el('button', 'loot-btn');
      kids(b, el('span', null, '🎁'), el('span', null, 'غنیمت ' + (r.khan || '')), el('small', null, '🪙' + R3.num(r.reward)));
      tap(b, function () { G().claimRaid(r, b); });
      box.appendChild(b);
    });
  };

  /* ---------------------------------------------------------- پنجره‌ها */
  var stack = [];
  H.modalCount = function () { return stack.length + (chestStage ? 1 : 0); };
  function notifyModal() { if (G()) G().modalChanged(H.modalCount() > 0); }
  H.open = function (id, title, build, opts) {
    opts = opts || {};
    H.close(id, true);
    var wrap = el('div', 'mwrap' + (opts.center ? ' center' : '') + (opts.clear ? ' clear' : ''));
    var sheet = el('div', 'sheet'), head = el('div', 'sh-head'), body = el('div', 'sh-body');
    if (opts.maxH) sheet.style.maxHeight = opts.maxH;
    var x = el('button', 'sh-x'); x.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" fill="none"/></svg>'; x.setAttribute('aria-label', 'بستن');
    kids(head, el('h2', null, title), x);
    kids(sheet, head, body); wrap.appendChild(sheet);
    var m = { id: id, wrap: wrap, body: body, sheet: sheet, onClose: opts.onClose, rebuild: null };
    m.rebuild = function () { body.textContent = ''; build(body, m); };
    tap(x, function () { H.close(id); });
    // The world opens on pointerup. Its trailing compatibility click can hit
    // this new backdrop: dismiss only if a NEW gesture began on the backdrop.
    var backdropPressed = false;
    wrap.addEventListener('pointerdown', function (e) { backdropPressed = e.target === wrap; });
    wrap.addEventListener('pointercancel', function () { backdropPressed = false; });
    wrap.addEventListener('click', function (e) {
      var dismiss = e.target === wrap && backdropPressed;
      backdropPressed = false;
      if (dismiss) { R3.sfx.play('tap'); H.close(id); }
    });
    sheet.addEventListener('click', function (e) { e.stopPropagation(); });
    m.rebuild();
    $('modals').appendChild(wrap);
    stack.push(m);
    notifyModal();
    return m;
  };
  H.find = function (id) { for (var i = 0; i < stack.length; i++) if (stack[i].id === id) return stack[i]; return null; };
  H.close = function (id, silent) {
    for (var i = stack.length - 1; i >= 0; i--) {
      var m = stack[i];
      if (id && m.id !== id) continue;
      stack.splice(i, 1);
      m.wrap.classList.add('out');
      (function (w) { setTimeout(function () { if (w.parentNode) w.parentNode.removeChild(w); }, 230); })(m.wrap);
      if (m.onClose) try { m.onClose(); } catch (e) { }
      if (!id) break;
    }
    if (!silent) notifyModal();
  };
  H.closeTop = function () {
    if (chestStage) { if (chestStage.revealed || chestStage.failed) H.chestClose(); return true; }
    if (!stack.length) return false;
    H.close(stack[stack.length - 1].id); return true;
  };
  H.refresh = function (id) { var m = H.find(id); if (m) m.rebuild(); };
  function btn(text, cls, fn) { var b = el('button', 'btn ' + (cls || ''), text); tap(b, fn); return b; }
  function bar(p, color) { var q = el('div', 'qbar'), i = el('i'); i.style.width = (R3.clamp(p, 0, 1) * 100).toFixed(1) + '%'; if (color) i.style.background = color; q.appendChild(i); return q; }
  H.btn = btn;

  /* ---------- مأموریت‌ها */
  H.openQuests = function () {
    H.open('quests', '📜 مأموریت‌های امروز', function (body) {
      var r3 = G().r3(); if (!r3) { body.appendChild(el('p', 'sh-note', 'اطلاعات بازی هنوز نرسیده است.')); return; }
      body.appendChild(el('p', 'sh-note', 'هر روز سه مأموریت تازه داری که فقط با تمرکز واقعی پیش می‌روند. نیمه‌شب نو می‌شوند.'));
      r3.quests.list.forEach(function (q) {
        var c = el('div', 'card quest' + (q.done ? ' done' : '') + (q.claimed ? ' claimed' : ''));
        var prog = q.unit === 'sec'
          ? R3.fa(Math.floor(q.progress / 60)) + ' از ' + R3.fa(Math.floor(q.goal / 60)) + ' دقیقه'
          : R3.num(q.progress) + ' از ' + R3.num(q.goal);
        var qm = kids(el('div', 'qm'), el('div', 'qt', R3.fa(q.title)), bar(q.progress / Math.max(1, q.goal)), el('div', 'qp', prog));
        var act;
        if (q.claimed) act = el('b', null, '✅');
        else if (q.done) act = btn('🪙' + R3.num(q.reward), 'gold small', function () { G().claimQuest(q.key, act); });
        else act = el('b', 'qp', '🪙' + R3.num(q.reward));
        kids(c, el('div', 'qe', q.emoji), qm, act);
        body.appendChild(c);
      });
      var bo = r3.quests.bonus, bc = el('div', 'card bonus quest' + (bo.claimed ? ' claimed' : ''));
      var ba;
      if (bo.claimed) ba = el('b', null, '✅');
      else if (bo.ready) ba = btn('دریافت', 'gold small', function () { G().claimQuest('bonus', ba); });
      else ba = el('b', 'qp', '🔒');
      kids(bc, el('div', 'qe', '🏅'), kids(el('div', 'qm'), el('div', 'qt', 'جایزهٔ هر سه مأموریت'), el('div', 'qp', '🪙' + R3.num(bo.reward) + ' + ' + H.RARITY[bo.chest || 'rare'].fa)), ba);
      body.appendChild(bc);
    });
  };

  /* ---------- صندوق‌ها */
  H.openChests = function () {
    H.open('chests', '🎁 صندوق‌های من', function (body) {
      var r3 = G().r3(); if (!r3) { body.appendChild(el('p', 'sh-note', 'اطلاعات بازی هنوز نرسیده است.')); return; }
      var me = r3.me, row = el('div', 'chests');
      ['common', 'rare', 'epic'].forEach(function (r) {
        var n = me.chests[r] || 0, c = el('div', 'chestc ' + r + (n ? '' : ' zero'));
        kids(c, el('div', 'ce', H.RARITY[r].e), el('div', 'cn', R3.fa(n)), el('div', 'cl', H.RARITY[r].fa));
        var b = btn('باز کن', 'small' + (r === 'epic' ? ' gold' : (r === 'rare' ? ' sky' : '')), function () { H.close('chests'); G().openChest(r); });
        if (!n) b.disabled = true;
        c.appendChild(b); row.appendChild(c);
      });
      body.appendChild(row);
      var nc = G().nextChestLeft();
      if (me.next_chest_sec > 0) {
        var card = el('div', 'card');
        kids(card, el('div', 'nextchest', '⏳ ' + R3.dur(nc) + ' تمرکز تا صندوق بعدی'), bar(1 - nc / Math.max(1, me.chest_sec), 'linear-gradient(90deg,#FDE68A,#F59E0B)'));
        body.appendChild(card);
      } else body.appendChild(el('div', 'nextchest', '🌙 سقف صندوق‌های امروز پر شد؛ فردا دوباره!'));
      body.appendChild(el('p', 'sh-note', 'هر ۲۵ دقیقه تمرکز = یک صندوق. هر چه کمبوی تو بالاتر باشد، شانس صندوق آبی و حماسی بیشتر است. داخل صندوق‌ها سکه یا کلاه است و هیچ خرید یا پول واقعی‌ای در کار نیست.'));
    });
  };
  var chestStage = null;
  H.chestStageStart = function (rarity, onTap) {
    H.chestClose(true);
    var st = el('div'); st.id = 'chest-stage';
    var note = el('div', 'tapnote', 'ضربه بزن تا باز شود! 👆');
    st.appendChild(note);
    st.addEventListener('click', function () { onTap(); });
    document.getElementById('app').appendChild(st);
    chestStage = { el: st, note: note, revealed: false, failed: false };
    document.body.classList.add('chesting');
    notifyModal();
    return chestStage;
  };
  H.chestReveal = function (chest, more, onNext, onWear) {
    if (!chestStage) return;
    chestStage.revealed = true;
    var r = chest.rarity || 'common', card = el('div', 'reveal ' + r);
    var isHat = chest.kind === 'hat';
    kids(card, el('div', 'rv-e', isHat ? chest.emoji || '🎩' : '🪙'),
      el('div', 'rv-t', isHat ? chest.title : '+' + R3.num(chest.value) + ' سکه'),
      el('div', 'rv-s', isHat ? 'کلاه تازه! حالا مال توست' : H.RARITY[r].fa));
    var acts = el('div', 'acts');
    if (isHat) acts.appendChild(btn('🎩 بپوش', 'gold', function () { onWear(chest.item); }));
    if (more > 0) acts.appendChild(btn('بعدی (' + R3.fa(more) + ')', 'sky', onNext));
    acts.appendChild(btn('بستن', 'ghost', function () { H.chestClose(); }));
    card.appendChild(acts);
    chestStage.note.textContent = '';
    chestStage.el.insertBefore(card, chestStage.note);
  };
  H.chestFail = function () { if (chestStage) { chestStage.failed = true; H.chestClose(); } };
  H.chestClose = function (silent) {
    if (!chestStage) return;
    var st = chestStage.el; chestStage = null;
    document.body.classList.remove('chesting');
    st.classList.add('out'); setTimeout(function () { if (st.parentNode) st.parentNode.removeChild(st); }, 300);
    R3.world.chestHide();
    if (!silent) notifyModal();
  };
  H.chestOpenNow = function () { return chestStage; };

  /* ---------- کمد کلاه‌ها */
  H.openWardrobe = function () {
    var sel = null;
    R3.world.focusMe(true);
    var m = H.open('hats', '🎩 کمد کلاه', function (body, mm) {
      var r3 = G().r3(), cat = G().catalog();
      if (!r3 || !cat) { body.appendChild(el('p', 'sh-note', 'اطلاعات کلاه‌ها هنوز نرسیده است.')); return; }
      var owned = {}, cur = r3.me.hat || '', coins = G().coins();
      r3.me.hats.forEach(function (h) { owned[h] = true; });
      if (sel === null) sel = cur;
      var grid = el('div', 'hats');
      var items = [{ key: '', title: 'بدون کلاه', emoji: '🙂', cost: 0 }].concat(cat);
      items.forEach(function (h) {
        var own = h.key === '' || owned[h.key], on = h.key === cur;
        var c = el('button', 'hat' + (on ? ' on' : '') + (!own && !h.cost ? ' lock' : ''));
        if (h.key === sel) c.style.outline = '3px solid var(--purple)';
        var st = on ? 'پوشیده' : (own ? 'داری ✅' : (h.cost ? '🪙' + R3.num(h.cost) : (h.boss ? '🔒 خان ' + R3.fa(h.boss) : '🔒 صندوق حماسی')));
        kids(c, el('div', 'he', h.emoji), el('div', 'ht', h.title), el('div', 'hp2', st));
        if (h.boss && !own) c.appendChild(el('span', 'tagx', 'جایزهٔ خان'));
        else if (!h.cost && h.chest && !own) c.appendChild(el('span', 'tagx', 'کمیاب'));
        tap(c, function () { sel = h.key; R3.world.previewHat(h.key); mm.rebuild(); });
        grid.appendChild(c);
      });
      body.appendChild(grid);
      var h = null; items.forEach(function (x) { if (x.key === sel) h = x; });
      var foot = el('div', 'row'); foot.style.marginTop = '12px';
      if (h) {
        var own2 = h.key === '' || owned[h.key];
        if (h.key === cur) foot.appendChild(el('div', 'sh-note', h.key ? 'این کلاه روی سرت است.' : 'الان کلاهی نداری.'));
        else if (own2) foot.appendChild(btn(h.key ? '🎩 بپوش' : 'درآوردن کلاه', 'wide', function (e) { G().setHat(h.key, e.currentTarget); }));
        else if (h.cost) {
          var b = btn('خرید با 🪙' + R3.num(h.cost), 'gold wide', function (e) { G().buyHat(h, e.currentTarget); });
          if (coins < h.cost) { b.disabled = true; b.textContent = 'سکهٔ کافی نداری (🪙' + R3.num(h.cost) + ')'; }
          foot.appendChild(b);
        } else foot.appendChild(el('div', 'sh-note', h.boss ? 'فقط با شکست ' + (G().bossTitle(h.boss) || 'خان آخر') + ' به دست می‌آید.' : 'فقط از صندوق حماسی می‌افتد.'));
      }
      body.appendChild(foot);
      body.appendChild(el('p', 'sh-note', 'کلاه‌ها فقط ظاهری‌اند و قدرتی اضافه نمی‌کنند؛ بازی منصفانه می‌ماند.'));
    }, { maxH: '46%', clear: true, onClose: function () { R3.world.focusMe(false); R3.world.previewHat(null); } });
    return m;
  };

  /* ---------- نبرد */
  H.openBattle = function () {
    H.open('battle', '⚔️ هفت‌خان', function (body) {
      var r3 = G().r3();
      if (!r3) { body.appendChild(el('p', 'sh-note', 'نبرد گروهی روی سرور فعال نیست.')); return; }
      var raid = r3.raid, khans = el('div', 'khans'), list = G().bosses();
      for (var s = 1; s <= 7; s++) {
        var k = el('div', 'khan' + (s < raid.stage ? ' done' : (s === raid.stage ? ' now' : ' next')));
        kids(k, el('div', 'kd', s < raid.stage ? '✅' : H.KHAN_EMOJI[s - 1]), el('div', null, list[s - 1] ? list[s - 1].title : 'خان ' + R3.fa(s)));
        khans.appendChild(k);
      }
      body.appendChild(khans);
      var dmg = G().shownDamage(), max = Math.max(1, raid.hp_max);
      var cur = el('div', 'card');
      kids(cur, kids(el('div', 'row'), el('b', null, raid.emoji + ' ' + raid.title), el('span', 'qp', raid.khan + (raid.cycle > 1 ? ' · دور ' + R3.fa(raid.cycle) : ''))),
        bar(1 - dmg / max, 'linear-gradient(90deg,#ff7b7b,#e53935)'),
        el('div', 'qp', '❤️ ' + R3.num(max - dmg) + ' از ' + R3.num(max) + (raid.fighters ? ' · ⚔️ ' + R3.fa(raid.fighters) + ' نفر در حال نبرد' : '')));
      body.appendChild(cur);
      var s2 = el('div', 'stat2');
      kids(s2, kids(el('div', 'card'), el('b', null, R3.num(raid.my_damage)), el('span', null, 'ضربهٔ تو به این خان')),
        kids(el('div', 'card'), el('b', null, R3.num(r3.me.damage_today)), el('span', null, 'ضربهٔ امروزت')));
      body.appendChild(s2);
      var top = el('div', 'card');
      top.appendChild(el('b', null, '🏆 قهرمان‌های این خان'));
      if (!raid.top.length) top.appendChild(el('div', 'qp', 'هنوز کسی ضربه نزده؛ اولین نفر باش!'));
      raid.top.forEach(function (t, i) {
        var r = el('div', 'toprow' + (t.is_me ? ' me' : ''));
        kids(r, el('span', 'rk', ['🥇', '🥈', '🥉'][i] || R3.fa(i + 1)), el('span', null, R3.world.SPECIES_EMOJI[t.character] || '🐾'),
          el('span', 'nm', t.is_me ? 'تو' : t.username), el('span', 'dm', R3.num(t.damage)));
        top.appendChild(r);
      });
      body.appendChild(top);
      if (r3.last_defeat) {
        var ld = r3.last_defeat;
        body.appendChild(kids(el('div', 'card'), el('div', 'qp', '🎉 آخرین پیروزی: ' + ld.title + ' — ' + agoText(ld.ago) + (ld.mvp ? ' · قهرمان: ' + ld.mvp : ''))));
      }
      if (r3.rewards && r3.rewards.length) {
        r3.rewards.forEach(function (rw) {
          var c = el('div', 'card bonus quest'), b2;
          b2 = btn('🪙' + R3.num(rw.reward), 'gold small', function () { G().claimRaid(rw, b2); });
          kids(c, el('div', 'qe', '🎁'), kids(el('div', 'qm'), el('div', 'qt', 'غنیمت ' + rw.title + (rw.mvp ? ' (قهرمان!)' : '')), el('div', 'qp', 'ضربهٔ تو: ' + R3.num(rw.damage) + (rw.unlock ? ' · کلاه ویژه' : ''))), b2);
          body.appendChild(c);
        });
      }
      body.appendChild(el('p', 'sh-note', 'هر ثانیه تمرکز یک ضربه است و کمبو ضریبش را تا ×۴ بالا می‌برد. وقتی خان شکست بخورد، هر کس دست‌کم ۵ دقیقه جنگیده باشد غنیمت می‌گیرد و بیشترین ضربه، جایزهٔ قهرمان. بعد از هفت خان، دور تازه با خان‌های قوی‌تر شروع می‌شود.'));
      body.appendChild(btn('📊 جدول رکورد امروز', 'ghost wide', function () { G().native('top'); }));
    });
  };
  function agoText(sec) {
    if (sec < 90) return 'همین الان';
    if (sec < 3600) return R3.fa(Math.round(sec / 60)) + ' دقیقه پیش';
    if (sec < 86400) return R3.fa(Math.round(sec / 3600)) + ' ساعت پیش';
    return R3.fa(Math.round(sec / 86400)) + ' روز پیش';
  }

  /* ---------- هم‌اتاقی */
  H.openPerson = function (p) {
    H.open('who', p.name || 'هم‌اتاقی', function (body) {
      var who = el('div', 'who');
      var st = p.state === 'studying' ? '📖 در حال مطالعه' : (p.state === 'sleeping' ? '💤 چرت' : '🙂 آماده');
      kids(who, el('div', 'av', R3.world.SPECIES_EMOJI[p.kind] || '🐾'),
        kids(el('div'), el('div', 'nm', p.name), el('div', 'sub', st + ' · امروز ' + R3.fa(p.minutes || 0) + ' دقیقه'),
          p.state === 'studying' && p.combo > 0 ? el('div', 'sub', H.TIER_FLAME[p.combo] + ' ' + H.TIER_NAME[p.combo] + ' ' + R3.mult(R3.world.MULT[p.combo])) : null));
      body.appendChild(who);
      body.appendChild(el('div', 'sh-note', 'یک تشویق بفرست تا انرژی بگیرد:'));
      var row = el('div', 'cheers');
      ['👏', '☕', '💪', '❤️', '⭐'].forEach(function (e) {
        var b = el('button', null, e); b.setAttribute('aria-label', 'تشویق ' + e);
        tap(b, function () { G().cheer(p, e); H.close('who'); });
        row.appendChild(b);
      });
      body.appendChild(row);
    }, { center: true });
  };

  /* ---------- منو */
  H.openMenu = function () {
    H.open('menu', '⚙️ تنظیمات اتاق', function (body, m) {
      var s = R3.settings, grid = el('div', 'menu');
      [['🐾 شخصیت', 'char'], ['🎨 تم اتاق', 'theme'], ['🎵 صدای محیط', 'sound'], ['🛍️ فروشگاه', 'shop'], ['👥 هم‌اتاقی‌ها', 'roster'], ['🎯 هدف روزانه', 'goal'], ['📊 رکوردها', 'top'], ['❓ راهنما', 'help']].forEach(function (it) {
        grid.appendChild(btn(it[0], 'ghost small', function () { if (it[1] === 'help') { H.close('menu'); H.openHelp(); } else { H.close('menu'); G().native(it[1]); } }));
      });
      body.appendChild(grid);
      var card = el('div', 'card'); card.style.marginTop = '10px';
      function toggle(label, on, fn) {
        var r = el('div', 'toggle'), sw = el('button', 'sw' + (on ? ' on' : ''));
        sw.setAttribute('role', 'switch'); sw.setAttribute('aria-checked', on ? 'true' : 'false'); sw.setAttribute('aria-label', label);
        tap(sw, function () { fn(!on); m.rebuild(); });
        kids(r, el('span', null, label), sw); card.appendChild(r);
      }
      toggle('🔊 صدای بازی', s.sound, function (v) { G().setSetting('sound', v); });
      toggle('📳 لرزش', s.haptic, function (v) { G().setSetting('haptic', v); });
      toggle('🌙 حالت شب', G().night(), function (v) { G().setNight(v); });
      toggle('🧘 حالت آرام (حرکت و لرزش کمتر)', s.calm, function (v) { G().setSetting('calm', v); });
      toggle('🔠 متن بزرگ‌تر', s.large, function (v) { G().setSetting('large', v); });
      toggle('🔋 کم‌نور و کم‌مصرف هنگام تمرکز', s.dim, function (v) { G().setSetting('dim', v); });
      var qr = el('div', 'toggle'), seg = el('div', 'seg');
      [['auto', 'خودکار'], [0, 'کم'], [1, 'متوسط'], [2, 'زیاد']].forEach(function (o) {
        var b = el('button', String(s.quality) === String(o[0]) ? 'on' : '', o[1]);
        tap(b, function () { G().setSetting('quality', o[0]); m.rebuild(); });
        seg.appendChild(b);
      });
      kids(qr, el('span', null, '✨ کیفیت گرافیک'), seg); card.appendChild(qr);
      body.appendChild(card);
      body.appendChild(btn('🏫 رفتن به اتاق کلاسیک (دوبعدی)', 'ghost wide', function () { G().native('classic'); }));
    });
  };

  /* ---------- راهنما */
  H.openHelp = function (first) {
    H.open('help', first ? '⚔️ به هفت‌خانِ تمرکز خوش آمدی!' : '❓ راهنمای بازی', function (body) {
      var ul = el('ul', 'help');
      [
        '🎯 دکمهٔ بزرگ پایین را بزن و درس بخوان. هر ثانیه تمرکز یک گوی انرژی است که به خان می‌خورد.',
        '🔥 تمرکز پیوسته کمبو می‌سازد: ۱۰ دقیقه ×۱٫۵، ۲۵ دقیقه ×۲، ۵۰ دقیقه ×۳ و ۹۰ دقیقه «خشم رستم» ×۴. استراحت پومودورو کمبو را نمی‌شکند.',
        '🎁 هر ۲۵ دقیقه تمرکز یک صندوق می‌گیری: سکه یا کلاه.',
        '📜 هر روز سه مأموریت داری؛ هر سه را تمام کنی جایزهٔ ویژه می‌گیری.',
        '🤝 همهٔ هم‌اتاقی‌ها با هم با هفت خانِ رستم می‌جنگند. خان که بیفتد، همه غنیمت می‌برند.',
        '👆 روی هم‌اتاقی‌ها بزن و تشویقشان کن. روی خودت بزنی، کمد کلاه باز می‌شود.',
        '✅ آخر کار «ثبت» را بزن تا دقیقه‌ها در گزارشت ذخیره شود.',
        '🔋 هنگام تمرکز اگر به صفحه دست نزنی، اتاق کم‌نور و کم‌مصرف می‌شود.',
        '🛡️ بازی منصفانه است: جایزه فقط با مطالعهٔ واقعی می‌آید و هیچ خرید با پول واقعی یا قمار در کار نیست.'
      ].forEach(function (t) { ul.appendChild(el('li', null, t)); });
      body.appendChild(ul);
      body.appendChild(btn(first ? 'بزن بریم! ⚔️' : 'فهمیدم', 'wide', function () { H.close('help'); }));
    }, { onClose: function () { if (first) R3.store.set('onboarded', 1); } });
  };

  H.confirm = function (text, yes, onYes, note) {
    H.open('confirm', text, function (body) {
      if (note) { var n = el('div', 'sub', note); n.style.textAlign = 'center'; n.style.margin = '0 0 10px'; body.appendChild(n); }
      var r = el('div', 'row'); r.style.justifyContent = 'center';
      kids(r, btn(yes, 'coral', function () { H.close('confirm'); onYes(); }), btn('نه', 'ghost', function () { H.close('confirm'); }));
      body.appendChild(r);
    }, { center: true });
  };

  /* ---------------------------------------------------------- اتصال دکمه‌ها */
  H.init = function () {
    window.addEventListener('resize', H.layout);
    H.layout();
    tap($('btn-menu'), function () { H.openMenu(); });
    tap($('btn-quest'), function () { H.openQuests(); });
    tap($('btn-chest'), function () { H.openChests(); });
    tap($('btn-hat'), function () { H.openWardrobe(); });
    tap($('btn-battle'), function () { H.openBattle(); });
    tap($('online'), function () { G().native('roster'); });
    tap($('lvl'), function () { G().native('shop'); });
    tap($('btn-mode'), function () { G().toggleMode(); });
    tap($('btn-skip'), function () { G().skip(); });
    tap($('btn-log'), function () { G().logStudy(); });
    var f = $('focus'), lp = 0, long = false;
    f.addEventListener('pointerdown', function () { long = false; clearTimeout(lp); lp = setTimeout(function () { long = true; R3.haptic('heavy'); G().askReset(); }, 750); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) { f.addEventListener(ev, function () { clearTimeout(lp); }); });
    f.addEventListener('click', function (e) { e.stopPropagation(); if (long) return; G().focusToggle(); });
  };
})();
