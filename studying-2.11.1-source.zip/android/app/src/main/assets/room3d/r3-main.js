/* هفت‌خانِ تمرکز — مغز بازی: پیام‌های اپ را می‌گیرد، پیش‌بینی جان خان و کمبو،
   جشن‌ها، و فرمان‌ها را به اپ می‌فرستد. */
(function () {
  'use strict';
  var R3 = window.R3, W = R3.world, H = R3.hud, B = R3.bridge;
  var GAP = 180, REST_GAP = 1800;

  R3.settings = (function () {
    var d = { sound: true, haptic: true, quality: 'auto', calm: false, large: false, dim: true };
    var s = R3.store.get('settings', {}) || {};
    Object.keys(d).forEach(function (k) { if (s[k] === undefined) s[k] = d[k]; });
    return s;
  })();

  var S = R3.S = {
    me: null, room: {}, others: [], r3: null, server: null, timer: null, catalog: null, bosses: null,
    mode: R3.store.get('mode', 'pomo'), studying: false, resting: false,
    run: { live: 0, gapUsed: 0, tier: 0 }, chestLeft: 0,
    hp: { id: 0, max: 1, server: 0, pred: 0 }, raidId: null, defeating: false,
    evLast: -1, snapSeq: -1, prevLevel: null, prevChests: null, questsDone: null, rewardIds: null,
    booted: false, ready: false, idleT: 0, hudT: 0, lastTimer: null, cheerAt: {}, firstState: true
  };

  /* ================================================================ تنظیمات */
  function applySettings() {
    var s = R3.settings;
    R3.sfx.enabled = !!s.sound;
    document.body.classList.toggle('calm', !!s.calm);
    document.body.classList.toggle('large', !!s.large);
    if (W.ready) {
      W.setCalm(!!s.calm);
      W.setAutoQuality(s.quality === 'auto');
      if (s.quality !== 'auto') W.setQuality(+s.quality);
    }
  }

  /* ================================================================ بازی برای HUD */
  var game = R3.game = {
    r3: function () { return S.r3; },
    catalog: function () { return S.catalog; },
    bosses: function () { return S.bosses || []; },
    coins: function () { return S.me ? S.me.coins || 0 : 0; },
    night: function () { return !!S.room.night; },
    bossTitle: function (stage) { var b = (S.bosses || [])[stage - 1]; return b ? b.title : ''; },
    shownDamage: function () { return Math.round(S.hp.pred); },
    nextChestLeft: function () { return Math.max(0, Math.round(S.chestLeft)); },
    modalChanged: function (open) { B.send('modal', { open: !!open }); if (open) wake(); },
    native: function (sheet) { B.send('open', { sheet: sheet }); },
    setSetting: function (k, v) { R3.settings[k] = v; R3.store.set('settings', R3.settings); applySettings(); if (k === 'dim' && !v) setAmbient(false); },
    setNight: function (v) { B.send('night', { on: !!v }); S.room.night = !!v; if (W.ready) W.setEnv(S.room.theme || 'library', !!v); },
    toggleMode: function () {
      var tm = S.timer;
      if (tm && (tm.running || tm.chrono_running || (tm.phase !== 'idle' && S.mode === 'pomo') || (tm.chrono_sec > 0 && S.mode === 'chrono'))) {
        H.toast('اول تایمر فعلی را تمام یا صفر کن', 'err'); R3.sfx.play('error'); return;
      }
      S.mode = S.mode === 'pomo' ? 'chrono' : 'pomo';
      R3.store.set('mode', S.mode);
      if (S.timer) S.timer.mode = S.mode;
      H.focus(S.timer, S.studying, S.resting);
      H.toast(S.mode === 'pomo' ? '⏱️ پومودورو: ۲۵ دقیقه تمرکز، بعد استراحت' : '⏲️ کرنومتر: هر قدر خواستی تمرکز کن', 'gold', 2600);
    },
    skip: function () { B.send('timer_skip', {}); },
    logStudy: function () { B.send('log', {}); },
    askReset: function () {
      H.confirm('تایمر صفر شود؟', 'صفر کن', function () { B.send('timer_reset', { mode: S.mode }); R3.sfx.play('pause'); },
        'زمانِ ثبت‌نشدهٔ این تایمر پاک می‌شود؛ برای نگه داشتنش اول «✅ ثبت مطالعه» را بزن.');
    },
    focusToggle: function () {
      R3.sfx.unlock();
      var tm = S.timer;
      var running = tm && (S.mode === 'chrono' ? tm.chrono_running : tm.running);
      R3.sfx.play(running ? 'pause' : 'start');
      R3.haptic(running ? 'light' : 'medium');
      B.send('focus_toggle', { mode: S.mode });
      if (!running && !S.startedOnce) {
        S.startedOnce = true;
        if (S.r3) H.toast('🔥 تمرکز شروع شد؛ گوی‌های انرژی به سمت خان می‌روند!', 'gold');
      }
    },
    cheer: function (p, emoji) {
      var now = Date.now(), last = S.cheerAt[p.id] || 0;
      if (now - last < 15000) { H.toast('کمی صبر کن؛ تشویق قبلی تازه رسیده 🙂', 'err'); return; }
      S.cheerAt[p.id] = now;
      B.send('cheer', { user_id: +p.id, emoji: emoji });
      W.floatEmoji(W.headPos(p.id), emoji, 3);
      W.burstAt(p.id, 0xFDE68A, 24);
      W.celebrate(p.id);
      R3.sfx.play('cheer'); R3.haptic('light');
      H.toast(emoji + ' تشویقت برای ' + (p.name || 'هم‌اتاقی') + ' رفت', 'cheer', 2600);
    },
    claimQuest: function (key, btnEl) {
      if (btnEl) btnEl.disabled = true;
      B.request('claim', { kind: 'quest', key: key }, function (res) {
        if (!res.ok) { if (btnEl) btnEl.disabled = false; fail(res); return; }
        var c = (res.data && res.data.claim) || {};
        adopt(res);
        var r = btnEl ? btnEl.getBoundingClientRect() : { left: 200, top: 300, width: 0, height: 0 };
        H.coinFly(r.left + r.width / 2, r.top + r.height / 2, 7);
        R3.sfx.play('levelup');
        H.toast('🪙 +' + R3.num(c.coins || 0) + ' سکه' + (c.chest ? ' و یک ' + H.RARITY[c.chest].fa + '!' : ''), 'gold');
        if (c.chest) { W.chestDrop(c.chest); W.confetti(); }
        H.refresh('quests');
      });
    },
    claimRaid: function (rw, btnEl) {
      if (btnEl) btnEl.disabled = true;
      B.request('claim', { kind: 'raid', raid_id: rw.raid_id }, function (res) {
        if (!res.ok) { if (btnEl) btnEl.disabled = false; fail(res); return; }
        var c = (res.data && res.data.claim) || {};
        adopt(res);
        var r = btnEl ? btnEl.getBoundingClientRect() : { left: 300, top: 150, width: 0, height: 0 };
        H.coinFly(r.left + r.width / 2, r.top + r.height / 2, 10);
        R3.sfx.play('victory');
        W.confetti(true);
        H.banner('🎁 +' + R3.num(c.coins || rw.reward) + ' سکه', c.mvp ? '👑 جایزهٔ قهرمانِ نبرد هم مال تو شد!' : 'غنیمت ' + (rw.title || 'خان'), 'boss');
        if (c.unlock) H.banner('👹 کلاه‌خود دیو سپید آزاد شد!', 'از کمد بپوشش', 'epic', 3000);
        H.refresh('battle');
      });
    },
    openChest: function (rarity) {
      if (!S.r3 || !(S.r3.me.chests[rarity] > 0)) { H.toast('صندوقی از این نوع نداری', 'err'); return; }
      var st = { taps: 0, result: null, done: false, rarity: rarity };
      W.chestShow(rarity);
      H.chestStageStart(rarity, function () {
        if (st.done) return;
        st.taps++;
        if (st.taps < 3) { W.chestShake(); return; }
        tryOpen();
      });
      function tryOpen() {
        if (st.done) return;
        if (!st.result) { W.chestShake(); st.waiting = true; return; }
        st.done = true;
        if (!st.result.ok) { H.chestFail(); fail(st.result); return; }
        var chest = (st.result.data && st.result.data.chest) || { rarity: rarity, kind: 'coins', value: 0 };
        W.chestOpen();
        setTimeout(function () {
          var left = S.r3 ? S.r3.me.chest_total : 0;
          H.chestReveal(chest, left, function () {
            var next = S.r3 && ['epic', 'rare', 'common'].filter(function (r) { return S.r3.me.chests[r] > 0; })[0];
            H.chestClose(true);
            if (next) setTimeout(function () { game.openChest(next); }, 120); else H.chestClose();
          }, function (hat) { H.chestClose(); game.setHat(hat); });
          if (chest.kind === 'coins') H.coinFly(window.innerWidth / 2, window.innerHeight * 0.45, Math.min(12, 3 + Math.round(chest.value / 10)));
          if (chest.kind === 'hat') { R3.sfx.play('levelup'); W.confetti(true); }
        }, 520);
      }
      B.request('chest_open', { rarity: rarity }, function (res) { st.result = res; if (res.ok) adopt(res); if (st.waiting) tryOpen(); });
    },
    setHat: function (key, btnEl) {
      if (btnEl) btnEl.disabled = true;
      B.request('hat', { hat: key }, function (res) {
        if (btnEl) btnEl.disabled = false;
        if (!res.ok) { fail(res); return; }
        adopt(res);
        if (S.r3) S.r3.me.hat = key;
        if (S.me) S.me.hat = key;
        W.previewHat(null);
        syncWorld();
        W.sparkleAtMe(0xC4B5FD, 26); W.celebrate('me');
        R3.sfx.play('coin');
        H.toast(key ? '🎩 کلاه تازه روی سرت!' : 'کلاه برداشته شد', 'epic', 2200);
        H.refresh('hats');
      });
    },
    buyHat: function (h, btnEl) {
      H.confirm('«' + h.title + '» را با ' + R3.num(h.cost) + ' سکه می‌خری؟', 'بخر', function () {
        if (btnEl) btnEl.disabled = true;
        B.request('buy', { item: h.key, cost: h.cost, equip: 1 }, function (res) {
          if (btnEl) btnEl.disabled = false;
          if (!res.ok) { fail(res); return; }
          adopt(res);
          if (S.r3) { if (S.r3.me.hats.indexOf(h.key) < 0) S.r3.me.hats.push(h.key); S.r3.me.hat = h.key; }
          W.previewHat(null); syncWorld();
          W.sparkleAtMe(0xFFD54F, 40); W.celebrate('me'); W.confetti();
          R3.sfx.play('levelup');
          H.banner('🎩 ' + h.title, 'مال خودت شد!', 'epic', 2400);
          H.refresh('hats');
        });
      });
    }
  };
  /** پاسخ موفق سرور معمولاً وضعیت تازهٔ بازی را هم دارد؛ همان را بی‌صدا جذب می‌کنیم
      تا شمارش صندوق‌ها و سکه‌ها فوراً درست شود و جشنِ تکراری پخش نشود. */
  function adopt(res) {
    var d = res && res.data;
    if (d && d.r3 && typeof d.r3 === 'object' && d.r3.raid && d.r3.me) {
      S.suppressDrop = true;
      try { onR3(d.r3); } finally { S.suppressDrop = false; }
    }
    if (d && typeof d.coins === 'number' && S.me) { S.me.coins = d.coins; H.top(S.me); }
  }
  function fail(res) {
    R3.sfx.play('error');
    H.toast('⚠️ ' + (res && res.error ? res.error : 'کار انجام نشد'), 'err');
  }

  /* ================================================================ همگام‌سازی صحنه */
  function tierOf(sec) { var t = 0; for (var i = 1; i < H.TIER_AT.length; i++) if (sec >= H.TIER_AT[i]) t = i; return t; }
  function syncWorld() {
    if (!W.ready || !S.me) return;
    var list = [{
      id: 'me', me: true, name: S.me.username, kind: S.me.character || 'cat', hat: (S.r3 && S.r3.me.hat) || '',
      state: S.studying ? 'studying' : 'idle', combo: S.studying ? S.run.tier : 0, rest: S.resting, minutes: S.me.today_minutes || 0, desk: S.me.desk || {}
    }];
    (S.others || []).slice(0, 11).forEach(function (o) {
      list.push({ id: String(o.user_id), name: o.username, kind: o.character || 'cat', hat: o.hat || '', state: o.state || 'idle', combo: o.combo || 0, rest: false, minutes: o.minutes_today || 0 });
    });
    W.syncPeople(list);
  }

  /* ================================================================ پیام‌های اپ */
  var queue = [];
  R3.push = function (msg) {
    try {
      if (typeof msg === 'string') msg = JSON.parse(msg);
      if (!S.ready) { queue.push(msg); return; }
      var h = handlers[msg.t];
      if (h) h(msg);
    } catch (e) { B.send('debug', { msg: 'push ' + (e && e.message) }); }
  };
  var handlers = {
    state: onState,
    timer: onTimer,
    result: function (m) { B.resolve(m); },
    toast: function (m) { H.toast(m.text || '', m.kind || ''); },
    lifecycle: function (m) {
      if (m.active) { if (W.ready) W.start(); }
      else { W.stop(); R3.sfx.suspend(); }
    },
    back: function () { if (!H.closeTop()) B.send('back_unhandled', {}); }
  };

  function onState(m) {
    var me = m.me || {}, room = m.room || {}, prevMe = S.me;
    S.me = me; S.others = m.others || []; S.server = m.server_r3;
    var themeChanged = room.theme !== S.room.theme || !!room.night !== !!S.room.night;
    S.room = room;
    if (W.ready && themeChanged) W.setEnv(room.theme || 'library', !!room.night);
    H.top(me); H.online(room.online || (S.others.length + 1));
    // سطح
    if (S.prevLevel !== null && me.level > S.prevLevel) {
      H.banner('⭐ سطح ' + R3.fa(me.level) + '!', (me.level_emoji || '') + ' ' + (me.level_title || ''), '', 3000);
      R3.sfx.play('levelup'); W.confetti(true); W.sparkleAtMe(0xFFD54F, 50); W.celebrate('me');
    }
    S.prevLevel = me.level || 1;
    // تشویق‌های رسیده
    if (m.snap_seq !== undefined && m.snap_seq !== S.snapSeq) {
      var first = S.snapSeq === -1;
      S.snapSeq = m.snap_seq;
      if (!first || (m.cheers && m.cheers.length)) (m.cheers || []).slice(0, 5).forEach(function (c, i) {
        setTimeout(function () {
          W.floatEmoji(W.headPos('me'), c.emoji || '👏', 3); W.celebrate('me');
          R3.sfx.play('cheer'); R3.haptic('light');
          H.toast((c.emoji || '👏') + ' ' + (c.from || 'یک هم‌اتاقی') + ' تشویقت کرد', 'cheer');
        }, i * 900);
      });
    }
    if (m.r3) onR3(m.r3); else if (S.r3 && m.r3 === null && m.server_r3 === false) { S.r3 = null; H.boss(null); }
    // پیام سرور
    if (room.error) H.serverNote('📡 ' + room.error);
    else if (!m.r3 && m.server_r3 === false) H.serverNote('⚔️ نبرد گروهی هنوز روی سرور فعال نشده؛ اتاق سه‌بعدی بدون خان کار می‌کند.');
    else H.serverNote(null);
    syncWorld();
    if (S.firstState) {
      S.firstState = false;
      hideSplash();
      if (!R3.store.get('onboarded', 0)) setTimeout(function () { H.openHelp(true); }, 700);
    }
  }

  function onR3(r3) {
    var prev = S.r3;
    S.r3 = r3;
    if (r3.hats_catalog) S.catalog = r3.hats_catalog;
    if (r3.bosses) S.bosses = r3.bosses;
    var me = r3.me;
    // کمبو
    if (S.studying) S.run.live = Math.max(me.run_sec, Math.min(S.run.live, me.run_sec + 45));
    else S.run.live = me.run_sec;
    if (me.run_sec > 0) S.run.gapUsed = 0;
    // صندوق
    S.chestLeft = me.next_chest_sec;
    var ch = me.chests;
    if (S.prevChests) {
      var drops = [];
      ['epic', 'rare', 'common'].forEach(function (r) { for (var i = S.prevChests[r]; i < ch[r]; i++) drops.push(r); });
      if (drops.length && !S.suppressDrop) {
        drops.slice(0, 3).forEach(function (r, i) { setTimeout(function () { W.chestDrop(r); }, i * 700); });
        H.toast('🎁 ' + (drops.length > 1 ? R3.fa(drops.length) + ' صندوق تازه گرفتی!' : H.RARITY[drops[0]].fa + ' گرفتی!'), 'gold');
      }
    }
    S.prevChests = { common: ch.common, rare: ch.rare, epic: ch.epic };
    var pileList = [];
    ['epic', 'rare', 'common'].forEach(function (r) { for (var i = 0; i < Math.min(3, ch[r]); i++) pileList.push(r); });
    W.setChestPile(pileList);
    // مأموریت‌ها
    var doneNow = {};
    r3.quests.list.forEach(function (q) { doneNow[q.key] = q.done; });
    if (S.questsDone) r3.quests.list.forEach(function (q) { if (q.done && !S.questsDone[q.key] && !q.claimed) { H.toast('📜 مأموریت انجام شد: ' + q.title, 'gold'); R3.sfx.play('combo'); } });
    S.questsDone = doneNow;
    // رویدادهای اتاق
    if (r3.events && S.evLast >= 0) r3.events.forEach(function (e) {
      if (e.id <= S.evLast || e.is_me) return;
      var u = e.user || 'یک هم‌اتاقی';
      if (e.kind === 'combo') H.toast(H.TIER_FLAME[e.value] + ' ' + u + ' به «' + H.TIER_NAME[e.value] + '» رسید', '');
      else if (e.kind === 'epic') H.toast('💎 ' + u + ' از صندوق حماسی ' + R3.num(e.value) + ' سکه گرفت', 'epic');
      else if (e.kind === 'hat') H.toast('🎩 ' + u + ' یک کلاه کمیاب پیدا کرد', 'epic');
      else if (e.kind === 'quests') H.toast('📜 ' + u + ' همهٔ مأموریت‌های امروز را تمام کرد', 'gold');
    });
    S.evLast = Math.max(S.evLast, r3.ev_last || 0);
    // خان
    var raid = r3.raid;
    if (S.raidId === null) {
      S.raidId = raid.id; S.hp = { id: raid.id, max: raid.hp_max, server: raid.damage, pred: raid.damage };
      W.setBoss(raid.key, { instant: true });
    } else if (raid.id !== S.raidId && !S.defeating) {
      bossChange(prev ? prev.raid : null, raid, r3.last_defeat);
    } else if (raid.id === S.hp.id) {
      var allowance = 60;
      if (S.studying) allowance += 60 * W.MULT[S.run.tier];
      S.others.forEach(function (o) { if (o.state === 'studying') allowance += 60 * W.MULT[o.combo || 0]; });
      S.hp.server = raid.damage; S.hp.max = raid.hp_max;
      S.hp.pred = Math.max(raid.damage, Math.min(S.hp.pred, raid.damage + allowance));
    }
    // غنیمت
    H.loot(r3.rewards);
    var ids = (r3.rewards || []).map(function (x) { return x.raid_id; }).join(',');
    S.rewardIds = ids;
    updateDock();
    if (!S.defeating) { H.boss(raid, S.hp.pred); W.bossHp(1 - S.hp.pred / Math.max(1, S.hp.max)); }
    ['quests', 'chests', 'battle'].forEach(function (id) { var md = H.find(id); if (md && id !== 'chests') md.rebuild(); });
  }

  function bossChange(old, raid, last) {
    S.defeating = true;
    var title = old ? old.title : 'خان';
    H.boss(old || raid, old ? old.hp_max : 0);
    W.bossDefeat(function () {
      var mvp = last && last.mvp ? '👑 قهرمان: ' + last.mvp : 'همه با هم!';
      H.banner('🎉 ' + title + ' شکست خورد!', mvp, 'boss', 3200);
      W.confetti(true);
      W.celebrate('me'); Object.keys(W.people).forEach(function (id) { W.celebrate(id); });
      R3.haptic('heavy');
      setTimeout(function () {
        S.defeating = false;
        S.raidId = raid.id; S.hp = { id: raid.id, max: raid.hp_max, server: raid.damage, pred: raid.damage };
        W.setBoss(raid.key);
        H.banner('⚔️ ' + raid.khan + ': ' + raid.title, 'جان: ' + R3.num(raid.hp_max) + (raid.cycle > 1 ? ' · دور ' + R3.fa(raid.cycle) : ''), 'boss', 2800);
        H.boss(raid, S.hp.pred);
        H.refresh('battle');
      }, 2600);
    });
  }

  function onTimer(tm) {
    var prev = S.lastTimer;
    if (tm.chrono_running && S.mode !== 'chrono') { S.mode = 'chrono'; R3.store.set('mode', 'chrono'); }
    else if ((tm.running || tm.phase !== 'idle') && !tm.chrono_running && !(tm.chrono_sec > 0) && S.mode !== 'pomo') { S.mode = 'pomo'; R3.store.set('mode', 'pomo'); }
    tm.mode = S.mode;
    S.timer = tm; S.lastTimer = tm;
    var wasStudying = S.studying;
    S.studying = (tm.phase === 'work' && tm.running) || !!tm.chrono_running;
    S.resting = tm.phase === 'break' || tm.phase === 'long_break';
    if (prev) {
      if (prev.phase === 'work' && S.resting) {
        H.banner('🍅 یک پومودورو تمام شد!', '☕ استراحت کن؛ کمبوی تو حفظ می‌شود', 'blue', 3200);
        R3.sfx.play('levelup'); W.confetti(); W.celebrate('me'); R3.haptic('heavy');
      } else if ((prev.phase === 'break' || prev.phase === 'long_break') && tm.phase === 'work') {
        H.banner('⚔️ برگرد به نبرد!', 'استراحت تمام شد', 'boss', 2400); R3.sfx.play('roar');
      }
    }
    if (wasStudying !== S.studying) { syncWorld(); if (!S.studying) setAmbient(false); S.idleT = 0; }
    H.focus(tm, S.studying, S.resting);
  }

  /* ================================================================ حلقهٔ منطق */
  function tick(dt) {
    // کمبو
    if (S.studying) { S.run.live += dt; S.run.gapUsed = 0; }
    else if (S.run.live > 0) {
      S.run.gapUsed += dt;
      if (S.run.gapUsed > (S.resting ? REST_GAP : GAP)) S.run.live = 0;
    }
    var tier = tierOf(S.run.live);
    if (tier !== S.run.tier) {
      var up = tier > S.run.tier;
      S.run.tier = tier;
      if (up && S.studying && tier > 0) {
        H.banner(H.TIER_FLAME[tier] + ' ' + H.TIER_NAME[tier] + '! ' + R3.mult(W.MULT[tier]), tier >= 4 ? 'خشم رستم بیدار شد — بیشترین قدرت!' : 'ضربه‌هایت قوی‌تر شد', tier >= 3 ? 'blue' : '', 2600);
        R3.sfx.play('combo'); H.comboBurst(); W.sparkleAtMe(W.TIER_COLOR[tier], 40); W.celebrate('me'); R3.haptic('medium');
      }
      syncWorld();
    }
    if (S.studying && S.chestLeft > 0) S.chestLeft = Math.max(0, S.chestLeft - dt);
    // حالت کم‌نور
    if (S.studying && R3.settings.dim && H.modalCount() === 0) {
      S.idleT += dt;
      if (S.idleT > 15 && !W.isAmbient()) setAmbient(true);
    }
    S.hudT -= dt;
    if (S.hudT <= 0) {
      S.hudT = W.isAmbient() ? 1 : 0.25;
      var gapLeft = Math.max(0, (S.resting ? REST_GAP : GAP) - S.run.gapUsed);
      H.combo({ tier: S.run.tier, live: S.run.live, studying: S.studying, resting: S.resting, gapLeft: gapLeft });
      if (S.r3 && !S.defeating) H.boss(S.r3.raid, S.hp.pred);
      updateDock();
    }
  }
  function updateDock() {
    var r3 = S.r3;
    if (!r3) { H.dock({}); return; }
    var q = r3.quests, questBadge = q.list.some(function (x) { return x.done && !x.claimed; }) || (q.bonus.ready && !q.bonus.claimed);
    var cat = S.catalog || [], coins = game.coins(), owned = r3.me.hats || [];
    var hatBadge = cat.some(function (h) { return h.cost > 0 && h.cost <= coins && owned.indexOf(h.key) < 0; }) && !R3.store.get('hatSeen' + Math.floor(coins / 100), 0);
    H.dock({ chests: r3.me.chest_total, chestP: r3.me.next_chest_sec > 0 ? 1 - S.chestLeft / Math.max(1, r3.me.chest_sec) : 1, quest: questBadge, hat: hatBadge, battle: (r3.rewards || []).length > 0 });
  }

  /* ================================================================ کم‌نور */
  function setAmbient(on) {
    if (!W.ready) return;
    if (on === W.isAmbient()) return;
    W.setAmbient(on);
    document.body.classList.toggle('ambient', on);
    var hint = R3.$('wake-hint');
    if (on) { hint.classList.remove('hidden'); setTimeout(function () { hint.classList.add('hidden'); }, 5000); }
    else hint.classList.add('hidden');
  }
  function wake() { S.idleT = 0; if (W.isAmbient()) setAmbient(false); }

  /* ================================================================ لمس روی صحنه */
  function onPick(type, id) {
    if (W.isAmbient()) return;
    if (type === 'me') { H.openWardrobe(); return; }
    if (type === 'avatar') {
      var p = W.person(String(id));
      if (p) H.openPerson(p);
      return;
    }
    if (type === 'boss') { H.openBattle(); return; }
    if (type === 'chest') { H.openChests(); return; }
  }

  /* ================================================================ راه‌اندازی */
  function hideSplash() {
    var sp = R3.$('splash');
    if (sp && !sp.classList.contains('out')) { sp.classList.add('out'); setTimeout(function () { sp.classList.add('hidden'); }, 700); }
  }
  function failSplash(reason) {
    var sub = R3.$('splash-sub');
    sub.textContent = 'این گوشی از نمایش سه‌بعدی پشتیبانی نمی‌کند. اتاق کلاسیک باز می‌شود…';
    var bar = document.querySelector('#splash .sp-bar'); if (bar) bar.classList.add('hidden');
    B.send('webgl_fail', { reason: String(reason || 'unsupported').slice(0, 160) });
  }
  function boot() {
    if (S.booted) return;
    S.booted = true;
    H.init();
    document.addEventListener('pointerdown', function () { wake(); }, true);
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { W.stop(); R3.sfx.suspend(); } else if (W.ready) W.start();
    });
    if (!W.supported()) { failSplash('no_webgl'); return; }
    var res;
    try { res = W.init(R3.$('stage'), { quality: R3.settings.quality, theme: 'library', night: false, preserve: !!window.R3_PRESERVE }); }
    catch (e) { res = { ok: false, reason: e && e.message }; }
    if (!res || !res.ok) { failSplash(res && res.reason); return; }
    W.hooks.tick = tick;
    W.hooks.pick = onPick;
    W.hooks.touch = wake;
    W.hooks.hit = function (pid, dmg, mine) {
      if (S.defeating || !S.r3) return;
      S.hp.pred = Math.min(S.hp.max - 1, S.hp.pred + dmg);
      if (mine) H.bossFlash();
      W.bossHp(1 - S.hp.pred / Math.max(1, S.hp.max));
    };
    W.hooks.quality = function (q) { B.send('debug', { msg: 'quality→' + q }); };
    var lostAt = 0;
    W.hooks.lost = function () {
      lostAt = Date.now();
      setTimeout(function () { if (lostAt && Date.now() - lostAt >= 3900) failSplash('context_lost'); }, 4000);
    };
    W.hooks.restored = function () { lostAt = 0; W.start(); };
    applySettings();
    W.start();
    S.ready = true;
    var q = queue; queue = [];
    q.forEach(function (msg) { R3.push(msg); });
    B.send('ready', { v: 1, quality: W.getQuality() });
    setTimeout(function () { if (S.firstState) R3.$('splash-sub').textContent = 'در حال پیوستن به هم‌اتاقی‌ها…'; }, 1800);
  }
  R3.boot = boot;
  function start() {
    var go = function () { setTimeout(boot, 0); };
    try {
      if (document.fonts && document.fonts.ready) {
        var done = false, fin = function () { if (!done) { done = true; go(); } };
        document.fonts.load('900 16px Vaz').then(fin, fin);
        setTimeout(fin, 1200);
      } else go();
    } catch (e) { go(); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
