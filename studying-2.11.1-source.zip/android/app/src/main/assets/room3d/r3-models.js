/* هفت‌خانِ تمرکز — مدل‌سازی رویه‌ای: همه‌چیز از شکل‌های ساده ساخته و در یک
   هندسهٔ رنگ‌به‌رأس ادغام می‌شود تا تعداد draw call کم بماند. هیچ تصویر یا مدل
   خارجی‌ای بارگذاری نمی‌شود. */
(function () {
  'use strict';
  var R3 = window.R3, T = THREE;
  var M = R3.models = {};
  var V3 = T.Vector3;
  var PI = Math.PI;

  /* ------------------------------------------------------------ ماتریس و ادغام */
  var _q = new T.Quaternion(), _e = new T.Euler(), _p = new V3(), _s = new V3();
  function tr(p, r, s) {
    var m = new T.Matrix4();
    _e.set(r ? r[0] : 0, r ? r[1] : 0, r ? r[2] : 0, (r && r[3]) || 'XYZ');
    _q.setFromEuler(_e);
    _p.set(p ? p[0] : 0, p ? p[1] : 0, p ? p[2] : 0);
    if (s === undefined) _s.set(1, 1, 1);
    else if (typeof s === 'number') _s.set(s, s, s);
    else _s.set(s[0], s[1], s[2]);
    return m.compose(_p, _q, _s);
  }
  M.tr = tr;

  function Builder() { this.parts = []; }
  Builder.prototype.add = function (geo, color, m) { this.parts.push([geo, color, m || null]); return this; };
  Builder.prototype.build = function () {
    var nV = 0, nI = 0, i, j;
    for (i = 0; i < this.parts.length; i++) {
      var g0 = this.parts[i][0];
      nV += g0.attributes.position.count;
      nI += g0.index ? g0.index.count : g0.attributes.position.count;
    }
    var pos = new Float32Array(nV * 3), nor = new Float32Array(nV * 3), col = new Float32Array(nV * 3);
    var idx = nV > 65000 ? new Uint32Array(nI) : new Uint16Array(nI);
    var vo = 0, io = 0, v = new V3(), n = new V3(), nm = new T.Matrix3(), c = new T.Color(), lp = new V3();
    for (i = 0; i < this.parts.length; i++) {
      var g = this.parts[i][0], color = this.parts[i][1], m = this.parts[i][2] || new T.Matrix4();
      nm.getNormalMatrix(m);
      var P = g.attributes.position, N = g.attributes.normal, cnt = P.count, fn = typeof color === 'function';
      if (!fn) c.set(color);
      for (j = 0; j < cnt; j++) {
        lp.fromBufferAttribute(P, j);
        v.copy(lp).applyMatrix4(m);
        n.fromBufferAttribute(N, j).applyMatrix3(nm).normalize();
        var k = (vo + j) * 3;
        pos[k] = v.x; pos[k + 1] = v.y; pos[k + 2] = v.z;
        nor[k] = n.x; nor[k + 1] = n.y; nor[k + 2] = n.z;
        if (fn) c.set(color(lp, v));
        col[k] = c.r; col[k + 1] = c.g; col[k + 2] = c.b;
      }
      if (g.index) { for (j = 0; j < g.index.count; j++) idx[io + j] = g.index.getX(j) + vo; io += g.index.count; }
      else { for (j = 0; j < cnt; j++) idx[io + j] = vo + j; io += cnt; }
      vo += cnt;
    }
    var out = new T.BufferGeometry();
    out.setAttribute('position', new T.BufferAttribute(pos, 3));
    out.setAttribute('normal', new T.BufferAttribute(nor, 3));
    out.setAttribute('color', new T.BufferAttribute(col, 3));
    out.setIndex(new T.BufferAttribute(idx, 1));
    out.computeBoundingSphere();
    out.computeBoundingBox();
    return out;
  };
  M.Builder = Builder;

  /* ------------------------------------------------------------ شکل‌های پایه */
  var cache = {};
  function G(key, f) { return cache[key] || (cache[key] = f()); }
  M.detail = 1; // 0.7 در کیفیت پایین
  function sg(n) { return Math.max(6, Math.round(n * M.detail)); }
  M.sphere = function (seg) { seg = sg(seg || 14); return G('s' + seg, function () { return new T.SphereGeometry(1, seg, Math.max(5, Math.round(seg * 0.7))); }); };
  M.hemi = function (seg) { seg = sg(seg || 14); return G('h' + seg, function () { return new T.SphereGeometry(1, seg, Math.max(4, Math.round(seg * 0.4)), 0, PI * 2, 0, PI / 2); }); };
  M.cyl = function (rt, rb, seg, open) {
    seg = sg(seg || 14);
    return G('c' + rt + '_' + rb + '_' + seg + (open ? 'o' : ''), function () { return new T.CylinderGeometry(rt, rb, 1, seg, 1, !!open); });
  };
  M.cone = function (seg) { seg = sg(seg || 12); return G('k' + seg, function () { return new T.ConeGeometry(1, 1, seg); }); };
  M.capsule = function (r, len, seg) {
    seg = sg(seg || 10);
    return G('p' + r + '_' + len + '_' + seg, function () { return new T.CapsuleGeometry(r, len, 3, seg); });
  };
  M.torus = function (R, t, arc, rs, ts) {
    rs = sg(rs || 8); ts = sg(ts || 24);
    return G('t' + R + '_' + t + '_' + (arc || 0) + '_' + rs + '_' + ts, function () { return new T.TorusGeometry(R, t, rs, ts, arc || PI * 2); });
  };
  M.ico = function (detail) { return G('i' + (detail || 0), function () { return new T.IcosahedronGeometry(1, detail || 0); }); };
  M.octa = function () { return G('o', function () { return new T.OctahedronGeometry(1, 0); }); };
  M.box = function () { return G('b', function () { return new T.BoxGeometry(1, 1, 1); }); };
  /** جعبهٔ گوشه‌گرد با نرمال نرم (برای خط دور تمیز). */
  M.rbox = function (w, h, d, r, seg) {
    seg = seg || 3;
    r = Math.min(r === undefined ? 0.04 : r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001);
    var key = 'rb' + w.toFixed(3) + '_' + h.toFixed(3) + '_' + d.toFixed(3) + '_' + r.toFixed(3) + '_' + seg;
    return G(key, function () {
      var g = new T.BoxGeometry(w, h, d, seg, seg, seg);
      var P = g.attributes.position, N = g.attributes.normal;
      var ix = w / 2 - r, iy = h / 2 - r, iz = d / 2 - r, v = new V3(), c = new V3(), n = new V3();
      for (var i = 0; i < P.count; i++) {
        v.fromBufferAttribute(P, i);
        c.set(R3.clamp(v.x, -ix, ix), R3.clamp(v.y, -iy, iy), R3.clamp(v.z, -iz, iz));
        n.subVectors(v, c);
        if (n.lengthSq() < 1e-10) n.fromBufferAttribute(N, i); else n.normalize();
        v.copy(c).addScaledVector(n, r);
        P.setXYZ(i, v.x, v.y, v.z); N.setXYZ(i, n.x, n.y, n.z);
      }
      return g;
    });
  };
  /** پرهٔ مثلثی دوطرفه (برای بال و تیزی‌ها). */
  M.tri = function () {
    return G('tri', function () {
      var g = new T.BufferGeometry();
      var p = [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0];
      var n = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, -1, 0, 0, -1];
      g.setAttribute('position', new T.Float32BufferAttribute(p, 3));
      g.setAttribute('normal', new T.Float32BufferAttribute(n, 3));
      return g;
    });
  };

  /** زنجیرهٔ کره‌ها روی یک مسیر — برای دم، شاخ و بدن اژدها. */
  M.chain = function (b, pts, r0, r1, color, scaleFn) {
    for (var i = 0; i < pts.length; i++) {
      var t = pts.length === 1 ? 0 : i / (pts.length - 1);
      var r = R3.lerp(r0, r1, t);
      var s = scaleFn ? scaleFn(t, r) : [r, r, r];
      b.add(M.sphere(10), typeof color === 'function' ? color(t) : color, tr(pts[i], null, s));
    }
  };
  /** شاخ مخروطی خمیده: چند مخروط پشت سر هم روی یک کمان. */
  M.horn = function (b, base, dir, up, len, r, segs, color, tipColor) {
    var p = new V3(base[0], base[1], base[2]), d = new V3(dir[0], dir[1], dir[2]).normalize(), u = new V3(up[0], up[1], up[2]).normalize();
    var step = len / segs, q = new T.Quaternion(), yAxis = new V3(0, 1, 0);
    for (var i = 0; i < segs; i++) {
      var t = i / segs;
      var cur = d.clone().lerp(u, Math.min(1, t * 1.2)).normalize();
      var rr = r * (1 - t * 0.85);
      var mid = p.clone().addScaledVector(cur, step / 2);
      q.setFromUnitVectors(yAxis, cur);
      var m = new T.Matrix4().compose(mid, q, new V3(rr, step * 1.15, rr));
      b.add(i === segs - 1 ? M.cone(10) : M.cyl(0.8, 1, 10), (i >= segs - 2 && tipColor) ? tipColor : color, m);
      p.addScaledVector(cur, step);
    }
  };

  /* ------------------------------------------------------------ مواد */
  var grad = (function () {
    var d = new Uint8Array([70, 70, 70, 255, 150, 150, 150, 255, 215, 215, 215, 255, 255, 255, 255, 255]);
    var t = new T.DataTexture(d, 4, 1, T.RGBAFormat);
    t.minFilter = t.magFilter = T.NearestFilter; t.generateMipmaps = false; t.needsUpdate = true;
    return t;
  })();
  M.toon = function (opts) {
    opts = opts || {};
    var m = new T.MeshToonMaterial({ color: opts.color || 0xffffff, vertexColors: opts.vertexColors !== false, gradientMap: grad });
    if (opts.emissive) m.emissive = new T.Color(opts.emissive);
    if (opts.transparent) { m.transparent = true; m.opacity = opts.opacity === undefined ? 1 : opts.opacity; }
    return m;
  };
  M.shared = { toon: null };
  M.sharedToon = function () { return M.shared.toon || (M.shared.toon = M.toon()); };
  M.basic = function (color, opts) {
    opts = opts || {};
    return new T.MeshBasicMaterial({ color: color === undefined ? 0xffffff : color, vertexColors: !!opts.vertexColors, transparent: !!opts.transparent, opacity: opts.opacity === undefined ? 1 : opts.opacity, fog: opts.fog !== false, depthWrite: opts.depthWrite !== false, blending: opts.additive ? T.AdditiveBlending : T.NormalBlending, side: opts.side || T.FrontSide });
  };
  var outlineCache = {};
  M.INK = 0x2B1E16;
  M.outlineMat = function (w) {
    var key = w.toFixed(4);
    if (outlineCache[key]) return outlineCache[key];
    var m = new T.ShaderMaterial({
      uniforms: { uW: { value: w }, uC: { value: new T.Color(M.INK) } },
      vertexShader: [
        'uniform float uW;',
        'void main(){',
        '  vec3 p = position + normal * uW;',
        '  #ifdef USE_INSTANCING',
        '    vec4 wp = modelMatrix * instanceMatrix * vec4(p, 1.0);',
        '  #else',
        '    vec4 wp = modelMatrix * vec4(p, 1.0);',
        '  #endif',
        '  gl_Position = projectionMatrix * viewMatrix * wp;',
        '}'].join('\n'),
      fragmentShader: 'uniform vec3 uC; void main(){ gl_FragColor = vec4(uC, 1.0);\n#include <colorspace_fragment>\n}',
      side: T.BackSide
    });
    outlineCache[key] = m;
    return m;
  };
  M.outlines = true;
  /** مش تون با خط دور مرکب (پوستهٔ وارونه). */
  M.mesh = function (geo, mat, ow) {
    var m = new T.Mesh(geo, mat || M.sharedToon());
    if (ow && M.outlines) {
      var o = new T.Mesh(geo, M.outlineMat(ow));
      o.raycast = function () { };
      o.userData.outline = true;
      m.add(o);
    }
    return m;
  };

  /* بافت‌های کوچک بوم برای ذره‌ها و درخشش */
  M.glowTex = (function () {
    var c = document.createElement('canvas'); c.width = c.height = 64;
    var g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,.8)');
    gr.addColorStop(0.6, 'rgba(255,255,255,.18)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    var t = new T.CanvasTexture(c); return t;
  })();
  /** اطلس ۲×۲: نقطهٔ نرم، ستاره، گلبرگ، دانهٔ برف/مربع */
  M.atlas = (function () {
    var c = document.createElement('canvas'); c.width = c.height = 128;
    var g = c.getContext('2d');
    var gr = g.createRadialGradient(32, 32, 0, 32, 32, 30);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,.7)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    g.save(); g.translate(96, 32); g.fillStyle = '#fff';
    g.beginPath();
    for (var i = 0; i < 8; i++) { var a = i * PI / 4, r = i % 2 ? 7 : 28; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
    g.closePath(); g.fill();
    var g2 = g.createRadialGradient(0, 0, 0, 0, 0, 14); g2.addColorStop(0, 'rgba(255,255,255,1)'); g2.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = g2; g.beginPath(); g.arc(0, 0, 14, 0, PI * 2); g.fill(); g.restore();
    g.save(); g.translate(32, 96); g.rotate(0.6); g.fillStyle = '#fff';
    g.beginPath(); g.moveTo(0, -26); g.bezierCurveTo(20, -14, 18, 16, 0, 26); g.bezierCurveTo(-18, 16, -20, -14, 0, -26); g.fill();
    g.restore();
    g.fillStyle = '#fff'; g.fillRect(64 + 12, 64 + 18, 40, 28);
    var t = new T.CanvasTexture(c); return t;
  })();

  /* ------------------------------------------------------------ رنگ‌ها */
  var C = M.C = {
    ink: 0x2B1E16, white: 0xFFFFFF, cream: 0xFFF6E5, pink: 0xF9A8C0, blush: 0xFF9FB0, dark: 0x2A2320, nose: 0x3B2A25,
    gold: 0xF5B800, goldD: 0xC98A00, steel: 0x9AA8B8, red: 0xE53935
  };

  /* ------------------------------------------------------------ آواتار حیوان‌ها */
  var SPECIES = M.SPECIES = {
    cat: { body: 0xF4A259, belly: 0xFFE5C4, muzzle: 0xFFF1DE, ear: 0xE8893C, earIn: 0xFFB8C6, nose: 0xE57373, fa: 'گربه' },
    dog: { body: 0xC98E5A, belly: 0xF5DFC2, muzzle: 0xF7E6CF, ear: 0x8A5A38, earIn: 0x8A5A38, nose: 0x3B2A25, fa: 'سگ' },
    owl: { body: 0x9A7458, belly: 0xE8D6C3, muzzle: 0xE8D6C3, ear: 0x7A573F, earIn: 0x7A573F, nose: 0xF59E0B, fa: 'جغد' },
    rabbit: { body: 0xEDEFF3, belly: 0xFFFFFF, muzzle: 0xFFFFFF, ear: 0xEDEFF3, earIn: 0xF9B4C8, nose: 0xF48FB1, fa: 'خرگوش' },
    fox: { body: 0xF57C1F, belly: 0xFFF3E6, muzzle: 0xFFF6EC, ear: 0xF57C1F, earIn: 0x3A2A22, nose: 0x2A2320, fa: 'روباه' },
    panda: { body: 0xFAFAFA, belly: 0xFFFFFF, muzzle: 0xFFFFFF, ear: 0x2B2B30, earIn: 0x2B2B30, nose: 0x2B2B30, fa: 'پاندا' },
    bear: { body: 0x9A6233, belly: 0xD9AE7E, muzzle: 0xE0BC8E, ear: 0x9A6233, earIn: 0xD9AE7E, nose: 0x3B2A25, fa: 'خرس' }
  };
  M.NECK_Y = 1.32;   // مفصل گردن (از کف زمین)
  M.HEAD_TOP = 0.86; // بالای سر نسبت به مفصل گردن
  var avatarCache = {};

  function buildBody(kind) {
    var s = SPECIES[kind] || SPECIES.cat, b = new Builder();
    var arm = kind === 'panda' ? 0x2B2B30 : s.body;
    if (kind === 'owl') {
      b.add(M.sphere(16), s.body, tr([0, 1.0, 0], null, [0.46, 0.52, 0.4]));
      b.add(M.sphere(14), s.belly, tr([0, 0.96, 0.17], null, [0.33, 0.38, 0.26]));
      for (var i = 0; i < 5; i++) {
        var a = (i - 2) * 0.13;
        b.add(M.sphere(8), 0xC9B39C, tr([a, 0.9 + (i % 2) * 0.09, 0.42], null, [0.04, 0.025, 0.02]));
      }
      // بال‌ها که روی میز آمده‌اند
      [-1, 1].forEach(function (sd) {
        b.add(M.sphere(12), 0x7E5B42, tr([sd * 0.42, 1.0, 0.08], [0.55, 0, sd * 0.18], [0.13, 0.36, 0.24]));
        b.add(M.sphere(10), 0x7E5B42, tr([sd * 0.3, 0.83, 0.46], null, [0.13, 0.08, 0.14]));
      });
    } else {
      b.add(M.sphere(16), s.body, tr([0, 1.0, 0], null, [0.44, 0.5, 0.38]));
      b.add(M.sphere(14), s.belly, tr([0, 0.98, 0.2], null, [0.3, 0.34, 0.22]));
      if (kind === 'panda') b.add(M.sphere(14), 0x2B2B30, tr([0, 1.2, -0.02], null, [0.46, 0.17, 0.4]));
      [-1, 1].forEach(function (sd) {
        b.add(M.capsule(0.1, 0.36), arm, tr([sd * 0.33, 1.0, 0.22], [1.0, 0, sd * 0.25]));
        b.add(M.sphere(10), arm, tr([sd * 0.27, 0.84, 0.47], null, [0.13, 0.1, 0.14]));
      });
    }
    if (kind === 'fox') b.add(M.sphere(12), 0xFFF3E6, tr([0, 1.16, 0.25], null, [0.2, 0.14, 0.12]));
    return b.build();
  }

  function buildHead(kind) {
    // مختصات نسبت به مفصل گردن
    var s = SPECIES[kind] || SPECIES.cat, b = new Builder(), hy = 0.34;
    var head = kind === 'owl' ? [0.5, 0.46, 0.46] : [0.47, 0.43, 0.44];
    b.add(M.sphere(18), s.body, tr([0, hy, 0], null, head));
    if (kind === 'panda') {
      [-1, 1].forEach(function (sd) {
        b.add(M.sphere(12), 0x2B2B30, tr([sd * 0.17, hy + 0.04, 0.35], [0, 0, sd * -0.5], [0.12, 0.15, 0.08]));
      });
    }
    if (kind === 'owl') {
      [-1, 1].forEach(function (sd) {
        b.add(M.sphere(14), 0xF7EBDD, tr([sd * 0.18, hy + 0.04, 0.34], null, [0.18, 0.18, 0.1]));
        b.add(M.sphere(12), 0xF4B942, tr([sd * 0.18, hy + 0.04, 0.4], null, [0.11, 0.11, 0.06]));
        b.add(M.cone(10), s.ear, tr([sd * 0.27, hy + 0.42, 0.04], [0, 0, sd * -0.55], [0.08, 0.24, 0.07]));
      });
      b.add(M.cone(10), 0xF59E0B, tr([0, hy - 0.12, 0.45], [PI, 0, 0], [0.07, 0.16, 0.06]));
    } else {
      var mz = kind === 'dog' || kind === 'bear' ? [0.23, 0.16, 0.17] : (kind === 'fox' ? [0.2, 0.13, 0.22] : [0.2, 0.14, 0.13]);
      b.add(M.sphere(14), s.muzzle, tr([0, hy - 0.11, 0.36], null, mz));
      if (kind === 'fox') {
        [-1, 1].forEach(function (sd) { b.add(M.sphere(12), 0xFFF6EC, tr([sd * 0.2, hy - 0.08, 0.27], null, [0.17, 0.14, 0.14])); });
      }
      b.add(M.sphere(10), s.nose, tr([0, hy - 0.04, kind === 'fox' ? 0.58 : (kind === 'dog' || kind === 'bear' ? 0.53 : 0.49)], null, kind === 'dog' || kind === 'bear' ? [0.075, 0.055, 0.05] : [0.055, 0.04, 0.04]));
      b.add(M.rbox(0.1, 0.018, 0.02, 0.008), 0x5A3B32, tr([0, hy - 0.18, 0.47]));
      [-1, 1].forEach(function (sd) {
        b.add(M.sphere(10), C.blush, tr([sd * 0.27, hy - 0.08, 0.3], null, [0.075, 0.05, 0.03]));
      });
    }
    // گوش‌ها
    if (kind === 'cat' || kind === 'fox') {
      var tall = kind === 'fox' ? 0.34 : 0.27;
      [-1, 1].forEach(function (sd) {
        b.add(M.cone(10), s.ear, tr([sd * 0.27, hy + 0.36, -0.02], [0, 0, sd * -0.32], [0.14, tall, 0.1]));
        b.add(M.cone(10), s.earIn, tr([sd * 0.26, hy + 0.34, 0.04], [0, 0, sd * -0.32], [0.08, tall * 0.7, 0.05]));
        if (kind === 'fox') b.add(M.cone(10), 0x2A2320, tr([sd * 0.315, hy + 0.47, -0.02], [0, 0, sd * -0.32], [0.06, 0.1, 0.05]));
      });
      if (kind === 'cat') {
        for (var k = -1; k <= 1; k++) b.add(M.rbox(0.035, 0.11, 0.02, 0.01), 0xC86F2A, tr([k * 0.075, hy + 0.32, 0.36], [-0.5, 0, k * 0.15]));
      }
    } else if (kind === 'dog') {
      [-1, 1].forEach(function (sd) { b.add(M.sphere(12), s.ear, tr([sd * 0.43, hy - 0.02, -0.02], [0, 0, sd * 0.32], [0.12, 0.27, 0.08])); });
      b.add(M.sphere(10), 0xF48FB1, tr([0.04, hy - 0.23, 0.44], [0.4, 0, 0], [0.05, 0.03, 0.04]));
    } else if (kind === 'rabbit') {
      [-1, 1].forEach(function (sd) {
        b.add(M.capsule(0.085, 0.42), s.ear, tr([sd * 0.15, hy + 0.62, -0.03], [0, 0, sd * -0.13]));
        b.add(M.capsule(0.045, 0.32), s.earIn, tr([sd * 0.155, hy + 0.62, 0.035], [0, 0, sd * -0.13]));
      });
      b.add(M.rbox(0.07, 0.06, 0.02, 0.01), 0xFFFFFF, tr([0, hy - 0.2, 0.46]));
    } else if (kind === 'panda' || kind === 'bear') {
      [-1, 1].forEach(function (sd) {
        b.add(M.sphere(12), s.ear, tr([sd * 0.31, hy + 0.33, -0.03], null, [0.13, 0.13, 0.08]));
        b.add(M.sphere(10), s.earIn, tr([sd * 0.31, hy + 0.33, 0.02], null, [0.07, 0.07, 0.05]));
      });
    }
    return b.build();
  }

  function buildEyes(kind) {
    var b = new Builder(), hy = 0.34, owl = kind === 'owl';
    [-1, 1].forEach(function (sd) {
      var x = sd * (owl ? 0.18 : 0.16), y = hy + (owl ? 0.04 : 0.05), z = owl ? 0.44 : 0.4;
      b.add(M.sphere(10), 0x1F1814, tr([x, y, z], null, owl ? [0.075, 0.075, 0.04] : [0.062, 0.07, 0.04]));
      b.add(M.sphere(8), 0xFFFFFF, tr([x + sd * -0.018, y + 0.025, z + 0.03], null, 0.02));
    });
    return b.build();
  }

  function buildTail(kind) {
    var s = SPECIES[kind] || SPECIES.cat, b = new Builder();
    if (kind === 'fox') {
      M.chain(b, [[0.32, 0.75, -0.3], [0.5, 0.95, -0.4], [0.58, 1.2, -0.42], [0.55, 1.42, -0.36]], 0.13, 0.17, function (t) { return t > 0.8 ? 0xFFF6EC : s.body; });
    } else if (kind === 'cat') {
      M.chain(b, [[0.3, 0.7, -0.32], [0.45, 0.9, -0.4], [0.5, 1.12, -0.42], [0.44, 1.3, -0.38], [0.36, 1.38, -0.33]], 0.06, 0.07, function (t) { return t > 0.75 ? 0xC86F2A : s.body; });
    } else if (kind === 'rabbit') {
      b.add(M.sphere(10), 0xFFFFFF, tr([0, 0.62, -0.38], null, 0.11));
    } else if (kind === 'dog') {
      M.chain(b, [[0.25, 0.72, -0.33], [0.36, 0.9, -0.42], [0.42, 1.05, -0.44]], 0.06, 0.05, s.body);
    } else return null;
    return b.build();
  }

  M.avatarGeo = function (kind) {
    if (!SPECIES[kind]) kind = 'cat';
    if (avatarCache[kind]) return avatarCache[kind];
    var g = { body: buildBody(kind), head: buildHead(kind), eyes: buildEyes(kind), tail: buildTail(kind) };
    avatarCache[kind] = g;
    return g;
  };

  /** یک آواتار کامل: ریشه روی زمین، رو به +z. */
  M.avatar = function (kind) {
    var g = M.avatarGeo(kind), root = new T.Group();
    var body = M.mesh(g.body, null, 0.022);
    var head = M.mesh(g.head, null, 0.02);
    head.position.y = M.NECK_Y;
    var eyes = new T.Mesh(g.eyes, M.sharedToon());
    var eyePivot = new T.Group(); eyePivot.position.set(0, 0.39, 0.4); eyes.position.set(0, -0.39, -0.4);
    eyePivot.add(eyes); head.add(eyePivot);
    var hatAnchor = new T.Group(); hatAnchor.position.set(0, kind === 'owl' ? 0.8 : 0.76, 0.02); head.add(hatAnchor);
    root.add(body); root.add(head);
    if (g.tail) { var tail = M.mesh(g.tail, null, 0.018); root.add(tail); root.userData.tail = tail; }
    root.userData.parts = { body: body, head: head, eyes: eyePivot, hat: hatAnchor };
    return root;
  };

  /* ------------------------------------------------------------ کلاه‌ها */
  M.HATS = {
    hat_cap: '🎓', hat_headphones: '🎧', hat_wizard: '🧙', hat_halo: '😇', hat_helmet: '⛑️', hat_crown: '👑', hat_simorgh: '🪶', hat_div: '👹'
  };
  var hatCache = {};
  M.hat = function (key) {
    var grp = new T.Group(), b = new Builder(), glow = null;
    if (hatCache[key]) { var c = hatCache[key]; grp.add(M.mesh(c.geo, null, c.ow)); if (c.glow) grp.add(M.hatGlow(c.glow)); return grp; }
    var ow = 0.018;
    switch (key) {
      case 'hat_cap':
        b.add(M.cyl(0.29, 0.3, 16), 0x1E293B, tr([0, 0.0, 0], null, [1, 0.16, 1]));
        b.add(M.rbox(0.74, 0.045, 0.74, 0.015), 0x111827, tr([0, 0.1, 0], [0, PI / 4, 0]));
        b.add(M.sphere(8), C.gold, tr([0, 0.135, 0], null, 0.04));
        b.add(M.cyl(0.012, 0.012, 6), C.gold, tr([0.24, 0.0, 0.24], null, [1, 0.22, 1]));
        b.add(M.sphere(8), C.gold, tr([0.24, -0.12, 0.24], null, [0.04, 0.07, 0.04]));
        break;
      case 'hat_headphones':
        b.add(M.torus(0.47, 0.05, PI, 8, 20), 0x374151, tr([0, -0.36, -0.02]));
        [-1, 1].forEach(function (sd) {
          b.add(M.cyl(0.15, 0.15, 16), 0xEF4444, tr([sd * 0.47, -0.36, -0.02], [0, 0, PI / 2], [1, 0.13, 1]));
          b.add(M.cyl(0.11, 0.11, 14), 0x1F2937, tr([sd * 0.4, -0.36, -0.02], [0, 0, PI / 2], [1, 0.06, 1]));
        });
        break;
      case 'hat_wizard':
        b.add(M.cyl(0.5, 0.5, 20), 0x4C1D95, tr([0, 0, 0], null, [1, 0.04, 1]));
        b.add(M.cone(16), 0x6D28D9, tr([0, 0.4, -0.06], [-0.22, 0, 0.05], [0.31, 0.8, 0.31]));
        b.add(M.torus(0.29, 0.035, 0, 6, 20), C.gold, tr([0, 0.07, 0], [PI / 2, 0, 0]));
        [[0.12, 0.3, 0.2], [-0.1, 0.5, 0.12], [0.03, 0.66, 0.02]].forEach(function (p) { b.add(M.octa(), 0xFDE047, tr(p, [0.3, 0.6, 0], 0.05)); });
        break;
      case 'hat_halo':
        b.add(M.torus(0.3, 0.045, 0, 8, 28), 0xFFD54F, tr([0, 0.22, 0], [PI / 2 - 0.25, 0, 0]));
        ow = 0;
        glow = { color: 0xFFE082, size: 1.2, y: 0.22 };
        break;
      case 'hat_helmet':
        b.add(M.hemi(18), 0xA9B6C6, tr([0, -0.17, 0], null, [0.5, 0.46, 0.5]));
        b.add(M.torus(0.5, 0.04, 0, 6, 26), 0xD4A017, tr([0, -0.16, 0], [PI / 2, 0, 0]));
        b.add(M.cone(10), 0xD4A017, tr([0, 0.39, 0], null, [0.06, 0.24, 0.06]));
        b.add(M.sphere(8), 0xD4A017, tr([0, 0.28, 0], null, 0.06));
        b.add(M.rbox(0.07, 0.26, 0.05, 0.02), 0x8A97A8, tr([0, -0.2, 0.49]));
        b.add(M.sphere(10), 0xE53935, tr([0, 0.47, -0.02], null, [0.05, 0.08, 0.05]));
        break;
      case 'hat_crown':
        b.add(M.cyl(0.3, 0.27, 20, true), 0xF5B800, tr([0, 0.06, 0], null, [1, 0.2, 1]));
        b.add(M.torus(0.29, 0.03, 0, 6, 24), 0xFFD54F, tr([0, -0.04, 0], [PI / 2, 0, 0]));
        for (var i = 0; i < 8; i++) {
          var a = i / 8 * PI * 2;
          b.add(M.cone(8), 0xF5B800, tr([Math.sin(a) * 0.29, 0.25, Math.cos(a) * 0.29], null, [0.06, 0.18, 0.06]));
          b.add(M.sphere(8), 0xFFF4C2, tr([Math.sin(a) * 0.29, 0.35, Math.cos(a) * 0.29], null, 0.03));
        }
        b.add(M.sphere(10), 0xE53935, tr([0, 0.06, 0.3], null, [0.06, 0.06, 0.03]));
        b.add(M.sphere(10), 0x1E88E5, tr([0.2, 0.06, 0.22], null, [0.04, 0.04, 0.025]));
        b.add(M.sphere(10), 0x43A047, tr([-0.2, 0.06, 0.22], null, [0.04, 0.04, 0.025]));
        break;
      case 'hat_simorgh':
        [[0.0, 0x14B8A6, 0], [-0.33, 0xF59E0B, -0.06], [0.33, 0xE11D48, -0.06]].forEach(function (f) {
          b.add(M.sphere(12), f[1], tr([f[0] * 0.5, 0.36, -0.12 + f[2]], [-0.35, 0, f[0]], [0.065, 0.42, 0.025]));
          b.add(M.sphere(8), 0x1E3A8A, tr([f[0] * 0.98, 0.64, -0.21 + f[2]], [-0.35, 0, f[0]], [0.04, 0.06, 0.03]));
        });
        b.add(M.sphere(10), 0xF5B800, tr([0, 0.02, -0.06], null, 0.075));
        glow = { color: 0x5EEAD4, size: 0.9, y: 0.45 };
        break;
      case 'hat_div':
        b.add(M.hemi(18), 0xEEF2F7, tr([0, -0.16, 0], null, [0.5, 0.44, 0.5]));
        M.horn(b, [0.3, 0.02, 0], [1, 0.2, 0], [0.4, 1, 0], 0.55, 0.08, 5, 0xFFF3D6, 0x3F3F46);
        M.horn(b, [-0.3, 0.02, 0], [-1, 0.2, 0], [-0.4, 1, 0], 0.55, 0.08, 5, 0xFFF3D6, 0x3F3F46);
        b.add(M.sphere(10), 0x38BDF8, tr([0, 0.0, 0.47], null, [0.06, 0.07, 0.04]));
        glow = { color: 0x7DD3FC, size: 0.7, y: 0.0, z: 0.5 };
        break;
      default:
        return grp;
    }
    var geo = b.build();
    hatCache[key] = { geo: geo, ow: ow, glow: glow };
    grp.add(M.mesh(geo, null, ow));
    if (glow) grp.add(M.hatGlow(glow));
    return grp;
  };
  M.hatGlow = function (g) {
    var sp = new T.Sprite(new T.SpriteMaterial({ map: M.glowTex, color: g.color, transparent: true, opacity: 0.7, blending: T.AdditiveBlending, depthWrite: false }));
    sp.scale.setScalar(g.size); sp.position.set(0, g.y || 0, g.z || 0);
    sp.userData.pulse = true;
    return sp;
  };

  /* ------------------------------------------------------------ میز و صندلی */
  M.THEME_WOOD = {
    library: { top: 0xC98E55, front: 0xA8703F, inset: 0xB98049, chair: 0x7C4A2A, rug: 0x9B2C2C },
    ancient_iran: { top: 0xD9C29A, front: 0xBFA172, inset: 0x2F8F9D, chair: 0x8C6A3F, rug: 0x7F1D1D },
    rasht: { top: 0x8D6E4E, front: 0x6E5238, inset: 0x7E9C5A, chair: 0x4E3B2A, rug: 0x2F5D50 },
    white_nights: { top: 0xBFC9D6, front: 0x8D9BB0, inset: 0xDDE6F0, chair: 0x51627A, rug: 0x34495E },
    japanese: { top: 0xD8B98A, front: 0x9C3B2E, inset: 0xF1E3C8, chair: 0x5A3A2A, rug: 0x6B8E5A }
  };
  M.deskGeo = function (theme, seed, mine) {
    var w = M.THEME_WOOD[theme] || M.THEME_WOOD.library, b = new Builder(), rnd = R3.rng(seed || 7);
    var W = mine ? 1.5 : 1.3;
    b.add(M.rbox(W, 0.08, 0.74, 0.03), w.top, tr([0, 0.78, 0.56]));
    b.add(M.rbox(W - 0.04, 0.7, 0.07, 0.025), w.front, tr([0, 0.4, 0.9]));
    b.add(M.rbox(W * 0.62, 0.36, 0.02, 0.02), w.inset, tr([0, 0.42, 0.94]));
    b.add(M.rbox(0.07, 0.7, 0.7, 0.02), w.front, tr([-(W / 2 - 0.05), 0.4, 0.56]));
    b.add(M.rbox(0.07, 0.7, 0.7, 0.02), w.front, tr([(W / 2 - 0.05), 0.4, 0.56]));
    // کتاب باز + مداد
    var cover = [0xB91C1C, 0x1D4ED8, 0x047857, 0x7C3AED, 0xC2410C][Math.floor(rnd() * 5)];
    b.add(M.rbox(0.62, 0.025, 0.4, 0.01), cover, tr([0, 0.83, 0.55], [0.12, 0, 0]));
    b.add(M.rbox(0.28, 0.03, 0.37, 0.008), 0xFFFBF0, tr([-0.145, 0.85, 0.55], [0.12, 0, -0.05]));
    b.add(M.rbox(0.28, 0.03, 0.37, 0.008), 0xFFFBF0, tr([0.145, 0.85, 0.55], [0.12, 0, 0.05]));
    for (var l = 0; l < 4; l++) {
      b.add(M.box(), 0x9CA3AF, tr([-0.15, 0.868, 0.45 + l * 0.06], [0.12, 0, -0.05], [0.2, 0.004, 0.008]));
      b.add(M.box(), 0x9CA3AF, tr([0.15, 0.868, 0.45 + l * 0.06], [0.12, 0, 0.05], [0.2, 0.004, 0.008]));
    }
    b.add(M.cyl(0.018, 0.018, 6), 0xFBBF24, tr([0.38, 0.84, 0.62], [PI / 2, 0, 0.7], [1, 0.3, 1]));
    // دسته‌کتاب کنار میز
    var bx = mine ? -0.55 : -0.46, h = 0.8;
    var nb = 1 + Math.floor(rnd() * 3);
    for (var k = 0; k < nb; k++) {
      var bc = [0x2563EB, 0xDC2626, 0x16A34A, 0xF59E0B, 0x9333EA, 0x0891B2][Math.floor(rnd() * 6)];
      var bh = 0.05 + rnd() * 0.03;
      b.add(M.rbox(0.26, bh, 0.34, 0.01), bc, tr([bx, h + bh / 2 + 0.02, 0.5], [0, (rnd() - 0.5) * 0.4, 0]));
      h += bh;
    }
    // صندلی
    b.add(M.rbox(0.8, 0.74, 0.09, 0.04), w.chair, tr([0, 1.0, -0.44], [-0.08, 0, 0]));
    b.add(M.rbox(0.66, 0.08, 0.6, 0.03), w.chair, tr([0, 0.5, -0.16]));
    return b.build();
  };

  /** وسایل خریده‌شده از فروشگاه روی میز خودم. */
  M.deskItems = function (desk) {
    desk = desk || {};
    var b = new Builder(), glows = [], any = false;
    var lamp = desk.lamp, clock = desk.clock, plant = desk.plant, mug = desk.mug;
    if (lamp) {
      any = true;
      var lx = 0.58, lz = 0.36;
      b.add(M.cyl(0.11, 0.13, 14), 0x374151, tr([lx, 0.835, lz], null, [1, 0.04, 1]));
      b.add(M.cyl(0.018, 0.018, 8), 0x4B5563, tr([lx, 1.03, lz], null, [1, 0.38, 1]));
      if (lamp === 'lamp_neon') {
        b.add(M.capsule(0.035, 0.4), 0xF472B6, tr([lx - 0.12, 1.22, lz + 0.05], [0, 0, PI / 2]));
        glows.push({ p: [lx - 0.12, 1.22, lz + 0.05], c: 0xF472B6, s: 0.9 });
      } else {
        b.add(M.cyl(0.08, 0.17, 14, true), 0x16A34A, tr([lx - 0.05, 1.22, lz + 0.03], [0, 0, 0.35], [1, 0.16, 1]));
        glows.push({ p: [lx - 0.07, 1.12, lz + 0.05], c: 0xFFE08A, s: 0.7 });
      }
    }
    if (clock) {
      any = true;
      var cx = -0.6, cz = 0.75, cy = 0.82;
      if (clock === 'clock_hourglass') {
        b.add(M.cone(10), 0xFDE68A, tr([cx, cy + 0.09, cz], [PI, 0, 0], [0.06, 0.09, 0.06]));
        b.add(M.cone(10), 0xFDE68A, tr([cx, cy + 0.18, cz], null, [0.06, 0.09, 0.06]));
        b.add(M.cyl(0.08, 0.08, 10), 0x7C4A2A, tr([cx, cy + 0.01, cz], null, [1, 0.02, 1]));
        b.add(M.cyl(0.08, 0.08, 10), 0x7C4A2A, tr([cx, cy + 0.27, cz], null, [1, 0.02, 1]));
      } else if (clock === 'clock_digital') {
        b.add(M.rbox(0.24, 0.12, 0.08, 0.02), 0x111827, tr([cx, cy + 0.07, cz]));
        b.add(M.rbox(0.19, 0.07, 0.01, 0.005), 0x22D3EE, tr([cx, cy + 0.075, cz + 0.042]));
        glows.push({ p: [cx, cy + 0.08, cz + 0.06], c: 0x22D3EE, s: 0.35 });
      } else if (clock === 'clock_pendulum') {
        b.add(M.rbox(0.16, 0.36, 0.09, 0.02), 0x7C4A2A, tr([cx, cy + 0.18, cz]));
        b.add(M.cyl(0.055, 0.055, 14), 0xFFF7E0, tr([cx, cy + 0.29, cz + 0.05], [PI / 2, 0, 0], [1, 0.01, 1]));
        b.add(M.sphere(8), 0xF5B800, tr([cx, cy + 0.1, cz + 0.05], null, 0.025));
      } else {
        b.add(M.cyl(0.1, 0.1, 16), 0xEF4444, tr([cx, cy + 0.11, cz], [PI / 2, 0, 0], [1, 0.06, 1]));
        b.add(M.cyl(0.082, 0.082, 16), 0xFFFBF0, tr([cx, cy + 0.11, cz + 0.032], [PI / 2, 0, 0], [1, 0.01, 1]));
        b.add(M.box(), 0x1F2937, tr([cx, cy + 0.14, cz + 0.04], null, [0.008, 0.06, 0.004]));
      }
    }
    if (plant) {
      any = true;
      var px = 0.62, pz = 0.78, py = 0.82;
      b.add(M.cyl(0.09, 0.07, 12), plant === 'plant_bonsai' ? 0x1E3A8A : 0xC2410C, tr([px, py + 0.07, pz], null, [1, 0.14, 1]));
      if (plant === 'plant_cactus') {
        b.add(M.capsule(0.045, 0.16), 0x16A34A, tr([px, py + 0.26, pz]));
        b.add(M.capsule(0.025, 0.06), 0x16A34A, tr([px + 0.06, py + 0.25, pz], [0, 0, -0.6]));
        b.add(M.sphere(8), 0xF472B6, tr([px, py + 0.38, pz], null, 0.03));
      } else if (plant === 'plant_monstera') {
        for (var i = 0; i < 5; i++) { var a = i / 5 * PI * 2; b.add(M.sphere(10), 0x15803D, tr([px + Math.sin(a) * 0.1, py + 0.25 + (i % 2) * 0.05, pz + Math.cos(a) * 0.1], [0.5, a, 0], [0.11, 0.02, 0.07])); }
      } else if (plant === 'plant_bonsai') {
        b.add(M.cyl(0.02, 0.03, 8), 0x6B4226, tr([px, py + 0.2, pz], [0, 0, 0.3], [1, 0.16, 1]));
        b.add(M.sphere(10), 0x15803D, tr([px - 0.04, py + 0.3, pz], null, [0.13, 0.07, 0.1]));
        b.add(M.sphere(10), 0x16A34A, tr([px + 0.06, py + 0.25, pz], null, [0.08, 0.05, 0.07]));
      } else {
        b.add(M.sphere(10), 0x22C55E, tr([px, py + 0.24, pz], null, [0.11, 0.12, 0.11]));
      }
    }
    if (mug) {
      any = true;
      var mx = -0.38, mz = 0.82, my = 0.82;
      var mc = { mug_coffee: [0xF8FAFC, 0x6B3F23], mug_tea: [0xFDE68A, 0xB45309], mug_matcha: [0xE7E5E4, 0x65A30D], mug_cocoa: [0xFCA5A5, 0x7C2D12] }[mug] || [0xF8FAFC, 0x6B3F23];
      b.add(M.cyl(0.075, 0.07, 14), mc[0], tr([mx, my + 0.08, mz], null, [1, 0.16, 1]));
      b.add(M.cyl(0.065, 0.065, 14), mc[1], tr([mx, my + 0.158, mz], null, [1, 0.005, 1]));
      b.add(M.torus(0.04, 0.012, 0, 6, 12), mc[0], tr([mx - 0.08, my + 0.08, mz], [0, 0, 0]));
      if (mug === 'mug_cocoa') { b.add(M.rbox(0.03, 0.03, 0.03, 0.008), 0xFFFFFF, tr([mx + 0.02, my + 0.17, mz])); b.add(M.rbox(0.03, 0.03, 0.03, 0.008), 0xFFFFFF, tr([mx - 0.02, my + 0.17, mz + 0.02])); }
    }
    if (!any) return null;
    return { geo: b.build(), glows: glows };
  };

  /* ------------------------------------------------------------ صندوق */
  M.CHEST = {
    common: { body: 0xA0703C, metal: 0x9CA3AF, gem: 0xFDE68A, glow: 0xFFE7A8 },
    rare: { body: 0x2563EB, metal: 0xE5E7EB, gem: 0x67E8F9, glow: 0x7DD3FC },
    epic: { body: 0x7E22CE, metal: 0xF5B800, gem: 0xF472B6, glow: 0xE9D5FF }
  };
  M.chest = function (rarity) {
    var c = M.CHEST[rarity] || M.CHEST.common, root = new T.Group();
    var b = new Builder();
    b.add(M.rbox(0.9, 0.52, 0.62, 0.05), c.body, tr([0, 0.26, 0]));
    [-0.27, 0.27].forEach(function (x) { b.add(M.rbox(0.1, 0.54, 0.65, 0.02), c.metal, tr([x, 0.27, 0])); });
    b.add(M.rbox(0.94, 0.06, 0.66, 0.02), c.metal, tr([0, 0.52, 0]));
    b.add(M.rbox(0.16, 0.2, 0.06, 0.02), c.metal, tr([0, 0.46, 0.32]));
    b.add(M.sphere(8), 0x1F2937, tr([0, 0.44, 0.355], null, [0.025, 0.04, 0.01]));
    if (rarity === 'epic' || rarity === 'rare') {
      [-0.27, 0.27].forEach(function (x) { b.add(M.sphere(10), c.gem, tr([x, 0.3, 0.335], null, [0.05, 0.05, 0.025])); });
    }
    var base = M.mesh(b.build(), null, 0.02);
    var lb = new Builder();
    lb.add(M.cyl(0.31, 0.31, 16, false), c.body, tr([0, 0, 0.31], [0, 0, PI / 2], [1, 0.9, 1]));
    [-0.27, 0.27].forEach(function (x) { lb.add(M.cyl(0.325, 0.325, 16, false), c.metal, tr([x, 0, 0.31], [0, 0, PI / 2], [1, 0.1, 1])); });
    var lidGeo = lb.build();
    // فقط نیمهٔ بالای استوانه دیده می‌شود؛ نیمهٔ پایین داخل بدنه پنهان است
    var lid = M.mesh(lidGeo, null, 0.02);
    var pivot = new T.Group(); pivot.position.set(0, 0.55, -0.31); lid.position.set(0, -0.0, 0);
    pivot.add(lid); root.add(base); root.add(pivot);
    root.userData.lid = pivot;
    root.userData.rarity = rarity;
    return root;
  };
})();
