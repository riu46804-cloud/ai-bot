/* هفت‌خانِ تمرکز — ابزارهای مشترک، پل اندروید و ذخیرهٔ تنظیمات. */
(function () {
  'use strict';
  var R3 = window.R3 = window.R3 || {};

  var FA = '۰۱۲۳۴۵۶۷۸۹';
  R3.fa = function (v) { return String(v).replace(/[0-9]/g, function (d) { return FA[+d]; }); };
  R3.num = function (n) {
    n = Math.round(+n || 0);
    var s = Math.abs(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
    return (n < 0 ? '-' : '') + R3.fa(s);
  };
  R3.dec = function (x) { return R3.fa(String(x).replace('.', '٫')); };
  R3.mult = function (m) { return '×' + R3.dec(m); };
  R3.clock = function (sec) {
    sec = Math.max(0, Math.floor(sec));
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    var t = (h ? h + ':' + (m < 10 ? '0' : '') + m : (m < 10 ? '0' : '') + m) + ':' + (s < 10 ? '0' : '') + s;
    return R3.fa(t);
  };
  /** «۱۲ دقیقه» / «۱ ساعت و ۵ دقیقه» */
  R3.dur = function (sec) {
    sec = Math.max(0, Math.round(sec));
    if (sec < 60) return R3.fa(sec) + ' ثانیه';
    var m = Math.ceil(sec / 60);
    if (m < 60) return R3.fa(m) + ' دقیقه';
    var h = Math.floor(m / 60), mm = m % 60;
    return R3.fa(h) + ' ساعت' + (mm ? ' و ' + R3.fa(mm) + ' دقیقه' : '');
  };
  R3.clamp = function (v, a, b) { return v < a ? a : (v > b ? b : v); };
  R3.lerp = function (a, b, t) { return a + (b - a) * t; };
  R3.damp = function (a, b, lambda, dt) { return R3.lerp(a, b, 1 - Math.exp(-lambda * dt)); };
  R3.ease = {
    outCubic: function (t) { return 1 - Math.pow(1 - t, 3); },
    inCubic: function (t) { return t * t * t; },
    inOutSine: function (t) { return -(Math.cos(Math.PI * t) - 1) / 2; },
    outBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    outElastic: function (t) { if (t === 0 || t === 1) return t; return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1; }
  };
  R3.hash = function (s) {
    s = String(s); var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  };
  R3.rng = function (seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0; var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  R3.now = function () { return performance.now() / 1000; };
  R3.$ = function (id) { return document.getElementById(id); };
  /** ساخت عنصر؛ متن همیشه با textContent می‌رود تا نام کاربرها هرگز HTML تفسیر نشود. */
  R3.el = function (tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = String(text);
    return e;
  };
  R3.kids = function (parent) {
    for (var i = 1; i < arguments.length; i++) { var c = arguments[i]; if (c) parent.appendChild(c); }
    return parent;
  };
  R3.tap = function (el, fn) {
    el.addEventListener('click', function (e) { e.stopPropagation(); if (R3.sfx) R3.sfx.play('tap'); fn(e); });
    return el;
  };

  /* ------------------------------------------------------------ تنظیمات */
  var mem = {};
  R3.store = {
    get: function (k, d) {
      try { var v = localStorage.getItem('r3.' + k); return v === null ? d : JSON.parse(v); }
      catch (e) { return mem.hasOwnProperty(k) ? mem[k] : d; }
    },
    set: function (k, v) {
      mem[k] = v;
      try { localStorage.setItem('r3.' + k, JSON.stringify(v)); } catch (e) { /* حالت خصوصی */ }
    }
  };

  /* ------------------------------------------------------------ پل اندروید */
  // اپ اندروید شیء AndroidR3 را تزریق می‌کند. اگر نبود (پیش‌نمایش مرورگر)،
  // r3-demo.js یک سرور خیالی می‌سازد.
  var rid = 0, pending = {};
  R3.bridge = {
    native: !!(window.AndroidR3 && window.AndroidR3.post),
    mock: null,
    send: function (type, data) {
      data = data || {};
      var json = JSON.stringify(data);
      try {
        if (window.AndroidR3 && window.AndroidR3.post) { window.AndroidR3.post(String(type), json); return; }
        if (R3.bridge.mock) setTimeout(function () { R3.bridge.mock(type, JSON.parse(json)); }, 0);
      } catch (e) { if (window.console) console.error('bridge', e); }
    },
    /** درخواستی که جواب می‌خواهد؛ جواب با {t:'result', rid} برمی‌گردد. */
    request: function (type, data, cb) {
      rid += 1;
      var id = rid;
      data = data || {};
      data.rid = id;
      pending[id] = { cb: cb, at: Date.now(), type: type };
      R3.bridge.send(type, data);
      setTimeout(function () {
        if (pending[id]) { var p = pending[id]; delete pending[id]; p.cb({ ok: false, error: 'پاسخی نرسید؛ اتصال را بررسی کن' }); }
      }, 20000);
      return id;
    },
    resolve: function (msg) {
      var p = pending[msg.rid];
      if (!p) return;
      delete pending[msg.rid];
      try { p.cb(msg); } catch (e) { if (window.console) console.error(e); }
    }
  };
  R3.haptic = function (kind) {
    if (!R3.settings || !R3.settings.haptic) return;
    R3.bridge.send('haptic', { kind: kind || 'light' });
  };

  window.addEventListener('error', function (e) {
    try { R3.bridge.send('debug', { msg: String(e.message || e).slice(0, 300), src: String(e.filename || '').slice(-40), line: e.lineno || 0 }); } catch (x) { }
  });
})();
