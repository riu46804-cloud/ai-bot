/* هفت‌خانِ تمرکز — صحنهٔ سه‌بعدی: رندر، دوربین، آواتارها، خان، گوی‌های انرژی،
   ذره‌ها، صندوق و لمس. منطق بازی در r3-main.js است؛ این فایل فقط نمایش می‌دهد. */
(function () {
  'use strict';
  var R3 = window.R3, T = THREE, M = R3.models, E = R3.env, PI = Math.PI;
  var W = R3.world = { ready: false, hooks: {} };
  var V3 = T.Vector3;

  var renderer, scene, camera, hemi, sun, envObj = null, boss = null, container;
  var raf = 0, running = false, lastT = 0, lastDraw = 0, clockT = 0, pxScale = 400;
  var quality = 1, maxQuality = 2, fpsCap = 0, calm = false, ambient = false;
  var view = { w: 1, h: 1, dpr: 1 };
  var tagsEl, fxEl;
  var tmpV = new V3(), tmpV2 = new V3();

  W.SPECIES_EMOJI = { cat: '🐱', dog: '🐶', owl: '🦉', rabbit: '🐰', fox: '🦊', panda: '🐼', bear: '🐻' };
  W.TIER_COLOR = [0xFFF3C4, 0xFFE08A, 0xFF9A3D, 0x60A5FA, 0xFFD54F];
  W.MULT = [1, 1.5, 2, 3, 4];

  /* ================================================================ ذره‌ها */
  var CELLS = [[0, 0.5], [0.5, 0.5], [0, 0], [0.5, 0]]; // dot, star, petal, square
  function Pool(max, additive) {
    this.max = max; this.n = 0;
    this.pos = new Float32Array(max * 3); this.col = new Float32Array(max * 3);
    this.siz = new Float32Array(max); this.alp = new Float32Array(max); this.cel = new Float32Array(max); this.rot = new Float32Array(max);
    this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.ttl = new Float32Array(max);
    this.s0 = new Float32Array(max); this.s1 = new Float32Array(max); this.grav = new Float32Array(max); this.drag = new Float32Array(max); this.spin = new Float32Array(max);
    var g = new T.BufferGeometry();
    this.aPos = new T.BufferAttribute(this.pos, 3).setUsage(T.DynamicDrawUsage);
    this.aCol = new T.BufferAttribute(this.col, 3).setUsage(T.DynamicDrawUsage);
    this.aSiz = new T.BufferAttribute(this.siz, 1).setUsage(T.DynamicDrawUsage);
    this.aAlp = new T.BufferAttribute(this.alp, 1).setUsage(T.DynamicDrawUsage);
    this.aCel = new T.BufferAttribute(this.cel, 1).setUsage(T.DynamicDrawUsage);
    this.aRot = new T.BufferAttribute(this.rot, 1).setUsage(T.DynamicDrawUsage);
    g.setAttribute('position', this.aPos); g.setAttribute('color', this.aCol); g.setAttribute('aSize', this.aSiz);
    g.setAttribute('aAlpha', this.aAlp); g.setAttribute('aCell', this.aCel); g.setAttribute('aRot', this.aRot);
    g.setDrawRange(0, 0);
    this.mat = new T.ShaderMaterial({
      uniforms: { uPx: { value: 400 }, uTex: { value: M.atlas } },
      vertexShader: [
        'attribute float aSize, aAlpha, aCell, aRot; attribute vec3 color; uniform float uPx;',
        'varying vec3 vC; varying float vA; varying vec2 vCell; varying float vR;',
        'void main(){ vC = color; vA = aAlpha; vR = aRot;',
        '  vCell = aCell < 0.5 ? vec2(0.0, 0.5) : (aCell < 1.5 ? vec2(0.5, 0.5) : (aCell < 2.5 ? vec2(0.0, 0.0) : vec2(0.5, 0.0)));',
        '  vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv;',
        '  gl_PointSize = aSize * uPx / max(0.3, -mv.z); }'].join('\n'),
      fragmentShader: [
        'uniform sampler2D uTex; varying vec3 vC; varying float vA; varying vec2 vCell; varying float vR;',
        'void main(){ vec2 c = gl_PointCoord - 0.5; float s = sin(vR), co = cos(vR); c = mat2(co, -s, s, co) * c * 1.15 + 0.5;',
        '  if (c.x < 0.0 || c.y < 0.0 || c.x > 1.0 || c.y > 1.0) discard;',
        '  vec4 t = texture2D(uTex, vCell + vec2(c.x, 1.0 - c.y) * 0.5); float a = t.a * vA; if (a < 0.01) discard;',
        '  gl_FragColor = vec4(vC, a); }'].join('\n'),
      transparent: true, depthWrite: false, blending: additive ? T.AdditiveBlending : T.NormalBlending
    });
    this.points = new T.Points(g, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = additive ? 5 : 4;
    this.geo = g;
  }
  var _c = new T.Color();
  Pool.prototype.emit = function (o) {
    var n = o.n || 1, mult = o.noScale ? 1 : W.fxMult();
    n = Math.max(o.min || 1, Math.round(n * mult));
    var base = o.p, sp = o.spread || 0, vs = o.vs || 0, cols = o.colors || [o.color || 0xffffff];
    for (var k = 0; k < n; k++) {
      if (this.n >= this.max) return;
      var i = this.n++, j = i * 3;
      this.pos[j] = base[0] + (Math.random() - 0.5) * sp; this.pos[j + 1] = base[1] + (Math.random() - 0.5) * (o.spreadY === undefined ? sp : o.spreadY); this.pos[j + 2] = base[2] + (Math.random() - 0.5) * sp;
      var v = o.v || [0, 0, 0];
      if (o.radial) {
        var th = Math.random() * PI * 2, ph = Math.acos(Math.random() * 2 - 1), sp2 = o.radial * (0.4 + Math.random() * 0.6);
        this.vel[j] = Math.sin(ph) * Math.cos(th) * sp2 + v[0]; this.vel[j + 1] = Math.abs(Math.cos(ph)) * sp2 * (o.upBias || 1) + v[1]; this.vel[j + 2] = Math.sin(ph) * Math.sin(th) * sp2 + v[2];
      } else {
        this.vel[j] = v[0] + (Math.random() - 0.5) * vs; this.vel[j + 1] = v[1] + (Math.random() - 0.5) * vs; this.vel[j + 2] = v[2] + (Math.random() - 0.5) * vs;
      }
      _c.set(cols[Math.floor(Math.random() * cols.length)]);
      this.col[j] = _c.r; this.col[j + 1] = _c.g; this.col[j + 2] = _c.b;
      var ttl = (o.life || 1) * (0.7 + Math.random() * 0.6);
      this.ttl[i] = ttl; this.life[i] = 0;
      this.s0[i] = (o.size || 0.2) * (0.7 + Math.random() * 0.6); this.s1[i] = o.sizeEnd === undefined ? this.s0[i] * 0.3 : o.sizeEnd;
      this.grav[i] = o.grav || 0; this.drag[i] = o.drag || 0; this.cel[i] = o.cell || 0;
      this.rot[i] = Math.random() * 6.28; this.spin[i] = (o.spin || 0) * (Math.random() - 0.5) * 2;
      this.alp[i] = 0; this.siz[i] = this.s0[i];
    }
  };
  Pool.prototype.update = function (dt) {
    var i = 0;
    while (i < this.n) {
      this.life[i] += dt;
      if (this.life[i] >= this.ttl[i]) { this.kill(i); continue; }
      var j = i * 3, d = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[j] *= d; this.vel[j + 1] = this.vel[j + 1] * d - this.grav[i] * dt; this.vel[j + 2] *= d;
      this.pos[j] += this.vel[j] * dt; this.pos[j + 1] += this.vel[j + 1] * dt; this.pos[j + 2] += this.vel[j + 2] * dt;
      var t = this.life[i] / this.ttl[i];
      this.alp[i] = t < 0.12 ? t / 0.12 : (1 - (t - 0.12) / 0.88);
      this.siz[i] = R3.lerp(this.s0[i], this.s1[i], t);
      this.rot[i] += this.spin[i] * dt;
      i++;
    }
    this.geo.setDrawRange(0, this.n);
    if (this.n) { this.aPos.needsUpdate = this.aCol.needsUpdate = this.aSiz.needsUpdate = this.aAlp.needsUpdate = this.aCel.needsUpdate = this.aRot.needsUpdate = true; }
  };
  Pool.prototype.kill = function (i) {
    var l = --this.n;
    if (i !== l) {
      var a = i * 3, b = l * 3;
      for (var k = 0; k < 3; k++) { this.pos[a + k] = this.pos[b + k]; this.col[a + k] = this.col[b + k]; this.vel[a + k] = this.vel[b + k]; }
      this.siz[i] = this.siz[l]; this.alp[i] = this.alp[l]; this.cel[i] = this.cel[l]; this.rot[i] = this.rot[l]; this.life[i] = this.life[l]; this.ttl[i] = this.ttl[l];
      this.s0[i] = this.s0[l]; this.s1[i] = this.s1[l]; this.grav[i] = this.grav[l]; this.drag[i] = this.drag[l]; this.spin[i] = this.spin[l];
    }
  };
  var fxAdd, fxNorm;
  W.fxMult = function () { return (calm ? 0.4 : 1) * (quality === 0 ? 0.45 : (quality === 1 ? 0.75 : 1)) * (ambient ? 0.5 : 1); };

  /* ================================================================ برچسب‌ها و اعداد DOM */
  function project(v, out) {
    tmpV2.copy(v).project(camera);
    out.x = (tmpV2.x * 0.5 + 0.5) * view.w; out.y = (-tmpV2.y * 0.5 + 0.5) * view.h; out.vis = tmpV2.z < 1 && tmpV2.z > -1;
    return out;
  }
  W.project = function (v) { return project(v, {}); };
  var dmgCount = 0;
  W.number = function (pos3, text, cls, force) {
    if (!fxEl) return;
    if (!force && dmgCount > (quality === 0 ? 10 : 22)) return;
    var s = project(pos3, {});
    if (!s.vis) return;
    var e = R3.el('div', 'dmg ' + (cls || ''), text);
    e.style.setProperty('--x', Math.round(s.x + (Math.random() - 0.5) * 26) + 'px');
    e.style.setProperty('--y', Math.round(s.y) + 'px');
    fxEl.appendChild(e); dmgCount++;
    setTimeout(function () { if (e.parentNode) e.parentNode.removeChild(e); dmgCount--; }, calm ? 950 : 1100);
  };
  W.floatEmoji = function (pos3, emoji, n) {
    if (!fxEl) return;
    var s = project(pos3, {});
    if (!s.vis) return;
    n = n || 1;
    for (var i = 0; i < n; i++) {
      (function (k) {
        setTimeout(function () {
          var e = R3.el('div', 'floatemo', emoji);
          e.style.setProperty('--x', Math.round(s.x - 18 + (Math.random() - 0.5) * 40) + 'px');
          e.style.setProperty('--y', Math.round(s.y - 30) + 'px');
          e.style.setProperty('--dx', Math.round((Math.random() - 0.5) * 80) + 'px');
          e.style.setProperty('--rot', Math.round((Math.random() - 0.5) * 50) + 'deg');
          fxEl.appendChild(e);
          setTimeout(function () { if (e.parentNode) e.parentNode.removeChild(e); }, 2300);
        }, k * 160);
      })(i);
    }
  };

  /* ================================================================ صندلی‌ها و آدم‌ها */
  var ME_SEAT = [0, 2.5];
  var SEATS = [[-2.1, 0.7], [2.1, 0.7], [-0.9, -1.1], [0.9, -1.1], [-2.7, -1.1], [2.7, -1.1], [-0.95, -2.9], [0.95, -2.9], [-2.8, -2.9], [2.8, -2.9], [-1.8, -4.6], [1.8, -4.6]];
  var seatOwner = SEATS.map(function () { return null; });
  var people = {}, meP = null, theme = 'library', night = false;
  W.people = people;

  function makeTag(p) {
    var e = R3.el('div', 'tag' + (p.me ? ' me' : ''));
    p.tagFl = R3.el('span', 'fl', ''); p.tagNm = R3.el('span', 'nm', ''); p.tagSt = R3.el('span', 'st', '');
    R3.kids(e, p.tagFl, p.tagNm, p.tagSt);
    tagsEl.appendChild(e);
    return e;
  }
  function shortName(s) { s = String(s || '').trim(); return s.length > 12 ? s.slice(0, 11) + '…' : (s || 'هم‌اتاقی'); }
  function tagRefresh(p) {
    var st = p.rest ? '☕' : (p.state === 'studying' ? '📖' : (p.state === 'sleeping' ? '💤' : ''));
    var fl = p.state === 'studying' && p.combo > 0 ? ['', '✨', '🔥', '💙', '⚡'][p.combo] : '';
    var nm = p.me ? 'تو' : shortName(p.name);
    var key = st + '|' + fl + '|' + nm;
    if (key === p.tagKey) return;
    p.tagKey = key;
    p.tagFl.textContent = fl; p.tagNm.textContent = nm; p.tagSt.textContent = st;
    p.tag.className = 'tag' + (p.me ? ' me' : '') + (p.state === 'sleeping' ? ' sleep' : '');
  }

  function buildDesk(p) {
    if (p.desk) { p.root.remove(p.desk); p.desk.geometry.dispose(); }
    var g = M.deskGeo(theme, p.me ? 1 : (R3.hash(p.id) % 997), p.me);
    p.desk = M.mesh(g, null, quality > 0 ? 0.02 : 0);
    p.desk.userData.pick = { type: p.me ? 'me' : 'avatar', id: p.id };
    p.root.add(p.desk);
  }
  function setDeskItems(p, desk) {
    if (p.items) { p.root.remove(p.items); p.items.traverse(function (o) { if (o.geometry && !o.userData.outline && !o.isSprite) o.geometry.dispose(); }); p.items = null; }
    var it = M.deskItems(desk);
    if (!it) return;
    var grp = new T.Group(), mesh = M.mesh(it.geo, null, quality > 0 ? 0.012 : 0);
    grp.add(mesh);
    p.itemGlows = [];
    it.glows.forEach(function (g) {
      var s = E.glowSprite(g.c, g.s * (night ? 1.4 : 0.8), night ? 0.85 : 0.35);
      s.position.set(g.p[0], g.p[1], g.p[2]); grp.add(s); p.itemGlows.push(s);
    });
    p.items = grp; p.root.add(grp);
  }
  function buildAvatar(p) {
    if (p.avatar) { p.root.remove(p.avatar); }
    p.avatar = M.avatar(p.kind);
    p.parts = p.avatar.userData.parts;
    p.avatar.traverse(function (o) { if (o.isMesh && !o.userData.outline) o.userData.pick = { type: p.me ? 'me' : 'avatar', id: p.id }; });
    p.root.add(p.avatar);
    p.hatKey = null; setHat(p, p.hat);
  }
  function setHat(p, key) {
    key = key || '';
    if (p.hatKey === key) return;
    p.hatKey = key;
    var a = p.parts.hat;
    while (a.children.length) a.remove(a.children[0]);
    if (key) {
      var h = M.hat(key);
      h.traverse(function (o) { if (o.isMesh && !o.userData.outline) o.userData.pick = { type: p.me ? 'me' : 'avatar', id: p.id }; });
      a.add(h);
      if (p.ready) { h.scale.setScalar(0.01); p.hatPop = 0; }
    }
  }
  function makeAura(p) {
    var s = E.glowSprite(0xFFFFFF, 1.8, 0);
    s.position.set(0, 1.25, -0.1); s.renderOrder = 3; p.root.add(s);
    var ring = new T.Mesh(new T.RingGeometry(0.62, 0.78, 32), M.basic(0xFFD54F, { transparent: true, opacity: 0, additive: true, depthWrite: false, side: T.DoubleSide }));
    ring.rotation.x = -PI / 2; ring.position.y = 0.04; p.root.add(ring);
    var shadow = new T.Mesh(new T.CircleGeometry(0.75, 20), new T.MeshBasicMaterial({ map: M.glowTex, color: 0x000000, transparent: true, opacity: 0.32, depthWrite: false }));
    shadow.rotation.x = -PI / 2; shadow.position.set(0, 0.02, 0.15); shadow.scale.set(1.25, 1, 1); p.root.add(shadow);
    p.aura = { s: s, ring: ring, k: 0 };
  }
  function seatPos(p) { return p.me ? ME_SEAT : SEATS[p.seat]; }

  function addPerson(d) {
    var p = {
      id: d.id, me: !!d.me, name: d.name, kind: d.kind || 'cat', hat: d.hat || '', state: d.state || 'idle', combo: d.combo || 0, rest: !!d.rest,
      minutes: d.minutes || 0, root: new T.Group(), appear: 0, leaving: false, ph: Math.random() * 10,
      blinkT: 1 + Math.random() * 3, lookT: 0, lookY: 0, lookX: 0, orbT: 1 + Math.random() * 2, cel: 0, tagKey: '', ready: false, jump: 0
    };
    if (!p.me) {
      var seat = -1;
      for (var i = 0; i < SEATS.length; i++) if (!seatOwner[i]) { seat = i; break; }
      if (seat < 0) return null;
      seatOwner[seat] = p.id; p.seat = seat;
    }
    var sp = seatPos(p);
    p.root.position.set(sp[0], 0, sp[1]);
    // کمی رو به مرکز تا صحنه گرم‌تر باشد
    p.root.rotation.y = p.me ? 0 : -sp[0] * 0.05;
    buildDesk(p); buildAvatar(p); makeAura(p);
    p.tag = makeTag(p);
    p.root.scale.setScalar(0.01);
    scene.add(p.root);
    people[p.id] = p;
    if (p.me) meP = p;
    if (W.ready && !p.me) {
      fxAdd.emit({ p: [sp[0], 1.2, sp[1]], n: 22, radial: 2.4, color: 0xFFF3C4, colors: [0xFFF3C4, 0xFFD54F, 0x7DD3FC], size: 0.22, life: 0.8, drag: 2.5, cell: 1, spin: 4 });
      R3.sfx.play('whoosh');
    }
    return p;
  }
  function removePerson(p) {
    p.leaving = true;
    fxNorm.emit({ p: [p.root.position.x, 1.0, p.root.position.z], n: 14, radial: 1.6, color: 0xFFFFFF, size: 0.4, sizeEnd: 0.7, life: 0.7, drag: 3, cell: 0 });
  }
  function destroyPerson(p) {
    scene.remove(p.root);
    if (p.tag && p.tag.parentNode) p.tag.parentNode.removeChild(p.tag);
    if (p.desk) p.desk.geometry.dispose();
    if (p.aura) { p.aura.ring.geometry.dispose(); p.aura.ring.material.dispose(); p.aura.s.material.dispose(); }
    if (!p.me && p.seat >= 0) seatOwner[p.seat] = null;
    delete people[p.id];
    if (p === meP) meP = null;
  }

  /** همگام‌سازی فهرست آدم‌ها: [{id, me, name, kind, hat, state, combo, rest, minutes}] */
  W.syncPeople = function (list) {
    if (!W.ready) return;
    var seen = {};
    list.forEach(function (d) {
      seen[d.id] = true;
      var p = people[d.id];
      if (p && p.leaving) { destroyPerson(p); p = null; }
      if (!p) { p = addPerson(d); if (!p) return; }
      if (d.kind && d.kind !== p.kind) { p.kind = d.kind; buildAvatar(p); fxAdd.emit({ p: [p.root.position.x, 1.4, p.root.position.z], n: 18, radial: 2, colors: [0xFFFFFF, 0xFDE68A], size: 0.25, life: 0.7, drag: 3, cell: 1 }); }
      if (!p.previewHat) setHat(p, d.hat || '');
      p.hat = d.hat || '';
      if (p.state !== d.state && d.state === 'studying' && p.ready) fxAdd.emit({ p: [p.root.position.x, 1.9, p.root.position.z], n: 10, radial: 1.3, color: 0x86EFAC, size: 0.18, life: 0.6, drag: 3, cell: 1 });
      p.state = d.state || 'idle'; p.combo = d.combo || 0; p.rest = !!d.rest; p.name = d.name; p.minutes = d.minutes || 0;
      if (p.me && d.desk !== undefined) {
        var dk = JSON.stringify(d.desk || {});
        if (dk !== p.deskKey) { p.deskKey = dk; setDeskItems(p, d.desk); }
      }
      tagRefresh(p);
    });
    Object.keys(people).forEach(function (id) { var p = people[id]; if (!seen[id] && !p.leaving) removePerson(p); });
  };
  W.person = function (id) { return people[id] || null; };
  W.headPos = function (id, out) {
    var p = people[id]; out = out || new V3();
    if (!p) return out.set(0, 2, 0);
    return out.set(p.root.position.x, 2.25, p.root.position.z);
  };
  W.celebrate = function (id) { var p = people[id]; if (p) p.jump = 1; };
  W.previewHat = function (key) {
    if (!meP) return;
    if (key === null || key === undefined) { meP.previewHat = false; setHat(meP, meP.hat); return; }
    meP.previewHat = true; setHat(meP, key);
    fxAdd.emit({ p: [meP.root.position.x, 2.35, meP.root.position.z], n: 14, radial: 1.5, colors: [0xFFFFFF, 0xFDE68A, 0xC4B5FD], size: 0.2, life: 0.6, drag: 3, cell: 1 });
  };

  function updatePerson(p, dt, t) {
    // ظاهر شدن / رفتن
    if (p.leaving) {
      p.appear -= dt * 3;
      if (p.appear <= 0) { destroyPerson(p); return; }
    } else if (p.appear < 1) { p.appear = Math.min(1, p.appear + dt * 2.2); if (p.appear >= 1) p.ready = true; }
    var s = p.leaving ? Math.max(0.01, p.appear) : Math.max(0.01, R3.ease.outBack(p.appear));
    p.root.scale.setScalar(s);
    var parts = p.parts, head = parts.head, body = parts.body, eyes = parts.eyes;
    var st = p.rest ? 'rest' : p.state, ph = p.ph, k = calm ? 0.5 : 1;
    var hx = 0, hy = 0, hz = 0, by = 0, eyeY = 1;
    if (st === 'studying') {
      hx = 0.34 + Math.sin(t * 1.3 + ph) * 0.05 * k;
      hy = Math.sin(t * 0.45 + ph) * 0.12 * k;
      by = Math.sin(t * 2.1 + ph) * 0.012;
      if (Math.sin(t * 0.37 + ph * 3) > 0.985) hx -= 0.25; // نگاه کوتاه به بالا
    } else if (st === 'sleeping') {
      hx = 0.55; hz = 0.22; eyeY = 0.12;
      by = Math.sin(t * 1.4 + ph) * 0.02;
      body.scale.y = 1 + Math.sin(t * 1.4 + ph) * 0.025;
      if ((t + ph) % 3.2 < dt && !ambient) W.floatEmoji(tmpV.set(p.root.position.x + 0.3, 2.3, p.root.position.z), '💤', 1);
    } else {
      p.lookT -= dt;
      if (p.lookT <= 0) { p.lookT = 1.5 + Math.random() * 3.5; p.lookY = (Math.random() - 0.5) * 1.0; p.lookX = -0.05 + (Math.random() - 0.5) * 0.2; }
      hx = p.lookX; hy = p.lookY;
      by = Math.sin(t * 1.6 + ph) * 0.015;
      if (st === 'rest') { hz = Math.sin(t * 1.2 + ph) * 0.1; hx = -0.08; }
    }
    if (st !== 'sleeping') body.scale.y = 1;
    head.rotation.x = R3.damp(head.rotation.x, hx, 5, dt);
    head.rotation.y = R3.damp(head.rotation.y, hy, 3, dt);
    head.rotation.z = R3.damp(head.rotation.z, hz, 4, dt);
    // پلک
    if (st !== 'sleeping') {
      p.blinkT -= dt;
      if (p.blinkT < 0) { eyeY = 0.1; if (p.blinkT < -0.12) p.blinkT = 2 + Math.random() * 4; }
    }
    eyes.scale.y = R3.damp(eyes.scale.y, eyeY, 30, dt);
    // پرش جشن
    var jy = 0;
    if (p.jump > 0) { p.jump = Math.max(0, p.jump - dt * 1.6); var jt = 1 - p.jump; jy = Math.abs(Math.sin(jt * PI * 2)) * 0.35 * p.jump; }
    p.avatar.position.y = by + jy;
    if (p.avatar.userData.tail) p.avatar.userData.tail.rotation.y = Math.sin(t * (st === 'studying' ? 2.4 : 1.2) + ph) * 0.18;
    if (p.hatPop !== undefined && p.hatPop < 1) {
      p.hatPop = Math.min(1, p.hatPop + dt * 2.5);
      var hc = parts.hat.children[0]; if (hc) hc.scale.setScalar(Math.max(0.01, R3.ease.outElastic(p.hatPop)));
    }
    var hatC = parts.hat.children[0];
    if (hatC) hatC.traverse(function (o) { if (o.userData.pulse) o.material.opacity = 0.5 + Math.sin(t * 3 + ph) * 0.25; });
    // هالهٔ کمبو
    var tier = st === 'studying' ? p.combo : 0, a = p.aura;
    var targetK = st === 'studying' ? (0.25 + tier * 0.2) : 0;
    a.k = R3.damp(a.k, targetK, 3, dt);
    a.s.material.color.setHex(W.TIER_COLOR[tier]);
    a.s.material.opacity = a.k * (0.8 + Math.sin(t * 4 + ph) * 0.2);
    a.s.scale.setScalar(1.4 + tier * 0.35 + Math.sin(t * 3 + ph) * 0.08);
    a.ring.material.opacity = tier >= 3 ? 0.5 + Math.sin(t * 5) * 0.2 : R3.damp(a.ring.material.opacity, 0, 4, dt);
    a.ring.material.color.setHex(W.TIER_COLOR[tier]);
    a.ring.rotation.z = t * 1.5;
    if (tier >= 2 && !p.leaving && Math.random() < dt * (tier * 5) * W.fxMult()) {
      fxAdd.emit({ p: [p.root.position.x, 0.9, p.root.position.z], spread: 0.9, spreadY: 0.4, v: [0, 1.4, 0], vs: 0.3, n: 1, noScale: true, color: W.TIER_COLOR[tier], size: 0.25, sizeEnd: 0.02, life: 0.9, cell: 0 });
    }
    // گوی انرژی
    if (st === 'studying' && boss && boss.alive && !p.leaving && p.ready) {
      p.orbT -= dt;
      if (p.orbT <= 0) {
        var interval = p.me ? 2.0 : (2.6 / (0.85 + tier * 0.3)) * (0.8 + Math.random() * 0.4);
        var dmg = Math.max(1, Math.round(W.MULT[tier] * (p.me ? (p.orbAcc || interval) : interval)));
        p.orbAcc = 0;
        p.orbT = interval;
        launchOrb(p, dmg, tier);
      }
    } else { p.orbT = Math.max(p.orbT, 0.6); }
  }

  /* ================================================================ گوی‌ها */
  var orbs = [], orbPool = [];
  function orbSprite() {
    var s = orbPool.pop();
    if (!s) { s = E.glowSprite(0xFFFFFF, 0.6, 1); s.renderOrder = 6; }
    scene.add(s); return s;
  }
  function launchOrb(p, dmg, tier) {
    var from = new V3(p.root.position.x, 1.95, p.root.position.z + 0.15);
    var to = bossCenter(new V3()).add(new V3((Math.random() - 0.5) * 1.2, (Math.random() - 0.3) * 1.2, 0.6));
    var mid = from.clone().lerp(to, 0.5);
    mid.y += 3 + Math.random() * 1.5; mid.x += (Math.random() - 0.5) * 3;
    var col = p.me ? 0xFFD54F : W.TIER_COLOR[tier];
    var s = orbSprite(); s.material.color.setHex(col); s.scale.setScalar(p.me ? 0.75 : 0.5 + tier * 0.06); s.position.copy(from);
    orbs.push({ s: s, a: from, b: mid, c: to, t: 0, dur: 0.85 + Math.random() * 0.35, dmg: dmg, me: p.me, tier: tier, col: col, pid: p.id });
    if (p.me) R3.sfx.play('orb');
    fxAdd.emit({ p: [from.x, from.y, from.z], n: 5, radial: 1.2, color: col, size: 0.16, life: 0.4, drag: 4, cell: 1 });
  }
  function updateOrbs(dt) {
    for (var i = orbs.length - 1; i >= 0; i--) {
      var o = orbs[i];
      o.t += dt / o.dur;
      var t = Math.min(1, o.t), u = 1 - t;
      var x = u * u * o.a.x + 2 * u * t * o.b.x + t * t * o.c.x;
      var y = u * u * o.a.y + 2 * u * t * o.b.y + t * t * o.c.y;
      var z = u * u * o.a.z + 2 * u * t * o.b.z + t * t * o.c.z;
      o.s.position.set(x, y, z);
      if (Math.random() < 0.8) fxAdd.emit({ p: [x, y, z], n: 1, noScale: true, color: o.col, size: o.me ? 0.3 : 0.2, sizeEnd: 0.02, life: 0.35, cell: 0 });
      if (o.t >= 1) {
        orbs.splice(i, 1); scene.remove(o.s); orbPool.push(o.s);
        bossHit(o);
      }
    }
  }

  /* ================================================================ خان */
  function bossCenter(out) {
    out = out || new V3();
    if (!boss) return out.set(0, 2.5, E.BOSS_Z);
    return out.set(0, E.PLAT_H + boss.r.height * 0.55, E.BOSS_Z);
  }
  W.bossCenter = function () { return bossCenter(new V3()); };
  function bossHit(o) {
    var c = o.c;
    fxAdd.emit({ p: [c.x, c.y, c.z], n: o.me ? 16 : 8, radial: o.me ? 3.2 : 2.2, colors: [o.col, 0xFFFFFF], size: o.me ? 0.32 : 0.22, life: 0.5, drag: 3, cell: 1, spin: 6 });
    if (!boss || !boss.alive) return;
    boss.flash = Math.min(1, boss.flash + (o.me ? 0.9 : 0.45));
    boss.kick = Math.min(1, boss.kick + (o.me ? 0.6 : 0.25));
    var cls = (o.me ? 'me ' : '') + (o.tier >= 2 ? 't' + o.tier : '');
    W.number(c, '-' + R3.num(o.dmg), cls, o.me);
    if (o.me) { R3.sfx.play('hit', { big: o.tier >= 3 }); R3.haptic('tick'); }
    if (W.hooks.hit) W.hooks.hit(o.pid, o.dmg, o.me);
  }
  W.setBoss = function (key, opts) {
    opts = opts || {};
    if (boss && boss.key === key && boss.alive) return;
    if (boss) { R3.bosses.dispose(boss.r); boss = null; }
    var r = R3.bosses.build(key);
    r.root.position.set(0, E.PLAT_H, E.BOSS_Z);
    scene.add(r.root);
    boss = { key: key, r: r, alive: true, flash: 0, kick: 0, roar: 0, spawn: opts.instant ? 1 : 0, dying: 0, enrage: 0, hp: 1, auraT: 0 };
    if (!opts.instant) {
      R3.sfx.play('spawn');
      setTimeout(function () { if (boss && boss.r === r) W.roar(); }, 1500);
    }
  };
  W.roar = function () {
    if (!boss || !boss.alive || boss.roar > 0) return;
    boss.roar = 1;
    R3.sfx.play('roar');
    W.shake(0.35);
    var c = bossCenter(new V3());
    fxAdd.emit({ p: [c.x, c.y + 0.8, c.z + 0.8], n: 40, radial: 5, colors: [boss.r.cfg.auraColor, 0xFFFFFF], size: 0.3, life: 0.9, drag: 2, cell: 0 });
  };
  W.bossHp = function (frac) {
    if (!boss) return;
    var prev = boss.hp;
    boss.hp = frac;
    boss.enrage = frac < 0.25 ? 1 : 0;
    [0.75, 0.5, 0.25].forEach(function (th) { if (prev > th && frac <= th && boss.spawn >= 1) W.roar(); });
  };
  W.bossDefeat = function (done) {
    if (!boss || !boss.alive) { if (done) done(); return; }
    boss.alive = false; boss.dying = 0.0001; boss.done = done;
    orbs.forEach(function (o) { scene.remove(o.s); orbPool.push(o.s); }); orbs.length = 0;
    R3.sfx.play('roar');
    W.shake(0.6);
  };
  function updateBoss(dt, t) {
    if (!boss) return;
    var r = boss.r, cfg = r.cfg, root = r.root, sc = r.scale;
    // ظهور
    if (boss.spawn < 1) {
      boss.spawn = Math.min(1, boss.spawn + dt / 1.6);
      var e = R3.ease.outBack(boss.spawn);
      root.scale.setScalar(Math.max(0.01, e * sc));
      root.position.y = E.PLAT_H - 2.2 * (1 - R3.ease.outCubic(boss.spawn));
      if (Math.random() < 0.6) fxAdd.emit({ p: [0, E.PLAT_H + 0.2, E.BOSS_Z], spread: 3, spreadY: 0.2, v: [0, 3, 0], vs: 1, n: 2, color: cfg.auraColor, size: 0.35, life: 0.9, cell: 1 });
    }
    // شکست
    if (boss.dying > 0) {
      boss.dying += dt / 2.4;
      var d = boss.dying;
      r.mat.emissive.setScalar(Math.sin(d * 40) > 0 ? 0.8 : 0.2);
      root.position.x = (Math.random() - 0.5) * 0.25 * (1 - d);
      if (d > 0.55) {
        var k = (d - 0.55) / 0.45;
        root.scale.setScalar(Math.max(0.01, sc * (1 - R3.ease.inCubic(k))));
        root.rotation.y += dt * 8 * k;
      }
      if (Math.random() < 0.7) fxAdd.emit({ p: [0, E.PLAT_H + r.height * 0.5, E.BOSS_Z], spread: 2, v: [0, 2, 0], vs: 3, n: 3, colors: [cfg.auraColor, 0xFFFFFF, 0xFFD54F], size: 0.4, life: 0.8, cell: 1 });
      if (d >= 1) {
        var c = new V3(0, E.PLAT_H + r.height * 0.5, E.BOSS_Z);
        fxAdd.emit({ p: [c.x, c.y, c.z], n: 160, radial: 9, colors: [cfg.auraColor, 0xFFFFFF, 0xFFD54F, 0xFF8A65], size: 0.45, life: 1.4, drag: 1.5, cell: 1, spin: 5, min: 60 });
        fxNorm.emit({ p: [c.x, c.y + 1, c.z], n: 110, radial: 7, upBias: 1.6, colors: [0xF59E0B, 0xEF4444, 0x22C55E, 0x3B82F6, 0xA855F7, 0xFDE047], size: 0.22, sizeEnd: 0.18, life: 2.6, grav: 4, drag: 0.6, cell: 3, spin: 8, min: 40 });
        W.shake(0.8);
        R3.sfx.play('victory');
        R3.bosses.dispose(r);
        var cb = boss.done; boss = null;
        if (cb) cb();
        return;
      }
      return;
    }
    // حالت عادی
    var en = boss.enrage, spd = 1 + en * 0.6, k2 = calm ? 0.5 : 1;
    var base = r.rest;
    boss.flash = Math.max(0, boss.flash - dt * 5);
    boss.kick = Math.max(0, boss.kick - dt * 4);
    var fl = calm ? boss.flash * 0.4 : boss.flash;
    r.mat.emissive.setRGB(fl * 0.9 + en * (0.18 + Math.sin(t * 6) * 0.1), fl * 0.85, fl * 0.75);
    var y0 = cfg.idle === 'hover' ? 0.35 + Math.sin(t * 1.4) * 0.15 : 0;
    if (boss.spawn >= 1) root.position.y = E.PLAT_H + y0;
    r.body.rotation.z = Math.sin(t * 0.8 * spd) * 0.04 * k2;
    r.body.position.y = Math.sin(t * 1.6 * spd) * 0.05;
    r.body.scale.set(1 + boss.kick * 0.04, 1 - boss.kick * 0.05, 1 + boss.kick * 0.04);
    if (cfg.idle === 'coil') r.body.rotation.y = Math.sin(t * 0.5) * 0.12;
    var roarK = 0;
    if (boss.roar > 0) { boss.roar = Math.max(0, boss.roar - dt / 1.3); roarK = Math.sin((1 - boss.roar) * PI); }
    r.head.rotation.x = Math.sin(t * 0.9) * 0.05 - roarK * 0.45 + boss.kick * 0.12;
    r.head.rotation.y = Math.sin(t * 0.5 * spd) * 0.25 * k2 * (1 - roarK);
    r.head.position.x = base.head.x + (Math.random() - 0.5) * boss.kick * 0.08;
    r.armL.rotation.x = base.armL.x + Math.sin(t * 1.2 * spd) * 0.15 - roarK * 1.3;
    r.armR.rotation.x = base.armR.x + Math.sin(t * 1.2 * spd + 1.5) * 0.15 - roarK * 1.3;
    r.armL.rotation.z = base.armL.z - roarK * 0.4; r.armR.rotation.z = base.armR.z + roarK * 0.4;
    if (r.jaw) r.jaw.rotation.x = roarK * 0.6 + Math.max(0, Math.sin(t * 0.7)) * 0.08;
    if (r.wings) r.wings.forEach(function (w, i) { var s = i ? 1 : -1; w.rotation.z = s * (Math.sin(t * 2.6 * spd) * 0.32 + roarK * 0.4); });
    var eg = 0.75 + Math.sin(t * 5) * 0.15 + en * 0.4 + roarK * 0.5;
    r.eyes.glows.forEach(function (g) { g.scale.setScalar(eg); });
    r.glowSprites.forEach(function (g) { g.scale.setScalar(1 + Math.sin(t * 3) * 0.15); });
    // ذرهٔ هاله
    boss.auraT -= dt;
    if (boss.auraT <= 0 && !ambient) {
      boss.auraT = 0.08 / W.fxMult();
      var h = r.height, a = cfg.aura, col = en ? 0xFF5A3D : cfg.auraColor;
      var px = (Math.random() - 0.5) * 3, pz = E.BOSS_Z + (Math.random() - 0.5) * 2;
      if (a === 'dust') fxNorm.emit({ p: [px, E.PLAT_H + 0.2, pz], v: [(Math.random() - 0.5) * 1.5, 0.6, 0], vs: 0.4, n: 1, noScale: true, color: col, size: 0.5, sizeEnd: 0.9, life: 1.6, drag: 0.5, cell: 0 });
      else if (a === 'snow') fxNorm.emit({ p: [px, E.PLAT_H + Math.random() * h, pz], v: [0, -0.3, 0], vs: 0.6, n: 1, noScale: true, color: col, size: 0.18, life: 1.8, cell: 1, spin: 2 });
      else fxAdd.emit({ p: [px, E.PLAT_H + Math.random() * h * 0.6, pz], v: [0, a === 'magic' ? 0.5 : 1.3, 0], vs: 0.6, n: 1, noScale: true, color: col, size: a === 'magic' ? 0.26 : 0.2, sizeEnd: 0.02, life: 1.4, cell: a === 'magic' ? 1 : 0, spin: 3 });
    }
  }

  /* ================================================================ صندوق‌های روی زمین */
  var pile = [], pileGroup = null, drops = [];
  var PILE_POS = [[1.25, 3.05], [1.62, 2.75], [1.45, 3.4]];
  W.setChestPile = function (list) {
    // list: ['common','rare',...] حداکثر سه تا نمایش داده می‌شود
    if (!pileGroup) return;
    var key = list.slice(0, 3).join(',');
    if (key === pileGroup.userData.key) return;
    pileGroup.userData.key = key;
    while (pileGroup.children.length) pileGroup.remove(pileGroup.children[0]);
    pile = [];
    list.slice(0, 3).forEach(function (r, i) {
      var c = M.chest(r); c.scale.setScalar(0.42);
      c.position.set(PILE_POS[i][0], 0, PILE_POS[i][1]); c.rotation.y = -0.4 + i * 0.5;
      c.traverse(function (o) { if (o.isMesh) o.userData.pick = { type: 'chest' }; });
      var g = E.glowSprite(M.CHEST[r].glow, 1.1, 0.5); g.position.set(0, 0.4, 0); c.add(g); c.userData.glow = g;
      pileGroup.add(c); pile.push(c);
    });
  };
  W.chestDrop = function (rarity) {
    if (!pileGroup) return;
    var c = M.chest(rarity); c.scale.setScalar(0.42);
    var tx = PILE_POS[0][0], tz = PILE_POS[0][1];
    c.position.set(tx, 9, tz); scene.add(c);
    drops.push({ c: c, t: 0, x: tx, z: tz, r: rarity, landed: false });
    R3.sfx.play('whoosh');
  };
  function updatePile(dt, t) {
    pile.forEach(function (c, i) {
      c.position.y = Math.abs(Math.sin(t * 2 + i)) * 0.04;
      if (c.userData.glow) c.userData.glow.material.opacity = 0.35 + Math.sin(t * 3 + i) * 0.2;
      c.userData.lid.rotation.x = -Math.max(0, Math.sin(t * 1.5 + i * 2)) * 0.12;
    });
    for (var i = drops.length - 1; i >= 0; i--) {
      var d = drops[i];
      d.t += dt;
      var y;
      if (d.t < 0.7) y = 9 * (1 - R3.ease.inCubic(d.t / 0.7));
      else { var k = (d.t - 0.7) / 0.6; y = Math.abs(Math.sin(k * PI * 2.2)) * 0.6 * Math.max(0, 1 - k); }
      d.c.position.y = y; d.c.rotation.y += dt * 4 * Math.max(0, 1 - d.t);
      if (!d.landed && d.t >= 0.7) {
        d.landed = true; R3.sfx.play('drop'); W.shake(0.2);
        fxAdd.emit({ p: [d.x, 0.3, d.z], n: 30, radial: 3, colors: [M.CHEST[d.r].glow, 0xFFFFFF], size: 0.25, life: 0.8, drag: 2.5, cell: 1, spin: 5 });
        fxNorm.emit({ p: [d.x, 0.1, d.z], n: 12, radial: 1.5, color: 0xE8DCC8, size: 0.45, sizeEnd: 0.8, life: 0.8, drag: 3, cell: 0 });
      }
      if (d.t > 1.4) { scene.remove(d.c); drops.splice(i, 1); if (W.hooks.dropped) W.hooks.dropped(d.r); }
    }
  }

  /* ================================================================ صحنهٔ بازکردن صندوق */
  var cs = null;
  function raysTex() {
    var c = document.createElement('canvas'); c.width = c.height = 256;
    var g = c.getContext('2d'); g.translate(128, 128);
    for (var i = 0; i < 16; i++) {
      g.rotate(PI / 8);
      var gr = g.createLinearGradient(0, 0, 0, -128); gr.addColorStop(0, 'rgba(255,255,255,.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.beginPath(); g.moveTo(-6, 0); g.lineTo(-20, -128); g.lineTo(20, -128); g.lineTo(6, 0); g.closePath(); g.fill();
    }
    return new T.CanvasTexture(c);
  }
  function ensureChestScene() {
    if (cs) return cs;
    var asp = view.w / Math.max(1, view.h), sc = new T.Scene(), cam = new T.PerspectiveCamera(asp < 1 ? 42 : 30, asp, 0.1, 50);
    cam.position.set(0, 1.7, 6.6); cam.lookAt(0, 0.05, 0);
    sc.add(new T.HemisphereLight(0xFFFFFF, 0x6B5B53, 2.2));
    var dl = new T.DirectionalLight(0xFFF1D6, 2.4); dl.position.set(2, 5, 4); sc.add(dl);
    var rays = new T.Mesh(new T.PlaneGeometry(5, 5), new T.MeshBasicMaterial({ map: raysTex(), transparent: true, opacity: 0, blending: T.AdditiveBlending, depthWrite: false }));
    rays.position.set(0, 0.8, -0.6); sc.add(rays);
    var glow = E.glowSprite(0xFFFFFF, 3.2, 0); glow.position.set(0, 0.6, -0.2); sc.add(glow);
    var pa = new Pool(500, true), pn = new Pool(300, false);
    sc.add(pa.points); sc.add(pn.points);
    cs = { scene: sc, cam: cam, rays: rays, glow: glow, chest: null, t: 0, shake: 0, open: 0, active: false, pa: pa, pn: pn, rarity: 'common' };
    return cs;
  }
  W.chestShow = function (rarity) {
    var c = ensureChestScene();
    if (c.chest) c.scene.remove(c.chest);
    c.rarity = rarity; c.chest = M.chest(rarity); c.chest.scale.setScalar(0.01); c.scene.add(c.chest);
    c.t = 0; c.open = 0; c.shake = 0; c.active = true; c.level = 0;
    c.rays.material.color.setHex(M.CHEST[rarity].glow); c.glow.material.color.setHex(M.CHEST[rarity].glow);
    c.rays.material.opacity = 0; c.glow.material.opacity = 0.25;
    R3.sfx.play('whoosh');
  };
  W.chestShake = function () {
    if (!cs || !cs.active) return;
    cs.level = Math.min(3, cs.level + 1); cs.shake = 1;
    R3.sfx.play('shake'); R3.haptic('light');
    cs.pa.emit({ p: [0, 0.6, 0.2], n: 8 + cs.level * 6, radial: 2 + cs.level, color: M.CHEST[cs.rarity].glow, size: 0.12, life: 0.6, drag: 3, cell: 1, noScale: true });
  };
  W.chestOpen = function () {
    if (!cs || !cs.active) return;
    cs.open = 0.0001;
    R3.sfx.play('open', { rarity: cs.rarity }); R3.haptic('heavy');
    var col = M.CHEST[cs.rarity].glow, n = cs.rarity === 'epic' ? 160 : (cs.rarity === 'rare' ? 110 : 70);
    cs.pa.emit({ p: [0, 0.7, 0], n: n, radial: 4.5, upBias: 1.5, colors: [col, 0xFFFFFF, 0xFFD54F], size: 0.16, life: 1.3, drag: 1.6, grav: 1.5, cell: 1, spin: 6, noScale: true });
    cs.pn.emit({ p: [0, 0.9, 0], n: n / 2, radial: 3.5, upBias: 2, colors: [0xF59E0B, 0xEF4444, 0x22C55E, 0x3B82F6, 0xA855F7, 0xFDE047], size: 0.09, sizeEnd: 0.08, life: 2.2, grav: 3.5, drag: 0.8, cell: 3, spin: 9, noScale: true });
  };
  W.chestHide = function () { if (cs) { cs.active = false; if (cs.chest) { cs.scene.remove(cs.chest); cs.chest = null; } } };
  function updateChestScene(dt) {
    var c = cs; if (!c || !c.active) return;
    c.t += dt;
    var ch = c.chest, appear = Math.min(1, c.t / 0.5);
    ch.scale.setScalar(Math.max(0.01, R3.ease.outBack(appear)));
    c.shake = Math.max(0, c.shake - dt * 2.5);
    var amp = c.shake * (0.06 + c.level * 0.03);
    ch.rotation.z = Math.sin(c.t * 60) * amp * 1.5;
    ch.position.x = Math.sin(c.t * 47) * amp;
    ch.position.y = Math.abs(Math.sin(c.t * 2)) * 0.05 * (1 - c.open);
    ch.rotation.y = Math.sin(c.t * 0.8) * 0.25 * (1 - Math.min(1, c.open * 2));
    c.glow.material.opacity = 0.25 + c.level * 0.12 + Math.sin(c.t * 6) * 0.05;
    if (c.open > 0) {
      c.open = Math.min(1, c.open + dt / 0.6);
      ch.userData.lid.rotation.x = -R3.ease.outBack(c.open) * 1.9;
      c.rays.material.opacity = Math.min(0.85, c.open * 1.2);
      c.rays.rotation.z += dt * 0.6;
      c.glow.material.opacity = 0.62; c.glow.scale.setScalar(2.6 + Math.sin(c.t * 4) * 0.25);
      if (Math.random() < 0.5) c.pa.emit({ p: [0, 0.75, 0], v: [0, 2.2, 0], vs: 1.4, n: 1, noScale: true, color: M.CHEST[c.rarity].glow, size: 0.14, life: 1, cell: 1 });
    }
    c.pa.update(dt); c.pn.update(dt);
  }

  /* ================================================================ دوربین و لمس */
  var cam = { yaw: 0, pitch: 0, zoom: 1, uYaw: 0, uPitch: 0, uZoom: 1, idle: 0, focus: 0, shake: 0, fit: { dist: 15, pitch: 0.6, fov: 55 }, target: new V3(0, 1.2, -1.6) };
  W.shake = function (a) { if (!calm) cam.shake = Math.min(1, cam.shake + a); };
  W.focusMe = function (on) { cam.focusOn = !!on; };
  function fitCamera() {
    var a = view.w / view.h;
    var fov = a < 0.62 ? 56 : (a < 1 ? 50 : 42);
    var th = Math.tan(fov * PI / 360);
    var dH = 4.1 / (a * th);
    var dV = 6.4 / th;
    var dist = R3.clamp(Math.max(dH, dV), 9.5, 22);
    var land = a >= 1 && view.h <= 560;
    cam.fit = { dist: dist * (a < 1 ? 1.06 : (land ? 1.02 : 1)), pitch: a < 1 ? 0.62 : (land ? 0.42 : 0.52), fov: fov };
    camera.fov = fov; camera.aspect = a;
    // نوار پایین بلندتر از نوار بالاست؛ صحنه کمی بالاتر کشیده می‌شود
    var off = Math.round(view.h * (a < 1 ? 0.065 : (land ? 0.0 : 0.05)));
    camera.setViewOffset(view.w, view.h, 0, off, view.w, view.h);
    camera.updateProjectionMatrix();
    pxScale = view.h * view.dpr / (2 * th);
    if (cs) { cs.cam.aspect = a; cs.cam.fov = a < 1 ? 42 : 30; cs.cam.updateProjectionMatrix(); }
  }
  var focusTarget = new V3(), baseTarget = new V3(0, 1.0, -1.7);
  function updateCamera(dt, t) {
    cam.idle += dt;
    if (cam.idle > 4) { cam.uYaw = R3.damp(cam.uYaw, 0, 1.2, dt); cam.uPitch = R3.damp(cam.uPitch, 0, 1.2, dt); cam.uZoom = R3.damp(cam.uZoom, 1, 1.2, dt); }
    cam.focus = R3.damp(cam.focus, cam.focusOn ? 1 : 0, 3.2, dt);
    var f = cam.focus, fit = cam.fit;
    var a = view.w / view.h;
    var yaw = cam.uYaw + Math.sin(t * 0.07) * 0.035 * (calm ? 0 : 1);
    var pitch = fit.pitch + cam.uPitch;
    var dist = fit.dist * cam.uZoom;
    // تمرکز روی من (کمد لباس)
    focusTarget.set(0, 1.55, ME_SEAT[1] + 0.1);
    var tgt = tmpV.copy(baseTarget).lerp(focusTarget, f);
    var d = R3.lerp(dist, a < 1 ? 5.2 : 4.4, f), pt = R3.lerp(pitch, 0.22, f), yw = R3.lerp(yaw, 0.0, f);
    camera.position.set(tgt.x + Math.sin(yw) * Math.cos(pt) * d, tgt.y + Math.sin(pt) * d, tgt.z + Math.cos(yw) * Math.cos(pt) * d);
    if (f > 0.01) camera.position.y -= f * (a < 1 ? 0.9 : 0.3);
    camera.lookAt(tgt.x, tgt.y - f * (a < 1 ? 0.55 : 0.2), tgt.z);
    if (cam.shake > 0) {
      cam.shake = Math.max(0, cam.shake - dt * 1.8);
      var s = cam.shake * cam.shake * 0.35;
      camera.position.x += (Math.random() - 0.5) * s; camera.position.y += (Math.random() - 0.5) * s;
    }
  }
  var ptrs = {}, gesture = null, ray = new T.Raycaster(), ndc = new T.Vector2();
  function onDown(e) {
    ptrs[e.pointerId] = { x: e.clientX, y: e.clientY, t: performance.now(), sx: e.clientX, sy: e.clientY };
    cam.idle = 0;
    var ids = Object.keys(ptrs);
    if (ids.length === 2) {
      var a = ptrs[ids[0]], b = ptrs[ids[1]];
      gesture = { pinch: Math.hypot(a.x - b.x, a.y - b.y), zoom: cam.uZoom };
    }
    if (W.hooks.touch) W.hooks.touch();
  }
  function onMove(e) {
    var p = ptrs[e.pointerId]; if (!p) return;
    var ids = Object.keys(ptrs);
    cam.idle = 0;
    if (ids.length >= 2 && gesture) {
      var a = ptrs[ids[0]], b = ptrs[ids[1]];
      p.x = e.clientX; p.y = e.clientY;
      var d = Math.hypot(a.x - b.x, a.y - b.y);
      cam.uZoom = R3.clamp(gesture.zoom * gesture.pinch / Math.max(20, d), 0.72, 1.3);
      return;
    }
    var dx = e.clientX - p.x, dy = e.clientY - p.y;
    p.x = e.clientX; p.y = e.clientY;
    if (cam.focusOn) return;
    cam.uYaw = R3.clamp(cam.uYaw - dx * 0.005, -0.6, 0.6);
    cam.uPitch = R3.clamp(cam.uPitch + dy * 0.003, -0.22, 0.28);
  }
  function onUp(e) {
    var p = ptrs[e.pointerId]; delete ptrs[e.pointerId];
    if (Object.keys(ptrs).length < 2) gesture = null;
    if (!p) return;
    var moved = Math.hypot(e.clientX - p.sx, e.clientY - p.sy), dt = performance.now() - p.t;
    if (moved < 12 && dt < 450) pick(e.clientX, e.clientY);
  }
  function findPick(o) { while (o) { if (o.userData && o.userData.pick) return o.userData.pick; o = o.parent; } return null; }
  function pick(x, y) {
    var rect = renderer.domElement.getBoundingClientRect();
    ndc.set((x - rect.left) / rect.width * 2 - 1, -((y - rect.top) / rect.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    var cands = [];
    Object.keys(people).forEach(function (id) { if (!people[id].leaving) cands.push(people[id].root); });
    if (boss && boss.alive) cands.push(boss.r.root);
    if (pileGroup) cands.push(pileGroup);
    var hits = ray.intersectObjects(cands, true);
    for (var i = 0; i < hits.length; i++) {
      var pk = findPick(hits[i].object);
      if (pk) { if (W.hooks.pick) W.hooks.pick(pk.type, pk.id, x, y); return; }
    }
    if (W.hooks.pick) W.hooks.pick('none', null, x, y);
  }

  /* ================================================================ محیط و کیفیت */
  W.setEnv = function (th, nt) {
    if (!W.ready) return;
    if (!E.THEMES || E.THEMES.indexOf(th) < 0) th = 'library';
    if (envObj && envObj.theme === th && envObj.night === !!nt) return;
    var themeChanged = th !== theme;
    theme = th; night = !!nt;
    if (envObj) { scene.remove(envObj.group); envObj.dispose(); envObj = null; }
    envObj = E.build(th, night, quality);
    scene.add(envObj.group);
    var L = envObj.light;
    hemi.color.setHex(L.hemi[0]); hemi.groundColor.setHex(L.hemi[1]); hemi.intensity = L.hemi[2];
    sun.color.setHex(L.sun[0]); sun.intensity = L.sun[1]; sun.position.set(L.sun[2][0], L.sun[2][1], L.sun[2][2]);
    scene.fog = new T.Fog(envObj.fog[0], envObj.fog[1], envObj.fog[2]);
    renderer.setClearColor(envObj.fog[0]);
    Object.keys(people).forEach(function (id) {
      var p = people[id];
      if (themeChanged) buildDesk(p);
      if (p.me && p.deskKey) setDeskItems(p, JSON.parse(p.deskKey));
    });
  };
  W.getQuality = function () { return quality; };
  W.setQuality = function (q, auto) {
    q = R3.clamp(q | 0, 0, 2);
    if (q === quality && !auto) return;
    var changed = q !== quality;
    quality = q;
    M.outlines = q > 0;
    var dpr = window.devicePixelRatio || 1;
    view.dpr = q === 0 ? Math.min(dpr, 1) : (q === 1 ? Math.min(dpr, 1.5) : Math.min(dpr, 2));
    if (ambient) view.dpr = Math.min(view.dpr, 1);
    renderer.setPixelRatio(view.dpr);
    renderer.setSize(view.w, view.h, false);
    fitCamera();
    scene.traverse(function (o) { if (o.userData && o.userData.outline) o.visible = q > 0; });
    if (changed && envObj) { var th = theme, nt = night; envObj.theme = '_'; W.setEnv(th, nt); }
  };
  function resize() {
    if (!renderer) return;
    var r = container.getBoundingClientRect();
    view.w = Math.max(1, Math.round(r.width)); view.h = Math.max(1, Math.round(r.height));
    renderer.setSize(view.w, view.h, false);
    fitCamera();
  }
  W.setAmbient = function (on) {
    on = !!on; if (on === ambient) return;
    ambient = on; fpsCap = on ? 20 : 0;
    W.setQuality(quality, true);
  };
  W.setCalm = function (on) { calm = !!on; };
  W.isAmbient = function () { return ambient; };

  /* ================================================================ حلقهٔ اصلی */
  var perf = { acc: 0, n: 0, t0: 0, lowRuns: 0, goodRuns: 0, auto: true };
  W.setAutoQuality = function (on) { perf.auto = !!on; };
  function tagsUpdate() {
    var o = {};
    Object.keys(people).forEach(function (id) {
      var p = people[id];
      tmpV.set(p.root.position.x, (p.state === 'sleeping' ? 2.15 : 2.45) + (p.hatKey ? 0.35 : 0) + p.avatar.position.y, p.root.position.z);
      project(tmpV, o);
      var sc = p.leaving ? p.appear : Math.min(1, p.appear * 1.5);
      if (!o.vis || sc <= 0.05) { if (p.tagVis !== false) { p.tag.style.display = 'none'; p.tagVis = false; } return; }
      if (p.tagVis === false) { p.tag.style.display = ''; p.tagVis = true; }
      p.tag.style.transform = 'translate(' + o.x.toFixed(1) + 'px,' + o.y.toFixed(1) + 'px) translate(-50%,-100%) scale(' + sc.toFixed(2) + ')';
    });
  }
  function frame(now) {
    if (!running) return;
    raf = requestAnimationFrame(frame);
    if (fpsCap && now - lastDraw < 1000 / fpsCap - 3) return;
    var dt = Math.min(0.1, Math.max(0.001, (now - (lastT || now)) / 1000));
    lastT = now; lastDraw = now;
    clockT += dt;
    var t = clockT;
    // سنجش کارایی (فقط وقتی سقف فریم نداریم)
    if (perf.auto && !fpsCap && !document.hidden) {
      perf.acc += dt; perf.n++;
      if (perf.acc > 4) {
        var avg = perf.acc / perf.n * 1000;
        if (avg > 30 && quality > 0) { perf.lowRuns++; if (perf.lowRuns >= 1) { W.setQuality(quality - 1); perf.lowRuns = 0; if (W.hooks.quality) W.hooks.quality(quality, avg); } }
        else perf.lowRuns = 0;
        perf.acc = 0; perf.n = 0;
      }
    }
    if (W.hooks.tick) W.hooks.tick(dt, t);
    Object.keys(people).forEach(function (id) { var p = people[id]; if (p.me && p.state === 'studying') p.orbAcc = (p.orbAcc || 0) + dt; updatePerson(p, dt, t); });
    updateOrbs(dt);
    updateBoss(dt, t);
    updatePile(dt, t);
    if (envObj) envObj.update(t, dt, pxScale);
    fxAdd.mat.uniforms.uPx.value = pxScale; fxNorm.mat.uniforms.uPx.value = pxScale;
    fxAdd.update(dt); fxNorm.update(dt);
    updateCamera(dt, t);
    tagsUpdate();
    renderer.clear();
    renderer.render(scene, camera);
    if (cs && cs.active) {
      updateChestScene(dt);
      cs.pa.mat.uniforms.uPx.value = pxScale; cs.pn.mat.uniforms.uPx.value = pxScale;
      renderer.clearDepth();
      renderer.render(cs.scene, cs.cam);
    }
  }
  W.start = function () {
    if (running || !W.ready) return;
    running = true; lastT = 0; lastDraw = 0;
    raf = requestAnimationFrame(frame);
  };
  W.stop = function () { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; };
  W.running = function () { return running; };

  /* ================================================================ جشن‌ها */
  W.confetti = function (big) {
    if (!W.ready) return;
    var c = camera.position, dir = tmpV.set(0, 0, -1).applyQuaternion(camera.quaternion);
    var p = [c.x + dir.x * 6, c.y + dir.y * 6 + 2.5, c.z + dir.z * 6];
    fxNorm.emit({ p: p, n: big ? 140 : 70, spread: 6, spreadY: 1, v: [0, 1, 0], vs: 3, colors: [0xF59E0B, 0xEF4444, 0x22C55E, 0x3B82F6, 0xA855F7, 0xFDE047, 0xFFFFFF], size: 0.16, sizeEnd: 0.14, life: 3, grav: 2.5, drag: 0.9, cell: 3, spin: 9, min: 30 });
  };
  W.sparkleAtMe = function (color, n) {
    if (!meP) return;
    fxAdd.emit({ p: [meP.root.position.x, 1.6, meP.root.position.z], n: n || 30, radial: 3, colors: [color || 0xFFD54F, 0xFFFFFF], size: 0.24, life: 0.9, drag: 2.5, cell: 1, spin: 5 });
  };
  W.burstAt = function (id, color, n) {
    var p = people[id]; if (!p) return;
    fxAdd.emit({ p: [p.root.position.x, 1.8, p.root.position.z], n: n || 20, radial: 2.4, colors: [color || 0xFFFFFF, 0xFFFFFF], size: 0.22, life: 0.8, drag: 2.5, cell: 1, spin: 5 });
  };
  W.screenOf = function (id) {
    var p = people[id]; if (!p) return null;
    return project(tmpV.set(p.root.position.x, 2.2, p.root.position.z), {});
  };

  /* ================================================================ راه‌اندازی */
  W.supported = function () {
    try {
      var c = document.createElement('canvas');
      return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
    } catch (e) { return false; }
  };
  W.init = function (el, opts) {
    opts = opts || {};
    container = el; tagsEl = R3.$('tags'); fxEl = R3.$('fxdom');
    var weak = (navigator.hardwareConcurrency || 4) <= 4 || (navigator.deviceMemory && navigator.deviceMemory <= 3);
    quality = opts.quality === undefined || opts.quality === 'auto' ? (weak ? 0 : 1) : R3.clamp(opts.quality | 0, 0, 2);
    perf.auto = opts.quality === undefined || opts.quality === 'auto';
    M.outlines = quality > 0;
    M.detail = quality === 0 ? 0.75 : 1;
    try {
      renderer = new T.WebGLRenderer({ antialias: !weak, alpha: false, stencil: false, powerPreference: 'default', preserveDrawingBuffer: !!opts.preserve });
    } catch (e) { return { ok: false, reason: String(e && e.message || e).slice(0, 160) }; }
    renderer.autoClear = false;
    renderer.setClearColor(0x2B1E16);
    el.appendChild(renderer.domElement);
    renderer.domElement.addEventListener('webglcontextlost', function (e) { e.preventDefault(); W.stop(); if (W.hooks.lost) W.hooks.lost(); }, false);
    renderer.domElement.addEventListener('webglcontextrestored', function () { if (W.hooks.restored) W.hooks.restored(); }, false);
    scene = new T.Scene();
    camera = new T.PerspectiveCamera(52, 1, 0.3, 220);
    hemi = new T.HemisphereLight(0xffffff, 0x8C7A6B, 1.7); scene.add(hemi);
    sun = new T.DirectionalLight(0xFFF1D6, 2.3); sun.position.set(6, 14, 8); scene.add(sun); scene.add(sun.target);
    sun.target.position.set(0, 0, -2);
    fxAdd = new Pool(quality === 0 ? 700 : 1400, true); fxNorm = new Pool(quality === 0 ? 400 : 800, false);
    scene.add(fxAdd.points); scene.add(fxNorm.points);
    pileGroup = new T.Group(); scene.add(pileGroup);
    view.dpr = quality === 0 ? 1 : Math.min(window.devicePixelRatio || 1, quality === 1 ? 1.5 : 2);
    renderer.setPixelRatio(view.dpr);
    resize();
    window.addEventListener('resize', resize);
    var cv = renderer.domElement;
    cv.addEventListener('pointerdown', onDown);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerup', onUp);
    cv.addEventListener('pointercancel', function (e) { delete ptrs[e.pointerId]; gesture = null; });
    W.ready = true;
    W.setEnv(opts.theme || 'library', !!opts.night);
    return { ok: true, quality: quality };
  };
  W.info = function () { return renderer ? { calls: renderer.info.render.calls, tris: renderer.info.render.triangles, geos: renderer.info.memory.geometries, tex: renderer.info.memory.textures, q: quality, dpr: view.dpr } : null; };
  W.renderOnce = function () { if (renderer) { renderer.clear(); renderer.render(scene, camera); } };
})();
