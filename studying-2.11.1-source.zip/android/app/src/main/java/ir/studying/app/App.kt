package ir.studying.app

import android.app.Application
import ir.studying.app.core.Store
import ir.studying.app.notify.MessageWorker
import ir.studying.app.notify.Notifications

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Store.init(this)
        Notifications.ensureChannels(this)
        ir.studying.app.notify.NotifCenter.start(this)
        MessageWorker.schedule(this)
        ir.studying.app.core.AutoPost.init(this)
        ir.studying.app.notify.DaySummary.schedule(this)
        /*
         * schedule respects PlannerAvailability. In the coming-soon release it
         * cancels existing planner alarms/notifications instead of scheduling new ones.
         * Other reminders, alarms, focus tools and saved planner data are unchanged.
         */
        ir.studying.app.notify.PlannerNightly.schedule(this)
        ir.studying.app.core.Flashcards.init(this)
        /*
         * Store.init reads from disk synchronously, so by this point the saved
         * pomodoro is available and an interrupted focus block can be put back
         * instead of silently disappearing with the killed process.
         */
        ir.studying.app.player.Pomodoro.restore(this)
        ir.studying.app.notify.StudyNotifier.sync(this)
        // Parts logged while offline are replayed as soon as there is a network again.
        ir.studying.app.notify.SyncWorker.schedule(this)
        ir.studying.app.notify.SyncWorker.kick(this)
        // Study targets are a local preference; load them before any screen asks.
        ir.studying.app.core.Goals.init()
        // دستیار هوشمند: تاریخچهٔ گفت‌وگوی هر حساب روی همین گوشی می‌ماند.
        ir.studying.app.core.Assistant.init(this)
        ir.studying.app.ui.components.StreakFx.init(this)
        ir.studying.app.widget.StudyWidget.refresh(this)
        /*
         * A focus session survives process death: its end time lives on disk, so
         * init() either resumes the lock or cleans up an expired one.
         */
        ir.studying.app.focus.FocusService.ensureChannel(this)
        ir.studying.app.focus.FocusLock.init(this)
        /*
         * زنگ‌ها: کانال نوتیفیکیشن و زمان‌بندی دوباره.
         *
         * زمان‌بندی مجدد در هر اجرا عمدی است — کاربر می‌تواند ساعت گوشی را عوض
         * کند، اپ می‌تواند آپدیت شود (که همهٔ PendingIntent‌های آلارم را پاک
         * می‌کند) یا سیستم آلارم را دور بیندازد؛ در هر سه حالت زنگ بی‌صدا
         * گم می‌شد.
         */
        ir.studying.app.alarm.AlarmService.ensureChannel(this)
        ir.studying.app.alarm.AlarmStore.rescheduleAll(this)
        ir.studying.app.alarm.AlarmLog.init(this)
        /* نگهبان دوره‌ای؛ اگر آلارمی از دست سیستم در رفت، ربع ساعت بعد جبران می‌شود. */
        ir.studying.app.alarm.AlarmScheduler.armWatchdog(this)
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
