package ir.studying.app.alarm

import android.content.Context
import ir.studying.app.core.Api
import ir.studying.app.core.Store
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * پایانِ زنگ، در یک جا.
 *
 * چرا جدا شد: خاموش‌کردن زنگ فقط «قطع صدا» نیست؛ باید سهمیهٔ تعویق صفر شود،
 * چک بیداری چیده شود، زنگ یک‌باره خودش خاموش شود، رویداد در دفترچه ثبت شود و
 * ساعت بیداری به سرور برود. حالا که همین کار هم از اکتیویتیِ زنگ و هم از
 * پوششِ داخل اپ انجام می‌شود، دوباره‌نویسی‌اش یعنی یکی از این پنج کار جا
 * می‌ماند.
 */
object AlarmDismiss {

    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** مأموریت انجام شد. */
    fun solve(context: Context, alarm: Alarm, wakeCheck: Boolean) {
        val ctx = context.applicationContext
        val seconds = AlarmService.ringingSeconds()
        AlarmService.stop(ctx)
        AlarmStore.resetSnoozed(alarm.id)
        if (wakeCheck) {
            /* چک بیداری پاس شد؛ دیگر تعقیبش نمی‌کنیم. */
            AlarmScheduler.cancelWakeCheck(ctx, alarm.id)
        } else {
            AlarmScheduler.scheduleWakeCheck(ctx, alarm)
            AlarmStore.finishOneShot(ctx, alarm.id)
        }
        runCatching { AlarmLog.solved(ctx, alarm.id, alarm, wakeCheck, seconds) }
        if (alarm.reportWakeup) reportWakeup()
    }

    /** تعویق. */
    fun snooze(context: Context, alarm: Alarm) {
        val ctx = context.applicationContext
        AlarmService.stop(ctx)
        AlarmScheduler.snooze(ctx, alarm)
        runCatching { AlarmLog.snoozed(ctx, alarm.id, alarm) }
    }

    /**
     * ساعت بیداری را همان‌جا به سرور می‌دهد.
     *
     * این تکهٔ کوچک، زنگ را به بقیهٔ اپ وصل می‌کند: کارت «بیداری» در خانه،
     * پیام صبح‌به‌خیر ربات و آمار گروه همه از همین یک مقدار تغذیه می‌شوند.
     */
    private fun reportWakeup() {
        if (Store.token.isNullOrBlank()) return
        val now = SimpleDateFormat("HH:mm", Locale.US)
            .apply { timeZone = ir.studying.app.core.IranTime.ZONE }
            .format(Date())
        io.launch {
            runCatching { Api.post("wakeup", JSONObject().put("wakeup_time", now)) }
            runCatching { ir.studying.app.core.RefreshBus.emit("home") }
        }
    }
}
