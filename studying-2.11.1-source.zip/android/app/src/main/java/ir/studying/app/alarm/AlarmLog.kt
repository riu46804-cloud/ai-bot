package ir.studying.app.alarm

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * دفترچهٔ زنگ‌ها.
 *
 * چرا لازم شد: تا حالا زنگ می‌زد و تمام؛ هیچ‌کس نمی‌دانست دیشب اصلاً زنگ خورد
 * یا نه، چند دقیقه طول کشید تا کاربر مأموریت را حل کند، چند بار تعویق زد و
 * چند بار کلاً جواب نداد. همین چند عدد است که به آدم می‌گوید «سحرخیزی» دارد
 * بهتر می‌شود یا نه — و اگر زنگی به‌خاطر بهینه‌سازی باتری نخورده باشد، فقط
 * از همین گزارش می‌شود فهمید.
 *
 * محلی و بدون شبکه ذخیره می‌شود؛ مثل خود زنگ نباید به اینترنت وابسته باشد.
 */
object AlarmLog {

    const val FIRED = "fired"
    const val SOLVED = "solved"
    const val SNOOZED = "snoozed"
    const val MISSED = "missed"

    private const val FILE = "studying_alarm_log"
    private const val K_LIST = "events"
    private const val K_CHECK = "last_check"
    /** سقف نگهداری؛ دفترچه نباید بی‌نهایت بزرگ شود. */
    private const val MAX = 400
    private const val KEEP_DAYS = 90L

    data class Event(
        val at: Long,
        val kind: String,
        val alarmId: Int,
        val label: String = "",
        /** برای SOLVED: چند ثانیه طول کشید تا مأموریت تمام شود. */
        val seconds: Int = 0,
        val wakeCheck: Boolean = false,
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("at", at).put("k", kind).put("id", alarmId)
            .put("l", label).put("s", seconds).put("w", wakeCheck)
    }

    private var prefs: SharedPreferences? = null
    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> get() = _events

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        _events.value = decode(prefs?.getString(K_LIST, null))
    }

    private fun decode(raw: String?): List<Event> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Event(
                    at = o.optLong("at"),
                    kind = o.optString("k", FIRED),
                    alarmId = o.optInt("id"),
                    label = o.optString("l", ""),
                    seconds = o.optInt("s"),
                    wakeCheck = o.optBoolean("w", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun add(context: Context, e: Event) {
        init(context)
        val floor = System.currentTimeMillis() - KEEP_DAYS * 86_400_000L
        val list = (_events.value + e).filter { it.at >= floor }.takeLast(MAX)
        _events.value = list
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        runCatching { prefs?.edit()?.putString(K_LIST, arr.toString())?.apply() }
    }

    fun fired(context: Context, id: Int, alarm: Alarm?, wakeCheck: Boolean) =
        add(context, Event(System.currentTimeMillis(), FIRED, id, labelOf(alarm), 0, wakeCheck))

    fun solved(context: Context, id: Int, alarm: Alarm?, wakeCheck: Boolean, seconds: Int) =
        add(context, Event(System.currentTimeMillis(), SOLVED, id, labelOf(alarm), seconds, wakeCheck))

    fun snoozed(context: Context, id: Int, alarm: Alarm?) =
        add(context, Event(System.currentTimeMillis(), SNOOZED, id, labelOf(alarm)))

    fun missed(context: Context, id: Int, alarm: Alarm?, at: Long = System.currentTimeMillis()) =
        add(context, Event(at, MISSED, id, labelOf(alarm)))

    private fun labelOf(alarm: Alarm?): String =
        alarm?.label?.takeIf { it.isNotBlank() }
            ?: alarm?.let { two(it.hour) + ":" + two(it.minute) }
            ?: ""

    private fun two(n: Int) = if (n < 10) "0$n" else "$n"

    /** آیا برای این لحظه (±۹۰ ثانیه) اصلاً زنگی ثبت شده؟ نگهبان از این استفاده می‌کند. */
    fun hasFiredNear(at: Long, id: Int): Boolean =
        _events.value.any { it.alarmId == id && it.kind == FIRED && kotlin.math.abs(it.at - at) < 90_000L }

    fun lastCheck(): Long = prefs?.getLong(K_CHECK, 0L) ?: 0L
    fun markCheck(at: Long = System.currentTimeMillis()) { runCatching { prefs?.edit()?.putLong(K_CHECK, at)?.apply() } }

    data class Report(
        val days: Int,
        val fired: Int,
        val solved: Int,
        val missed: Int,
        val snoozes: Int,
        val avgSolveSec: Int,
        val bestSolveSec: Int,
        /** میانگین ساعت بیداری بر حسب دقیقه از نیمه‌شب؛ ۱- یعنی داده‌ای نیست. */
        val avgWakeMinute: Int,
        val wakeChecksPassed: Int,
    ) {
        val successRate: Int get() = if (fired == 0) 0 else (solved * 100 / fired).coerceIn(0, 100)
    }

    /** خلاصهٔ [days] روز گذشته. */
    fun report(days: Int = 7): Report {
        val from = System.currentTimeMillis() - days * 86_400_000L
        val win = _events.value.filter { it.at >= from }
        val fired = win.count { it.kind == FIRED && !it.wakeCheck }
        val solvedEvents = win.filter { it.kind == SOLVED && !it.wakeCheck }
        val times = solvedEvents.map { it.seconds }.filter { it > 0 }
        val wakeMinutes = solvedEvents.map {
            val c = Calendar.getInstance().apply { timeInMillis = it.at }
            c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        }
        return Report(
            days = days,
            fired = fired,
            solved = solvedEvents.size,
            missed = win.count { it.kind == MISSED },
            snoozes = win.count { it.kind == SNOOZED },
            avgSolveSec = if (times.isEmpty()) 0 else times.average().toInt(),
            bestSolveSec = times.minOrNull() ?: 0,
            avgWakeMinute = if (wakeMinutes.isEmpty()) -1 else wakeMinutes.average().toInt(),
            wakeChecksPassed = win.count { it.kind == SOLVED && it.wakeCheck },
        )
    }

    /** آخرین رویدادها، تازه‌ترین اول. */
    fun recent(limit: Int = 12): List<Event> = _events.value.sortedByDescending { it.at }.take(limit)
}
