package ir.studying.app.alarm

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * زنگ بیدارباش — همان ایدهٔ Alarmy.
 *
 * چرا این اپ به زنگ خودش نیاز داشت: تمام سازوکار انگیزشی این برنامه روی «صبح
 * زود بیدار شدن» بنا شده (ساعت بیداری به سرور می‌رود، در گروه تلگرام اعلام
 * می‌شود، استریک به آن وصل است) ولی بیدار کردنِ کاربر به زنگ گوشی سپرده بود.
 * زنگ گوشی با یک ضربه خاموش می‌شود و آدم دوباره می‌خوابد.
 *
 * پس زنگ اینجا سه چیز دارد که زنگ معمولی ندارد:
 *  ۱) «مأموریت»: تا چند سؤال ریاضی حل نشود، صدا قطع نمی‌شود.
 *  ۲) «چک بیداری»: ده دقیقه بعد از خاموش‌کردن، دوباره می‌پرسد بیدار مانده‌ای؟
 *  ۳) ثبت خودکار ساعت بیداری روی سرور، همان چیزی که بقیهٔ اپ منتظرش است.
 */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    /** روزهای هفته با شمارهٔ [Calendar.DAY_OF_WEEK]؛ خالی = فقط یک بار. */
    val days: Set<Int> = emptySet(),
    val enabled: Boolean = true,
    val label: String = "",
    /** نوع مأموریتِ خاموش‌کردن: math / typing / shake / none. */
    val mission: String = MISSION_MATH,
    /** سختی سؤال‌ها: ۱ ساده، ۲ متوسط، ۳ سخت. */
    val difficulty: Int = 2,
    /** چند سؤال درست لازم است. */
    val problems: Int = 3,
    /** تعویق چند دقیقه‌ای؛ ۰ یعنی تعویق ممنوع. */
    val snoozeMinutes: Int = 5,
    /** حداکثر تعداد تعویق. */
    val snoozeLimit: Int = 3,
    /** چک بیداری چند دقیقه بعد؟ ۰ یعنی خاموش. */
    val wakeCheckMinutes: Int = 10,
    val vibrate: Boolean = true,
    /** بالا رفتن تدریجی صدا، مثل Alarmy. */
    val gentleRamp: Boolean = true,
    /**
     * صدای زنگ. خالی = زنگ پیش‌فرض گوشی، «raw:chime» و مانند آن = صدای داخل اپ،
     * هر چیز دیگر = URI آهنگی که کاربر از گوشی خودش انتخاب کرده.
     */
    val soundUri: String = "",
    /** بلندی صدا نسبت به بیشینهٔ کانال آلارم (۲۰ تا ۱۰۰). */
    val volumePercent: Int = 100,
    /** چند ثانیه طول بکشد تا صدا به بلندی کامل برسد؛ ۰ = بی‌درنگ. */
    val rampSeconds: Int = 30,
    /** اگر کسی جواب ندهد، بعد از این چند دقیقه صدا خودش می‌ایستد؛ ۰ = تا سقف امن. */
    val autoSilenceMinutes: Int = 15,
    /** ثبت ساعت بیداری روی سرور بعد از انجام مأموریت. */
    val reportWakeup: Boolean = true,
) {
    companion object {
        const val MISSION_MATH = "math"
        /** تایپ کردن یک جملهٔ فارسی، کلمه‌به‌کلمه. */
        const val MISSION_TYPING = "typing"
        /** تکان دادن گوشی؛ برای کسی که با سؤال ریاضی هم می‌خوابد. */
        const val MISSION_SHAKE = "shake"
        const val MISSION_NONE = "none"

        /** صداهای داخل اپ که به‌عنوان زنگ معنا می‌دهند. */
        val builtInSounds: List<Pair<String, String>> = listOf(
            "" to "زنگ پیش‌فرض گوشی",
            "raw:chime" to "زنگ ملایم",
            "raw:amb_thunder" to "رعد",
            "raw:amb_ocean" to "دریا",
            "raw:amb_rain" to "باران",
        )

        /** برچسب فارسی روزها، به ترتیبی که در ایران شمرده می‌شود. */
        val weekOrder: List<Pair<Int, String>> = listOf(
            Calendar.SATURDAY to "ش",
            Calendar.SUNDAY to "ی",
            Calendar.MONDAY to "د",
            Calendar.TUESDAY to "س",
            Calendar.WEDNESDAY to "چ",
            Calendar.THURSDAY to "پ",
            Calendar.FRIDAY to "ج",
        )
    }

    val isRepeating: Boolean get() = days.isNotEmpty()

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("hour", hour).put("minute", minute)
        .put("days", JSONArray(days.toList()))
        .put("enabled", enabled).put("label", label)
        .put("mission", mission).put("difficulty", difficulty).put("problems", problems)
        .put("snooze", snoozeMinutes).put("snooze_limit", snoozeLimit)
        .put("wake_check", wakeCheckMinutes)
        .put("vibrate", vibrate).put("ramp", gentleRamp).put("report", reportWakeup)
        .put("sound", soundUri).put("volume", volumePercent)
        .put("ramp_sec", rampSeconds).put("auto_silence", autoSilenceMinutes)
}

/**
 * ذخیره‌گاه زنگ‌ها.
 *
 * SharedPreferences و نه سرور: زنگ باید بدون اینترنت، بدون لاگین و بلافاصله
 * بعد از ریبوت هم کار کند. هیچ‌چیزِ زنگ به شبکه وابسته نیست.
 */
object AlarmStore {

    private const val FILE = "studying_alarms"
    private const val K_LIST = "alarms"
    private const val K_SEQ = "next_id"
    /** شمارهٔ تعویق‌های همین بار؛ با خاموش‌شدن کامل صفر می‌شود. */
    private const val K_SNOOZED = "snoozed_"

    private var prefs: SharedPreferences? = null

    private val _alarms = MutableStateFlow<List<Alarm>>(emptyList())
    val alarms: StateFlow<List<Alarm>> get() = _alarms

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        _alarms.value = decode(prefs?.getString(K_LIST, null))
    }

    private fun decode(raw: String?): List<Alarm> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val dayArr = o.optJSONArray("days")
                val days = buildSet {
                    if (dayArr != null) for (j in 0 until dayArr.length()) add(dayArr.getInt(j))
                }
                Alarm(
                    id = o.getInt("id"),
                    hour = o.optInt("hour", 7),
                    minute = o.optInt("minute"),
                    days = days,
                    enabled = o.optBoolean("enabled", true),
                    label = o.optString("label", ""),
                    mission = o.optString("mission", Alarm.MISSION_MATH),
                    difficulty = o.optInt("difficulty", 2),
                    problems = o.optInt("problems", 3),
                    snoozeMinutes = o.optInt("snooze", 5),
                    snoozeLimit = o.optInt("snooze_limit", 3),
                    wakeCheckMinutes = o.optInt("wake_check", 10),
                    vibrate = o.optBoolean("vibrate", true),
                    gentleRamp = o.optBoolean("ramp", true),
                    reportWakeup = o.optBoolean("report", true),
                    /* کلیدهای تازه با مقدار پیش‌فرض خوانده می‌شوند، پس زنگ‌های
                       ذخیره‌شدهٔ نسخهٔ قبلی بدون مهاجرت کار می‌کنند. */
                    soundUri = o.optString("sound", ""),
                    volumePercent = o.optInt("volume", 100),
                    rampSeconds = o.optInt("ramp_sec", if (o.optBoolean("ramp", true)) 30 else 0),
                    autoSilenceMinutes = o.optInt("auto_silence", 15),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun persist(list: List<Alarm>) {
        _alarms.value = list.sortedWith(compareBy({ it.hour }, { it.minute }))
        val arr = JSONArray()
        _alarms.value.forEach { arr.put(it.toJson()) }
        prefs?.edit()?.putString(K_LIST, arr.toString())?.apply()
    }

    fun of(id: Int): Alarm? = _alarms.value.firstOrNull { it.id == id }

    private fun nextId(): Int {
        val p = prefs ?: return 1
        val id = p.getInt(K_SEQ, 1)
        p.edit().putInt(K_SEQ, id + 1).apply()
        return id
    }

    /** ذخیرهٔ یک زنگ تازه یا ویرایش‌شده و زمان‌بندی دوبارهٔ همان. */
    fun save(context: Context, alarm: Alarm): Alarm {
        val withId = if (alarm.id > 0) alarm else alarm.copy(id = nextId())
        persist(_alarms.value.filterNot { it.id == withId.id } + withId)
        AlarmScheduler.reschedule(context, withId)
        return withId
    }

    fun remove(context: Context, id: Int) {
        AlarmScheduler.cancel(context, id)
        persist(_alarms.value.filterNot { it.id == id })
    }

    fun setEnabled(context: Context, id: Int, on: Boolean) {
        val a = of(id) ?: return
        save(context, a.copy(enabled = on))
    }

    fun snoozedCount(id: Int): Int = prefs?.getInt(K_SNOOZED + id, 0) ?: 0
    fun bumpSnoozed(id: Int) { prefs?.edit()?.putInt(K_SNOOZED + id, snoozedCount(id) + 1)?.apply() }
    fun resetSnoozed(id: Int) { prefs?.edit()?.putInt(K_SNOOZED + id, 0)?.apply() }

    /**
     * بعد از یک زنگِ یک‌بارهٔ انجام‌شده، خودش خاموش می‌شود.
     *
     * بدون این، زنگ یک‌باره در لیست روشن می‌ماند و فردا صبح معلوم نیست چرا
     * دیگر زنگ نمی‌زند.
     */
    fun finishOneShot(context: Context, id: Int) {
        val a = of(id) ?: return
        if (!a.isRepeating) save(context, a.copy(enabled = false))
    }

    /** زمان‌بندی همهٔ زنگ‌ها؛ بعد از ریبوت یا تغییر ساعت سیستم. */
    fun rescheduleAll(context: Context) {
        init(context)
        _alarms.value.forEach { AlarmScheduler.reschedule(context, it) }
    }
}
