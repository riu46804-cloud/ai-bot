package ir.studying.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.studying.app.core.Store

/**
 * لحظهٔ زنگ.
 *
 * کار این گیرنده حداقلی است و باید هم باشد: BroadcastReceiver فقط چند
 * میلی‌ثانیه وقت دارد. پس صدا و صفحه را به سرویس و اکتیویتی می‌سپارد و
 * بلافاصله برمی‌گردد. زنگ تکرارشونده هم همان‌جا برای نوبت بعدی دوباره
 * زمان‌بندی می‌شود، وگرنه فقط یک بار زنگ می‌زد.
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val ctx = context.applicationContext
        val id = intent?.getIntExtra(AlarmScheduler.EXTRA_ID, 0) ?: 0
        val wakeCheck = intent?.action == AlarmScheduler.ACTION_WAKE_CHECK

        /*
         * تلنگر: زنگ همین حالا در حال پخش است ولی صفحه‌اش جلو نیست. فقط صفحه
         * را برمی‌گردانیم؛ نه سرویس دوباره راه می‌افتد، نه صدا از نو شروع می‌شود.
         */
        if (intent?.action == AlarmScheduler.ACTION_KICK) {
            if (AlarmService.ringingId >= 0 && !AlarmRingActivity.visible && !AlarmService.overlayVisible) {
                runCatching {
                    ctx.startActivity(
                        Intent(ctx, AlarmRingActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra(AlarmService.EXTRA_ID, AlarmService.ringingId)
                            .putExtra(AlarmService.EXTRA_WAKE_CHECK, AlarmService.ringingWakeCheck),
                    )
                }
            }
            return
        }

        /*
         * نگهبان دوره‌ای: چیدن دوبارهٔ همهٔ زنگ‌ها و ثبت زنگ‌های از قلم افتاده.
         */
        if (intent?.action == AlarmScheduler.ACTION_WATCHDOG) {
            runCatching {
                AlarmStore.init(ctx)
                AlarmLog.init(ctx)
                AlarmStore.rescheduleAll(ctx)
                auditMissed(ctx)
                AlarmScheduler.armWatchdog(ctx)
            }
            return
        }

        /*
         * چند ثانیه بیدار نگه داشتن CPU.
         *
         * بین برگشتن این گیرنده و اولین نفسِ سرویس، گوشی می‌تواند دوباره به
         * خواب عمیق برود و زنگ اصلاً شروع نشود. سرویس خودش قفل بلندمدت را
         * می‌گیرد؛ این فقط همان شکاف کوتاه را پر می‌کند.
         */
        runCatching {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            pm?.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "studying:alarm-fire")
                ?.apply { setReferenceCounted(false); acquire(20_000L) }
        }

        runCatching {
            Store.init(ctx)
            AlarmStore.init(ctx)
            AlarmLog.init(ctx)
            val alarm = AlarmStore.of(id)
            AlarmService.start(ctx, id, wakeCheck)
            val full = Intent(ctx, AlarmRingActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .putExtra(AlarmService.EXTRA_ID, id)
                .putExtra(AlarmService.EXTRA_WAKE_CHECK, wakeCheck)
            /* روی اندروید ۱۰+ اجرای اکتیویتی از پس‌زمینه ممکن است رد شود؛
               به همین دلیل نوتیفیکیشن سرویس یک fullScreenIntent هم دارد. */
            runCatching { ctx.startActivity(full) }
            if (alarm != null && !wakeCheck && alarm.isRepeating) {
                AlarmScheduler.reschedule(ctx, alarm)
            }
            AlarmLog.markCheck()
            AlarmScheduler.armWatchdog(ctx)
        }
    }

    /**
     * زنگ‌هایی که باید می‌خوردند ولی خبری ازشان نیست.
     *
     * از آخرین بازرسی تا حالا، هر زنگِ روشنی که زمانش گذشته و در دفترچه ثبت
     * نشده، «از دست رفته» علامت می‌خورد. این تنها راهی است که کاربر بفهمد
     * مقصرِ خواب ماندنش، تنظیمات باتریِ گوشی بوده نه خودش.
     */
    private fun auditMissed(ctx: Context) {
        val now = System.currentTimeMillis()
        val last = AlarmLog.lastCheck()
        AlarmLog.markCheck(now)
        if (last <= 0L) return
        AlarmStore.alarms.value.filter { it.enabled }.forEach { a ->
            val prev = AlarmScheduler.prevTrigger(a, now)
            if (prev > last && prev < now - 120_000L && !AlarmLog.hasFiredNear(prev, a.id)) {
                AlarmLog.missed(ctx, a.id, a, prev)
            }
        }
    }
}
