package ir.studying.app.alarm

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Api
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.ui.theme.StudyingTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * صفحهٔ زنگ: تا مأموریت تمام نشود، بسته نمی‌شود.
 *
 * نکته‌های ریز ولی حیاتی:
 *  - روی صفحهٔ قفل و با صفحهٔ خاموش هم باید بیاید (showWhenLocked / turnScreenOn).
 *  - دکمهٔ بازگشت کاری نمی‌کند؛ وگرنه «مأموریت» یک تشریفات بی‌اثر می‌شد.
 *  - صدا اینجا پخش نمی‌شود؛ مالکش [AlarmService] است. این صفحه فقط مأموریت
 *    را می‌گیرد و به سرویس می‌گوید کِی ساکت شود.
 */
class AlarmRingActivity : ComponentActivity() {

    companion object {
        /**
         * آیا صفحهٔ زنگ همین حالا جلوی چشم کاربر است؟
         *
         * [AlarmService] از این می‌خواند: اگر کاربر صفحه را کنار زده باشد،
         * نگهبانِ سرویس دوباره جلویش می‌آورد.
         */
        @Volatile
        var visible: Boolean = false
    }

    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** مأموریت انجام شد یا تعویق خورد؟ فقط در این حالت اجازهٔ بسته شدن داریم. */
    private var dismissed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        Store.init(applicationContext)
        AlarmStore.init(applicationContext)

        val id = intent?.getIntExtra(AlarmService.EXTRA_ID, 0) ?: 0
        val wakeCheck = intent?.getBooleanExtra(AlarmService.EXTRA_WAKE_CHECK, false) ?: false
        val alarm = AlarmStore.of(id) ?: Alarm(id = id, hour = 7, minute = 0)

        setContent {
            StudyingTheme {
                RingScreen(
                    alarm = alarm,
                    wakeCheck = wakeCheck,
                    onSolved = { finishMission(alarm, wakeCheck) },
                    onSnooze = { snooze(alarm) },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        visible = true
    }

    /**
     * فرار ممنوع.
     *
     * دکمهٔ Home یا Recents این صفحه را می‌برد و زنگ عملاً «غیب» می‌شد: صدا
     * می‌ماند ولی راه خاموش کردنش پیدا نبود. تا وقتی مأموریت انجام نشده و
     * سرویس در حال زنگ زدن است، صفحه خودش را دوباره جلو می‌آورد.
     */
    override fun onStop() {
        super.onStop()
        visible = false
        if (!dismissed && AlarmService.ringingId >= 0) {
            runCatching {
                startActivity(
                    Intent(this, AlarmRingActivity::class.java)
                        .addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                                Intent.FLAG_ACTIVITY_CLEAR_TOP,
                        )
                        .putExtra(AlarmService.EXTRA_ID, AlarmService.ringingId)
                        .putExtra(AlarmService.EXTRA_WAKE_CHECK, AlarmService.ringingWakeCheck),
                )
            }
        }
    }

    override fun onDestroy() {
        if (visible) visible = false
        super.onDestroy()
    }

    /** مأموریت انجام شد: صدا قطع، چک بیداری زمان‌بندی، ساعت بیداری ثبت. */
    private fun finishMission(alarm: Alarm, wakeCheck: Boolean) {
        dismissed = true
        AlarmDismiss.solve(applicationContext, alarm, wakeCheck)
        finish()
    }

    private fun snooze(alarm: Alarm) {
        dismissed = true
        AlarmDismiss.snooze(applicationContext, alarm)
        finish()
    }
}
