package ir.studying.app.alarm

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.fa
import ir.studying.app.ui.alarm.DawnGold
import ir.studying.app.ui.alarm.DawnPink
import ir.studying.app.ui.alarm.WobblingBell
import ir.studying.app.ui.components.AuroraBackdrop
import ir.studying.app.ui.components.GlassPill
import ir.studying.app.ui.components.RippleRings
import ir.studying.app.ui.components.RollingText
import ir.studying.app.ui.components.StarField
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.shine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * بدنهٔ بصری زنگ، جدا از اکتیویتی.
 *
 * چرا جدا شد: حالا همین صفحه در دو جا لازم است — اکتیویتیِ تمام‌صفحه (وقتی
 * گوشی قفل است) و پوششِ داخل خود اپ (وقتی کاربر با اپ باز است و اندروید
 * اجازهٔ اجرای اکتیویتی از پس‌زمینه را نمی‌دهد). دو نسخه از یک مأموریت یعنی
 * دو جای خراب‌شدنی، پس یکی است.
 *
 * ظاهر ۲.۹: آسمانِ سپیده‌دم (شفق صورتی/طلایی روی شب)، زنگوله‌ای که می‌لرزد و
 * موج صدا از آن بیرون می‌زند، ثانیه‌شمار غلتان و کارت شیشه‌ای مأموریت.
 * رنگ‌ها عمداً مستقل از تم‌اند: این صفحه همیشه تیره است تا چشمِ خواب‌آلود نزند.
 */
@Composable
fun RingScreen(alarm: Alarm, wakeCheck: Boolean, onSolved: () -> Unit, onSnooze: () -> Unit) {
    /* دکمهٔ بازگشت عمداً بی‌اثر است. */
    BackHandler(enabled = true) { }

    var clock by remember { mutableStateOf(nowClock()) }
    LaunchedEffect(Unit) {
        while (true) {
            clock = nowClock()
            kotlinx.coroutines.delay(1000)
        }
    }

    val needed = if (alarm.mission == Alarm.MISSION_NONE) 0 else alarm.problems.coerceIn(1, 10)

    RingFrame(clock, alarm, wakeCheck) {
        when {
            needed == 0 -> RingButton("خاموش کردن", onClick = onSolved, modifier = Modifier.padding(top = 8.dp), big = true)
            alarm.mission == Alarm.MISSION_SHAKE -> ShakeBody(alarm, needed, onSolved)
            alarm.mission == Alarm.MISSION_TYPING -> TypingBody(alarm, needed, onSolved)
            else -> MathBody(alarm, needed, onSolved)
        }
        SnoozeRow(alarm, wakeCheck, onSnooze)
    }
}

private val RingGreen = Color(0xFF10B981)
private val RingMint = Color(0xFF4ADE9F)

/** دکمهٔ اصلی صفحهٔ زنگ: قرص گرادیانی سبز با نوار نور. */
@Composable
private fun RingButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, big: Boolean = false) {
    Box(
        modifier
            .fillMaxWidth()
            .height(if (big) 62.dp else 54.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(RingGreen, RingMint)))
            .shine(enabled = enabled)
            .bouncyClick(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Black, fontSize = if (big) 18.sp else 16.sp)
    }
}

/** نوار پیشرفت مأموریت: هر مرحله یک قرص که با انجام شدن کش می‌آید و پر می‌شود. */
@Composable
private fun MissionDots(done: Int, total: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(total) { i ->
            val on = i < done
            val w by animateDpAsState(if (on) 28.dp else 10.dp, spring(dampingRatio = 0.55f, stiffness = 400f), label = "dot$i")
            Box(
                Modifier.size(width = w, height = 10.dp)
                    .clip(CircleShape)
                    .background(
                        if (on) Brush.horizontalGradient(listOf(RingGreen, RingMint))
                        else Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.22f))),
                    ),
            )
        }
    }
}

@Composable
private fun MissionCaption(text: String) {
    GlassPill(text, style = androidx.compose.material3.MaterialTheme.typography.labelMedium)
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun MissionCard(content: @Composable () -> Unit) {
    Spacer(Modifier.height(16.dp))
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.05f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.06f))), shape)
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) { content() }
}

/** رنگ‌های ورودی روی زمینهٔ همیشه تیرهٔ زنگ، مستقل از تم روشن/تیره. */
@Composable
private fun ringFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    cursorColor = DawnGold,
    focusedBorderColor = DawnPink,
    unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
    errorBorderColor = Color(0xFFFB7185),
    errorTextColor = Color.White,
    focusedContainerColor = Color.White.copy(alpha = 0.07f),
    unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
    errorContainerColor = Color(0xFFFB7185).copy(alpha = 0.08f),
)

/* ------------------------------ ریاضی ------------------------------ */

@Composable
private fun MathBody(alarm: Alarm, needed: Int, onSolved: () -> Unit) {
    var solved by remember { mutableIntStateOf(0) }
    var problem by remember { mutableStateOf(MathMission.generate(alarm.difficulty)) }
    var input by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    fun check() {
        val given = input.trim().toIntOrNull()
        if (given == null) { wrong = true; return }
        if (given == problem.answer) {
            solved += 1
            input = ""
            wrong = false
            if (solved >= needed) onSolved()
            else problem = MathMission.generate(alarm.difficulty)
        } else {
            /* جواب غلط: سؤال تازه، تا کسی با حدس زدن رد نشود. */
            wrong = true
            input = ""
            problem = MathMission.generate(alarm.difficulty)
        }
    }

    MissionCaption("🧮 سؤال " + (solved + 1).fa() + " از " + needed.fa() + " · " + MathMission.label(alarm.difficulty))
    MissionDots(solved, needed)
    MissionCard {
        val shake = wrongShake(wrong, solved, problem.text)
        androidx.compose.material3.Text(
            problem.text + " = ?",
            color = Color.White,
            fontSize = 36.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.graphicsLayer { translationX = shake * density },
        )
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { v -> input = v.filter { it.isDigit() || it == '-' }.take(6) },
            singleLine = true,
            isError = wrong,
            placeholder = { Text("جواب", color = Color.White.copy(alpha = 0.35f)) },
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { check() }),
            colors = ringFieldColors(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
        )
        if (wrong) {
            Spacer(Modifier.height(6.dp))
            Text("درست نبود؛ یک سؤال تازه.", color = Color(0xFFFB7185), fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        RingButton("تأیید", onClick = { check() }, enabled = input.isNotBlank())
    }
}

/** لرزش افقی کوتاه وقتی جواب غلط است. */
@Composable
private fun wrongShake(wrong: Boolean, vararg keys: Any): Float {
    val anim = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(wrong, *keys) {
        if (wrong) {
            anim.snapTo(0f)
            anim.animateTo(
                0f,
                keyframes {
                    durationMillis = 420
                    -14f at 50
                    12f at 120
                    -9f at 200
                    6f at 280
                    -3f at 350
                },
            )
        }
    }
    return anim.value
}

/* ------------------------------- تایپ ------------------------------- */

@Composable
private fun TypingBody(alarm: Alarm, needed: Int, onSolved: () -> Unit) {
    var done by remember { mutableIntStateOf(0) }
    var sentence by remember { mutableStateOf(TypingMission.sentence(alarm.difficulty)) }
    var input by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    fun check() {
        if (TypingMission.matches(sentence, input)) {
            done += 1
            input = ""
            wrong = false
            if (done >= needed) onSolved() else sentence = TypingMission.sentence(alarm.difficulty)
        } else {
            wrong = true
        }
    }

    MissionCaption("⌨️ جملهٔ " + (done + 1).fa() + " از " + needed.fa() + " · عیناً تایپ کن")
    MissionDots(done, needed)
    MissionCard {
        Text(
            "«" + sentence + "»",
            color = Color.White,
            fontSize = 19.sp,
            lineHeight = 30.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { input = it.take(80); wrong = false },
            singleLine = false,
            isError = wrong,
            placeholder = { Text("همان جمله را بنویس", color = Color.White.copy(alpha = 0.35f)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { check() }),
            colors = ringFieldColors(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
        )
        if (wrong) {
            Spacer(Modifier.height(6.dp))
            Text("هنوز مو‌به‌مو نشده.", color = Color(0xFFFB7185), fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        RingButton("تأیید", onClick = { check() }, enabled = input.isNotBlank())
    }
}

/* ------------------------------ تکان دادن ------------------------------ */

/**
 * شمارش تکان‌ها با شتاب‌سنج.
 *
 * چرا این هم لازم بود: کسی که با سؤال ریاضی هم جواب می‌دهد و دوباره می‌خوابد،
 * با سی بار تکان دادن گوشی عملاً از تخت بیرون می‌آید. آستانه عمداً بالاست تا
 * تکان‌های خواب‌آلود روی بالش حساب نشود.
 */
@Composable
private fun ShakeBody(alarm: Alarm, needed: Int, onSolved: () -> Unit) {
    val ctx = LocalContext.current
    val target = needed * when (alarm.difficulty.coerceIn(1, 3)) { 1 -> 8; 2 -> 12; else -> 18 }
    var count by remember { mutableIntStateOf(0) }
    val progress by animateFloatAsState(
        (count.toFloat() / target).coerceIn(0f, 1f), tween(220), label = "shake",
    )

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var lastPeak = 0L
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val g = kotlin.math.sqrt(
                    (e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble(),
                ) / SensorManager.GRAVITY_EARTH
                val now = System.currentTimeMillis()
                if (g > 2.2 && now - lastPeak > 220) {
                    lastPeak = now
                    count += 1
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { runCatching { sm?.unregisterListener(listener) } }
    }

    /* پایان مأموریت حتماً روی ترد اصلی اعلام می‌شود؛ شنوندهٔ سنسور ترد خودش را دارد. */
    LaunchedEffect(count) { if (count >= target) onSolved() }

    /* گوشی بدون شتاب‌سنج: مأموریت به ریاضی برمی‌گردد، نه به بن‌بست. */
    val hasSensor = remember {
        (ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager)
            ?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
    }
    if (!hasSensor) {
        MathBody(alarm, needed, onSolved)
        return
    }

    MissionCaption("📳 گوشی را تکان بده")
    MissionCard {
        val wob by rememberInfiniteTransition(label = "phone").animateFloat(
            -12f, 12f,
            infiniteRepeatable(tween(180, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "phoneWob",
        )
        Text("📱", fontSize = 52.sp, modifier = Modifier.graphicsLayer { rotationZ = wob })
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(count.fa(), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text(" / " + target.fa(), color = Color.White.copy(alpha = 0.55f), fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.fillMaxWidth().height(14.dp).clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
        ) {
            Box(
                Modifier.fillMaxWidth(progress).height(14.dp).clip(CircleShape)
                    .background(Brush.horizontalGradient(listOf(RingGreen, RingMint, DawnGold)))
                    .shine(periodMs = 1400),
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "محکم تکان بده تا شمرده شود",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 12.sp,
        )
    }
}

/* ------------------------------- تعویق ------------------------------- */

@Composable
private fun SnoozeRow(alarm: Alarm, wakeCheck: Boolean, onSnooze: () -> Unit) {
    /* تعویق: فقط اگر کاربر خودش اجازه داده و سهمیه‌اش تمام نشده. */
    val used = AlarmStore.snoozedCount(alarm.id)
    val canSnooze = !wakeCheck && alarm.snoozeMinutes > 0 && used < alarm.snoozeLimit
    if (canSnooze) {
        Row(
            Modifier
                .padding(top = 14.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.10f))
                .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape)
                .bouncyClick(onClick = onSnooze)
                .padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("💤", fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                "تعویق " + alarm.snoozeMinutes.fa() + " دقیقه‌ای (" +
                    (alarm.snoozeLimit - used).fa() + " بار مانده)",
                color = Color.White.copy(alpha = 0.85f),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
            )
        }
    } else if (!wakeCheck && alarm.snoozeMinutes > 0) {
        Text(
            "سهمیهٔ تعویق تمام شد.",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 12.dp),
        )
    }
}

/** قالب مشترک صفحهٔ زنگ: آسمان سپیده‌دم، زنگولهٔ لرزان، ساعت و بدنهٔ مأموریت. */
@Composable
private fun RingFrame(clock: String, alarm: Alarm, wakeCheck: Boolean, body: @Composable () -> Unit) {
    val pulse by rememberInfiniteTransition(label = "ring").animateFloat(
        0.98f, 1.03f,
        infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulse",
    )
    Box(Modifier.fillMaxSize().background(Color(0xFF0B1026))) {
        AuroraBackdrop(
            Modifier.fillMaxSize(),
            base = listOf(Color(0xFF070B1F), Color(0xFF1B1446), Color(0xFF3A1650)),
            blobs = listOf(DawnPink.copy(alpha = 0.30f), DawnGold.copy(alpha = 0.20f), Color(0xFF38BDF8).copy(alpha = 0.20f)),
            periodMs = 11000,
        )
        StarField(Modifier.fillMaxSize(), count = 60, seed = 5, maxAlpha = 0.75f)
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            GlassPill(
                if (wakeCheck) "چک بیداری" else "وقت بیدار شدن",
                leading = if (wakeCheck) "⏱" else "⏰",
                tint = Color(0xFFFDE68A),
                style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
            )
            Spacer(Modifier.height(10.dp))
            Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                RippleRings(Modifier.fillMaxSize(), color = DawnPink, rings = 3, periodMs = 2100, strokeWidth = 2.dp, filled = true)
                Box(
                    Modifier
                        .size(80.dp)
                        .graphicsLayer { scaleX = pulse; scaleY = pulse }
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(DawnPink, DawnGold))),
                    contentAlignment = Alignment.Center,
                ) {
                    WobblingBell(tint = Color.White, size = 40.dp, icon = Icons.Rounded.NotificationsActive, periodMs = 1300)
                }
            }
            Spacer(Modifier.height(6.dp))
            RollingText(
                clock,
                style = androidx.compose.ui.text.TextStyle(fontSize = 54.sp, fontWeight = FontWeight.Black),
                color = Color.White,
            )
            if (alarm.label.isNotBlank()) {
                Text(alarm.label, color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                if (wakeCheck) "ده دقیقه گذشت — ثابت کن بیدار مانده‌ای."
                else "تا جواب درست ندهی، صدا قطع نمی‌شود.",
                color = Color.White.copy(alpha = 0.62f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(18.dp))
            body()
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun nowClock(): String =
    SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()).fa()
