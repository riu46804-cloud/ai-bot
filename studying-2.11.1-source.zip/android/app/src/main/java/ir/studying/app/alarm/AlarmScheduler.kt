package ir.studying.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * زمان‌بندی زنگ‌ها.
 *
 * از [AlarmManager.setAlarmClock] استفاده می‌شود، نه setExact: فقط همین نوع
 * آلارم است که اندروید حتی در Doze و حالت صرفه‌جویی باتری سر وقت بیدار می‌کند
 * و آیکون زنگ را در نوار وضعیت نشان می‌دهد. اگر کاربر اجازهٔ آلارم دقیق را
 * نداده باشد، به setAndAllowWhileIdle برمی‌گردیم — کمی بی‌دقت، ولی کار می‌کند.
 *
 * ساعت زنگ با ساعت خودِ گوشی حساب می‌شود، نه تهران: کسی که ساعت ۶:۳۰ زنگ
 * می‌گذارد، ۶:۳۰ ساعت دیوار اتاقش را می‌گوید.
 */
object AlarmScheduler {

    const val ACTION_FIRE = "ir.studying.app.alarm.FIRE"
    const val ACTION_WAKE_CHECK = "ir.studying.app.alarm.WAKE_CHECK"
    /** تلنگرِ چند ثانیه‌ای برای برگرداندن صفحهٔ زنگ (پایین‌تر توضیح داده شده). */
    const val ACTION_KICK = "ir.studying.app.alarm.KICK"
    /** نگهبان دوره‌ای: هر ربع ساعت چک می‌کند زنگ‌ها هنوز سر جایشان هستند. */
    const val ACTION_WATCHDOG = "ir.studying.app.alarm.WATCHDOG"
    const val EXTRA_ID = "alarm_id"

    /** شناسهٔ درخواست: زنگ و چکِ بیداریِ همان زنگ نباید همدیگر را پاک کنند. */
    private fun req(id: Int, wakeCheck: Boolean) = (if (wakeCheck) 900_000 else 800_000) + id
    private fun kickReq(id: Int) = 700_000 + id
    private const val WATCHDOG_REQ = 600_001
    private const val WATCHDOG_EVERY = 15L * 60L * 1000L

    private fun pending(context: Context, id: Int, wakeCheck: Boolean): PendingIntent {
        val i = Intent(context, AlarmReceiver::class.java)
            .setAction(if (wakeCheck) ACTION_WAKE_CHECK else ACTION_FIRE)
            .putExtra(EXTRA_ID, id)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, req(id, wakeCheck), i, flags)
    }

    private fun kickPending(context: Context, id: Int, wakeCheck: Boolean): PendingIntent {
        val i = Intent(context, AlarmReceiver::class.java)
            .setAction(ACTION_KICK)
            .putExtra(EXTRA_ID, id)
            .putExtra("wake_check", wakeCheck)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, kickReq(id), i, flags)
    }

    /**
     * تلنگر: چند ثانیهٔ دیگر دوباره از اندروید بخواه صفحهٔ زنگ را بالا بیاورد.
     *
     * چرا لازم است: از اندروید ۱۰ اجرای اکتیویتی از پس‌زمینه ممنوع است و
     * سرویسِ در حال زنگ زدن فقط چند ثانیه بعد از شلیکِ آلارم اجازه دارد. اگر
     * کاربر صفحه را کنار بزند، بدون این تلنگر دیگر هیچ‌وقت برنمی‌گردد. هر
     * شلیکِ AlarmClock دوباره همان اجازهٔ کوتاه را می‌دهد.
     */
    fun armKick(context: Context, id: Int, wakeCheck: Boolean, delayMs: Long = 3_000L) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = kickPending(ctx, id, wakeCheck)
        val at = System.currentTimeMillis() + delayMs
        runCatching {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setAlarmClock(AlarmManager.AlarmClockInfo(at, pi), pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancelKick(context: Context, id: Int) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        runCatching { am.cancel(kickPending(ctx, id, false)) }
    }

    /**
     * نگهبان دوره‌ای.
     *
     * چرا: PendingIntentهای آلارم شکننده‌اند — آپدیت اپ، Force Stop توسط
     * پوستهٔ سازنده، پاک‌سازی باتری، تغییر ساعت سیستم یا حتی کشته‌شدن پروسه
     * می‌تواند زنگ فردا صبح را بی‌سروصدا ببلعد. هر ربع ساعت یک آلارم سبک
     * بیدار می‌شود، همه را از نو می‌چیند و اگر زنگی از قلم افتاده باشد در
     * دفترچه ثبتش می‌کند. مصرفش ناچیز است، ولی همین است که فرق «زنگ» با
     * «یادآور» را می‌سازد.
     */
    fun armWatchdog(context: Context) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_WATCHDOG)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pi = PendingIntent.getBroadcast(ctx, WATCHDOG_REQ, i, flags)
        runCatching {
            am.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + WATCHDOG_EVERY, pi,
            )
        }
    }

    /** آخرین زمانی که این زنگ باید زده می‌شد (در گذشته). */
    fun prevTrigger(alarm: Alarm, before: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = before
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis > before) c.add(Calendar.DAY_OF_YEAR, -1)
        if (alarm.days.isEmpty()) return c.timeInMillis
        for (step in 0..7) {
            if (alarm.days.contains(c.get(Calendar.DAY_OF_WEEK))) return c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, -1)
        }
        return c.timeInMillis
    }

    /** نزدیک‌ترین زمان بعدیِ این زنگ، بر ساعت گوشی. */
    fun nextTrigger(alarm: Alarm, from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (alarm.days.isEmpty()) {
            if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis
        }
        /* حداکثر هفت روز جلو می‌رویم تا به یکی از روزهای انتخابی برسیم. */
        for (step in 0..7) {
            if (c.timeInMillis > from && alarm.days.contains(c.get(Calendar.DAY_OF_WEEK))) return c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }

    fun reschedule(context: Context, alarm: Alarm) {
        val ctx = context.applicationContext
        cancel(ctx, alarm.id)
        if (!alarm.enabled) return
        arm(ctx, alarm.id, nextTrigger(alarm), wakeCheck = false)
    }

    /** چک بیداری: همان زنگ، [minutes] دقیقه بعد، با پیام متفاوت. */
    fun scheduleWakeCheck(context: Context, alarm: Alarm) {
        if (alarm.wakeCheckMinutes <= 0) return
        arm(
            context.applicationContext, alarm.id,
            System.currentTimeMillis() + alarm.wakeCheckMinutes * 60_000L,
            wakeCheck = true,
        )
    }

    fun cancelWakeCheck(context: Context, id: Int) {
        val am = context.applicationContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        runCatching { am.cancel(pending(context.applicationContext, id, true)) }
    }

    /** تعویق: همین زنگ، چند دقیقه بعد. */
    fun snooze(context: Context, alarm: Alarm) {
        if (alarm.snoozeMinutes <= 0) return
        AlarmStore.bumpSnoozed(alarm.id)
        arm(
            context.applicationContext, alarm.id,
            System.currentTimeMillis() + alarm.snoozeMinutes * 60_000L,
            wakeCheck = false,
        )
    }

    private fun arm(context: Context, id: Int, atMs: Long, wakeCheck: Boolean) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = pending(context, id, wakeCheck)
        runCatching {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(atMs, pi), pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            }
        }
    }

    fun cancel(context: Context, id: Int) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        runCatching { am.cancel(pending(ctx, id, false)) }
        runCatching { am.cancel(pending(ctx, id, true)) }
        runCatching { am.cancel(kickPending(ctx, id, false)) }
    }

    /** نزدیک‌ترین زنگ روشن، برای کارت صفحهٔ اصلی. */
    fun nextAcross(alarms: List<Alarm>): Pair<Alarm, Long>? =
        alarms.filter { it.enabled }
            .map { it to nextTrigger(it) }
            .minByOrNull { it.second }
}
