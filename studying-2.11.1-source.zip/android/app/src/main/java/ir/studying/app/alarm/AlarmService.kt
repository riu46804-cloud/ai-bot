package ir.studying.app.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import ir.studying.app.R

/**
 * سرویسِ صدای زنگ.
 *
 * چرا سرویس و نه پخش داخل Activity: اگر کاربر صفحهٔ زنگ را با دکمهٔ Recents
 * کنار بزند، Activity از بین می‌رود و با آن صدا هم قطع می‌شود — یعنی زنگی که
 * با یک حرکت خاموش می‌شود، همان چیزی که قرار بود حل کنیم. صدا در یک سرویس
 * foreground زندگی می‌کند و فقط با انجام مأموریت یا تعویق می‌ایستد.
 *
 * WakeLock هم لازم است: بدون آن گوشی می‌تواند وسط زنگ دوباره بخوابد.
 */
class AlarmService : Service() {

    companion object {
        const val CH_ALARM = "alarm_clock"
        const val EXTRA_ID = "alarm_id"
        const val EXTRA_WAKE_CHECK = "wake_check"
        private const val NOTE_ID = 1301

        /** سقف امن مطلق: هیچ زنگی بیشتر از این صدا نمی‌دهد. */
        private const val MAX_RING_MS = 30L * 60L * 1000L

        /**
         * زنگِ در حال پخش.
         *
         * صفحهٔ زنگ از این می‌خواند تا بفهمد باید خودش را دوباره جلو بیندازد
         * یا نه؛ و سرویس از همین برای «نگهبان» استفاده می‌کند.
         */
        @Volatile
        var ringingId: Int = -1

        @Volatile
        var ringingWakeCheck: Boolean = false

        /**
         * آیا پوششِ داخلِ اپ همین حالا مأموریت را نشان می‌دهد؟
         *
         * اگر بله، نگهبان نباید اکتیویتی را هم جلو بیندازد؛ وگرنه دو صفحهٔ
         * زنگ سر کاربر دعوا می‌کنند.
         */
        @Volatile
        var overlayVisible: Boolean = false

        /** لحظهٔ شروع زنگِ فعلی؛ «چند ثانیه طول کشید تا بیدار شد» از همین درمی‌آید. */
        @Volatile
        var ringStartedAt: Long = 0L

        fun ringingSeconds(): Int =
            if (ringStartedAt <= 0L) 0
            else ((System.currentTimeMillis() - ringStartedAt) / 1000L).toInt().coerceIn(0, 7200)

        /** زنگِ در حال پخش، برای رابط کاربری. */
        data class Ringing(val id: Int, val wakeCheck: Boolean, val startedAt: Long)

        private val _ringing = kotlinx.coroutines.flow.MutableStateFlow<Ringing?>(null)

        /**
         * چرا StateFlow: از حالا خودِ اپ هم باید زنگ را نشان بدهد.
         *
         * روی اندروید ۱۰ به بعد اجرای اکتیویتی از پس‌زمینه ممکن است رد شود؛
         * ولی اگر کاربر همان موقع داخل اپ باشد، اپ می‌تواند بدون هیچ مجوزی
         * صفحهٔ مأموریت را روی خودش بیندازد. این جریان همان سیم رابط است.
         */
        val ringing: kotlinx.coroutines.flow.StateFlow<Ringing?> get() = _ringing

        fun start(context: Context, id: Int, wakeCheck: Boolean) {
            val i = Intent(context, AlarmService::class.java)
                .putExtra(EXTRA_ID, id).putExtra(EXTRA_WAKE_CHECK, wakeCheck)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
                else context.startService(i)
            }
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, AlarmService::class.java)) }
        }

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(
                NotificationChannel(CH_ALARM, "زنگ بیدارباش", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "صدای زنگ و صفحهٔ مأموریت بیدار شدن"
                    setSound(null, null) // صدا را خودمان پخش می‌کنیم، با بلندی کنترل‌شده.
                    enableVibration(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                },
            )
        }
    }

    private var player: MediaPlayer? = null
    private var current: Alarm? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var volume = 0.25f

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra(EXTRA_ID, 0) ?: 0
        val wakeCheck = intent?.getBooleanExtra(EXTRA_WAKE_CHECK, false) ?: false
        AlarmStore.init(this)
        val alarm = AlarmStore.of(id)

        ensureChannel(this)
        startForeground(NOTE_ID, notification(id, wakeCheck, alarm))

        /* شلیک دوباره برای همان زنگ (مثلاً بعد از START_STICKY) نباید صدا را
           از اول شروع کند یا دو پخش‌کننده بسازد. */
        if (ringingId == id && player != null) return START_STICKY

        ringingId = id
        ringingWakeCheck = wakeCheck
        ringStartedAt = System.currentTimeMillis()
        _ringing.value = Ringing(id, wakeCheck, ringStartedAt)
        current = alarm
        runCatching { AlarmLog.fired(this, id, alarm, wakeCheck) }

        acquireWakeLock()
        play(alarm)
        if (alarm?.vibrate != false) vibrate()
        guard(id, wakeCheck)

        /* سقف امن. نبودش یعنی یک زنگ فراموش‌شده تا شب صدا می‌دهد. */
        val cap = ((alarm?.autoSilenceMinutes ?: 15).takeIf { it > 0 }?.times(60_000L) ?: MAX_RING_MS)
            .coerceAtMost(MAX_RING_MS)
        handler.postDelayed({
            /* اینجا یعنی هیچ‌کس جواب نداد: خاموش‌کردنِ موفق، سرویس را از بین
               می‌برد و همین callback را هم پاک می‌کند. پس فقط «از دست رفته». */
            runCatching { AlarmLog.missed(this, id, alarm) }
            stopSelf()
        }, cap)
        return START_STICKY
    }

    private fun notification(id: Int, wakeCheck: Boolean, alarm: Alarm?): Notification {
        val full = Intent(this, AlarmRingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_WAKE_CHECK, wakeCheck)
        val pi = PendingIntent.getActivity(
            this, 1300 + id, full,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val title = if (wakeCheck) "چک بیداری" else (alarm?.label?.takeIf { it.isNotBlank() } ?: "وقت بیدار شدن")
        val text = if (wakeCheck) "بیدار مانده‌ای؟ برای تأییدش مأموریت را انجام بده."
                   else "برای خاموش‌کردن، مأموریت را انجام بده."
        return NotificationCompat.Builder(this, CH_ALARM)
            .setSmallIcon(R.drawable.ic_splash)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(pi)
            /* صفحهٔ زنگ باید روی صفحهٔ قفل هم بیاید؛ همین کار را می‌کند. */
            .setFullScreenIntent(pi, true)
            .build()
    }

    private fun acquireWakeLock() {
        runCatching {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "studying:alarm").apply {
                setReferenceCounted(false)
                acquire(MAX_RING_MS + 60_000L)
            }
        }
    }

    /**
     * صدای انتخابی کاربر.
     *
     * سه حالت: خالی = زنگ پیش‌فرض گوشی، «raw:xxx» = صدای داخل اپ، و هر چیز
     * دیگر = URI آهنگی که خودش از گوشی انتخاب کرده. اگر آن URI دیگر در دسترس
     * نباشد (فایل پاک شده)، به زنگ پیش‌فرض برمی‌گردیم — زنگِ بی‌صدا یعنی
     * خواب ماندن.
     */
    private fun soundUri(alarm: Alarm?): Uri {
        val raw = alarm?.soundUri.orEmpty()
        if (raw.startsWith("raw:")) {
            val name = raw.removePrefix("raw:")
            val id = resources.getIdentifier(name, "raw", packageName)
            if (id != 0) return Uri.parse("android.resource://$packageName/$id")
        } else if (raw.isNotBlank()) {
            return Uri.parse(raw)
        }
        return defaultUri()
    }

    private fun defaultUri(): Uri =
        RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
            ?: Uri.parse("content://settings/system/alarm_alert")

    private fun play(alarm: Alarm?) {
        val target = ((alarm?.volumePercent ?: 100).coerceIn(20, 100)) / 100f
        val rampSec = (alarm?.rampSeconds ?: 30).coerceIn(0, 300)
        volume = if (rampSec > 0) (target * 0.12f).coerceAtLeast(0.05f) else target
        val started = runCatching { open(soundUri(alarm)) }.getOrDefault(false)
        /* اگر آهنگ انتخابی باز نشد، بی‌صدا نمی‌مانیم. */
        if (!started) runCatching { open(defaultUri()) }
        if (rampSec > 0) rampUp(target, rampSec)
    }

    private fun open(uri: Uri): Boolean {
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            setDataSource(this@AlarmService, uri)
            isLooping = true
            /* کانال آلارم را هم بالا می‌بریم: اگر کاربر شب صدا را صفر کرده
               باشد، زنگِ بی‌صدا فایده‌ای ندارد. بلندیِ دلخواه کاربر بعد از
               آن با ضریب خودِ پخش‌کننده اعمال می‌شود. */
            runCatching {
                val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                am?.let { it.setStreamVolume(AudioManager.STREAM_ALARM, it.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) }
            }
            setVolume(volume, volume)
            prepare()
            start()
        }
        return true
    }

    /** بلندی صدا پله‌پله بالا می‌رود؛ بیدار شدن با نعره لازم نیست. */
    private fun rampUp(target: Float, seconds: Int) {
        val steps = 12
        val stepMs = (seconds * 1000L / steps).coerceAtLeast(300L)
        val delta = (target - volume) / steps
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (volume >= target) return
                volume = (volume + delta).coerceAtMost(target)
                runCatching { player?.setVolume(volume, volume) }
                handler.postDelayed(this, stepMs)
            }
        }, stepMs)
    }

    /**
     * نگهبان: هر چند ثانیه صفحهٔ زنگ را دوباره جلو می‌آورد.
     *
     * بدون این، کافی بود کاربر صفحه را با Recents کنار بزند یا دکمهٔ Home را
     * بزند تا زنگ عملاً «غیب» شود؛ صدا می‌ماند ولی راه خاموش کردنش پیدا نبود.
     * حالا تا وقتی مأموریت انجام نشده، صفحه برمی‌گردد و نوتیفیکیشن تمام‌صفحه
     * هم دوباره ارسال می‌شود (برای وقتی که اجرای اکتیویتی از پس‌زمینه رد شود).
     */
    private fun guard(id: Int, wakeCheck: Boolean) {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (ringingId < 0) return
                if (!AlarmRingActivity.visible && !overlayVisible) {
                    val i = Intent(this@AlarmService, AlarmRingActivity::class.java)
                        .addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                Intent.FLAG_ACTIVITY_SINGLE_TOP,
                        )
                        .putExtra(EXTRA_ID, id)
                        .putExtra(EXTRA_WAKE_CHECK, wakeCheck)
                    runCatching { startActivity(i) }
                    runCatching {
                        getSystemService(NotificationManager::class.java)
                            ?.notify(NOTE_ID, notification(id, wakeCheck, current))
                    }
                    /* اجرای اکتیویتی از پس‌زمینه ممکن است رد شود؛ شلیک دوبارهٔ
                       آلارم همان اجازهٔ کوتاه را از نو می‌گیرد. */
                    AlarmScheduler.armKick(this@AlarmService, id, wakeCheck)
                }
                handler.postDelayed(this, 4_000L)
            }
        }, 4_000L)
    }

    /**
     * کنار زدن اپ از Recents نباید زنگ را بکشد.
     *
     * سرویس دوباره راه می‌افتد (START_STICKY) و صفحه هم برمی‌گردد.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (ringingId >= 0) {
            runCatching {
                startActivity(
                    Intent(this, AlarmRingActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(EXTRA_ID, ringingId)
                        .putExtra(EXTRA_WAKE_CHECK, ringingWakeCheck),
                )
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun vibrate() {
        runCatching {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            val pattern = longArrayOf(0, 600, 700)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    override fun onDestroy() {
        runCatching { if (ringingId >= 0) AlarmScheduler.cancelKick(this, ringingId) }
        ringingId = -1
        ringStartedAt = 0L
        _ringing.value = null
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { vibrator?.cancel() }
        runCatching { wakeLock?.release() }
        wakeLock = null
        super.onDestroy()
    }
}
