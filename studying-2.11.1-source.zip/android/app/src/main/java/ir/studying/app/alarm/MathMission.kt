package ir.studying.app.alarm

import kotlin.random.Random

/**
 * سؤال‌های ریاضیِ خاموش‌کردن زنگ.
 *
 * منطقش ساده ولی مهم است: سؤال باید آن‌قدر سخت باشد که مغز روشن شود، و
 * آن‌قدر ساده که با چشمِ نیم‌باز شدنی باشد. پس هیچ سؤالی جواب منفی یا اعشاری
 * ندارد و ضرب‌ها از جدول ضرب خارج نمی‌شوند.
 */
object MathMission {

    data class Problem(val text: String, val answer: Int)

    /** [difficulty]: ۱ ساده، ۲ متوسط، ۳ سخت. */
    fun generate(difficulty: Int, rnd: Random = Random.Default): Problem = when (difficulty.coerceIn(1, 3)) {
        1 -> {
            val a = rnd.nextInt(5, 40)
            val b = rnd.nextInt(3, 30)
            if (rnd.nextBoolean()) Problem("$a + $b", a + b)
            else Problem("${a + b} − $b", a)
        }
        2 -> {
            when (rnd.nextInt(3)) {
                0 -> {
                    val a = rnd.nextInt(3, 13); val b = rnd.nextInt(3, 13)
                    Problem("$a × $b", a * b)
                }
                1 -> {
                    val a = rnd.nextInt(24, 99); val b = rnd.nextInt(11, 48)
                    Problem("$a + $b", a + b)
                }
                else -> {
                    val b = rnd.nextInt(3, 12); val q = rnd.nextInt(3, 13)
                    Problem("${b * q} ÷ $b", q)
                }
            }
        }
        else -> {
            when (rnd.nextInt(3)) {
                0 -> {
                    val a = rnd.nextInt(12, 26); val b = rnd.nextInt(11, 20)
                    Problem("$a × $b", a * b)
                }
                1 -> {
                    val a = rnd.nextInt(4, 13); val b = rnd.nextInt(3, 10); val c = rnd.nextInt(5, 40)
                    Problem("$a × $b + $c", a * b + c)
                }
                else -> {
                    val a = rnd.nextInt(3, 10)
                    val b = rnd.nextInt(3, 10)
                    val c = rnd.nextInt(2, 9)
                    Problem("($a + $b) × $c", (a + b) * c)
                }
            }
        }
    }

    fun label(difficulty: Int): String = when (difficulty.coerceIn(1, 3)) {
        1 -> "ساده"
        2 -> "متوسط"
        else -> "سخت"
    }
}
