package ir.studying.app.alarm

import kotlin.random.Random

/**
 * مأموریت تایپ: یک جملهٔ کوتاه فارسی باید مو‌به‌مو تایپ شود.
 *
 * چرا کنار ریاضی: بعضی‌ها نیمه‌خواب هم جمع و ضرب را درست جواب می‌دهند، ولی
 * تایپ کردن یک جمله بدون باز کردن چشم ممکن نیست. جمله‌ها عمداً دربارهٔ خودِ
 * صبح و درس‌اند تا همان لحظه ذهن را به روزِ پیش‌رو وصل کنند.
 */
object TypingMission {

    private val easy = listOf(
        "صبح بخیر",
        "بیدار شدم",
        "امروز می‌خوانم",
        "وقت درس است",
    )

    private val medium = listOf(
        "امروز روز خوبی برای درس خواندن است",
        "یک ساعت مطالعه بهتر از هیچ است",
        "الان بیدار می‌شوم و شروع می‌کنم",
        "برنامهٔ امروزم را جدی می‌گیرم",
    )

    private val hard = listOf(
        "هر صبحی که زود بیدار شوم، یک قدم از دیروز جلوترم",
        "تصمیم دیشبم این بود که امروز سر وقت شروع کنم",
        "خواب بیشتر چیزی به من نمی‌دهد، ولی این ساعت می‌دهد",
    )

    fun sentence(difficulty: Int, rnd: Random = Random.Default): String = when (difficulty.coerceIn(1, 3)) {
        1 -> easy.random(rnd)
        2 -> medium.random(rnd)
        else -> hard.random(rnd)
    }

    /**
     * مقایسهٔ آسان‌گیرانه اما نه بی‌خیال.
     *
     * فاصله‌های اضافه، نیم‌فاصله و «ي/ك» عربی نباید کاربرِ نیمه‌خواب را شکست
     * بدهند؛ ولی کلمه‌ها باید همان کلمه‌ها باشند.
     */
    fun matches(target: String, typed: String): Boolean = normalize(target) == normalize(typed)

    fun normalize(s: String): String = s
        .replace('\u064A', '\u06CC') // ي عربی → ی
        .replace('\u0643', '\u06A9') // ك عربی → ک
        .replace('\u200C', ' ')      // نیم‌فاصله = فاصله
        .replace(Regex("[\\u064B-\\u0652]"), "")
        .replace(Regex("[.،!؟?]"), "")
        .trim()
        .replace(Regex("\\s+"), " ")
}
