package ir.studying.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import okio.buffer
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * [body] بدنهٔ JSON خطا اگر سرور فرستاده باشد (مثلاً error_ref و retry دستیار)؛
 * [cause] خطای اصلی شبکه، تا بشود «اینترنت قطع است» را از «دیر جواب داد» جدا کرد.
 */
class ApiException(
    message: String,
    val code: Int = 0,
    val errorCode: String? = null,
    val body: JSONObject? = null,
    cause: Throwable? = null,
) : Exception(message, cause) {
    /** درخواست اصلاً به سرور نرسید یا جوابش نیامد (نه خطای خودِ سرور). */
    val isNetwork: Boolean get() = code == 0 && errorCode == null && cause != null
}

/** خطاهای فنی/شبکه را به پیام فارسی تمیز تبدیل می‌کند — هرگز نام هاست یا جزئیات فنی لو نمی‌رود. */
fun humanizeError(e: Throwable): String = when {
    e is ApiException -> e.message ?: "خطایی پیش آمد"
    e is java.net.UnknownHostException -> "اینترنت در دسترس نیست 🌐"
    e is java.net.SocketTimeoutException -> "سرور دیر جواب داد؛ دوباره تلاش کن ⏳"
    e is java.net.ConnectException -> "ارتباط برقرار نشد؛ اتصالت رو چک کن 📡"
    e is javax.net.ssl.SSLException -> "ارتباط امن برقرار نشد؛ دوباره تلاش کن 🔒"
    e is java.io.IOException -> "مشکل در اتصال — اینترنتت رو بررسی کن 🌐"
    else -> "خطایی پیش آمد؛ دوباره تلاش کن"
}

object Api {
    // NEW SERVER (studying.ir). Old host was beautifulrabor.ir (legacy)
    const val HOST = "studying.ir"
    const val BASE = "https://studying.ir/api.php"
    const val MEDIA_BASE = "https://studying.ir/"
    // Media gateway: once media.php is live, signed links come from the server,
    // so mediaUrl() below keeps working for both plain and signed paths.
    const val MEDIA_GATEWAY = "https://studying.ir/media.php"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private val messageSendClient by lazy { MessageSendTransport.client(client) }

    /** دستیار هوشمند ممکن است چند ابزار پشت‌سرهم صدا بزند؛ برای همین صبر بیشتری لازم است. */
    private val slowClient by lazy {
        client.newBuilder()
            .readTimeout(120, TimeUnit.SECONDS)
            .callTimeout(130, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Private media used to arrive as a signed link that died after six hours.
     * Any screen restored from cache — which is most of them — then showed
     * broken images and files that refused to open. The signature is dropped
     * here and the session token is used instead: the URL is now stable, so the
     * image cache actually hits, and it stays valid as long as the login does.
     */
    fun mediaUrl(path: String?): String? {
        if (path.isNullOrBlank()) return null
        /* آواتار آمادهٔ داخل اپ آدرس اینترنتی ندارد؛ نباید دنبال دانلودش برویم. */
        if (Avatars.isBuiltin(path)) return null
        val raw = if (path.startsWith("http")) path else MEDIA_BASE + path.trimStart('/')
        val marker = "media.php?"
        val q = raw.indexOf(marker)
        if (q < 0) return raw
        val p = raw.substring(q + marker.length)
            .split('&')
            .firstOrNull { it.startsWith("p=") }
            ?.removePrefix("p=")
            ?: return raw
        val token = Store.token ?: return raw
        return MEDIA_GATEWAY + "?p=" + p + "&t=" + URLEncoder.encode(token, "UTF-8")
    }

    /**
     * Avatars go through this instead of [mediaUrl]. The stored path is stable
     * across uploads, so the version marker is the only thing that tells the
     * image loader the picture is different.
     */
    fun avatarUrl(path: String?): String? {
        val base = mediaUrl(path) ?: return null
        val v = Store.prefs.value.avatarVersion
        if (v == 0L) return base
        return base + (if (base.contains('?')) "&" else "?") + "av=" + v
    }

    private fun buildUrl(action: String, query: Map<String, String>): String {
        val sb = StringBuilder("$BASE?action=$action")
        for ((k, v) in query) {
            sb.append('&').append(k).append('=').append(URLEncoder.encode(v, "UTF-8"))
        }
        return sb.toString()
    }

    private fun execute(action: String, method: String, body: JSONObject?, query: Map<String, String>, session: SessionState = Store.session.value, slow: Boolean = false): String {
        val builder = Request.Builder().url(buildUrl(action, query))
        session.token?.let { builder.header("Authorization", "Bearer $it") }
        builder.header("Accept", "application/json")
        when (method) {
            "GET" -> builder.get()
            "DELETE" -> builder.delete()
            else -> {
                val json = (body ?: JSONObject()).toString()
                val payload = json.toRequestBody("application/json; charset=utf-8".toMediaType())
                builder.method(method, if (MessageSendTransport.applies(action, method)) MessageSendTransport.oneShot(payload) else payload)
            }
        }
        val http = when {
            MessageSendTransport.applies(action, method) -> messageSendClient
            slow -> slowClient
            else -> client
        }
        val call = try { http.newCall(builder.build()).execute() } catch (e: Exception) { throw ApiException(humanizeError(e), cause = e) }
        call.use { resp ->
            val text = try { resp.body?.string()?.trim() ?: "" } catch (e: java.io.IOException) { throw ApiException(humanizeError(e), cause = e) }
            if (text.startsWith("{")) {
                val obj = JSONObject(text)
                if (obj.has("error")) {
                    if (resp.code == 401 && action != "login" && action != "register") Store.clearSession(expectedToken = session.token)
                    throw ApiException(obj.str("error"), resp.code, obj.optString("error_code").takeIf { it.isNotBlank() }, obj)
                }
            }
            if (!resp.isSuccessful) throw ApiException("سرور در دسترس نیست (${resp.code}) 🛠", resp.code)
            return text
        }
    }

    suspend fun get(action: String, vararg query: Pair<String, String>): String =
        withContext(Dispatchers.IO) { execute(action, "GET", null, query.toMap()) }

    suspend fun post(action: String, body: JSONObject = JSONObject(), vararg query: Pair<String, String>): String =
        withContext(Dispatchers.IO) { execute(action, "POST", body, query.toMap()) }

    /** مثل [post] ولی با مهلت طولانی‌تر — برای درخواست‌هایی که سمت سرور زمان‌بر هستند (دستیار هوشمند). */
    suspend fun postSlow(action: String, body: JSONObject = JSONObject()): String =
        withContext(Dispatchers.IO) { execute(action, "POST", body, emptyMap(), slow = true) }

    suspend fun getForSession(action: String, session: SessionState, vararg query: Pair<String, String>): String =
        withContext(Dispatchers.IO) {
            check(Store.session.value == session) { "Session changed" }
            execute(action, "GET", null, query.toMap(), session)
        }

    /** Replay with the captured owner's token, never whichever account logs in during IO dispatch. */
    suspend fun postForSession(action: String, body: JSONObject, session: SessionState): String =
        withContext(Dispatchers.IO) {
            check(Store.session.value == session) { "Session changed" }
            execute(action, "POST", body, emptyMap(), session)
        }

    suspend fun put(action: String, body: JSONObject = JSONObject(), vararg query: Pair<String, String>): String =
        withContext(Dispatchers.IO) { execute(action, "PUT", body, query.toMap()) }

    suspend fun delete(action: String, vararg query: Pair<String, String>): String =
        withContext(Dispatchers.IO) { execute(action, "DELETE", null, query.toMap()) }

    class FilePart(val field: String, val fileName: String, val bytes: ByteArray, val mime: String)

    suspend fun upload(action: String, fields: Map<String, String>, files: List<FilePart>, onProgress: ((Int) -> Unit)? = null): String =
        withContext(Dispatchers.IO) {
            val mp = MultipartBody.Builder().setType(MultipartBody.FORM)
            for ((k, v) in fields) mp.addFormDataPart(k, v)
            for (f in files) {
                mp.addFormDataPart(f.field, f.fileName, f.bytes.toRequestBody(f.mime.toMediaType()))
            }
            val body = mp.build()
            val reqBody = if (onProgress != null) ProgressRequestBody(body, onProgress) else body
            val builder = Request.Builder().url(buildUrl(action, emptyMap())).post(reqBody)
            Store.token?.let { builder.header("Authorization", "Bearer $it") }
            val call = try { client.newCall(builder.build()).execute() } catch (e: Exception) { throw ApiException(humanizeError(e)) }
            call.use { resp ->
                val text = resp.body?.string()?.trim() ?: ""
                if (text.startsWith("{")) {
                    val obj = JSONObject(text)
                    if (obj.has("error")) throw ApiException(obj.str("error"), resp.code, obj.optString("error_code").takeIf { it.isNotBlank() })
                }
                if (!resp.isSuccessful) throw ApiException("سرور در دسترس نیست (${resp.code}) 🛠", resp.code)
                text
            }
        }

    private class ProgressRequestBody(private val delegate: RequestBody, private val onProgress: (Int) -> Unit) : RequestBody() {
        override fun contentType() = delegate.contentType()
        override fun contentLength() = runCatching { delegate.contentLength() }.getOrDefault(-1L)
        override fun writeTo(sink: BufferedSink) {
            val total = contentLength()
            var written = 0L
            val counting = object : okio.ForwardingSink(sink) {
                override fun write(source: okio.Buffer, byteCount: Long) {
                    super.write(source, byteCount)
                    written += byteCount
                    if (total > 0) onProgress(((written * 100) / total).toInt().coerceIn(0, 100))
                }
            }
            val buffered = counting.buffer()
            delegate.writeTo(buffered)
            buffered.flush()
        }
    }

    fun obj(text: String): JSONObject = JSONObject(text)
    fun arr(text: String): JSONArray = JSONArray(text)
}
