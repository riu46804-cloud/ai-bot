package ir.studying.app.core

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Nightlight
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Park
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.QueryStats
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Rocket
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.SentimentSatisfied
import androidx.compose.material.icons.rounded.Square
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Central emoji -> vector icon vocabulary.
 *
 * The app used to draw plain emoji glyphs wherever a small pictogram was
 * needed. Emoji render with the system font, so they changed shape between
 * devices, ignored the app palette and could not be tinted. Everything that is
 * *decoration* now resolves through here to a Material vector instead.
 *
 * Emoji that are genuine user data — the mood a person picked, the icon chosen
 * for a course, chat reactions, ambient-sound labels and room characters — are
 * deliberately NOT routed through this map. Those stay as real emoji.
 */
object AppIcons {

    // Named roles used directly by the UI.
    val Study: ImageVector = Icons.AutoMirrored.Rounded.MenuBook
    val Tasks: ImageVector = Icons.Rounded.TaskAlt
    val Library: ImageVector = Icons.Rounded.LibraryMusic
    val Community: ImageVector = Icons.Rounded.Groups
    val Streak: ImageVector = Icons.Rounded.LocalFireDepartment
    val Trophy: ImageVector = Icons.Rounded.EmojiEvents
    val Goal: ImageVector = Icons.Rounded.TrendingUp
    val Sunrise: ImageVector = Icons.Rounded.WbSunny
    val Offline: ImageVector = Icons.Rounded.WifiTethering
    val Empty: ImageVector = Icons.Rounded.SelfImprovement
    val Chat: ImageVector = Icons.Rounded.ChatBubble
    val Media: ImageVector = Icons.Rounded.AttachFile
    val Locked: ImageVector = Icons.Rounded.Lock
    val Unlocked: ImageVector = Icons.Rounded.LockOpen
    val Celebrate: ImageVector = Icons.Rounded.Celebration

    /**
     * Maps a decorative emoji to its vector equivalent.
     *
     * Returns null when the glyph is user data or has no sensible icon, in
     * which case the caller keeps rendering the emoji unchanged.
     */
    fun forEmoji(raw: String): ImageVector? {
        val e = raw.replace("\uFE0F", "").trim()
        return when (e) {
            "\uD83D\uDCDA" -> Icons.AutoMirrored.Rounded.MenuBook          // books
            "\uD83D\uDCD6" -> Icons.AutoMirrored.Rounded.MenuBook          // open book
            "\u2705" -> Icons.Rounded.TaskAlt                 // check mark
            "\u2713" -> Icons.Rounded.Check
            "\uD83C\uDFB5" -> Icons.Rounded.MusicNote
            "\uD83C\uDFA7" -> Icons.Rounded.Headphones
            "\uD83D\uDC65" -> Icons.Rounded.Groups
            "\uD83E\uDEC2" -> Icons.Rounded.Groups            // people hugging
            "\uD83D\uDCAC" -> Icons.Rounded.ChatBubble
            "\uD83D\uDCCE" -> Icons.Rounded.AttachFile
            "\uD83D\uDD25" -> Icons.Rounded.LocalFireDepartment
            "\uD83C\uDF0B" -> Icons.Rounded.LocalFireDepartment
            "\uD83C\uDFC6" -> Icons.Rounded.EmojiEvents
            "\u2B50" -> Icons.Rounded.Star
            "\uD83C\uDF1F" -> Icons.Rounded.Star
            "\u2728" -> Icons.Rounded.AutoAwesome
            "\uD83E\uDE84" -> Icons.Rounded.AutoAwesome       // magic wand
            "\uD83C\uDF89" -> Icons.Rounded.Celebration
            "\uD83D\uDC4F" -> Icons.Rounded.Celebration
            "\uD83C\uDF31" -> Icons.Rounded.Park              // seedling
            "\uD83C\uDF3F" -> Icons.Rounded.Park
            "\uD83C\uDF43" -> Icons.Rounded.Park
            "\uD83C\uDF32" -> Icons.Rounded.Park
            "\uD83D\uDD01" -> Icons.Rounded.Repeat
            "\uD83D\uDD04" -> Icons.Rounded.Refresh
            "\uD83D\uDD14" -> Icons.Rounded.Notifications
            "\uD83D\uDD15" -> Icons.Rounded.NotificationsOff
            "\uD83D\uDD12" -> Icons.Rounded.Lock
            "\uD83D\uDD13" -> Icons.Rounded.LockOpen
            "\uD83D\uDD0D" -> Icons.Rounded.Search
            "\uD83D\uDCCC" -> Icons.Rounded.PushPin
            "\uD83D\uDCCA" -> Icons.Rounded.Insights
            "\uD83D\uDCC8" -> Icons.Rounded.TrendingUp
            "\uD83C\uDFAF" -> Icons.Rounded.TrendingUp
            "\uD83D\uDCC4" -> Icons.Rounded.Straighten
            "\uD83D\uDCCB" -> Icons.Rounded.TaskAlt
            "\uD83D\uDCDD" -> Icons.Rounded.Edit
            "\u270F" -> Icons.Rounded.Edit
            "\u270D" -> Icons.Rounded.Edit
            "\uD83D\uDDD2" -> Icons.Rounded.Edit
            "\uD83D\uDCF7" -> Icons.Rounded.PhotoCamera
            "\uD83D\uDCF8" -> Icons.Rounded.PhotoCamera
            "\uD83D\uDDBC" -> Icons.Rounded.Image
            "\uD83C\uDFAC" -> Icons.Rounded.Movie
            "\uD83C\uDFA4" -> Icons.Rounded.Mic
            "\uD83D\uDCE2" -> Icons.Rounded.Notifications
            "\uD83D\uDCE3" -> Icons.Rounded.Notifications
            "\uD83C\uDF10" -> Icons.Rounded.Public
            "\uD83C\uDF0D" -> Icons.Rounded.Public
            "\uD83D\uDCE1" -> Icons.Rounded.WifiTethering
            "\uD83D\uDEE0" -> Icons.Rounded.Bolt
            "\u26A1" -> Icons.Rounded.Bolt
            "\uD83D\uDCA1" -> Icons.Rounded.Lightbulb
            "\uD83E\uDDE0" -> Icons.Rounded.Psychology
            "\uD83E\uDDEC" -> Icons.Rounded.Science
            "\uD83E\uDDEA" -> Icons.Rounded.Science
            "\uD83D\uDD2C" -> Icons.Rounded.Science
            "\uD83E\uDDEE" -> Icons.Rounded.Calculate
            "\uD83D\uDCD0" -> Icons.Rounded.Straighten
            "\uD83D\uDCCF" -> Icons.Rounded.Straighten
            "\uD83D\uDCBB" -> Icons.Rounded.Computer
            "\uD83D\uDE80" -> Icons.Rounded.Rocket
            "\uD83D\uDC8E" -> Icons.Rounded.Diamond
            "\u2615" -> Icons.Rounded.LocalCafe
            "\uD83C\uDF19" -> Icons.Rounded.Nightlight
            "\u2600" -> Icons.Rounded.WbSunny
            "\uD83C\uDF05" -> Icons.Rounded.WbSunny
            "\uD83C\uDF0A" -> Icons.Rounded.WaterDrop
            "\u23F0" -> Icons.Rounded.AccessTime
            "\u23F1" -> Icons.Rounded.Timer
            "\u23F3" -> Icons.Rounded.Timer
            "\uD83D\uDD50" -> Icons.Rounded.AccessTime
            "\u2795" -> Icons.Rounded.Add
            "\u2764" -> Icons.Rounded.Favorite
            "\uD83D\uDCBF" -> Icons.Rounded.Album
            "\uD83D\uDD17" -> Icons.Rounded.Link
            else -> null
        }
    }
}
