package ir.studying.app.core

import android.content.Context
import ir.studying.app.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.InterruptedIOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * دستیار هوشمند داخل اپ.
 *
 * کلید OpenAI فقط روی سرور است؛ اپ فقط با api.php حرف می‌زند (ai_status، ai_chat و ai_step).
 * تاریخچه روی همین گوشی و جدا برای هر حساب ذخیره می‌شود و هر بار چند پیام آخرش
 * همراه درخواست فرستاده می‌شود؛ سرور فقط تا وقتی جواب آماده شود (حداکثر ۲۰ دقیقه)
 * وضعیت کار را نگه می‌دارد.
 *
 * نسخهٔ ۲ (اپ ۲.۹):
 *  - هر درخواست یک شناسه (rid) دارد و در چند «قدم» کوتاه انجام می‌شود. هیچ قدمی آن‌قدر
 *    طول نمی‌کشد که درگاه سرور یا اینترنت موبایل قطعش کند، و قطعی وسط کار با فرستادن
 *    دوبارهٔ همان قدم جبران می‌شود؛ سرور تکراری‌ها را می‌شناسد و دوباره حساب نمی‌کند.
 *  - کارهای روی گوشی (تایمر، زنگ، یادآور، صدا، تم، باز کردن صفحه) واقعاً اجرا و بعد
 *    بررسی می‌شوند؛ نتیجه زیر پیام دیده می‌شود و به پیام بعدی سرور هم می‌رسد.
 *  - ری‌اکشن روی پیام کاربر و استیکرهای جغد.
 */
object Assistant {
    private const val KEEP = 60
    private const val HISTORY = 16
    private const val STATUS_TTL_MS = 10 * 60_000L
    private const val PROTO = 2
    /** سقف صبر برای یک جواب، همهٔ قدم‌ها روی هم (سرور خودش زیر ۱۵۰ ثانیه تمامش می‌کند). */
    private const val TOTAL_WAIT_MS = 4 * 60_000L
    /** چند بار یک قدم بعد از قطعی شبکه بی‌صدا دوباره فرستاده شود. */
    private const val NET_RETRIES = 3
    /** مکث بین جواب و باز شدن صفحه، تا کاربر جواب را ببیند. */
    private const val NAV_DELAY_MS = 1100L
    /** اگر تا این مدت رسید ناوبری نیامد، «باز نشد» نشان داده می‌شود. */
    private const val NAV_TIMEOUT_MS = 4000L
    const val DEFAULT_NAME = "دانا"

    enum class Role { USER, BOT, ERROR }

    data class Status(
        val enabled: Boolean = false,
        val name: String = DEFAULT_NAME,
        val greeting: String = "",
        val suggestions: List<String> = emptyList(),
        /** ۰ یعنی بی‌سقف. */
        val limit: Int = 0,
        /** ‎-1 یعنی بی‌سقف. */
        val remaining: Int = -1,
        /** نسخهٔ پروتکل سرور؛ ۱ یعنی سرور ۲.۸ (بدون کارهای روی گوشی). */
        val proto: Int = 1,
    ) {
        val exhausted: Boolean get() = limit > 0 && remaining == 0
    }

    data class Action(
        val type: String,
        val screen: String = "",
        val deckId: Int = 0,
        val label: String = "",
        val daily: Int = 0,
        val weekly: Int = 0,
        /** همهٔ فیلدهای اکشن همان‌طور که سرور فرستاده (تایمر، زنگ، صدا، تم…). */
        val raw: JSONObject = JSONObject(),
    )

    /** نتیجهٔ اجرای یک اکشن روی گوشی. ok = null یعنی هنوز در جریان است. */
    data class Outcome(val ok: Boolean?, val text: String = "", val fixScreen: String = "")

    data class Msg(
        val id: String,
        val role: Role,
        val text: String,
        val cards: List<JSONObject> = emptyList(),
        val actions: List<Action> = emptyList(),
        val suggestions: List<String> = emptyList(),
        /** پیام کاربر: کارتی که خودش با دکمه ارزیابی کرد (شناسهٔ کارت به کیفیت). */
        val fcGraded: Pair<Int, Int>? = null,
        /** پیام دستیار: نمرهٔ ثبت‌شدهٔ کارت‌های همین پیام. */
        val graded: Map<Int, Int> = emptyMap(),
        /** پیام خطا: «تلاش دوباره» معنی دارد یا نه. */
        val retry: Boolean = false,
        val time: Long = System.currentTimeMillis(),
        /** پیام کاربر: ری‌اکشنی که دستیار به آن داد. */
        val reaction: String? = null,
        /** پیام دستیار: استیکر جغد. */
        val sticker: String? = null,
        /** پیام دستیار: ابزارهای کاری که اجرا شد (برای ادامهٔ گفت‌وگو به سرور برمی‌گردد). */
        val trace: String? = null,
        /** پیام دستیار: نتیجهٔ هر اکشن روی گوشی، به ترتیب [actions]. */
        val outcomes: Map<Int, Outcome> = emptyMap(),
        /** پیام خطا: کد کوچک پیگیری (مثلاً AI-TIMEOUT). */
        val errorRef: String? = null,
        /** پیام خطا: net، slow، server، limit یا off — برای انتخاب استیکر. */
        val errorKind: String? = null,
    )

    val gradeLabels = listOf("دوباره", "سخت", "خوب", "آسان")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ioLock = Any()

    private val _messages = MutableStateFlow<List<Msg>>(emptyList())
    val messages: StateFlow<List<Msg>> = _messages.asStateFlow()

    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending.asStateFlow()

    private val _status = MutableStateFlow(Status())
    val status: StateFlow<Status> = _status.asStateFlow()

    private val _open = MutableStateFlow(false)
    val open: StateFlow<Boolean> = _open.asStateFlow()

    /** متن کوتاهِ «الان دارم چه کار می‌کنم» که سرور وسط کار می‌فرستد. */
    private val _stage = MutableStateFlow<String?>(null)
    val stage: StateFlow<String?> = _stage.asStateFlow()

    @Volatile private var appCtx: Context? = null
    @Volatile private var owner: String? = null
    @Volatile private var statusAt = 0L
    @Volatile private var job: Job? = null
    @Volatile private var gen = 0L
    private var seq = 0L

    /** ناوبری‌هایی که منتظر رسیدشان هستیم: شناسهٔ درخواست ← (پیام، شمارهٔ اکشن). */
    private val pendingNav = ConcurrentHashMap<Long, Pair<String, Int>>()

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        scope.launch {
            Store.session.collect { s -> switchOwner(if (s.token.isNullOrBlank()) null else s.username) }
        }
        scope.launch { NavBus.navResults.collect { onNavResult(it) } }
    }

    private fun switchOwner(user: String?) {
        if (user == owner) return
        job?.cancel()
        job = null
        gen++
        _sending.value = false
        _stage.value = null
        _open.value = false
        pendingNav.clear()
        owner = user
        statusAt = 0L
        _messages.value = if (user == null) emptyList() else readChat(user)
        _status.value = (if (user == null) null else readStatus(user)) ?: Status()
        if (user != null) refreshStatus(force = true)
    }

    /* ============================== باز و بسته ============================== */

    fun openChat() {
        if (owner == null) return
        _open.value = true
        refreshStatus(force = true)
    }

    fun close() { _open.value = false }

    /* ============================== وضعیت ============================== */

    fun refreshStatus(force: Boolean = false) {
        val me = owner ?: return
        val now = System.currentTimeMillis()
        if (!force && now - statusAt < STATUS_TTL_MS) return
        statusAt = now
        scope.launch {
            try {
                val o = Api.obj(Api.get("ai_status", "proto" to PROTO.toString()))
                if (owner != me) return@launch
                val st = Status(
                    enabled = o.boolish("enabled"),
                    name = o.str("name").ifBlank { DEFAULT_NAME },
                    greeting = o.str("greeting"),
                    suggestions = (o.optJSONArray("suggestions") ?: JSONArray()).strings().filter { it.isNotBlank() }.take(4),
                    limit = o.int("limit"),
                    remaining = o.intOrNull("remaining") ?: -1,
                    proto = o.intOrNull("proto") ?: 1,
                )
                _status.value = st
                writeStatus(me, st)
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                if (owner != me) return@launch
                /*
                 * سرور قدیمی (بدون دستیار) با 404 جواب می‌دهد و سرور بی‌کلید با
                 * ai_not_installed/ai_disabled؛ در این حالت دکمه پنهان می‌شود.
                 * خطای شبکه یا 5xx گذرا وضعیت قبلی را دست نمی‌زند و زودتر دوباره می‌پرسد.
                 */
                val hide = e.code in 400..499 && e.code != 429 || e.errorCode in setOf("ai_not_installed", "ai_disabled", "ai_not_configured")
                if (hide) {
                    val st = _status.value.copy(enabled = false)
                    _status.value = st
                    writeStatus(me, st)
                } else {
                    statusAt = System.currentTimeMillis() - STATUS_TTL_MS + 60_000L
                }
            } catch (e: Exception) {
                statusAt = System.currentTimeMillis() - STATUS_TTL_MS + 60_000L
            }
        }
    }

    /* ============================== گفت‌وگو ============================== */

    fun send(text: String, fcGraded: Pair<Int, Int>? = null) {
        val t = text.trim().take(1500)
        if (t.isEmpty() || _sending.value || owner == null) return
        _messages.update { list -> (list.filter { it.role != Role.ERROR } + Msg(newId(), Role.USER, t, fcGraded = fcGraded)).takeLast(KEEP) }
        save()
        request()
    }

    fun retry() {
        if (_sending.value) return
        _messages.update { list -> list.filter { it.role != Role.ERROR } }
        save()
        if (_messages.value.lastOrNull()?.role == Role.USER) request()
    }

    /** «گفت‌وگوی تازه» */
    fun clear() {
        job?.cancel()
        job = null
        gen++
        _sending.value = false
        _stage.value = null
        pendingNav.clear()
        _messages.value = emptyList()
        save()
    }

    private fun request() {
        val me = owner ?: return
        val g = ++gen
        _sending.value = true
        _stage.value = null
        val rid = newRid()
        val userId = _messages.value.lastOrNull { it.role == Role.USER }?.id
        val body = buildBody(rid)
        job = scope.launch {
            try {
                val o = exchange(me, g, body, rid, userId)
                if (owner == me && gen == g) handleReply(o, userId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (owner == me && gen == g) handleError(e)
            } finally {
                if (owner == me && gen == g) {
                    _sending.value = false
                    _stage.value = null
                }
            }
        }
    }

    /**
     * فرستادن و دنبال کردن یک درخواست تا جواب نهایی.
     *
     * سرور هر قدم را زیر حدود ۲۰ ثانیه برمی‌گرداند: یا جواب نهایی، یا «هنوز دارم کار
     * می‌کنم» (pending) با شمارهٔ قدم. قدم بعدی بلافاصله خواسته می‌شود. اگر همان قدم
     * هنوز در دست سرور باشد (busy)، کمی صبر می‌کنیم و دوباره می‌پرسیم.
     */
    private suspend fun exchange(me: String, g: Long, first: JSONObject, rid: String, userId: String?): JSONObject {
        val t0 = System.currentTimeMillis()
        var o = call("ai_chat", first, t0)
        var guard = 0
        while (o.optBoolean("pending", false)) {
            if (owner != me || gen != g) throw CancellationException("assistant request replaced")
            o.str("stage").takeIf { it.isNotBlank() }?.let { _stage.value = it }
            o.str("reaction").takeIf { it.isNotBlank() }?.let { react(userId, it) }
            if (++guard > 80 || System.currentTimeMillis() - t0 > TOTAL_WAIT_MS) throw SlowReply()
            delay(if (o.optBoolean("busy", false)) 1500L else 120L)
            val step = o.optInt("step", 0)
            o = call("ai_step", JSONObject().put("rid", rid).put("step", step + 1).put("proto", PROTO), t0)
        }
        return o
    }

    private class SlowReply : Exception("slow")

    /**
     * یک درخواست به سرور. قطعی شبکه یا خطای گذرای درگاه (502/503/504 بدون جواب JSON)
     * بی‌صدا چند بار تکرار می‌شود؛ چون rid و شمارهٔ قدم ثابت است، تکرار هیچ کاری را
     * دوبار انجام نمی‌دهد و سهمیه را هم دوبار کم نمی‌کند.
     */
    private suspend fun call(action: String, body: JSONObject, t0: Long): JSONObject {
        var attempt = 0
        while (true) {
            try {
                return Api.obj(Api.postSlow(action, body))
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                val gateway = e.body == null && e.code in setOf(502, 503, 504, 520, 521, 522, 523, 524)
                val transient = e.isNetwork || gateway
                if (!transient || attempt >= NET_RETRIES || System.currentTimeMillis() - t0 > TOTAL_WAIT_MS) throw e
                attempt++
                _stage.value = if (e.isNetwork) "اینترنت یه لحظه قطع و وصل شد 📶 دارم دوباره می‌فرستم…"
                else "سرور یه لحظه شلوغ شد 🚦 دارم دوباره امتحان می‌کنم…"
                delay(1300L * attempt)
            }
        }
    }

    private fun react(userId: String?, emoji: String) {
        if (userId == null) return
        val e = emoji.trim().take(8)
        if (e.isEmpty()) return
        _messages.update { list -> list.map { if (it.id == userId && it.reaction != e) it.copy(reaction = e) else it } }
    }

    private fun buildBody(rid: String): JSONObject {
        val arr = JSONArray()
        for (m in _messages.value.filter { it.role != Role.ERROR }.takeLast(HISTORY)) {
            val o = JSONObject()
                .put("role", if (m.role == Role.USER) "user" else "assistant")
                .put("text", historyText(m))
            if (m.role == Role.BOT) {
                val ids = JSONArray()
                m.cards.filter { it.str("type") == "flashcard" }.forEach {
                    ids.put(JSONObject().put("type", "flashcard").put("card_id", it.int("card_id")))
                }
                if (ids.length() > 0) o.put("cards", ids)
                m.sticker?.let { o.put("sticker", it) }
                m.trace?.let { t -> runCatching { JSONArray(t) }.getOrNull()?.takeIf { it.length() > 0 }?.let { o.put("trace", it) } }
            } else {
                m.reaction?.let { o.put("reaction", it) }
            }
            m.fcGraded?.let { (cid, q) -> o.put("fc_graded", JSONObject().put("card_id", cid).put("quality", q)) }
            arr.put(o)
        }
        val client = JSONObject()
            .put("goal_daily", Goals.daily.value.coerceAtLeast(0))
            .put("goal_weekly", Goals.weekly.value.coerceAtLeast(0))
            .put("app_version", BuildConfig.VERSION_NAME)
            .put("planner_enabled", PlannerAvailability.ENABLED)
            .put("proto", PROTO)
        AssistantDevice.snapshot(appCtx, client)
        return JSONObject().put("messages", arr).put("client", client).put("rid", rid).put("proto", PROTO)
    }

    /**
     * کارت گزارش در متن پیام نیست؛ خلاصه‌اش برای ادامهٔ گفت‌وگو کنار متن می‌رود.
     * کاری هم که روی گوشی انجام نشد همین‌جا یادداشت می‌شود تا دستیار بداند.
     */
    private fun historyText(m: Msg): String {
        if (m.role != Role.BOT) return m.text
        val notes = m.cards.filter { it.str("type") == "report" }.map {
            "(کارت «" + it.str("title") + "» نشان داده شد: " + it.str("subtitle") + "، مجموع " + Fmt.minutes(it.int("total_minutes")) + ")"
        }.toMutableList()
        m.outcomes.values.filter { it.ok == false && it.text.isNotBlank() }.forEach {
            notes += "(یادداشت اپ: روی گوشی انجام نشد — " + it.text + ")"
        }
        return if (notes.isEmpty()) m.text else (m.text + "\n" + notes.joinToString("\n")).trim()
    }

    private fun handleReply(o: JSONObject, userId: String?) {
        val cards = (o.optJSONArray("cards") ?: JSONArray()).objects()
        val actions = (o.optJSONArray("actions") ?: JSONArray()).objects().map { actionOf(it) }.filter { it.type.isNotBlank() }
        val effects = (o.optJSONArray("effects") ?: JSONArray()).objects()
        val reaction = o.str("reaction").trim().take(8).ifBlank { null }
        val trace = o.optJSONArray("trace")?.takeIf { it.length() > 0 }?.toString()
        val bot = Msg(
            id = newId(), role = Role.BOT,
            text = o.str("reply"),
            cards = cards, actions = actions,
            suggestions = (o.optJSONArray("suggestions") ?: JSONArray()).strings().filter { it.isNotBlank() }.take(3),
            sticker = o.str("sticker").trim().lowercase().ifBlank { null },
            trace = trace,
            outcomes = actions.indices.filter { isDeviceAction(actions[it].type) }.associateWith { Outcome(null) },
        )
        _messages.update { list ->
            val withReaction = if (reaction == null || userId == null) list else list.map { if (it.id == userId) it.copy(reaction = reaction) else it }
            (withReaction + bot).takeLast(KEEP)
        }
        val rem = o.intOrNull("remaining")
        val lim = o.intOrNull("limit")
        _status.update { it.copy(enabled = true, remaining = rem ?: it.remaining, limit = lim ?: it.limit) }
        owner?.let { writeStatus(it, _status.value) }
        applyEffects(effects)
        save()
        if (actions.isNotEmpty()) scope.launch { runActions(bot.id, actions) }
    }

    private fun isDeviceAction(type: String) = type in setOf("set_goal", "timer", "alarm", "reminder", "ambient", "theme")

    private fun handleError(e: Exception) {
        val api = e as? ApiException
        val code = api?.errorCode
        val final = code == "ai_daily_limit" || code == "ai_disabled" || code == "ai_not_configured" || code == "ai_not_installed"
        var ref: String? = api?.body?.str("error_ref")?.ifBlank { null }
        val kind: String
        val text: String
        when {
            e is SlowReply -> {
                kind = "slow"; ref = "APP-SLOW"
                text = "این یکی از حد معمول بیشتر طول کشید ⏳ یه بار دیگه بفرست؛ اگه درخواستت بلنده، می‌تونی تیکه‌تیکه‌ش کنی."
            }
            api != null && api.isNetwork -> {
                val c = api.cause
                if (c is java.net.UnknownHostException || c is java.net.ConnectException) {
                    kind = "net"; ref = "APP-NET"
                    text = "انگار اینترنتت قطعه 🌐 وصل که شدی «دوباره بفرست» رو بزن؛ من همین‌جام!"
                } else if (c is InterruptedIOException) {
                    kind = "slow"; ref = "APP-TIMEOUT"
                    text = "جوابم توی راه موند و به گوشیت نرسید ⏳ یه بار دیگه بفرست، این دفعه سریع‌ترم!"
                } else {
                    kind = "net"; ref = "APP-NET"
                    text = "ارتباطم با سرور یه لحظه قطع شد 📡 دوباره امتحان کن."
                }
            }
            api != null && api.body == null && api.code >= 500 -> {
                kind = "server"; ref = "APP-" + api.code
                text = "سرور یه لحظه نفسش گرفت 🛠 چند ثانیه دیگه دوباره بفرست."
            }
            api != null -> {
                kind = when (code) {
                    "ai_daily_limit" -> "limit"
                    "ai_disabled", "ai_not_configured", "ai_not_installed" -> "off"
                    "ai_timeout" -> "slow"
                    "ai_network", "ai_upstream", "ai_upstream_busy", "ai_rate_limited" -> "server"
                    else -> "server"
                }
                text = api.message?.takeIf { it.isNotBlank() } ?: humanizeError(e)
            }
            e is JSONException -> {
                kind = "server"; ref = "APP-JSON"
                text = "جوابم نصفه رسید 🙈 یه بار دیگه بفرست."
            }
            else -> {
                kind = "server"; ref = ref ?: "APP-ERR"
                text = "یه گره کوچیک توی کارم افتاد 🙈 یه بار دیگه بفرست، درستش می‌کنم."
            }
        }
        val retry = if (final) false else api?.body?.takeIf { it.has("retry") }?.optBoolean("retry", true) ?: true
        if (code == "ai_daily_limit") {
            _status.update { it.copy(remaining = 0, limit = if (it.limit > 0) it.limit else 1) }
            owner?.let { writeStatus(it, _status.value) }
        }
        if (final && code != "ai_daily_limit") statusAt = 0L
        _messages.update { (it + Msg(newId(), Role.ERROR, text, retry = retry, errorRef = ref, errorKind = kind)).takeLast(KEEP) }
        save()
    }

    private fun applyEffects(effects: List<JSONObject>) {
        var tasks = false
        var fc = false
        for (e in effects) when (e.str("type")) {
            "refresh" -> when (e.str("scope")) {
                "tasks" -> tasks = true
                "flashcards" -> fc = true
            }
            "fc_graded" -> markGraded(e.int("card_id"), e.int("quality"))
        }
        if (tasks) {
            RefreshBus.emit("tasks")
            appCtx?.let { ir.studying.app.widget.TasksWidget.refresh(it) }
        }
        if (fc) scope.launch { runCatching { Flashcards.loadDecks() } }
    }

    private fun markGraded(cardId: Int, quality: Int) {
        if (cardId <= 0) return
        _messages.update { list ->
            val idx = list.indexOfLast { m -> m.role == Role.BOT && m.cards.any { it.str("type") == "flashcard" && it.int("card_id") == cardId } }
            if (idx < 0) list
            else list.toMutableList().also { it[idx] = it[idx].copy(graded = it[idx].graded + (cardId to quality.coerceIn(0, 3))) }
        }
    }

    /**
     * کاربر خودش با دکمه نمره داد: مثل صفحهٔ مرور، نمره اول در صف محلی فلش‌کارت
     * ثبت می‌شود (آفلاین هم کار می‌کند) و بعد به دستیار خبر داده می‌شود تا کارت بعدی را بیاورد.
     */
    fun gradeCard(msg: Msg, cardId: Int, quality: Int) {
        if (_sending.value || owner == null) return
        val q = quality.coerceIn(0, 3)
        val seconds = ((System.currentTimeMillis() - msg.time) / 1000).toInt().coerceIn(1, 600)
        markGraded(cardId, q)
        save()
        _sending.value = true
        scope.launch {
            runCatching { Flashcards.review(cardId, q, seconds) }
            _sending.value = false
            send(gradeLabels[q], fcGraded = cardId to q)
        }
    }

    /* ============================== اکشن‌ها ============================== */

    private fun actionOf(o: JSONObject) = Action(
        type = o.str("type"),
        screen = o.str("screen"),
        deckId = o.int("deck_id"),
        label = o.str("label"),
        daily = o.int("daily_minutes"),
        weekly = o.int("weekly_minutes"),
        raw = runCatching { JSONObject(o.toString()) }.getOrDefault(JSONObject()),
    )

    private fun applyGoal(a: Action) {
        if (a.daily > 0) Goals.setDaily(a.daily)
        if (a.weekly > 0) Goals.setWeekly(a.weekly)
        RefreshBus.emit("home")
    }

    private fun setOutcome(msgId: String, idx: Int, out: Outcome) {
        _messages.update { list ->
            list.map { if (it.id == msgId) it.copy(outcomes = it.outcomes + (idx to out)) else it }
        }
    }

    /**
     * اجرای خودکار اکشن‌های یک جواب تازه: کارهای روی گوشی همین الان، و در آخر
     * (اگر لازم بود و چت هنوز باز است) باز کردن صفحه.
     */
    private suspend fun runActions(msgId: String, actions: List<Action>) {
        val ctx = appCtx ?: return
        var go: Pair<Int, String>? = null
        actions.forEachIndexed { i, a ->
            val out: AssistantDevice.Outcome? = try {
                withContext(Dispatchers.Main) {
                    when (a.type) {
                        "set_goal" -> {
                            applyGoal(a)
                            val ok = (a.daily <= 0 || Goals.daily.value > 0) && (a.weekly <= 0 || Goals.weekly.value > 0)
                            AssistantDevice.Outcome(ok, if (ok) "هدف ثبت شد" else "هدف ثبت نشد")
                        }
                        "timer" -> AssistantDevice.timer(ctx, a.raw)
                        "alarm" -> AssistantDevice.alarm(ctx, a.raw)
                        "reminder" -> AssistantDevice.reminder(ctx, a.raw)
                        "ambient" -> AssistantDevice.ambient(ctx, a.raw)
                        "theme" -> AssistantDevice.theme(a.raw)
                        else -> null
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AssistantDevice.Outcome(false, "روی گوشی انجام نشد")
            }
            if (out != null) {
                setOutcome(msgId, i, Outcome(out.ok, out.text, out.fixScreen))
                when {
                    // نتیجهٔ تایمر («پومودورو روشن شد») نباید با «باز شد» عوض شود؛ برای همین بدون شماره.
                    // شروع و توقف هر دو صفحهٔ مطالعه را باز می‌کنند (توقف: برای ثبت جلسه)؛ سرور هم همین را به دستیار گفته.
                    a.type == "timer" && out.ok -> go = -1 to "study_timer"
                    !out.ok && out.fixScreen.isNotBlank() && go == null -> go = -1 to out.fixScreen
                }
            }
            if (a.type == "navigate") go = i to a.screen
        }
        save()
        val target = go ?: return
        delay(NAV_DELAY_MS)
        // اگر کاربر در این فاصله چت را بسته، بی‌خبر جابه‌جایش نمی‌کنیم.
        if (!_open.value) return
        val (idx, screen) = target
        val a = actions.getOrNull(idx)
        openScreen(msgId, idx, screen, if (a?.type == "navigate") a.deckId else 0)
    }

    /** دکمهٔ زیر پیام: باز کردن دوبارهٔ صفحه، یا صفحه‌ای که اکشن به آن مربوط است. */
    fun runAction(msg: Msg, idx: Int) {
        val a = msg.actions.getOrNull(idx) ?: return
        val fix = msg.outcomes[idx]?.takeIf { it.ok == false }?.fixScreen.orEmpty()
        when (a.type) {
            "navigate", "link" -> openScreen(msg.id, idx, a.screen, a.deckId)
            "timer" -> openScreen(msg.id, -1, "study_timer", 0)
            "alarm" -> openScreen(msg.id, -1, "alarms", 0)
            "reminder" -> openScreen(msg.id, -1, fix.ifBlank { "notification_settings" }, 0)
            "ambient" -> openScreen(msg.id, -1, "study_timer", 0)
            "theme" -> openScreen(msg.id, -1, "settings", 0)
            "set_goal" -> openScreen(msg.id, -1, "home", 0)
        }
    }

    /** برای سازگاری با نسخهٔ قبل (و تست‌ها): اکشن بدون پیام. */
    fun runAction(a: Action) {
        when (a.type) {
            "navigate", "link" -> openScreen(null, -1, a.screen, a.deckId)
            "set_goal" -> applyGoal(a)
        }
    }

    private fun routeOf(screen: String, deckId: Int): String? = when (screen) {
        "notification_settings", "settings_notif" -> "settings_notif"
        "telegram" -> "settings_telegram"
        "flashcard_deck" -> if (deckId > 0) "fc_deck/$deckId" else "flashcards"
        "flashcard_review" -> "fc_review/" + deckId.coerceAtLeast(0)
        "flashcard_stats" -> "fc_stats"
        "home", "messages", "tasks", "community", "library", "profile", "profile_edit", "settings", "room",
        "focus_settings", "focus_apps", "focus_guide", "focus_phone", "alarms", "flashcards", "planner",
        -> screen
        else -> null
    }

    /**
     * باز کردن یک صفحه. صفحه‌های معمولی از راه [NavBus.requestAssistNav] باز می‌شوند
     * و MainScaffold رسید می‌دهد؛ تا رسید نیاید چت بسته نمی‌شود، و اگر باز نشد
     * چت باز می‌ماند و زیر پیام «باز نشد» با دکمهٔ دوباره دیده می‌شود.
     */
    private fun openScreen(msgId: String?, idx: Int, screen: String, deckId: Int) {
        when (screen) {
            "study_timer" -> {
                close()
                NavBus.requestStudy()
                if (msgId != null && idx >= 0) markNav(msgId, idx, true)
                return
            }
            "groups" -> {
                close()
                NavBus.requestGroupsHome()
                if (msgId != null && idx >= 0) markNav(msgId, idx, true)
                return
            }
            "room_leaderboard" -> {
                close()
                NavBus.requestRoom("top")
                if (msgId != null && idx >= 0) markNav(msgId, idx, true)
                return
            }
        }
        val route = routeOf(screen, deckId)
        if (route == null) {
            if (msgId != null && idx >= 0) setOutcome(msgId, idx, Outcome(false, "این صفحه توی این نسخهٔ اپ نیست"))
            return
        }
        val id = NavBus.requestAssistNav(route)
        pendingNav[id] = (msgId ?: "") to (if (msgId != null) idx else -1)
        // اگر صفحهٔ اصلی اصلاً جواب نداد (مثلاً اپ پشت صحنه بود)، بی‌جواب نمی‌ماند.
        scope.launch {
            delay(NAV_TIMEOUT_MS)
            val left = pendingNav.remove(id) ?: return@launch
            NavBus.consumeAssistNav(id)
            if (left.first.isNotEmpty() && left.second >= 0) markNav(left.first, left.second, false)
        }
    }

    private fun markNav(msgId: String, idx: Int, ok: Boolean) {
        setOutcome(msgId, idx, if (ok) Outcome(true, "باز شد") else Outcome(false, "باز نشد؛ دکمه‌ش رو بزن"))
        save()
    }

    private fun onNavResult(r: NavBus.NavResult) {
        val (msgId, idx) = pendingNav.remove(r.id) ?: return
        if (r.ok) close()
        if (msgId.isNotEmpty() && idx >= 0) markNav(msgId, idx, r.ok)
    }

    /* ============================== ذخیره روی گوشی ============================== */

    private fun newId(): String = synchronized(this) { "m" + System.currentTimeMillis().toString(36) + "_" + (seq++).toString(36) }

    /** شناسهٔ یکتای هر درخواست (۸ تا ۴۰ نویسهٔ لاتین، همان چیزی که سرور می‌پذیرد). */
    private fun newRid(): String {
        val r = java.util.UUID.randomUUID().toString().replace("-", "").take(20)
        return "r" + System.currentTimeMillis().toString(36) + r
    }

    private fun key(user: String): String = runCatching {
        MessageDigest.getInstance("SHA-1").digest(user.lowercase().toByteArray()).joinToString("") { "%02x".format(it) }.take(20)
    }.getOrDefault(user.hashCode().toString())

    private fun chatFile(user: String): File? = appCtx?.let { File(it.filesDir, "assistant_chat_" + key(user) + ".json") }
    private fun statusFile(user: String): File? = appCtx?.let { File(it.filesDir, "assistant_status_" + key(user) + ".json") }

    private fun save() {
        val me = owner ?: return
        scope.launch {
            synchronized(ioLock) {
                if (owner != me) return@synchronized
                val f = chatFile(me) ?: return@synchronized
                runCatching {
                    val arr = JSONArray()
                    _messages.value.forEach { arr.put(encode(it)) }
                    val tmp = File(f.parentFile, f.name + ".tmp")
                    tmp.writeText(JSONObject().put("v", 2).put("messages", arr).toString())
                    if (!tmp.renameTo(f)) { f.writeText(tmp.readText()); tmp.delete() }
                }
            }
        }
    }

    private fun readChat(user: String): List<Msg> = synchronized(ioLock) {
        val f = chatFile(user) ?: return emptyList()
        if (!f.exists()) return emptyList()
        runCatching {
            (JSONObject(f.readText()).optJSONArray("messages") ?: JSONArray()).objects().mapNotNull { decode(it) }.takeLast(KEEP)
        }.getOrDefault(emptyList())
    }

    private fun encode(m: Msg): JSONObject {
        val o = JSONObject()
            .put("id", m.id)
            .put("role", m.role.name.lowercase())
            .put("text", m.text)
            .put("time", m.time)
        if (m.cards.isNotEmpty()) o.put("cards", JSONArray().also { a -> m.cards.forEach { a.put(it) } })
        if (m.actions.isNotEmpty()) o.put("actions", JSONArray().also { a ->
            m.actions.forEach {
                val x = runCatching { JSONObject(it.raw.toString()) }.getOrDefault(JSONObject())
                x.put("type", it.type).put("screen", it.screen).put("deck_id", it.deckId).put("label", it.label)
                    .put("daily_minutes", it.daily).put("weekly_minutes", it.weekly)
                a.put(x)
            }
        })
        if (m.suggestions.isNotEmpty()) o.put("suggestions", JSONArray(m.suggestions))
        m.fcGraded?.let { o.put("fc_graded", JSONObject().put("card_id", it.first).put("quality", it.second)) }
        if (m.graded.isNotEmpty()) o.put("graded", JSONObject().also { g -> m.graded.forEach { (k, v) -> g.put(k.toString(), v) } })
        if (m.retry) o.put("retry", true)
        m.reaction?.let { o.put("reaction", it) }
        m.sticker?.let { o.put("sticker", it) }
        m.trace?.let { o.put("trace", it) }
        m.errorRef?.let { o.put("error_ref", it) }
        m.errorKind?.let { o.put("error_kind", it) }
        if (m.outcomes.isNotEmpty()) o.put("outcomes", JSONObject().also { g ->
            m.outcomes.forEach { (k, v) ->
                // کاری که وسط ذخیره هنوز تمام نشده بود، بعد از باز شدن دوبارهٔ اپ «نامعلوم» است، نه «در جریان».
                if (v.ok != null) g.put(k.toString(), JSONObject().put("ok", v.ok).put("text", v.text).put("fix", v.fixScreen))
            }
        })
        return o
    }

    private fun decode(o: JSONObject): Msg? {
        val role = when (o.str("role")) { "user" -> Role.USER; "bot" -> Role.BOT; "error" -> Role.ERROR; else -> return null }
        val graded = mutableMapOf<Int, Int>()
        o.optJSONObject("graded")?.let { g -> g.keys().forEach { k -> k.toIntOrNull()?.let { graded[it] = g.int(k) } } }
        val outcomes = mutableMapOf<Int, Outcome>()
        o.optJSONObject("outcomes")?.let { g ->
            g.keys().forEach { k ->
                val v = g.optJSONObject(k) ?: return@forEach
                k.toIntOrNull()?.let { outcomes[it] = Outcome(v.optBoolean("ok", false), v.str("text"), v.str("fix")) }
            }
        }
        return Msg(
            id = o.str("id").ifBlank { newId() },
            role = role,
            text = o.str("text"),
            cards = (o.optJSONArray("cards") ?: JSONArray()).objects(),
            actions = (o.optJSONArray("actions") ?: JSONArray()).objects().map { actionOf(it) },
            suggestions = (o.optJSONArray("suggestions") ?: JSONArray()).strings(),
            fcGraded = o.optJSONObject("fc_graded")?.let { it.int("card_id") to it.int("quality") },
            graded = graded,
            retry = o.optBoolean("retry", false),
            time = o.optLong("time", System.currentTimeMillis()),
            reaction = o.str("reaction").ifBlank { null },
            sticker = o.str("sticker").ifBlank { null },
            trace = o.str("trace").ifBlank { null },
            outcomes = outcomes,
            errorRef = o.str("error_ref").ifBlank { null },
            errorKind = o.str("error_kind").ifBlank { null },
        )
    }

    private fun writeStatus(user: String, st: Status) {
        val f = statusFile(user) ?: return
        runCatching {
            f.writeText(
                JSONObject()
                    .put("enabled", st.enabled).put("name", st.name).put("greeting", st.greeting)
                    .put("suggestions", JSONArray(st.suggestions)).put("limit", st.limit).put("remaining", st.remaining)
                    .put("proto", st.proto)
                    .put("day", IranTime.todayIso())
                    .toString()
            )
        }
    }

    private fun readStatus(user: String): Status? {
        val f = statusFile(user) ?: return null
        if (!f.exists()) return null
        return runCatching {
            val o = JSONObject(f.readText())
            val sameDay = o.str("day") == IranTime.todayIso()
            Status(
                enabled = o.optBoolean("enabled", false),
                name = o.str("name").ifBlank { DEFAULT_NAME },
                greeting = o.str("greeting"),
                suggestions = (o.optJSONArray("suggestions") ?: JSONArray()).strings(),
                limit = o.int("limit"),
                // سهمیه هر روز نو می‌شود؛ عدد دیروز را نشان نمی‌دهیم.
                remaining = if (sameDay) (o.intOrNull("remaining") ?: -1) else -1,
                proto = o.intOrNull("proto") ?: 1,
            )
        }.getOrNull()
    }
}
