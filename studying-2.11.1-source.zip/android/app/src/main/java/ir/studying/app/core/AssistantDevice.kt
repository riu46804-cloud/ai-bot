package ir.studying.app.core

import android.app.AlarmManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import ir.studying.app.alarm.Alarm
import ir.studying.app.alarm.AlarmScheduler
import ir.studying.app.alarm.AlarmStore
import ir.studying.app.notify.Reminder
import ir.studying.app.player.AmbientMixer
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro
import ir.studying.app.ui.theme.AppPalettes
import org.json.JSONArray
import org.json.JSONObject

/**
 * کارهایی که دستیار هوشمند روی خودِ گوشی انجام می‌دهد (تایمر، زنگ، یادآور، صدا، تم).
 *
 * هر تابع واقعاً کار را انجام می‌دهد و بعد خودش بررسی می‌کند که انجام شد یا نه؛
 * نتیجه ([Outcome]) زیر پیام دستیار نشان داده می‌شود و در پیام بعدی به سرور هم
 * می‌رسد، تا دستیار دیگر چیزی را که اجرا نشده «انجام شد» نگوید.
 *
 * همه روی رشتهٔ اصلی صدا زده می‌شوند (تایمرها و پخش‌کننده‌ها آنجا زندگی می‌کنند).
 */
internal object AssistantDevice {

    data class Outcome(
        val ok: Boolean,
        val text: String,
        /** اگر کاربر باید کاری کند (اجازه بدهد و…)، این صفحه باز می‌شود. */
        val fixScreen: String = "",
    )

    private fun hm(h: Int, m: Int) = (h.toString().padStart(2, '0') + ":" + m.toString().padStart(2, '0')).fa()

    /* ============================== تایمر ============================== */

    fun timer(ctx: Context, a: JSONObject): Outcome {
        if (a.str("op") == "stop") {
            val p = Pomodoro.state.value.running
            val c = Chrono.running
            if (p) Pomodoro.pause()
            if (c) Chrono.pause()
            val stopped = !Pomodoro.state.value.running && !Chrono.running
            return when {
                !p && !c -> Outcome(true, "تایمری روشن نبود")
                stopped -> Outcome(true, "تایمر متوقف شد؛ هر وقت خواستی ثبتش کن")
                else -> Outcome(false, "تایمر متوقف نشد")
            }
        }

        val force = a.optBoolean("force", false)
        val before = Pomodoro.state.value
        if ((before.running || Chrono.running) && !force) {
            return Outcome(true, "تایمر قبلی‌ات هنوز روشنه؛ همون ادامه داره")
        }
        val course = a.int("course_id")
        if (course > 0) Chrono.setCourse(course)
        val courseName = a.str("course_name")

        // پومودوروی نیمه‌کاره بی‌صدا دور ریخته نمی‌شود: دقیقه‌های خوانده‌شده‌اش برای ثبت می‌ماند.
        var saved = 0
        fun clearPomodoro() {
            val s = Pomodoro.state.value
            if (s.phase == Pomodoro.Phase.IDLE) return
            if (s.phase == Pomodoro.Phase.WORK) saved = Pomodoro.skip(ctx)
            Pomodoro.reset()
        }

        if (a.str("mode") == "stopwatch") {
            clearPomodoro()
            if (Chrono.running) Chrono.pause()
            Store.setLastStudyMode(0)
            Chrono.start()
            val ok = Chrono.running
            return Outcome(ok, if (ok) withSaved("کرنومتر روشن شد" + course(courseName), saved) else "کرنومتر روشن نشد")
        }

        val work = a.int("work_minutes").let { if (it <= 0) 25 else it }.coerceIn(1, 240)
        val brk = a.int("break_minutes").let { if (it <= 0) (if (work <= 30) 5 else if (work <= 60) 10 else 20) else it }.coerceIn(1, 240)
        if (Chrono.running) Chrono.pause()
        clearPomodoro()
        val cur = Pomodoro.state.value.config
        val long = (if (brk >= 20) 30 else 15).coerceAtLeast(brk).coerceAtMost(240)
        runCatching { Pomodoro.setConfig(cur.copy(workMin = work, breakMin = brk, longBreakMin = long)) }
        Store.setLastStudyMode(1)
        Pomodoro.start(ctx)
        val s = Pomodoro.state.value
        val ok = s.running && s.phase == Pomodoro.Phase.WORK && s.config.workMin == work
        return if (ok) Outcome(true, withSaved("پومودوروی " + work.fa() + " دقیقه‌ای روشن شد" + course(courseName), saved))
        else Outcome(false, "پومودورو روشن نشد")
    }

    private fun course(name: String) = if (name.isBlank()) "" else " · $name"
    private fun withSaved(t: String, saved: Int) = if (saved > 0) "$t (" + saved.fa() + " دقیقهٔ قبلی برای ثبت ماند)" else t

    /* ============================== زنگ بیدارباش ============================== */

    fun alarm(ctx: Context, a: JSONObject): Outcome {
        val h = a.int("hour")
        val m = a.int("minute")
        if (h !in 0..23 || m !in 0..59) return Outcome(false, "ساعت زنگ نامعتبر بود")
        val days = (a.optJSONArray("days") ?: JSONArray()).let { arr -> (0 until arr.length()).map { arr.optInt(it) }.filter { it in 1..7 }.toSet() }
        val mission = a.str("mission").takeIf { it in setOf(Alarm.MISSION_MATH, Alarm.MISSION_TYPING, Alarm.MISSION_SHAKE, Alarm.MISSION_NONE) } ?: Alarm.MISSION_MATH
        val label = a.str("label").take(40).ifBlank { "بیدارباش" }
        AlarmStore.init(ctx)
        val same = AlarmStore.alarms.value.firstOrNull { it.hour == h && it.minute == m && it.days == days }
        val saved = runCatching {
            if (same != null) AlarmStore.save(ctx, same.copy(enabled = true, label = label, mission = mission))
            else AlarmStore.save(ctx, Alarm(id = 0, hour = h, minute = m, days = days, enabled = true, label = label, mission = mission))
        }.getOrNull()
        val stored = saved != null && AlarmStore.alarms.value.any { it.id == saved.id && it.enabled }
        if (!stored) return Outcome(false, "زنگ ساخته نشد", "alarms")
        val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            (ctx.getSystemService(AlarmManager::class.java)?.canScheduleExactAlarms() ?: true)
        val notif = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        val text = "زنگ " + hm(h, m) + " · " + daysLabel(days)
        return when {
            !exact -> Outcome(false, "$text ساخته شد، ولی اجازهٔ «آلارم دقیق» خاموشه", "alarms")
            !notif -> Outcome(false, "$text ساخته شد، ولی اعلان‌های اپ خاموشه", "alarms")
            else -> Outcome(true, "$text ساخته شد")
        }
    }

    private fun daysLabel(days: Set<Int>): String {
        if (days.isEmpty()) return "یک بار"
        if (days.size == 7) return "هر روز"
        val names = mapOf(7 to "شنبه", 1 to "یکشنبه", 2 to "دوشنبه", 3 to "سه‌شنبه", 4 to "چهارشنبه", 5 to "پنجشنبه", 6 to "جمعه")
        return listOf(7, 1, 2, 3, 4, 5, 6).filter { it in days }.joinToString("، ") { names.getValue(it) }
    }

    /* ============================== یادآور روزانه ============================== */

    fun reminder(ctx: Context, a: JSONObject): Outcome {
        val p = Store.prefs.value
        val on = a.optBoolean("enabled", true)
        val h = if (a.has("hour")) a.int("hour").coerceIn(0, 23) else p.reminderHour
        val m = if (a.has("minute")) a.int("minute").coerceIn(0, 59) else p.reminderMinute
        if (!on) {
            Store.setReminder(false, h, m)
            Reminder.apply(ctx)
            return Outcome(!Store.prefs.value.reminderEnabled, "یادآور روزانه خاموش شد")
        }
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
            // ساعت همین الان ذخیره می‌شود؛ روشن کردنش با کلید صفحهٔ اعلان‌ها است که اجازه را هم می‌گیرد.
            Store.setReminder(false, h, m)
            return Outcome(false, "یادآور " + hm(h, m) + " آماده‌ست؛ فقط اعلان‌ها رو روشن کن", "settings_notif")
        }
        Store.setReminder(true, h, m)
        Reminder.apply(ctx)
        val ok = Store.prefs.value.reminderEnabled && Store.prefs.value.reminderHour == h
        return Outcome(ok, if (ok) "یادآور هر روز ساعت " + hm(h, m) else "یادآور تنظیم نشد", if (ok) "" else "settings_notif")
    }

    /* ============================== صدای محیطی ============================== */

    fun ambient(ctx: Context, a: JSONObject): Outcome {
        val known = AmbientMixer.sounds.associateBy { it.key }
        val keys = (a.optJSONArray("sounds") ?: JSONArray()).strings().map { it.lowercase() }.filter { it in known }.distinct()
        if (a.str("op") == "stop") {
            if (keys.isEmpty()) AmbientMixer.stopAll()
            else keys.forEach { if (AmbientMixer.stateOf(it).active) AmbientMixer.toggle(ctx, it) }
            val left = if (keys.isEmpty()) AmbientMixer.sounds.count { AmbientMixer.stateOf(it.key).active } else keys.count { AmbientMixer.stateOf(it).active }
            return Outcome(left == 0, if (keys.isEmpty()) "صداهای محیطی قطع شد" else keys.joinToString(" و ") { known.getValue(it).label } + " قطع شد")
        }
        val list = keys.ifEmpty { listOf("rain") }.take(4)
        list.forEach { if (!AmbientMixer.stateOf(it).active) AmbientMixer.toggle(ctx, it) }
        val ok = list.all { AmbientMixer.stateOf(it).active }
        val names = list.joinToString(" + ") { known.getValue(it).emoji + " " + known.getValue(it).label }
        return Outcome(ok, if (ok) "$names در حال پخش" else "صدا پخش نشد")
    }

    /* ============================== تم ============================== */

    fun theme(a: JSONObject): Outcome {
        val mode = a.str("mode")
        val color = a.str("color")
        val parts = mutableListOf<String>()
        if (mode in setOf("dark", "light", "system")) {
            Store.setThemeMode(mode)
            parts += when (mode) { "dark" -> "تم تیره"; "light" -> "تم روشن"; else -> "تم هماهنگ با گوشی" }
        }
        if (color.isNotBlank()) {
            val pal = AppPalettes.firstOrNull { it.id == color }
                ?: return Outcome(false, if (color == "dynamic") "رنگ هماهنگ با والپیپر فقط روی اندروید ۱۲ به بعده" else "این رنگ توی اپ نیست")
            Store.setThemeColor(pal.id)
            parts += "رنگ " + pal.fa + " " + pal.emoji
        }
        if (parts.isEmpty()) return Outcome(false, "تمی برای عوض کردن نبود")
        val p = Store.prefs.value
        val ok = (mode.isBlank() || p.themeMode == mode) && (color.isBlank() || p.themeColor == color)
        return Outcome(ok, parts.joinToString(" · ") + if (ok) " فعال شد" else " عوض نشد")
    }

    /* ============================== وضعیت گوشی برای سرور ============================== */

    /** خلاصهٔ کوچک وضعیت گوشی؛ سرور فقط همین کلیدها را می‌خواند و چیزی ذخیره نمی‌کند. */
    fun snapshot(ctx: Context?, into: JSONObject) {
        runCatching {
            val p = Pomodoro.state.value
            val pomo = p.running || p.phase != Pomodoro.Phase.IDLE
            val chronoMs = Chrono.elapsedMs()
            val t = JSONObject()
            val mode = when {
                pomo -> "pomodoro"
                Chrono.running || chronoMs > 0 -> "stopwatch"
                Store.prefs.value.lastStudyMode == 1 -> "pomodoro"
                else -> "stopwatch"
            }
            t.put("mode", mode)
            t.put("running", p.running || Chrono.running)
            if (mode == "pomodoro" && pomo) {
                t.put("phase", when (p.phase) { Pomodoro.Phase.BREAK -> "break"; Pomodoro.Phase.LONG_BREAK -> "long_break"; else -> "work" })
                t.put("remaining_sec", p.remainingSec.coerceAtLeast(0))
            }
            if (mode == "stopwatch") t.put("elapsed_sec", (chronoMs / 1000).toInt())
            Store.timer.value.courseId?.let { id -> CourseCache.peek().firstOrNull { it.id == id }?.name?.let { t.put("course", it.take(40)) } }
            val pend = StudyPending.minutes.value
            if (pend > 0) t.put("pending_minutes", pend)
            into.put("timer", t)
        }
        runCatching {
            val p = Store.prefs.value
            into.put("theme", JSONObject().put("mode", p.themeMode).put("color", p.themeColor))
        }
        runCatching {
            into.put("sounds", JSONArray(AmbientMixer.sounds.map { it.key }.filter { AmbientMixer.stateOf(it).active }))
        }
        runCatching {
            if (ctx != null) AlarmStore.init(ctx)
            val on = AlarmStore.alarms.value.filter { it.enabled }
            val al = JSONObject().put("count", on.size)
            on.minByOrNull { AlarmScheduler.nextTrigger(it) }?.let { al.put("next", it.hour.toString().padStart(2, '0') + ":" + it.minute.toString().padStart(2, '0')) }
            into.put("alarms", al)
        }
    }
}
