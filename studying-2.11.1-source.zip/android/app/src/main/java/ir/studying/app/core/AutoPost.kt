package ir.studying.app.core

import android.content.Context
import android.content.SharedPreferences
import ir.studying.app.data.CourseMinutes
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Automatic achievement posts.
 *
 * The server used to publish the "studied today" post itself, the instant a
 * session was saved (the `share_post` flag on the `study` action). That fired
 * in the middle of the day, so it announced a partial number and it could fire
 * several times. The client now owns all three achievement posts instead:
 *
 *  - [DAILY]  one end-of-day summary, posted by the 23:50 alarm.
 *  - [GOAL]   fired the moment the personal daily goal is reached.
 *  - [STREAK] fired on round / meaningful streak milestones only.
 *
 * Each post carries a compact machine-readable tag as its first characters so
 * the feed can render it as an achievement card rather than an ordinary post.
 * [strip] removes the tag before any human ever sees the text, and a client
 * that does not understand the tag still shows a perfectly readable sentence.
 */
object AutoPost {

    private const val FILE = "studying_autopost"
    private const val K_DAILY = "last_daily_date"
    private const val K_GOAL = "last_goal_date"
    private const val K_STREAK = "last_streak_value"

    /** Sentinel brackets. Rare enough never to appear in real Persian text. */
    private const val OPEN = "\u27EA"
    private const val CLOSE = "\u27EB"

    const val DAILY = "daily"
    const val GOAL = "goal"
    const val STREAK = "streak"

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    /** Tehran, always. The server stamps study_date on a Tehran clock. */
    private fun todayIso(): String = IranTime.todayIso()

    // ---------------------------------------------------------------- tagging

    data class Badge(
        val kind: String,
        val minutes: Int,
        val goal: Int,
        val streak: Int,
        val body: String,
        /** Per-course split, present on daily summaries. */
        val courses: List<Pair<String, Int>> = emptyList(),
        val questionTotals: QuestionTotals? = null,
    )

    /** Course names are cleaned of the separators the tag itself relies on. */
    private fun encodeCourses(courses: List<CourseMinutes>): String =
        courses.asSequence()
            .filter { it.minutes > 0 }
            .sortedByDescending { it.minutes }
            .take(6)
            .joinToString(",") { c ->
                c.name.replace("|", " ").replace(",", " ").replace("~", " ").trim() + "~" + c.minutes
            }

    private fun tag(
        kind: String,
        minutes: Int,
        goal: Int,
        streak: Int,
        courses: List<CourseMinutes> = emptyList(),
        questionTotals: QuestionTotals? = null,
    ): String {
        val head = OPEN + "dh|" + kind + "|" + minutes + "|" + goal + "|" + streak
        val split = encodeCourses(courses)
        return when {
            questionTotals != null -> head + "|" + split + "|" + questionTotals.encodeTag() + CLOSE
            split.isEmpty() -> head + CLOSE
            else -> head + "|" + split + CLOSE
        }
    }

    private fun decodeCourses(raw: String): List<Pair<String, Int>> =
        raw.split(",").mapNotNull { part ->
            val i = part.lastIndexOf("~")
            if (i <= 0) return@mapNotNull null
            val m = part.substring(i + 1).toIntOrNull() ?: return@mapNotNull null
            part.substring(0, i).trim() to m
        }

    /** Reads the achievement tag off a post, or null for an ordinary post. */
    fun parse(text: String?): Badge? {
        val t = (text ?: return null).trimStart()
        if (!t.startsWith(OPEN + "dh|")) return null
        val end = t.indexOf(CLOSE)
        if (end <= 0) return null
        val parts = t.substring(1, end).split("|")
        if (parts.size < 5) return null
        val split = if (parts.size >= 6) decodeCourses(parts[5]) else emptyList()
        return Badge(
            kind = parts[1],
            minutes = parts[2].toIntOrNull() ?: 0,
            goal = parts[3].toIntOrNull() ?: 0,
            streak = parts[4].toIntOrNull() ?: 0,
            body = t.substring(end + 1).trim(),
            courses = split,
            questionTotals = if (parts.size >= 7) QuestionTotals.decodeTag(parts[6]) else null,
        )
    }

    /** The human sentence, with any tag removed. Safe on untagged posts. */
    fun strip(text: String?): String = parse(text)?.body ?: (text ?: "")

    // ---------------------------------------------------------------- posting

    private suspend fun publish(tagged: String) {
        runCatching { Api.post("post_create", JSONObject().put("text", tagged)) }
    }

    private fun hoursLabel(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> h.fa() + " ساعت و " + m.fa() + " دقیقه"
            h > 0 -> h.fa() + " ساعت"
            else -> m.fa() + " دقیقه"
        }
    }

    /**
     * End-of-day summary for one specific date.
     *
     * The date is passed in rather than read from the clock, because this can
     * run after midnight (a slipped alarm, or a catch-up on next launch) and
     * must still be stamped with the day it actually describes.
     */
    suspend fun postDailySummary(dateIso: String, totalMinutes: Int, courses: List<CourseMinutes>, questionTotals: QuestionTotals? = null) {
        if (totalMinutes <= 0) return
        if (!Store.prefs.value.autoStudyPost) return
        val p = prefs ?: return
        if (p.getString(K_DAILY, null) == dateIso) return
        publish(dailySummaryText(totalMinutes, courses, questionTotals))
        p.edit().putString(K_DAILY, dateIso).apply()
    }

    /** Pure encoder for new summaries; older clients still read the first six fields. */
    internal fun dailySummaryText(totalMinutes: Int, courses: List<CourseMinutes>, questionTotals: QuestionTotals?): String {
        val top = courses.maxByOrNull { it.minutes }?.name
        val course = if (top.isNullOrBlank()) "" else " بیشترین تمرکز روی «" + top + "»."
        val questions = questionTotals?.let { " ${it.tests.fa()} تست و ${it.descriptive.fa()} سؤال تشریحی ثبت کردم." } ?: ""
        val body = "امروز " + hoursLabel(totalMinutes) + " مطالعه کردم." + questions + course
        return tag(DAILY, totalMinutes, 0, 0, courses, questionTotals) + body
    }

    /** Fired once per day, the moment the personal goal is reached. */
    suspend fun postGoalReached(totalMinutes: Int, goalMinutes: Int) {
        if (!Store.prefs.value.autoStudyPost) return
        /* هدفِ تنظیم‌نشده (۰) یعنی هیچ هدفی محقق نشده؛ پست ساختگی نمی‌گذاریم. */
        if (goalMinutes <= 0 || totalMinutes < goalMinutes) return
        val p = prefs ?: return
        val today = todayIso()
        if (p.getString(K_GOAL, null) == today) return
        val body = "به هدف امروزم رسیدم — " + hoursLabel(goalMinutes) + " مطالعه\u200C. " +
            "مجموع امروز: " + hoursLabel(totalMinutes) + "."
        publish(tag(GOAL, totalMinutes, goalMinutes, 0) + body)
        p.edit().putString(K_GOAL, today).apply()
    }

    /**
     * Milestone streaks only. Every day up to a week, then the round numbers
     * people actually celebrate, then every hundred.
     */
    fun isMilestone(streak: Int): Boolean = when {
        streak < 7 -> false
        streak == 7 || streak == 14 || streak == 21 || streak == 30 -> true
        streak == 50 || streak == 75 || streak == 100 -> true
        streak == 150 || streak == 200 || streak == 250 || streak == 300 -> true
        streak == 365 -> true
        streak > 365 && streak % 100 == 0 -> true
        else -> false
    }

    /**
     * Called right after a study session is saved. Publishes the goal post
     * the first time the day crosses the personal target, and celebrates a
     * milestone streak if the save produced one.
     */
    suspend fun afterStudySaved(goalMinutes: Int) {
        if (!Store.prefs.value.autoStudyPost) return
        runCatching {
            val today = ir.studying.app.data.StudyToday.from(Api.obj(Api.get("study_today")))
            postGoalReached(today.totalMinutes, goalMinutes)
            val streak = Api.obj(Api.get("streak")).optInt("streak", 0)
            postStreak(streak)
        }
    }

    suspend fun postStreak(streak: Int) {
        /* بدون این شرط، استریک‌ها حتی با خاموش‌بودن پست خودکار منتشر می‌شدند. */
        if (!Store.prefs.value.autoStudyPost) return
        if (!isMilestone(streak)) return
        val p = prefs ?: return
        if (p.getInt(K_STREAK, 0) == streak) return
        val flavour = when {
            streak >= 365 -> "یک سال بدون وقفه!"
            streak >= 100 -> "سه رقمی شد!"
            streak >= 30 -> "یک ماه پیوسته!"
            else -> "ادامه می‌دم."
        }
        val body = streak.fa() + " روز پشت‌سرهم مطالعه کردم — " + flavour
        publish(tag(STREAK, 0, 0, streak) + body)
        p.edit().putInt(K_STREAK, streak).apply()
    }
}
