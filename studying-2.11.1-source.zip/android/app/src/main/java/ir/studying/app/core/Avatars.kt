package ir.studying.app.core

import ir.studying.app.R

/**
 * آواتارهای آمادهٔ داخل اپ.
 *
 * چرا داخل اپ و نه روی سرور: این ده تصویر ثابت‌اند و برای همهٔ کاربران یکی؛
 * آپلودشان به ازای هر کاربر هم پهنای باند سرور را می‌سوزاند و هم هر بار باید
 * دوباره دانلود شوند. پس فایل‌ها یک‌بار در APK می‌آیند و سرور فقط کلید کوتاه
 * («builtin:a3») را نگه می‌دارد؛ بقیهٔ کاربران همان کلید را از روی نسخهٔ خودشان
 * رندر می‌کنند.
 */
object Avatars {

    const val PREFIX = "builtin:"

    /**
     * مسیر معادل روی سرور.
     *
     * چرا: نسخه‌های قدیمی اپ «builtin:» را نمی‌فهمند، پس سرور در خروجی خود
     * کلید را به فایل واقعی «assets/avatars/av_03.webp» تبدیل می‌کند. نسخهٔ
     * جدید باید همان مسیر را هم بشناسد تا به‌جای دانلود، تصویر داخلی را رندر کند.
     */
    private const val ASSET_PREFIX = "assets/avatars/av_"

    /** ترتیب نمایش در انتخابگر. */
    val keys: List<String> = (1..10).map { "a$it" }

    private val res: Map<String, Int> = mapOf(
        "a1" to R.drawable.av_01,
        "a2" to R.drawable.av_02,
        "a3" to R.drawable.av_03,
        "a4" to R.drawable.av_04,
        "a5" to R.drawable.av_05,
        "a6" to R.drawable.av_06,
        "a7" to R.drawable.av_07,
        "a8" to R.drawable.av_08,
        "a9" to R.drawable.av_09,
        "a10" to R.drawable.av_10,
    )

    fun isBuiltin(value: String?): Boolean = keyOf(value) != null

    fun keyOf(value: String?): String? {
        val v = value ?: return null
        val k = if (v.startsWith(PREFIX)) {
            v.removePrefix(PREFIX)
        } else {
            /* مسیر سروری؛ با هر پیشوندی مثل «/assets/avatars/av_03.webp» */
            val i = v.indexOf(ASSET_PREFIX)
            if (i < 0) return null
            val num = v.substring(i + ASSET_PREFIX.length).takeWhile { it.isDigit() }
            val n = num.toIntOrNull() ?: return null
            "a$n"
        }
        return if (res.containsKey(k)) k else null
    }

    /** منبع تصویر برای یک مقدارِ آواتار، یا null اگر آواتار آماده نباشد. */
    fun drawableOf(value: String?): Int? = keyOf(value)?.let { res[it] }

    /** منبع تصویر مستقیماً از روی کلید (برای خود انتخابگر). */
    fun drawableForKey(key: String): Int = res[key] ?: R.drawable.av_01

    fun value(key: String): String = PREFIX + key

    /**
     * شخصیتِ هر کاراکتر سه‌بعدی (نسخهٔ ۲.۹).
     *
     * چرا این‌جا و نه در UI: اسم و رنگ هر کاراکتر هم در انتخابگر، هم در سرصفحهٔ
     * پروفایل و هم در شبکهٔ اجتماعی لازم است؛ یک منبع واحد نمی‌گذارد «پنگو» در
     * یک صفحه بنفش باشد و در صفحهٔ دیگر آبی. رنگ‌ها عدد ARGB‌اند تا این شیء
     * بدون وابستگی به Compose در تست‌های JVM هم قابل بررسی بماند.
     *
     * [focus]، [energy] و [mischief] امتیاز ۱ تا ۵ برای کارت «انتخاب شخصیت»اند؛
     * فقط جنبهٔ سرگرمی دارند و هیچ منطقی به آن‌ها وابسته نیست.
     */
    data class Character(
        val key: String,
        val name: String,
        val tagline: String,
        val emoji: String,
        val color: Long,
        val glow: Long,
        val focus: Int,
        val energy: Int,
        val mischief: Int,
    )

    val characters: List<Character> = listOf(
        Character("a1", "میو", "گربهٔ آرام و کنجکاو", "🐱", 0xFF8B5CF6, 0xFFC4B5FD, 4, 2, 3),
        Character("a2", "فاکسی", "روباه کتاب‌خوان", "🦊", 0xFFFB7185, 0xFFFDBA74, 5, 3, 2),
        Character("a3", "دینو", "کاشف ماجراجو", "🦖", 0xFF14B8A6, 0xFF67E8F9, 3, 4, 4),
        Character("a4", "پاندا", "ورزشکار پرانرژی", "🐼", 0xFF3B82F6, 0xFF93C5FD, 3, 5, 3),
        Character("a5", "شیرشاه", "سلطان استریک", "🦁", 0xFFE11D48, 0xFFFBBF24, 4, 5, 2),
        Character("a6", "خرگوشک", "عاشق موسیقی", "🐰", 0xFFF59E0B, 0xFFFDE68A, 3, 4, 5),
        Character("a7", "پنگو", "خونسرد و باحال", "🐧", 0xFFA855F7, 0xFFF0ABFC, 4, 2, 5),
        Character("a8", "یخی", "خرس قطبی مهربان", "❄️", 0xFF0EA5E9, 0xFFBAE6FD, 4, 3, 3),
        Character("a9", "اژدری", "اژدهای شیطون", "🐲", 0xFF10B981, 0xFFA3E635, 2, 5, 5),
        Character("a10", "رُبو", "ربات باهوش", "🤖", 0xFFF97316, 0xFF22D3EE, 5, 4, 2),
    )

    fun characterOf(key: String?): Character? = characters.firstOrNull { it.key == key }

    /** شخصیتِ یک مقدارِ آواتار («builtin:a3» یا مسیر سروری)، یا null برای عکس شخصی. */
    fun characterOfValue(value: String?): Character? = characterOf(keyOf(value))
}
