package ir.studying.app.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * دستاوردها: امتیازهایی که با «کار معنادار» گرفته می‌شوند، نه فقط با گذشت زمان.
 *
 * چرا اضافه شد: امتیاز قبلاً تقریباً فقط «دقیقهٔ مطالعه» بود، پس رتبهٔ اول
 * روز شدن، تکمیل یک رقابت یا تحمل‌کردن قفل گوشی هیچ اثر جداگانه‌ای نداشت.
 * حالا سرور برای هر رویداد یک‌بار پاداش ثبت می‌کند (تکراری نمی‌دهد) و اپ
 * فقط نتیجه را نشان می‌دهد؛ پس امتیاز روی گوشی قابل جعل نیست.
 */
object Awards {

    data class Award(
        val key: String,
        val kind: String,
        val title: String,
        val emoji: String,
        val xp: Int,
        val coins: Int,
        val note: String = "",
        val day: String = "",
    )

    data class CatalogItem(val kind: String, val title: String, val emoji: String, val xp: Int, val coins: Int)

    private fun one(o: JSONObject) = Award(
        key = o.optString("key"),
        kind = o.optString("kind"),
        title = o.optString("title").ifBlank { "پاداش" },
        emoji = o.optString("emoji").ifBlank { "✨" },
        xp = o.optInt("xp"),
        coins = o.optInt("coins"),
        note = o.optString("note", ""),
        day = o.optString("day", ""),
    )

    /** پاداش‌های تازه‌ای که همراه پاسخ یک درخواست دیگر آمده‌اند. */
    fun from(root: JSONObject?): List<Award> {
        val arr: JSONArray = root?.optJSONArray("awards") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::one) }
    }

    fun from(raw: String?): List<Award> = try {
        if (raw.isNullOrBlank()) emptyList() else from(JSONObject(raw))
    } catch (_: Exception) { emptyList() }

    data class Feed(val awards: List<Award>, val catalog: List<CatalogItem>, val xp: Int, val ready: Boolean)

    suspend fun load(limit: Int = 30): Feed = try {
        val o = Api.obj(Api.get("awards", "limit" to limit.toString()))
        val a = o.optJSONArray("awards") ?: JSONArray()
        val c = o.optJSONArray("catalog") ?: JSONArray()
        Feed(
            awards = (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let(::one) },
            catalog = (0 until c.length()).mapNotNull { i ->
                c.optJSONObject(i)?.let {
                    CatalogItem(
                        kind = it.optString("kind"),
                        title = it.optString("title"),
                        emoji = it.optString("emoji").ifBlank { "✨" },
                        xp = it.optInt("xp"),
                        coins = it.optInt("coins"),
                    )
                }
            },
            xp = o.optInt("award_xp"),
            ready = o.optInt("ready", 1) == 1,
        )
    } catch (_: Exception) {
        Feed(emptyList(), emptyList(), 0, false)
    }

    /** متن کوتاه یک پاداش برای اسنک‌بار. */
    fun line(a: Award): String =
        a.emoji + " " + a.title + " +" + a.xp.toString() + " امتیاز" +
            (if (a.coins > 0) " و " + a.coins.toString() + " سکه" else "")

    /**
     * پاداش‌های تازه را به کاربر اعلام می‌کند. چند پاداش هم‌زمان در یک پیام
     * جمع می‌شوند تا سه اسنک‌بار پشت سر هم روی صفحه نیفتد.
     */
    suspend fun announce(list: List<Award>) {
        if (list.isEmpty()) return
        val text = list.joinToString(" · ") { line(it) }
        ir.studying.app.ui.components.AppSnack.show(text)
        Game.refresh()
    }
}
