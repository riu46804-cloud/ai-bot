package ir.studying.app.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * A tiny read-through cache for API payloads.
 *
 * Every screen used to open on a spinner and stay there until the network
 * answered, which on a bad connection meant an app that looked broken. The raw
 * JSON of the last successful response is kept here, so a screen can paint real
 * content immediately and then quietly replace it once the fresh data lands.
 *
 * Payloads are stored verbatim: no parsing happens on the write path, so a
 * server-side field change can never corrupt the cache, and a cache miss is
 * always safe because callers fall back to the network.
 */
object Cache {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** One day. Long enough to survive a night offline, short enough to not show stale weeks. */
    const val DEFAULT_MAX_AGE_MS = 24L * 60L * 60L * 1000L

    private const val PREFIX = "cache_"

    private fun slot(key: String, owner: String?, day: String): String? {
        if (owner.isNullOrBlank()) return null
        val user = java.security.MessageDigest.getInstance("SHA-256").digest(owner.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val daily = key in setOf(STUDY_TODAY, STREAK, "widget_snapshot")
        return PREFIX + user + "_" + key + if (daily) "_" + day else ""
    }

    fun put(key: String, payload: String, owner: String? = Store.username, day: String = IranTime.todayIso()) {
        if (payload.isBlank()) return
        val slot = slot(key, owner, day) ?: return
        scope.launch { Store.putString(slot, System.currentTimeMillis().toString() + "|" + payload) }
    }

    /** Returns the cached payload, or null when missing or older than [maxAgeMs]. */
    suspend fun get(key: String, maxAgeMs: Long = DEFAULT_MAX_AGE_MS, owner: String? = Store.username, day: String = IranTime.todayIso()): String? {
        val slot = slot(key, owner, day) ?: return null
        val raw = Store.getString(slot) ?: return null
        if (Store.username != owner) return null
        val sep = raw.indexOf('|')
        if (sep <= 0) return null
        val savedAt = raw.substring(0, sep).toLongOrNull() ?: return null
        val age = System.currentTimeMillis() - savedAt
        if (age < 0L || (maxAgeMs > 0L && age > maxAgeMs)) return null
        return raw.substring(sep + 1)
    }

    /** Age of the cached payload in milliseconds, or null when there is nothing cached. */
    suspend fun ageMs(key: String): Long? {
        val raw = Store.getString(slot(key, Store.username, IranTime.todayIso()) ?: return null) ?: return null
        val sep = raw.indexOf('|')
        if (sep <= 0) return null
        val savedAt = raw.substring(0, sep).toLongOrNull() ?: return null
        return System.currentTimeMillis() - savedAt
    }

    fun forget(key: String) {
        val slot = slot(key, Store.username, IranTime.todayIso()) ?: return
        scope.launch { Store.putString(slot, null) }
    }

    /** Remove legacy unscoped entries. Scoped entries can only be read by their owner. */
    fun clearAll() {
        scope.launch { for (k in KNOWN) Store.putString(PREFIX + k, null) }
    }

    // Cache keys. Kept as constants so a typo cannot silently create a second cache.
    const val STUDY_TODAY = "study_today"
    const val STREAK = "streak"
    const val COURSES = "courses"
    const val GROUPS = "group_list"
    const val FEED = "feed"
    const val INBOX = "inbox"
    const val HISTORY = "history"
    /** آخرین برنامه‌ی مطالعه‌ی ساخته‌شده؛ عمداً روزانه نیست چون چند هفته اعتبار دارد. */
    const val PLANNER = "planner_plan"
    /** فهرست کتاب‌ها و مباحث؛ هفته‌ها ثابت می‌ماند، پس عمر طولانی دارد. */
    const val PLANNER_CURRICULUM = "planner_curriculum"

    private val KNOWN = listOf(STUDY_TODAY, STREAK, COURSES, GROUPS, FEED, INBOX, HISTORY, PLANNER, PLANNER_CURRICULUM)
}
