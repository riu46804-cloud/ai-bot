package ir.studying.app.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * چالش‌های دو نفره: «رقابت مطالعه» و «پیشنهاد قفل گوشی».
 *
 * پیشنهاد به شکل یک پیام متنی نشانه‌دار داخل همان چت رد و بدل می‌شود (پیشوند [MARK])
 * تا نه به نوع پیام جدیدی در سرور چت نیاز باشد و نه نسخه‌های قدیمی اپ چیزی را از دست بدهند؛
 * نسخهٔ قدیمی حداکثر یک متن خام می‌بیند، نه خطا.
 *
 * خواندن لیست خطا را بی‌صدا رد می‌کند (نباید چت را بشکند) ولی کنش‌ها
 * (ساخت/پاسخ/لغو) متن خطا برمی‌گردانند تا کاربر بازخورد درست بگیرد.
 */
object Challenges {

    /** نشانهٔ ابتدای پیام چالش. */
    const val MARK = "⚔️CHALLENGE:"

    /** برچسب RefreshBus؛ هر تغییری در چالش‌ها با همین منتشر می‌شود. */
    const val TAG = "challenges"

    /** پیشنهادی که داخل چت نشان داده می‌شود. */
    data class Offer(
        val id: Int,
        /** study = رقابت مطالعه، lock = پیشنهاد قفل گوشی */
        val kind: String,
        val minutes: Int,
        val days: Int,
        val mode: String,
        val from: String,
    )

    /** چالشی که پذیرفته شده و در جریان است (برای صفحهٔ اصلی). */
    data class Active(
        val id: Int,
        val kind: String,
        val opponent: String,
        val minutes: Int,
        val days: Int,
        val mode: String,
        val myMinutes: Int,
        val theirMinutes: Int,
        val status: String,
        /** پیشنهاد از طرف خودم فرستاده شده؟ */
        val mine: Boolean = false,
        /** به هدف رقابت رسیده‌ام و پاداشش هنوز گرفته نشده. */
        val canClaim: Boolean = false,
    )

    fun payload(id: Int, kind: String, minutes: Int, days: Int, mode: String, from: String): String =
        MARK + JSONObject().apply {
            put("id", id)
            put("kind", kind)
            put("minutes", minutes)
            put("days", days)
            put("mode", mode)
            put("from", from)
        }.toString()

    /** متن خوانا برای پیش‌نمایش چت؛ اگر چالش نباشد همان متن اصلی. */
    fun label(text: String?): String {
        val offer = parse(text) ?: return text ?: ""
        return if (offer.kind == "lock") "🔒 پیشنهاد قفل گوشی" else "⚔️ پیشنهاد رقابت مطالعه"
    }

    /** اگر این متن یک پیشنهاد چالش است، آن را برمی‌گرداند. */
    fun parse(text: String?): Offer? {
        if (text == null || !text.startsWith(MARK)) return null
        return try {
            val o = JSONObject(text.removePrefix(MARK))
            Offer(
                id = o.optInt("id"),
                kind = o.optString("kind", "study"),
                minutes = o.optInt("minutes", 0),
                days = o.optInt("days", 1),
                mode = o.optString("mode", "apps"),
                from = o.optString("from", ""),
            )
        } catch (_: Exception) {
            null
        }
    }

    /**
     * خطاها دیگر بلع نمی‌شوند.
     *
     * قبلاً این توابع Boolean برمی‌گرداندند و هر استثنا را می‌خوردند؛ در عمل
     * پاسخ خطادار سرور («چالش پیدا نشد»، سقف رقابت‌ها و…) بی‌صدا رد می‌شد و
     * کاربر فکر می‌کرد پذیرش انجام شده. حالا خروجی متن خطاست (null = موفق)
     * تا رابط کاربری بتواند واقعیت را نشان بدهد.
     */
    suspend fun create(to: String, kind: String, minutes: Int, days: Int, mode: String): String? = try {
        Api.post(
            "challenge_create",
            JSONObject().apply {
                put("to", to)
                put("kind", kind)
                put("minutes", minutes)
                put("days", days)
                put("mode", mode)
            },
        )
        RefreshBus.emit(TAG)
        null
    } catch (e: Exception) {
        humanizeError(e)
    }

    /** پاسخ به پیشنهاد؛ null = انجام شد. */
    suspend fun respond(id: Int, accept: Boolean): String? = try {
        Api.post(
            "challenge_respond",
            JSONObject().apply {
                put("id", id)
                put("action", if (accept) "accept" else "decline")
            },
        )
        RefreshBus.emit(TAG)
        null
    } catch (e: Exception) {
        humanizeError(e)
    }

    /** لغو پیشنهاد یا پایان دادن به رقابت (هر دو طرف مجازند). */
    suspend fun cancel(id: Int): String? = try {
        Api.post(
            "challenge_respond",
            JSONObject().apply {
                put("id", id)
                put("action", "cancel")
            },
        )
        RefreshBus.emit(TAG)
        null
    } catch (e: Exception) {
        humanizeError(e)
    }

    /**
     * وضعیت لحظه‌ای چند چالش.
     *
     * متن پیام چالش در چت هرگز تغییر نمی‌کند، پس کارت داخل حباب نمی‌تواند از
     * خود پیام بفهمد که پذیرفته شده یا نه؛ این پرس‌وجو همان شکاف را پر می‌کند.
     */
    suspend fun states(ids: List<Int>): Map<Int, String> = try {
        if (ids.isEmpty()) emptyMap() else {
            val root = JSONObject(Api.get("challenge_state", "ids" to ids.distinct().take(30).joinToString(",")))
            val arr = root.optJSONArray("states") ?: JSONArray()
            val out = HashMap<Int, String>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out[o.optInt("id")] = o.optString("status", "pending")
            }
            out
        }
    } catch (_: Exception) {
        emptyMap()
    }

    /**
     * دریافت پاداش رقابتِ تکمیل‌شده. سرور خودش بررسی می‌کند که واقعاً به هدف
     * رسیده باشی و پاداش هر رقابت را فقط یک بار می‌دهد.
     * خروجی: پیام خطا (null = موفق) به همراه پاداش‌های گرفته‌شده.
     */
    suspend fun claim(id: Int): Pair<String?, List<Awards.Award>> = try {
        val o = Api.obj(Api.post("challenge_claim", JSONObject().put("id", id)))
        val err = o.optString("error", "")
        if (err.isNotBlank()) err to emptyList()
        else {
            RefreshBus.emit(TAG)
            null to Awards.from(o)
        }
    } catch (e: Exception) {
        humanizeError(e) to emptyList()
    }

    /** چالش‌های در جریان با امتیاز هر دو طرف. */
    suspend fun list(): List<Active> = try {
        val root = JSONObject(Api.get("challenge_list"))
        val arr = root.optJSONArray("challenges") ?: JSONArray()
        val out = ArrayList<Active>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                Active(
                    id = o.optInt("id"),
                    kind = o.optString("kind", "study"),
                    opponent = o.optString("opponent", ""),
                    minutes = o.optInt("minutes", 0),
                    days = o.optInt("days", 1),
                    mode = o.optString("mode", "apps"),
                    myMinutes = o.optInt("my_minutes", 0),
                    theirMinutes = o.optInt("their_minutes", 0),
                    status = o.optString("status", "accepted"),
                    mine = o.optInt("is_mine", 0) == 1,
                    canClaim = o.optInt("can_claim", 0) == 1,
                ),
            )
        }
        out
    } catch (_: Exception) {
        emptyList()
    }
}
