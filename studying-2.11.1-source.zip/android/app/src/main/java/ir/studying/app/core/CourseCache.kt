package ir.studying.app.core

import ir.studying.app.data.Course
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * لیست درس‌ها، آفلاین‌اول.
 *
 * مشکلی که این کلاس حل می‌کند: صفحهٔ مطالعه لیست درس را هر بار از شبکه می‌گرفت.
 * بی‌اینترنت لیست خالی می‌ماند، و چون ثبت پارت بدون درس ممنوع است، کل حالت
 * آفلاین بی‌فایده می‌شد — صف آفلاین وجود داشت ولی کاربر هیچ‌وقت نمی‌توانست
 * چیزی داخلش بگذارد.
 *
 * پس آخرین لیست موفق روی دیسک می‌ماند و **بدون انقضا** خوانده می‌شود: درس‌ها
 * ماه‌ها عوض نمی‌شوند و یک نام کمی قدیمی، بی‌نهایت بهتر از لیست خالی است.
 * شناسه‌ها همان شناسهٔ سرور است، پس پارت‌های آفلاین با همان `course_id` بعداً
 * درست سینک می‌شوند.
 */
object CourseCache {

    private val lock = Mutex()
    private val _courses = MutableStateFlow<List<Course>>(emptyList())

    /** لیست جاری؛ صفحه‌ها می‌توانند مستقیم به آن گوش بدهند. */
    val courses: StateFlow<List<Course>> get() = _courses

    /** لیست بدون انتظار — برای جاهایی که همان لحظه چیزی برای نشان‌دادن می‌خواهند. */
    fun peek(): List<Course> = _courses.value

    /** فقط از دیسک. بدون انقضا، چون بدون درس، مطالعهٔ آفلاین ممکن نیست. */
    suspend fun cached(): List<Course> = runCatching {
        val raw = Cache.get(Cache.COURSES, maxAgeMs = 0L) ?: return emptyList()
        Course.list(Api.arr(raw))
    }.getOrDefault(emptyList())

    /**
     * اول کش را منتشر می‌کند (تا لیست فوراً دیده شود) و بعد شبکه را امتحان
     * می‌کند. اگر شبکه نبود، همان کش نتیجهٔ نهایی است و خطا به کاربر نمی‌خورد.
     */
    suspend fun refresh(): List<Course> = lock.withLock {
        if (_courses.value.isEmpty()) {
            val disk = cached()
            if (disk.isNotEmpty()) _courses.value = disk
        }
        val owner = Store.username
        try {
            val raw = Api.get("courses")
            val fresh = Course.list(Api.arr(raw))
            if (Store.username == owner) {
                Cache.put(Cache.COURSES, raw, owner)
                _courses.value = fresh
            }
            fresh
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            /* آفلاین یا سرور خواب: کش تنها چیزی است که داریم و کافی است. */
            _courses.value.ifEmpty { cached().also { if (it.isNotEmpty()) _courses.value = it } }
        }
    }

    /** موقع خروج از حساب؛ درس‌های نفر قبلی نباید به نفر بعدی نشان داده شوند. */
    fun reset() { _courses.value = emptyList() }
}
