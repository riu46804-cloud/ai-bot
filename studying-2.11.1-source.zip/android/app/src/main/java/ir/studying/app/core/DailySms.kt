package ir.studying.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * کلاینت «پیامک صبحگاهی» — سرویسی جدا از `api.php`، با آدرس و دیتابیس خودش.
 *
 * با همان توکن ورود کار می‌کند. توکن هم در `Authorization` می‌رود و هم در
 * `X-Auth-Token`، چون بعضی هاست‌ها هدر Authorization را به PHP نمی‌رسانند.
 * برخلاف [Api]، پاسخ ۴۰۱ این سرویس نشست را پاک نمی‌کند: مشکل یک سرویس جانبی
 * نباید کاربر را از کل اپ بیرون بیندازد.
 */
object DailySms {
    /** آدرس سرویس؛ اگر روی آدرس دیگری نصب شد فقط همین خط عوض شود. */
    const val BASE = "https://studying.ir/sms/api.php"

    data class Exam(
        val key: String,
        val title: String,
        val shortTitle: String,
        val emoji: String,
        val date: String?,
        val dateFa: String?,
        val daysLeft: Int?,
        val official: Boolean,
    )

    data class Preview(val text: String, val parts: Int, val isSample: Boolean, val daysLeft: Int?)

    data class HistoryItem(
        val date: String,
        val dateFa: String,
        val timeFa: String?,
        val kind: String,
        val text: String,
        val status: String,
        val statusLabel: String,
    )

    data class Status(
        val eligible: Boolean,
        /** subscription_required | phone_required | phone_unverified | null */
        val blockReason: String?,
        val subscriptionExpiresFa: String?,
        val subscriptionDaysLeft: Int,
        val phoneMasked: String?,
        val phoneOk: Boolean,
        val motivational: Boolean,
        val konkur: Boolean,
        val examKey: String?,
        val active: Boolean,
        val suggestedExamKey: String?,
        val exams: List<Exam>,
        val sendTimeFa: String,
        val nextSendLabel: String,
        val nextSendDayFa: String,
        val preview: Preview?,
        val quotesCount: Int,
        val todayStatus: String?,
        val totalSent: Int,
        val sinceFa: String?,
        val history: List<HistoryItem>,
        val testAvailable: Boolean,
        val testUsedToday: Boolean,
    ) {
        /** گروهی که شمارش معکوس برایش نشان داده می‌شود: انتخاب کاربر، پیشنهاد از رشته، یا اولی. */
        val shownExam: Exam?
            get() = exams.firstOrNull { it.key == examKey } ?: exams.firstOrNull { it.key == suggestedExamKey } ?: exams.firstOrNull()
        val anyOn: Boolean get() = motivational || konkur
        val locked: Boolean get() = blockReason == "subscription_required"
    }

    class Result(val status: Status, val message: String)

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        // Never forward the fallback auth header to a different origin, or
        // automatically replay an ambiguous test-send request.
        .followRedirects(false)
        .followSslRedirects(false)
        .retryOnConnectionFailure(false)
        .build()

    suspend fun status(): Status = withContext(Dispatchers.IO) { parse(call("status", null)) }

    suspend fun save(motivational: Boolean, konkur: Boolean, examKey: String?): Result = withContext(Dispatchers.IO) {
        val body = JSONObject().put("motivational", motivational).put("konkur", konkur)
        if (examKey != null) body.put("exam_key", examKey)
        val o = call("save", body)
        Result(parse(o), o.str("message"))
    }

    suspend fun sendTest(): Result = withContext(Dispatchers.IO) {
        val o = call("test", JSONObject())
        Result(parse(o), o.str("message"))
    }

    /** Request construction is testable without sending SMS or using real credentials. */
    internal fun buildRequest(action: String, body: JSONObject?, token: String): Request {
        require(action in setOf("status", "save", "test"))
        val builder = Request.Builder().url("$BASE?action=$action")
            .header("Accept", "application/json")
            .header("Authorization", "Bearer $token")
            .header("X-Auth-Token", token)
        if (body == null) builder.get()
        else builder.post(MessageSendTransport.oneShot(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType())))
        return builder.build()
    }

    private fun call(action: String, body: JSONObject?): JSONObject {
        val token = Store.token ?: throw ApiException("اول وارد حسابت شو.", 401, "unauthorized")
        val request = buildRequest(action, body, token)
        val response = try {
            client.newCall(request).execute()
        } catch (e: Exception) {
            throw ApiException(humanizeError(e))
        }
        response.use { resp ->
            val text = resp.body?.string()?.trim().orEmpty()
            val o = if (text.startsWith("{")) runCatching { JSONObject(text) }.getOrNull() else null
            if (o != null && o.has("error") && !o.isNull("error")) {
                throw ApiException(o.str("error").ifBlank { "خطایی پیش آمد" }, resp.code, o.strOrNull("error_code"))
            }
            if (!resp.isSuccessful || o == null) throw ApiException("سرویس پیامک فعلاً در دسترس نیست (${resp.code.fa()}) 🛠", resp.code)
            return o
        }
    }

    internal fun parse(o: JSONObject): Status {
        val sub = o.optJSONObject("subscription") ?: JSONObject()
        val phone = o.optJSONObject("phone") ?: JSONObject()
        val settings = o.optJSONObject("settings") ?: JSONObject()
        val schedule = o.optJSONObject("schedule") ?: JSONObject()
        val stats = o.optJSONObject("stats") ?: JSONObject()
        val preview = o.optJSONObject("preview")
        val today = o.optJSONObject("today")
        return Status(
            eligible = o.boolish("eligible"),
            blockReason = o.strOrNull("block_reason"),
            subscriptionExpiresFa = sub.strOrNull("expires_fa"),
            subscriptionDaysLeft = sub.int("days_left"),
            phoneMasked = phone.strOrNull("masked"),
            phoneOk = phone.boolish("ok"),
            motivational = settings.boolish("motivational"),
            konkur = settings.boolish("konkur"),
            examKey = settings.strOrNull("exam_key"),
            active = o.boolish("active"),
            suggestedExamKey = o.strOrNull("suggested_exam_key"),
            exams = o.optJSONArray("exams")?.objects()?.map {
                Exam(
                    key = it.str("key"), title = it.str("title"), shortTitle = it.str("short_title"),
                    emoji = it.str("emoji"), date = it.strOrNull("date"), dateFa = it.strOrNull("date_fa"),
                    daysLeft = it.intOrNull("days_left"), official = it.boolish("official"),
                )
            } ?: emptyList(),
            sendTimeFa = schedule.str("send_time_fa").ifBlank { "۷:۰۰" },
            nextSendLabel = schedule.str("next_send_label"),
            nextSendDayFa = schedule.str("next_send_day_fa"),
            preview = preview?.let {
                Preview(it.str("text"), it.int("parts"), it.boolish("is_sample"), it.intOrNull("days_left"))
            },
            quotesCount = o.int("quotes_count"),
            todayStatus = today?.strOrNull("status"),
            totalSent = stats.int("total_sent"),
            sinceFa = stats.strOrNull("since_fa"),
            history = o.optJSONArray("history")?.objects()?.map {
                HistoryItem(
                    date = it.str("date"), dateFa = it.str("date_fa"), timeFa = it.strOrNull("time_fa"),
                    kind = it.str("kind"), text = it.str("text"), status = it.str("status"),
                    statusLabel = it.str("status_label"),
                )
            } ?: emptyList(),
            testAvailable = o.boolish("test_available"),
            testUsedToday = o.boolish("test_used_today"),
        )
    }
}
