package ir.studying.app.core

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import ir.studying.app.R
import java.io.File
import java.io.FileOutputStream

/**
 * Renders one day as a shareable card, as PNG or PDF.
 *
 * The card is drawn directly onto a [Canvas] rather than captured from the
 * Compose tree: a screenshot would inherit the device's scroll position, the
 * system bars and the current screen density. Drawing it explicitly produces
 * an identical, print-quality 1080-wide card on every phone, and it can be
 * produced even while the sheet is closing.
 *
 * Typography is the app's own Vazirmatn, loaded from `res/font`, so exports
 * match the product instead of falling back to the system Latin face (which
 * renders Persian noticeably worse).
 */
object DayExport {

    private const val W = 1080
    private const val PAD = 64f

    // Palette mirrors the dark theme.
    private const val BG = 0xFF0B100E.toInt()
    private const val SURF = 0xFF141C18.toInt()
    private const val VAR = 0xFF1B2621.toInt()
    private const val MINT = 0xFF4ADE9F.toInt()
    private const val CYAN = 0xFF38BDF8.toInt()
    private const val AMBER = 0xFFFBBF24.toInt()
    private const val ORANGE = 0xFFFB923C.toInt()
    private const val INK = 0xFFEFF6F2.toInt()
    private const val MUTED = 0xFF8CA298.toInt()

    private val BAR_COLOURS = intArrayOf(MINT, CYAN, 0xFFA78BFA.toInt(), ORANGE, 0xFFF472B6.toInt(), AMBER)

    // ------------------------------------------------------------------ model

    data class Stat(val label: String, val value: String)
    data class Bar(val label: String, val minutes: Int)
    data class Session(val label: String, val range: String, val minutes: Int)
    data class Task(val text: String, val done: Boolean)

    data class DayCard(
        val dayTitle: String,
        val daySubtitle: String,
        /** Null for a future day, which has no study history to show. */
        val totalLabel: String?,
        val stats: List<Stat> = emptyList(),
        val bars: List<Bar> = emptyList(),
        val sessions: List<Session> = emptyList(),
        val tasks: List<Task> = emptyList(),
        val note: String? = null,
    )

    // --------------------------------------------------------------- typeface

    private var regular: Typeface? = null
    private var bold: Typeface? = null
    private var black: Typeface? = null

    private fun loadFonts(context: Context) {
        if (regular != null) return
        regular = runCatching { ResourcesCompat.getFont(context, R.font.vazirmatn_regular) }.getOrNull()
            ?: Typeface.DEFAULT
        bold = runCatching { ResourcesCompat.getFont(context, R.font.vazirmatn_bold) }.getOrNull()
            ?: Typeface.DEFAULT_BOLD
        black = runCatching { ResourcesCompat.getFont(context, R.font.vazirmatn_black) }.getOrNull()
            ?: bold
    }

    private fun p(
        size: Float,
        colour: Int,
        face: Typeface?,
        align: Paint.Align = Paint.Align.RIGHT,
    ): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = colour
        this.textSize = size
        this.typeface = face
        this.textAlign = align
    }

    private fun fill(colour: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colour }

    // ----------------------------------------------------------------- layout

    private fun heightOf(card: DayCard): Int {
        var h = 0f
        h += 340f                                            // header
        if (card.stats.isNotEmpty()) h += 150f
        if (card.bars.isNotEmpty()) h += 78f + 86f * card.bars.size
        if (card.sessions.isNotEmpty()) h += 78f + 74f * card.sessions.size
        h += 78f + (if (card.tasks.isEmpty()) 70f else 84f * card.tasks.size)
        if (card.note != null) h += 78f
        h += 168f                                            // footer
        return h.toInt().coerceAtLeast(900)
    }

    // ----------------------------------------------------------------- render

    fun render(context: Context, card: DayCard): Bitmap {
        loadFonts(context)
        val h = heightOf(card)
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(BG)

        val right = W - PAD
        val left = PAD

        // ---------------------------------------------------------- header
        val headerH = 300f
        val header = RectF(left, PAD, W - PAD, PAD + headerH)
        c.drawRoundRect(
            header, 44f, 44f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    header.right, header.top, header.left, header.bottom,
                    intArrayOf(0xFF12241D.toInt(), 0xFF0F1D2A.toInt()), null, Shader.TileMode.CLAMP,
                )
            },
        )
        // Soft mint bloom in the leading corner.
        c.save()
        c.clipRect(header)
        c.drawCircle(
            header.right - 60f, header.top + 40f, 240f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    header.right - 60f, header.top + 40f, 240f,
                    intArrayOf(0x554ADE9F, 0x00000000), null, Shader.TileMode.CLAMP,
                )
            },
        )
        c.restore()

        var y = header.top + 82f
        c.drawText(card.dayTitle, right - 34f, y, p(52f, INK, black))
        y += 44f
        c.drawText(card.daySubtitle, right - 34f, y, p(27f, MUTED, regular))

        if (card.totalLabel != null) {
            y += 92f
            c.drawText(card.totalLabel, right - 34f, y, p(78f, MINT, black))
            val tw = p(78f, MINT, black).measureText(card.totalLabel)
            c.drawText("\u0645\u0637\u0627\u0644\u0639\u0647", right - 48f - tw, y, p(26f, MUTED, regular))
        } else {
            y += 78f
            c.drawText("\u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u067e\u06cc\u0634\u200c\u0631\u0648", right - 34f, y, p(34f, CYAN, bold))
        }

        y = header.bottom + 44f

        // ---------------------------------------------------------- stats
        if (card.stats.isNotEmpty()) {
            val n = card.stats.size
            val gap = 14f
            val cw = (W - 2 * PAD - gap * (n - 1)) / n
            card.stats.forEachIndexed { i, s ->
                // Laid out right to left to match the reading direction.
                val r = RectF(right - cw - i * (cw + gap) , y, right - i * (cw + gap), y + 106f)
                c.drawRoundRect(r, 26f, 26f, fill(SURF))
                c.drawText(s.value, r.centerX() + p(34f, INK, bold).measureText(s.value) / 2f, r.top + 48f, p(34f, INK, bold))
                c.drawText(s.label, r.centerX() + p(22f, MUTED, regular).measureText(s.label) / 2f, r.top + 82f, p(22f, MUTED, regular))
            }
            y += 150f
        }

        // ---------------------------------------------------------- courses
        if (card.bars.isNotEmpty()) {
            c.drawText("\u062f\u0631\u0633\u200c\u0647\u0627", right, y, p(32f, INK, bold))
            y += 46f
            val maxM = card.bars.maxOf { it.minutes }.coerceAtLeast(1)
            card.bars.forEachIndexed { i, b ->
                val colour = BAR_COLOURS[i % BAR_COLOURS.size]
                c.drawText(b.label, right, y + 26f, p(28f, INK, regular))
                val mins = Fmt.minutes(b.minutes)
                c.drawText(mins, left, y + 26f, p(26f, MUTED, regular, Paint.Align.LEFT))
                val track = RectF(left, y + 44f, right, y + 62f)
                c.drawRoundRect(track, 9f, 9f, fill(VAR))
                val frac = b.minutes.toFloat() / maxM
                // Bars grow from the right, the direction the text reads.
                val filled = RectF(right - (track.width() * frac), track.top, right, track.bottom)
                c.drawRoundRect(filled, 9f, 9f, fill(colour))
                y += 86f
            }
            y += 32f
        }

        // ---------------------------------------------------------- sessions
        if (card.sessions.isNotEmpty()) {
            c.drawText("\u062e\u0637 \u0632\u0645\u0627\u0646\u06cc", right, y, p(32f, INK, bold))
            y += 46f
            card.sessions.forEach { s ->
                val r = RectF(left, y, right, y + 58f)
                c.drawRoundRect(r, 18f, 18f, fill(SURF))
                c.drawCircle(right - 26f, r.centerY(), 7f, fill(MINT))
                c.drawText(s.label, right - 50f, r.centerY() + 10f, p(27f, INK, regular))
                c.drawText(s.range, left + 22f, r.centerY() + 10f, p(24f, MUTED, regular, Paint.Align.LEFT))
                y += 74f
            }
            y += 24f
        }

        // ---------------------------------------------------------- tasks
        c.drawText("\u062a\u0633\u06a9\u200c\u0647\u0627", right, y, p(32f, INK, bold))
        y += 46f
        if (card.tasks.isEmpty()) {
            c.drawText("\u062a\u0633\u06a9\u06cc \u0628\u0631\u0627\u06cc \u0627\u06cc\u0646 \u0631\u0648\u0632 \u062b\u0628\u062a \u0646\u0634\u062f\u0647", right, y + 30f, p(26f, MUTED, regular))
            y += 70f
        } else {
            card.tasks.forEach { t ->
                val r = RectF(left, y, right, y + 68f)
                c.drawRoundRect(r, 20f, 20f, fill(if (t.done) VAR else SURF))
                val pipX = right - 40f
                val pipY = r.centerY()
                c.drawCircle(
                    pipX, pipY, 17f,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (t.done) MINT else MUTED
                        style = if (t.done) Paint.Style.FILL else Paint.Style.STROKE
                        strokeWidth = 4f
                    },
                )
                if (t.done) {
                    val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = BG; strokeWidth = 5f
                        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
                    }
                    c.drawLine(pipX - 8f, pipY, pipX - 2f, pipY + 7f, tick)
                    c.drawLine(pipX - 2f, pipY + 7f, pipX + 8f, pipY - 7f, tick)
                }
                val tp = p(28f, if (t.done) MUTED else INK, regular)
                c.drawText(ellipsize(t.text, tp, r.width() - 110f), pipX - 34f, pipY + 10f, tp)
                y += 84f
            }
        }

        if (card.note != null) {
            y += 12f
            c.drawText(card.note, right, y + 30f, p(23f, MUTED, regular))
            y += 66f
        }

        // ---------------------------------------------------------- footer
        val fy = h - 92f
        c.drawLine(left, fy - 56f, right, fy - 56f, Paint().apply { color = 0xFF22302A.toInt(); strokeWidth = 2f })
        c.drawCircle(right - 22f, fy - 10f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(right - 44f, fy - 32f, right, fy + 12f, MINT, CYAN, Shader.TileMode.CLAMP)
        })
        c.drawText("\u062f\u0631\u0633 \u0647\u0627\u0628", right - 56f, fy, p(30f, INK, bold))
        c.drawText("studying", left, fy, p(24f, MUTED, regular, Paint.Align.LEFT))

        return bmp
    }

    private fun ellipsize(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var s = text
        while (s.isNotEmpty() && paint.measureText(s + "\u2026") > maxWidth) s = s.dropLast(1)
        return s + "\u2026"
    }

    // ------------------------------------------------------------------ files

    private fun outDir(context: Context): File =
        File(context.cacheDir, "exports").apply { mkdirs() }

    fun writePng(context: Context, card: DayCard, name: String): File {
        val f = File(outDir(context), name + ".png")
        val bmp = render(context, card)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return f
    }

    fun writePdf(context: Context, card: DayCard, name: String): File {
        val f = File(outDir(context), name + ".pdf")
        val bmp = render(context, card)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, 1).create())
        page.canvas.drawBitmap(bmp, 0f, 0f, null)
        doc.finishPage(page)
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        bmp.recycle()
        return f
    }

    fun share(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(send, "\u0627\u0634\u062a\u0631\u0627\u06a9 \u062e\u0631\u0648\u062c\u06cc")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}
