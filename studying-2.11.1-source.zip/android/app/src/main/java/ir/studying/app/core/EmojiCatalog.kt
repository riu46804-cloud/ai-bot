package ir.studying.app.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Emoji sets used by the chat: reactions and the 3D emoji keyboard.
 *
 * Everything listed here has a Fluent 3D render bundled by
 * tools/fetch_3d_icons.py (it scans this file). Unicode 15+ emoji are left out
 * on purpose: older phones show them as empty boxes inside the text field.
 */
object EmojiCatalog {

    private fun split(s: String) = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    /** First row of the reaction bar; the old 12 stay first so habits don't break. */
    val quickReactions: List<String> = split("❤️ 👍 👎 😂 🔥 🍓 🍌 🖕 😢 🤯 💯 🙏")

    /** Full Telegram style reaction grid shown after the expand button. */
    val allReactions: List<String> = (quickReactions + split(
        "🥰 👏 😁 🤔 😱 🤬 🎉 🤩 🤮 💩 👌 🕊️ 🤡 🥱 🥴 😍 🐳 ❤️‍🔥 🌚 🌭 🤣 ⚡ 🏆 💔 🤨 😐 " +
            "🍾 💋 😈 😴 😭 🤓 👻 🧑‍💻 👀 🎃 🙈 😇 😨 🤝 ✍️ 🤗 🫡 🎅 🎄 ☃️ 💅 🤪 🗿 🆒 💘 🙉 🦄 😘 💊 🙊 😎 👾 🤷 😡",
    )).distinct()

    data class Category(val key: String, val title: String, val icon: String, val emojis: List<String>)

    val categories: List<Category> = listOf(
        Category("smileys", "شکلک‌ها", "😀", split(
            "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 🫠 😉 😊 😇 🥰 😍 🤩 😘 😗 ☺️ 😚 😙 🥲 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🫢 🫣 🤫 🤔 🫡 " +
                "🤐 🤨 😐 😑 😶 🫥 😶‍🌫️ 😏 😒 🙄 😬 😮‍💨 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 😵‍💫 🤯 🤠 🥳 🥸 " +
                "😎 🤓 🧐 😕 🫤 😟 🙁 ☹️ 😮 😯 😲 😳 🥺 🥹 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 " +
                "😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 👾 🤖 😺 😸 😹 😻 😼 😽 🙀 😿 😾 🙈 🙉 🙊",
        )),
        Category("hearts", "قلب‌ها", "❤️", split(
            "❤️ 🧡 💛 💚 💙 💜 🤎 🖤 🤍 💔 ❤️‍🔥 ❤️‍🩹 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 💌 💋 💯 💢 💥 💫 💦 💨 🕳️ 💬 🗨️ 🗯️ 💭 💤",
        )),
        Category("people", "دست و آدم‌ها", "👍", split(
            "👍 👎 👏 🙌 🙏 👌 🤌 ✌️ 🤞 🫰 🤟 🤘 🤙 👋 🤝 💪 ✍️ 👀 🫶 👊 ✊ 🤛 🤜 ✋ 🖐️ 👆 👇 👈 👉 ☝️ 🫵 🤲 " +
                "🧠 🫀 🤷 🙋 🙆 🙅 🤦 🙇 💁 🧑‍🎓 🧑‍🏫 🧑‍💻 🧑‍🔬 🏃 🧘 💃 🕺 🫂",
        )),
        Category("study", "درس و کار", "📚", split(
            "📚 📖 📕 📗 📘 📙 📓 📔 📒 📝 ✏️ 🖊️ 🖋️ 🖍️ 📌 📍 📎 🖇️ 📐 📏 🧮 🗂️ 📁 📂 🗃️ 🗒️ 📋 📊 📈 📉 " +
                "💡 🔦 🔬 🔭 🧪 🧫 🧬 ⚗️ 🩺 💊 🧲 🌡️ 🖥️ 💻 ⌨️ 🖱️ 📱 ☎️ 🎧 🎤 🎵 🎶 🎹 🎸 🎻 🥁 🎬 📷 📸 🎨 🧩 ♟️ 🎲 🎮 " +
                "⏰ ⏳ ⌛ ⏱️ ⏲️ 🕰️ 📅 📆 🗓️ 🔤 🔢 ➕ ➖ ✖️ ➗ ♾️",
        )),
        Category("party", "جشن و نماد", "🎉", split(
            "🎉 🎊 🎁 🎈 🎂 ✨ ⭐ 🌟 ⚡ 🔥 ✅ ☑️ ✔️ ❌ ❎ ❗ ❓ ‼️ ⁉️ 🔔 🔕 📣 📢 " +
                "🎯 🏆 🥇 🥈 🥉 🏅 🎖️ 👑 💎 💰 🪙 🔑 🗝️ 🔒 🔓 🛡️ ⚔️ 🧭 🆒 🆕 🆗 🆘 ⛔ 🚫 ⚠️",
        )),
        Category("nature", "طبیعت", "🌿", split(
            "🌍 🌈 ☀️ 🌤️ ⛅ 🌦️ 🌧️ ⛈️ ❄️ ☃️ ⛄ 🌊 🌙 🌛 🌚 🌝 🌞 🪐 🌠 🌌 🌅 🌄 🌇 🌃 " +
                "🌱 🌿 ☘️ 🍀 🌵 🌴 🌳 🌲 🍁 🍂 🍃 🌸 🌺 🌻 🌹 🥀 🌷 💐 🌼 🍄 " +
                "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦉 🦄 🐝 🦋 🐞 🐢 🐍 🐙 🐬 🐳 🐋 🦈 🕊️ 🦅 🦖",
        )),
        Category("food", "خوراکی", "🍓", split(
            "☕ 🍵 🧋 🥤 🧃 🥛 🍕 🍔 🍟 🌭 🥪 🌮 🍿 🍩 🍪 🍫 🍬 🍭 🧁 🍰 🎂 🍦 🍨 🍓 🍒 🍎 🍏 🍊 🍋 🍌 🍉 🍇 🍑 🥭 🍍 🥥 🥑 🍞 🧀 🍳 🥗 🍚 🍜 🍝 🍲",
        )),
        Category("travel", "سفر و ورزش", "🚀", split(
            "🚀 ✈️ 🚗 🚕 🚌 🚲 🛴 🚂 ⛵ 🏠 🏡 🏫 🏛️ 🕌 🏔️ 🏕️ 🏖️ 🗿 🎡 🎢 ⚽ 🏀 🏐 🎾 🏓 🏸 ⛳ 🥊 🏋️ 🚴 🏊 ⛷️ " +
                "🤖 🧊 🪄 🔮 🧿 💣 🧨 🪅 🪩 🧸 🪁 📦 ✉️ 📩 💌 🏷️ 🔗 ⚙️ 🛠️ 🔧 🔨 🚨 🚦",
        )),
    )

    // ------------------------------------------------------------ recents --

    private const val KEY = "emoji_recent_v1"
    private const val MAX = 32
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _recent = MutableStateFlow<List<String>>(emptyList())
    val recent: StateFlow<List<String>> get() = _recent
    @Volatile private var loaded = false

    fun load() {
        if (loaded) return
        loaded = true
        io.launch {
            runCatching { Store.getString(KEY) }.getOrNull()?.let { s ->
                val list = s.split('\u0001').filter { it.isNotEmpty() }
                if (_recent.value.isEmpty()) _recent.value = list
            }
        }
    }

    fun use(emoji: String) {
        val next = (listOf(emoji) + _recent.value.filter { it != emoji }).take(MAX)
        _recent.value = next
        io.launch { runCatching { Store.putString(KEY, next.joinToString("\u0001")) } }
    }
}
