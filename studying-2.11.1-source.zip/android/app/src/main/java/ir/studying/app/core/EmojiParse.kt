package ir.studying.app.core

/**
 * Splits text into plain runs and emoji clusters, so emoji can be drawn with
 * the bundled 3D renders instead of the phone's emoji font.
 *
 * Pure Kotlin on purpose: it is unit tested on the JVM. A cluster is one base
 * emoji plus its variation selector, skin tone, keycap mark and any zero width
 * joined parts (👩‍💻, ❤️‍🔥). Plain symbols that are text by default (▲ ✓ ← ™)
 * stay text unless they carry U+FE0F, which is exactly what keyboards do.
 */
object EmojiParse {

    data class Seg(val text: String, val emoji: Boolean)

    private fun isRegional(cp: Int) = cp in 0x1F1E6..0x1F1FF
    private fun isSkinTone(cp: Int) = cp in 0x1F3FB..0x1F3FF

    /** Code points that can start an emoji cluster at all. */
    fun isEmojiBase(cp: Int): Boolean = when {
        cp in 0x1F000..0x1FAFF -> !isSkinTone(cp)
        cp in 0x2600..0x27BF -> true
        cp in 0x2B00..0x2BFF -> true
        cp in 0x2300..0x23FF -> true
        cp in 0x2190..0x21FF -> true
        cp in 0x25AA..0x25FE -> true
        cp == 0x2934 || cp == 0x2935 || cp == 0x3030 || cp == 0x303D -> true
        cp == 0x3297 || cp == 0x3299 || cp == 0x203C || cp == 0x2049 -> true
        cp == 0x2122 || cp == 0x2139 || cp == 0x24C2 || cp == 0x00A9 || cp == 0x00AE -> true
        else -> false
    }

    /** BMP code points that look like emoji even without U+FE0F. */
    private val defaultEmojiBmp: Set<Int> = buildSet {
        addAll(listOf(0x231A, 0x231B, 0x23E9, 0x23EA, 0x23EB, 0x23EC, 0x23F0, 0x23F3, 0x25FD, 0x25FE))
        addAll(listOf(0x2614, 0x2615, 0x267F, 0x2693, 0x26A1, 0x26AA, 0x26AB, 0x26BD, 0x26BE, 0x26C4, 0x26C5))
        addAll(listOf(0x26CE, 0x26D4, 0x26EA, 0x26F2, 0x26F3, 0x26F5, 0x26FA, 0x26FD, 0x2705, 0x270A, 0x270B))
        addAll(listOf(0x2728, 0x274C, 0x274E, 0x2753, 0x2754, 0x2755, 0x2757, 0x2795, 0x2796, 0x2797, 0x27B0, 0x27BF))
        addAll(listOf(0x2B1B, 0x2B1C, 0x2B50, 0x2B55))
        addAll(0x2648..0x2653)
    }

    /**
     * Returns the end index (exclusive) of the emoji cluster starting at [start],
     * or -1 when no emoji starts there.
     */
    fun clusterEnd(text: String, start: Int): Int {
        if (start >= text.length) return -1
        val cp = text.codePointAt(start)
        var i = start + Character.charCount(cp)
        // keycap: 0-9 # * then optional FE0F then U+20E3
        if (cp in 0x30..0x39 || cp == 0x23 || cp == 0x2A) {
            var j = i
            if (j < text.length && text[j].code == 0xFE0F) j++
            return if (j < text.length && text[j].code == 0x20E3) j + 1 else -1
        }
        if (isRegional(cp)) {
            if (i < text.length) {
                val n = text.codePointAt(i)
                if (isRegional(n)) return i + Character.charCount(n)
            }
            return -1
        }
        if (!isEmojiBase(cp)) return -1
        var hasVs = false
        var joined = false
        fun tail() {
            if (i < text.length && text[i].code == 0xFE0F) { i++; hasVs = true }
            if (i < text.length) {
                val n = text.codePointAt(i)
                if (isSkinTone(n)) { i += Character.charCount(n); hasVs = true }
            }
            if (i < text.length && text[i].code == 0x20E3) { i++; hasVs = true }
        }
        tail()
        while (i + 1 < text.length && text[i].code == 0x200D) {
            val n = text.codePointAt(i + 1)
            if (!isEmojiBase(n)) break
            i += 1 + Character.charCount(n)
            joined = true
            tail()
        }
        val looksEmoji = cp >= 0x1F000 || hasVs || joined || cp in defaultEmojiBmp
        return if (looksEmoji) i else -1
    }

    fun segments(text: String): List<Seg> {
        if (text.isEmpty()) return emptyList()
        val out = ArrayList<Seg>()
        val plain = StringBuilder()
        var i = 0
        while (i < text.length) {
            val end = clusterEnd(text, i)
            if (end > i) {
                if (plain.isNotEmpty()) { out.add(Seg(plain.toString(), false)); plain.setLength(0) }
                out.add(Seg(text.substring(i, end), true))
                i = end
            } else {
                val cp = text.codePointAt(i)
                plain.appendCodePoint(cp)
                i += Character.charCount(cp)
            }
        }
        if (plain.isNotEmpty()) out.add(Seg(plain.toString(), false))
        return out
    }

    /** Emoji clusters of [text], in order. */
    fun emojis(text: String): List<String> = segments(text).filter { it.emoji }.map { it.text }

    /**
     * When the message is nothing but 1..[max] emoji (spaces allowed) returns
     * them, so the chat can show them big like Telegram. Otherwise null.
     */
    fun onlyEmoji(text: String?, max: Int = 3): List<String>? {
        if (text.isNullOrBlank()) return null
        val segs = segments(text.trim())
        if (segs.any { !it.emoji && it.text.isNotBlank() }) return null
        val e = segs.filter { it.emoji }.map { it.text }
        return if (e.size in 1..max) e else null
    }

    /** Resource name of the 3D render: ic3d_1f525. Skips U+FE0F and U+200D. */
    fun assetName(emoji: String): String {
        val sb = StringBuilder("ic3d")
        var i = 0
        while (i < emoji.length) {
            val cp = emoji.codePointAt(i)
            i += Character.charCount(cp)
            if (cp == 0xFE0F || cp == 0x200D) continue
            sb.append('_').append(Integer.toHexString(cp))
        }
        return sb.toString()
    }
}
