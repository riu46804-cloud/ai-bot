package ir.studying.app.core

/**
 * Small pure helpers behind the flashcard screens, kept apart from Compose so
 * they can be unit tested on the JVM.
 */
object FlashcardLogic {

    /** Where a card sits in the learning curve. The server marks 21+ day intervals as mastered. */
    enum class Bucket { NEW, LEARNING, REVIEW, MASTERED }

    const val MASTERED_DAYS = 21

    fun bucket(state: String, intervalDays: Int): Bucket = when (state) {
        "learning" -> Bucket.LEARNING
        "review" -> if (intervalDays >= MASTERED_DAYS) Bucket.MASTERED else Bucket.REVIEW
        else -> Bucket.NEW
    }

    /* ---------------- multiple choice ---------------- */

    /** Options to the stored `extra` format: one per line, `*` marks the right answer. */
    fun mcqExtra(options: List<Pair<String, Boolean>>): String =
        options.map { it.first.replace('\n', ' ').trim() to it.second }
            .filter { it.first.isNotEmpty() }
            .joinToString("\n") { (text, ok) -> if (ok) "*$text" else text }

    fun mcqOptions(extra: String): List<Pair<String, Boolean>> =
        extra.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            .map { if (it.startsWith("*")) it.removePrefix("*").trim() to true else it to false }

    /** At least two filled options and one of them marked right. */
    fun mcqValid(options: List<Pair<String, Boolean>>): Boolean {
        val filled = options.filter { it.first.isNotBlank() }
        return filled.size >= 2 && filled.any { it.second }
    }

    /* ---------------- cloze ---------------- */

    // Escape both closing braces: Android ICU rejects bare closing braces.
    private val clozeRx = Regex("\\{\\{(.+?)\\}\\}")

    fun clozeCount(text: String): Int = clozeRx.findAll(text).count()

    /** The text split into plain runs and hidden runs (second = true). */
    fun clozeParts(text: String): List<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>()
        var last = 0
        clozeRx.findAll(text).forEach { m ->
            if (m.range.first > last) out.add(text.substring(last, m.range.first) to false)
            out.add(m.groupValues[1] to true)
            last = m.range.last + 1
        }
        if (last < text.length) out.add(text.substring(last) to false)
        return out
    }

    /**
     * Toggles a `{{ }}` blank around the selection. With a bare cursor the word
     * under it is used; a selection that is already a blank is unwrapped.
     * Returns the new text and the new cursor position.
     */
    fun wrapCloze(text: String, selStart: Int, selEnd: Int): Pair<String, Int> {
        var s = minOf(selStart, selEnd).coerceIn(0, text.length)
        var e = maxOf(selStart, selEnd).coerceIn(0, text.length)
        // Already inside a blank: unwrap it.
        val open = text.lastIndexOf("{{", s)
        val close = text.indexOf("}}", e.coerceAtLeast(s))
        if (open >= 0 && close >= 0 && open + 2 <= s) {
            val between = text.substring(open + 2, close)
            val inner = open + 2 <= s && e <= close && !between.contains("{{") && !between.contains("}}")
            if (inner) {
                val t = text.substring(0, open) + between + text.substring(close + 2)
                return t to (close - 2).coerceIn(0, t.length)
            }
        }
        if (s == e) {
            while (s > 0 && !text[s - 1].isWhitespace()) s--
            while (e < text.length && !text[e].isWhitespace()) e++
        }
        while (s < e && text[s].isWhitespace()) s++
        while (e > s && text[e - 1].isWhitespace()) e--
        if (s == e) {
            val t = text.substring(0, s) + "{{}}" + text.substring(s)
            return t to s + 2
        }
        val sel = text.substring(s, e)
        if (sel.length >= 4 && sel.startsWith("{{") && sel.endsWith("}}")) {
            val t = text.substring(0, s) + sel.substring(2, sel.length - 2) + text.substring(e)
            return t to e - 4
        }
        val t = text.substring(0, s) + "{{" + sel + "}}" + text.substring(e)
        return t to e + 4
    }

    /* ---------------- stats ---------------- */

    /** Consecutive review days ending today, or yesterday while today is still open. */
    fun streak(history: List<Pair<String, Int>>, today: String): Int {
        val days = history.filter { it.second > 0 }.map { it.first }.toHashSet()
        var cursor = when {
            today in days -> today
            ReportStats.shift(today, -1) in days -> ReportStats.shift(today, -1)
            else -> return 0
        }
        var n = 0
        while (cursor in days) {
            n++
            cursor = ReportStats.shift(cursor, -1)
        }
        return n
    }

    /** The next [days] days starting today; overdue cards are folded into today. */
    fun forecast(forecast: List<Pair<String, Int>>, today: String, days: Int): List<Pair<String, Int>> {
        val byDay = HashMap<String, Int>()
        forecast.forEach { (iso, count) ->
            val key = if (iso < today) today else iso
            byDay[key] = (byDay[key] ?: 0) + count
        }
        return (0 until days).map { i -> ReportStats.shift(today, i).let { it to (byDay[it] ?: 0) } }
    }

    /** Cards that were due before [today] and are still waiting. */
    fun overdue(forecast: List<Pair<String, Int>>, today: String): Int =
        forecast.filter { it.first < today }.sumOf { it.second.coerceAtLeast(0) }

    /** The collection split into the four buckets of the stats screen. */
    data class Breakdown(val fresh: Int, val learning: Int, val review: Int, val mastered: Int) {
        val total: Int get() = fresh + learning + review + mastered
        fun percent(part: Int): Int = if (total <= 0) 0 else ((part * 100f) / total + 0.5f).toInt().coerceIn(0, 100)
        fun share(part: Int): Float = if (total <= 0) 0f else (part.toFloat() / total).coerceIn(0f, 1f)
    }

    /**
     * [states] counts review rows per state, [mastered] the rows with a 21+ day
     * interval (a subset of "review") and [unseen] the cards that have no review
     * row yet, which the server reports per deck as "new".
     */
    fun breakdown(states: Map<String, Int>, mastered: Int, unseen: Int): Breakdown {
        val review = (states["review"] ?: 0).coerceAtLeast(0)
        val m = mastered.coerceIn(0, review)
        return Breakdown(
            fresh = (states["new"] ?: 0).coerceAtLeast(0) + unseen.coerceAtLeast(0),
            learning = (states["learning"] ?: 0).coerceAtLeast(0),
            review = review - m,
            mastered = m,
        )
    }

    /** Totals over the review history (date, cards, seconds). */
    data class HistorySummary(
        val cards: Int,
        val seconds: Int,
        val activeDays: Int,
        val bestDay: String?,
        val bestCards: Int,
    ) {
        val minutes: Int get() = (seconds + 30) / 60
        val perActiveDay: Int get() = if (activeDays <= 0) 0 else (cards + activeDays / 2) / activeDays
        val secondsPerCard: Int get() = if (cards <= 0) 0 else (seconds + cards / 2) / cards
    }

    fun summarize(history: List<Triple<String, Int, Int>>): HistorySummary {
        var cards = 0
        var seconds = 0
        var active = 0
        var bestDay: String? = null
        var best = 0
        history.forEach { (day, c, sec) ->
            val n = c.coerceAtLeast(0)
            cards += n
            seconds += sec.coerceAtLeast(0)
            if (n > 0) active++
            if (n > best) { best = n; bestDay = day }
        }
        return HistorySummary(cards, seconds, active, bestDay, best)
    }

    /** Share of graded cards the user remembered, as a whole percent. */
    fun accuracy(graded: Int, forgotten: Int): Int =
        if (graded <= 0) 0 else (((graded - forgotten).coerceAtLeast(0) * 100f) / graded).toInt().coerceIn(0, 100)
}
