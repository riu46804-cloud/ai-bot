package ir.studying.app.core

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Flashcards client.
 *
 * Two decisions shape this file. First, grading a card never blocks on the
 * network: a review is written to a local queue and flushed later, because the
 * whole point of spaced repetition is a fast rhythm and a spinner between every
 * card destroys it. Second, the server owns the SM-2 schedule, so the app never
 * computes a due date itself and the two can never disagree.
 */
object Flashcards {

    data class Deck(
        val id: Int,
        val name: String,
        val icon: String = "",
        val color: String = "",
        val description: String = "",
        val total: Int = 0,
        val due: Int = 0,
        val fresh: Int = 0,
        val mastered: Int = 0,
        val shareCode: String = "",
        val owner: Boolean = true,
    ) {
        /** Everything seen at least once and not buried in the new pile. */
        val progress: Float get() = if (total <= 0) 0f else (mastered.toFloat() / total).coerceIn(0f, 1f)
    }

    data class Card(
        val id: Int,
        val deckId: Int,
        val type: String = "basic",
        val front: String = "",
        val back: String = "",
        val extra: String = "",
        val image: String = "",
        val audio: String = "",
        val position: Int = 0,
        val state: String = "new",
        val intervalDays: Int = 0,
    ) {
        /** Multiple choice options live in `extra`, one per line, `*` marks the answer. */
        val choices: List<Pair<String, Boolean>>
            get() = if (type != "mcq") emptyList() else extra.split("\n")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { if (it.startsWith("*")) it.removePrefix("*").trim() to true else it to false }
    }

    data class Stats(
        val states: Map<String, Int> = emptyMap(),
        val forecast: List<Pair<String, Int>> = emptyList(),
        val history: List<Triple<String, Int, Int>> = emptyList(),
        val mastered: Int = 0,
    )

    data class Preview(
        val name: String,
        val icon: String,
        val color: String,
        val description: String,
        val ownerName: String,
        val total: Int,
        val shareCode: String,
    )

    private val _decks = MutableStateFlow<List<Deck>>(emptyList())
    val decks: StateFlow<List<Deck>> = _decks.asStateFlow()

    private val _dueTotal = MutableStateFlow(0)
    val dueTotal: StateFlow<Int> = _dueTotal.asStateFlow()

    private val _pendingSync = MutableStateFlow(0)
    val pendingSync: StateFlow<Int> = _pendingSync.asStateFlow()

    private var queueFile: File? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(ctx: Context) {
        queueFile = File(ctx.filesDir, "fc_queue.json")
        _pendingSync.value = readQueue().length()
        scope.launch { runCatching { flush() } }
    }

    /* ---------------- decks ---------------- */

    private fun deckOf(o: JSONObject) = Deck(
        id = o.int("id"),
        name = o.str("name"),
        icon = o.str("icon"),
        color = o.str("color"),
        description = o.str("description"),
        total = o.int("total"),
        due = o.int("due"),
        fresh = o.int("new"),
        mastered = o.int("mastered"),
        shareCode = o.str("share_code"),
        owner = o.int("owner") == 1,
    )

    private fun cardOf(o: JSONObject) = Card(
        id = o.int("id"),
        deckId = o.int("deck_id"),
        type = o.str("type").ifBlank { "basic" },
        front = o.str("front"),
        back = o.str("back"),
        extra = o.str("extra"),
        image = o.str("image"),
        audio = o.str("audio"),
        position = o.int("position"),
        state = o.str("state").ifBlank { "new" },
        intervalDays = o.int("interval_days"),
    )

    suspend fun loadDecks(): List<Deck> {
        val o = Api.obj(Api.get("fc_decks"))
        val list = (o.optJSONArray("decks") ?: JSONArray()).objects().map { deckOf(it) }
        _decks.value = list
        _dueTotal.value = o.int("due_total")
        return list
    }

    suspend fun saveDeck(
        id: Int = 0,
        name: String,
        icon: String = "",
        color: String = "",
        description: String = "",
    ): Deck {
        val b = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("icon", icon)
            .put("color", color)
            .put("description", description)
        val deck = deckOf(Api.obj(Api.post("fc_deck_save", b)).getJSONObject("deck"))
        loadDecks()
        return deck
    }

    suspend fun deleteDeck(id: Int) {
        Api.post("fc_deck_delete", JSONObject().put("id", id))
        _decks.value = _decks.value.filterNot { it.id == id }
    }

    /* ---------------- cards ---------------- */

    suspend fun cards(deckId: Int): List<Card> {
        val o = Api.obj(Api.get("fc_cards", "deck_id" to deckId.toString()))
        return (o.optJSONArray("cards") ?: JSONArray()).objects().map { cardOf(it) }
    }

    suspend fun saveCard(card: Card): Card? {
        val b = JSONObject()
            .put("deck_id", card.deckId)
            .put("id", card.id)
            .put("type", card.type)
            .put("front", card.front)
            .put("back", card.back)
            .put("extra", card.extra)
            .put("image", card.image)
            .put("audio", card.audio)
            .put("position", card.position)
        val arr = Api.obj(Api.post("fc_card_save", b)).optJSONArray("cards") ?: JSONArray()
        return arr.objects().firstOrNull()?.let { cardOf(it) }
    }

    suspend fun deleteCard(id: Int) {
        Api.post("fc_card_delete", JSONObject().put("id", id))
    }

    /**
     * Delete that keeps running after the screen is gone, for the undo
     * snackbar: the commit fires when the bar times out, which may be after
     * the user has already navigated away.
     */
    fun deleteCardInBackground(id: Int, onDone: (Throwable?) -> Unit = {}) {
        scope.launch {
            val r = runCatching { deleteCard(id) }
            if (r.isSuccess) runCatching { loadDecks() }
            withContext(Dispatchers.Main) { onDone(r.exceptionOrNull()) }
        }
    }

    /** Due cards first, then a capped slice of never seen cards. */
    suspend fun due(deckId: Int = 0, limit: Int = 60, newLimit: Int = 20): List<Card> {
        val q = mutableListOf("limit" to limit.toString(), "new_limit" to newLimit.toString())
        if (deckId > 0) q.add("deck_id" to deckId.toString())
        val o = Api.obj(Api.get("fc_due", *q.toTypedArray()))
        val due = (o.optJSONArray("due") ?: JSONArray()).objects().map { cardOf(it) }
        val fresh = (o.optJSONArray("new") ?: JSONArray()).objects().map { cardOf(it) }
        return due + fresh
    }

    /* ---------------- reviewing ---------------- */

    /**
     * Records a grade. Always succeeds locally; the network is best effort.
     * quality: 0 again, 1 hard, 2 good, 3 easy.
     */
    suspend fun review(cardId: Int, quality: Int, seconds: Int) {
        val item = JSONObject()
            .put("card_id", cardId)
            .put("quality", quality.coerceIn(0, 3))
            .put("seconds", seconds.coerceIn(0, 600))
            .put("day", IranTime.todayIso())
        val q = readQueue()
        q.put(item)
        writeQueue(q)
        runCatching { flush() }
    }

    /** Sends every queued review in one request, then clears the queue. */
    suspend fun flush() {
        val q = readQueue()
        if (q.length() == 0) return
        Api.post("fc_review", JSONObject().put("reviews", q))
        writeQueue(JSONArray())
        runCatching { loadDecks() }
    }

    private fun readQueue(): JSONArray {
        val f = queueFile ?: return JSONArray()
        if (!f.exists()) return JSONArray()
        return runCatching { JSONArray(f.readText()) }.getOrDefault(JSONArray())
    }

    private fun writeQueue(a: JSONArray) {
        _pendingSync.value = a.length()
        val f = queueFile ?: return
        runCatching { f.writeText(a.toString()) }
    }

    /* ---------------- stats, sharing, media ---------------- */

    suspend fun stats(deckId: Int = 0): Stats {
        val o = if (deckId > 0) {
            Api.obj(Api.get("fc_stats", "deck_id" to deckId.toString()))
        } else {
            Api.obj(Api.get("fc_stats"))
        }
        val states = HashMap<String, Int>()
        o.optJSONObject("states")?.let { s ->
            val keys = s.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                states[k] = s.optInt(k, 0)
            }
        }
        return Stats(
            states = states,
            forecast = (o.optJSONArray("forecast") ?: JSONArray()).objects()
                .map { it.str("date") to it.int("count") },
            history = (o.optJSONArray("history") ?: JSONArray()).objects()
                .map { Triple(it.str("date"), it.int("cards"), it.int("seconds")) },
            mastered = o.int("mastered"),
        )
    }

    suspend fun share(deckId: Int): String =
        Api.obj(Api.post("fc_share", JSONObject().put("deck_id", deckId))).str("share_code")

    suspend fun preview(code: String): Preview {
        val d = Api.obj(Api.get("fc_preview", "code" to code.uppercase())).getJSONObject("deck")
        return Preview(
            name = d.str("name"),
            icon = d.str("icon"),
            color = d.str("color"),
            description = d.str("description"),
            ownerName = d.str("owner_name"),
            total = d.int("total"),
            shareCode = d.str("share_code"),
        )
    }

    suspend fun import(code: String): Deck {
        val o = Api.obj(Api.post("fc_import", JSONObject().put("code", code.uppercase())))
        val deck = deckOf(o.getJSONObject("deck"))
        loadDecks()
        return deck
    }

    /** Returns the deck name and a CSV body ready to be written to a file. */
    suspend fun export(deckId: Int): Pair<String, String> {
        val o = Api.obj(Api.get("fc_export", "deck_id" to deckId.toString()))
        return o.str("name") to o.str("csv")
    }

    suspend fun uploadImage(bytes: ByteArray, fileName: String, mime: String): String =
        withContext(Dispatchers.IO) {
            val part = Api.FilePart("image", fileName, bytes, mime)
            Api.obj(Api.upload("fc_image", emptyMap(), listOf(part))).str("image")
        }

    suspend fun uploadAudio(file: File): String = withContext(Dispatchers.IO) {
        val part = Api.FilePart("audio", file.name, file.readBytes(), "audio/mp4")
        Api.obj(Api.upload("fc_audio", emptyMap(), listOf(part))).str("audio")
    }

    /**
     * Parses a pasted CSV or a simple "front,back" list into unsaved cards.
     * Anki exports and hand written lists both land here, so the separator is
     * detected per line rather than assumed.
     */
    fun parseCsv(text: String, deckId: Int): List<Card> {
        val out = mutableListOf<Card>()
        text.lineSequence().forEachIndexed { i, raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEachIndexed
            if (i == 0 && line.startsWith("type,front")) return@forEachIndexed
            val sep = when {
                line.contains('\t') -> '\t'
                line.contains(';') -> ';'
                else -> ','
            }
            val cells = splitCsvLine(line, sep)
            if (cells.size >= 4 && cells[0] in listOf("basic", "mcq", "cloze", "image", "audio")) {
                out.add(Card(0, deckId, cells[0], cells[1], cells[2], cells[3], position = out.size))
            } else if (cells.size >= 2) {
                out.add(Card(0, deckId, "basic", cells[0], cells[1], position = out.size))
            }
        }
        return out
    }

    private fun splitCsvLine(line: String, sep: Char): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == sep && !quoted -> { out.add(sb.toString().trim()); sb.clear() }
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString().trim())
        return out
    }
}
