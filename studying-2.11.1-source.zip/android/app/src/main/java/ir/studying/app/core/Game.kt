package ir.studying.app.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

/**
 * امتیاز سراسری کاربر (XP)، سکه‌ها و احیای استریک.
 *
 * همه‌چیز روی سرور حساب و ذخیره می‌شود تا رقابت بین کاربران معنا داشته باشد و
 * سکه‌ها با پاک‌کردن اپ یا عوض‌کردن گوشی از بین نروند.
 */
object Game {

    data class State(
        val xp: Int = 0,
        val level: Int = 1,
        val levelTitle: String = "",
        /* لقب اسطوره‌ای: از سرور می‌آید و اگر نیامد از [Ranks] خوانده می‌شود. */
        val levelEmoji: String = "",
        val levelKey: String = "",
        val levelRank: Int = 0,
        val levelRankCount: Int = 0,
        val nextTitle: String = "",
        val nextTitleLevel: Int = 0,
        val levelStartXp: Int = 0,
        val nextLevelXp: Int = 100,
        val coins: Int = 0,
        val spent: Int = 0,
        val streak: Int = 0,
        val bestStreak: Int = 0,
        val rank: Int = 0,
        val owned: Set<String> = emptySet(),
        /** روزهای جامانده‌ای که با سکه می‌شود احیا کرد (تازه‌ترین اول). */
        val missedDays: List<String> = emptyList(),
        val reviveCost: Int = 300,
        val todayMinutes: Int = 0,
        /* دستاوردها: سهم امتیازِ کارهای معنادار + تازه‌ترین‌هایشان. */
        val awardXp: Int = 0,
        val awards: List<Awards.Award> = emptyList(),
        /** هدف روزانهٔ ذخیره‌شده روی سرور (۰ یعنی تعیین‌نشده). */
        val goalDaily: Int = 0,
        val goalWeekly: Int = 0,
        val goalReached: Boolean = false,
        val loaded: Boolean = false,
    ) {
        val levelProgress: Float
            get() {
                val span = (nextLevelXp - levelStartXp).coerceAtLeast(1)
                return ((xp - levelStartXp).toFloat() / span).coerceIn(0f, 1f)
            }

        /* --- لقب: همیشه یک مقدار درست، حتی با سرور قدیمی یا حالت آفلاین --- */

        val rankTitle: String get() = Ranks.titleFor(level, levelTitle)
        val rankEmoji: String get() = Ranks.emojiFor(level, levelEmoji)
        val rankIndex: Int get() = if (levelRank > 0) levelRank else Ranks.rankIndex(level)
        val rankCount: Int get() = if (levelRankCount > 0) levelRankCount else Ranks.count
        val nextRankTitle: String get() = nextTitle.ifBlank { Ranks.next(level)?.title ?: "" }
        val nextRankLevel: Int get() = if (nextTitleLevel > 0) nextTitleLevel else (Ranks.next(level)?.minLevel ?: 0)
    }

    private val stateLock = Any()
    // A refresh started before a purchase/revive/logout must not overwrite it.
    private var mutationVersion = 0L
    private val _state = MutableStateFlow(State())

    private fun applyMutation(state: State) = synchronized(stateLock) {
        mutationVersion++
        _state.value = state
    }
    val state: StateFlow<State> get() = _state

    data class TopRow(
        val rank: Int,
        val username: String,
        val xp: Int,
        val level: Int,
        val isMe: Boolean,
        val levelTitle: String = "",
        val levelEmoji: String = "",
    ) {
        val rankTitle: String get() = Ranks.titleFor(level, levelTitle)
        val rankEmoji: String get() = Ranks.emojiFor(level, levelEmoji)
    }

    private fun parse(o: JSONObject): State = State(
        xp = o.optInt("xp"),
        level = o.optInt("level", 1),
        levelTitle = o.optString("level_title", ""),
        levelEmoji = o.optString("level_emoji", ""),
        levelKey = o.optString("level_key", ""),
        levelRank = o.optInt("level_rank"),
        levelRankCount = o.optInt("level_rank_count"),
        nextTitle = o.optString("next_title", ""),
        nextTitleLevel = o.optInt("next_title_level"),
        levelStartXp = o.optInt("level_start_xp"),
        nextLevelXp = o.optInt("next_level_xp", 100),
        coins = o.optInt("coins"),
        spent = o.optInt("coins_spent"),
        streak = o.optInt("streak"),
        bestStreak = o.optInt("best_streak"),
        rank = o.optInt("rank"),
        owned = o.optJSONArray("owned")?.let { a ->
            (0 until a.length()).mapNotNull { a.optString(it).takeIf { s -> s.isNotBlank() } }.toSet()
        } ?: emptySet(),
        missedDays = o.optJSONArray("missed_days")?.let { a ->
            (0 until a.length()).mapNotNull { a.optString(it).takeIf { s -> s.isNotBlank() } }
        } ?: emptyList(),
        reviveCost = o.optInt("revive_cost", 300),
        todayMinutes = o.optInt("today_minutes"),
        awardXp = o.optInt("award_xp"),
        awards = Awards.from(o),
        goalDaily = o.optJSONObject("goal")?.optInt("daily") ?: 0,
        goalWeekly = o.optJSONObject("goal")?.optInt("weekly") ?: 0,
        goalReached = (o.optJSONObject("goal")?.optInt("reached") ?: 0) == 1,
        loaded = true,
    )

    /** وضعیت را از سرور می‌گیرد. خطا را قورت می‌دهد؛ صفحه‌ها باید بی‌خطا بمانند. */
    suspend fun refresh(): Boolean = runCatching {
        val version = synchronized(stateLock) { mutationVersion }
        val o = Api.obj(Api.get("game_state"))
        val s = parse(o)
        synchronized(stateLock) {
            if (version == mutationVersion) {
                _state.value = s
                Goals.applyServer(s.goalDaily, s.goalWeekly)
            }
        }
        true
    }.getOrDefault(false)

    /**
     * وضعیتی که سرور همراه پاسخ یک کار فرستاده (مثلاً جایزهٔ بازی اتاق سه‌بعدی).
     * پاسخ ناقص یا خالی نادیده گرفته می‌شود تا سکه‌ها صفر نشوند.
     */
    fun applyServerState(o: JSONObject) {
        if (!o.has("coins") || !o.has("xp")) return
        applyMutation(parse(o))
    }

    /** خرید وسیله با سکهٔ سراسری. پیام خطا را برمی‌گرداند؛ null یعنی موفق. */
    suspend fun buy(itemKey: String, cost: Int): String? = try {
        val o = Api.obj(Api.post("game_buy", JSONObject().put("item", itemKey).put("cost", cost)))
        if (o.optBoolean("success")) { applyMutation(parse(o.optJSONObject("state") ?: JSONObject())); null }
        else o.optString("error").ifBlank { "خرید انجام نشد" }
    } catch (e: Exception) { humanizeError(e) }

    /** احیای استریکِ پریده با سکه. */
    suspend fun revive(day: String): String? = try {
        val o = Api.obj(Api.post("streak_revive", JSONObject().put("day", day)))
        if (o.optBoolean("success")) { applyMutation(parse(o.optJSONObject("state") ?: JSONObject())); null }
        else o.optString("error").ifBlank { "احیا انجام نشد" }
    } catch (e: Exception) { humanizeError(e) }

    data class GiftResult(
        val granted: Int = 0,
        val alreadyRedeemed: Boolean = false,
        val previousGrant: Int = 0,
        val error: String? = null,
    )

    /** Server-authoritative reward and wallet. A retry never adds local coins. */
    internal fun acceptGiftResponse(o: JSONObject): GiftResult {
        if (!o.optBoolean("success")) return GiftResult(error = o.optString("error").ifBlank { "دریافت هدیه انجام نشد" })
        val wallet = o.optJSONObject("state") ?: return GiftResult(error = "پاسخ سرور کامل نبود؛ دوباره همین کد را وارد کنید.")
        applyMutation(parse(wallet))
        return GiftResult(
            granted = o.optInt("granted").coerceAtLeast(0),
            alreadyRedeemed = o.optBoolean("already_redeemed"),
            previousGrant = o.optInt("previous_grant").coerceAtLeast(0),
        )
    }

    suspend fun redeemGift(rawCode: String): GiftResult {
        val code = GiftCodeInput.normalize(rawCode) ?: return GiftResult(error = GiftCodeInput.ERROR)
        val session = Store.session.value
        return try {
            val o = Api.obj(Api.postForSession("gift_redeem", JSONObject().put("code", code), session))
            if (Store.session.value != session) throw kotlinx.coroutines.CancellationException("Account changed")
            acceptGiftResponse(o)
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { GiftResult(error = humanizeError(e)) }
    }

    /** جدول رقابت امتیاز. */
    suspend fun top(): List<TopRow> = runCatching {
        val a = Api.arr(Api.get("score_top"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            TopRow(
                rank = o.optInt("rank"),
                username = o.optString("username"),
                xp = o.optInt("xp"),
                level = o.optInt("level", 1),
                isMe = o.optInt("is_me") == 1,
                levelTitle = o.optString("level_title", ""),
                levelEmoji = o.optString("level_emoji", ""),
            )
        }
    }.getOrDefault(emptyList())

    fun clear() { applyMutation(State()) }
}
