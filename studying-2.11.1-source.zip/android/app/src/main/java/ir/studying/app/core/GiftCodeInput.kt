package ir.studying.app.core

import java.util.Locale

/** Codes are server-managed ASCII identifiers, never client-side rewards. */
object GiftCodeInput {
    const val ERROR = "کد باید ۳ تا ۶۴ حرف یا عدد انگلیسی باشد؛ خط تیره و زیرخط هم مجازند."
    private val pattern = Regex("^[a-z0-9][a-z0-9_-]{2,63}$")
    fun normalize(raw: String): String? {
        // Match PHP trim's accepted edge whitespace; never strip characters
        // from the middle or turn an invalid code into a different campaign.
        val code = raw.trim { it == ' ' || it == '\t' || it == '\n' || it == '\r' || it == '\u0000' || it == '\u000B' }
            .lowercase(Locale.ROOT)
        return code.takeIf { pattern.matches(it) }
    }
}
