package ir.studying.app.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Daily and weekly study targets.
 *
 * The app could tell you how long you studied but never what you were aiming
 * for, so a good day and a bad day looked identical. A target turns the same
 * numbers into feedback: today's minutes mean something only next to the number
 * the user chose in the morning.
 *
 * Targets are a personal setting, not server state, so they live on the device
 * and never block on the network.
 */
object Goals {
    private const val KEY_DAILY = "goal_daily_minutes"
    private const val KEY_WEEKLY = "goal_weekly_minutes"
    private const val KEY_SNAPSHOT = "widget_snapshot"

    /**
     * هیچ هدفِ پیش‌فرضی وجود ندارد.
     *
     * قبلاً دو ساعت به‌زور روی همه گذاشته می‌شد و همین باعث می‌شد اپ از طرف
     * کاربر حرف بزند: کارت «هدف امروز» عددی نشان می‌داد که کاربر انتخابش نکرده
     * بود و پست خودکار هم بر اساس همان عدد ساختگی ساخته می‌شد.
     *
     * پس حالا «۰» یعنی تنظیم‌نشده؛ [UNSET] هم همین را خوانا می‌کند. این عددها
     * فقط پیشنهادِ اولیهٔ صفحهٔ انتخاب هستند، نه مقدار واقعی.
     */
    const val UNSET = 0
    const val SUGGESTED_DAILY = 120
    const val SUGGESTED_WEEKLY = 720

    /**
     * Editable range. The ceiling is 14 hours a day because that is what a
     * student in exam season actually asks for, and 98 hours a week is simply
     * that same ceiling seven times over.
     *
     * Steps exist so the slider lands on round numbers: nobody means to pick a
     * target of 3h 07m.
     */
    const val MIN_DAILY = 15
    const val MAX_DAILY = 14 * 60
    const val STEP_DAILY = 15

    const val MIN_WEEKLY = 60
    const val MAX_WEEKLY = 14 * 7 * 60
    const val STEP_WEEKLY = 30

    /** Number of discrete stops between min and max, for slider `steps`. */
    fun stepCount(min: Int, max: Int, step: Int): Int =
        ((max - min) / step - 1).coerceAtLeast(0)

    /** Snap a raw slider value onto the nearest legal step. */
    fun snap(minutes: Int, min: Int, max: Int, step: Int): Int {
        val clamped = minutes.coerceIn(min, max)
        val rounded = ((clamped - min).toFloat() / step).toInt() * step + min
        return rounded.coerceIn(min, max)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _daily = MutableStateFlow(UNSET)

    /** دقیقهٔ هدف روزانه، یا [UNSET] اگر کاربر هنوز خودش انتخاب نکرده. */
    val daily: StateFlow<Int> get() = _daily

    private val _weekly = MutableStateFlow(UNSET)
    val weekly: StateFlow<Int> get() = _weekly

    /** آیا کاربر هدف روزانه را خودش تعیین کرده؟ */
    val isDailySet: Boolean get() = _daily.value > 0

    suspend fun load() {
        _daily.value = Store.getString(KEY_DAILY)?.toIntOrNull()?.takeIf { it > 0 } ?: UNSET
        _weekly.value = Store.getString(KEY_WEEKLY)?.toIntOrNull()?.takeIf { it > 0 } ?: UNSET
    }

    fun init() {
        scope.launch {
            load()
            /* بعد از خواندن مقدار محلی، سرور را هم چک می‌کنیم (نصب تازه). */
            if (!Store.token.isNullOrBlank()) pull()
        }
    }

    /**
     * هدف روزانه را تعیین می‌کند. هدف هفتگی هم اگر دست‌نخورده باشد، هم‌راستا
     * می‌شود تا کاربر مجبور نباشد دو جا یک چیز را بچیند (شش روز کاری در هفته).
     */
    fun setDaily(minutes: Int) {
        val v = minutes.coerceIn(MIN_DAILY, MAX_DAILY)
        _daily.value = v
        scope.launch { Store.putString(KEY_DAILY, v.toString()) }
        if (_weekly.value <= 0) setWeekly(snap(v * 6, MIN_WEEKLY, MAX_WEEKLY, STEP_WEEKLY))
        push()
    }

    fun setWeekly(minutes: Int) {
        val v = minutes.coerceIn(MIN_WEEKLY, MAX_WEEKLY)
        _weekly.value = v
        scope.launch { Store.putString(KEY_WEEKLY, v.toString()) }
        push()
    }

    /* ===================== همگام‌سازی با سرور =====================
     *
     * هدف قبلاً فقط روی گوشی بود، پس با پاک‌کردن اپ یا عوض‌کردن گوشی از بین
     * می‌رفت و سرور هم نمی‌دانست کاربر دنبال چه عددی است (برای همین نمی‌شد
     * «رسیدن به هدف» را پاداش داد). حالا مقدار روی سرور هم ذخیره می‌شود.
     * دستگاه همیشه سریع و آفلاین کار می‌کند؛ شبکه فقط پشت صحنه است.
     */

    /** آخرین مقدار را روی سرور می‌نویسد. خطا مهم نیست؛ مقدار محلی سر جایش است. */
    fun push() {
        val d = _daily.value
        val w = _weekly.value
        if (d <= 0 && w <= 0) return
        scope.launch {
            runCatching {
                Api.post(
                    "goals",
                    org.json.JSONObject().put("daily", d).put("weekly", w),
                )
            }
        }
    }

    /**
     * هدف را از سرور می‌خواند. اگر سرور عددی داشت، همان مرجع است (نصب تازه
     * این‌طور هدفش را پس می‌گیرد)؛ اگر نداشت، هدف محلی برایش فرستاده می‌شود.
     */
    suspend fun pull() {
        val o = runCatching { Api.obj(Api.get("goals")) }.getOrNull() ?: return
        val g = o.optJSONObject("goal") ?: return
        val d = g.optInt("daily")
        val w = g.optInt("weekly")
        if (d > 0) {
            _daily.value = d.coerceIn(MIN_DAILY, MAX_DAILY)
            Store.putString(KEY_DAILY, _daily.value.toString())
            if (w > 0) {
                _weekly.value = w.coerceIn(MIN_WEEKLY, MAX_WEEKLY)
                Store.putString(KEY_WEEKLY, _weekly.value.toString())
            }
        } else if (_daily.value > 0) {
            push()
        }
    }

    /** مقداری که سرور در پاسخ‌های دیگر (مثلاً game_state) می‌فرستد. */
    fun applyServer(daily: Int, weekly: Int) {
        if (daily <= 0) return
        if (daily == _daily.value && (weekly <= 0 || weekly == _weekly.value)) return
        _daily.value = daily.coerceIn(MIN_DAILY, MAX_DAILY)
        if (weekly > 0) _weekly.value = weekly.coerceIn(MIN_WEEKLY, MAX_WEEKLY)
        scope.launch {
            Store.putString(KEY_DAILY, _daily.value.toString())
            Store.putString(KEY_WEEKLY, _weekly.value.toString())
        }
    }

    /**
     * Progress as 0f..1f. Kept pure and free of Android types so the arithmetic
     * that drives every progress ring in the app is unit-testable.
     */
    fun progress(done: Int, goal: Int): Float {
        if (goal <= 0) return 0f
        if (done <= 0) return 0f
        return (done.toFloat() / goal.toFloat()).coerceAtMost(1f)
    }

    /** Minutes still to go, never negative. */
    fun remaining(done: Int, goal: Int): Int = (goal - done).coerceAtLeast(0)

    /** Short Persian label for a target, e.g. "2h 30m". */
    fun label(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> h.toString() + "h " + m + "m"
            h > 0 -> h.toString() + "h"
            else -> m.toString() + "m"
        }
    }

    /**
     * The home-screen widget lives in the launcher's process and cannot call the
     * API, so whichever screen last talked to the server leaves the numbers here
     * for it to read.
     */
    fun saveSnapshot(todayMinutes: Int, streak: Int, owner: String? = Store.username, day: String = IranTime.todayIso()) {
        scope.launch {
            Cache.put(KEY_SNAPSHOT, todayMinutes.toString() + "|" + streak + "|" + _daily.value, owner, day)
        }
    }

    data class Snapshot(val todayMinutes: Int, val streak: Int, val dailyGoal: Int)

    suspend fun snapshot(): Snapshot {
        val raw = Cache.get(KEY_SNAPSHOT) ?: return Snapshot(0, 0, _daily.value)
        val p = raw.split("|")
        return Snapshot(
            todayMinutes = p.getOrNull(0)?.toIntOrNull() ?: 0,
            streak = p.getOrNull(1)?.toIntOrNull() ?: 0,
            dailyGoal = p.getOrNull(2)?.toIntOrNull()?.takeIf { it > 0 } ?: UNSET,
        )
    }
}
