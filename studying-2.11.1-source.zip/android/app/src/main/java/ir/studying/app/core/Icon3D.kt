package ir.studying.app.core

import androidx.compose.ui.graphics.asImageBitmap
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.em

/*
 * 3D emoji layer, backed by Microsoft Fluent Emoji (MIT).
 *
 * The app never hard codes an R.drawable id. Renders are looked up by name at
 * runtime (and cached), so:
 *
 *   - the project compiles and runs with zero 3D assets present,
 *   - tools/fetch_3d_icons.py can add or drop renders with no code change,
 *   - a single missing render degrades to the phone's emoji glyph.
 *
 * Naming is derived from the emoji itself: fire is U+1F525, so the file is
 * res/drawable-nodpi/ic3d_1f525.webp. U+FE0F and U+200D are dropped since the
 * renders do not distinguish them. res/raw/keep_3d_emoji.xml keeps them alive
 * through resource shrinking, because nothing references them by id.
 */

/** ic3d_1f525 for the fire emoji. Skips U+FE0F and U+200D. */
internal fun icon3dName(emoji: String): String = EmojiParse.assetName(emoji)

/** Cached emoji -> drawable id lookups. getIdentifier is slow; a chat calls this a lot. */
object Emoji3D {
    private val cache = HashMap<String, Int>()

    fun resId(context: Context, emoji: String): Int {
        synchronized(cache) { cache[emoji]?.let { return it } }
        @Suppress("DiscouragedApi")
        val id = runCatching {
            context.resources.getIdentifier(icon3dName(emoji), "drawable", context.packageName)
        }.getOrDefault(0)
        synchronized(cache) { cache[emoji] = id }
        return id
    }

    fun has(context: Context, emoji: String): Boolean = resId(context, emoji) != 0
}

/**
 * Draws [emoji] as a 3D render when the asset exists, otherwise as the emoji
 * glyph at a matching optical size.
 */
@Composable
fun Icon3D(
    emoji: String,
    size: Dp,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
) {
    val context = LocalContext.current
    val resId = remember(emoji) { Emoji3D.resId(context, emoji) }
    if (resId != 0) {
        Image(
            painter = painterResource(resId),
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = modifier.size(size),
        )
    } else {
        // Fallback. 0.78 keeps the glyph inside the same box the render fills.
        Box(modifier.size(size), contentAlignment = Alignment.Center) {
            Text(
                text = emoji,
                style = LocalTextStyle.current.copy(
                    fontSize = TextUnit(size.value * 0.78f, TextUnitType.Sp),
                ),
            )
        }
    }
}

/** The 3D render as a bitmap for Canvas drawing; null when the pack lacks it. */
@Composable
fun rememberEmojiBitmap(emoji: String): androidx.compose.ui.graphics.ImageBitmap? {
    val context = LocalContext.current
    return remember(emoji) {
        val id = Emoji3D.resId(context, emoji)
        if (id == 0) null else runCatching {
            android.graphics.BitmapFactory.decodeResource(context.resources, id)
        }.getOrNull()?.asImageBitmap()
    }
}

/** True when the 3D pack has a render for this emoji. */
@Composable
fun hasIcon3D(emoji: String): Boolean {
    val context = LocalContext.current
    return remember(emoji) { Emoji3D.has(context, emoji) }
}

/**
 * Text that draws every emoji with the bundled 3D renders instead of the
 * phone's emoji font, so chats, reactions and the report look the same on
 * every device. Text without emoji takes the plain Text fast path.
 *
 * @param emojiScale size of an inline emoji relative to the font size.
 */
@Composable
fun EmojiText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
    emojiScale: Float = 1.18f,
    onTextLayout: (TextLayoutResult) -> Unit = {},
) {
    val context = LocalContext.current
    val built = remember(text) { buildEmojiText(context, text) }
    if (built == null) {
        Text(text, modifier, color = color, style = style, fontWeight = fontWeight, textAlign = textAlign,
            maxLines = maxLines, overflow = overflow, onTextLayout = onTextLayout)
        return
    }
    val (annotated, ids) = built
    val inline = remember(built, emojiScale) {
        ids.mapIndexed { i, resId ->
            "e$i" to InlineTextContent(
                Placeholder(emojiScale.em, emojiScale.em, PlaceholderVerticalAlign.TextCenter),
            ) {
                Image(painterResource(resId), contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize())
            }
        }.toMap()
    }
    Text(annotated, modifier, color = color, style = style, fontWeight = fontWeight, textAlign = textAlign,
        maxLines = maxLines, overflow = overflow, inlineContent = inline, onTextLayout = onTextLayout)
}

/** null when [text] has no emoji with a 3D render. */
private fun buildEmojiText(context: Context, text: String): Pair<AnnotatedString, List<Int>>? {
    if (text.isEmpty()) return null
    val segs = EmojiParse.segments(text)
    if (segs.none { it.emoji && Emoji3D.has(context, it.text) }) return null
    val ids = ArrayList<Int>()
    val annotated = buildAnnotatedString {
        for (s in segs) {
            val id = if (s.emoji) Emoji3D.resId(context, s.text) else 0
            if (id != 0) {
                appendInlineContent("e${ids.size}", s.text)
                ids.add(id)
            } else append(s.text)
        }
    }
    return annotated to ids
}
