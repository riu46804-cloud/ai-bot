package ir.studying.app.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Every "day" in this app is an Iranian calendar day.
 *
 * The server stores study_date with CURDATE() on a Tehran clock, so the client
 * has to agree with it. Using the device's own timezone silently broke the
 * end-of-day post for anyone travelling, anyone with a wrong clock, and every
 * emulator (which defaults to UTC): the summary was stamped with the wrong
 * date and the once-per-day guard then swallowed the real one.
 */
object IranTime {

    val ZONE: TimeZone = TimeZone.getTimeZone("Asia/Tehran")

    fun calendar(): Calendar = Calendar.getInstance(ZONE)

    private fun dateFormat(): SimpleDateFormat =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = ZONE; isLenient = false }

    /** Today in Tehran, as the yyyy-MM-dd the server would call CURDATE(). */
    fun todayIso(): String = dateFormat().format(Date())

    /** The Tehran date [daysAgo] days before today. */
    fun isoDaysAgo(daysAgo: Int): String {
        val c = calendar()
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return dateFormat().format(c.time)
    }

    /** Whole Tehran days between [dateIso] and today. 0 = today, 1 = yesterday. */
    fun daysAgoOf(dateIso: String): Int {
        if (!dateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return -1
        val parsed = runCatching { dateFormat().parse(dateIso) }.getOrNull() ?: return -1
        val a = calendar().apply { time = parsed; zeroTime() }
        val b = calendar().apply { zeroTime() }
        val diff = b.timeInMillis - a.timeInMillis
        return Math.round(diff / 86_400_000.0).toInt()
    }

    /** روزهای باقی‌مانده تا [dateIso]. منفی یعنی گذشته یا تاریخ نامعتبر. */
    fun daysUntil(dateIso: String): Int = -daysAgoOf(dateIso)

    /** Hour of day, 0..23, on a Tehran clock. */
    fun hour(): Int = calendar().get(Calendar.HOUR_OF_DAY)

    /**
     * The next epoch millisecond at which it is [hour]:[minute] in Tehran.
     * Always strictly in the future, so an alarm set to it never fires twice.
     */
    fun nextOccurrence(hour: Int, minute: Int): Long {
        val c = calendar()
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun Calendar.zeroTime() {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
}
