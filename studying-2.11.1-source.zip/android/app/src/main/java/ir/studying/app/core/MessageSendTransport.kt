package ir.studying.app.core

import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okio.BufferedSink

/** Without backend idempotency, an acknowledged/lost POST must not be replayed. */
internal object MessageSendTransport {
    fun applies(action: String, method: String): Boolean = method == "POST" &&
        action in setOf("dm_send", "chat", "group_chat")

    fun client(base: OkHttpClient): OkHttpClient = base.newBuilder()
        .retryOnConnectionFailure(false)
        .followRedirects(false)
        .followSslRedirects(false)
        .build()

    fun oneShot(body: RequestBody): RequestBody = object : RequestBody() {
        override fun contentType() = body.contentType()
        override fun contentLength() = body.contentLength()
        override fun writeTo(sink: BufferedSink) = body.writeTo(sink)
        override fun isOneShot() = true
    }
}
