package ir.studying.app.core

import android.app.Activity
import android.content.Context
import ir.myket.billingclient.IabHelper
import ir.myket.billingclient.util.IabResult
import ir.myket.billingclient.util.Inventory
import ir.myket.billingclient.util.Purchase
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.security.MessageDigest
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** One serialized SDK connection, scoped to both the live Activity and app account. */
object MyketBilling {
    data class UiState(val busy: Boolean = false, val ready: Boolean = false, val message: String? = null, val error: String? = null)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> get() = _state
    private val mutex = Mutex()
    private var activity = WeakReference<Activity>(null)
    private var owner: SessionState? = null
    private var generation = 0
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var helper: IabHelper? = null
    private var helperKey = ""

    fun attach(act: Activity) { activity = WeakReference(act) }
    fun detach(act: Activity) {
        if (activity.get() === act) { reset(); activity.clear(); owner = null }
    }
    fun onSessionChanged(session: SessionState) {
        if (owner != session) { reset(); owner = session }
    }
    private fun reset() {
        generation++
        scope.cancel()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        runCatching { helper?.dispose() }
        helper = null; helperKey = ""
        _state.value = UiState()
    }
    private fun host(): Activity = activity.get()?.takeUnless { it.isFinishing || it.isDestroyed }
        ?: throw ApiException("صفحهٔ خرید آماده نیست؛ برنامه را دوباره باز کنید.")
    private fun failure(result: IabResult): ApiException = ApiException(when (result.response) {
        1 -> "خرید لغو شد؛ اگر مبلغی کسر شده، بازیابی خرید را بزنید."
        3 -> "اتصال به پرداخت مایکت برقرار نشد؛ مایکت و اینترنت را بررسی کنید."
        4 -> "محصول اشتراک در مایکت در دسترس نیست؛ شناسهٔ محصول باید در پنل تعریف شود."
        7 -> "خرید قبلی هنوز نهایی نشده؛ بازیابی خرید را بزنید."
        else -> "عملیات مایکت کامل نشد؛ دوباره تلاش یا خرید قبلی را بازیابی کنید."
    })
    private suspend fun ensureHelper(publicKey: String): IabHelper {
        helper?.takeIf { helperKey == publicKey }?.let { return it }
        runCatching { helper?.dispose() }
        _state.value = _state.value.copy(ready = false)
        val h = IabHelper(host(), publicKey)
        h.enableDebugLogging(false)
        helper = h; helperKey = publicKey
        try {
            withTimeout(35_000) {
                suspendCancellableCoroutine<Unit> { cont ->
                    h.startSetup { result ->
                        if (cont.isActive) {
                            if (result.isSuccess) cont.resume(Unit) else cont.resumeWithException(failure(result))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            runCatching { h.dispose() }; helper = null; helperKey = ""; throw e
        }
        _state.value = _state.value.copy(ready = true)
        return h
    }
    private suspend fun inventory(h: IabHelper, skus: List<String>, details: Boolean = true): Inventory = withTimeout(40_000) {
        suspendCancellableCoroutine { cont ->
            h.queryInventoryAsync(details, skus) { result, inv ->
                if (cont.isActive) {
                    if (result.isSuccess && inv != null) cont.resume(inv) else cont.resumeWithException(failure(result))
                }
            }
        }
    }
    private suspend fun purchase(h: IabHelper, sku: String, payload: String, session: SessionState): Purchase {
      val receiptContext = host().applicationContext
      val receiptOwner = session.username.orEmpty()
      return withTimeout(180_000) {
        suspendCancellableCoroutine { cont ->
            h.launchPurchaseFlow(host(), sku, { result, receipt ->
                if (receipt != null) {
                    // Preserve evidence before any account/coroutine check. A
                    // cancelled Activity can always recover via Myket inventory.
                    if (receiptOwner.isNotBlank()) runCatching {
                        Pending.put(receiptContext, receiptOwner, receipt.originalJson, receipt.signature)
                    }
                }
                if (cont.isActive) {
                    if (result.isSuccess && receipt != null) cont.resume(receipt) else cont.resumeWithException(failure(result))
                }
            }, payload)
        }
      }
    }
    private fun operation(action: suspend (SessionState, IabHelper, List<SubscriptionPlan>) -> Unit) {
        if (_state.value.busy) return
        val session = Store.session.value
        if (session.token.isNullOrBlank() || session.username.isNullOrBlank()) return
        onSessionChanged(session)
        val version = generation
        _state.value = _state.value.copy(busy = true, message = null, error = null)
        scope.launch {
            try {
                mutex.withLock {
                    if (!Subscriptions.refresh()) throw ApiException("دریافت اطلاعات اشتراک ناموفق بود؛ اتصال و نسخهٔ سرور را بررسی کنید.")
                    val catalogue = Subscriptions.state.value
                    if (!catalogue.billingReady) throw ApiException("پرداخت اشتراک هنوز روی سرور راه‌اندازی نشده است.")
                    val h = ensureHelper(catalogue.publicKey)
                    if (Store.session.value != session) throw CancellationException("Account changed")
                    Subscriptions.syncPending(session)
                    action(session, h, catalogue.plans)
                }
            } catch (e: CancellationException) {
                // Timeouts are retryable; account/activity cancellations must
                // never apply old results to the next account.
                if (e is TimeoutCancellationException && generation == version) {
                    _state.value = _state.value.copy(error = "پاسخ خرید دیر رسید؛ بازیابی خرید را بزنید. تأیید دوباره، اشتراک را دوباره شارژ نمی‌کند.")
                }
            } catch (e: Exception) {
                if (generation == version && Store.session.value == session) {
                    _state.value = _state.value.copy(error = humanizeError(e))
                }
            } finally {
                if (generation == version) _state.value = _state.value.copy(busy = false)
            }
        }
    }
    private data class Recovery(val count: Int, val blockedSkus: Set<String>)
    fun restore(force: Boolean = false) = operation { session, h, plans ->
        val recovered = recover(session, h, plans, force)
        _state.value = _state.value.copy(message = if (recovered.count > 0) "خریدهای قبلی بررسی و وضعیت اشتراک بازیابی شد." else null)
    }
    fun buy(displayedPlan: SubscriptionPlan) = operation { session, h, plans ->
        val base = plans.firstOrNull { it.key == displayedPlan.key } ?: throw ApiException("این پلن فعال نیست؛ اطلاعات را تازه‌سازی کنید.")
        // A displayed discount is re-approved by the server immediately before checkout.
        val plan = displayedPlan.discountCode?.let { code ->
            val fresh = Subscriptions.quote(code, session)
            BillingDiscountRules.effective(base, fresh).also {
                if (it.discountCode == null) throw ApiException("تخفیف این پلن تغییر کرده؛ قیمت به‌روز را دوباره بررسی کنید.")
            }
        } ?: base
        if (!BillingPlanRules.sameTerms(displayedPlan, plan)) {
            Subscriptions.clearDiscount()
            throw ApiException("قیمت یا شرایط پلن تغییر کرده؛ اطلاعات به‌روز را ببینید و دوباره تأیید کنید.")
        }
        val recovered = recover(session, h, plans, force = false)
        if (plan.sku in recovered.blockedSkus) throw ApiException("خرید قبلی این پلن نیازمند بررسی است؛ بازیابی خرید یا ورود به حساب خریدار را امتحان کنید.")
        if (recovered.count > 0) {
            _state.value = _state.value.copy(message = "خرید قبلی بازیابی شد. اگر تمدید تازه می‌خواهید، دوباره دکمهٔ خرید را بزنید.")
            return@operation
        }
        val inv = inventory(h, listOf(plan.sku))
        val details = inv.getSkuDetails(plan.sku) ?: throw ApiException("محصول این پلن هنوز در پنل مایکت فعال نشده است.")
        if (details.type != "inapp" || BillingPriceRules.rialValue(details.price) != plan.priceRial) {
            throw ApiException("قیمت یا نوع محصول مایکت با پلن سرور یکسان نیست؛ پیش از پرداخت باید اصلاح شود.")
        }
        Pending.checkCapacity(host().applicationContext)
        val order = Subscriptions.createOrder(plan, session)
        if (Store.session.value != session) throw CancellationException("Account changed")
        val result = purchase(h, plan.sku, order.optString("developer_payload"), session)
        val raw = result.originalJson; val signature = result.signature
        Pending.put(host().applicationContext, session.username!!, raw, signature)
        if (Store.session.value != session) throw CancellationException("Account changed")
        val confirmed = Subscriptions.confirm(raw, signature, session)
        Pending.put(host().applicationContext, session.username, raw, signature, verifiedOwner = true)
        Pending.removeRejected(host().applicationContext, raw)
        if (!confirmed.optBoolean("consume_pending")) Pending.remove(host().applicationContext, raw)
        _state.value = _state.value.copy(message = if (confirmed.optBoolean("consume_pending"))
            "اشتراک فعال شد؛ نهایی‌سازی خرید در اتصال بعدی دوباره بررسی می‌شود." else "اشتراک با موفقیت فعال یا تمدید شد.")
    }
    private suspend fun recover(session: SessionState, h: IabHelper, plans: List<SubscriptionPlan>, force: Boolean): Recovery {
        val context = host().applicationContext
        val account = session.username!!
        val keyHash = Pending.hash(Subscriptions.state.value.publicKey)
        val seen = mutableSetOf<String>()
        val successfulTokens = mutableSetOf<String>()
        val blocked = mutableMapOf<String, String>()
        var count = 0
        var warning = false
        suspend fun process(entry: Pending.Entry) {
            val id = Pending.key(entry.raw)
            val variant = Pending.hash(entry.raw + "\u0000" + entry.signature)
            if (!seen.add(variant) || id in successfulTokens) return
            try {
                val confirmed = Subscriptions.confirm(entry.raw, entry.signature, session)
                Pending.put(context, account, entry.raw, entry.signature, verifiedOwner = true)
                Pending.removeRejected(context, entry.raw)
                if (!confirmed.optBoolean("consume_pending")) Pending.remove(context, entry.raw)
                successfulTokens += id
                blocked.remove(id)
                count++
            } catch (e: ApiException) {
                if (e.code == 403 && e.errorCode == "order_owner_mismatch") {
                    blocked[id] = Pending.sku(entry.raw); warning = true
                } else if (BillingRecoveryRules.quarantine(e.code, e.errorCode)) {
                    // Preserve evidence, but a bad old receipt must not poison
                    // all unrelated checkout or stop later legitimate recovery.
                    Pending.quarantine(context, account, entry.raw, entry.signature, e.errorCode.orEmpty(), keyHash)
                    Pending.remove(context, entry.raw)
                    blocked[id] = Pending.sku(entry.raw); warning = true
                } else throw e
            }
        }
        // Recover local evidence even before querying the SDK inventory.
        Pending.list(context, account).forEach { process(it) }
        Pending.rejected(context, account, keyHash, force).forEach { process(it) }
        val allowed = Subscriptions.state.value.recoverySkus + plans.map { it.sku }
        val inv = inventory(h, allowed.toList(), details = false)
        val owned = inv.allPurchases.filter { it.sku in allowed }
        owned.forEach { p ->
            val id = Pending.key(p.originalJson)
            if (id in successfulTokens || Pending.hash(p.originalJson + "\u0000" + p.signature) in seen) return@forEach
            if (Pending.isRejected(context, account, p.originalJson, p.signature, keyHash) && !force) {
                blocked[id] = p.sku; warning = true
            } else {
                Pending.put(context, account, p.originalJson, p.signature)
                process(Pending.Entry(account, p.originalJson, p.signature))
            }
        }
        if (warning) _state.value = _state.value.copy(error = "بعضی رسیدهای قبلی نیازمند بررسی‌اند؛ رسیدها برای پیگیری حفظ شدند و بقیهٔ خریدها جدا بررسی می‌شوند.")
        val currentlyOwned = owned.map { Pending.key(it.originalJson) }.toSet()
        return Recovery(count, blocked.filterKeys { it in currentlyOwned }.values.toSet())
    }

    /** Private durable evidence only; never stores an app bearer or merchant access token. */
    private object Pending {
        data class Entry(val owner: String, val raw: String, val signature: String)
        private const val FILE = "studying_billing_pending"
        private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        private fun rejectedPrefs(ctx: Context) = ctx.getSharedPreferences(FILE + "_quarantine", Context.MODE_PRIVATE)
        fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
        fun sku(raw: String): String = runCatching { JSONObject(raw).optString("productId") }.getOrDefault("")
        fun key(raw: String): String {
            val token = runCatching { JSONObject(raw).optString("purchaseToken").ifBlank { JSONObject(raw).optString("token") } }.getOrDefault(raw)
            return hash(token)
        }
        fun list(ctx: Context, owner: String): List<Entry> = prefs(ctx).all.values.mapNotNull { value ->
            runCatching {
                val o = JSONObject(value as String)
                if (o.optString("owner") == owner) Entry(owner, o.getString("raw"), o.getString("signature")) else null
            }.getOrNull()
        }
        fun quarantine(ctx: Context, owner: String, raw: String, signature: String, reason: String, keyHash: String) {
            val value = JSONObject().put("owner", owner).put("raw", raw).put("signature", signature).put("reason", reason).put("key_hash", keyHash)
            if (!rejectedPrefs(ctx).edit().putString(key(raw), value.toString()).commit()) throw ApiException("رسید برای پیگیری ذخیره نشد؛ فضای دستگاه را بررسی کنید.")
        }
        fun removeRejected(ctx: Context, raw: String) { rejectedPrefs(ctx).edit().remove(key(raw)).commit() }
        fun isRejected(ctx: Context, owner: String, raw: String, signature: String, keyHash: String): Boolean = runCatching {
            val o = JSONObject(rejectedPrefs(ctx).getString(key(raw), "")!!)
            o.optString("owner") == owner && o.optString("key_hash") == keyHash && o.optString("raw") == raw && o.optString("signature") == signature
        }.getOrDefault(false)
        fun rejected(ctx: Context, owner: String, keyHash: String, force: Boolean): List<Entry> = rejectedPrefs(ctx).all.values.mapNotNull { v ->
            runCatching {
                val o = JSONObject(v as String)
                if (o.optString("owner") == owner && (force || o.optString("key_hash") != keyHash)) Entry(owner, o.getString("raw"), o.getString("signature")) else null
            }.getOrNull()
        }
        fun checkCapacity(ctx: Context) { if (prefs(ctx).all.size >= 64) throw ApiException("ابتدا خریدهای قبلی را بازیابی کنید؛ صف خرید در انتظار تکمیل است.") }
        fun put(ctx: Context, owner: String, raw: String, signature: String, verifiedOwner: Boolean = false) {
            if (raw.length > 32768 || signature.length > 8192) throw ApiException("اندازهٔ رسید خرید معتبر نیست.")
            val p = prefs(ctx); val k = key(raw)
            val priorOwner = runCatching { JSONObject(p.getString(k, "")!!).optString("owner") }.getOrDefault("")
            if (!verifiedOwner && priorOwner.isNotBlank() && priorOwner != owner) return
            if (!p.contains(k)) checkCapacity(ctx)
            if (!p.edit().putString(k, JSONObject().put("owner", owner).put("raw", raw).put("signature", signature).toString()).commit()) {
                throw ApiException("رسید خرید ذخیره نشد؛ خرید قبلی را بازیابی کنید.")
            }
        }
        fun remove(ctx: Context, raw: String) { prefs(ctx).edit().remove(key(raw)).commit() }
    }
}
