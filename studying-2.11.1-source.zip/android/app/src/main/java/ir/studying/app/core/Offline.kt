package ir.studying.app.core

import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Write-ahead outbox. Acknowledgements remove only the matching owner/uid, never a stale snapshot. */
object Offline {
    private val KEY = stringPreferencesKey("offline_study_queue")
    private val flushLock = Mutex()
    private val addLock = Mutex()
    private val _pending = MutableStateFlow(0)
    val pending: StateFlow<Int> get() = _pending
    private val _parts = MutableStateFlow<List<Part>>(emptyList())
    val parts: StateFlow<List<Part>> get() = _parts

    enum class Source { MANUAL, CHRONO, POMODORO, ALL_TIMERS }
    /** [detail] یک JSON فشرده از جزئیات گزارش است (سرفصل، تست‌ها، زمان‌ها، تمرکز).
     *  خالی بودنش یعنی گزارش ساده؛ دقیقاً مثل نسخه‌های قبل رفتار می‌کند. */
    data class Part(val id: String, val minutes: Int, val courseId: Int, val at: Long,
        val uid: String, val tries: Int = 0, val user: String = "", val rejected: Boolean = false,
        val detail: String = "")

    fun stamp(ms: Long): String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        .apply { timeZone = IranTime.ZONE }.format(java.util.Date(ms))

    // Unknown/legacy HTTP-200 errors are NOT proof that study can be discarded.
    fun isPermanent(e: Throwable?): Boolean = (e as? ApiException)?.code in listOf(400, 422)

    internal fun decode(raw: String?): List<Part> {
        if (raw == null) return emptyList()
        val a = JSONArray(raw) // Fail closed: malformed storage must not be overwritten as an empty queue.
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val id = o.getString("id")
            Part(id, o.getInt("minutes"), o.optInt("course_id"), o.optLong("at"),
                o.optString("uid").ifBlank { id }, o.optInt("tries"), o.optString("user"), o.optBoolean("rejected"),
                o.optString("detail"))
        }
    }

    internal fun encode(list: List<Part>): String = JSONArray().apply {
        list.forEach { p -> put(JSONObject().put("id", p.id).put("minutes", p.minutes)
            .put("course_id", p.courseId).put("at", p.at).put("uid", p.uid)
            .put("tries", p.tries).put("user", p.user).put("rejected", p.rejected)
            .put("detail", p.detail)) }
    }.toString()

    internal fun resetView() { _parts.value = emptyList(); _pending.value = 0 }

    private fun publish(list: List<Part>) {
        val owner = Store.username
        val visible = list.filter { !owner.isNullOrBlank() && it.user == owner }
        _parts.value = visible
        _pending.value = visible.size
    }

    private fun mutate(change: (List<Part>) -> List<Part>) {
        var result = emptyList<Part>()
        Store.durableStudyEdit { p -> result = change(decode(p[KEY])); p[KEY] = encode(result) }
        publish(result)
    }

    /** Commit the study AND consume its source before any HTTP call or UI success. */
    fun record(minutes: Int, courseId: Int, source: Source = Source.MANUAL,
        uid: String = UUID.randomUUID().toString(), atMs: Long = System.currentTimeMillis(),
        detail: String = ""): Boolean {
        require(minutes > 0) { "زمانی برای ثبت نیست" }
        val owner = Store.username?.takeIf { it.isNotBlank() } ?: error("ابتدا وارد حساب شو")
        val consumeChrono = source == Source.CHRONO || source == Source.ALL_TIMERS
        val consumePomodoro = source == Source.POMODORO || source == Source.ALL_TIMERS
        if (consumeChrono) ir.studying.app.player.Chrono.pause()
        if (consumePomodoro) ir.studying.app.player.Pomodoro.pause()
        var added = false
        var result = emptyList<Part>()
        Store.durableStudyEdit { p ->
            check(Store.username == owner) { "حساب کاربری تغییر کرد" }
            val list = decode(p[KEY])
            if (list.any { it.user == owner && it.uid == uid }) { result = list; return@durableStudyEdit }
            val blocks = buildList {
                if (source == Source.MANUAL) add(StudyPending.Block(minutes, atMs))
                if (consumeChrono) add(StudyPending.Block(
                    (ir.studying.app.player.Chrono.elapsedMs() / 60_000).toInt(),
                    Store.timer.value.endEpochMs.takeIf { it > 0L } ?: atMs))
                if (consumePomodoro) {
                    addAll(StudyPending.read(p))
                    val s = ir.studying.app.player.Pomodoro.state.value
                    val partial = if (s.phase == ir.studying.app.player.Pomodoro.Phase.WORK)
                        ((s.config.workMin * 60 - s.remainingSec) / 60).coerceAtLeast(0) else 0
                    if (partial > 0) add(StudyPending.Block(partial,
                        Store.pomodoro.value.endEpochMs.takeIf { it > 0L } ?: atMs))
                }
            }.filter { it.minutes > 0 }
            check(blocks.isNotEmpty()) { "زمانی برای ثبت نیست" }
            // UI covers the combined timers, but each HTTP row must fit its own minutes.
            // Keep questions once; distribute the activity budget rather than overfill block zero.
            val details = if (detail.isBlank()) null else
                ir.studying.app.data.StudyDetail.from(JSONObject(detail)).splitAcross(blocks.map { it.minutes })
            val entries = blocks.mapIndexed { i, b ->
                val partUid = if (i == 0) uid else "$uid-$i"
                /* splitAcross keeps question counts once and time within each block. */
                Part(partUid, b.minutes, courseId, b.at, partUid, user = owner,
                    detail = details?.get(i)?.takeIf { !it.isEmpty }?.toJson()?.toString().orEmpty())
            }
            result = list + entries // Never silently evict old study after a long offline stretch.
            p[KEY] = encode(result)
            if (consumeChrono) Store.consumeTimer(p, pomodoro = false)
            if (consumePomodoro) {
                Store.consumeTimer(p, pomodoro = true)
                StudyPending.write(p, emptyList())
            }
            added = true
        }
        publish(result)
        if (added) runCatching { ir.studying.app.ui.components.StreakFx.onStudyRecorded() }
        runCatching {
            if (consumePomodoro) ir.studying.app.player.Pomodoro.restore(ir.studying.app.App.instance)
            if (source != Source.MANUAL) ir.studying.app.notify.StudyNotifier.sync(ir.studying.app.App.instance)
        }
        return added
    }

    suspend fun add(minutes: Int, courseId: Int, uid: String = UUID.randomUUID().toString(),
        atMs: Long = System.currentTimeMillis(), detail: String = ""): Boolean = addLock.withLock {
        record(minutes, courseId, uid = uid, atMs = atMs, detail = detail)
    }

    suspend fun remove(id: String) { mutate { rows -> rows.filterNot { it.id == id && it.user == Store.username } } }
    suspend fun refresh(): Int {
        publish(decode(Store.getString(KEY.name)))
        return _pending.value
    }
    suspend fun hasRetryable(): Boolean = decode(Store.getString(KEY.name)).any {
        !Store.token.isNullOrBlank() && !Store.username.isNullOrBlank() && it.user == Store.username && !it.rejected
    }

    suspend fun flush(retryRejected: Boolean = false): Int = flushLock.withLock {
        val session = Store.session.value
        if (session.token.isNullOrBlank() || session.username.isNullOrBlank()) return@withLock 0
        val snapshot = decode(Store.getString(KEY.name)).filter { it.user == session.username && (retryRejected || !it.rejected) }
        var sent = 0
        for (p in snapshot) {
            if (Store.session.value != session) break
            // It may have been removed while the previous request was in flight.
            if (decode(Store.getString(KEY.name)).none { it.user == p.user && it.uid == p.uid }) continue
            try {
                val body = JSONObject().put("minutes", p.minutes).put("share_post", 0).put("client_uid", p.uid)
                if (p.at > 0L) body.put("ended_at", stamp(p.at))
                if (p.courseId > 0) body.put("course_id", p.courseId)
                /* Never send a written-question report to a server that would discard its new field. */
                if (p.detail.isNotBlank()) {
                    val detail = JSONObject(p.detail)
                    if (detail.optInt("q_descriptive") > 0) StudyServer.requireDescriptiveSupport(session)
                    body.put("detail", detail)
                }
                val response = JSONObject(Api.postForSession("study", body, session))
                check(!response.has("error") &&
                    (response.boolish("ok") || response.boolish("success") || response.optInt("id") > 0) &&
                    (!response.has("success") || response.boolish("success")) &&
                    (!response.has("ok") || response.boolish("ok"))) { "Unconfirmed study response" }
                mutate { rows -> rows.filterNot { it.user == p.user && it.uid == p.uid } }
                /* پاداش‌های تازه (هدف روزانه، رتبهٔ اول روز…) را همان‌جا اعلام می‌کنیم. */
                runCatching { Awards.announce(Awards.from(response)) }
                sent++
            } catch (e: CancellationException) {
                throw e // Durable entry remains, with its original idempotency key.
            } catch (e: Exception) {
                mutate { rows -> rows.map { if (it.user == p.user && it.uid == p.uid)
                    it.copy(tries = (it.tries + 1).coerceAtLeast(1), rejected = isPermanent(e)) else it } }
                if (!isPermanent(e)) break // Respect auth/rate limits; don't hammer the rest of the queue.
            }
        }
        refresh()
        if (sent > 0) {
            ir.studying.app.data.StudyHistory.invalidate()
            RefreshBus.emit("study")
            if (Store.session.value == session) runCatching { AutoPost.afterStudySaved(ir.studying.app.ui.study.room.RoomPrefs.goal.value) }
        }
        sent
    }

    suspend fun clear() { mutate { emptyList() } }
}
