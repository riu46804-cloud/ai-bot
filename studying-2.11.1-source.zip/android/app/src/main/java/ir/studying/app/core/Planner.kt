package ir.studying.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/* ======================================================================== */
/*  مدل‌های برنامه‌ی مطالعه — آینهٔ خروجی موتور برنامه‌ریزی (planner 1.5.0)  */
/* ======================================================================== */

/*
 * چرا تایپ‌دار؟ خروجی موتور چند لایه تودرتو دارد (روز ← تسک ← فاز) و اگر UI
 * مستقیم با JSONObject کار کند، هر تغییر کوچک سرور به کرش در عمق درخت ختم
 * می‌شود. اینجا یک‌بار با خوانش ایمن (opt*) پارس می‌شود؛ هر فیلد غایب مقدار
 * بی‌خطر می‌گیرد، پس نسخهٔ قدیمی‌تر سرور هم صفحه را نمی‌شکند.
 */

data class PlanPhase(val key: String, val labelFa: String, val minutes: Int, val howFa: String)

data class PlanCriteria(val textFa: String, val measures: List<Pair<String, String>>)

data class PlanTimeEstimate(val minutes: Int, val basis: String, val explainFa: String)

data class PlanPages(
    val pdfStart: Int?, val pdfEnd: Int?,
    val printedStart: Int?, val printedEnd: Int?,
) {
    /** شماره‌ی چاپ‌شده روی کتاب را ترجیح می‌دهیم؛ همانی است که دانش‌آموز می‌بیند. */
    val labelFa: String?
        get() {
            val s = printedStart ?: pdfStart ?: return null
            val e = printedEnd ?: pdfEnd ?: return null
            val tag = if (printedStart != null) "کتاب" else "PDF"
            return "صفحه ${s.fa()} تا ${e.fa()} ($tag)"
        }
}

data class PlanTask(
    val taskId: String,
    val type: String,
    val typeFa: String,
    val topicId: String?,
    val title: String,
    val subject: String,
    val bookId: String?,
    val chapterTitle: String?,
    val lessonTitle: String?,
    val pages: PlanPages?,
    val subtopics: List<String>,
    val durationMinutes: Int,
    val priority: String,
    val evaluationLevel: String,
    val minRequired: Boolean,
    val movable: Boolean,
    val focusFa: String,
    val watchOutFa: List<String>,
    val estimate: PlanTimeEstimate?,
    val date: String,
    val startTime: String,
    val endTime: String,
    val split: Boolean,
    val phases: List<PlanPhase>,
    val criteria: PlanCriteria?,
    val questionCount: Int?,
) {
    val isEvaluation: Boolean get() = type in setOf("weekly_review", "weekly_test", "mock_exam", "mock_analysis")
}

data class PlanBreak(val startTime: String, val endTime: String, val minutes: Int, val labelFa: String)

data class PlanDay(
    val date: String,
    val weekday: String,
    val isBlocked: Boolean,
    val dayType: String,
    val energyFactor: Double,
    val isLowEnergy: Boolean,
    val capacityMinutes: Int,
    val plannedMinutes: Int,
    val capacityNoteFa: String,
    val windows: List<Pair<String, String>>,
    val tasks: List<PlanTask>,
    val breaks: List<PlanBreak>,
) {
    val requiredCount: Int get() = tasks.count { it.minRequired }
}

data class PlanTotals(
    val capacityMinutes: Int,
    val plannedMinutes: Int,
    val utilization: Double,
    val taskCount: Int,
    val unscheduledCount: Int,
    val byActivity: List<Pair<String, Int>>,
)

data class StudyPlan(
    val startDate: String,
    val endDate: String,
    val totals: PlanTotals,
    val days: List<PlanDay>,
    val backlog: List<PlanTask>,
    val capacityNoteFa: String,
)

data class ReviewRow(
    val topicId: String, val title: String, val subject: String,
    val learnDates: List<String>, val reviewDates: List<String>, val testDates: List<String>,
    val gapWarningFa: String?,
)

data class RetentionSeries(val title: String, val retention: List<Float>, val endRetention: Float)

data class RetentionForecast(val dates: List<String>, val series: List<RetentionSeries>)

data class WeekRow(
    val week: String, val from: String, val to: String,
    val plannedMinutes: Int, val capacityMinutes: Int, val taskCount: Int,
    val topics: List<String>,
)

data class MistakeRow(val labelFa: String, val actionFa: String, val count: Int, val topics: List<String>)

data class CheckItem(val group: String, val labelFa: String, val ok: Boolean)

data class PlanChecklist(val score: Int, val total: Int, val items: List<CheckItem>)

/** یک نتیجهٔ کامل: برنامه + همهٔ نماهای تحلیلی + درخواستی که آن را ساخت. */
data class PlanResult(
    val plan: StudyPlan,
    val review: List<ReviewRow>,
    val retention: RetentionForecast,
    val weekly: List<WeekRow>,
    val mistakes: List<MistakeRow>,
    val checklist: PlanChecklist?,
    /** درخواست نهایی؛ برای بازبرنامه‌ریزی باید بی‌کم‌وکاست پس فرستاده شود. */
    val request: JSONObject?,
    /** آزمونی که این برنامه برایش چیده شده. */
    val examTarget: ExamTarget? = null,
    /** جملهٔ راهبرد از لایهٔ AI. */
    val strategyFa: String? = null,
    /** نکته‌های کوتاه همان برنامه. */
    val notesFa: List<String> = emptyList(),
    /** برنامه را مدل نوشته (`ai`) یا موتور قطعی (`rules`). */
    val plannerBy: String? = null,
    /** «آزمون بعدی چه می‌خواهد و با وقت تو چقدرش جا می‌شود». */
    val examBrief: ExamBrief? = null,
    /** چرا برنامه آزمون‌محور نشد: `outdated` / `no_schedule` / `no_match`. */
    val examStatus: String? = null,
    val examStatusFa: String? = null,
)

/**
 * گزارش آزمون بعدی.
 *
 * دانش‌آموز قبل از دیدن جدول باید سه چیز را بداند: سرفصل آزمون چیست،
 * با ساعت‌هایی که اعلام کرده چقدرش در این دوره جا می‌شود، و چه می‌ماند.
 */
data class ExamBrief(
    val dateIso: String?,
    val titleFa: String?,
    val daysLeft: Int?,
    val scope: List<ExamScopeBook>,
    val capacityMinutes: Int,
    val neededMinutes: Int,
    val balanceMinutes: Int,
    val enough: Boolean,
    val topicsTotal: Int,
    val topicsPlanned: Int,
    val leftOut: List<ExamLeftOut>,
    val summaryFa: String,
) {
    val ratio: Float get() = if (topicsTotal > 0) topicsPlanned.toFloat() / topicsTotal else 0f
}

data class ExamScopeBook(
    val bookId: String, val subject: String, val chapters: List<String>,
    val topics: Int, val minutes: Int, val plannedTopics: Int,
)

data class ExamLeftOut(val topicId: String, val title: String, val subject: String, val minutes: Int)

/** آزمون هدفِ این دوره — عنوان صفحهٔ برنامه از همین می‌آید. */
data class ExamTarget(
    val provider: String,
    val dateIso: String,
    val dateFa: String,
    val milestoneFa: String,
    val chapterCount: Int,
)

/* ======================================================================== */
/*  پارس                                                                    */
/* ======================================================================== */

private fun JSONObject.pairsOf(key: String): List<Pair<String, String>> {
    val o = optJSONObject(key) ?: return emptyList()
    return o.keys().asSequence().map { it to o.opt(it).toString() }.toList()
}

private fun JSONObject.intsOf(key: String): List<Pair<String, Int>> {
    val o = optJSONObject(key) ?: return emptyList()
    return o.keys().asSequence().map { it to o.optInt(it) }.toList()
}

private fun JSONArray?.list(): List<JSONObject> =
    if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

private fun JSONArray?.texts(): List<String> =
    if (this == null) emptyList() else (0 until length()).mapNotNull { if (isNull(it)) null else optString(it) }

private fun JSONObject.nullableInt(key: String): Int? = if (isNull(key)) null else optInt(key)

private fun parsePages(o: JSONObject?): PlanPages? {
    if (o == null) return null
    return PlanPages(o.nullableInt("pdf_start"), o.nullableInt("pdf_end"),
        o.nullableInt("printed_start"), o.nullableInt("printed_end"))
}

private fun parseTask(o: JSONObject): PlanTask = PlanTask(
    taskId = o.optString("task_id"),
    type = o.optString("type"),
    typeFa = o.optString("type_fa").ifBlank { plannerTypeFa(o.optString("type")) },
    topicId = o.optString("topic_id").takeIf { it.isNotBlank() && it != "null" },
    title = o.optString("topic_title").ifBlank { o.optString("type_fa") },
    subject = o.optString("subject"),
    bookId = o.optString("book_id").takeIf { it.isNotBlank() && it != "null" },
    chapterTitle = o.optString("chapter_title").takeIf { it.isNotBlank() && it != "null" },
    lessonTitle = o.optString("lesson_title").takeIf { it.isNotBlank() && it != "null" },
    pages = parsePages(o.optJSONObject("page_range")),
    subtopics = o.optJSONArray("subtopics").texts(),
    durationMinutes = o.optInt("duration_minutes"),
    priority = o.optString("priority", "normal"),
    evaluationLevel = o.optString("evaluation_level", "topic"),
    minRequired = o.optBoolean("min_required", false),
    movable = o.optBoolean("movable", true),
    focusFa = o.optString("focus_fa"),
    watchOutFa = o.optJSONArray("watch_out_fa").texts(),
    estimate = o.optJSONObject("time_estimate")?.let {
        PlanTimeEstimate(it.optInt("minutes"), it.optString("basis"), it.optString("explain_fa"))
    },
    date = o.optString("date"),
    startTime = o.optString("start_time"),
    endTime = o.optString("end_time"),
    split = o.optBoolean("split", false),
    phases = o.optJSONArray("phases").list().map {
        PlanPhase(it.optString("key"), it.optString("label_fa"), it.optInt("minutes"), it.optString("how_fa"))
    },
    criteria = o.optJSONObject("completion_criteria")?.let {
        PlanCriteria(it.optString("text_fa"), it.pairsOf("measures"))
    },
    questionCount = o.nullableInt("question_count"),
)

/** نام فارسی نوع تسک — وقتی سرور قدیمی `type_fa` نمی‌فرستد. */
fun plannerTypeFa(type: String): String = when (type) {
    "learn" -> "یادگیری"
    "practice" -> "تست و تمرین"
    "review" -> "مرور"
    "flash_review" -> "مرور سریع"
    "reteach" -> "آموزش مجدد"
    "analyze_errors" -> "تحلیل خطا"
    "timed_drill" -> "تمرین زمان‌دار"
    "weekly_review" -> "مرور هفتگی"
    "weekly_test" -> "آزمون هفتگی"
    "mock_exam" -> "آزمون جامع"
    "mock_analysis" -> "تحلیل آزمون"
    else -> "مطالعه"
}

fun parsePlanResult(root: JSONObject): PlanResult? {
    val p = root.optJSONObject("plan") ?: return null
    val tot = p.optJSONObject("totals") ?: JSONObject()
    val plan = StudyPlan(
        startDate = p.optString("start_date"),
        endDate = p.optString("end_date"),
        capacityNoteFa = p.optString("capacity_note_fa"),
        totals = PlanTotals(
            tot.optInt("capacity_minutes"), tot.optInt("planned_minutes"),
            tot.optDouble("utilization", 0.0), tot.optInt("task_count"),
            tot.optInt("unscheduled_count"), tot.intsOf("minutes_by_activity"),
        ),
        days = p.optJSONArray("days").list().map { d ->
            PlanDay(
                date = d.optString("date"),
                weekday = d.optString("weekday"),
                isBlocked = d.optBoolean("is_blocked", false),
                dayType = d.optString("day_type", "normal"),
                energyFactor = d.optDouble("energy_factor", 1.0),
                isLowEnergy = d.optBoolean("is_low_energy", false),
                capacityMinutes = d.optInt("capacity_minutes"),
                plannedMinutes = d.optInt("planned_minutes"),
                capacityNoteFa = d.optString("capacity_note_fa"),
                windows = d.optJSONArray("windows").list().map { it.optString("start") to it.optString("end") },
                tasks = d.optJSONArray("tasks").list().map(::parseTask),
                breaks = d.optJSONArray("breaks").list().map {
                    PlanBreak(it.optString("start_time"), it.optString("end_time"), it.optInt("minutes"),
                        it.optString("label_fa").ifBlank { "استراحت" })
                },
            )
        },
        backlog = (p.optJSONObject("backlog")?.optJSONArray("carry_over") ?: p.optJSONArray("backlog")).list().map(::parseTask),
    )
    return PlanResult(
        plan = plan,
        review = root.optJSONArray("review_schedule").list().map {
            ReviewRow(it.optString("topic_id"), it.optString("title"), it.optString("subject"),
                it.optJSONArray("learn_dates").texts(), it.optJSONArray("review_dates").texts(),
                it.optJSONArray("test_dates").texts(),
                it.optString("gap_warning_fa").takeIf { s -> s.isNotBlank() && s != "null" })
        },
        retention = root.optJSONObject("retention_forecast").let { r ->
            RetentionForecast(
                r?.optJSONArray("dates").texts(),
                r?.optJSONArray("series").list().map { s ->
                    val arr = s.optJSONArray("retention")
                    RetentionSeries(s.optString("title"),
                        (0 until (arr?.length() ?: 0)).map { arr!!.optDouble(it, 0.0).toFloat() },
                        s.optDouble("end_retention", 0.0).toFloat())
                } ?: emptyList(),
            )
        },
        weekly = root.optJSONArray("weekly_overview").list().map {
            WeekRow(it.optString("week"), it.optString("from"), it.optString("to"),
                it.optInt("planned_minutes"), it.optInt("capacity_minutes"), it.optInt("task_count"),
                it.optJSONArray("topics").texts())
        },
        mistakes = root.optJSONArray("mistake_overview").list().map {
            MistakeRow(it.optString("label_fa"), it.optString("action_fa"), it.optInt("count"),
                it.optJSONArray("topics").texts())
        },
        checklist = root.optJSONObject("checklist")?.let { c ->
            PlanChecklist(c.optInt("score"), c.optInt("total", 12), c.optJSONArray("items").list().map {
                CheckItem(it.optString("group"), it.optString("label_fa"), it.optBoolean("ok", false))
            })
        },
        request = root.optJSONObject("request"),
        examStatus = root.optJSONObject("exam_plan")?.optString("status")
            ?.takeIf { it.isNotBlank() && it != "null" && it != "ok" },
        examStatusFa = root.optJSONObject("exam_plan")?.optString("message_fa")
            ?.takeIf { it.isNotBlank() && it != "null" },
        examTarget = root.optJSONObject("exam_plan")?.takeIf { it.optBoolean("focus") }?.let {
            ExamTarget(
                provider = it.optString("provider"),
                dateIso = it.optString("target_date"),
                dateFa = it.optString("target_fa"),
                milestoneFa = it.optString("milestone_fa"),
                chapterCount = it.optInt("chapter_count"),
            )
        },
        strategyFa = root.optJSONObject("ai")?.optString("strategy_fa")?.takeIf { it.isNotBlank() && it != "null" },
        notesFa = root.optJSONObject("ai")?.optJSONArray("notes_fa").texts(),
        plannerBy = root.optJSONObject("meta")?.optJSONObject("engine")?.optString("planner")
            ?.takeIf { it.isNotBlank() && it != "null" },
        examBrief = root.optJSONObject("exam_brief")?.let { b ->
            val ex = b.optJSONObject("exam")
            val tm = b.optJSONObject("time")
            val cv = b.optJSONObject("coverage")
            ExamBrief(
                dateIso = ex?.optString("date")?.takeIf { it.isNotBlank() && it != "null" },
                titleFa = ex?.optString("title_fa")?.takeIf { it.isNotBlank() && it != "null" },
                daysLeft = if (ex != null && ex.has("days_left") && !ex.isNull("days_left")) ex.optInt("days_left") else null,
                scope = b.optJSONArray("scope").list().map {
                    ExamScopeBook(it.optString("book_id"), it.optString("subject"),
                        it.optJSONArray("chapters").texts(), it.optInt("topics"),
                        it.optInt("minutes"), it.optInt("planned_topics"))
                },
                capacityMinutes = tm?.optInt("capacity_minutes") ?: 0,
                neededMinutes = tm?.optInt("needed_minutes") ?: 0,
                balanceMinutes = tm?.optInt("balance_minutes") ?: 0,
                enough = tm?.optBoolean("enough", true) ?: true,
                topicsTotal = cv?.optInt("topics_total") ?: 0,
                topicsPlanned = cv?.optInt("topics_planned") ?: 0,
                leftOut = b.optJSONArray("left_out").list().map {
                    ExamLeftOut(it.optString("topic_id"), it.optString("title"),
                        it.optString("subject"), it.optInt("minutes"))
                },
                summaryFa = b.optString("summary_fa"),
            )
        },
    )
}

/* ======================================================================== */
/*  کلاینت                                                                  */
/* ======================================================================== */

/**
 * موتور برنامه‌ریزی روی یک اسکریپت جدای `api.php` می‌نشیند، پس نمی‌تواند از
 * [Api] استفاده کند. مسیر با `?path=` ساخته می‌شود چون تنها شکلی است که بدون
 * rewrite، با rewrite و در زیرپوشه یکسان کار می‌کند. مهلت‌ها بلند است: ساخت
 * برنامه با مدل زبانی تا یک دقیقه هم طول می‌کشد.
 */
object PlannerApi {
    const val BASE = "https://studying.ir/single/planner.php"

    /**
     * کلید دسترسی به موتور برنامه‌ریز.
     *
     * `planner.php` سرویس جدایی از `api.php` است و توکن ورود کاربر را
     * نمی‌شناسد؛ فقط کلید سرویس را قبول می‌کند. نسخهٔ قبلی به‌اشتباه توکن
     * حساب را در هدر `Authorization` می‌فرستاد و سرور هر درخواست را با
     * `unauthorized` رد می‌کرد — همان خطای «کلید کلاینت» روی گوشی.
     */
    private const val CLIENT_KEY = "lrG18HzVvlkb_BVaCwO7ynwrWEZpi-8q"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(150, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * مسیر با `?path=` ساخته می‌شود. اگر خود مسیر کوئری داشته باشد، کوئری
     * بیرون از `path` می‌رود — وگرنه کل رشته انکود می‌شد و سرور «مسیر» را
     * `/v1/curriculum?track=...` می‌دید و ۴۰۴ می‌داد.
     */
    private fun url(path: String): String {
        val q = path.indexOf('?')
        if (q < 0) return BASE + "?path=" + URLEncoder.encode(path, "UTF-8")
        return BASE + "?path=" + URLEncoder.encode(path.substring(0, q), "UTF-8") + "&" + path.substring(q + 1)
    }

    private fun run(req: Request): String {
        val call = try { client.newCall(req).execute() } catch (e: Exception) { throw ApiException(humanizeError(e)) }
        call.use { resp ->
            val text = resp.body?.string()?.trim().orEmpty()
            if (text.startsWith("{")) {
                val o = JSONObject(text)
                val err = o.optJSONObject("error")
                if (err != null) throw ApiException(plannerErrorFa(err.optString("code"), err.optString("message")), resp.code)
            }
            if (!resp.isSuccessful) throw ApiException("سرور برنامه‌ریز در دسترس نیست (${resp.code}) 🛠", resp.code)
            return text
        }
    }

    // کلید سرویس در هر دو شکلی که سرور می‌پذیرد می‌رود تا به تنظیمات میزبان
    // (حذف‌شدن هدر Authorization توسط بعضی وب‌سرورها) حساس نباشد. توکن حساب
    // در هدر جدا می‌رود، نه روی Authorization، وگرنه جای کلید را می‌گیرد.
    private fun builder(path: String): Request.Builder {
        PlannerAvailability.requireEnabled()
        return Request.Builder().url(url(path))
        .header("Accept", "application/json")
        .header("X-API-Key", CLIENT_KEY)
        .header("Authorization", "Bearer $CLIENT_KEY")
        .apply { Store.token?.let { header("X-App-Token", it) } }
    }

    suspend fun post(path: String, body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        JSONObject(run(builder(path).post(body.toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())).build()))
    }

    suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        JSONObject(run(builder(path).get().build()))
    }

    /** فایل تقویم؛ متن ICS خام برمی‌گردد. */
    suspend fun ics(plan: JSONObject): String = withContext(Dispatchers.IO) {
        run(builder("/v1/plan/ics").post(JSONObject().put("plan", plan).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())).build())
    }
}

/** خطاهای موتور را به زبان دانش‌آموز ترجمه می‌کند — کد فنی به درد او نمی‌خورد. */
fun plannerErrorFa(code: String, message: String): String = when (code) {
    "ai_not_configured" -> "سرویس هوشمند برنامه‌ریزی هنوز فعال نشده؛ کمی بعد دوباره امتحان کن 🤖"
    "unauthorized" -> "دسترسی به موتور برنامه‌ریز تأیید نشد؛ نسخهٔ اپ را به‌روز کن 🔑"
    "rate_limited" -> "درخواست‌ها زیاد شد؛ چند لحظه صبر کن و دوباره بفرست ⏳"
    "validation_error" -> message.ifBlank { "اطلاعات درخواست کامل نیست" }
    else -> message.ifBlank { "ساخت برنامه ناموفق بود؛ دوباره تلاش کن" }
}
