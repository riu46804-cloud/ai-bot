package ir.studying.app.core

/** Release-wide switch. Planner data is retained, but no planner UI/network/report runs. */
object PlannerAvailability {
    const val ENABLED = false
    const val BADGE = "به‌زودی"
    const val MESSAGE = "پلنر به‌زودی فعال می‌شود"
    const val DESCRIPTION = "در حال آماده‌سازی نسخهٔ بهتر پلنر هستیم. تا آن زمان، می‌توانی از سایر امکانات اپ استفاده کنی."

    fun requireEnabled() {
        check(ENABLED) { MESSAGE }
    }
}
