package ir.studying.app.core

import org.json.JSONObject

/* ======================================================================== */
/*  محتوای درسی — دیتاست رسمی ۱۴۰۵                                          */
/* ======================================================================== */

/** یک رشتهٔ تحصیلی به‌همراه پایه‌هایی که برایش کتاب وجود دارد. */
data class CurrTrack(
    val trackId: String,
    val title: String,
    val bookCount: Int,
    val grades: List<Pair<Int, String>>,
)

data class CurrTopic(
    val topicId: String,
    val chapterId: String,
    val title: String,
    /** زیرمبحث‌های واقعی کتاب (از خلاصهٔ مفاهیم همان دیتاست). */
    val subtopics: List<String> = emptyList(),
    /** دقیقهٔ مطالعهٔ تشریحی طبق بودجه‌بندی رسمی. */
    val studyMinutes: Int = 0,
    val testMinutes: Int = 0,
    val suggestedTests: Int = 0,
) {
    val timeFa: String?
        get() = if (studyMinutes <= 0) null else "${(studyMinutes / 60f).let { if (it % 1f == 0f) it.toInt().fa() else String.format("%.1f", it).toFaDigits() }} ساعت"
}

data class CurrChapter(
    val chapterId: String,
    val title: String,
    val description: String?,
    val topics: List<CurrTopic>,
)

data class CurrBook(
    val bookId: String,
    val title: String,
    val subject: String,
    val grade: String,
    val gradeNumber: Int,
    val topicCount: Int,
    val isKonkur: Boolean = false,
    /** مجموع دقیقهٔ تشریحی کل کتاب، طبق دیتاست. */
    val studyMinutes: Int = 0,
    val chapters: List<CurrChapter> = emptyList(),
) {
    val loaded: Boolean get() = chapters.isNotEmpty()
    val allTopics: List<CurrTopic> get() = chapters.flatMap { it.topics }
}

/** ارقام لاتین داخل یک رشته را فارسی می‌کند (برای «۳.۵ ساعت»). */
private fun String.toFaDigits(): String =
    map { c -> if (c in '0'..'9') '۰' + (c - '0') else c }.joinToString("")

/**
 * دیتاست رسمی ۱۴۰۵ را از سرویس می‌گیرد.
 *
 * دیتاست ۸۱ کتاب دارد، پس همه‌چیز را یک‌جا نمی‌گیریم: اول رشته‌ها، بعد کتاب‌های
 * همان رشته و پایه، و ساختار کامل هر کتاب فقط وقتی که کاربر بازش می‌کند.
 * هر سه لایه در [Cache] می‌نشینند چون محتوای کتاب درسی در طول سال عوض نمی‌شود.
 */
object PlannerCurriculum {

    private const val TTL = 30L * 24 * 60 * 60 * 1000   // یک ماه

    private var trackMemo: List<CurrTrack> = emptyList()
    private val bookMemo = mutableMapOf<String, List<CurrBook>>()     // "track|grade" → کتاب‌ها
    private val detailMemo = mutableMapOf<String, CurrBook>()         // bookId → کتاب کامل

    /* --------------------------------------------------------------- رشته‌ها */

    suspend fun tracks(): List<CurrTrack> {
        trackMemo.takeIf { it.isNotEmpty() }?.let { return it }
        val raw = cached("planner_tracks") { PlannerApi.get("/v1/tracks") }
        val arr = raw.optJSONArray("tracks")
        val out = mutableListOf<CurrTrack>()
        for (i in 0 until (arr?.length() ?: 0)) {
            val t = arr!!.optJSONObject(i) ?: continue
            val gArr = t.optJSONArray("grades")
            val grades = mutableListOf<Pair<Int, String>>()
            for (j in 0 until (gArr?.length() ?: 0)) {
                val g = gArr!!.optJSONObject(j) ?: continue
                grades += g.optInt("grade_number") to g.optString("title")
            }
            out += CurrTrack(t.optString("track_id"), t.optString("title"), t.optInt("books"), grades)
        }
        trackMemo = out
        return out
    }

    /* ------------------------------------------------- کتاب‌های یک رشته و پایه */

    suspend fun books(track: String, grade: Int): List<CurrBook> = books(track, listOf(grade))

    /**
     * کتاب‌های یک رشته در چند پایه.
     *
     * کنکوری و فارغ‌التحصیل با یک پایه کارشان راه نمی‌افتد؛ کنکور از هر سه پایه
     * سؤال می‌دهد، پس باید بتوانند کتاب دهم و یازدهم را هم انتخاب کنند.
     */
    suspend fun books(track: String, grades: List<Int>): List<CurrBook> {
        val list = grades.filter { it > 0 }.distinct().sorted()
        if (list.isEmpty()) return emptyList()
        val key = "$track|" + list.joinToString(",")
        bookMemo[key]?.let { return it }
        val raw = cached("planner_books_${track}_" + list.joinToString("_")) {
            PlannerApi.get("/v1/curriculum?track=$track&grade=" + list.joinToString(","))
        }
        val arr = raw.optJSONArray("books")
        val out = mutableListOf<CurrBook>()
        for (i in 0 until (arr?.length() ?: 0)) {
            val b = arr!!.optJSONObject(i) ?: continue
            out += CurrBook(
                bookId = b.optString("book_id"),
                title = b.optString("title"),
                subject = b.optString("subject"),
                grade = b.optString("grade"),
                gradeNumber = b.optInt("grade_number"),
                topicCount = b.optInt("topics"),
                isKonkur = b.optBoolean("is_konkur"),
                studyMinutes = b.optInt("descriptive_minutes"),
            )
        }
        bookMemo[key] = out
        return out
    }

    /* ------------------------------------------------- ساختار کامل یک کتاب */

    suspend fun detail(book: CurrBook): CurrBook {
        detailMemo[book.bookId]?.let { return it }
        val raw = cached("planner_book_${book.bookId}") { PlannerApi.get("/v1/curriculum/${book.bookId}") }
        val full = book.copy(chapters = parseChapters(raw.optJSONObject("book") ?: raw))
        detailMemo[book.bookId] = full
        return full
    }

    private fun parseChapters(detail: JSONObject): List<CurrChapter> {
        val byChapter = mutableMapOf<String, MutableList<CurrTopic>>()
        val tArr = detail.optJSONArray("topics")
        for (i in 0 until (tArr?.length() ?: 0)) {
            val t = tArr!!.optJSONObject(i) ?: continue
            // زیرمبحث‌ها در دیتاست جدا از مبحث می‌آیند؛ پایین‌تر وصلشان می‌کنیم
            val topic = CurrTopic(
                topicId = t.optString("topic_id"),
                chapterId = t.optString("chapter_id"),
                title = t.optString("title"),
                studyMinutes = t.optInt("estimated_study_minutes"),
                testMinutes = t.optInt("test_minutes"),
                suggestedTests = t.optInt("suggested_tests"),
            )
            byChapter.getOrPut(topic.chapterId) { mutableListOf() }.add(topic)
        }
        val subs = mutableMapOf<String, MutableList<String>>()
        val sArr = detail.optJSONArray("subtopics")
        for (i in 0 until (sArr?.length() ?: 0)) {
            val s = sArr!!.optJSONObject(i) ?: continue
            subs.getOrPut(s.optString("topic_id")) { mutableListOf() }.add(s.optString("title"))
        }

        val out = mutableListOf<CurrChapter>()
        val cArr = detail.optJSONArray("chapters")
        for (i in 0 until (cArr?.length() ?: 0)) {
            val c = cArr!!.optJSONObject(i) ?: continue
            val cid = c.optString("chapter_id")
            out += CurrChapter(
                chapterId = cid,
                title = c.optString("title"),
                description = c.optString("description").takeIf { it.isNotBlank() },
                topics = byChapter[cid].orEmpty().map { it.copy(subtopics = subs[it.topicId].orEmpty()) },
            )
        }
        return out
    }

    /* ----------------------------------------------------------- ابزار */

    private suspend fun cached(key: String, fetch: suspend () -> JSONObject): JSONObject {
        Cache.get(key, TTL)?.let { raw -> runCatching { return JSONObject(raw) } }
        val fresh = fetch()
        Cache.put(key, fresh.toString())
        return fresh
    }

    /** عنوان خوانای یک مبحث از روی کتاب‌هایی که تا الان بارگذاری شده‌اند. */
    fun titleOf(topicId: String): String? =
        detailMemo.values.asSequence().flatMap { it.allTopics.asSequence() }
            .firstOrNull { it.topicId == topicId }?.title

    /** کتاب‌های کاملاً بارگذاری‌شده — گزارش شبانه از همین استفاده می‌کند. */
    fun loadedBooks(): List<CurrBook> = detailMemo.values.toList()
}
