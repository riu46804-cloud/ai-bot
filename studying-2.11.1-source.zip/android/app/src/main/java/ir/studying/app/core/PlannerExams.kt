package ir.studying.app.core

/* ======================================================================== */
/*  تقویم آزمون آزمایشی                                                     */
/* ======================================================================== */

/**
 * یک مؤسسهٔ آزمون آزمایشی.
 *
 * `available = false` یعنی هنوز تقویم آن مؤسسه را نداریم. عمداً حذفش نمی‌کنیم
 * و خاکستری نشانش می‌دهیم؛ دانش‌آموزی که قلم‌چی می‌رود باید ببیند که اسمش
 * هست و فعلاً آماده نیست، نه اینکه فکر کند اپ او را نمی‌شناسد.
 */
data class ExamProvider(
    val providerId: String,
    val title: String,
    val short: String,
    val available: Boolean,
    val noteFa: String?,
    val scheduleCount: Int,
)

/** یک آزمون پیشِ‌رو از تقویم مؤسسه. */
data class UpcomingExam(
    val step: Int,
    val date: String,
    val dateFa: String,
    val milestone: String,
    val subjects: List<String>,
)

object PlannerExams {

    private const val TTL = 7L * 24 * 60 * 60 * 1000   // یک هفته

    private var memo: List<ExamProvider> = emptyList()

    suspend fun providers(): List<ExamProvider> {
        memo.takeIf { it.isNotEmpty() }?.let { return it }
        val raw = Cache.get("planner_exam_providers", TTL)?.let { runCatching { org.json.JSONObject(it) }.getOrNull() }
            ?: PlannerApi.get("/v1/exams").also { Cache.put("planner_exam_providers", it.toString()) }
        val arr = raw.optJSONArray("providers")
        val out = mutableListOf<ExamProvider>()
        for (i in 0 until (arr?.length() ?: 0)) {
            val p = arr!!.optJSONObject(i) ?: continue
            out += ExamProvider(
                providerId = p.optString("provider_id"),
                title = p.optString("title"),
                short = p.optString("short").ifBlank { p.optString("title") },
                available = p.optBoolean("available"),
                noteFa = p.optString("note_fa").takeIf { it.isNotBlank() },
                scheduleCount = p.optInt("schedule_count"),
            )
        }
        // موجودها اول، تا انتخاب بی‌راه‌تر شود
        memo = out.sortedByDescending { it.available }
        return memo
    }

    /**
     * آزمون‌های پیشِ‌روی یک رشته و پایه.
     *
     * برای نمایش در تب برنامه است، نه برای ساخت برنامه؛ خود سرور با بلوک
     * `exam_plan` آزمون‌ها را وارد موتور می‌کند و اپ لازم نیست سرفصل را بفرستد.
     */
    suspend fun upcoming(provider: String, track: String, grade: Int, limit: Int = 4): List<UpcomingExam> {
        if (provider.isBlank() || provider == "none") return emptyList()
        val raw = runCatching {
            PlannerApi.get("/v1/exams/schedule?provider=$provider&track=$track&grade=$grade&limit=$limit")
        }.getOrNull() ?: return emptyList()
        val arr = raw.optJSONArray("upcoming")
        val out = mutableListOf<UpcomingExam>()
        for (i in 0 until (arr?.length() ?: 0)) {
            val e = arr!!.optJSONObject(i) ?: continue
            val sArr = e.optJSONArray("subjects")
            val subs = (0 until (sArr?.length() ?: 0)).mapNotNull { sArr!!.optJSONObject(it)?.optString("subject") }
            out += UpcomingExam(
                step = e.optInt("step"),
                date = e.optString("date"),
                dateFa = e.optString("date_fa"),
                milestone = e.optString("milestone"),
                subjects = subs.distinct(),
            )
        }
        return out
    }
}
