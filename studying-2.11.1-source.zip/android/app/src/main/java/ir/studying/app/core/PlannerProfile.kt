package ir.studying.app.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/* ======================================================================== */
/*  پروندهٔ درسی کاربر                                                      */
/* ======================================================================== */

/** وضعیت یک مبحث از نگاه کاربر. ترتیب اهمیت دارد: از نخوانده تا مسلط. */
enum class TopicStatus(val api: String, val labelFa: String, val mastery: Double?) {
    NOT_STARTED("not_started", "نخوانده‌ام", null),
    LEARNING("learning", "شروع کرده‌ام", 0.35),
    STUDIED("studied", "خوانده‌ام", 0.60),
    MASTERED("mastered", "مسلطم", 0.90);

    companion object {
        fun of(api: String?): TopicStatus = entries.firstOrNull { it.api == api } ?: NOT_STARTED
    }
}

/**
 * هرچه برنامه‌ریز دربارهٔ این کاربرِ مشخص می‌داند.
 *
 * چرا لازم شد: نسخهٔ اول هیچ هویتی نمی‌فرستاد، پس سرور برای همه `chat_user` را
 * می‌دید و عملاً یک برنامهٔ یکسان برای کل کاربرها می‌ساخت — همان چیزی که در
 * عمل دیده شد. حالا `student_id` نام کاربری است و وضعیت مباحث، ساعت‌های آزاد و
 * سهمیهٔ ساخت برنامه هم کنارش ذخیره می‌شود.
 *
 * همه‌چیز به نام کاربری مقید است؛ عوض‌شدن حساب روی گوشی مشترک نباید وضعیت
 * درسی نفر قبلی را به نفر بعد نشان بدهد.
 */
data class PlannerProfile(
    val studentId: String = "",
    val grade: String = "دوازدهم",
    /** شمارهٔ پایه: ۱۰، ۱۱ یا ۱۲ — مبنای فیلتر کتاب‌ها. */
    val gradeNumber: Int = 12,
    /** رشته: experimental | math | humanities | islamic */
    val field: String = "experimental",
    /**
     * فارغ‌التحصیل.
     *
     * پایهٔ جدایی ندارد: کتاب‌هایش همان سه پایه است و تقویم آزمونش همان
     * دوازدهم. فقط برای این نگه داشته می‌شود که متن‌ها درست باشند و پایهٔ
     * ۱۲ را به کسی که دیگر مدرسه نمی‌رود نچسبانیم.
     */
    val graduate: Boolean = false,
    /** مؤسسهٔ آزمون آزمایشی: maze | ghalamchi | gozine2 | kheilisabz | none */
    val examProvider: String = "none",
    /** کتاب‌هایی که برنامه روی آن‌ها چیده می‌شود (همهٔ کتاب‌های رشته و پایه). */
    val bookIds: List<String> = emptyList(),
    /** topic_id ← وضعیت. فقط مواردی که کاربر دست زده ذخیره می‌شوند. */
    val topics: Map<String, TopicStatus> = emptyMap(),
    /** کلید روز هفته (sat..fri) ← «16:00-19:00». خالی یعنی از پیش‌فرض استفاده کن. */
    val availability: Map<String, String> = emptyMap(),
    val sessionMinutes: Int = 60,
    /** ساعت آزاد روزانه برای درس خواندن. مبنای ساخت پنجره‌های زمانی پیش‌فرض است. */
    val freeHoursPerDay: Int = 3,
    val onboarded: Boolean = false,
    /** زمان ساخت آخرین برنامه. */
    val lastPlanAt: Long = 0L,
    /** تاریخ ایران و شمارندهٔ ساخت برنامه در همان روز. */
    val planDay: String = "",
    val plansToday: Int = 0,
) {
    val studiedCount: Int get() = topics.count { it.value != TopicStatus.NOT_STARTED }

    /**
     * پایه‌هایی که کتابشان باید در دسترس باشد.
     *
     * کنکوری (دوازدهم) و فارغ‌التحصیل هر سه پایه را لازم دارند؛ دهم و یازدهم
     * فقط کتاب خودشان را.
     */
    val gradeScope: List<Int>
        get() = if (graduate || gradeNumber >= 12) listOf(10, 11, 12) else listOf(gradeNumber)

    val gradeLabelFa: String get() = if (graduate) "فارغ‌التحصیل" else grade

    fun statusOf(topicId: String): TopicStatus = topics[topicId] ?: TopicStatus.NOT_STARTED
}

/**
 * ذخیره و بازخوانی پرونده.
 *
 * داخل DataStore می‌نشیند، با کلیدی که هش نام کاربری را دارد؛ همان الگویی که
 * [Cache] استفاده می‌کند، به همان دلیل: دادهٔ یک حساب نباید با حساب دیگر دیده
 * شود، حتی اگر کسی کلید را حدس بزند.
 */
object PlannerStore {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _profile = MutableStateFlow(PlannerProfile())
    val profile: StateFlow<PlannerProfile> = _profile

    /** حداکثر ساخت برنامهٔ تازه در یک روز؛ هم جلوی هدررفت اعتبار AI را می‌گیرد، هم جلوی برنامه‌عوض‌کردن وسواسی را. */
    const val MAX_PLANS_PER_DAY = 3

    /** تا این مدت بعد از ساخت برنامه، جایگزینی نیاز به تأیید کاربر دارد. */
    const val REPLACE_CONFIRM_MS = 20L * 60 * 60 * 1000

    private fun key(user: String): String {
        val h = java.security.MessageDigest.getInstance("SHA-256")
            .digest(user.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "planner_profile_$h"
    }

    suspend fun load(): PlannerProfile {
        val user = Store.username
        if (user.isNullOrBlank()) { _profile.value = PlannerProfile(); return _profile.value }
        val raw = Store.getString(key(user))
        val p = if (raw.isNullOrBlank()) PlannerProfile(studentId = user) else parse(raw, user)
        _profile.value = p
        return p
    }

    private fun parse(raw: String, user: String): PlannerProfile = runCatching {
        val o = JSONObject(raw)
        val topics = mutableMapOf<String, TopicStatus>()
        o.optJSONObject("topics")?.let { t -> t.keys().forEach { topics[it] = TopicStatus.of(t.optString(it)) } }
        val avail = mutableMapOf<String, String>()
        o.optJSONObject("availability")?.let { a -> a.keys().forEach { avail[it] = a.optString(it) } }
        PlannerProfile(
            studentId = o.optString("student_id").ifBlank { user },
            grade = o.optString("grade", "دوازدهم"),
            gradeNumber = o.optInt("grade_number", 12),
            field = o.optString("field", "experimental"),
            graduate = o.optBoolean("graduate", false),
            examProvider = o.optString("exam_provider", "none"),
            bookIds = o.optJSONArray("book_ids")?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty(),
            topics = topics,
            availability = avail,
            sessionMinutes = o.optInt("session_minutes", 60),
            freeHoursPerDay = o.optInt("free_hours_per_day", 3),
            onboarded = o.optBoolean("onboarded", false),
            lastPlanAt = o.optLong("last_plan_at", 0L),
            planDay = o.optString("plan_day"),
            plansToday = o.optInt("plans_today", 0),
        )
    }.getOrElse { PlannerProfile(studentId = user) }

    fun save(p: PlannerProfile) {
        val user = Store.username ?: return
        _profile.value = p
        val o = JSONObject()
            .put("student_id", p.studentId.ifBlank { user })
            .put("grade", p.grade)
            .put("grade_number", p.gradeNumber)
            .put("field", p.field)
            .put("graduate", p.graduate)
            .put("exam_provider", p.examProvider)
            .put("book_ids", JSONArray(p.bookIds))
            .put("topics", JSONObject().apply { p.topics.forEach { (k, v) -> put(k, v.api) } })
            .put("availability", JSONObject().apply { p.availability.forEach { (k, v) -> put(k, v) } })
            .put("session_minutes", p.sessionMinutes)
            .put("free_hours_per_day", p.freeHoursPerDay)
            .put("onboarded", p.onboarded)
            .put("last_plan_at", p.lastPlanAt)
            .put("plan_day", p.planDay)
            .put("plans_today", p.plansToday)
        scope.launch { Store.putString(key(user), o.toString()) }
    }

    /** بعد از هر ساخت موفق برنامه صدا زده می‌شود تا سهمیه و زمان به‌روز شود. */
    fun notePlanBuilt() {
        val today = IranTime.todayIso()
        val p = _profile.value
        save(
            p.copy(
                lastPlanAt = System.currentTimeMillis(),
                planDay = today,
                plansToday = if (p.planDay == today) p.plansToday + 1 else 1,
            )
        )
    }

    /** چند بار دیگر امروز می‌تواند برنامه بسازد. */
    fun remainingToday(): Int {
        val p = _profile.value
        val used = if (p.planDay == IranTime.todayIso()) p.plansToday else 0
        return (MAX_PLANS_PER_DAY - used).coerceAtLeast(0)
    }

    /** آیا برنامهٔ فعلی آن‌قدر تازه است که جایگزینی‌اش باید تأیید شود؟ */
    fun needsReplaceConfirm(): Boolean {
        val p = _profile.value
        return p.lastPlanAt > 0 && System.currentTimeMillis() - p.lastPlanAt < REPLACE_CONFIRM_MS
    }
}

/* ======================================================================== */
/*  ساخت درخواست پایه                                                       */
/* ======================================================================== */

/**
 * پروندهٔ کاربر را به `base_request` موتور ترجمه می‌کند.
 *
 * این تابع تنها جایی است که هویت و وضعیت درسی وارد چرخه می‌شود. هر مبحثی که
 * کاربر در آنبوردینگ علامت زده، با وضعیت و تسلط تخمینی‌اش فرستاده می‌شود، پس
 * موتور دیگر از صفر فرض نمی‌کند و مباحث خوانده‌شده را دوباره جلو نمی‌اندازد.
 */
fun PlannerProfile.toBaseRequest(
    books: List<String> = bookIds,
    /**
     * روشن است.
     *
     * قبلاً خاموش بود تا مدل نتواند مبحث یا زمان از خودش دربیاورد، ولی نتیجه
     * برنامه‌ای شد که ترتیبش هیچ ربطی به آزمون پیشِ‌رو و به وضعیت خودِ
     * دانش‌آموز نداشت. حالا مدل اجازهٔ ساختن مبحث ندارد — فقط ترتیب همان
     * مباحثی را که موتور از سرفصل آزمون انتخاب کرده جابه‌جا می‌کند — ولی
     * همین جابه‌جایی فرق بین «برنامهٔ قالبی» و «برنامهٔ من» است.
     */
    useAi: Boolean = true,
): JSONObject {
    val o = JSONObject()
    o.put("student", JSONObject()
        .put("student_id", studentId.ifBlank { Store.username ?: "guest" })
        .put("grade", gradeLabelFa)
        .put("field", field))
    o.put("goal", JSONObject().put("type", "general"))

    // تقویم آزمون آزمایشی. سرور خودش آزمون‌های این بازه را پیدا می‌کند،
    // سرفصلشان را به فصل کتاب نگاشت می‌کند و قبل از تاریخ هر آزمون جا می‌دهد.
    // اگر «بدون آزمون» انتخاب شده باشد چیزی نمی‌فرستیم تا رفتار موتور عوض نشود.
    if (examProvider.isNotBlank() && examProvider != "none") {
        o.put("exam_plan", JSONObject()
            .put("provider", examProvider)
            .put("track", field)
            .put("grade", gradeNumber)
            .put("graduate", graduate))
    }
    o.put("planning_mode", "balanced")
    o.put("use_ai", useAi)
    o.put("start_date", IranTime.todayIso())
    // افق را سرور تعیین می‌کند: تا یک روز بعد از آزمون بعدی. ۷ روزِ ثابت
    // باعث می‌شد آزمون‌های دوهفته‌یک‌بار ماز اصلاً داخل بازه نیفتند.
    if (examProvider.isBlank() || examProvider == "none") o.put("horizon_days", 14)
    if (books.isNotEmpty()) o.put("books", JSONArray(books))

    // مهم: اگر اینجا خالی بماند، موتور هیچ پنجرهٔ زمانی ندارد و برنامهٔ تولیدشده
    // صفر جلسه خواهد داشت (در تست زنده دقیقاً همین اتفاق افتاد). پس همیشه یا
    // ساعت‌های دلخواه کاربر را می‌فرستیم یا پنجره‌های پیش‌فرض ساخته‌شده از
    // «ساعت آزاد روزانه» را.
    val windows = if (availability.isNotEmpty()) availability else defaultAvailability(freeHoursPerDay)
    // هر روز آرایه‌ای از پنجره‌ها فرستاده می‌شود، نه یک رشتهٔ کاماخورده.
    // رشتهٔ «۰۶:۰۰-۱۵:۳۰, ۱۶:۰۰-۲۲:۳۰» را سرور یک پنجرهٔ نامعتبر می‌دید و
    // ظرفیت همهٔ روزها صفر می‌شد: برنامهٔ خالی، بدون هیچ پیام خطایی.
    o.put("available_time", JSONObject().put(
        "availability",
        JSONObject().apply {
            windows.forEach { (k, v) ->
                put(k, JSONArray().apply {
                    v.split(',', '،', ';').map { it.trim() }.filter { it.isNotEmpty() }.forEach { put(it) }
                })
            }
        }
    ))
    o.put("preferences", JSONObject()
        .put("preferred_session_minutes", sessionMinutes)
        .put("max_session_minutes", (sessionMinutes + 30).coerceAtMost(120)))

    // فقط مباحثی که کاربر واقعاً علامت زده؛ فرستادن کل فهرست با not_started
    // چیزی به موتور اضافه نمی‌کند و درخواست را بی‌دلیل بزرگ می‌کند.
    val states = JSONArray()
    topics.forEach { (id, st) ->
        if (st == TopicStatus.NOT_STARTED) return@forEach
        val e = JSONObject().put("topic_id", id).put("status", st.api)
        st.mastery?.let { e.put("mastery", it) }
        states.put(e)
    }
    if (states.length() > 0) o.put("topic_states", states)
    return o
}

/**
 * پنجره‌های زمانی پیش‌فرض بر پایهٔ ساعت آزاد روزانه.
 *
 * روزهای مدرسه از ۱۶:۰۰ شروع می‌شوند (بعد از برگشت از مدرسه) و پنجشنبه/جمعه
 * از صبح، چون معمولاً وقت بیشتری هست. طول پنجره = ساعت آزاد + نیم‌ساعت فاصله
 * بین جلسه‌ها، تا موتور واقعاً جا برای استراحت داشته باشد.
 */
fun defaultAvailability(freeHours: Int): Map<String, String> {
    val h = freeHours.coerceIn(1, 15)

    /**
     * ساعت آزاد را به پنجره تبدیل می‌کند.
     *
     * یک پنجرهٔ پیوسته فقط تا ۶ ساعت منطقی است؛ بالاتر از آن اگر همه را پشت
     * سر هم بگذاریم از نیمه‌شب رد می‌شود و موتور ساعت‌ها را دور می‌ریزد.
     * پس مازاد به یک پنجرهٔ صبح منتقل می‌شود.
     */
    fun win(startHour: Int, morningStart: Int): String {
        val slack = 30                                   // فاصلهٔ بین جلسه‌ها
        val evening = minOf(h, 6)
        val morning = h - evening
        fun span(from: Int, minutes: Int): Pair<String, Int> {
            val end = (from * 60 + minutes + slack).coerceAtMost(23 * 60 + 59)
            return "%02d:00-%02d:%02d".format(from, end / 60, end % 60) to end
        }
        val parts = mutableListOf<String>()
        var next = startHour
        if (morning > 0) {
            val (txt, end) = span(morningStart, morning * 60)
            parts += txt
            // پنجرهٔ عصر نباید با صبح هم‌پوشانی کند، وگرنه ظرفیت دوبار شمرده می‌شود
            next = maxOf(startHour, (end + 59) / 60)
        }
        parts += span(next, evening * 60).first
        return parts.joinToString(", ")
    }

    val school = win(16, 6)                              // قبل از مدرسه + بعد از مدرسه
    return mapOf(
        "sat" to school, "sun" to school, "mon" to school,
        "tue" to school, "wed" to school,
        "thu" to win(15, 8), "fri" to win(15, 9),        // تعطیل: صبح هم آزاد است
    )
}
