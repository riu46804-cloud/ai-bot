package ir.studying.app.core

/** Test totals include correct + wrong + blank; descriptive questions stay independent. */
data class QuestionTotals(val tests: Int, val descriptive: Int) {
    init { require(tests >= 0 && descriptive >= 0) }
    companion object {
        /** Unknown old data must not masquerade as a measured zero. Empty known days are zero. */
        fun sumKnown(parts: List<QuestionTotals?>): QuestionTotals? {
            if (parts.any { it == null }) return null
            return QuestionTotals(
                parts.sumOf { it!!.tests.toLong() }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
                parts.sumOf { it!!.descriptive.toLong() }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            )
        }
        fun decodeTag(raw: String?): QuestionTotals? {
            val values = raw?.split(":") ?: return null
            if (values.size != 3 || values[0] != "q") return null
            val tests = values[1].toIntOrNull()?.takeIf { it >= 0 } ?: return null
            val descriptive = values[2].toIntOrNull()?.takeIf { it >= 0 } ?: return null
            return QuestionTotals(tests, descriptive)
        }
    }
    fun encodeTag(): String = "q:$tests:$descriptive"
}
