package ir.studying.app.core

import androidx.compose.ui.graphics.Color

/**
 * نردبان لقب‌ها — اسطوره‌های شاهنامه و ایران کهن.
 *
 * منبع حقیقت سرور است (`level_title` در `game_state`)، ولی همین جدول محلی دو کار
 * می‌کند: ۱) وقتی اپ آفلاین است یا سرور قدیمی است و لقب نمی‌فرستد، اسم درست
 * نمایش داده می‌شود؛ ۲) رنگ و ایموجی هر رده را می‌دهد تا رابط کاربری فقط به یک
 * رشتهٔ متنی وابسته نباشد.
 *
 * آستانه‌ها دقیقاً همان چیزی است که سرور دارد (`sb_rank_tiers`). اگر روزی سرور
 * عوض شد، سرور برنده است: [titleFor] ابتدا مقدار سرور را برمی‌گرداند.
 */
object Ranks {

    data class Tier(
        val key: String,
        val title: String,
        val emoji: String,
        val minLevel: Int,
        val color: Color,
    )

    val all: List<Tier> = listOf(
        Tier("kiomars", "کیومرث", "🌱", 1, Color(0xFF86EFAC)),
        Tier("hushang", "هوشنگ", "🔥", 2, Color(0xFFFB923C)),
        Tier("arash", "آرش کمانگیر", "🏹", 3, Color(0xFF38BDF8)),
        Tier("gordafarid", "گردآفرید", "🗡️", 4, Color(0xFFF472B6)),
        Tier("kaveh", "کاوهٔ آهنگر", "⚒️", 6, Color(0xFFEF4444)),
        Tier("zal", "زالِ زر", "🕊️", 8, Color(0xFFE5E7EB)),
        Tier("siavash", "سیاوش", "💠", 10, Color(0xFF22D3EE)),
        Tier("esfandiar", "اسفندیارِ رویین‌تن", "🛡️", 13, Color(0xFF94A3B8)),
        Tier("rostam", "رستمِ دستان", "🦁", 16, Color(0xFFF59E0B)),
        Tier("fereydun", "فریدونِ فرخ", "👑", 20, Color(0xFFA78BFA)),
        Tier("keykhosrow", "کیخسرو", "☀️", 25, Color(0xFFFDE047)),
        Tier("simorgh", "سیمرغ", "🪶", 32, Color(0xFF2DD4BF)),
    )

    /** ردهٔ یک سطح. همیشه چیزی برمی‌گرداند؛ سطح ۰ یا منفی هم می‌شود کیومرث. */
    fun of(level: Int): Tier = all.lastOrNull { level >= it.minLevel } ?: all.first()

    /** ردهٔ بعدی، یا null اگر کاربر روی آخرین پله است. */
    fun next(level: Int): Tier? {
        val cur = of(level)
        val i = all.indexOf(cur)
        return all.getOrNull(i + 1)
    }

    /** شمارهٔ رده (۱ تا ۱۲) برای نمایش «رده ۵ از ۱۲». */
    fun rankIndex(level: Int): Int = all.indexOf(of(level)) + 1

    val count: Int get() = all.size

    /** لقب سرور را ترجیح بده؛ اگر خالی بود از جدول محلی بخوان. */
    fun titleFor(level: Int, serverTitle: String?): String =
        if (!serverTitle.isNullOrBlank()) serverTitle else of(level).title

    /** ایموجی سرور را ترجیح بده؛ اگر خالی بود از جدول محلی بخوان. */
    fun emojiFor(level: Int, serverEmoji: String?): String =
        if (!serverEmoji.isNullOrBlank()) serverEmoji else of(level).emoji

    /**
     * رنگ رده بر اساس لقب یا کلیدِ سرور.
     *
     * چرا روی هر دو تطبیق می‌دهیم: کاربرهای لیدربورد و پروفایلِ دیگران فقط
     * `level_title` دارند، ولی خودِ کاربر `level_key` هم می‌گیرد.
     */
    fun colorOf(level: Int, key: String? = null, title: String? = null): Color {
        if (!key.isNullOrBlank()) all.firstOrNull { it.key == key }?.let { return it.color }
        if (!title.isNullOrBlank()) all.firstOrNull { it.title == title }?.let { return it.color }
        return of(level).color
    }
}
