package ir.studying.app.core

import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * حساب‌وکتاب خالص صفحهٔ «گزارش».
 *
 * هیچ وابستگی‌ای به اندروید یا Compose ندارد و «امروز» را همیشه صریح می‌گیرد،
 * پس تست‌ها تقویم را ثابت نگه می‌دارند. تاریخ‌ها همان yyyy-MM-dd سرورند و
 * جمع و تفریق روزها روی شمارهٔ روز (epoch day) انجام می‌شود، نه روی ساعت؛
 * این‌طوری منطقهٔ زمانی و ساعت تابستانی‌های قدیمی هیچ روزی را جابه‌جا نمی‌کنند.
 */
object ReportStats {

    /** یک روز مطالعه همان‌طور که study_calendar می‌دهد. */
    data class Day(val minutes: Int, val sessions: Int = 0)

    // ---------------------------------------------------------------- تقویم

    /** شمارهٔ روز از ۱۹۷۰-۰۱-۰۱؛ برای ورودی نامعتبر null. */
    fun epochDay(iso: String?): Long? {
        if (iso == null || iso.length < 10 || iso[4] != '-' || iso[7] != '-') return null
        val y = iso.substring(0, 4).toIntOrNull() ?: return null
        val m = iso.substring(5, 7).toIntOrNull() ?: return null
        val d = iso.substring(8, 10).toIntOrNull() ?: return null
        if (m !in 1..12 || d !in 1..31) return null
        return civilToDays(y, m, d)
    }

    fun isoOfEpochDay(n: Long): String {
        val z = n + 719468
        val era = Math.floorDiv(z, 146097L)
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = if (mp < 10) mp + 3 else mp - 9
        val y = yoe + era * 400 + if (m <= 2) 1 else 0
        return "$y-${pad2(m)}-${pad2(d)}"
    }

    fun isoOf(gy: Int, gm: Int, gd: Int): String = "$gy-${pad2(gm.toLong())}-${pad2(gd.toLong())}"

    /** همان تاریخ، [days] روز جلوتر (منفی یعنی عقب‌تر). */
    fun shift(iso: String, days: Int): String = epochDay(iso)?.let { isoOfEpochDay(it + days) } ?: iso

    /** [count] روز پشت‌سرهم که به [endIso] ختم می‌شوند؛ قدیمی‌ترین اول. */
    fun window(endIso: String, count: Int): List<String> {
        val end = epochDay(endIso) ?: return emptyList()
        if (count <= 0) return emptyList()
        return (count - 1 downTo 0).map { isoOfEpochDay(end - it) }
    }

    /** چند روز از [fromIso] تا [toIso]؛ مثبت یعنی [toIso] بعدتر است. */
    fun daysBetween(fromIso: String, toIso: String): Int? {
        val a = epochDay(fromIso) ?: return null
        val b = epochDay(toIso) ?: return null
        return (b - a).toInt()
    }

    /** روز هفتهٔ ایرانی: ۰ = شنبه … ۶ = جمعه. */
    fun weekdayIndex(iso: String): Int =
        epochDay(iso)?.let { Math.floorMod(it + 5, 7L).toInt() } ?: 0

    /** شنبهٔ همین هفته. */
    fun weekStart(iso: String): String = shift(iso, -weekdayIndex(iso))

    private fun civilToDays(y0: Int, m: Int, d: Int): Long {
        val y = (if (m <= 2) y0 - 1 else y0).toLong()
        val era = Math.floorDiv(y, 400L)
        val yoe = y - era * 400
        val mp = (m + 9) % 12
        val doy = (153 * mp + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    private fun pad2(v: Long): String = if (v < 10) "0$v" else v.toString()

    // ---------------------------------------------------------------- خلاصه

    data class Summary(
        val days: Int,
        val total: Int,
        val activeDays: Int,
        val sessions: Int,
        val bestIso: String?,
        val bestMinutes: Int,
    ) {
        /** میانگین روی همهٔ روزهای بازه، حتی روزهای خالی. */
        val avgPerDay: Int get() = if (days > 0) (total.toFloat() / days).roundToInt() else 0
        val avgPerActiveDay: Int get() = if (activeDays > 0) (total.toFloat() / activeDays).roundToInt() else 0
        val avgSession: Int get() = if (sessions > 0) (total.toFloat() / sessions).roundToInt() else 0
    }

    fun summarize(dates: List<String>, byDate: Map<String, Day>): Summary {
        var total = 0
        var active = 0
        var sessions = 0
        var bestIso: String? = null
        var best = 0
        for (iso in dates) {
            val d = byDate[iso] ?: continue
            val m = d.minutes.coerceAtLeast(0)
            total += m
            sessions += d.sessions.coerceAtLeast(0)
            if (m > 0) active++
            if (m > best) { best = m; bestIso = iso }
        }
        return Summary(dates.size, total, active, sessions, bestIso, best)
    }

    /** درصد تغییر؛ وقتی چیزی برای مقایسه نیست null. */
    fun deltaPercent(current: Int, previous: Int): Int? {
        if (previous <= 0) return null
        return ((current - previous) * 100f / previous).roundToInt()
    }

    // ---------------------------------------------------------------- استریک

    /** روزهای پشت‌سرهم تا امروز؛ اگر امروز هنوز چیزی ثبت نشده، از دیروز می‌شمارد. */
    fun currentStreak(byDate: Map<String, Int>, todayIso: String): Int {
        val today = epochDay(todayIso) ?: return 0
        var day = if ((byDate[todayIso] ?: 0) > 0) today else today - 1
        var n = 0
        while ((byDate[isoOfEpochDay(day)] ?: 0) > 0) { n++; day-- }
        return n
    }

    data class Run(val length: Int, val endIso: String?)

    /** طولانی‌ترین زنجیرهٔ روزهای مطالعه در داده‌ای که داریم. */
    fun longestStreak(byDate: Map<String, Int>): Run {
        val days = byDate.filterValues { it > 0 }.keys.mapNotNull { epochDay(it) }.sorted()
        var best = 0
        var bestEnd: Long? = null
        var run = 0
        var prev: Long? = null
        for (d in days) {
            run = if (prev != null && d == prev + 1) run + 1 else 1
            if (run > best) { best = run; bestEnd = d }
            prev = d
        }
        return Run(best, bestEnd?.let { isoOfEpochDay(it) })
    }

    // ---------------------------------------------------------------- روند

    /** میانگین متحرک پسرو؛ نقطه‌های اول میانگینِ همان‌قدر که هست. */
    fun movingAverage(values: List<Int>, window: Int): List<Float> {
        if (window <= 1) return values.map { it.toFloat() }
        val out = ArrayList<Float>(values.size)
        var sum = 0L
        for (i in values.indices) {
            sum += values[i]
            if (i >= window) sum -= values[i - window]
            out.add(sum.toFloat() / minOf(i + 1, window))
        }
        return out
    }

    data class Weekdays(val totals: List<Int>, val counts: List<Int>) {
        /** میانگین هر روز هفته؛ مثلاً «سه‌شنبه‌ها به‌طور میانگین». */
        val averages: List<Int>
            get() = totals.indices.map { i -> if (counts[i] > 0) (totals[i].toFloat() / counts[i]).roundToInt() else 0 }
    }

    fun weekdays(dates: List<String>, byDate: Map<String, Int>): Weekdays {
        val t = IntArray(7)
        val c = IntArray(7)
        for (iso in dates) {
            val i = weekdayIndex(iso)
            c[i]++
            t[i] += (byDate[iso] ?: 0).coerceAtLeast(0)
        }
        return Weekdays(t.toList(), c.toList())
    }

    // ---------------------------------------------------------------- ساعت‌ها

    /** صبح ۵ تا ۱۲، ظهر ۱۲ تا ۱۷، عصر ۱۷ تا ۲۱، شب ۲۱ تا ۵. */
    fun dayPartOf(hour: Int): Int = when (hour) {
        in 5..11 -> 0
        in 12..16 -> 1
        in 17..20 -> 2
        else -> 3
    }

    fun dayParts(hours: List<Int>): List<Int> {
        val out = IntArray(4)
        hours.forEachIndexed { h, m -> if (h in 0..23) out[dayPartOf(h)] += m.coerceAtLeast(0) }
        return out.toList()
    }

    /** پرکارترین ساعت، یا ۱- وقتی هیچ ساعتی ثبت نشده. */
    fun peakHour(hours: List<Int>): Int {
        var best = -1
        var bestV = 0
        hours.forEachIndexed { h, m -> if (m > bestV) { bestV = m; best = h } }
        return best
    }

    /** "08:30" → ۵۱۰؛ برای متن نامعتبر null. */
    fun minuteOfDay(hm: String?): Int? {
        if (hm.isNullOrBlank()) return null
        val p = hm.trim().split(":")
        if (p.size < 2) return null
        val h = p[0].trim().toIntOrNull() ?: return null
        val m = p[1].trim().take(2).toIntOrNull() ?: return null
        if (h !in 0..24 || m !in 0..59) return null
        return (h * 60 + m).coerceAtMost(1440)
    }

    /**
     * بازهٔ یک پارت داخل روز خودش [start, end) به دقیقه.
     * پایان از «شروع + طول» ساخته می‌شود تا پارتی که از نیمه‌شب رد شده
     * برعکس کشیده نشود؛ هرچه بعد از ۲۴ باشد بریده می‌شود.
     */
    fun span(start: String?, minutes: Int): Pair<Int, Int>? {
        val s = minuteOfDay(start) ?: return null
        val e = (s + minutes.coerceAtLeast(0)).coerceAtMost(1440)
        return s to e
    }

    /** چند دقیقه از این بازه‌ها تا دقیقهٔ [nowMinute] روز گذشته بوده. */
    fun minutesUntil(spans: List<Pair<Int, Int>>, nowMinute: Int): Int =
        spans.sumOf { (s, e) -> (minOf(e, nowMinute) - s).coerceAtLeast(0) }

    // ---------------------------------------------------------------- محورها

    private val AXIS_STEPS = intArrayOf(5, 10, 15, 20, 30, 60, 90, 120, 180, 240, 300, 360, 480, 600, 720)

    /** سقف گرد محور و فاصلهٔ خط‌ها برای بیشینهٔ [value] دقیقه با [lines] خط. */
    fun niceAxis(value: Int, lines: Int = 3): Pair<Int, Int> {
        val v = value.coerceAtLeast(1)
        val n = lines.coerceAtLeast(1)
        val step = AXIS_STEPS.firstOrNull { it * n >= v } ?: ((v + n * 60 - 1) / (n * 60) * 60)
        return step * n to step
    }

    // ---------------------------------------------------------------- ماه‌ها

    data class MonthBucket(
        val year: Int,
        val month: Int,
        val minutes: Int,
        val activeDays: Int,
        /** روزهایی از این ماه که تا امروز گذشته. */
        val elapsedDays: Int,
        val firstIso: String,
    )

    fun jalaliMonthLength(jy: Int, jm: Int): Int = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        isJalaliLeap(jy) -> 30
        else -> 29
    }

    private fun isJalaliLeap(jy: Int): Boolean {
        val g = Jalali.toGregorian(jy, 12, 30)
        val back = Jalali.fromGregorian(g[0], g[1], g[2])
        return back.year == jy && back.month == 12 && back.day == 30
    }

    /** اولین روز ماه شمسی به میلادی. */
    fun jalaliMonthStart(jy: Int, jm: Int): String {
        val g = Jalali.toGregorian(jy, jm, 1)
        return isoOf(g[0], g[1], g[2])
    }

    fun jalaliOf(iso: String): Jalali.JDate? {
        val e = epochDay(iso) ?: return null
        val norm = isoOfEpochDay(e)
        return Jalali.fromGregorian(norm.substring(0, 4).toInt(), norm.substring(5, 7).toInt(), norm.substring(8, 10).toInt())
    }

    /** [count] ماه شمسی اخیر، تازه‌ترین اول، هر کدام فقط تا امروز. */
    fun jalaliMonths(byDate: Map<String, Int>, todayIso: String, count: Int): List<MonthBucket> {
        val today = epochDay(todayIso) ?: return emptyList()
        val j = jalaliOf(todayIso) ?: return emptyList()
        var jy = j.year
        var jm = j.month
        val out = ArrayList<MonthBucket>(count)
        repeat(count.coerceAtLeast(0)) {
            val len = jalaliMonthLength(jy, jm)
            val firstIso = jalaliMonthStart(jy, jm)
            val first = epochDay(firstIso) ?: return out
            var total = 0
            var active = 0
            var elapsed = 0
            for (k in 0 until len) {
                val e = first + k
                if (e > today) break
                elapsed++
                val v = (byDate[isoOfEpochDay(e)] ?: 0).coerceAtLeast(0)
                total += v
                if (v > 0) active++
            }
            out.add(MonthBucket(jy, jm, total, active, elapsed, firstIso))
            jm--
            if (jm == 0) { jm = 12; jy-- }
        }
        return out
    }

    // ---------------------------------------------------------------- نقشهٔ حرارتی

    /** سقف مقیاس: صدک ۹۰ روزهای فعال، تا یک روز ماراتنی بقیه را کم‌رنگ نکند. */
    fun heatScale(values: Collection<Int>): Int {
        val active = values.filter { it > 0 }.sorted()
        if (active.isEmpty()) return 0
        return active[((active.size - 1) * 0.9).roundToInt()]
    }

    /** ۰ = هیچ، ۱ تا ۴ = چهار پلهٔ شدت نسبت به [scale]. */
    fun heatLevel(minutes: Int, scale: Int): Int = when {
        minutes <= 0 -> 0
        scale <= 0 -> 4
        else -> ceil(minutes * 4.0 / scale).toInt().coerceIn(1, 4)
    }

    // ---------------------------------------------------------------- قالب

    /** "۲:۰۵" — برای برچسب‌های فشردهٔ نمودار. */
    fun clock(minutes: Int): String {
        val m = minutes.coerceAtLeast(0)
        val mm = m % 60
        return ("" + (m / 60) + ":" + (if (mm < 10) "0$mm" else mm.toString())).fa()
    }

    /** برچسب محور: «۴۵د»، «۲س»، «۱:۳۰». */
    fun axisLabel(minutes: Int): String = when {
        minutes <= 0 -> "۰"
        minutes < 60 -> minutes.fa() + "د"
        minutes % 60 == 0 -> (minutes / 60).fa() + "س"
        else -> clock(minutes)
    }
}
