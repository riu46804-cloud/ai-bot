package ir.studying.app.core

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

private val Context.dataStore by preferencesDataStore(name = "studying")

data class SessionState(val token: String?, val username: String?)

data class TimerPersist(
    val running: Boolean,
    val startEpochMs: Long,
    val accumMs: Long,
    val courseId: Int?,
    val endEpochMs: Long = 0L,
)

/**
 * Pomodoro survives process death now.
 *
 * The focus timer lived only in memory, so a swipe from recents or a background
 * kill silently threw away a running block; the user came back to an idle screen
 * with no idea how many minutes were lost. The deadline is stored as an absolute
 * timestamp rather than a countdown, so the remaining time stays correct even if
 * the process was dead for twenty minutes.
 */
data class PomodoroPersist(
    val phase: String = "IDLE",
    val running: Boolean = false,
    /** Phase deadline while running; timestamp of the last pause while stopped. */
    val endEpochMs: Long = 0L,
    /** Seconds left when the timer was paused. */
    val remainingSec: Int = 0,
    val completedWork: Int = 0,
    /*
     * The preset (25/50/90) used to live only in memory, so after a process
     * kill the restore path credited a 90-minute block as 25 minutes. The
     * config travels with the timer now.
     */
    val workMin: Int = 25,
    val breakMin: Int = 5,
    val longBreakMin: Int = 15,
    val cyclesBeforeLong: Int = 4,
)

/** "system" | "dark" | "light" */
data class Prefs(
    val themeMode: String = "system",
    val themeColor: String = "mint",
    val reminderEnabled: Boolean = false,
    val reminderHour: Int = 20,
    val reminderMinute: Int = 0,
    val avatar: String? = null,
    /** Bumped whenever the photo is replaced, to defeat image caching. */
    val avatarVersion: Long = 0L,
    val muted: Set<String> = emptySet(),
    val pinned: Set<String> = emptySet(),
    val pushTypes: Set<String> = setOf("follow", "post_like", "post_reply", "repost", "mention", "group_reply", "reaction", "dm"),
    val adImages: Boolean = true,
    val adVoice: Boolean = true,
    val adFiles: Boolean = false,
    val adMaxMb: Int = 10,
    val lastStudyMode: Int = 0,
    /*
     * پست خودکار در شبکهٔ اجتماعی، پیش‌فرض خاموش.
     *
     * قبلاً روشن بود و اپ از طرف کاربر پست می‌گذاشت («به هدف امروزم رسیدم…»)
     * بدون اینکه کسی اجازه داده باشد. انتشار در صفحهٔ عمومی چیزی است که کاربر
     * باید خودش روشن کند.
     */
    val autoStudyPost: Boolean = false,
)

object Store {
    private val KEY_TOKEN = stringPreferencesKey("token")
    private val KEY_USER = stringPreferencesKey("username")
    private val KEY_T_RUNNING = booleanPreferencesKey("timer_running")
    private val KEY_T_END = longPreferencesKey("timer_end")
    private val KEY_T_START = longPreferencesKey("timer_start")
    private val KEY_T_ACCUM = longPreferencesKey("timer_accum")
    private val KEY_T_COURSE = intPreferencesKey("timer_course")
    private val KEY_THEME = stringPreferencesKey("theme_mode")
    private val KEY_THEME_COLOR = stringPreferencesKey("theme_color")
    private val KEY_REM_EN = booleanPreferencesKey("reminder_enabled")
    private val KEY_REM_H = intPreferencesKey("reminder_hour")
    private val KEY_REM_M = intPreferencesKey("reminder_minute")
    private val KEY_AVATAR = stringPreferencesKey("avatar")
    private val KEY_AVATAR_VER = androidx.datastore.preferences.core.longPreferencesKey("avatar_version")
    private val KEY_DM_SEEN = intPreferencesKey("dm_seen_count")
    private val KEY_MUTED = stringSetPreferencesKey("muted")
    private val KEY_PINNED = stringSetPreferencesKey("pinned")
    private val KEY_PUSH_TYPES = stringSetPreferencesKey("push_types")
    private val KEY_LAST_NOTIF = intPreferencesKey("last_notif_id")
    private val KEY_AD_IMG = booleanPreferencesKey("ad_images")
    private val KEY_AD_VOICE = booleanPreferencesKey("ad_voice")
    private val KEY_AD_FILE = booleanPreferencesKey("ad_files")
    private val KEY_AD_MAX = intPreferencesKey("ad_max_mb")
    private val KEY_STUDY_MODE = intPreferencesKey("study_mode")
    private val KEY_AUTO_POST = booleanPreferencesKey("auto_study_post")
    private val KEY_P_PHASE = stringPreferencesKey("pomo_phase")
    private val KEY_P_RUNNING = booleanPreferencesKey("pomo_running")
    private val KEY_P_END = longPreferencesKey("pomo_end")
    private val KEY_P_REMAIN = intPreferencesKey("pomo_remaining")
    private val KEY_P_DONE = intPreferencesKey("pomo_done")
    private val KEY_P_WORK = intPreferencesKey("pomo_work_min")
    private val KEY_P_BREAK = intPreferencesKey("pomo_break_min")
    private val KEY_P_LONG = intPreferencesKey("pomo_long_min")
    private val KEY_P_CYCLES = intPreferencesKey("pomo_cycles")
    private val KEY_INTRO_SEEN = booleanPreferencesKey("intro_seen_v1")
    private val KEY_NEW_USER_GUIDE = booleanPreferencesKey("new_user_guide_pending_v1")
    private val KEY_MYKET_POPUP_SEEN = booleanPreferencesKey("myket_popup_seen_v1")

    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _session = MutableStateFlow(SessionState(null, null))
    val session: StateFlow<SessionState> get() = _session

    private val _timer = MutableStateFlow(TimerPersist(false, 0L, 0L, null))
    val timer: StateFlow<TimerPersist> get() = _timer

    private val _prefs = MutableStateFlow(Prefs())
    val prefs: StateFlow<Prefs> get() = _prefs

    private val _pomodoro = MutableStateFlow(PomodoroPersist())
    private val _introSeen = MutableStateFlow(false)
    val introSeen: StateFlow<Boolean> get() = _introSeen
    private val _newUserGuidePending = MutableStateFlow(false)
    val newUserGuidePending: StateFlow<Boolean> get() = _newUserGuidePending
    @Volatile var myketPopupSeen: Boolean = false
        private set
    val pomodoro: StateFlow<PomodoroPersist> get() = _pomodoro

    val token: String? get() = _session.value.token
    val username: String? get() = _session.value.username

    @Synchronized
    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        runBlocking {
            val p = appContext.dataStore.data.first()
            _session.value = SessionState(p[KEY_TOKEN], p[KEY_USER])
            _timer.value = TimerPersist(
                running = p[KEY_T_RUNNING] ?: false,
                startEpochMs = p[KEY_T_START] ?: 0L,
                accumMs = p[KEY_T_ACCUM] ?: 0L,
                courseId = p[KEY_T_COURSE]?.takeIf { it > 0 },
                endEpochMs = p[KEY_T_END] ?: 0L,
            )
            _pomodoro.value = PomodoroPersist(
                phase = p[KEY_P_PHASE] ?: "IDLE",
                running = p[KEY_P_RUNNING] ?: false,
                endEpochMs = p[KEY_P_END] ?: 0L,
                remainingSec = p[KEY_P_REMAIN] ?: 0,
                completedWork = p[KEY_P_DONE] ?: 0,
                workMin = p[KEY_P_WORK] ?: 25,
                breakMin = p[KEY_P_BREAK] ?: 5,
                longBreakMin = p[KEY_P_LONG] ?: 15,
                cyclesBeforeLong = p[KEY_P_CYCLES] ?: 4,
            )
            _prefs.value = Prefs(
                themeMode = p[KEY_THEME] ?: "system",
                themeColor = p[KEY_THEME_COLOR] ?: "mint",
                reminderEnabled = p[KEY_REM_EN] ?: false,
                reminderHour = p[KEY_REM_H] ?: 20,
                reminderMinute = p[KEY_REM_M] ?: 0,
                avatar = p[KEY_AVATAR],
                avatarVersion = p[KEY_AVATAR_VER] ?: 0L,
                muted = p[KEY_MUTED] ?: emptySet(),
                pinned = p[KEY_PINNED] ?: emptySet(),
                pushTypes = p[KEY_PUSH_TYPES] ?: setOf("follow", "post_like", "post_reply", "repost", "mention", "group_reply", "reaction", "dm"),
                adImages = p[KEY_AD_IMG] ?: true,
                adVoice = p[KEY_AD_VOICE] ?: true,
                adFiles = p[KEY_AD_FILE] ?: false,
                adMaxMb = p[KEY_AD_MAX] ?: 10,
                lastStudyMode = p[KEY_STUDY_MODE] ?: 0,
                autoStudyPost = p[KEY_AUTO_POST] ?: false,
            )
            _introSeen.value = p[KEY_INTRO_SEEN] ?: false
            _newUserGuidePending.value = p[KEY_NEW_USER_GUIDE] ?: false
            myketPopupSeen = p[KEY_MYKET_POPUP_SEEN] ?: false
            StudyPending.publish(p)
        }
    }

    @Synchronized
    fun saveSession(token: String, username: String) {
        val previous = this.username
        durableStudyEdit { p ->
            // Preserve interrupted work when reauthentication selects another account.
            if (previous != username) {
                if (!previous.isNullOrBlank()) archiveWork(p, previous) else quarantineWork(p)
                restoreWork(p, username)
            }
            p[KEY_TOKEN] = token; p[KEY_USER] = username
        }
        _session.value = SessionState(token, username)
        Offline.resetView()
        CourseCache.reset()
        StudyPending.publish(readStudyStrings())
        ir.studying.app.data.StudyHistory.invalidate()
        ir.studying.app.player.Pomodoro.restore(appContext)
        ir.studying.app.notify.SyncWorker.kick(appContext)
    }

    /**
     * Expiry preserves current work for reauthentication. Explicit sign-out pauses
     * timers and archives local work for its owner; it never deletes unsent study.
     * Unowned legacy work is quarantined, never assigned to the next login.
     */
    @Synchronized
    fun clearSession(explicitSignOut: Boolean = false, expectedToken: String? = token) {
        // A late 401 from a previous login must not sign out the new account.
        if (token != expectedToken) return
        val owner = username
        if (explicitSignOut) {
            // Persist elapsed time and settle any completed focus phases while
            // ownership is still intact, before hiding the account's work.
            ir.studying.app.player.Chrono.pause()
            ir.studying.app.player.Pomodoro.pause()
        }
        durableStudyEdit { p ->
            p.remove(KEY_TOKEN)
            if (explicitSignOut) {
                if (!owner.isNullOrBlank()) archiveWork(p, owner) else quarantineWork(p)
                p.remove(KEY_USER)
                clearWork(p)
                // The outbox already carries an owner per row. Keep every row,
                // including unowned legacy rows, which Offline never reattributes.
                p.remove(stringPreferencesKey("user_mood"))
            }
        }
        _session.value = SessionState(null, if (explicitSignOut) null else owner)
        Offline.resetView()
        CourseCache.reset()
        Cache.clearAll()
        ir.studying.app.data.StudyHistory.invalidate()
        StudyPending.publish(readStudyStrings())
        if (explicitSignOut) {
            ir.studying.app.player.Pomodoro.restore(appContext)
            ir.studying.app.notify.StudyNotifier.sync(appContext)
        }
    }

    private fun isWorkKey(name: String) = name.startsWith("timer_") || name.startsWith("pomo_") || name.startsWith("pomodoro_pending_")

    private fun clearWork(p: MutablePreferences) {
        p.asMap().keys.filter { isWorkKey(it.name) }.forEach { p.remove(it) }
    }

    private fun archiveWork(p: MutablePreferences, owner: String) {
        val o = org.json.JSONObject()
        p.asMap().filterKeys { isWorkKey(it.name) }.forEach { (k, v) -> o.put(k.name, v) }
        p[stringPreferencesKey("study_archive_$owner")] = o.toString()
    }

    private fun quarantineWork(p: MutablePreferences) {
        val work = p.asMap().filterKeys { isWorkKey(it.name) }
        if (work.isEmpty()) return
        val o = org.json.JSONObject()
        work.forEach { (k, v) -> o.put(k.name, v) }
        // Separate namespace: restoreWork cannot assign these records to a login.
        p[stringPreferencesKey("study_unowned_${java.util.UUID.randomUUID()}")] = o.toString()
    }

    private fun restoreWork(p: MutablePreferences, owner: String) {
        clearWork(p)
        val key = stringPreferencesKey("study_archive_$owner")
        val raw = p[key] ?: return
        val o = org.json.JSONObject(raw)
        o.keys().forEach { name ->
            when {
                name == "timer_running" || name == "pomo_running" -> p[booleanPreferencesKey(name)] = o.getBoolean(name)
                name == "timer_start" || name == "timer_end" || name == "timer_accum" || name == "pomo_end" -> p[longPreferencesKey(name)] = o.getLong(name)
                name == "pomo_phase" || name.startsWith("pomodoro_pending_") -> p[stringPreferencesKey(name)] = o.getString(name)
                else -> p[intPreferencesKey(name)] = o.getInt(name)
            }
        }
        p.remove(key)
    }

    /** Small user transitions commit before returning; no unordered fire-and-forget writes.
     * Queue transfer, timer reset and banked blocks share this same disk transaction. */
    @Synchronized
    internal fun durableStudyEdit(block: (MutablePreferences) -> Unit) {
        val p = runBlocking(Dispatchers.IO) {
            appContext.dataStore.edit {
                block(it)
                StudyPending.read(it) // Validate before commit, not while publishing an already-committed change.
            }
        }
        _timer.value = TimerPersist(p[KEY_T_RUNNING] ?: false, p[KEY_T_START] ?: 0L,
            p[KEY_T_ACCUM] ?: 0L, p[KEY_T_COURSE]?.takeIf { it > 0 }, p[KEY_T_END] ?: 0L)
        _pomodoro.value = PomodoroPersist(p[KEY_P_PHASE] ?: "IDLE", p[KEY_P_RUNNING] ?: false,
            p[KEY_P_END] ?: 0L, p[KEY_P_REMAIN] ?: 0, p[KEY_P_DONE] ?: 0,
            p[KEY_P_WORK] ?: 25, p[KEY_P_BREAK] ?: 5, p[KEY_P_LONG] ?: 15, p[KEY_P_CYCLES] ?: 4)
        StudyPending.publish(p)
    }

    internal fun readStudyStrings() = runBlocking(Dispatchers.IO) { appContext.dataStore.data.first() }

    internal fun consumeTimer(p: MutablePreferences, pomodoro: Boolean) {
        if (pomodoro) {
            p[KEY_P_PHASE] = "IDLE"; p[KEY_P_RUNNING] = false; p[KEY_P_END] = 0L
            p[KEY_P_REMAIN] = 0; p[KEY_P_DONE] = 0
        } else {
            p[KEY_T_RUNNING] = false; p[KEY_T_START] = 0L; p[KEY_T_ACCUM] = 0L; p[KEY_T_END] = 0L
        }
    }

    fun savePomodoro(p: PomodoroPersist, credits: List<StudyPending.Block> = emptyList()) {
        durableStudyEdit {
            it[KEY_P_PHASE] = p.phase; it[KEY_P_RUNNING] = p.running
            it[KEY_P_END] = p.endEpochMs; it[KEY_P_REMAIN] = p.remainingSec
            it[KEY_P_DONE] = p.completedWork
            it[KEY_P_WORK] = p.workMin; it[KEY_P_BREAK] = p.breakMin
            it[KEY_P_LONG] = p.longBreakMin; it[KEY_P_CYCLES] = p.cyclesBeforeLong
            if (credits.isNotEmpty()) StudyPending.append(it, credits)
        }
    }

    /**
     * Generic string slots, used by the offline queue and the payload cache.
     * They live here so those helpers never need their own DataStore instance,
     * which would open a second file over the same preferences and corrupt it.
     */
    suspend fun putString(key: String, value: String?) {
        val k = stringPreferencesKey(key)
        appContext.dataStore.edit { if (value == null) it.remove(k) else it[k] = value }
    }

    suspend fun getString(key: String): String? = appContext.dataStore.data.first()[stringPreferencesKey(key)]

    fun saveTimer(t: TimerPersist) {
        durableStudyEdit {
            it[KEY_T_RUNNING] = t.running; it[KEY_T_START] = t.startEpochMs
            it[KEY_T_ACCUM] = t.accumMs; it[KEY_T_COURSE] = t.courseId ?: 0; it[KEY_T_END] = t.endEpochMs
        }
    }

    fun setThemeMode(mode: String) {
        _prefs.value = _prefs.value.copy(themeMode = mode)
        scope.launch { appContext.dataStore.edit { it[KEY_THEME] = mode } }
    }

    fun setThemeColor(color: String) {
        _prefs.value = _prefs.value.copy(themeColor = color)
        scope.launch { appContext.dataStore.edit { it[KEY_THEME_COLOR] = color } }
    }

    fun setReminder(enabled: Boolean, hour: Int, minute: Int) {
        _prefs.value = _prefs.value.copy(reminderEnabled = enabled, reminderHour = hour, reminderMinute = minute)
        scope.launch {
            appContext.dataStore.edit {
                it[KEY_REM_EN] = enabled; it[KEY_REM_H] = hour; it[KEY_REM_M] = minute
            }
        }
    }

    /**
     * The server reuses the same file name for a replaced photo, so the
     * URL never changes and every cache in the chain keeps serving the old
     * bytes. A version counter gives each upload a genuinely distinct URL.
     */
    fun bumpAvatarVersion() {
        val v = System.currentTimeMillis()
        _prefs.value = _prefs.value.copy(avatarVersion = v)
        scope.launch { appContext.dataStore.edit { it[KEY_AVATAR_VER] = v } }
    }

    fun setAvatar(path: String?) {
        _prefs.value = _prefs.value.copy(avatar = path)
        scope.launch { appContext.dataStore.edit { if (path != null) it[KEY_AVATAR] = path else it.remove(KEY_AVATAR) } }
    }

    fun togglePushType(t: String) {
        val cur = _prefs.value.pushTypes.toMutableSet()
        if (!cur.remove(t)) cur.add(t)
        _prefs.value = _prefs.value.copy(pushTypes = cur)
        scope.launch { appContext.dataStore.edit { it[KEY_PUSH_TYPES] = cur } }
    }

    /** بزرگ‌ترین شناسه نوتیفی که پوش شده — برای جلوگیری از پوش تکراری. */
    fun lastNotifId(): Int = runBlocking { appContext.dataStore.data.first()[KEY_LAST_NOTIF] ?: 0 }
    fun setLastNotifId(id: Int) { scope.launch { appContext.dataStore.edit { it[KEY_LAST_NOTIF] = id } } }

    /** آخرین شناسهٔ پیامِ «منشن/ریپلای‌شدهٔ من» که کاربر دیده — ماندگار روی دستگاه، تا با بستن و باز کردن چت دوباره ظاهر نشود. */
    fun groupSeen(groupId: Int): Int = runBlocking { appContext.dataStore.data.first()[intPreferencesKey("grp_seen_$groupId")] ?: 0 }
    fun setGroupSeen(groupId: Int, msgId: Int) { scope.launch { appContext.dataStore.edit { it[intPreferencesKey("grp_seen_$groupId")] = msgId } } }

    /** همان مفهوم برای ریپلای‌های کانال (چت عمومی/رفع‌اشکال) — بدون تگ، فقط ریپلای. */
    fun channelReplySeen(channel: String): Int = runBlocking { appContext.dataStore.data.first()[intPreferencesKey("ch_reply_seen_$channel")] ?: 0 }
    fun setChannelReplySeen(channel: String, msgId: Int) { scope.launch { appContext.dataStore.edit { it[intPreferencesKey("ch_reply_seen_$channel")] = msgId } } }

    fun togglePin(key: String) {
        val cur = _prefs.value.pinned.toMutableSet()
        if (!cur.remove(key)) cur.add(key)
        _prefs.value = _prefs.value.copy(pinned = cur)
        scope.launch { appContext.dataStore.edit { it[KEY_PINNED] = cur } }
    }

    fun toggleMute(key: String) {
        val cur = _prefs.value.muted.toMutableSet()
        if (!cur.add(key)) cur.remove(key)
        _prefs.value = _prefs.value.copy(muted = cur)
        scope.launch { appContext.dataStore.edit { it[KEY_MUTED] = cur } }
    }

    fun isMuted(key: String): Boolean = _prefs.value.muted.contains(key)

    fun setAutoDownload(images: Boolean, voice: Boolean, files: Boolean, maxMb: Int) {
        _prefs.value = _prefs.value.copy(adImages = images, adVoice = voice, adFiles = files, adMaxMb = maxMb)
        scope.launch { appContext.dataStore.edit { it[KEY_AD_IMG] = images; it[KEY_AD_VOICE] = voice; it[KEY_AD_FILE] = files; it[KEY_AD_MAX] = maxMb } }
    }

    fun setAutoStudyPost(v: Boolean) {
        _prefs.value = _prefs.value.copy(autoStudyPost = v)
        scope.launch { appContext.dataStore.edit { it[KEY_AUTO_POST] = v } }
    }

    fun setLastStudyMode(m: Int) {
        _prefs.value = _prefs.value.copy(lastStudyMode = m)
        scope.launch { appContext.dataStore.edit { it[KEY_STUDY_MODE] = m } }
    }

    // ---- DM seen count (for background notification worker) ----
    suspend fun dmSeenCount(): Int = appContext.dataStore.data.first()[KEY_DM_SEEN] ?: 0
    fun setDmSeenCount(n: Int) { scope.launch { appContext.dataStore.edit { it[KEY_DM_SEEN] = n } } }

    /** Token read directly from disk — for use in background workers where the object may be fresh. */

    fun completeIntro() {
        _introSeen.value = true
        scope.launch { appContext.dataStore.edit { it[KEY_INTRO_SEEN] = true } }
    }

    fun markNewUser() {
        _introSeen.value = true
        _newUserGuidePending.value = true
        scope.launch { appContext.dataStore.edit {
            it[KEY_INTRO_SEEN] = true
            it[KEY_NEW_USER_GUIDE] = true
        } }
    }

    fun completeNewUserGuide() {
        _newUserGuidePending.value = false
        scope.launch { appContext.dataStore.edit { it[KEY_NEW_USER_GUIDE] = false } }
    }

    fun markMyketPopupSeen() {
        myketPopupSeen = true
        scope.launch { appContext.dataStore.edit { it[KEY_MYKET_POPUP_SEEN] = true } }
    }

    suspend fun tokenFromDisk(): String? = appContext.dataStore.data.first()[KEY_TOKEN]
}
