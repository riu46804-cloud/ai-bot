package ir.studying.app.core

import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Completed blocks retain their actual end date, even when registered after midnight. */
object StudyPending {
    private val KEY = stringPreferencesKey("pomodoro_pending_blocks")
    private val LEGACY = stringPreferencesKey("pomodoro_pending_minutes")
    data class Block(val minutes: Int, val at: Long)
    private val _minutes = MutableStateFlow(0)
    val minutes: StateFlow<Int> get() = _minutes

    internal fun read(p: Preferences): List<Block> {
        val raw = p[KEY]
        if (raw == null) {
            val old = p[LEGACY]?.toIntOrNull() ?: 0
            // Old builds did not save a completion date; it cannot be reconstructed.
            return if (old > 0) listOf(Block(old, System.currentTimeMillis())) else emptyList()
        }
        val a = JSONArray(raw)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Block(o.getInt("minutes"), o.getLong("at"))
        }.filter { it.minutes > 0 }
    }

    internal fun write(p: MutablePreferences, blocks: List<Block>) {
        val a = JSONArray()
        blocks.forEach { a.put(JSONObject().put("minutes", it.minutes).put("at", it.at)) }
        p[KEY] = a.toString()
        p.remove(LEGACY)
    }

    internal fun append(p: MutablePreferences, blocks: List<Block>) = write(p, read(p) + blocks)
    internal fun publish(p: Preferences) { _minutes.value = read(p).sumOf { it.minutes } }

    suspend fun load(): Int {
        Store.durableStudyEdit { write(it, read(it)) }
        return _minutes.value
    }

    suspend fun clear() { Store.durableStudyEdit { write(it, emptyList()) } }
}
