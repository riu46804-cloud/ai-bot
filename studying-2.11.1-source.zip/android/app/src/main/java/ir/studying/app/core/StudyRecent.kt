package ir.studying.app.core

import android.content.Context
import android.content.SharedPreferences
import ir.studying.app.data.StudyDetail
import org.json.JSONArray
import org.json.JSONObject

/**
 * «همان قبلی».
 *
 * چرا: کسی که هر روز سه پارت ریاضی می‌زند، هر بار باید کل درخت سرفصل‌ها را
 * باز می‌کرد و همان فصل دیروز را پیدا می‌کرد؛ همین یک کار کافی بود تا بی‌خیال
 * ثبت جزئیات شود. حالا آخرین سرفصل‌های هر درس یک ضربه فاصله دارند.
 */
object StudyRecent {

    private const val FILE = "studying_recent_detail"
    private const val K = "items"
    private const val MAX = 14

    data class Entry(
        val courseId: Int,
        val topicId: Int,
        val topicTitle: String,
        val at: Long,
        val detail: StudyDetail,
    )

    private var prefs: SharedPreferences? = null
    private var items: List<Entry> = emptyList()

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        items = decode(prefs?.getString(K, null))
    }

    private fun decode(raw: String?): List<Entry> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Entry(
                    courseId = o.optInt("course"),
                    topicId = o.optInt("topic"),
                    topicTitle = o.optString("title", ""),
                    at = o.optLong("at"),
                    detail = StudyDetail(
                        topicId = o.optInt("topic"),
                        topicTitle = o.optString("title", ""),
                        qCorrect = o.optInt("qc"), qWrong = o.optInt("qw"), qBlank = o.optInt("qb"),
                        qDescriptive = o.optInt("qd"),
                        minVideo = o.optInt("v"), minTest = o.optInt("t"), minBook = o.optInt("b"),
                        minReview = o.optInt("r"), minLearn = o.optInt("l"),
                        focus = o.optInt("f"),
                    ),
                )
            }
        }.getOrDefault(emptyList())
    }

    /** ثبت یک گزارش تازه؛ تکراری‌ها (همان درس و همان سرفصل) جایگزین می‌شوند. */
    fun push(context: Context, courseId: Int, detail: StudyDetail) {
        init(context)
        if (courseId <= 0) return
        if (detail.topicId <= 0 && detail.focus <= 0) return
        val e = Entry(courseId, detail.topicId, detail.topicTitle, System.currentTimeMillis(), detail)
        val list = (listOf(e) + items.filterNot { it.courseId == courseId && it.topicId == detail.topicId })
            .take(MAX)
        items = list
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("course", it.courseId).put("topic", it.topicId)
                    .put("title", it.topicTitle).put("at", it.at)
                    .put("qc", it.detail.qCorrect).put("qw", it.detail.qWrong)
                    .put("qb", it.detail.qBlank).put("qd", it.detail.qDescriptive)
                    .put("v", it.detail.minVideo).put("t", it.detail.minTest)
                    .put("b", it.detail.minBook).put("r", it.detail.minReview)
                    .put("l", it.detail.minLearn).put("f", it.detail.focus),
            )
        }
        runCatching { prefs?.edit()?.putString(K, arr.toString())?.apply() }
    }

    fun forCourse(courseId: Int): List<Entry> =
        items.filter { it.courseId == courseId && it.topicTitle.isNotBlank() }.sortedByDescending { it.at }
}
