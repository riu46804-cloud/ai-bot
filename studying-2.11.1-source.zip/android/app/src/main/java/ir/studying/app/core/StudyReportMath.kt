package ir.studying.app.core

import java.text.NumberFormat
import java.util.Locale

/** Pure report rules shared by registration, history and topic statistics. */
object StudyReportMath {
    const val MAX_QUESTIONS = 2000
    const val MAX_MINUTES = 1440

    /** Iranian exam score: blanks count in the denominator; three wrong cancel one correct. */
    fun examPercent(correct: Int, wrong: Int, blank: Int): Double {
        val total = correct.toLong() + wrong + blank
        return if (total <= 0L) 0.0 else (3.0 * correct - wrong) * 100.0 / (3.0 * total)
    }

    /** Answered-question accuracy is NOT the exam score. */
    fun accuracyPercent(correct: Int, wrong: Int): Double {
        val answered = correct.toLong() + wrong
        return if (answered <= 0L) 0.0 else correct * 100.0 / answered
    }

    /** Split activity minutes across real timer blocks without duplicating question counts. */
    fun splitActivities(activities: List<Int>, budgets: List<Int>): List<List<Int>> {
        require(activities.all { it >= 0 } && budgets.all { it > 0 })
        require(activities.sumOf { it.toLong() } <= budgets.sumOf { it.toLong() })
        val remaining = activities.toMutableList()
        return budgets.map { budget ->
            var free = budget
            remaining.indices.map { i ->
                val take = minOf(remaining[i], free)
                remaining[i] -= take
                free -= take
                take
            }
        }
    }

    fun formatPercent(value: Double, locale: Locale = Locale("fa")): String =
        NumberFormat.getNumberInstance(locale).apply {
            minimumFractionDigits = 1
            maximumFractionDigits = 1
            isGroupingUsed = false
            roundingMode = java.math.RoundingMode.HALF_UP
        }.format(value)
}

/** Text is kept independently from its number so clearing a field never inserts an unwanted zero. */
object StudyNumberInput {
    /** Only Latin, Persian and Arabic decimal digits; never turn '-5' into '5'. */
    fun normalize(raw: String): String? {
        val out = StringBuilder(raw.length)
        raw.forEach { ch ->
            out.append(when (ch) {
                in '0'..'9' -> ch
                in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                else -> return null
            })
        }
        return out.toString()
    }

    /** Empty optional fields mean zero at submission, not during typing. Null means invalid. */
    fun parse(raw: String, max: Int = Int.MAX_VALUE): Int? {
        val digits = normalize(raw) ?: return null
        if (digits.isEmpty()) return 0
        return digits.toIntOrNull()?.takeIf { it in 0..max }
    }
}
