package ir.studying.app.core

/** Avoid a successful old-server response silently discarding written-question counts. */
object StudyServer {
    private var readyFor: SessionState? = null
    private var checkedAt: Long = 0L

    suspend fun requireDescriptiveSupport(session: SessionState) {
        val now = System.nanoTime()
        if (readyFor == session && now - checkedAt in 0..60_000_000_000L) return
        val capabilities = try {
            Api.obj(Api.getForSession("server_capabilities", session))
        } catch (e: ApiException) {
            if (e.code == 401) throw e
            throw ApiException("سرور هنوز برای ثبت سؤال تشریحی به‌روزرسانی نشده است.", 503)
        }
        if (capabilities.optInt("api_version") < 25 || !capabilities.optBoolean("study_descriptive")) {
            throw ApiException("ابتدا مهاجرت سرور نسخهٔ ۲۵ را برای ثبت سؤال تشریحی انجام دهید.", 503)
        }
        check(Store.session.value == session) { "Session changed" }
        readyFor = session
        checkedAt = System.nanoTime()
    }
}
