package ir.studying.app.core

import org.json.JSONObject
import java.util.Locale
import java.math.BigDecimal
import java.math.RoundingMode

object SubscriptionFeatures { const val ROOM_THEMES = "room_themes" }

data class SubscriptionPlan(
    val key: String, val title: String, val sku: String, val durationDays: Int,
    val priceRial: Long, val features: Set<String>,
    /** Main (undiscounted) server price. Equal to [priceRial] unless a server offer is applied. */
    val listPriceRial: Long = priceRial,
    val discountCode: String? = null,
    val defaultDiscountApplied: Boolean = false,
) {
    val discounted: Boolean get() = priceRial > 0L && priceRial < listPriceRial
    /** Whole percent rounded down: never overstates the actual saving, and never overflows Long. */
    val discountPercent: Int get() = if (!discounted) 0 else
        BigDecimal.valueOf(listPriceRial - priceRial).multiply(BigDecimal.valueOf(100))
            .divide(BigDecimal.valueOf(listPriceRial), 0, RoundingMode.DOWN).toInt()
    companion object {
        fun from(o: JSONObject): SubscriptionPlan = SubscriptionPlan(
            o.optString("key"), o.optString("title"), o.optString("sku"),
            o.optInt("duration_days"), o.optLong("price_rial"),
            o.optJSONArray("features")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }.toSet() } ?: emptySet(),
            listPriceRial = if (o.has("list_price_rial")) o.optLong("list_price_rial") else o.optLong("price_rial"),
            defaultDiscountApplied = o.optBoolean("default_discount_applied"),
        )
    }
}

/** Server time + monotonic device time, never the editable handset wall clock. */
data class SubscriptionLease(val serverTime: Long, val observedElapsedMs: Long, val features: Map<String, Long>) {
    fun remainingSeconds(feature: String, elapsedMs: Long): Long {
        if (elapsedMs < observedElapsedMs || serverTime <= 0L) return 0L
        val now = serverTime + (elapsedMs - observedElapsedMs) / 1000L
        return ((features[feature] ?: 0L) - now).coerceAtLeast(0L)
    }
    fun allows(feature: String, elapsedMs: Long): Boolean = remainingSeconds(feature, elapsedMs) > 0L
    companion object {
        fun from(o: JSONObject, elapsedMs: Long): SubscriptionLease {
            val f = o.optJSONObject("features")
            val entries = mutableMapOf<String, Long>()
            f?.keys()?.forEach { key -> entries[key] = f.optLong(key).coerceAtLeast(0L) }
            return SubscriptionLease(o.optLong("server_time"), elapsedMs, entries)
        }
    }
}

object BillingPriceRules {
    /** Myket prices are rials. Only convert toman when explicitly labelled. */
    fun rialValue(raw: String): Long? {
        var text = raw.trim().lowercase(Locale.ROOT)
        val toman = text.contains("تومان") || text.contains("تومن")
        val rial = text.contains("ریال") || text.contains("irr") || text.contains("rial") || text.contains("﷼")
        if (toman && rial) return null
        listOf("تومان", "تومن", "ریال", "irr", "rial", "﷼").forEach { text = text.replace(it, "") }
        val digits = StringBuilder()
        text.forEach { c -> when (c) {
            in '0'..'9' -> digits.append(c)
            in '۰'..'۹' -> digits.append('0' + (c - '۰'))
            in '٠'..'٩' -> digits.append('0' + (c - '٠'))
            ',', '٬', ' ', '\t', '\u00A0', '\u202F' -> Unit
            else -> return null
        } }
        val amount = digits.toString().toLongOrNull() ?: return null
        if (amount <= 0 || (toman && amount > Long.MAX_VALUE / 10)) return null
        return if (toman) amount * 10 else amount
    }
}


object BillingPlanRules {
    fun sameTerms(displayed: SubscriptionPlan, fresh: SubscriptionPlan): Boolean =
        displayed.key == fresh.key && displayed.sku == fresh.sku &&
            displayed.priceRial == fresh.priceRial && displayed.listPriceRial == fresh.listPriceRial &&
            displayed.discountCode == fresh.discountCode && displayed.defaultDiscountApplied == fresh.defaultDiscountApplied &&
            displayed.durationDays == fresh.durationDays && displayed.features == fresh.features
}

object BillingRecoveryRules {
    private val terminal = setOf("invalid_signature", "invalid_receipt", "package_mismatch", "sku_mismatch",
        "invalid_purchase_time", "invalid_payload", "payload_mismatch", "unknown_order", "purchase_outside_window",
        "receipt_mismatch", "token_replayed", "purchase_already_consumed", "purchase_revoked", "order_not_pending", "purchase_not_paid")
    fun quarantine(httpStatus: Int, errorCode: String?): Boolean = httpStatus in setOf(409, 422) && errorCode in terminal
}


/** One server-approved discounted Myket product for a plan. Never derived from a client percentage. */
data class DiscountOffer(val planKey: String, val sku: String, val priceRial: Long, val listPriceRial: Long) {
    val savingsRial: Long get() = (listPriceRial - priceRial).coerceAtLeast(0)
}
data class DiscountQuote(val code: String, val offers: Map<String, DiscountOffer>) {
    companion object {
        fun from(o: JSONObject): DiscountQuote? {
            val code = o.optString("code").takeIf { it.isNotBlank() } ?: return null
            val a = o.optJSONArray("offers") ?: return null
            val offers = (0 until a.length()).mapNotNull { i ->
                a.optJSONObject(i)?.let {
                    DiscountOffer(it.optString("plan_key"), it.optString("sku"), it.optLong("price_rial"), it.optLong("list_price_rial"))
                }
            }.filter { it.planKey.isNotBlank() && it.sku.isNotBlank() && it.priceRial in 1 until it.listPriceRial }
                .associateBy { it.planKey }
            return if (offers.isEmpty()) null else DiscountQuote(code, offers)
        }
    }
}

object BillingDiscountRules {
    const val INVALID = "کد تخفیف باید ۳ تا ۶۴ حرف یا عدد انگلیسی باشد؛ خط تیره و زیرخط هم مجازند."
    private val pattern = Regex("^[a-z0-9][a-z0-9_-]{2,63}$")
    fun normalize(raw: String): String? =
        raw.trim { it == ' ' || it == '\t' || it == '\n' || it == '\r' || it == '\u0000' || it == '\u000B' }
            .lowercase(Locale.ROOT).takeIf { pattern.matches(it) }
    /** Display/terms plan: the offer replaces SKU and price, while the server main price is kept for comparison. */
    fun effective(plan: SubscriptionPlan, quote: DiscountQuote?): SubscriptionPlan {
        val offer = quote?.offers?.get(plan.key) ?: return plan
        if (offer.listPriceRial != plan.listPriceRial) return plan // stale base reference: never mix prices
        // A code REPLACES the default sale, even when its final price is higher. Never stack or choose min().
        return plan.copy(sku = offer.sku, priceRial = offer.priceRial, listPriceRial = offer.listPriceRial,
            discountCode = quote.code, defaultDiscountApplied = false)
    }
}
