package ir.studying.app.core

import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

/** Shared entitlement service; new paid features only need a stable feature key. */
object Subscriptions {
    data class State(
        val plans: List<SubscriptionPlan> = emptyList(),
        val catalogLoaded: Boolean = false,
        val billingReady: Boolean = false,
        val publicKey: String = "",
        val recoverySkus: Set<String> = emptySet(),
        val loaded: Boolean = false,
        val lease: SubscriptionLease? = null,
        val expiresAt: Long = 0,
        val latestPlanKey: String = "",
        val pendingConsumptions: Int = 0,
        val elapsedMs: Long = 0,
        val error: String? = null,
        val discount: DiscountQuote? = null,
        val discountBusy: Boolean = false,
        val discountError: String? = null,
    )
    private val guard = Any()
    private var owner: SessionState? = null
    private var mutationVersion = 0L
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> get() = _state
    private val _paywall = MutableStateFlow<String?>(null)
    val paywall: StateFlow<String?> get() = _paywall

    fun bind(session: SessionState) {
        synchronized(guard) {
            if (owner == session) return
            owner = session
            mutationVersion++
            _state.value = State()
            _paywall.value = null
        }
    }
    fun canAccess(feature: String): Boolean = synchronized(guard) {
        val current = Store.session.value
        !current.token.isNullOrBlank() && owner == current && _state.value.loaded &&
            _state.value.lease?.allows(feature, SystemClock.elapsedRealtime()) == true
    }
    /** Generic paid-tier gate for future app modules; feature gates stay optional. */
    fun hasActiveSubscription(): Boolean = synchronized(guard) {
        val current = Store.session.value
        val snapshot = _state.value
        if (current.token.isNullOrBlank() || owner != current || !snapshot.loaded) return@synchronized false
        val lease = snapshot.lease ?: return@synchronized false
        val now = SystemClock.elapsedRealtime()
        lease.features.keys.any { lease.allows(it, now) }
    }
    fun tick() {
        synchronized(guard) {
            if (owner == Store.session.value && _state.value.loaded) {
                _state.value = _state.value.copy(elapsedMs = SystemClock.elapsedRealtime())
            }
        }
    }
    fun openPaywall(feature: String = SubscriptionFeatures.ROOM_THEMES) { _paywall.value = feature }
    fun closePaywall() { _paywall.value = null }

    internal fun applyState(o: JSONObject, session: SessionState, mutation: Boolean = true) = synchronized(guard) {
        if (owner != session || Store.session.value != session) return@synchronized
        if (mutation) mutationVersion++
        val elapsed = SystemClock.elapsedRealtime()
        _state.value = _state.value.copy(
            loaded = true, lease = SubscriptionLease.from(o, elapsed),
            expiresAt = o.optLong("expires_at"), latestPlanKey = o.optString("latest_plan_key"),
            pendingConsumptions = o.optInt("pending_consumptions"), elapsedMs = elapsed, error = null,
        )
    }
    suspend fun refresh(): Boolean {
        val session = Store.session.value
        if (session.token.isNullOrBlank() || session.username.isNullOrBlank()) return false
        val version = synchronized(guard) { mutationVersion }
        return try {
            val catalogue = Api.obj(Api.getForSession("subscription_catalog", session))
            val status = Api.obj(Api.getForSession("subscription_state", session))
            synchronized(guard) {
                if (owner != session || Store.session.value != session) throw CancellationException("Account changed")
                if (version != mutationVersion) return@synchronized
                val plans = catalogue.optJSONArray("plans")?.let { a -> (0 until a.length()).mapNotNull { i ->
                    a.optJSONObject(i)?.let(SubscriptionPlan::from)
                } } ?: emptyList()
                _state.value = _state.value.copy(
                    plans = plans, catalogLoaded = true,
                    billingReady = catalogue.optBoolean("billing_ready") && catalogue.optString("public_key").isNotBlank(),
                    publicKey = catalogue.optString("public_key"),
                    recoverySkus = catalogue.optJSONArray("recovery_skus")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() } ?: plans.map { it.sku }.toSet(),
                    error = null,
                )
                applyState(status, session, mutation = false)
            }
            true
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            synchronized(guard) {
                if (owner == session && Store.session.value == session) {
                    _state.value = _state.value.copy(error = humanizeError(e))
                }
            }
            false
        }
    }
    /** Fetches a quote without reserving or consuming the code. */
    suspend fun quote(code: String, session: SessionState): DiscountQuote {
        val o = Api.obj(Api.postForSession("subscription_quote", JSONObject().put("code", code), session))
        return DiscountQuote.from(o) ?: throw ApiException("این کد برای پلن‌های فعلی تخفیفی ندارد.")
    }
    suspend fun applyDiscount(raw: String): Boolean {
        val code = BillingDiscountRules.normalize(raw)
        if (code == null) {
            _state.value = _state.value.copy(discountError = BillingDiscountRules.INVALID); return false
        }
        val session = Store.session.value
        if (session.token.isNullOrBlank() || session.username.isNullOrBlank()) return false
        synchronized(guard) { if (owner != session) return false; _state.value = _state.value.copy(discountBusy = true, discountError = null) }
        return try {
            val q = quote(code, session)
            synchronized(guard) {
                if (owner != session || Store.session.value != session) throw CancellationException("Account changed")
                _state.value = _state.value.copy(discount = q, discountBusy = false, discountError = null)
            }
            true
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            synchronized(guard) {
                if (owner == session && Store.session.value == session) {
                    _state.value = _state.value.copy(discountBusy = false, discountError = humanizeError(e))
                }
            }
            false
        }
    }
    fun clearDiscount() { synchronized(guard) { _state.value = _state.value.copy(discount = null, discountError = null, discountBusy = false) } }
    suspend fun createOrder(plan: SubscriptionPlan, session: SessionState): JSONObject {
        val body = JSONObject().put("plan_key", plan.key)
        plan.discountCode?.let { body.put("discount_code", it) }
        val o = Api.obj(Api.postForSession("subscription_order", body, session))
        // The user must see and accept a new price, never be charged a silent change.
        val features = o.optJSONArray("features")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() }
        val serverList = if (o.has("list_price_rial")) o.optLong("list_price_rial") else o.optLong("price_rial")
        val discountOk = if (plan.discountCode == null) !o.optBoolean("discount_applied") else
            o.optBoolean("discount_applied") && o.optString("discount_code").equals(plan.discountCode, ignoreCase = true)
        if (o.optString("sku") != plan.sku || o.optLong("price_rial") != plan.priceRial || serverList != plan.listPriceRial ||
            !discountOk || o.optInt("duration_days") != plan.durationDays || features != plan.features) {
            refresh()
            throw ApiException("مشخصات پلن تغییر کرده است؛ قیمت به‌روز را دوباره بررسی کنید.")
        }
        return o
    }
    suspend fun confirm(raw: String, signature: String, session: SessionState): JSONObject {
        val o = Api.obj(Api.postForSession("subscription_confirm", JSONObject()
            .put("purchase_data", raw).put("signature", signature), session))
        if (Store.session.value != session) throw CancellationException("Account changed")
        if (!o.optBoolean("success")) throw ApiException("تأیید خرید کامل نشد؛ خرید قبلی را بازیابی کنید.")
        val status = o.optJSONObject("subscription") ?: throw ApiException("وضعیت اشتراک از سرور نرسید؛ بازیابی خرید را بزنید.")
        applyState(status, session)
        return o
    }
    suspend fun syncPending(session: SessionState) {
        if (_state.value.pendingConsumptions <= 0) return
        val o = Api.obj(Api.postForSession("subscription_sync", JSONObject(), session))
        o.optJSONObject("subscription")?.let { applyState(it, session) }
    }
}
