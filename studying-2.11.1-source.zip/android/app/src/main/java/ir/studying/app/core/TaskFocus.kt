package ir.studying.app.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * تسکی که همین حالا رویش کار می‌شود.
 *
 * تا امروز تسک و تایمر دو دنیای جدا بودند: کاربر تسک می‌نوشت، جای دیگری زمان
 * می‌گرفت و هیچ‌وقت معلوم نمی‌شد روی هر کار چقدر وقت گذاشته. وقتی از صفحهٔ
 * تسک «شروع مطالعه» زده شود، id اینجا می‌نشیند و [ir.studying.app.ui.study.StudyViewModel]
 * بعد از ثبت هر پارت، همان دقیقه‌ها را روی این تسک هم ثبت می‌کند.
 */
object TaskFocus {
    private val _id = MutableStateFlow(0)
    val id: StateFlow<Int> get() = _id

    private val _title = MutableStateFlow("")
    val title: StateFlow<String> get() = _title

    fun select(id: Int, title: String) { _id.value = id; _title.value = title }
    fun clear() { _id.value = 0; _title.value = "" }

    /** دقیقه‌های ثبت‌شده را روی تسک فعال می‌نویسد؛ خطا هیچ‌وقت ثبت مطالعه را نمی‌شکند. */
    suspend fun credit(minutes: Int) {
        val t = _id.value
        if (t <= 0 || minutes <= 0) return
        runCatching {
            Api.post("task_spend", org.json.JSONObject().put("id", t).put("minutes", minutes))
            RefreshBus.emit("tasks")
        }
    }
}
