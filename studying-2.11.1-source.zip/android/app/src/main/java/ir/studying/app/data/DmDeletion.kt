package ir.studying.app.data

import ir.studying.app.core.Api
import ir.studying.app.core.ApiException
import ir.studying.app.core.SessionState
import org.json.JSONObject

/** A missing choice always means local deletion, never deletion for the peer. */
enum class DmDeleteScope(val api: String) {
    ME("me"), BOTH("both");
    companion object {
        fun fromBothChecked(checked: Boolean) = if (checked) BOTH else ME
    }
}

object DmDeletion {
    private fun checked(raw: String, scope: DmDeleteScope): JSONObject {
        val out = Api.obj(raw)
        if (!out.optBoolean("success") || out.optString("scope") != scope.api) {
            throw ApiException("حذف تأیید نشد؛ ابتدا نسخهٔ جدید سرور را نصب کنید.")
        }
        return out
    }

    suspend fun conversation(username: String, scope: DmDeleteScope, session: SessionState) {
        val out = checked(Api.postForSession("dm_delete_conversation",
            JSONObject().put("username", username).put("scope", scope.api), session), scope)
        if (!out.has("through_id")) throw ApiException("پاسخ حذف گفتگو معتبر نیست.")
    }

    suspend fun message(id: Int, scope: DmDeleteScope, session: SessionState) {
        val out = checked(Api.postForSession("dm_delete",
            JSONObject().put("id", id).put("scope", scope.api), session), scope)
        if (out.optInt("id") != id) throw ApiException("پاسخ حذف پیام معتبر نیست.")
    }
}
