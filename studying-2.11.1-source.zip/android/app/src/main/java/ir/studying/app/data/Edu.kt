package ir.studying.app.data

/**
 * پایه، رشته و جنسیت — هم‌تراز با `profile_lib.php`.
 *
 * چرا محلی: این فهرست‌ها در ثبت‌نام لازم‌اند، یعنی قبل از آن‌که کاربر توکنی
 * داشته باشد که بشود با آن `profile_meta` را گرفت. پس کلیدها همان کلیدهای
 * سرورند و اگر روزی سرور فهرست تازه‌ای بدهد، فقط همین فایل باید به‌روز شود.
 */
object Edu {

    data class Item(val key: String, val label: String, val emoji: String = "")

    val grades: List<Item> = listOf(
        Item("g1", "اول دبستان"), Item("g2", "دوم دبستان"), Item("g3", "سوم دبستان"),
        Item("g4", "چهارم دبستان"), Item("g5", "پنجم دبستان"), Item("g6", "ششم دبستان"),
        Item("g7", "هفتم"), Item("g8", "هشتم"), Item("g9", "نهم"),
        Item("g10", "دهم"), Item("g11", "یازدهم"), Item("g12", "دوازدهم"),
        Item("grad", "فارغ‌التحصیل"),
    )

    val fields: List<Item> = listOf(
        Item("math", "ریاضی و فیزیک", "📐"),
        Item("exp", "علوم تجربی", "🧪"),
        Item("human", "علوم انسانی", "📜"),
        Item("islamic", "علوم و معارف اسلامی", "🕌"),
        Item("art", "هنر", "🎨"),
        Item("tech", "فنی و حرفه‌ای", "🔧"),
        Item("voc", "کاردانش", "🛠"),
    )

    val genders: List<Item> = listOf(
        Item("male", "پسر", "👦"),
        Item("female", "دختر", "👧"),
    )

    /** رشته فقط از دهم به بالا معنی دارد — دقیقاً مثل سرور. */
    private val needFieldKeys = setOf("g10", "g11", "g12", "grad")

    fun needsField(gradeKey: String?): Boolean = gradeKey != null && gradeKey in needFieldKeys

    fun gradeLabel(key: String?): String = grades.firstOrNull { it.key == key }?.label ?: ""
    fun fieldLabel(key: String?): String = fields.firstOrNull { it.key == key }?.label ?: ""
    fun genderLabel(key: String?): String = genders.firstOrNull { it.key == key }?.label ?: ""

    /**
     * نام کاربری فقط حروف و ارقام انگلیسی.
     * همان قانون سرور است؛ اینجا ورودی همان لحظه پاک می‌شود تا کاربر بعد از
     * پر کردن کل فرم با پیام خطا روبه‌رو نشود.
     */
    fun cleanUsername(raw: String): String =
        raw.filter { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '_' }.take(30)
}
