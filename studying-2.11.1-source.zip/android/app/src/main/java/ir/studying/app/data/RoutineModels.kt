package ir.studying.app.data

import ir.studying.app.core.int
import ir.studying.app.core.objects
import ir.studying.app.core.str
import ir.studying.app.core.strOrNull
import org.json.JSONArray
import org.json.JSONObject

/**
 * روتین = مجموعه‌ای نام‌دار از کارهای تکرارشونده با برنامهٔ روزانه و استریک.
 *
 * چرا موجودیت جدا: «تکرار» تا نسخهٔ قبل فقط یک ستون روی تسک بود، پس چند کارِ
 * هرروزه نه هویت مشترک داشتند، نه پیشرفت گروهی و نه زنجیرهٔ روزانه.
 */
data class RoutineItem(
    val id: Int = 0,
    val title: String,
    val dueTime: String? = null,
    val estimateMin: Int = 0,
    val priority: String = "normal",
    val course: String = "",
) {
    val dueHm: String? get() = dueTime?.takeIf { it.length >= 4 }?.take(5)

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title)
        .put("due_time", dueTime ?: "")
        .put("estimate_min", estimateMin)
        .put("priority", priority)
        .put("course", course)

    companion object {
        fun from(o: JSONObject) = RoutineItem(
            o.int("id"), o.str("title"),
            o.strOrNull("due_time")?.takeIf { it.isNotBlank() && it != "null" },
            o.int("estimate_min"),
            o.str("priority").ifEmpty { "normal" },
            o.str("course"),
        )
    }
}

/** یک روز از نقشهٔ ۳۰ روزهٔ روتین. state: ۰ ناتمام، ۱ کامل، ۲ استراحت. */
data class RoutineDay(val day: String, val done: Int, val total: Int, val state: Int)

data class Routine(
    val id: Int,
    val title: String,
    val emoji: String = "🌅",
    val color: String = "",
    /** daily | weekdays | dow:0,2,4 */
    val days: String = "daily",
    val startTime: String? = null,
    val active: Boolean = true,
    val items: List<RoutineItem> = emptyList(),
    val todayTotal: Int = 0,
    val todayDone: Int = 0,
    val scheduledToday: Boolean = true,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val history: List<RoutineDay> = emptyList(),
) {
    val startHm: String? get() = startTime?.takeIf { it.length >= 4 }?.take(5)
    val progress: Float get() = if (todayTotal == 0) 0f else todayDone.toFloat() / todayTotal
    val completedToday: Boolean get() = todayTotal > 0 && todayDone >= todayTotal
    val daysLabel: String get() = when {
        days == "daily" -> "هر روز"
        days == "weekdays" -> "شنبه تا چهارشنبه"
        days.startsWith("dow:") -> days.removePrefix("dow:").split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .joinToString("، ") { DAY_NAMES.getOrElse(it) { "" } }
            .ifBlank { "هفتگی" }
        else -> "هر روز"
    }
    /** ایندکس روزهای انتخاب‌شده (۰=شنبه) برای فرم ویرایش. */
    val selectedDays: Set<Int> get() = when {
        days == "daily" -> (0..6).toSet()
        days == "weekdays" -> (0..4).toSet()
        days.startsWith("dow:") -> days.removePrefix("dow:").split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
        else -> (0..6).toSet()
    }

    companion object {
        val DAY_NAMES = listOf("شنبه", "یک‌شنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه")
        val DAY_SHORT = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

        /** مجموعهٔ روزها → قانون سرور. */
        fun rule(days: Set<Int>): String = when {
            days.size >= 7 -> "daily"
            days == setOf(0, 1, 2, 3, 4) -> "weekdays"
            days.isEmpty() -> "daily"
            else -> "dow:" + days.sorted().joinToString(",")
        }

        fun from(o: JSONObject) = Routine(
            id = o.int("id"),
            title = o.str("title"),
            emoji = o.str("emoji").ifEmpty { "🌅" },
            color = o.str("color"),
            days = o.str("days").ifEmpty { "daily" },
            startTime = o.strOrNull("start_time")?.takeIf { it.isNotBlank() && it != "null" },
            active = o.int("active") == 1,
            items = (o.optJSONArray("items") ?: JSONArray()).objects().map { RoutineItem.from(it) },
            todayTotal = o.int("today_total"),
            todayDone = o.int("today_done"),
            scheduledToday = o.int("scheduled_today") == 1,
            streak = o.int("streak"),
            bestStreak = o.int("best_streak"),
            history = (o.optJSONArray("history") ?: JSONArray()).objects().map {
                RoutineDay(it.str("day"), it.int("done"), it.int("total"), it.int("state"))
            },
        )

        fun list(a: JSONArray) = a.objects().map { from(it) }
    }
}

/** قالب‌های آماده تا کاربر از صفر شروع نکند. */
data class RoutineTemplate(
    val emoji: String,
    val title: String,
    val days: Set<Int>,
    val startTime: String?,
    val items: List<RoutineItem>,
)

val RoutineTemplates: List<RoutineTemplate> = listOf(
    RoutineTemplate("🌅", "صبح مطالعه", (0..6).toSet(), "07:00", listOf(
        RoutineItem(title = "مرور فلش‌کارت‌های دیروز", estimateMin = 15),
        RoutineItem(title = "یک پارت تمرکز ۵۰ دقیقه‌ای", estimateMin = 50),
        RoutineItem(title = "نوشتن سه هدف امروز", estimateMin = 5),
    )),
    RoutineTemplate("🌙", "مرور شب", (0..6).toSet(), "21:00", listOf(
        RoutineItem(title = "مرور درس‌های امروز", estimateMin = 20),
        RoutineItem(title = "حل ۱۰ تست از مبحث امروز", estimateMin = 20),
        RoutineItem(title = "برنامهٔ فردا", estimateMin = 5),
    )),
    RoutineTemplate("📚", "روز کنکور", setOf(0, 1, 2, 3, 4), "08:00", listOf(
        RoutineItem(title = "ریاضی — دو پارت تمرکز", estimateMin = 100, priority = "high"),
        RoutineItem(title = "زیست — تست زمان‌دار", estimateMin = 45),
        RoutineItem(title = "مرور اشتباهات آزمون", estimateMin = 30),
    )),
    RoutineTemplate("💪", "سلامت و تمرکز", (0..6).toSet(), "18:00", listOf(
        RoutineItem(title = "۲۰ دقیقه پیاده‌روی", estimateMin = 20),
        RoutineItem(title = "۱۰ دقیقه تنفس/مدیتیشن", estimateMin = 10),
        RoutineItem(title = "خواب قبل از ۱۲", priority = "low"),
    )),
)
