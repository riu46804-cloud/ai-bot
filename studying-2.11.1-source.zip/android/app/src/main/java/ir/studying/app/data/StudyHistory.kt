package ir.studying.app.data

import ir.studying.app.core.QuestionTotals
import ir.studying.app.core.Api
import ir.studying.app.core.IranTime
import ir.studying.app.core.Store
import kotlinx.coroutines.CancellationException
import ir.studying.app.core.int
import ir.studying.app.core.objects
import ir.studying.app.core.strOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Exact per-course study data for ANY day in the past.
 *
 * The API only ever exposed a course split for today (study_today) and for
 * yesterday (analytics_hourly). Everything older showed a bare total, which is
 * why the calendar used to say the breakdown was not kept.
 *
 * It is kept. study_by_course?days=N returns per-course totals for the window
 * CURDATE()-N .. today, so the window for N minus the window for N-1 is
 * exactly the single day CURDATE()-N. Two cheap requests reconstruct any past
 * day precisely, and because the windows are cached, walking further back
 * through the calendar costs one extra request per day.
 */
object StudyHistory {

    data class DayStudy(
        val dateIso: String,
        val daysAgo: Int,
        val totalMinutes: Int,
        val courses: List<CourseMinutes>,
        val sessions: List<HourlyPart>,
        /** Session start/end times exist for today and yesterday only. */
        val hasSessionTimeline: Boolean,
    ) {
        val questionTotals: QuestionTotals? get() = if (hasSessionTimeline)
            QuestionTotals.sumKnown(sessions.map { it.questionTotals }) else null
    }

    private val lock = Mutex()
    private val cumulativeCache = java.util.concurrent.ConcurrentHashMap<Int, Map<String, CourseMinutes>>()
    private val dayCache = java.util.concurrent.ConcurrentHashMap<String, DayStudy>()
    private val generation = java.util.concurrent.atomic.AtomicLong()
    private var cacheScope = ""

    /** Called after a session is saved, so the caches cannot go stale. */
    fun invalidate() {
        generation.incrementAndGet()
        cumulativeCache.clear()
        dayCache.clear()
    }

    private fun group(parts: List<HourlyPart>): List<CourseMinutes> =
        parts.groupBy { it.course }
            .map { (n, ps) -> CourseMinutes(n, ps.first().icon, ps.sumOf { it.minutes }) }
            .sortedByDescending { it.minutes }

    private suspend fun cumulative(days: Int): Map<String, CourseMinutes> {
        cumulativeCache[days]?.let { return it }
        val map = LinkedHashMap<String, CourseMinutes>()
        val o = Api.obj(Api.get(ACT_BY_COURSE, PARAM_DAYS to days.toString()))
        o.optJSONArray(KEY_COURSES)?.objects()?.forEach { c -> putCourse(map, c) }
        cumulativeCache[days] = map
        return map
    }

    private fun subtract(
        newer: Map<String, CourseMinutes>,
        older: Map<String, CourseMinutes>,
    ): List<CourseMinutes> {
        val out = ArrayList<CourseMinutes>()
        for ((n, c) in newer) {
            val m = c.minutes - (older[n]?.minutes ?: 0)
            if (m > 0) out.add(CourseMinutes(n, c.icon, m))
        }
        out.sortByDescending { it.minutes }
        return out
    }

    private fun putCourse(map: LinkedHashMap<String, CourseMinutes>, c: org.json.JSONObject) {
        val n = c.strOrNull(KEY_NAME) ?: FALLBACK_COURSE
        map[n] = CourseMinutes(n, c.strOrNull(KEY_ICON) ?: FALLBACK_ICON, c.int(KEY_MINUTES))
    }

    private fun coursesOf(o: org.json.JSONObject): List<CourseMinutes> {
        val map = LinkedHashMap<String, CourseMinutes>()
        o.optJSONArray(KEY_COURSES)?.objects()?.forEach { c -> putCourse(map, c) }
        return map.values.sortedByDescending { it.minutes }
    }

    private const val ACT_DAY = "study_day"
    private const val ACT_BY_COURSE = "study_by_course"
    private const val ACT_HOURLY = "analytics_hourly"
    private const val ACT_TODAY = "study_today"
    private const val PARAM_DAYS = "days"
    private const val PARAM_DATE = "date"
    private const val KEY_COURSES = "courses"
    private const val KEY_SESSIONS = "sessions"
    private const val KEY_NAME = "name"
    private const val KEY_ICON = "icon"
    private const val KEY_MINUTES = "minutes"
    private const val KEY_TOTAL = "total_minutes"
    private const val FALLBACK_COURSE = "بدون درس"
    private const val FALLBACK_ICON = "📖"

    /** Preferred path: one request, works for every date, needs api.php v3. */
    private suspend fun viaStudyDay(iso: String): DayStudy? {
        val o = try { Api.obj(Api.get(ACT_DAY, PARAM_DATE to iso)) }
        catch (e: CancellationException) { throw e }
        catch (e: ir.studying.app.core.ApiException) {
            if (e.code == 404) return null else throw e
        }
        if (o.has("error") || !o.has(KEY_TOTAL)) return null
        val parts = o.optJSONArray(KEY_SESSIONS)?.let { HourlyPart.list(it) } ?: emptyList()
        return DayStudy(iso, IranTime.daysAgoOf(iso), o.int(KEY_TOTAL), coursesOf(o), parts, true)
    }

    /** Fallback for an un-upgraded server. */
    private suspend fun viaLegacy(daysAgo: Int, iso: String): DayStudy {
        if (daysAgo == 0) {
            val t = StudyToday.from(Api.obj(Api.get(ACT_TODAY)))
            val p = hourly("today_parts")
            val c = t?.courses?.takeIf { it.isNotEmpty() } ?: group(p)
            return DayStudy(iso, 0, t?.totalMinutes ?: p.sumOf { it.minutes }, c, p, true)
        }
        if (daysAgo == 1) {
            val p = hourly("yesterday_parts")
            return DayStudy(iso, 1, p.sumOf { it.minutes }, group(p), p, true)
        }
        val c = subtract(cumulative(daysAgo), cumulative(daysAgo - 1))
        return DayStudy(iso, daysAgo, c.sumOf { it.minutes }, c, emptyList(), false)
    }

    private suspend fun hourly(key: String): List<HourlyPart> =
        Api.obj(Api.get(ACT_HOURLY)).optJSONArray(key)?.let { HourlyPart.list(it) } ?: emptyList()

    /** Full course split for the Tehran day [daysAgo] days before today. */
    suspend fun day(daysAgo: Int): DayStudy = withContext(Dispatchers.IO) {
        lock.withLock {
            inScope {
                val iso = IranTime.isoDaysAgo(daysAgo)
                dayCache[iso] ?: (viaStudyDay(iso) ?: viaLegacy(daysAgo, iso)).also {
                    if (daysAgo > 0) dayCache[iso] = it
                }
            }
        }
    }

    private suspend fun <T> inScope(load: suspend () -> T): T {
        val session = Store.session.value
        check(!session.username.isNullOrBlank() && !session.token.isNullOrBlank())
        val scope = session.username + "|" + IranTime.todayIso()
        if (cacheScope != scope) { invalidate(); cacheScope = scope }
        val version = generation.get()
        val result = try { load() } catch (e: Exception) { invalidate(); throw e }
        if (Store.session.value != session || scope != Store.username + "|" + IranTime.todayIso() || generation.get() != version) {
            invalidate()
            throw CancellationException("Study history changed")
        }
        return result
    }

    suspend fun forDate(dateIso: String): DayStudy? {
        val n = IranTime.daysAgoOf(dateIso)
        if (n < 0) return null
        return day(n)
    }

    suspend fun rangeCourses(days: Int): List<CourseMinutes> = withContext(Dispatchers.IO) {
        lock.withLock { inScope { cumulative(days).values.sortedByDescending { it.minutes } } }
    }
}
