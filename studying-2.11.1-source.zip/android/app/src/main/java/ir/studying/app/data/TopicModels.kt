package ir.studying.app.data

import ir.studying.app.core.StudyReportMath
import ir.studying.app.core.Api
import ir.studying.app.core.int
import ir.studying.app.core.intOrNull
import ir.studying.app.core.objects
import ir.studying.app.core.str
import org.json.JSONArray
import org.json.JSONObject

/**
 * جزئیات درس‌ها: فصل → بخش → پارت.
 *
 * چرا درخت تودرتو: سرور خودش ساختار را تودرتو می‌دهد تا کلاینت مجبور نباشد
 * روی هر بار باز شدن صفحه، والد و فرزند را دوباره به هم بچسباند.
 */
data class CourseTopic(
    val id: Int,
    val parentId: Int,
    val level: Int,
    val title: String,
    val done: Boolean,
    val children: List<CourseTopic>,
) {
    /** همهٔ گره‌ها به صورت تخت، همراه با مسیر خوانا («فصل ۱ › رونویسی»). */
    fun flatten(prefix: String = ""): List<Pair<CourseTopic, String>> {
        val path = if (prefix.isEmpty()) title else "$prefix › $title"
        return listOf(this to path) + children.flatMap { it.flatten(path) }
    }

    companion object {
        fun from(o: JSONObject): CourseTopic = CourseTopic(
            id = o.int("id"),
            parentId = o.int("parent_id"),
            level = o.int("level"),
            title = o.str("title"),
            done = o.int("done") == 1,
            children = o.optJSONArray("children")?.objects()?.map { from(it) } ?: emptyList(),
        )
        fun list(a: JSONArray?): List<CourseTopic> = a?.objects()?.map { from(it) } ?: emptyList()
    }
}

/** آمار تجمیعی یک سرفصل (از روی پارت‌های ثبت‌شده). */
data class TopicStat(
    val topicId: Int,
    val minutes: Int,
    val parts: Int,
    val qTotal: Int,
    val qCorrect: Int,
    val qWrong: Int,
    val qBlank: Int,
    val focus: Int?,
    val qDescriptive: Int = 0,
) {
    val accuracy: Double get() = StudyReportMath.accuracyPercent(qCorrect, qWrong)
    val examPercent: Double get() = StudyReportMath.examPercent(qCorrect, qWrong, qBlank)

    companion object {
        fun from(o: JSONObject) = TopicStat(
            o.int("topic_id"), o.int("minutes"), o.int("parts"),
            o.int("q_total"), o.int("q_correct"), o.int("q_wrong"), o.int("q_blank"),
            o.intOrNull("focus"), o.int("q_descriptive"),
        )
        fun list(a: JSONArray?): List<TopicStat> = a?.objects()?.map { from(it) } ?: emptyList()
    }
}

/** درس آمادهٔ سرور (بر اساس پایه و رشته). */
data class ReadyCourse(
    val id: Int,
    val name: String,
    val icon: String,
    val color: String,
    val gradeLabel: String,
    val fieldLabel: String?,
    val topicCount: Int,
) {
    companion object {
        fun from(o: JSONObject) = ReadyCourse(
            o.int("id"), o.str("name"), o.str("icon").ifEmpty { "📖" }, o.str("color"),
            o.str("grade_label"), o.str("field_label").ifEmpty { null }, o.int("topic_count"),
        )
        fun list(a: JSONArray?): List<ReadyCourse> = a?.objects()?.map { from(it) } ?: emptyList()
    }
}

/**
 * جزئیات یک گزارش مطالعه. همهٔ فیلدها اختیاری‌اند؛ اگر کاربر چیزی پر نکند،
 * پارت دقیقاً مثل قبل (فقط دقیقه و درس) ثبت می‌شود.
 */
data class StudyDetail(
    val topicId: Int = 0,
    val topicTitle: String = "",
    val qCorrect: Int = 0,
    val qWrong: Int = 0,
    val qBlank: Int = 0,
    val minVideo: Int = 0,
    val minTest: Int = 0,
    val minBook: Int = 0,
    val minReview: Int = 0,
    val minLearn: Int = 0,
    val focus: Int = 0,
    val note: String = "",
    val qDescriptive: Int = 0,
) {
    val qTotal: Int get() = qCorrect + qWrong + qBlank
    val examPercent: Double get() = StudyReportMath.examPercent(qCorrect, qWrong, qBlank)
    val accuracy: Double get() = StudyReportMath.accuracyPercent(qCorrect, qWrong)
    val activityMinutes: Int get() = minVideo + minTest + minBook + minReview + minLearn
    val isEmpty: Boolean
        get() = topicId <= 0 && qTotal == 0 && qDescriptive == 0 && focus <= 0 && note.isBlank() &&
            minVideo + minTest + minBook + minReview + minLearn == 0

    fun validationError(minutes: Int): String? {
        val counts = listOf(qCorrect, qWrong, qBlank, qDescriptive)
        if (counts.any { it !in 0..StudyReportMath.MAX_QUESTIONS } ||
            listOf(qCorrect, qWrong, qBlank).sumOf { it.toLong() } > StudyReportMath.MAX_QUESTIONS)
            return "تعداد تست یا سؤال تشریحی نامعتبر است (حداکثر ۲۰۰۰)"
        val times = listOf(minVideo, minTest, minBook, minReview, minLearn)
        if (times.any { it !in 0..StudyReportMath.MAX_MINUTES } ||
            times.sumOf { it.toLong() } > minutes.toLong())
            return "مجموع زمان فعالیت‌ها نباید از زمان مطالعه بیشتر باشد"
        return null
    }

    /** Questions and note belong to the registration once; topic/focus cover every block. */
    fun splitAcross(blockMinutes: List<Int>): List<StudyDetail> {
        validationError(blockMinutes.sum()).let { require(it == null) { it.orEmpty() } }
        val times = StudyReportMath.splitActivities(
            listOf(minVideo, minTest, minBook, minReview, minLearn), blockMinutes,
        )
        return times.mapIndexed { i, t ->
            copy(qCorrect = if (i == 0) qCorrect else 0, qWrong = if (i == 0) qWrong else 0,
                qBlank = if (i == 0) qBlank else 0, qDescriptive = if (i == 0) qDescriptive else 0,
                minVideo = t[0], minTest = t[1], minBook = t[2], minReview = t[3], minLearn = t[4],
                note = if (i == 0) note else "")
        }
    }

    fun toJson(): JSONObject = JSONObject()
        .put("topic_id", topicId)
        .put("q_total", qTotal)
        .put("q_correct", qCorrect)
        .put("q_wrong", qWrong)
        .put("q_blank", qBlank)
        .put("q_descriptive", qDescriptive)
        .put("min_video", minVideo)
        .put("min_test", minTest)
        .put("min_book", minBook)
        .put("min_review", minReview)
        .put("min_learn", minLearn)
        .put("focus_score", focus)
        .put("note", note)

    companion object {
        fun from(o: JSONObject) = StudyDetail(
            topicId = o.int("topic_id"),
            topicTitle = o.str("topic"),
            qDescriptive = o.int("q_descriptive"),
            qCorrect = o.int("q_correct"), qWrong = o.int("q_wrong"), qBlank = o.int("q_blank"),
            minVideo = o.int("min_video"), minTest = o.int("min_test"), minBook = o.int("min_book"),
            minReview = o.int("min_review"), minLearn = o.int("min_learn"),
            focus = o.intOrNull("focus_score") ?: 0,
            note = o.str("note"),
        )
        fun parse(raw: String?): StudyDetail? = raw?.takeIf { it.isNotBlank() }
            ?.let { runCatching { from(JSONObject(it)) }.getOrNull() }
    }
}

/** لایهٔ شبکهٔ جزئیات درس‌ها. همهٔ خطاها به بالا پرتاب می‌شوند تا UI پیام بدهد. */
object TopicRepo {

    /** درخت سرفصل‌ها + آمار + اینکه اصلاً ساختارش روی سرور نصب هست یا نه. */
    data class Tree(
        val topics: List<CourseTopic>,
        val stats: List<TopicStat>,
        val notReady: Boolean = false,
    )

    suspend fun tree(courseId: Int): Tree {
        val o = Api.obj(Api.get("course_topics", "course_id" to courseId.toString()))
        return Tree(
            CourseTopic.list(o.optJSONArray("topics")),
            TopicStat.list(o.optJSONArray("stats")),
            o.optBoolean("not_ready", false),
        )
    }

    suspend fun topics(courseId: Int): Pair<List<CourseTopic>, List<TopicStat>> =
        tree(courseId).let { it.topics to it.stats }

    /**
     * نصب/تعمیر ساختار «جزئیات درس‌ها» روی سرور.
     *
     * چرا از داخل اپ: نصب تا حالا فقط با باز کردن دستی یک آدرس روی سرور ممکن
     * بود و اگر انجام نمی‌شد، این بخش بی‌صدا خالی می‌ماند.
     */
    suspend fun setup(): Boolean =
        Api.obj(Api.post("curriculum_setup", JSONObject())).optInt("ready") == 1

    suspend fun save(courseId: Int, title: String, parentId: Int = 0, level: Int = 0, id: Int = 0): Int {
        val body = JSONObject().put("course_id", courseId).put("title", title)
            .put("parent_id", parentId).put("level", level)
        if (id > 0) body.put("id", id)
        return Api.obj(Api.post("course_topics", body)).int("id")
    }

    suspend fun rename(courseId: Int, id: Int, title: String) { save(courseId, title, id = id) }

    suspend fun delete(id: Int) { Api.delete("course_topics", "id" to id.toString()) }

    suspend fun reorder(ids: List<Int>) {
        Api.post("course_topic_reorder", JSONObject().put("ids", JSONArray(ids)))
    }

    suspend fun ready(all: Boolean = false): List<ReadyCourse> {
        val q = if (all) arrayOf("all" to "1") else emptyArray()
        return ReadyCourse.list(Api.obj(Api.get("curriculum_list", *q)).optJSONArray("courses"))
    }

    suspend fun readyDetail(id: Int): List<CourseTopic> =
        CourseTopic.list(Api.obj(Api.get("curriculum_detail", "id" to id.toString())).optJSONArray("topics"))

    /** وارد کردن یک درس آماده به حساب کاربر؛ شناسهٔ درسِ ساخته‌شده برمی‌گردد. */
    suspend fun importCourse(id: Int): Int =
        Api.obj(Api.post("curriculum_import", JSONObject().put("id", id))).int("course_id")

    /** ویرایش جزئیات یک پارت ثبت‌شده. */
    suspend fun updatePart(partId: Int, detail: StudyDetail) {
        detail.validationError(StudyReportMath.MAX_MINUTES).let { require(it == null) { it.orEmpty() } }
        val session = ir.studying.app.core.Store.session.value
        if (detail.qDescriptive > 0) ir.studying.app.core.StudyServer.requireDescriptiveSupport(session)
        Api.postForSession("study_part_detail", detail.toJson().put("id", partId), session)
    }
}
