package ir.studying.app.focus

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock

/**
 * نگهبان اپِ پیش‌زمینه.
 *
 * موتور «آمار مصرف» کارش این است: هر چند صد میلی‌ثانیه رویدادهای
 * `UsageStatsManager.queryEvents` را می‌خواند و آخرین اپی که به پیش‌زمینه آمده را
 * پیدا می‌کند.
 *
 * دو نکتهٔ مهم که نسخهٔ قبلی را سوراخ کرده بود:
 *
 * 1. `queryUsageStats` (تجمیعی) به درد تشخیص لحطه‌ای نمی‌خورد؛ روی بعضی برندها
 *    چند ده ثانیه تاخیر دارد. فقط `queryEvents` بلافاصله جواب می‌دهد.
 * 2. باز کردن اپ از «برنامه‌های اخیر» رویداد جدیدی با همان نام بسته می‌سازد؛ اگر
 *    فقط «بستهٔ قبلی را یاد بگیر و تکراری را دور بریز» باشیم، برگشت از اخیرها
 *    تشخیص داده نمی‌شود. پس برای جلوگیری از حلقه، به جای نام بسته،
 *    «زمان رویداد» را مبنای تکراری بودن می‌گیریم و علاوه بر آن، هر بار که اپِ
 *    مسدود هنوز در پیش‌زمینه است، هر ۲ ثانیه مجدداً سد را می‌آوریم.
 */
object AppWatcher {

    /** فاصلهٔ نمونه‌برداری وقتی صفحه روشن است. */
    const val POLL_MS = 700L

    /** هر چند میلی‌ثانیه اجازهٔ تکرار سد روی همان اپ را بدهیم. */
    private const val REBLOCK_MS = 1_800L

    /** پنجرهٔ عقب‌گرد برای خواندن رویدادها در اولین تیک. */
    private const val LOOKBACK_MS = 12_000L

    @Volatile private var cursor = 0L
    @Volatile private var lastFg: String? = null
    @Volatile private var lastBlockedPkg: String? = null
    @Volatile private var lastBlockAt = 0L

    /** با شروع/پایان نشست و بازگشت از استراحت صدا می‌شود. */
    fun reset() {
        cursor = 0L
        lastFg = null
        lastBlockedPkg = null
        lastBlockAt = 0L
    }

    /** آخرین اپی که به پیش‌زمینه آمده است (یا null اگر رویداد جدیدی نیست). */
    fun foreground(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < 22) return null
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val now = System.currentTimeMillis()
        val from = if (cursor <= 0L) now - LOOKBACK_MS else cursor - 250L
        val events = try { usm.queryEvents(from, now + 1_000L) } catch (_: Exception) { null } ?: return null
        var pkg: String? = null
        var at = cursor
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            try { events.getNextEvent(e) } catch (_: Exception) { break }
            val resumed = e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (Build.VERSION.SDK_INT >= 29 && e.eventType == UsageEvents.Event.ACTIVITY_RESUMED)
            if (!resumed) continue
            if (e.timeStamp >= at) {
                at = e.timeStamp
                pkg = e.packageName
            }
        }
        if (pkg != null) {
            cursor = at + 1L
            lastFg = pkg
            return pkg
        }
        cursor = now
        return null
    }

    /**
     * یک تیک نگهبانی. از [FocusService] صدا می‌شود.
     *
     * حتی وقتی رویداد جدیدی نیست، اگر آخرین اپِ پیش‌زمینه مسدود باشد سد را تکرار
     * می‌کنیم؛ این دقیقاً همان چیزی است که بازگشت از «اخیرها» را می‌گیرد.
     */
    fun tick(ctx: Context) {
        val session = FocusLock.session.value ?: return
        if (!FocusRules.isActive(session)) return
        val fresh = foreground(ctx)
        val pkg = fresh ?: lastFg ?: return
        /* در استراحت هم تیک می‌زنیم، ولی enforce فقط مسیرهای فرار
           (حذف اپ / پس گرفتن دسترسی) را سد می‌کند. */
        enforce(ctx, pkg)
    }

    /**
     * قواعد را روی یک بسته اعمال می‌کند. هم نگهبان و هم سرویس دسترسی‌پذیری
     * از این یک تابع استفاده می‌کنند تا رفتارشان دقیقاً یکسان باشد.
     *
     * @return true اگر این بسته مسدود است.
     */
    fun enforce(ctx: Context, pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        val session = FocusLock.session.value ?: return false
        if (!FocusRules.isActive(session)) return false
        lastFg = pkg

        // کیبورد هرگز سد نمی‌شود؛ وگرنه باز کردن کیبورد اپ را می‌بست.
        if (FocusRules.isKeyboard(pkg, InstalledApps.imePackages(ctx))) return false

        /* مسیر فرار (حذف اپ، صفحهٔ دسترسی‌ها، مدیر دستگاه): حتی در استراحت هم
           سد می‌شود، چون همین پنجره راهِ خلاص‌شدن همیشگی از قفل بود. */
        if (FocusRules.isEscapeBlocked(pkg, session)) {
            val now = SystemClock.elapsedRealtime()
            if (pkg == lastBlockedPkg && now - lastBlockAt < REBLOCK_MS) return true
            lastBlockedPkg = pkg
            lastBlockAt = now
            block(ctx, pkg)
            return true
        }

        // از این‌جا به بعد قفلِ عادی است و در استراحت اعمال نمی‌شود.
        if (FocusRules.inBreak(session)) return false

        // قفل کامل: خودِ خاموش کردن صفحه در [DeviceLock] انجام می‌شود.
        if (session.config.mode == FocusMode.TOTAL) {
            if (FocusRules.isCallApp(pkg) || pkg == ctx.packageName) return false
            DeviceLock.lockNow(ctx)
            return true
        }

        val blocked = FocusRules.isAppBlocked(
            pkg = pkg,
            session = session,
            extraAllowed = allowedNow(ctx, session),
            selfPkg = ctx.packageName,
        )
        if (!blocked) {
            if (lastBlockedPkg != null && lastBlockedPkg != pkg) lastBlockedPkg = null
            return false
        }
        val now = SystemClock.elapsedRealtime()
        if (pkg == lastBlockedPkg && now - lastBlockAt < REBLOCK_MS) return true
        lastBlockedPkg = pkg
        lastBlockAt = now
        block(ctx, pkg)
        return true
    }

    /**
     * اپ‌های مجازِ لحطه‌ای.
     *
     * در حالت «همه‌چیز جز تماس» لانچر را عمداً مجاز نمی‌کنیم — درخواست کاربر
     * این بود که هیچ منویی از گوشی باز نشود و خودِ اپ نقش منو را داشته باشد.
     */
    private fun allowedNow(ctx: Context, session: FocusSession): Set<String> =
        when (session.config.mode) {
            FocusMode.ALL_BUT_CALLS, FocusMode.TOTAL -> setOf(ctx.packageName)
            else -> InstalledApps.runtimeAllowed(ctx)
        }

    /** سد را بالا می‌آورد. */
    fun block(ctx: Context, pkg: String) {
        FocusLock.noteBlockedOpen(pkg)
        val i = Intent(ctx, BlockOverlayActivity::class.java).apply {
            putExtra(BlockOverlayActivity.EXTRA_PKG, pkg)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS,
            )
        }
        try { ctx.startActivity(i) } catch (_: Exception) { }
    }
}
