package ir.studying.app.focus

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import ir.studying.app.MainActivity
import ir.studying.app.core.Store
import ir.studying.app.ui.focus.FocusBlockScene
import ir.studying.app.ui.theme.StudyingTheme

/**
 * صفحهٔ سد.
 *
 * عمداً یک Activity است و نه پنجرهٔ رویه: روی اندروید ۱۲+ رویهٔ تمام‌صفحه روی
 * بعضی برندها قابل رد شدن است و در حالت چندپنجره می‌شود پشتش کار کرد؛ Activity
 * درست روی اپ مزاحم می‌نشیند و تمرکز ورودی را می‌گیرد.
 */
class BlockOverlayActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent?.getStringExtra(EXTRA_PKG)
        val label = pkg?.let { InstalledApps.label(this, it) }
        setContent {
            val prefs by Store.prefs.collectAsState()
            val dark = when (prefs.themeMode) {
                "dark" -> true
                "light" -> false
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                StudyingTheme(darkTheme = dark, colorId = prefs.themeColor) {
                    BlockBody(
                        appLabel = label,
                        onStudy = {
                            startActivity(
                                Intent(this, MainActivity::class.java)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            )
                            finish()
                        },
                        onHome = { goHome() },
                    )
                }
            }
        }
    }

    /** دکمهٔ بازگشت نباید کاربر را به اپ مزاحم برگرداند؛ برود خانه. */
    @Deprecated("Compat with older API levels")
    override fun onBackPressed() {
        goHome()
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
        finish()
    }

    companion object {
        const val EXTRA_PKG = "pkg"
    }
}

@Composable
private fun BlockBody(
    appLabel: String?,
    onStudy: () -> Unit,
    onHome: () -> Unit,
) {
    val remaining by FocusLock.remaining.collectAsState()
    val session by FocusLock.session.collectAsState()
    val s = session
    val total = if (s != null) (s.endAt - s.startAt).coerceAtLeast(1L) else 1L
    val done = if (s != null) ((total - remaining).toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    // طراحی «گاوصندوق» نسخهٔ ۲.۹ — همان زبان بصری بقیهٔ بخش قفل.
    FocusBlockScene(
        appLabel = appLabel,
        mode = s?.mode,
        remaining = remaining,
        progress = done,
        onStudy = onStudy,
        onHome = onHome,
    )
}
