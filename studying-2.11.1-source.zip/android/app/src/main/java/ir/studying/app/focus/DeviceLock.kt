package ir.studying.app.focus

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings

/**
 * قفل کامل گوشی با Device Admin.
 *
 * منطق ساده ولی بی‌رحم است: هر بار که صفحه روشن می‌شود، `lockNow()` را می‌زنیم.
 *
 * مزیت جانبی و مهم: تا وقتی اپ مدیر دستگاه فعال است، خودِ اندروید اجازهٔ حذف اپ را
 * نمی‌دهد؛ پس همین دسترسی سنگر «منع حذف در زمان قفل» هم هست.
 */
object DeviceLock {

    private const val MIN_GAP_MS = 900L
    @Volatile private var lastLockAt = 0L

    fun component(ctx: Context): ComponentName =
        ComponentName(ctx.applicationContext, FocusAdminReceiver::class.java)

    private fun dpm(ctx: Context): DevicePolicyManager? =
        ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager

    /** آیا کاربر نقش مدیر دستگاه را به اپ داده است؟ */
    fun isAdmin(ctx: Context): Boolean =
        try { dpm(ctx)?.isAdminActive(component(ctx)) == true } catch (_: Exception) { false }

    /**
     * باز کردن صفحهٔ سیستمی فعال‌سازی مدیر دستگاه.
     *
     * دلیل باز نشدنِ قبلی: اینتنت با Contextِ اپلیکیشن و پرچم NEW_TASK اجرا می‌شد و
     * روی بسیاری از رام‌ها (خاصه MIUI/One UI) بی‌صدا رد می‌شد؛ و خطا هم در حلقهٔ
     * `catch` خورده می‌شد و کاربر فقط می‌دید «هیچ اتفاقی نمی‌افتد».
     *
     * الان: اگر Context یک Activity باشد بدون NEW_TASK اجرا می‌شود، و سه مسیر جایگین
     * به ترتیب امتحان می‌شوند. خروجی Boolean است تا UI بتواند پیام شکست نشان دهد.
     */
    fun request(ctx: Context): Boolean {
        val isActivity = ctx is android.app.Activity
        val explain =
            "برای «قفل کامل گوشی» و جلوگیری از حذف اپ در زمان قفل، لازم است اپ بتواند صفحه را قفل کند. هیچ داده‌ای خوانده یا پاک نمی‌شود."

        val candidates = listOf(
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(ctx))
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, explain)
            },
            // فهرست مدیران دستگاه (اگر صفحهٔ افزودن روی این رام وجود نداشت).
            Intent("android.app.action.DEVICE_ADMIN_SETTINGS"),
            Intent(Settings.ACTION_SECURITY_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.parse("package:" + ctx.packageName)),
        )

        for (i in candidates) {
            if (!isActivity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val canHandle = try {
                i.resolveActivity(ctx.packageManager) != null
            } catch (_: Exception) { false }
            if (!canHandle) continue
            try {
                ctx.startActivity(i)
                return true
            } catch (_: Exception) { }
        }
        return false
    }

    /** برداشتن دسترسی مدیر دستگاه — فقط وقتی هیچ نشستی فعال نیست. */
    fun release(ctx: Context) {
        // در هر نشست فعالی (نه فقط قفل کامل) این دسترسی سنگرِ منع حذف اپ است.
        if (FocusLock.isActive) return
        try { dpm(ctx)?.removeActiveAdmin(component(ctx)) } catch (_: Exception) { }
    }

    /** قفل فوری صفحه. */
    fun lockNow(ctx: Context): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLockAt < MIN_GAP_MS) return true
        val d = dpm(ctx) ?: return false
        if (!isAdmin(ctx)) return false
        return try {
            d.lockNow()
            lastLockAt = now
            true
        } catch (_: Exception) { false }
    }

    /**
     * نگهبان قفل کامل: اگر نشست در حالت `TOTAL` فعال است، صفحه را خاموش کن.
     * از گیرندهٔ SCREEN_ON / USER_PRESENT در [FocusService] صدا می‌شود.
     */
    fun enforceIfNeeded(ctx: Context): Boolean {
        if (!FocusRules.isTotalLock(FocusLock.session.value)) return false
        return lockNow(ctx)
    }
}
