package ir.studying.app.focus

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * موتور سریع قفل.
 *
 * برخلاف پولینگ UsageStats، اینجا دقیقاً در لحظهٔ باز شدن پنجره خبر داریم، پس کاربر
 * عملاً فرصت دیدن فید اینستاگرام را هم پیدا نمی‌کند، و مصرف باتری عملاً صفر است.
 *
 * این سرویس به هیچ محتوایی دست نمی‌زند: فقط نام بستهٔ پنجرهٔ فعال را می‌خواند، متن
 * را نمی‌خواند و هیچ چیزی را ذخیره یا ارسال نمی‌کند.
 */
class FocusAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) return
        val session = FocusLock.session.value ?: return
        if (!FocusRules.isActive(session)) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        // کیبورد پنجرهٔ خودش را باز می‌کند؛ این را اپ مزاحم نگیر.
        if (FocusRules.isKeyboard(pkg, InstalledApps.imePackages(this))) return

        /* مسیر فرار همیشه سد است، حتی در استراحت. */
        if (FocusRules.isEscapeBlocked(pkg, session)) {
            try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { }
            AppWatcher.block(this, pkg)
            return
        }
        if (FocusRules.inBreak(session)) return

        // قفل کامل گوشی: هر پنجره‌ای جز تماس/پیامک یعنی صفحه باید خاموش شود.
        if (FocusRules.isTotalLock(session) && !FocusRules.isCallApp(pkg)) {
            DeviceLock.lockNow(this)
            return
        }

        val uninstall = FocusRules.isUninstallRoute(pkg)
        if (!uninstall && !FocusRules.isAppBlocked(
                pkg = pkg,
                session = session,
                extraAllowed = InstalledApps.runtimeAllowed(this),
                selfPkg = packageName,
            )
        ) return

        /*
         * دو کار پشت سر هم: اول برگشت به خانه تا اپ مزاحم عقب برود (این را فقط
         * دسترسی‌پذیری می‌تواند بکند، رویهٔ ساده نمی‌تواند)، بعد نمایش صفحهٔ سد تا
         * کاربر بفهمد چرا پرت شد و چقدر از نشستش مانده.
         */
        try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { }
        AppWatcher.block(this, pkg)
    }

    override fun onInterrupt() {}
}
