package ir.studying.app.focus

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * گیرندهٔ مدیر دستگاه.
 *
 * تنها سیاستی که می‌خواهیم `force-lock` است (فایل `res/xml/device_admin.xml`)؛
 * نه پاک‌کردن داده، نه رمز عوض کردن، نه خواندن هیچ چیزی.
 */
class FocusAdminReceiver : DeviceAdminReceiver() {

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "اگر این دسترسی را برداری، حالت «قفل کامل گوشی» دیگر کار نمی‌کند."

    override fun onEnabled(context: Context, intent: Intent) {
        PermState.invalidate()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        PermState.invalidate()
    }
}
