package ir.studying.app.focus

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * آینهٔ نشست روی SharedPreferences.
 *
 * چرا وقتی خودِ نشست در Store ذخیره می‌شود: Store روی DataStore است و خواندنش
 * غیرهمگام (suspend) است. در لحظهٔ بوت یا وقتی سیستم سرویس را دوباره می‌سازد،
 * باید *همین حالا* و بدون کوروتین بدانیم نشست فعالی هست یا نه؛ وگرنه چند صد
 * میلی‌ثانیه پنجرهٔ فرار باز می‌ماند و در حالت قفل کامل، کاربر فرصت ری‌استارت
 * و خلاص‌شدن از قفل را پیدا می‌کند.
 */
object FocusMirror {

    private const val FILE = "focus_mirror"
    private const val K_END = "endAt"
    private const val K_MODE = "mode"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun write(ctx: Context, endAt: Long, mode: String) {
        try {
            prefs(ctx).edit().putLong(K_END, endAt).putString(K_MODE, mode).apply()
        } catch (_: Exception) { }
    }

    fun clear(ctx: Context) {
        try { prefs(ctx).edit().remove(K_END).remove(K_MODE).apply() } catch (_: Exception) { }
    }

    fun endAt(ctx: Context): Long = try { prefs(ctx).getLong(K_END, 0L) } catch (_: Exception) { 0L }

    fun mode(ctx: Context): String = try { prefs(ctx).getString(K_MODE, "") ?: "" } catch (_: Exception) { "" }

    /** آیا نشستی هنوز زنده است؟ بدون دست‌زدن به DataStore. */
    fun active(ctx: Context): Boolean = endAt(ctx) > System.currentTimeMillis()

    fun isTotal(ctx: Context): Boolean = active(ctx) && mode(ctx) == FocusMode.TOTAL.id
}

/**
 * برگرداندن قفل پس از ریبوت، آپدیت اپ و تغییر ساعت.
 *
 * باگی که رفع می‌کند: در «قفل کامل» کاربر گوشی را ری‌استارت می‌کرد و قفل عملاً
 * غیرفعال می‌شد. دلیلش این بود که برگرداندن نشست فقط به رویدادِ زنگ‌ها و باز
 * شدن اپ گره خورده بود؛ پس تا کاربر خودش اپ را باز نمی‌کرد، نه سرویس پیش‌زمینه
 * بالا می‌آمد و نه صفحه قفل می‌شد.
 */
class FocusBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val ctx = context?.applicationContext ?: return
        if (!FocusMirror.active(ctx)) return
        /* در قفل کامل، اول صفحه را قفل کن و بعد سرویس را بالا بیاور؛ ترتیبش مهم
           است چون آوردن سرویس چند صد میلی‌ثانیه طول می‌کشد. */
        if (FocusMirror.isTotal(ctx)) DeviceLock.lockNow(ctx)
        FocusService.start(ctx)
        FocusLock.init(ctx)
        FocusLock.resumeIfActive(ctx)
        FocusWatchdog.arm(ctx)
    }
}

/**
 * نگهبان دوره‌ای قفل.
 *
 * اگر سیستم سرویس پیش‌زمینه را کشته باشد (کم‌حافظه، بهینه‌سازی باتری برندها،
 * Force Stop) این آلارم هر چند دقیقه سرویس را برمی‌گرداند. مهلت نشست روی دیسک
 * است، پس هیچ‌چیز از دست نمی‌رود؛ فقط باید دوباره سرِ پا شود.
 */
object FocusWatchdog {

    private const val REQ = 9131
    const val ACTION = "ir.studying.app.focus.WATCHDOG"
    private const val PERIOD_MS = 2L * 60_000L

    private fun intent(ctx: Context): PendingIntent {
        val i = Intent(ctx, FocusWatchdogReceiver::class.java).setAction(ACTION)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(ctx.applicationContext, REQ, i, flags)
    }

    fun arm(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val next = System.currentTimeMillis() + PERIOD_MS
        try {
            /* setInexactRepeating کافی است: دقت ثانیه‌ای لازم نیست و باتری کمتری
               می‌برد؛ در عوض در هر بیدارشدن، آلارم بعدی هم دوباره چیده می‌شود. */
            am.set(AlarmManager.RTC_WAKEUP, next, intent(ctx))
        } catch (_: Exception) { }
    }

    fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        try { am.cancel(intent(ctx)) } catch (_: Exception) { }
    }
}

class FocusWatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val ctx = context?.applicationContext ?: return
        if (!FocusMirror.active(ctx)) {
            FocusWatchdog.cancel(ctx)
            return
        }
        FocusService.start(ctx)
        FocusLock.init(ctx)
        FocusLock.resumeIfActive(ctx)
        if (FocusMirror.isTotal(ctx)) DeviceLock.enforceIfNeeded(ctx)
        FocusWatchdog.arm(ctx)
    }
}
