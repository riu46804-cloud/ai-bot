package ir.studying.app.focus

import android.app.NotificationManager
import android.content.Context
import android.os.Build

/**
 * حالت مزاحمت نکن سیستمی.
 *
 * راه ارزان و مطمئن برای ساکت کردن همهٔ اپ‌ها: نه به خواندن اعلان‌ها نیاز دارد نه
 * به سرویس دائمی. فقط انتخابی نیست؛ برای انتخابی [NotifGuard] هست.
 *
 * حالت قبلی کاربر را ذخیره و دقیقاً همان را برمی‌گرداند — اگر کاربر خودش قبلاً DND را
 * روشن کرده بود، ما نباید بعد از نشست خاموشش کنیم.
 */
object FocusDnd {

    @Volatile private var previousFilter: Int? = null

    private fun nm(ctx: Context): NotificationManager? =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    fun enable(ctx: Context) {
        if (Build.VERSION.SDK_INT < 23) return
        if (!FocusPerms.hasDndAccess(ctx)) return
        val manager = nm(ctx) ?: return
        try {
            if (previousFilter == null) previousFilter = manager.currentInterruptionFilter
            if (manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
                manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            }
        } catch (_: Exception) { }
    }

    fun restore(ctx: Context) {
        if (Build.VERSION.SDK_INT < 23) return
        if (!FocusPerms.hasDndAccess(ctx)) { previousFilter = null; return }
        val manager = nm(ctx) ?: return
        val back = previousFilter ?: NotificationManager.INTERRUPTION_FILTER_ALL
        previousFilter = null
        try { manager.setInterruptionFilter(back) } catch (_: Exception) { }
    }
}
