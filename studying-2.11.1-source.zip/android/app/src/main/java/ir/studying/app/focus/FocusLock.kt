package ir.studying.app.focus

import android.content.Context
import ir.studying.app.core.Store
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * منبع حقیقت قفل تمرکز.
 *
 * همهٔ لایه‌ها (قفل درون‌اپی، سکوت اعلان، قفل اپ‌های مزاحم، قفل کامل گوشی، پین صفحه)
 * فقط این جسم را می‌خوانند. هر کدام اگر حالت خودش را نگه می‌داشت، بالاخره یکیشان با
 * بقیه اختلاف پیدا می‌کرد و قفل سوراخ می‌شد.
 *
 * ماندگاری: [FocusSession.endAt] مطلق است و روی دیسک می‌نشیند، پس کشتن پروسه،
 * سوایپ از ریسنت یا ریبوت، قفل را باطل نمی‌کند.
 */
object FocusLock {

    private const val KEY_SESSION = "focus_session"
    private const val KEY_CONFIG = "focus_config"
    private const val KEY_BADGES = "focus_badges"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var ticker: Job? = null
    private var appContext: Context? = null

    private val _session = MutableStateFlow<FocusSession?>(null)
    val session: StateFlow<FocusSession?> get() = _session

    private val _config = MutableStateFlow(FocusConfig())
    val config: StateFlow<FocusConfig> get() = _config

    /** برای شمارش معکوس در UI؛ هر ثانیه بروز می‌شود. */
    private val _remaining = MutableStateFlow(0L)
    val remaining: StateFlow<Long> get() = _remaining

    /** کارت پایان نشست؛ UI پس از نمایش، [clearRecap] را صدا می‌زند. */
    private val _recap = MutableStateFlow<FocusRecap?>(null)
    val recap: StateFlow<FocusRecap?> get() = _recap

    /** نشان‌های تمرکزِ کامل‌شده. خروج اضطراری نشان این نشست را می‌سوزاند. */
    private val _badges = MutableStateFlow(0)
    val badges: StateFlow<Int> get() = _badges

    /** متن تعهدی که برای همین نشست قرعه خورده است. */
    @Volatile private var challengeText: String = UnlockTexts.random()

    /** شمارنده‌های همین نشست — خوراک کارت پایان. */
    @Volatile private var suppressedOwn = 0
    @Volatile private var suppressedForeign = 0
    @Volatile private var blockedOpens = 0

    val isActive: Boolean get() = FocusRules.isActive(_session.value)

    /* ---------------- راه‌اندازی ---------------- */

    fun init(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        scope.launch {
            _config.value = readConfig()
            _badges.value = (Store.getString(KEY_BADGES)?.toIntOrNull() ?: 0)
            val saved = readSession()
            if (saved != null) {
                if (FocusRules.isActive(saved)) {
                    // نشست از پروسهٔ قبلی هنوز زنده است — دوباره سرِ پا.
                    _session.value = saved
                    _remaining.value = FocusRules.remainingMs(saved)
                    applyEnvironment(saved)
                    startTicker()
                } else {
                    // مهلتش در نبودِ ما تمام شده بود؛ پاک‌سازی کن و محیط را برگردان.
                    finishInternal(saved, broke = false, restoreOnly = true)
                }
            }
            appContext?.let { FocusScheduler.sync(it, _config.value) }
            FocusSync.flush()
        }
    }

    /**
     * پس از ریبوت صدا زده می‌شود: اگر نشستی هنوز زنده است سرویس و محیط را برمی‌گرداند.
     */
    fun resumeIfActive(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        scope.launch {
            val saved = readSession() ?: return@launch
            if (!FocusRules.isActive(saved)) {
                finishInternal(saved, broke = false, restoreOnly = true)
                return@launch
            }
            if (_session.value == null) _session.value = saved
            _remaining.value = FocusRules.remainingMs(saved)
            FocusMirror.write(ctx, saved.endAt, saved.config.mode.id)
            FocusWatchdog.arm(ctx)
            applyEnvironment(saved)
            startTicker()
        }
    }

    private suspend fun readConfig(): FocusConfig {
        val raw = try { Store.getString(KEY_CONFIG) } catch (_: Exception) { null } ?: return FocusConfig()
        return try { FocusConfig.fromJson(JSONObject(raw)) } catch (_: Exception) { FocusConfig() }
    }

    private suspend fun readSession(): FocusSession? {
        val raw = try { Store.getString(KEY_SESSION) } catch (_: Exception) { null } ?: return null
        return try { FocusSession.fromJson(JSONObject(raw)) } catch (_: Exception) { null }
    }

    /* ---------------- تنظیمات ---------------- */

    fun updateConfig(update: (FocusConfig) -> FocusConfig) {
        val next = update(_config.value)
        _config.value = next
        scope.launch { Store.putString(KEY_CONFIG, next.toJson().toString()) }
    }

    /** چیدن مجدد آلارم زمان‌بندی‌ها. */
    fun syncSchedules(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        FocusScheduler.sync(ctx, _config.value)
    }

    /* ---------------- چرخهٔ عمر نشست ---------------- */

    /**
     * شروع نشست.
     *
     * اگر نشستی در جریان باشد فقط تمدید می‌شود؛ دو نشست هم‌زمان یعنی دو منبع حقیقت.
     */
    fun start(
        context: Context,
        minutes: Int,
        groupCode: String? = null,
        mode: FocusMode? = null,
    ) {
        val ctx = context.applicationContext
        appContext = ctx
        val safeMinutes = minutes.coerceIn(MIN_MINUTES, MAX_MINUTES)
        val running = _session.value
        if (FocusRules.isActive(running)) {
            extend(safeMinutes)
            return
        }
        if (mode != null) updateConfig { it.copy(mode = mode) }
        val cfg = _config.value
        val now = System.currentTimeMillis()
        val s = FocusSession(
            startAt = now,
            endAt = now + safeMinutes * 60_000L,
            plannedMinutes = safeMinutes,
            config = cfg,
            groupCode = groupCode,
        )
        suppressedOwn = 0
        suppressedForeign = 0
        blockedOpens = 0
        challengeText = UnlockTexts.random(persian = cfg.unlockPersianText)
        AppWatcher.reset()
        _session.value = s
        _remaining.value = FocusRules.remainingMs(s, now)
        persist(s)
        applyEnvironment(s)
        startTicker()
    }

    /** شروع خودکار از یک زمان‌بندی. */
    fun startFromSchedule(context: Context, id: Int) {
        val ctx = context.applicationContext
        appContext = ctx
        scope.launch {
            if (_config.value.schedules.isEmpty()) _config.value = readConfig()
            val s = _config.value.schedules.firstOrNull { it.id == id }
            // آلارم بعدیِ همین زمان‌بندی را دوباره بچین (آلارم دقیقِ تکرارشونده نداریم).
            FocusScheduler.sync(ctx, _config.value)
            if (s == null || !s.enabled) return@launch
            if (FocusRules.isActive(_session.value)) return@launch
            start(ctx, s.minutes, mode = s.mode)
        }
    }

    /** تمدید نشست جاری. */
    fun extend(minutes: Int) {
        val s = _session.value ?: return
        if (!FocusRules.isActive(s)) return
        val next = s.copy(endAt = s.endAt + minutes.coerceIn(1, MAX_MINUTES) * 60_000L)
        _session.value = next
        _remaining.value = FocusRules.remainingMs(next)
        persist(next)
        appContext?.let { FocusService.refresh(it) }
    }

    /* ---------------- استراحت ---------------- */

    /** آیا الان می‌شود استراحت گرفت؟ */
    fun canBreak(): Boolean {
        val s = _session.value ?: return false
        if (!FocusRules.isActive(s)) return false
        if (FocusRules.inBreak(s)) return false
        if (!FocusRules.breaksAllowed(s)) return false
        return FocusRules.breaksLeft(s) > 0
    }

    /** شروع یک استراحت کوتاه: قفل موقتاً برداشته می‌شود. */
    fun startBreak() {
        val s = _session.value ?: return
        if (!canBreak()) return
        val now = System.currentTimeMillis()
        val until = (now + s.config.breakSeconds * 1000L).coerceAtMost(s.endAt)
        val next = s.copy(breakUntil = until, breaksUsed = s.breaksUsed + 1)
        _session.value = next
        persist(next)
        AppWatcher.reset()
        val ctx = appContext ?: return
        // در استراحت، پین صفحه و قفل کامل باید موقتاً کنار بروند.
        ScreenPin.stop()
        FocusService.refresh(ctx)
    }

    /** پایان دستی استراحت. */
    fun endBreak() {
        val s = _session.value ?: return
        if (!FocusRules.inBreak(s)) return
        val next = s.copy(breakUntil = 0L)
        _session.value = next
        persist(next)
        AppWatcher.reset()
        val ctx = appContext ?: return
        applyEnvironment(next)
        FocusService.refresh(ctx)
    }

    /* ---------------- پایان نشست ---------------- */

    /** پایان طبیعی (مهلت تمام شد) — نشان تمرکز گرفته می‌شود. */
    fun complete() {
        val s = _session.value ?: return
        finishInternal(s, broke = false)
    }

    /**
     * خروج اضطراری. هزینه‌اش سوختن نشان همین نشست است — فشار اجتماعی، نه زندان.
     */
    fun breakOut() {
        val s = _session.value ?: return
        /* اگر پیش از شروع، «خروج اضطراری» را خاموش کرده باشد، نه دکمهٔ خروج و نه
           اکشن توقفِ اعلان کاری نمی‌کنند؛ نشست فقط با پایان زمان تمام می‌شود. */
        if (FocusRules.isActive(s) && !FocusRules.canExit(s)) return
        finishInternal(s, broke = true)
    }

    /** آیا نشست جاری اجازهٔ خروج اضطراری دارد؟ (برای UI) */
    fun canExit(): Boolean = FocusRules.canExit(_session.value)

    /* ---------------- چالش خروج ---------------- */

    /** خروج این نشست باید سخت باشد؟ */
    fun unlockNeedsChallenge(): Boolean {
        val s = _session.value ?: return false
        if (!FocusRules.isActive(s)) return false
        return s.config.unlockTyping || s.config.unlockDelaySec > 0
    }

    /** متن تعهدی که باید تایپ شود. */
    fun unlockText(): String = challengeText

    /** تأخیر پس از تایپ درست (ثانیه). */
    fun unlockDelaySec(): Int =
        (_session.value?.config ?: _config.value).unlockDelaySec.coerceIn(0, 300)

    private fun finishInternal(s: FocusSession, broke: Boolean, restoreOnly: Boolean = false) {
        ticker?.cancel()
        ticker = null
        _session.value = null
        _remaining.value = 0L
        val ctx = appContext
        ScreenPin.stop()
        if (ctx != null) {
            FocusDnd.restore(ctx)
            FocusService.stop(ctx)
        }
        AppWatcher.reset()
        if (ctx != null) {
            FocusMirror.clear(ctx)
            FocusWatchdog.cancel(ctx)
        }
        val minutes = FocusRules.elapsedMinutes(s, System.currentTimeMillis())
        if (!restoreOnly) {
            _recap.value = FocusRecap(
                minutes = minutes,
                broke = broke,
                suppressedNotifs = suppressedOwn + suppressedForeign,
                blockedOpens = blockedOpens,
            )
        }
        val earned = if (!broke && minutes >= (s.plannedMinutes * 0.9).toInt()) 1 else 0
        scope.launch {
            Store.putString(KEY_SESSION, null)
            if (earned > 0) {
                val next = _badges.value + 1
                _badges.value = next
                Store.putString(KEY_BADGES, next.toString())
            }
            if (s.config.shareToServer && minutes > 0) {
                FocusSync.log(
                    startAt = s.startAt,
                    endAt = System.currentTimeMillis(),
                    minutes = minutes,
                    broke = broke,
                    profile = s.config.mode.id,
                    groupCode = s.groupCode,
                )
            }
            // گزارش فقط وقتی کاربر خواسته، نشست شکسته نشده و بالای دو ساعت بوده است
            if (s.config.shareReports && !broke && minutes >= 120) {
                FocusSync.shareReport(minutes = minutes, mode = s.config.mode.title)
            }
        }
    }

    fun clearRecap() { _recap.value = null }

    /* ---------------- محیط و تیک ---------------- */

    private fun persist(s: FocusSession) {
        scope.launch { Store.putString(KEY_SESSION, s.toJson().toString()) }
        /* آینهٔ همگام روی SharedPreferences؛ در بوت و بازسازی سرویس، بدون
           کوروتین و بی‌درنگ خوانده می‌شود. */
        appContext?.let {
            FocusMirror.write(it, s.endAt, s.config.mode.id)
            FocusWatchdog.arm(it)
        }
    }

    /** لایه‌های سیستمی را مطابق نشست برقرار می‌کند. */
    private fun applyEnvironment(s: FocusSession) {
        val ctx = appContext ?: return
        if (s.config.useDnd) FocusDnd.enable(ctx)
        FocusService.start(ctx)
        // قفل کامل: همین حالا صفحه را خاموش کن و بعد هر بار روشن شد باز خاموش.
        if (FocusRules.isTotalLock(s)) DeviceLock.enforceIfNeeded(ctx)
        // پین صفحه: هر حالتی که کاربر پین را روشن کرده باشد (جز قفل کامل).
        if (FocusRules.needsScreenPin(s)) ScreenPin.start()
    }

    /**
     * تیک ۱ ثانیه‌ای فقط برای شمارش معکوس، پایان خودکار و پایان استراحت.
     * نگهبانی اپ‌ها کارِ [FocusService] است، چون فقط سرویس پیش‌زمینه بعد از بستن
     * اپ زنده می‌ماند.
     */
    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            var wasInBreak = FocusRules.inBreak(_session.value)
            while (true) {
                val s = _session.value ?: break
                val left = FocusRules.remainingMs(s)
                _remaining.value = left
                if (left <= 0L) { complete(); break }
                val nowInBreak = FocusRules.inBreak(s)
                if (wasInBreak && !nowInBreak) {
                    // استراحت خودش تمام شد؛ قفل را برگردان.
                    _session.value = s.copy(breakUntil = 0L)
                    _session.value?.let { persist(it); applyEnvironment(it) }
                    AppWatcher.reset()
                }
                wasInBreak = nowInBreak
                delay(1000L)
            }
        }
    }

    /* ---------------- شمارنده‌ها ---------------- */

    fun noteSuppressedOwn() { suppressedOwn++ }
    fun noteSuppressedForeign() { suppressedForeign++ }
    fun noteBlockedOpen(@Suppress("UNUSED_PARAMETER") pkg: String) { blockedOpens++ }

    /** میانبر برای گیت‌های اعلان در کدِ موجود: یک شرط و تمام. */
    fun allowOwnNotif(key: String): Boolean {
        val ok = FocusRules.isOwnNotifAllowed(key, _session.value)
        if (!ok) noteSuppressedOwn()
        return ok
    }

    /** آیا این مسیر ناوبری الان قفل است؟ (برای MainScaffold) */
    fun isRouteLocked(route: String?): Boolean = FocusRules.isRouteLocked(route, _session.value)

    const val MIN_MINUTES = 5
    const val MAX_MINUTES = 480
}
