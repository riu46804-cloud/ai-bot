package ir.studying.app.focus

import org.json.JSONArray
import org.json.JSONObject

/**
 * سه حالت قفل.
 *
 * حالت، «شدت» قفل را تعیین می‌کند. در نسخهٔ ۲.۷ حالت چهارمِ قدیمی («قفل عادی» که
 * فقط خود اپ را پین می‌کرد) حذف شد: عملاً هیچ‌چیز را قفل نمی‌کرد، کاربر فکر می‌کرد
 * در حالت تمرکز است و اپ‌های مزاحم همچنان باز می‌شدند. حالا «پین صفحه» یک گزینهٔ
 * تقویتی است که روی همین سه حالت سوار می‌شود، نه یک حالتِ جداگانه.
 *
 * [order] شدت است (۱ تا ۳) و برای نوار شدت در رابط کاربری استفاده می‌شود.
 */
enum class FocusMode(
    val id: String,
    val title: String,
    val emoji: String,
    val blurb: String,
    /** شدت قفل، ۱ تا ۳ — فقط برای نمایش. */
    val order: Int,
    /** یک جملهٔ کوتاه که می‌گوید چه چیزی باز می‌ماند. */
    val keepsOpen: String,
    /** دسترسی‌ای که این حالت لازم دارد؛ خالی یعنی هیچ. */
    val needs: String,
) {
    /** لایهٔ ۱: فقط اپ‌های انتخابی بسته می‌شوند. */
    APPS(
        "apps", "قفل اپ‌های منتخب", "🚫",
        "اپ‌هایی که خودت انتخاب کردی باز نمی‌شوند",
        order = 1,
        keepsOpen = "بقیهٔ گوشی آزاد است",
        needs = "موتور تشخیص اپ",
    ),

    /** لایهٔ ۲: همه‌چیز جز تماس و پیامک و خود اپ. */
    ALL_BUT_CALLS(
        "all_but_calls", "همه‌چیز جز تماس و پیامک", "📵",
        "هیچ منویی باز نمی‌شود؛ تماس و پیامک از داخل اپ",
        order = 2,
        keepsOpen = "تماس و پیامک باز است",
        needs = "موتور تشخیص اپ",
    ),

    /** لایهٔ ۳: قفل کامل گوشی با Device Admin. */
    TOTAL(
        "total", "قفل کامل گوشی", "🔒",
        "صفحه روشن شود بی‌درنگ خاموش می‌شود؛ حتی رمز هم نمی‌شود زد",
        order = 3,
        /* قبلاً «فقط تماس اضطراری» نوشته بود؛ چنین استثنایی در اپ پیاده نشده و
           ادعای نادرست روی قفلی که صفحه را خاموش می‌کند خطرناک است. */
        keepsOpen = "هیچ اپی باز نمی‌ماند",
        needs = "مدیر دستگاه",
    );

    val needsAppEngine: Boolean get() = this == APPS || this == ALL_BUT_CALLS

    companion object {
        /**
         * شناسه به حالت.
         *
         * `"pin"` شناسهٔ حالتِ حذف‌شده است و عمداً به [APPS] نگاشت می‌شود: تنظیمات
         * ذخیره‌شدهٔ کاربران قدیمی، زمان‌بندی‌هایشان و چالش‌هایی که از نسخه‌های
         * قبلی اپ روی سرور مانده‌اند همه `pin` دارند و نباید خطا بدهند.
         */
        fun of(id: String?): FocusMode = when (id) {
            "pin" -> APPS
            else -> values().firstOrNull { it.id == id } ?: APPS
        }
    }
}

/**
 * یک زمان‌بندی قفل.
 *
 * [minuteOfDay] دقیقهٔ شبانه‌روز محلی و [days] روزهای هفته به سبک
 * `java.util.Calendar` (۱=یکشنبه … ۷=شنبه). خالی بودن [days] یعنی «هر روز».
 */
data class FocusSchedule(
    val id: Int,
    val minuteOfDay: Int,
    val minutes: Int,
    val days: Set<Int> = emptySet(),
    val mode: FocusMode = FocusMode.APPS,
    val enabled: Boolean = true,
) {
    val hour: Int get() = minuteOfDay / 60
    val minute: Int get() = minuteOfDay % 60

    fun clock(): String = String.format(java.util.Locale.US, "%02d:%02d", hour, minute)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("minuteOfDay", minuteOfDay)
        put("minutes", minutes)
        put("days", JSONArray(days.toList()))
        put("mode", mode.id)
        put("enabled", enabled)
    }

    companion object {
        fun fromJson(o: JSONObject): FocusSchedule? {
            val minuteOfDay = o.optInt("minuteOfDay", -1)
            if (minuteOfDay < 0 || minuteOfDay > 1439) return null
            val days = LinkedHashSet<Int>()
            o.optJSONArray("days")?.let { a ->
                for (i in 0 until a.length()) {
                    val d = a.optInt(i, 0)
                    if (d in 1..7) days.add(d)
                }
            }
            return FocusSchedule(
                id = o.optInt("id", minuteOfDay),
                minuteOfDay = minuteOfDay,
                minutes = o.optInt("minutes", 50).coerceIn(5, 480),
                days = days,
                mode = FocusMode.of(o.optString("mode")),
                enabled = o.optBoolean("enabled", true),
            )
        }
    }
}

/**
 * تمام چیزی که کاربر می‌تواند انتخاب کند.
 *
 * این کلاس عمداً «داده»ی خالص است: نه Context می‌شناسد نه Compose. همین باعث
 * می‌شود [FocusRules] تست‌پذیر بماند و بشود دقیقاً همین قواعد را بعداً در وب هم
 * پیاده کرد.
 */
data class FocusConfig(
    val mode: FocusMode = FocusMode.APPS,

    /* ---- لایهٔ ۱: قفل داخل خود اپ ---- */
    val lockChat: Boolean = true,
    val lockSocial: Boolean = true,
    /** اعلان‌های خود اپ که در زمان تمرکز نباید بیایند (کلید کانال/نوع). */
    val silenced: Set<String> = setOf("messages", "social"),

    /* ---- لایهٔ ۲: سکوت اعلان بقیهٔ اپ‌ها ---- */
    val useDnd: Boolean = true,
    /** سکوت گزینشی با NotificationListener؛ نیاز به دسترسی جدا دارد. */
    val perAppSilence: Boolean = false,
    val silencedApps: Set<String> = emptySet(),

    /* ---- لایهٔ ۳: قفل اپ‌های مزاحم ---- */
    val blockApps: Boolean = false,
    val blocked: Set<String> = emptySet(),
    /** اپ‌هایی که حتی در حالت سخت باز می‌مانند (دیکشنری، ماشین‌حساب…). */
    val allowed: Set<String> = emptySet(),
    /**
     * پین صفحه: کاربر داخل اتاق مطالعه حبس می‌شود.
     *
     * از نسخهٔ ۲.۷ یک تقویت‌کنندهٔ مستقل است و با هر حالتی جز «قفل کامل» کار می‌کند
     * (در قفل کامل صفحه خاموش می‌شود، پس پین بی‌معناست).
     */
    val pinScreen: Boolean = false,

    /* ---- استراحت‌ها ---- */
    /** طول هر استراحت به ثانیه: ۳۰ تا ۳۰۰. */
    val breakSeconds: Int = 120,
    /** چند بار در هر نشست می‌شود استراحت گرفت. صفر = بدون استراحت. */
    val breakLimit: Int = 2,
    /**
     * آیا این نشست اجازهٔ استراحت دارد؟
     *
     * جدا از [breakLimit] است تا کاربر بتواند پیش از شروع، بدون دست‌زدن به
     * تنظیمات عمومی، همین نشست را «بی‌استراحت» کند.
     */
    val allowBreaks: Boolean = true,
    /**
     * آیا خروج اضطراری از این نشست ممکن است؟
     *
     * اگر false باشد، دکمهٔ خروج و اکشن توقف در اعلان کار نمی‌کنند و نشست فقط با
     * رسیدن به پایان زمان تمام می‌شود. انتخابش پیش از شروع نشست انجام می‌شود،
     * چون تصمیم‌گیری در لحظهٔ وسوسه بی‌فایده است.
     */
    val allowExit: Boolean = true,
    /**
     * نگهبانی مسیرهای فرار (حذف اپ، صفحهٔ تنظیماتِ همین اپ، دسترسی‌پذیری،
     * مدیر دستگاه) حتی در زمان استراحت.
     *
     * چرا لازم شد: در استراحت همهٔ سدها برداشته می‌شد و کاربر می‌توانست برود
     * دسترسی‌ها را پس بگیرد یا اپ را حذف کند و قفل برای همیشه خلاص شود.
     */
    val guardEscape: Boolean = true,

    /* ---- سختی باز کردن قفل ---- */
    /** باز کردن قفل نیاز به تایپ متن طولانی دارد. */
    val unlockTyping: Boolean = true,
    /** پس از تایپ درست، چند ثانیه صبر لازم است. */
    val unlockDelaySec: Int = 60,
    /** متن تعهد فارسی باشد یا انگلیسی (پیش‌فرض انگلیسی: تایپش روی هر کیبوردی ساده است). */
    val unlockPersianText: Boolean = false,

    /* ---- رفتار نشست ---- */
    val defaultMinutes: Int = 50,
    /** با شروع کرنومتر/پومودورو قفل هم خودکار روشن شود. */
    val autoWithTimer: Boolean = false,
    /** ثبت نشست روی سرور و شرکت در لیدربورد. */
    val shareToServer: Boolean = true,
    /** انتشار گزارش نشست در صفحهٔ اجتماعی — فقط نشست‌های بالای دو ساعت. */
    val shareReports: Boolean = false,
    /** زمان‌بندی‌های خودکار. */
    val schedules: List<FocusSchedule> = emptyList(),
    /** ویزارد راه‌اندازی یک بار دیده شده است. */
    val onboarded: Boolean = false,
) {
    /** با این تنظیمات، آیا به موتور تشخیص اپ (دسترسی‌پذیری یا آمار مصرف) نیاز داریم؟ */
    val needsAppEngine: Boolean get() = mode.needsAppEngine && (blockApps || mode == FocusMode.ALL_BUT_CALLS)

    fun toJson(): JSONObject = JSONObject().apply {
        put("mode", mode.id)
        put("lockChat", lockChat)
        put("lockSocial", lockSocial)
        put("silenced", JSONArray(silenced.toList()))
        put("useDnd", useDnd)
        put("perAppSilence", perAppSilence)
        put("silencedApps", JSONArray(silencedApps.toList()))
        put("blockApps", blockApps)
        put("blocked", JSONArray(blocked.toList()))
        put("allowed", JSONArray(allowed.toList()))
        put("pinScreen", pinScreen)
        put("breakSeconds", breakSeconds)
        put("breakLimit", breakLimit)
        put("allowBreaks", allowBreaks)
        put("allowExit", allowExit)
        put("guardEscape", guardEscape)
        put("unlockTyping", unlockTyping)
        put("unlockDelaySec", unlockDelaySec)
        put("unlockPersianText", unlockPersianText)
        put("defaultMinutes", defaultMinutes)
        put("autoWithTimer", autoWithTimer)
        put("shareToServer", shareToServer)
        put("shareReports", shareReports)
        put("onboarded", onboarded)
        put("schedules", JSONArray(schedules.map { it.toJson() }))
    }

    companion object {
        private fun setOf(a: JSONArray?): Set<String> {
            if (a == null) return emptySet()
            val out = LinkedHashSet<String>()
            for (i in 0 until a.length()) {
                val v = a.optString(i)
                if (!v.isNullOrBlank()) out.add(v)
            }
            return out
        }

        private fun schedules(a: JSONArray?): List<FocusSchedule> {
            if (a == null) return emptyList()
            val out = ArrayList<FocusSchedule>(a.length())
            for (i in 0 until a.length()) {
                a.optJSONObject(i)?.let { FocusSchedule.fromJson(it) }?.let { out.add(it) }
            }
            return out
        }

        fun fromJson(o: JSONObject): FocusConfig {
            val d = FocusConfig()
            return FocusConfig(
                mode = FocusMode.of(o.optString("mode", d.mode.id)),
                lockChat = o.optBoolean("lockChat", d.lockChat),
                lockSocial = o.optBoolean("lockSocial", d.lockSocial),
                silenced = if (o.has("silenced")) setOf(o.optJSONArray("silenced")) else d.silenced,
                useDnd = o.optBoolean("useDnd", d.useDnd),
                perAppSilence = o.optBoolean("perAppSilence", d.perAppSilence),
                silencedApps = setOf(o.optJSONArray("silencedApps")),
                blockApps = o.optBoolean("blockApps", d.blockApps),
                blocked = setOf(o.optJSONArray("blocked")),
                allowed = setOf(o.optJSONArray("allowed")),
                pinScreen = o.optBoolean("pinScreen", d.pinScreen),
                breakSeconds = o.optInt("breakSeconds", d.breakSeconds).coerceIn(30, 300),
                breakLimit = o.optInt("breakLimit", d.breakLimit).coerceIn(0, 10),
                allowBreaks = o.optBoolean("allowBreaks", d.allowBreaks),
                allowExit = o.optBoolean("allowExit", d.allowExit),
                guardEscape = o.optBoolean("guardEscape", d.guardEscape),
                unlockTyping = o.optBoolean("unlockTyping", d.unlockTyping),
                unlockDelaySec = o.optInt("unlockDelaySec", d.unlockDelaySec).coerceIn(0, 300),
                unlockPersianText = o.optBoolean("unlockPersianText", d.unlockPersianText),
                defaultMinutes = o.optInt("defaultMinutes", d.defaultMinutes).coerceIn(5, 480),
                autoWithTimer = o.optBoolean("autoWithTimer", d.autoWithTimer),
                shareToServer = o.optBoolean("shareToServer", d.shareToServer),
                shareReports = o.optBoolean("shareReports", d.shareReports),
                schedules = schedules(o.optJSONArray("schedules")),
                onboarded = o.optBoolean("onboarded", d.onboarded),
            )
        }

    }
}

/**
 * یک نشست تمرکز در حال اجرا.
 *
 * [endAt] مطلق است و روی دیسک می‌نشیند، پس کشته شدن پروسه، ریبوت یا Force Stop
 * قفل را باطل نمی‌کند؛ چیزی که کل قابلیت روی آن سوار است.
 *
 * [config] هم اسنپ‌شات گرفته می‌شود تا تغییر تنظیمات وسط نشست، قواعدِ همان نشست
 * را عوض نکند (راه فرار کلاسیک: رفتن به تنظیمات و خاموش کردن قفل).
 */
data class FocusSession(
    val startAt: Long,
    val endAt: Long,
    val plannedMinutes: Int,
    val config: FocusConfig,
    /** کد «قفل گروهی» اگر نشست با دوستان است. */
    val groupCode: String? = null,
    /** تا این لحظه استراحت است و قفل موقتاً برداشته شده. */
    val breakUntil: Long = 0L,
    val breaksUsed: Int = 0,
) {
    val mode: FocusMode get() = config.mode

    fun toJson(): JSONObject = JSONObject().apply {
        put("startAt", startAt)
        put("endAt", endAt)
        put("plannedMinutes", plannedMinutes)
        put("config", config.toJson())
        put("groupCode", groupCode ?: JSONObject.NULL)
        put("breakUntil", breakUntil)
        put("breaksUsed", breaksUsed)
    }

    companion object {
        fun fromJson(o: JSONObject): FocusSession? {
            val end = o.optLong("endAt", 0L)
            if (end <= 0L) return null
            val cfg = o.optJSONObject("config")?.let { FocusConfig.fromJson(it) } ?: FocusConfig()
            return FocusSession(
                startAt = o.optLong("startAt", 0L),
                endAt = end,
                plannedMinutes = o.optInt("plannedMinutes", 0),
                config = cfg,
                groupCode = o.optString("groupCode").takeIf { it.isNotBlank() && it != "null" },
                breakUntil = o.optLong("breakUntil", 0L),
                breaksUsed = o.optInt("breaksUsed", 0),
            )
        }
    }
}

/** آنچه در زمان قفل جلویش گرفته شد — برای کارت «کیف تمرکز» بعد از پایان نشست. */
data class FocusRecap(
    val minutes: Int,
    val broke: Boolean,
    val suppressedNotifs: Int,
    val blockedOpens: Int,
)

/**
 * متن‌های تعهدی که کاربر برای باز کردن قفل باید تایپ کند.
 *
 * متن‌های قبلی فارسیِ ادبی بودند و نویسه‌هایی داشتند که با کیبورد معمولی
 * تایپ‌شان سخت یا ناممکن بود (همزه، نیم‌فاصله، گیومهٔ فارسی). حالا پیش‌فرض
 * انگلیسیِ ساده است و گزینهٔ فارسی هم فقط حروف پایه دارد.
 */
object UnlockTexts {

    /** انگلیسی ساده — پیش‌فرض، چون روی هر کیبوردی تایپ می‌شود. */
    private val EN = listOf(
        "I am choosing to break my own focus session right now and nobody else is responsible for this",
        "My study goal for today is not finished yet but I am stopping this focus session on purpose",
        "Every time I break the lock the next time becomes easier and I still choose to open it now",
        "The minutes I spend on my phone now are taken from my own study time and nobody gives them back",
    )

    /** فارسی ساده: بدون همزه، نیم‌فاصله و گیومه. */
    private val FA = listOf(
        "من خودم تصمیم گرفتم قفل تمرکز را بشکنم و مسئول این تصمیم خودم هستم",
        "هدف امروز من تمام نشده ولی با انتخاب خودم این نشست را نیمه کاره رها میکنم",
        "هر بار شکستن قفل دفعه بعد را اسان تر میکند و باز هم خودم قفل را باز میکنم",
        "این دقیقه ها از وقت درس خودم کم میشود و هیچ کس جای ان را پر نمیکند",
    )

    fun random(seed: Long = System.currentTimeMillis(), persian: Boolean = false): String {
        val list = if (persian) FA else EN
        return list[((seed / 1000L) % list.size).toInt().coerceAtLeast(0)]
    }

    /** مقایسهٔ ساده‌شده: فاصله‌ها، بزرگی/کوچکی حروف و نویسه‌های عربی/فارسی یکسان می‌شوند. */
    fun matches(expected: String, typed: String): Boolean =
        normalize(expected) == normalize(typed)

    fun normalize(s: String): String = s
        .lowercase()
        .replace('\u064A', '\u06CC')
        .replace('\u0643', '\u06A9')
        .replace('\u200C', ' ')
        .replace(Regex("[\\s\u060C\u061B.,!?؟«»\"'()]+"), " ")
        .trim()
}
