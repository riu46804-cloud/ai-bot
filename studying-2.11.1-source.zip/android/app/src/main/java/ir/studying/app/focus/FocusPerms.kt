package ir.studying.app.focus

import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.text.TextUtils

/**
 * وضعیت دسترسی‌ها + انتخاب خودکار موتور قفل.
 *
 * هیچ جای دیگری از کد نباید خودش با AppOps یا رشتهٔ سرویس‌های دسترسی‌پذیری ور برود؛
 * این جواب‌ها روی برندهای مختلف حساس‌اند و باید یک جا درست شوند.
 */
object FocusPerms {

    /** کدام موتور برای تشخیص اپِ جلو استفاده شود. */
    enum class Engine { NONE, USAGE_OVERLAY, ACCESSIBILITY }

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    ctx.packageName,
                )
            } else {
                @Suppress("DEPRECATION")
                ops.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    ctx.packageName,
                )
            }
        } catch (_: Exception) {
            return false
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlay(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(ctx) else true

    fun hasDndAccess(ctx: Context): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return false
        return if (Build.VERSION.SDK_INT >= 23) nm.isNotificationPolicyAccessGranted else false
    }

    /** دسترسی خواندن اعلان‌ها (برای سکوت گزینشی اپ‌به‌اپ). */
    fun hasNotifListener(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(ctx.packageName)
    }

    fun hasAccessibility(ctx: Context): Boolean {
        val expected = ComponentName(ctx, FocusAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            ctx.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            val part = splitter.next()
            if (part.equals(expected, ignoreCase = true) ||
                part.equals(expected.replace("/", "/.").replace(ctx.packageName + "/." + ctx.packageName, ctx.packageName + "/"), ignoreCase = true) ||
                part.startsWith(ctx.packageName + "/") && part.contains("FocusAccessibilityService")
            ) return true
        }
        return false
    }

    /**
     * موتور مناسب را خودش انتخاب می‌کند.
     *
     * دسترسی‌پذیری ارجح است چون رویدtime واقعی واکنش می‌دهد و مصرف باتری ندارد؛
     * اگر فعال نباشد، سراغ UsageStats + رویه می‌رویم. اگر هیچ‌کدام نبود، قفلِ درون‌اپی
     * (لایهٔ ۱) همچنان بی‌نقص کار می‌کند — قابلیت هرگز کاملاً زمین نمی‌خورد.
     */
    fun engine(ctx: Context): Engine = when {
        hasAccessibility(ctx) -> Engine.ACCESSIBILITY
        hasUsageAccess(ctx) && hasOverlay(ctx) -> Engine.USAGE_OVERLAY
        else -> Engine.NONE
    }

    fun engineLabel(e: Engine): String = when (e) {
        Engine.ACCESSIBILITY -> "سرویس دسترسی‌پذیری (سریع‌ترین)"
        Engine.USAGE_OVERLAY -> "آمار مصرف + رویه"
        Engine.NONE -> "فقط قفل درون اپ"
    }

    /* ---------- مسیرهای دادن دسترسی ---------- */

    private fun open(ctx: Context, intent: Intent) {
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }


    /** کاربر را مستقیماً به نزدیک‌ترین صفحهٔ دسترسی لازم برای حالت فعلی می‌برد. */
    fun openFirstMissing(ctx: Context, mode: FocusMode) {
        val snap = PermState.current(ctx)
        when (mode) {
            FocusMode.APPS, FocusMode.ALL_BUT_CALLS -> when {
                snap.accessibility -> Unit
                !snap.usage -> openUsageAccess(ctx)
                !snap.overlay -> openOverlay(ctx)
                else -> openAccessibility(ctx)
            }
            FocusMode.TOTAL -> if (!snap.deviceAdmin) DeviceLock.request(ctx) else Unit
        }
    }

    fun openUsageAccess(ctx: Context) = open(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    fun openOverlay(ctx: Context) = open(
        ctx,
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)),
    )

    fun openDndAccess(ctx: Context) =
        open(ctx, Intent("android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS"))

    fun openNotifListener(ctx: Context) =
        open(ctx, Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))

    fun openAccessibility(ctx: Context) = open(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    /**
     * معافیت بهینه‌سازی باتری.
     *
     * روی خیلی از گوشی‌های رایج بازار ایران (شاومی، هواوی، اوپو، ویوو، ریلمی)
     * سرویس پیش‌زمینه بی‌این معافیت بعد از چند دقیقه بی‌صدا کشته می‌شود و قفل وا می‌رود.
     */
    fun isBatteryExempt(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager ?: return true
        return try { pm.isIgnoringBatteryOptimizations(ctx.packageName) } catch (_: Exception) { true }
    }

    fun openBatteryExempt(ctx: Context) {
        if (Build.VERSION.SDK_INT < 23) return
        open(
            ctx,
            Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + ctx.packageName),
            ),
        )
    }

    /** صفحهٔ «اجرای خودکار» برندهای چینی؛ اگر نبود، به تنطیمات اپ می‌رویم. */
    fun openAutoStart(ctx: Context) {
        val candidates = listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"),
        )
        for (c in candidates) {
            val i = Intent().setComponent(c).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (ctx.packageManager.resolveActivity(i, 0) != null) {
                try { ctx.startActivity(i); return } catch (_: Exception) { }
            }
        }
        open(
            ctx,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)),
        )
    }
}
