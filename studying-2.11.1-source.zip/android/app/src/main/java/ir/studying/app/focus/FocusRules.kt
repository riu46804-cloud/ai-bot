package ir.studying.app.focus

/**
 * تمام تصمیم‌های «این را قفل کنم یا نه؟» در یک جا، خالص و بدون Context.
 *
 * دلیل جدا بودنش: این قواعد از چند جای مختلف صدا می‌شوند (UI، سرویس نگهبان،
 * سرویس دسترسی‌پذیری، NotificationListener، مرکز اعلان‌ها) و اگر هر کدام نسخهٔ خودش را
 * داشته باشد، بالاخره یکیشان با بقیه فرق پیدا می‌کند و قفل سوراخ می‌شود.
 */
object FocusRules {

    /** مسیرهای ناوبری که جزء بخش چت هستند. */
    private val CHAT_ROUTES = setOf("messages")

    /** مسیرهای شبکهٔ اجتماعی. */
    private val SOCIAL_ROUTES = setOf("community", "feed")

    /**
     * اپ‌هایی که در حالتِ «قفل اپ‌های منتخب» تحت هیچ شرایطی قفل نمی‌شوند.
     *
     * این لیست مسئلهٔ ایمنی است، نه راحتی: کاربر باید بتواند تماس اورژانس بگیرد و به
     * تنطیمات سیستم برسد.
     */
    val NEVER_BLOCK: Set<String> = setOf(
        "com.android.dialer",
        "com.google.android.dialer",
        "com.samsung.android.dialer",
        "com.android.server.telecom",
        "com.android.phone",
        "com.android.incallui",
        "com.android.emergency",
        "com.android.mms",
        "com.samsung.android.messaging",
        "com.google.android.apps.messaging",
        "com.android.settings",
        "com.android.systemui",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "android",
    )

    /**
     * پیشوند/ریشه‌هایی که در حالت‌های سخت (همه‌چیز جز تماس، قفل کامل) باز می‌مانند.
     *
     * اسم بستهٔ اپ تلفن و پیامک روی برندهای مختلف فرق می‌کند، پس به جای لیست
     * ثابت، الگوی نام را هم چک می‌کنیم تا روی هیچ گوشی تماس گرفتن ممکن نشود.
     */
    private val CALL_HINTS = listOf(
        "dialer", "telecom", "incallui", "emergency",
        "messaging", "", // placeholder replaced below
    ).filter { it.isNotEmpty() }

    private val SMS_HINTS = listOf("messag", ".mms", "sms")

    /** اجزای سیستمی که مسدود کردنشان گوشی را به حلقهٔ بی‌پایان می‌برد. */
    private val SYSTEM_CRITICAL = setOf(
        "android",
        "com.android.systemui",
        "com.android.server.telecom",
        "com.android.phone",
        "com.android.incallui",
        "com.android.emergency",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
    )

    /**
     * مسیرهای حذف اپ. در زمان قفل، این‌ها همیشه مسدودند تا کاربر نتواند وسط
     * نشست اپ را پاک کند. سنگر اصلی «مدیر دستگاه» است که خودِ اندروید را
     * وادار می‌کند حذف را رد کند؛ این لایه مسیر رسیدن به صفحهٔ حذف را هم می‌بندد.
     */
    val UNINSTALL_GUARD: Set<String> = setOf(
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.samsung.android.packageinstaller",
        "com.miui.packageinstaller",
        "com.oppo.packageinstaller",
    )

    /**
     * مسیرهای «پس گرفتن دسترسی» — صفحهٔ جزئیات اپ، دسترسی‌پذیری، مدیر دستگاه.
     *
     * نام بستهٔ تنظیمات روی برندها فرق می‌کند، پس هم فهرست و هم الگوی نام چک
     * می‌شود. این‌ها فقط در «نگهبانی فرار» استفاده می‌شوند، نه قفل عادی.
     */
    private val SETTINGS_GUARD: Set<String> = setOf(
        "com.android.settings",
        "com.miui.securitycenter",
        "com.samsung.android.lool",
        "com.coloros.safecenter",
        "com.oppo.safe",
        "com.huawei.systemmanager",
        "com.vivo.permissionmanager",
        "com.iqoo.secure",
    )

    /** آیا این بسته یکی از مسیرهای پس‌گرفتن دسترسی/حذف است؟ */
    fun isEscapeRoute(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (isUninstallRoute(pkg)) return true
        if (SETTINGS_GUARD.contains(pkg)) return true
        val p = pkg.lowercase()
        return p.endsWith(".settings") || p.contains("securitycenter") || p.contains("safecenter")
    }

    /**
     * نگهبانی فرار: حتی در استراحت هم فعال است.
     *
     * چرا: قبلاً در پنجرهٔ استراحت همهٔ سدها برداشته می‌شد و کاربر می‌توانست
     * دسترسی‌ها را پس بگیرد یا اپ را حذف کند و قفل را برای همیشه بی‌اثر کند.
     */
    fun isEscapeBlocked(pkg: String?, session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (!isActive(session, now)) return false
        // حذف اپ همیشه ممنوع است، در هر حالتی.
        if (isUninstallRoute(pkg)) return true
        if (!session!!.config.guardEscape) return false
        /* صفحهٔ تنظیمات/دسترسی‌ها را فقط جایی می‌بندیم که راه فرار است: در پنجرهٔ
           استراحت (که بقیهٔ سدها برداشته‌اند) و در حالت‌های سخت. در «قفل اپ‌های
           منتخب» تنظیمات باز می‌ماند، چون آن حالت قرار است سبک باشد. */
        val risky = inBreak(session, now) || session.config.mode != FocusMode.APPS
        return risky && isEscapeRoute(pkg)
    }

    /** آیا خروج اضطراری از این نشست اجازه دارد؟ */
    fun canExit(session: FocusSession?): Boolean = session?.config?.allowExit ?: true

    /** آیا این نشست اجازهٔ استراحت دارد؟ */
    fun breaksAllowed(session: FocusSession?): Boolean {
        val c = session?.config ?: return false
        return c.allowBreaks && c.breakLimit > 0
    }

    /** آیا این بسته، مسیر حذف نصب اپ است؟ */
    fun isUninstallRoute(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (UNINSTALL_GUARD.contains(pkg)) return true
        val p = pkg.lowercase()
        return p.contains("packageinstaller") || p.contains("packageuninstaller")
    }

    /** آیا این نشست باید صفحه را پین کند؟ */
    fun needsScreenPin(session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean {
        if (!isActive(session, now)) return false
        if (inBreak(session, now)) return false
        val c = session!!.config
        // پین با هر حالتی جمع می‌شود، جز قفل کامل که صفحه را خاموش می‌کند.
        return c.pinScreen && c.mode != FocusMode.TOTAL
    }

    /** کانال‌های اعلان خود اپ که قفل هرگز ساکتشان نمی‌کند — خودِ کارکردِ تمرکزند. */
    val ALWAYS_ALLOWED_CHANNELS: Set<String> = setOf("study", "focus")

    fun isActive(session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean =
        session != null && now < session.endAt

    fun remainingMs(session: FocusSession?, now: Long = System.currentTimeMillis()): Long =
        if (session == null) 0L else (session.endAt - now).coerceAtLeast(0L)

    fun elapsedMinutes(session: FocusSession?, now: Long = System.currentTimeMillis()): Int {
        if (session == null) return 0
        val end = if (now < session.endAt) now else session.endAt
        return (((end - session.startAt) / 60000L).coerceAtLeast(0L)).toInt()
    }

    /** الان در پنجرهٔ استراحت هستیم؟ در این حالت هیچ چیز مسدود نمی‌شود. */
    fun inBreak(session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean =
        session != null && now < session.breakUntil

    fun breakRemainingMs(session: FocusSession?, now: Long = System.currentTimeMillis()): Long =
        if (session == null) 0L else (session.breakUntil - now).coerceAtLeast(0L)

    fun breaksLeft(session: FocusSession?): Int =
        if (session == null) 0 else (session.config.breakLimit - session.breaksUsed).coerceAtLeast(0)

    /** در قفل کامل، صفحه باید خاموش نگه داشته شود. */
    fun isTotalLock(session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean =
        isActive(session, now) && !inBreak(session, now) && session!!.config.mode == FocusMode.TOTAL

    /** آیا این تب/مسیر درون‌اپی الان قفل است؟ */
    fun isRouteLocked(route: String?, session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean {
        if (route == null) return false
        if (!isActive(session, now)) return false
        if (inBreak(session, now)) return false
        val c = session!!.config
        return when {
            CHAT_ROUTES.contains(route) -> c.lockChat
            SOCIAL_ROUTES.contains(route) -> c.lockSocial
            else -> false
        }
    }

    /**
     * کیبورد هیچ‌وقت «اپ مزاحم» نیست.
     *
     * باگ: باز شدن کیبورد یک رویداد پنجره با نام بستهٔ خودش می‌سازد و نگهبان آن
     * را اپ غریبه می‌دید، صفحهٔ سد را می‌آورد و اپ بسته می‌شد — دقیقاً وسط تایپِ
     * متن خروج. حالا بستهٔ همهٔ کیبوردهای نصب‌شده از قفل مستثنی است.
     */
    fun isKeyboard(pkg: String?, imePkgs: Set<String>): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (imePkgs.contains(pkg)) return true
        val p = pkg.lowercase()
        return p.contains("inputmethod") || p.contains("keyboard") || p.contains("latin") ||
            p.contains("gboard") || p.contains("swiftkey")
    }

    fun isCallApp(pkg: String): Boolean {
        val p = pkg.lowercase()
        if (NEVER_BLOCK.contains(pkg)) return true
        return CALL_HINTS.any { p.contains(it) } || SMS_HINTS.any { p.contains(it) }
    }

    /**
     * آیا این بستهٔ خارجی باید مسدود شود؟
     *
     * رفتار بر اساس [FocusMode] عوض می‌شود:
     * - `APPS`: فقط لیست انتخابی.
     * - `ALL_BUT_CALLS`: همه‌چیز جز تماس/پیامک، خود اپ و اجزای حیاتی سیستم؛ لانچر و
     *   منوهای گوشی هم مسدودند.
     * - `TOTAL`: همه‌چیز (مراقبت اصلی با خاموش کردن صفحه انجام می‌شود).
     *
     * [extraAllowed] برای چیزهایی است که فقط در زمان اجرا معلوم‌اند: خودِ این اپ،
     * لانچر فعلی، اپ تلفنِ پیش‌فرض و اپ پیامک.
     */
    fun isAppBlocked(
        pkg: String?,
        session: FocusSession?,
        extraAllowed: Set<String> = emptySet(),
        now: Long = System.currentTimeMillis(),
        selfPkg: String? = null,
    ): Boolean {
        if (pkg.isNullOrBlank()) return false
        if (!isActive(session, now)) return false
        if (inBreak(session, now)) return false
        val c = session!!.config
        if (selfPkg != null && pkg == selfPkg) return false
        // کیبورد جزء رابط کاربر است، نه اپ مزاحم.
        if (isKeyboard(pkg, extraAllowed)) return false
        // حذف اپ در زمان قفل ممنوع است — در همهٔ حالت‌ها، حتی پین.
        if (isUninstallRoute(pkg)) return true
        if (SYSTEM_CRITICAL.contains(pkg)) return false

        return when (c.mode) {
            FocusMode.APPS -> {
                if (!c.blockApps) false
                else if (NEVER_BLOCK.contains(pkg)) false
                else if (extraAllowed.contains(pkg)) false
                else if (c.allowed.contains(pkg)) false
                else c.blocked.contains(pkg)
            }

            // همه‌چیز بسته است مگر تماس/پیامک یا استثنای خود کاربر.
            FocusMode.ALL_BUT_CALLS ->
                !isCallApp(pkg) && !c.allowed.contains(pkg)

            FocusMode.TOTAL -> !isCallApp(pkg)
        }
    }

    /**
     * اعلان خودِ اپ.
     *
     * [key] هم می‌تواند نام کانال باشد (`messages`، `social`، `reminder`، `study`) و هم نوع
     * اعلان سرور (`dm`، `follow`، `post_like`…).
     */
    fun isOwnNotifAllowed(key: String, session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean {
        if (!isActive(session, now)) return true
        if (inBreak(session, now)) return true
        val channel = channelOf(key)
        if (ALWAYS_ALLOWED_CHANNELS.contains(channel)) return true
        return !session!!.config.silenced.contains(channel)
    }

    /** نوع اعلان سرور → کانال اعلان محلی. */
    fun channelOf(key: String): String = when (key) {
        "dm", "messages", "group_reply", "reaction" -> "messages"
        "reminder" -> "reminder"
        "study", "focus" -> "study"
        else -> "social"
    }

    /** آیا اعلان اپ خارجی باید ساکت/تعویق شود؟ */
    fun isForeignNotifSilenced(
        pkg: String?,
        session: FocusSession?,
        selfPkg: String,
        now: Long = System.currentTimeMillis(),
    ): Boolean {
        if (pkg.isNullOrBlank() || pkg == selfPkg) return false
        if (!isActive(session, now)) return false
        if (inBreak(session, now)) return false
        val c = session!!.config
        if (isCallApp(pkg)) return false
        if (c.mode == FocusMode.ALL_BUT_CALLS || c.mode == FocusMode.TOTAL) return true
        if (!c.perAppSilence) return false
        // لیست خالی = همان اپ‌هایی که قفلشان کرده؛ دو بار انتخاب کردن یک لیست آزاردهنده است.
        val list = if (c.silencedApps.isNotEmpty()) c.silencedApps else c.blocked
        return list.contains(pkg)
    }

    /** دیپ‌لینکی که به مقصدِ قفل‌شده می‌رود باید بلع شود. */
    fun isDeepLinkLocked(route: String?, session: FocusSession?, now: Long = System.currentTimeMillis()): Boolean =
        isRouteLocked(route, session, now)

    /** متن شمارش معکوس به شکل mm:ss یا h:mm:ss. */
    fun clock(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(java.util.Locale.US, "%02d:%02d", m, s)
    }
}
