package ir.studying.app.focus

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * زمان‌بندی قفل.
 *
 * هر زمان‌بندی یک آلارم دقیق دارد که در ساعت مقرر [FocusAlarmReceiver] را بیدار می‌کند و
 * نشست را خودکار شروع می‌کند. پس از اجرا، آلارم بعدی همان زمان‌بندی دوباره
 * چیده می‌شود (تکرار دستی، چون آلارمِ تکرارشوندهٔ دقیق در اندروید وجود ندارد).
 */
object FocusScheduler {

    const val ACTION_FIRE = "ir.studying.app.focus.SCHEDULE_FIRE"
    const val EXTRA_ID = "sid"

    private fun am(ctx: Context): AlarmManager? =
        ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    private fun pending(ctx: Context, s: FocusSchedule): PendingIntent {
        val i = Intent(ctx, FocusAlarmReceiver::class.java).apply {
            action = ACTION_FIRE
            putExtra(EXTRA_ID, s.id)
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(ctx, 7300 + (s.id % 500), i, flags)
    }

    /** آیا می‌توانیم آلارم دقیق بگذاریم؟ (اندروید ۱۲+) */
    fun canExact(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT < 31) true
        else try { am(ctx)?.canScheduleExactAlarms() == true } catch (_: Exception) { false }

    /** بعدین زمان اجرای یک زمان‌بندی. */
    fun nextTrigger(s: FocusSchedule, from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.HOUR_OF_DAY, s.hour)
            set(Calendar.MINUTE, s.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= from + 1_000L) c.add(Calendar.DAY_OF_YEAR, 1)
        if (s.days.isNotEmpty()) {
            var guard = 0
            while (!s.days.contains(c.get(Calendar.DAY_OF_WEEK)) && guard < 8) {
                c.add(Calendar.DAY_OF_YEAR, 1)
                guard++
            }
        }
        return c.timeInMillis
    }

    /** تمام آلارم‌ها را مطابق تنطیمات فعلی از نو می‌چیند. */
    fun sync(ctx: Context, config: FocusConfig) {
        val a = am(ctx) ?: return
        // اول همه را لغو کن؛ چیدمان مجدد ارزان‌تر از دنبال کردن تغییرات است.
        for (id in 0 until 12) {
            val fake = FocusSchedule(id = id, minuteOfDay = 0, minutes = 1)
            try { a.cancel(pending(ctx, fake)) } catch (_: Exception) { }
        }
        for (s in config.schedules) {
            if (!s.enabled) continue
            val at = nextTrigger(s)
            val pi = pending(ctx, s)
            try {
                if (canExact(ctx)) {
                    if (Build.VERSION.SDK_INT >= 23) a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    else a.setExact(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    if (Build.VERSION.SDK_INT >= 23) a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    else a.set(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } catch (_: Exception) { }
        }
    }

    /** صفحهٔ سیستمی اجازهٔ آلارم دقیق. */
    fun openExactAlarmSettings(ctx: Context) {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            ctx.startActivity(
                Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM")
                    .setData(android.net.Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (_: Exception) { }
    }

    /** متن روزهای هفته. */
    fun daysLabel(days: Set<Int>): String {
        if (days.isEmpty()) return "هر روز"
        val names = mapOf(
            Calendar.SATURDAY to "ش",
            Calendar.SUNDAY to "ی",
            Calendar.MONDAY to "د",
            Calendar.TUESDAY to "س",
            Calendar.WEDNESDAY to "چ",
            Calendar.THURSDAY to "پ",
            Calendar.FRIDAY to "ج",
        )
        val order = listOf(
            Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY,
            Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY,
        )
        return order.filter { days.contains(it) }.joinToString("\u060C") { names[it] ?: "" }
    }
}

/**
 * آلارم زمان‌بندی: نشست را شروع می‌کند و آلارم بعدی را می‌چیند.
 */
class FocusAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != FocusScheduler.ACTION_FIRE) return
        val id = intent.getIntExtra(FocusScheduler.EXTRA_ID, -1)
        val app = context.applicationContext
        FocusService.ensureChannel(app)
        FocusLock.init(app)
        FocusLock.startFromSchedule(app, id)
    }
}
