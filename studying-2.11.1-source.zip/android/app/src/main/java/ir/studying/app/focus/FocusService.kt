package ir.studying.app.focus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import ir.studying.app.MainActivity
import ir.studying.app.R

/**
 * نگهبان نشست تمرکز.
 *
 * دو کار می‌کند:
 * ۱. اعلان پیش‌زمینهٔ شمارش معکوس را نگه می‌دارد — هم شفافیت است و هم تنها راه
 *    زنده ماندن پس از بستن اپ.
 * ۲. اگر موتور فعال UsageStats باشد، هر چند صدمیلی‌ثانیه اپِ جلو را چک می‌کند.
 *    اگر موتور دسترسی‌پذیری فعال باشد، پولینگ انجام نمی‌شود (بی‌فایده و باتری‌خور).
 *
 * پولینگ با خاموش شدن صفحه متوقف می‌شود؛ وقتی صفحه خاموش است هیچ اپی جلو
 * نیست که بخواهیم سدش کنیم.
 */
class FocusService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var screenOn = true

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    screenOn = true
                    // قفل کامل: صفحه روشن شد، بی‌درنگ خاموش.
                    DeviceLock.enforceIfNeeded(this@FocusService)
                    handler.removeCallbacks(loop)
                    handler.post(loop)
                }
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    AppWatcher.reset()
                }
            }
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            val s = FocusLock.session.value
            if (s == null || !FocusRules.isActive(s)) {
                stopSelf()
                return
            }
            notify(FocusRules.remainingMs(s))
            // در حالت‌های سخت (همه‌چیز جز تماس / قفل کامل) نگهبانی به پرچم
            // blockApps وابسته نیست؛ خودِ حالت یعنی همه‌چیز بسته است.
            val needsWatch = s.config.blockApps ||
                s.config.mode == FocusMode.ALL_BUT_CALLS ||
                s.config.mode == FocusMode.TOTAL
            if (screenOn && needsWatch &&
                FocusPerms.engine(this@FocusService) == FocusPerms.Engine.USAGE_OVERLAY
            ) {
                AppWatcher.tick(this@FocusService)
            }
            if (screenOn) DeviceLock.enforceIfNeeded(this@FocusService)
            handler.postDelayed(this, if (screenOn) AppWatcher.POLL_MS else 15_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
        startForeground(NOTIF_ID, build(FocusRules.remainingMs(FocusLock.session.value)))
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, f)
        /* سرویس ممکن است بعد از کشته‌شدن توسط سیستم دوباره ساخته شود؛ در آن حالت
           هنوز هیچ‌کس نشست را از دیسک نخوانده است. */
        FocusLock.init(this)
        FocusLock.resumeIfActive(this)
        FocusWatchdog.arm(this)
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            /* اگر نشست «بدون خروج» است، توقف از اعلان هم کار نمی‌کند و سرویس
               زنده می‌ماند؛ وگرنه کافی بود کاربر از اعلان قفل را خلاص کند. */
            if (!FocusLock.canExit()) {
                notify(FocusRules.remainingMs(FocusLock.session.value))
                return START_STICKY
            }
            FocusLock.breakOut()
            stopSelf()
            return START_NOT_STICKY
        }
        notify(FocusRules.remainingMs(FocusLock.session.value))
        // START_STICKY: اگر سیستم ما را کشت، دوباره برگرد؛ مهلت نشست روی دیسک است.
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notify(remaining: Long) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        try { nm.notify(NOTIF_ID, build(remaining)) } catch (_: Exception) { }
    }

    private fun build(remaining: Long): Notification {
        val open = PendingIntent.getActivity(
            this,
            910,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )
        val s = FocusLock.session.value
        val title = (s?.config?.mode?.emoji ?: "\uD83C\uDFAF") + " حالت تمرکز فعال است"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText("تا پایان: " + FocusRules.clock(remaining))
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val CHANNEL = "focus"
        const val NOTIF_ID = 1011
        const val ACTION_STOP = "ir.studying.app.focus.STOP"

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val ch = NotificationChannel(CHANNEL, "حالت تمرکز", NotificationManager.IMPORTANCE_LOW).apply {
                description = "شمارش معکوس قفل تمرکز"
                setShowBadge(false)
                enableVibration(false)
            }
            try { nm.createNotificationChannel(ch) } catch (_: Exception) { }
        }

        fun start(ctx: Context) {
            val i = Intent(ctx, FocusService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Exception) { }
        }

        /** بروزرسانی اعلان پس از تمدید. */
        fun refresh(ctx: Context) = start(ctx)

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, FocusService::class.java)) } catch (_: Exception) { }
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            try { nm?.cancel(NOTIF_ID) } catch (_: Exception) { }
        }
    }
}
