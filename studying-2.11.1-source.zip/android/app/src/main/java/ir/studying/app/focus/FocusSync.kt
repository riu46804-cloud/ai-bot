package ir.studying.app.focus

import ir.studying.app.core.Api
import ir.studying.app.core.Store
import ir.studying.app.core.int
import ir.studying.app.core.objects
import ir.studying.app.core.str
import org.json.JSONArray
import org.json.JSONObject

/**
 * لایهٔ اجتماعی قفل تمرکز: ثبت نشست، لیدربورد تمرکز و «قفل گروهی».
 *
 * همهٔ خطاها بلع می‌شوند: قفل یک قابلیتِ محلی است و نباید به سرور گرو باشد.
 * اگر اینترنت نبود، نشست کاملاً سالم کار می‌کند و فقط رکوردش بعداً می‌رود.
 */
object FocusSync {

    data class TopRow(val username: String, val avatar: String?, val minutes: Int, val sessions: Int)

    /** نشست‌هایی که هنگام پایانِ آن‌ها اینترنت نبوده؛ دفعهٔ بعد دوباره فرستاده می‌شوند. */
    private const val QUEUE_KEY = "focus_outbox"

    suspend fun log(
        startAt: Long,
        endAt: Long,
        minutes: Int,
        broke: Boolean,
        profile: String,
        groupCode: String?,
    ) {
        val body = JSONObject().apply {
            put("started_at", startAt / 1000L)
            put("ended_at", endAt / 1000L)
            put("minutes", minutes)
            put("broke", if (broke) 1 else 0)
            put("profile", profile)
            if (!groupCode.isNullOrBlank()) put("group_code", groupCode)
        }
        if (!send(body)) enqueue(body)
    }

    private suspend fun send(body: JSONObject): Boolean = try {
        val raw = Api.post("focus_log", body)
        /* قفل کاملِ نشکسته حالا پاداش دارد؛ سرور پاداش‌ها را در همین پاسخ می‌دهد. */
        runCatching { ir.studying.app.core.Awards.announce(ir.studying.app.core.Awards.from(raw)) }
        true
    } catch (_: Exception) {
        false
    }

    private suspend fun enqueue(body: JSONObject) {
        try {
            val raw = Store.getString(QUEUE_KEY)
            val arr = if (raw.isNullOrBlank()) JSONArray() else JSONArray(raw)
            // سقف صف: صفِ بی‌سقف همان باگی بود که قبلاً در صف ارسال پارت‌ها درست شد.
            while (arr.length() >= 50) arr.remove(0)
            arr.put(body)
            Store.putString(QUEUE_KEY, arr.toString())
        } catch (_: Exception) { }
    }

    /** در اولین فرصتِ آنلاین، صف را خالی می‌کند. */
    suspend fun flush() {
        if (Store.token.isNullOrBlank()) return
        val raw = try { Store.getString(QUEUE_KEY) } catch (_: Exception) { null } ?: return
        if (raw.isBlank()) return
        val arr = try { JSONArray(raw) } catch (_: Exception) { return }
        val left = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!send(o)) left.put(o)
        }
        Store.putString(QUEUE_KEY, if (left.length() == 0) null else left.toString())
    }

    /** لیدربورد تمرکز در [days] روز گذشته. */
    suspend fun top(days: Int = 7): List<TopRow> = try {
        val text = Api.get("focus_top", "days" to days.toString())
        val root = JSONObject(text)
        (root.optJSONArray("top") ?: JSONArray()).objects().map {
            TopRow(
                username = it.str("username"),
                avatar = Api.avatarUrl(it.str("avatar").ifBlank { null }),
                minutes = it.int("minutes"),
                sessions = it.int("sessions"),
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    /**
     * انتشار گزارش نشست در صفحهٔ اجتماعی کاربر (همان پست معمولی).
     *
     * تصمیم «آیا باید منتشر شود؟» در FocusLock گرفته می‌شود؛ اینجا فقط ارسال است.
     */
    suspend fun shareReport(minutes: Int, mode: String) {
        try {
            val h = minutes / 60
            val m = minutes % 60
            val dur = if (m == 0) "$h ساعت" else "$h ساعت و $m دقیقه"
            Api.post(
                "post_create",
                JSONObject().put("text", "\uD83D\uDD12 گزارش قفل تمرکز: $dur مطالعهٔ بدون وقفه (حالت: $mode)"),
            )
        } catch (_: Exception) {
        }
    }
}
