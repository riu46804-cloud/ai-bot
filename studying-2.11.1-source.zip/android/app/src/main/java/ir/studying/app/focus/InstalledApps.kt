package ir.studying.app.focus

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable

/**
 * لیست اپ‌های قابل اجرا برای انتخاب در لیست قفل.
 *
 * عمداً از QUERY_ALL_PACKAGES استفاده نمی‌کنیم (درخواستِ حساسی که رد می‌شود)؛ تگ
 * `<queries>` با فیلتر MAIN/LAUNCHER دقیقاً همان چیزی را می‌دهد که لازم داریم: اپ‌هایی
 * که کاربر می‌تواند بازشان کند.
 */
object InstalledApps {

    data class Entry(
        val pkg: String,
        val label: String,
        val icon: Drawable?,
        /** دقیقهٔ استفاده در ۷ روز گذشته؛ برای مرتب‌سازی و پیشنهاد هوشمند. */
        val weekMinutes: Int,
    )

    /** دسته‌هایی که معمولاً مقصرِ وقت تلف‌کردن‌اند — برای دکمهٔ «پیشنهاد هوشمند». */
    private val USUAL_SUSPECTS = listOf(
        "instagram", "telegram", "whatsapp", "tiktok", "twitter", "x.android",
        "youtube", "facebook", "snapchat", "soroush", "eitaa", "rubika", "bale",
        "igap", "aparat", "filimo", "namava", "clash", "game", "pubg", "reddit",
        "discord", "pinterest", "linkedin", "divar", "sheypoor", "basalam",
    )

    fun list(ctx: Context, withIcons: Boolean = true): List<Entry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = try { pm.queryIntentActivities(intent, 0) } catch (_: Exception) { emptyList() }
        val usage = weekUsageMinutes(ctx)
        val seen = HashSet<String>()
        val out = ArrayList<Entry>(resolved.size)
        for (ri in resolved) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (pkg == ctx.packageName) continue
            if (FocusRules.NEVER_BLOCK.contains(pkg)) continue
            if (!seen.add(pkg)) continue
            val label = try { ri.loadLabel(pm).toString() } catch (_: Exception) { pkg }
            val icon = if (withIcons) try { ri.loadIcon(pm) } catch (_: Exception) { null } else null
            out.add(Entry(pkg, label, icon, usage[pkg] ?: 0))
        }
        // پرمصرف‌ها بالا؛ بقیه الفبایی تا پیدا کردنشان سخت نباشد.
        return out.sortedWith(compareByDescending<Entry> { it.weekMinutes }.thenBy { it.label })
    }

    /** پیشنهاد اولیهٔ لیست قفل: اپ‌های شناخته‌شدهٔ مزاحم که واقعاً استفاده می‌شوند. */
    fun suggest(entries: List<Entry>): Set<String> {
        val byUsage = entries.filter { it.weekMinutes >= 60 }.take(8).map { it.pkg }
        val byName = entries.filter { e -> USUAL_SUSPECTS.any { e.pkg.contains(it, ignoreCase = true) } }.map { it.pkg }
        return (byUsage + byName).toSet()
    }

    /** دقیقهٔ استفادهٔ ۷ روز گذشته؛ اگر دسترسی آمار نداریم مپ خالی می‌دهد (نه کرش). */
    fun weekUsageMinutes(ctx: Context): Map<String, Int> {
        if (!FocusPerms.hasUsageAccess(ctx)) return emptyMap()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
        val now = System.currentTimeMillis()
        val stats = try {
            usm.queryUsageStats(UsageStatsManager.INTERVAL_WEEKLY, now - 7L * 86_400_000L, now)
        } catch (_: Exception) { null } ?: return emptyMap()
        val out = HashMap<String, Int>()
        for (s in stats) {
            val m = (s.totalTimeInForeground / 60000L).toInt()
            if (m <= 0) continue
            out[s.packageName] = (out[s.packageName] ?: 0) + m
        }
        return out
    }

    /** بستهٔ همهٔ کیبوردهای نصب‌شده؛ یک‌بار خوانده و کش می‌شود. */
    @Volatile private var imeCache: Set<String>? = null

    fun imePackages(ctx: Context): Set<String> {
        imeCache?.let { return it }
        val out = HashSet<String>()
        try {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            imm?.inputMethodList?.forEach { out.add(it.packageName) }
            imm?.enabledInputMethodList?.forEach { out.add(it.packageName) }
        } catch (_: Exception) { }
        try {
            /* روی بعضی رام‌ها فهرست بالا خالی برمی‌گردد؛ از روی سرویس‌های IME هم می‌خوانیم. */
            val i = Intent("android.view.InputMethod")
            ctx.packageManager.queryIntentServices(i, 0).forEach { ri ->
                ri.serviceInfo?.packageName?.let { out.add(it) }
            }
        } catch (_: Exception) { }
        imeCache = out
        return out
    }

    fun label(ctx: Context, pkg: String): String = try {
        val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
        ctx.packageManager.getApplicationLabel(ai).toString()
    } catch (_: Exception) { pkg }

    /**
     * اپ‌هایی که در زمان اجرا باید مجاز بمانند: خودِ اپ، لانچر فعلی، تلفنِ پیش‌فرض
     * و اپ پیامک. اگر لانچر قفل شود، گوشی عملاً قفلِ دائم می‌شود — خطرناک.
     */
    fun runtimeAllowed(ctx: Context): Set<String> {
        val out = HashSet<String>()
        out.add(ctx.packageName)
        out.addAll(imePackages(ctx))
        val pm = ctx.packageManager
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { out.add(it) }
        } catch (_: Exception) { }
        try {
            val dial = Intent(Intent.ACTION_DIAL)
            pm.resolveActivity(dial, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { out.add(it) }
        } catch (_: Exception) { }
        try {
            if (android.os.Build.VERSION.SDK_INT >= 19) {
                android.provider.Telephony.Sms.getDefaultSmsPackage(ctx)?.let { out.add(it) }
            }
        } catch (_: Exception) { }
        return out
    }
}
