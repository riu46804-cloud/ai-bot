package ir.studying.app.focus

import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * سکوت گزینشی اعلانِ اپ‌های دیگر در زمان تمرکز.
 *
 * مکملِ [FocusDnd] است، نه جایگزینِ آن: DND همه را می‌بندد، این فقط همان چند اپی را
 * که خودِ کاربر علامت زده. به جای cancel از snooze استفاده می‌کند تا اعلان پاک نشود،
 * فقط تا انتهای نشست عقب بیفتد و بعد خودش برگردد — کاربر هیچ پیامی را از دست نمی‌دهد.
 *
 * توجه: خودِ اعلان‌های این اپ از این مسیر عبور نمی‌کنند؛ آن‌ها قبل از ساخته شدن
 * جلویشان گرفته می‌شود (FocusRules.isOwnNotifAllowed) که خیلی تمیزتر است.
 */
class NotifGuard : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        val session = FocusLock.session.value ?: return
        if (!FocusRules.isForeignNotifSilenced(n.packageName, session, packageName)) return
        if (n.isOngoing) return // نوار پخشِ موسیقی و مسیریابی را نباید پرت کرد.

        FocusLock.noteSuppressedForeign()
        val remaining = FocusRules.remainingMs(session)
        try {
            if (Build.VERSION.SDK_INT >= 26 && remaining > 0L) {
                // سقف رسمی snooze روی بعضی نسخه‌ها محدود است؛ بیش از ۲ ساعت را تکه‌تکه می‌کنیم.
                snoozeNotification(n.key, remaining.coerceAtMost(2 * 60 * 60 * 1000L))
            } else {
                cancelNotification(n.key)
            }
        } catch (_: Exception) {
            try { cancelNotification(n.key) } catch (_: Exception) { }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
    }

    companion object {
        /** فقط برای نمایش وضعیت در تنطیمات. */
        @Volatile var connected = false
            private set
    }
}
