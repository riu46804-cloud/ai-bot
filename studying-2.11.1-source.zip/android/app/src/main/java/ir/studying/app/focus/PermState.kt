package ir.studying.app.focus

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * وضعیت زندهٔ دسترسی‌ها.
 *
 * مشکل نسخهٔ قبلی این بود که وضعیت دسترسی فقط در زمان ساخته شدن صفحه خوانده
 * می‌شد؛ پس وقتی کاربر از تنطیمات برمی‌گشت، اپ هنوز فکر می‌کرد دسترسی نیست.
 * اینجا یک منبع حقیقت داریم که هم با بازگشت به اپ (ON_RESUME) و هم با یک
 * نمونه‌برداری ۱ ثانیه‌ای در زمانی که صفحه باز است تازه می‌شود.
 */
object PermState {

    data class Snap(
        val usage: Boolean = false,
        val overlay: Boolean = false,
        val accessibility: Boolean = false,
        val dnd: Boolean = false,
        val notifListener: Boolean = false,
        val deviceAdmin: Boolean = false,
        val batteryExempt: Boolean = false,
    ) {
        /** موتور قفل اپ‌ها آماده است؟ (هر کدام از دو مسیر کافی است) */
        val appEngineReady: Boolean get() = accessibility || (usage && overlay)

        /** چند قلم از موارد لازم برای این حالت مانده است. */
        fun missingFor(mode: FocusMode): List<String> {
            val out = ArrayList<String>(3)
            when (mode) {
                FocusMode.APPS, FocusMode.ALL_BUT_CALLS -> {
                    if (!appEngineReady) out.add("موتور تشخیص اپ (دسترسی‌پذیری یا آمار مصرف + رویه)")
                }
                FocusMode.TOTAL -> {
                    if (!deviceAdmin) out.add("مدیر دستگاه (قفل صفحه)")
                }
            }
            return out
        }
    }

    private val _state = MutableStateFlow(Snap())
    val state: StateFlow<Snap> = _state

    @Volatile private var dirty = true

    /** دفعهٔ بعد حتماً از نو بخوان. */
    fun invalidate() { dirty = true }

    /** خواندن وضعیت واقعی از سیستم و انتشار آن. */
    fun refresh(ctx: Context): Snap {
        val snap = Snap(
            usage = FocusPerms.hasUsageAccess(ctx),
            overlay = FocusPerms.hasOverlay(ctx),
            accessibility = FocusPerms.hasAccessibility(ctx),
            dnd = FocusPerms.hasDndAccess(ctx),
            notifListener = FocusPerms.hasNotifListener(ctx),
            deviceAdmin = DeviceLock.isAdmin(ctx),
            batteryExempt = FocusPerms.isBatteryExempt(ctx),
        )
        dirty = false
        if (_state.value != snap) _state.value = snap
        return snap
    }

    /** مقدار فعلی؛ اگر بایات است تازه می‌شود. */
    fun current(ctx: Context): Snap = if (dirty) refresh(ctx) else _state.value
}
