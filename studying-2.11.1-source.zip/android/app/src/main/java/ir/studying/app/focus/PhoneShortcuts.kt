package ir.studying.app.focus

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony

/**
 * در حالت «همه‌چیز جز تماس و پیامک»، خودِ اپ می‌شود منوی گوشی.
 *
 * عمداً هیچ داده‌ای خوانده نمی‌شود: نه مخاطبی، نه پیامک، نه تاریخچهٔ تماس.
 * فقط اپِ تلفن و پیامکِ پیش‌فرضِ خودِ گوشی باز می‌شود — به همین دلیل این قابلیت
 * هیچ دسترسی حساسی (READ_SMS / READ_CONTACTS / CALL_LOG) نمی‌خواهد.
 */
object PhoneShortcuts {

    /** اپ تلفن پیش‌فرض را باز می‌کند (صفحهٔ شماره‌گیری). */
    fun openDialer(ctx: Context): Boolean = start(
        ctx,
        Intent(Intent.ACTION_DIAL).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) },
    )

    /** اپ پیامک پیش‌فرض را باز می‌کند. */
    fun openSms(ctx: Context): Boolean {
        val pkg = try { Telephony.Sms.getDefaultSmsPackage(ctx) } catch (_: Exception) { null }
        if (!pkg.isNullOrBlank()) {
            val i = ctx.packageManager.getLaunchIntentForPackageSafe(pkg)
            if (i != null) return start(ctx, i.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        }
        return start(
            ctx,
            Intent(Intent.ACTION_VIEW, Uri.parse("sms:")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) },
        )
    }

    /** تماس اورژانسی: فقط شماره را در شماره‌گیر می‌گذارد؛ تماس را خود کاربر می‌گیرد. */
    fun dial(ctx: Context, number: String): Boolean = start(
        ctx,
        Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        },
    )

    private fun start(ctx: Context, i: Intent): Boolean =
        try { ctx.startActivity(i); true } catch (_: Exception) { false }

    private fun android.content.pm.PackageManager.getLaunchIntentForPackageSafe(pkg: String): Intent? =
        try { getLaunchIntentForPackage(pkg) } catch (_: Exception) { null }
}
