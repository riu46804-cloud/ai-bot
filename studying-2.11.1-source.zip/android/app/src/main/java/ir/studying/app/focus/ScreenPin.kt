package ir.studying.app.focus

import android.app.Activity
import android.os.Build
import java.lang.ref.WeakReference

/**
 * پین کردن صفحه (Lock Task سبک آزاد).
 *
 * گزینهٔ «حبس در اتاق مطالعه/پین» در نسخه‌های قدیمی فقط یک پرچم در تنطیمات بود و هیچ جا اعمال
 * نمی‌شد. پین فقط از درون یک Activity زنده ممکن است، پس این جسم یک ارجاع سبک به
 * Activity جاری نگه می‌دارد تا [FocusLock] بتواند از هر جا پین را روشن/خاموش کند.
 *
 * نکتهٔ مهم: بدون مالکیت دستگاه، `startLockTask` پنجرهٔ تأیید سیستمی نشان می‌دهد و
 * کاربر با نگه داشتن هم‌زمان برگشت+مرور می‌تواند خارج شود — این محدودیت خود
 * اندروید است، ولی نگهبان اپ (AppWatcher) بلافاصله برمی‌گرداند.
 */
object ScreenPin {

    private var activityRef: WeakReference<Activity>? = null
    @Volatile private var pinned = false

    val isPinned: Boolean get() = pinned

    /** از `onResume` صدا می‌شود. */
    fun attach(activity: Activity) {
        activityRef = WeakReference(activity)
        // اگر نشستی در حالت پین فعال است، با بازگشت به اپ دوباره پین کن.
        if (FocusRules.needsScreenPin(FocusLock.session.value)) start()
    }

    /** از `onDestroy` صدا می‌شود. */
    fun detach(activity: Activity) {
        if (activityRef?.get() === activity) {
            activityRef = null
            pinned = false
        }
    }

    /** شروع پین صفحه. */
    fun start(): Boolean {
        if (Build.VERSION.SDK_INT < 21) return false
        val a = activityRef?.get() ?: return false
        if (pinned) return true
        return try {
            a.runOnUiThread { try { a.startLockTask() } catch (_: Exception) { } }
            pinned = true
            true
        } catch (_: Exception) { false }
    }

    /** پایان پین صفحه — پایان نشست یا شروع استراحت. */
    fun stop() {
        if (Build.VERSION.SDK_INT < 21) return
        val a = activityRef?.get()
        pinned = false
        if (a == null) return
        try {
            a.runOnUiThread { try { a.stopLockTask() } catch (_: Exception) { } }
        } catch (_: Exception) { }
    }

    /** هم‌خوانی وضعیت پین با نشست جاری. */
    fun sync() {
        if (FocusRules.needsScreenPin(FocusLock.session.value)) start() else stop()
    }
}
