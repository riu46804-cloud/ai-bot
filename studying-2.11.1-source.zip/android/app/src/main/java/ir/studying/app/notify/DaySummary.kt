package ir.studying.app.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import ir.studying.app.core.Api
import ir.studying.app.core.AutoPost
import ir.studying.app.core.IranTime
import ir.studying.app.core.Store
import ir.studying.app.data.DailyReport
import ir.studying.app.data.StudyHistory
import ir.studying.app.ui.profile.ReportImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fires the end-of-day achievement post.
 *
 * Five separate faults used to stop this from ever working:
 *  1. the alarm was built on the phone timezone while the server records
 *     study_date on a Tehran clock, so the dates disagreed;
 *  2. the alarm was inexact, so it could slip past midnight, stamp the guard
 *     with tomorrow and permanently block every following day;
 *  3. BootReceiver never rescheduled it, so a reboot killed it for good;
 *  4. a phone that was off at 23:50 lost that day forever;
 *  5. the post ignored the user setting.
 *
 * It is now anchored to Tehran, exact where permitted, rescheduled on boot,
 * and it always summarises the day it is actually reporting on.
 */
object DaySummary {
    private const val REQ = 7101
    const val HOUR = 23
    const val MINUTE = 55

    private fun pending(context: Context): PendingIntent {
        val intent = Intent(context, DaySummaryReceiver::class.java)
            .setAction("ir.studying.app.DAY_SUMMARY")
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQ, intent, flags)
    }

    /** Books the next 23:55 Tehran, exact when the OS allows it. */
    fun schedule(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val at = IranTime.nextOccurrence(HOUR, MINUTE)
        val pi = pending(context)
        runCatching {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /**
     * Publishes the summary for the day that has just ended.
     *
     * Late in the evening that is today. If the alarm slipped, or the phone
     * was off and this is a catch-up on next launch, it is yesterday, and
     * yesterday must be read from history rather than from study_today.
     */
    suspend fun runNow(context: Context? = null) {
        if (Store.token.isNullOrBlank()) return
        if (!Store.prefs.value.autoStudyPost) return
        val daysAgo = if (IranTime.hour() >= 12) 0 else 1
        val d = runCatching { StudyHistory.day(daysAgo) }.getOrNull() ?: return
        AutoPost.postDailySummary(d.dateIso, d.totalMinutes, d.courses, d.questionTotals)
        val streak = runCatching { Api.obj(Api.get("streak")).optInt("streak", 0) }.getOrDefault(0)
        AutoPost.postStreak(streak)
        if (context != null) runCatching { sendReportCard(context, d.dateIso) }
    }

    /**
     * Renders the same report card the profile screen shows and hands it to the
     * server, which forwards it to Telegram. The server can only send a photo
     * it can actually reach, so the picture has to be uploaded from here rather
     * than described; this is the piece that was missing, which is why the bot
     * only ever sent text.
     */
    private suspend fun sendReportCard(context: Context, dateIso: String) {
        val report = runCatching { DailyReport.from(Api.obj(Api.get("daily_report", "date" to dateIso))) }.getOrNull() ?: return
        // A legacy server may ignore the date query. Never attach today's
        // picture to yesterday's catch-up report.
        if (report.dateIso != dateIso || report.totalMinutes <= 0) return
        val png = ReportImage.bytes(
            ctx = context,
            username = Store.username ?: "",
            r = report,
            primary = 0xFF4ADE9F.toInt(),
            secondary = 0xFF38BDF8.toInt(),
            dark = true,
        ) ?: return
        Api.upload(
            "tg_report_photo",
            mapOf("caption" to "\uD83C\uDF19 گزارش امروز"),
            listOf(Api.FilePart("image", "report.jpg", png, "image/png")),
        )
    }

    /**
     * Called on every app start. Recovers a day whose alarm never ran, then
     * re-books the next one so the chain can never break silently.
     */
    fun catchUp(context: Context) {
        schedule(context)
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch { runCatching { runNow(app) } }
    }
}

class DaySummaryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val app = context.applicationContext
        runCatching { Store.init(app) }
        AutoPost.init(app)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { DaySummary.runNow(app) }
            runCatching { DaySummary.schedule(app) }
            runCatching { pending.finish() }
        }
    }
}
