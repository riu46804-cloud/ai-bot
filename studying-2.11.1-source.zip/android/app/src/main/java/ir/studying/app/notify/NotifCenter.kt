package ir.studying.app.notify

import android.content.Context
import ir.studying.app.core.Api
import ir.studying.app.core.Store
import ir.studying.app.data.Notif
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** مرکز اعلان‌ها: هر ۲۰ ثانیه سرور را چک می‌کند، لیست را برای صفحه خانه نگه می‌دارد
 *  و بر اساس تنظیمات کاربر، موارد جدید را به‌صورت پوش نوتیفیکیشن نشان می‌دهد. */
object NotifCenter {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _notifs = MutableStateFlow<List<Notif>>(emptyList())
    val notifs: StateFlow<List<Notif>> get() = _notifs
    private var started = false

    fun start(appContext: Context) {
        if (started) return
        started = true
        scope.launch {
            while (true) {
                if (!Store.token.isNullOrBlank()) refresh(appContext)
                delay(20000)
            }
        }
    }

    suspend fun refresh(appContext: Context, markRead: Boolean = false) {
        runCatching {
            val raw = if (markRead) Api.post("notif_list", org.json.JSONObject()) else Api.get("notif_list")
            val list = Notif.list(Api.arr(raw))
            val lastSeen = Store.lastNotifId()
            val enabled = Store.prefs.value.pushTypes
            val fresh = list.filter { it.id > lastSeen && !it.read }
            if (fresh.isNotEmpty()) {
                fresh.take(4).forEach { n ->
                    /*
                     * انواع تازه (مثل لایک/کامنت جزوه) در تنظیمات ذخیره‌شدهٔ کاربران قدیمی
                     * نیستند؛ اگر مستقیم contains می‌گرفتیم، آن اعلان‌ها برای همه خاموش
                     * می‌ماندند. pushKey آن‌ها را به کلید معادل قدیمی نگاشت می‌کند.
                     */
                    if (enabled.contains(pushKey(n.type)) && ir.studying.app.focus.FocusLock.allowOwnNotif(n.type)) {
                        Notifications.notifySocial(appContext, n.id, n.title, n.text ?: "", n.type, n.refId, n.actor)
                    }
                }
                Store.setLastNotifId(list.maxOf { it.id })
            }
            _notifs.value = list
        }
    }

    /** نگاشت نوع اعلان به کلید تنظیماتِ موجود، تا انواع جدید هم قابل‌کنترل و پیش‌فرض روشن باشند. */
    private fun pushKey(type: String): String = when (type) {
        "note_like", "summary_like", "music_like" -> "post_like"
        "note_comment", "summary_comment" -> "post_reply"
        "quote" -> "repost"
        "task_shared" -> "follow"
        "group_invite" -> "group_reply"
        else -> type
    }

    /* وقتی کاربر روی یک اعلان می‌زند، همان مورد باید فوراً «خوانده» دیده شود
       (سرور فقط API «همه را خوانده کن» دارد، پس این یکی محلی است). */
    fun markReadLocal(id: Int) {
        _notifs.value = _notifs.value.map { if (it.id == id) it.copy(read = true) else it }
    }

    fun markAllRead(appContext: Context) {
        // فوری در UI خوانده شود؛ سرور هم در پس‌زمینه آپدیت می‌شود
        _notifs.value = _notifs.value.map { it.copy(read = true) }
        scope.launch {
            runCatching { Api.post("notif_list", org.json.JSONObject()) }
            refresh(appContext)
        }
    }
}
