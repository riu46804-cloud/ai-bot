package ir.studying.app.notify

import ir.studying.app.core.NavBus
import ir.studying.app.data.Notif

/**
 * مقصد هر اعلان.
 *
 * تا پیش از این، هم لیست اعلان‌های داخل اپ و هم نوتیفیکیشن سیستمی فقط «اپ را باز»
 * می‌کردند و کاربر باید خودش دنبال پست یا چت می‌گشت. این کلاس نگاشت نوع اعلان به
 * مقصد را در یک جا نگه می‌دارد تا هر دو مسیر (تپ درون‌برنامه‌ای و دیپ‌لینک) دقیقاً
 * یک رفتار داشته باشند و اضافه‌شدن نوع جدید فقط یک خط باشد.
 */
object NotifRouter {

    /** رشتهٔ دیپ‌لینکی که در PendingIntent نوتیفیکیشن می‌نشیند. */
    fun deepLink(type: String, refId: Int, actor: String): String =
        "studying://notif?type=" + android.net.Uri.encode(type) +
            "&ref=" + refId + "&actor=" + android.net.Uri.encode(actor)

    fun open(notif: Notif) = open(notif.type, notif.refId, notif.actor)

    fun open(type: String, refId: Int, actor: String) {
        val user = actor.trim().removePrefix("@")
        when (type) {
            // فالو/منشن در پروفایل → مستقیم پروفایل طرف
            "follow" -> if (user.isNotEmpty()) NavBus.requestUser(user)

            // هر چیزی که روی یک پست اتفاق افتاده → همان پست؛ اگر ref نداشتیم، پروفایل طرف
            "post_like", "post_reply", "repost", "quote", "post_mention", "mention_post" ->
                if (refId > 0) NavBus.requestPost(refId)
                else if (user.isNotEmpty()) NavBus.requestUser(user)

            // پیام‌ها: پیوی مستقیم کاربر
            "dm", "reaction" -> if (user.isNotEmpty()) NavBus.requestDm(user) else NavBus.requestRoute("messages")

            // گروه: صفحهٔ چت گروه با همان id
            "group_reply", "mention", "group_invite" ->
                if (refId > 0) NavBus.requestGroup(refId, "گروه") else NavBus.requestRoute("messages")

            // تسکی که دوستت فرستاده → صفحهٔ تسک‌ها
            "task_shared" -> NavBus.requestRoute("tasks")

            // جزوه‌ها/خلاصه‌ها در کتابخانه
            "summary_like", "summary_comment", "note_like", "note_comment" -> NavBus.requestRoute("library")

            else -> if (user.isNotEmpty()) NavBus.requestUser(user)
        }
    }
}
