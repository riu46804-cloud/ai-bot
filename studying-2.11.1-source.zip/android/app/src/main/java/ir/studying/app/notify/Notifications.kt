package ir.studying.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.studying.app.MainActivity
import ir.studying.app.R

object Notifications {
    const val CH_MESSAGES = "messages"
    const val CH_REMINDER = "reminder"
    const val CH_STUDY = "study"
    const val CH_PLANNER = "planner"
    const val CH_SOCIAL = "social"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_MESSAGES, "پیام‌ها", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "پیام‌های خصوصی و گروهی"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SOCIAL, "اجتماع", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "فالو، لایک، پاسخ و منشن‌ها"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_REMINDER, "یادآوری مطالعه", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "یادآوری روزانه درس خواندن"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_PLANNER, "گزارش برنامه", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "گزارش شبانه‌ی برنامه‌ی مطالعه"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_STUDY, "در حال مطالعه", NotificationManager.IMPORTANCE_LOW).apply {
                description = "نمایش زمان مطالعه هنگام تمرکز"
                setShowBadge(false)
            }
        )
    }

    /*
     * [link] یک دیپ‌لینک studying:// است؛ اگر داده شود، تپ روی نوتیفیکیشن به‌جای
     * صفحهٔ اول اپ مستقیم همان مقصد را باز می‌کند. requestCode برابر id است تا
     * نوتیفیکیشن‌های مختلف PendingIntentهای جدا داشته باشند.
     */
    private fun contentIntent(context: Context, id: Int = 0, link: String? = null): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (!link.isNullOrBlank()) {
                action = Intent.ACTION_VIEW
                data = android.net.Uri.parse(link)
            }
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getActivity(context, id, intent, flags)
    }

    private fun post(context: Context, id: Int, channel: String, title: String, text: String, link: String? = null) {
        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_splash)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(contentIntent(context, id, link))
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(id, n) }
    }

    /**
     * گزارش شبانه‌ی برنامه.
     *
     * BigTextStyle لازم است: متن چندخطی است و در حالت جمع‌شده فقط خط اول دیده
     * می‌شود، که همان سرخط «چقدر انجام شد» است — و اگر کسی بازش کرد، تفکیک
     * کامل را می‌بیند. شناسهٔ ثابت یعنی گزارش دیشب جای گزارش امشب را نمی‌گیرد.
     */
    fun notifyPlannerReport(context: Context, title: String, body: String) {
        if (!ir.studying.app.core.PlannerAvailability.ENABLED) return
        val n = NotificationCompat.Builder(context, CH_PLANNER)
            .setSmallIcon(R.drawable.ic_splash)
            .setContentTitle(title)
            .setContentText(body.lineSequence().firstOrNull().orEmpty())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(contentIntent(context, 7311, "studying://planner"))
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(7311, n) }
    }

    fun notifyMessage(context: Context, count: Int) {
        if (!ir.studying.app.focus.FocusLock.allowOwnNotif("dm")) {
            ir.studying.app.focus.FocusLock.noteSuppressedOwn()
            return
        }
        ensureChannels(context)
        val text = if (count > 1) "$count پیام جدید داری" else "یک پیام جدید داری"
        // تپ روی اعلان پیام باید مستقیم صندوق پیام‌ها را باز کند، نه صفحهٔ خانه
        post(context, 1001, CH_MESSAGES, "Studying", text, "studying://messages")
    }

    /* یادآور ساعتی یک تسک؛ تپ روی آن مستقیم صفحهٔ تسک‌ها را باز می‌کند. */
    fun notifyTaskDue(context: Context, taskId: Int, title: String) {
        // کلید "reminder" چون یادآور تسک باید مثل یادآوری مطالعه رفتار کند، نه اعلان اجتماعی
        if (!ir.studying.app.focus.FocusLock.allowOwnNotif("reminder")) {
            ir.studying.app.focus.FocusLock.noteSuppressedOwn()
            return
        }
        ensureChannels(context)
        post(context, 43000 + taskId % 1000, CH_REMINDER, "یادآوری تسک ⏰", title, "studying://tasks")
    }

    fun notifyReminder(context: Context) {
        ensureChannels(context)
        post(context, 1002, CH_REMINDER, "وقت مطالعه‌ست! 📚", "بزن بریم، امروز هم استریکت رو حفظ کن 🔥", "studying://part/new")
    }
}

/*
 * اعلان اجتماعی حالا «قابل تپ» است: به‌جای باز کردن خالی اپ، یک دیپ‌لینک
 * studying://notif حمل می‌کند تا MainActivity کاربر را دقیقاً به پست/پروفایل/چتِ
 * مربوطه ببرد. پارامترها اختیاری‌اند تا امضای قبلی تابع نشکند.
 */
fun Notifications.notifySocial(
    context: Context,
    id: Int,
    title: String,
    text: String,
    type: String = "",
    refId: Int = 0,
    actor: String = "",
) {
    runCatching {
        ensureChannels(context)
        val n = NotificationCompat.Builder(context, Notifications.CH_SOCIAL)
            .setSmallIcon(R.drawable.ic_splash)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(run {
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    action = Intent.ACTION_VIEW
                    if (type.isNotBlank()) {
                        // هر اعلان باید PendingIntent یکتا داشته باشد وگرنه UPDATE_CURRENT
                        // همهٔ آن‌ها را به آخرین مقصد می‌برد؛ id در requestCode همین را تضمین می‌کند.
                        data = android.net.Uri.parse(NotifRouter.deepLink(type, refId, actor))
                    }
                }
                PendingIntent.getActivity(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
            })
            .build()
        NotificationManagerCompat.from(context).notify(200000 + id % 100000, n)
    }
}
