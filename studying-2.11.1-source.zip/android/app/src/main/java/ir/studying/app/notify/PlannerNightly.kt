package ir.studying.app.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import ir.studying.app.core.Cache
import ir.studying.app.core.Fmt
import ir.studying.app.core.IranTime
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.core.parsePlanResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

/* ======================================================================== */
/*  بررسی شبانهٔ برنامه                                                     */
/* ======================================================================== */

/**
 * هر شب ساعت ۲۲:۳۰ به وقت ایران، برنامهٔ امروز را با آنچه واقعاً انجام شده
 * مقایسه می‌کند و یک گزارش می‌فرستد.
 *
 * چرا لازم است: برنامه‌ای که کسی بازخوردش را نبیند، بعد از دو روز رها می‌شود.
 * تا پیش از این کاربر باید خودش صفحه را باز می‌کرد تا بفهمد عقب است یا جلو —
 * یعنی دقیقاً همان کاری که وقتی عقب است انجام نمی‌دهد.
 *
 * ساعت ۲۲:۳۰ انتخاب شد نه ۲۳:۵۵: اگر یک جلسهٔ کوتاه جا مانده باشد، هنوز وقت
 * هست امشب جبرانش کند. گزارشِ نیمه‌شب فقط خبر بد می‌دهد، بی‌آنکه کاری از دست
 * کسی بربیاید.
 *
 * همهٔ کار از روی کش محلی انجام می‌شود، نه شبکه: گوشی ممکن است شب آفلاین
 * باشد و گزارشی که به اینترنت وابسته باشد همان شب‌هایی غایب است که بیشترین
 * اهمیت را دارد.
 */
object PlannerNightly {
    private const val REQ = 7311
    const val HOUR = 22
    const val MINUTE = 30

    private fun pending(context: Context): PendingIntent {
        val intent = Intent(context, PlannerNightlyReceiver::class.java)
            .setAction("ir.studying.app.PLANNER_NIGHTLY")
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQ, intent, flags)
    }

    fun schedule(context: Context) {
        if (!ir.studying.app.core.PlannerAvailability.ENABLED) {
            cancel(context)
            return
        }
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val at = IranTime.nextOccurrence(HOUR, MINUTE)
        val pi = pending(context)
        runCatching {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(context: Context) {
        // Cancel any alarm inherited from the installed version without creating a new one.
        runCatching {
            val intent = Intent(context, PlannerNightlyReceiver::class.java)
                .setAction("ir.studying.app.PLANNER_NIGHTLY")
            val flags = PendingIntent.FLAG_NO_CREATE or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            val pi = PendingIntent.getBroadcast(context, REQ, intent, flags)
            if (pi != null) {
                (context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.cancel(pi)
                pi.cancel()
            }
        }
        runCatching { androidx.core.app.NotificationManagerCompat.from(context).cancel(REQ) }
    }

    /** در هر بار باز شدن اپ: زنگ بعدی چیده می‌شود تا زنجیره نشکند. */
    fun catchUp(context: Context) = schedule(context)

    /* ------------------------------------------------------------------ */

    /** خلاصهٔ آنچه امروز قرار بود انجام شود و آنچه شد. */
    data class Report(
        val date: String,
        val planned: Int,
        val done: Int,
        val plannedMinutes: Int,
        val doneMinutes: Int,
        val missedTitles: List<String>,
        val missedRequired: Int,
        val tomorrowCount: Int,
        val tomorrowMinutes: Int,
    ) {
        val ratio: Float get() = if (plannedMinutes == 0) 0f else doneMinutes.toFloat() / plannedMinutes
        val percent: Int get() = (ratio * 100).toInt().coerceIn(0, 100)
    }

    /** گزارش امروز را از کش می‌سازد؛ اگر برنامه‌ای برای امروز نباشد null. */
    suspend fun buildReport(): Report? {
        if (!ir.studying.app.core.PlannerAvailability.ENABLED) return null
        val raw = Cache.get(Cache.PLANNER, maxAgeMs = 30L * 24 * 60 * 60 * 1000) ?: return null
        val saved = runCatching { JSONObject(raw) }.getOrNull() ?: return null
        val res = runCatching { parsePlanResult(saved.getJSONObject("result")) }.getOrNull() ?: return null
        val plan = res.plan

        val today = IranTime.todayIso()
        val day = plan.days.firstOrNull { it.date == today } ?: return null
        if (day.tasks.isEmpty()) return null

        val reports = saved.optJSONObject("reports")
        fun isDone(taskId: String) = reports?.optJSONObject(taskId)?.optBoolean("completed") == true
        fun minutesOf(taskId: String) = reports?.optJSONObject(taskId)?.optInt("minutes") ?: 0

        val done = day.tasks.count { isDone(it.taskId) }
        val doneMinutes = day.tasks.filter { isDone(it.taskId) }
            .sumOf { minutesOf(it.taskId).takeIf { m -> m > 0 } ?: it.durationMinutes }
        val missed = day.tasks.filterNot { isDone(it.taskId) }

        val tomorrow = plan.days.firstOrNull { it.date > today }
        return Report(
            date = today,
            planned = day.tasks.size,
            done = done,
            plannedMinutes = day.plannedMinutes,
            doneMinutes = doneMinutes,
            missedTitles = missed.map { it.title.ifBlank { it.typeFa } }.take(3),
            missedRequired = missed.count { it.minRequired },
            tomorrowCount = tomorrow?.tasks?.size ?: 0,
            tomorrowMinutes = tomorrow?.plannedMinutes ?: 0,
        )
    }

    /**
     * متن گزارش.
     *
     * لحن عمداً با درصد عوض می‌شود. یک متن ثابت برای کسی که کل روز را خوانده و
     * کسی که هیچ نخوانده، هر دو را بی‌اثر می‌کند: اولی تشویق نمی‌شود و دومی
     * احساس می‌کند دستگاه حواسش نیست. ولی هیچ‌وقت سرزنش نمی‌کند؛ کاری که
     * دانش‌آموز را از اپ فراری می‌دهد همین است.
     */
    fun text(r: Report): Pair<String, String> {
        val head = when {
            r.percent >= 100 -> "کارت عالی بود 🎯"
            r.percent >= 70 -> "روز خوبی بود 👌"
            r.percent >= 35 -> "نصفه‌نیمه پیش رفت 🤏"
            r.done > 0 -> "کم بود ولی صفر نبود 🌱"
            else -> "امروز برنامه زمین ماند 🌙"
        }

        val lines = mutableListOf<String>()
        lines += "${r.done.fa()} از ${r.planned.fa()} جلسه • ${Fmt.minutes(r.doneMinutes)} از ${Fmt.minutes(r.plannedMinutes)} (${r.percent.fa()}٪)"

        if (r.missedTitles.isNotEmpty()) {
            lines += "جا ماند: " + r.missedTitles.joinToString("، ")
        }
        if (r.missedRequired > 0) {
            lines += "${r.missedRequired.fa()} جلسه از حداقل‌های امروز انجام نشد؛ این‌ها به روزهای بعد فشار می‌آورند."
        }
        if (r.tomorrowCount > 0) {
            lines += "فردا: ${r.tomorrowCount.fa()} جلسه، ${Fmt.minutes(r.tomorrowMinutes)}."
        }
        lines += when {
            r.percent >= 100 -> "همین ریتم را نگه دار."
            r.percent >= 70 -> "باقی‌مانده کوچک است؛ فردا راحت جبران می‌شود."
            r.percent >= 35 -> "اگر این الگو تکرار شد، «بازبرنامه‌ریزی» را بزن تا ظرفیت روزانه واقعی‌تر شود."
            else -> "یک بار «بازبرنامه‌ریزی» بزن؛ برنامه خودش را با توان واقعی‌ات تنظیم می‌کند."
        }
        return head to lines.joinToString("\n")
    }

    suspend fun runNow(context: Context) {
        if (!ir.studying.app.core.PlannerAvailability.ENABLED) {
            cancel(context)
            return
        }
        if (Store.token.isNullOrBlank()) return
        val r = buildReport() ?: return
        val (title, body) = text(r)
        Notifications.notifyPlannerReport(context, title, body)
    }
}

class PlannerNightlyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!ir.studying.app.core.PlannerAvailability.ENABLED) {
            PlannerNightly.cancel(context)
            return
        }
        val app = context.applicationContext
        runCatching { Store.init(app) }
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { PlannerNightly.runNow(app) }
            // زنگ فردا همین‌جا چیده می‌شود؛ setExactAndAllowWhileIdle یک‌بارمصرف است.
            runCatching { PlannerNightly.schedule(app) }
            runCatching { pending.finish() }
        }
    }
}
