package ir.studying.app.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.studying.app.R
import ir.studying.app.core.Store
import ir.studying.app.player.Pomodoro

/**
 * آلارم دقیق پایان هر مرحلهٔ پومودورو.
 *
 * Until now the only thing driving the timer was a coroutine inside the app
 * process. Android freezes cached processes, so a user who started a 25 minute
 * block and locked the phone got no chime, no phase change and no credited
 * minutes until the app was opened again -- and if the process was killed and
 * the app reopened the next day, the parts landed on the wrong study date.
 *
 * An RTC_WAKEUP alarm at the phase deadline wakes the process exactly when the
 * block ends, so each part is settled and banked at the right moment even with
 * the app fully closed. It falls back to an inexact alarm when the user has not
 * granted exact alarms, which only costs a little accuracy.
 */
object PomodoroAlarm {
    private const val REQ = 7009
    private const val ACTION = "ir.studying.app.action.POMODORO_PHASE_END"
    private const val NOTE_ID = 1004

    private fun pending(context: Context): PendingIntent {
        val i = Intent(context, PomodoroAlarmReceiver::class.java).setAction(ACTION)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, REQ, i, flags)
    }

    /** Arms the alarm for [atMs]. A non-positive value simply cancels it. */
    fun schedule(context: Context, atMs: Long) {
        val ctx = context.applicationContext
        if (atMs <= 0L) { cancel(ctx); return }
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        runCatching {
            val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pending(ctx))
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pending(ctx))
            }
        }
    }

    fun cancel(context: Context) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        runCatching { am.cancel(pending(ctx)) }
    }

    /**
     * The ongoing study notification is deliberately silent, so it cannot tell
     * the user that a block just ended. This one alerts once.
     */
    fun notifyPhase(context: Context) {
        val ctx = context.applicationContext
        runCatching {
            Notifications.ensureChannels(ctx)
            val s = Pomodoro.state.value
            val text = when (s.phase) {
                Pomodoro.Phase.WORK -> "وقت تمرکز است — مرحلهٔ تازه شروع شد"
                Pomodoro.Phase.BREAK -> "وقت استراحت کوتاه ☕"
                Pomodoro.Phase.LONG_BREAK -> "وقت استراحت بلند 🌟"
                Pomodoro.Phase.IDLE -> "پومودورو تمام شد"
            }
            val i = Intent(ctx, ir.studying.app.MainActivity::class.java)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val n = NotificationCompat.Builder(ctx, Notifications.CH_STUDY)
                .setSmallIcon(R.drawable.ic_splash)
                .setContentTitle("مرحلهٔ پومودورو تمام شد")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            NotificationManagerCompat.from(ctx).notify(NOTE_ID, n)
        }
    }
}

class PomodoroAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val ctx = context.applicationContext
        runCatching {
            // The process may have just been created by this broadcast.
            Store.init(ctx)
            Pomodoro.onAlarm(ctx)
            PomodoroAlarm.notifyPhase(ctx)
            StudyNotifier.sync(ctx)
        }
    }
}
