package ir.studying.app.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro

/**
 * Handles the buttons on the ongoing study notification.
 *
 * The notification used to be read only, so pausing a timer meant unlocking the
 * phone and finding the study screen — exactly the friction that makes people
 * leave a timer running through dinner and then stop trusting their own numbers.
 *
 * Nothing is ever logged from here on purpose: minutes are only sent to the
 * server from a screen the user is looking at, so a mis-tap in the shade can
 * never write a wrong session.
 */
class StudyActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        when (intent.action) {
            ACTION_PAUSE -> {
                // Pausing keeps every accumulated minute; only the clock halts.
                if (Pomodoro.state.value.running) Pomodoro.pause()
                if (Chrono.running) Chrono.pause()
            }
            ACTION_SKIP -> {
                if (Pomodoro.state.value.phase != Pomodoro.Phase.IDLE) Pomodoro.skip(ctx)
            }
        }
        runCatching { StudyNotifier.sync(ctx) }
    }

    companion object {
        const val ACTION_PAUSE = "ir.studying.app.action.STUDY_PAUSE"
        const val ACTION_SKIP = "ir.studying.app.action.STUDY_SKIP"
    }
}
