package ir.studying.app.notify

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.studying.app.R
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** Shows an ongoing (non-dismissible) notification with a live study time while studying. */
object StudyNotifier {
    private const val ID = 1003
    // FIX: روی Dispatchers.Main بود؛ هر کار سنگینی در UI این حلقه را عقب می‌انداخت
    // و زمان روی اعلان یخ می‌زد. این حلقه هیچ دسترسی UI ندارد.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private val faDigits = charArrayOf('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹')
    private fun fa(s: String) = buildString { for (c in s) append(if (c in '0'..'9') faDigits[c - '0'] else c) }

    fun sync(context: Context) {
        val ctx = context.applicationContext
        val running = Chrono.running || Pomodoro.state.value.running
        if (running) {
            if (job == null) job = scope.launch { loop(ctx) }
        } else {
            job?.cancel(); job = null
            runCatching { NotificationManagerCompat.from(ctx).cancel(ID) }
        }
    }

    /**
     * Tapping the notification must land on the study screen, not on a fresh copy
     * of the app stacked on top of itself.
     */
    private fun openApp(ctx: Context): PendingIntent? = runCatching {
        val i = Intent(ctx, ir.studying.app.MainActivity::class.java)
            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }.getOrNull()

    private fun action(ctx: Context, act: String, label: String, code: Int): NotificationCompat.Action {
        val i = Intent(ctx, StudyActionReceiver::class.java).setAction(act)
        val pi = PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Action(R.drawable.ic_splash, label, pi)
    }

    private suspend fun loop(ctx: Context) {
        Notifications.ensureChannels(ctx)
        while (Chrono.running || Pomodoro.state.value.running) {
            val pomo = Pomodoro.state.value
            val (title, text) = if (pomo.running) {
                val m = pomo.remainingSec / 60; val s = pomo.remainingSec % 60
                val phase = when (pomo.phase) { Pomodoro.Phase.WORK -> "تمرکز"; Pomodoro.Phase.BREAK -> "استراحت"; Pomodoro.Phase.LONG_BREAK -> "استراحت بلند"; else -> "پومودورو" }
                "در حال مطالعه — $phase" to fa(String.format(Locale.US, "%02d:%02d", m, s)) + " مانده"
            } else {
                val sec = Chrono.elapsedMs() / 1000
                "در حال مطالعه ⏱" to fa(String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60))
            }
            val n = NotificationCompat.Builder(ctx, Notifications.CH_STUDY)
                .setSmallIcon(R.drawable.ic_splash)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(openApp(ctx))
                .addAction(action(ctx, StudyActionReceiver.ACTION_PAUSE, "توقف موقت", 1101))
                .apply {
                    // Skipping only means something while a pomodoro phase is on the clock.
                    if (pomo.running) addAction(action(ctx, StudyActionReceiver.ACTION_SKIP, "رد کردن مرحله", 1102))
                }
                .build()
            runCatching { NotificationManagerCompat.from(ctx).notify(ID, n) }
            delay(1000)
        }
        runCatching { NotificationManagerCompat.from(ctx).cancel(ID) }
        job = null
    }
}
