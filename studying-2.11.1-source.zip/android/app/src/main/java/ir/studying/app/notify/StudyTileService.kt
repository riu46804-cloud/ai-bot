package ir.studying.app.notify

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import ir.studying.app.R
import ir.studying.app.core.Store
import ir.studying.app.player.Chrono

/**
 * Quick Settings tile that starts and pauses the stopwatch.
 *
 * The fastest path to "I am studying now" used to be unlock, open the app, wait
 * for the splash, find the timer. Every one of those steps is a chance to get
 * distracted, so the tile puts the same switch one swipe from the lock screen.
 *
 * TileService is API 24, which is exactly this app's minSdk, so no version
 * guard is needed here.
 */
class StudyTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        sync()
    }

    override fun onClick() {
        super.onClick()
        runCatching {
            Store.init(applicationContext)
            if (Chrono.running) Chrono.pause() else Chrono.start()
        }
        sync()
    }

    private fun sync() {
        val tile = qsTile ?: return
        runCatching {
            Store.init(applicationContext)
            val running = Chrono.running
            tile.state = if (running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            tile.label = if (running) "در حال مطالعه" else "شروع مطالعه"
            tile.icon = Icon.createWithResource(this, R.drawable.ic_splash)
            tile.updateTile()
        }
    }
}
