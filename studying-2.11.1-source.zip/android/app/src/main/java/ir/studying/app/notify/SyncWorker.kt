package ir.studying.app.notify

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import ir.studying.app.core.Offline
import ir.studying.app.core.Store
import java.util.concurrent.TimeUnit

/**
 * Drains the offline study queue.
 *
 * Two entry points on purpose: [kick] runs the moment a part fails to send, so a
 * short connection blip is repaired within seconds, and [schedule] keeps a slow
 * periodic sweep alive for the case where the app is never opened again while
 * the phone is offline — the parts still arrive before the nightly report.
 */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            Store.init(applicationContext)
            if (Store.tokenFromDisk().isNullOrBlank()) return Result.success()
            Offline.flush()
            // Retry only this authenticated owner's non-rejected entries, not another account's backlog.
            if (Offline.hasRetryable()) Result.retry() else Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_NOW = "offline_study_sync"
        private const val UNIQUE_PERIODIC = "offline_study_sync_periodic"

        private fun onlyWhenOnline() = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        /** Runs as soon as there is a network. Safe to call repeatedly. */
        fun kick(context: Context) {
            val req = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(onlyWhenOnline())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            runCatching {
                WorkManager.getInstance(context)
                    .enqueueUniqueWork(UNIQUE_NOW, ExistingWorkPolicy.KEEP, req)
            }
        }

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<SyncWorker>(1, TimeUnit.HOURS)
                .setConstraints(onlyWhenOnline())
                .build()
            runCatching {
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    UNIQUE_PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req,
                )
            }
        }
    }
}
