package ir.studying.app.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import ir.studying.app.data.TaskItem
import java.util.Calendar

/**
 * یادآور ساعتی تسک.
 *
 * تسک تا امروز فقط «تاریخ» داشت، یعنی یادآوری‌اش عملاً وجود نداشت و کاربر باید
 * خودش اپ را باز می‌کرد. حالا هر تسکِ امروز که ساعت دارد و انجام نشده، یک آلارم
 * محلی می‌گیرد. همه‌چیز روی دستگاه است تا بدون اینترنت هم کار کند.
 */
object TaskAlarm {
    private const val REQ_BASE = 43000
    /** idهایی که آلارم فعال دارند؛ برای لغو دقیق هنگام هر بازچینی. */
    private val scheduled = mutableSetOf<Int>()

    private fun pending(context: Context, id: Int, title: String, create: Boolean): PendingIntent? {
        val intent = Intent(context, TaskAlarmReceiver::class.java)
            .setAction("ir.studying.app.TASK_DUE")
            .putExtra("task_id", id)
            .putExtra("task_title", title)
        var flags = (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQ_BASE + (id % 1000), intent, flags)
    }

    /** آلارم‌های امروز را با لیست تازه هم‌خوان می‌کند (قبلی‌ها لغو، جدیدها ست). */
    fun sync(context: Context, todayTasks: List<TaskItem>) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val wanted = todayTasks.filter { !it.done && !it.dueHm.isNullOrBlank() }
        runCatching {
            (scheduled - wanted.map { it.id }.toSet()).forEach { old ->
                pending(context, old, "", create = false)?.let { am.cancel(it) }
            }
        }
        scheduled.clear()
        val now = System.currentTimeMillis()
        wanted.forEach { t ->
            val hm = t.dueHm ?: return@forEach
            val h = hm.substringBefore(':').toIntOrNull() ?: return@forEach
            val m = hm.substringAfter(':').toIntOrNull() ?: return@forEach
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            // ساعتی که گذشته دوباره زنگ نمی‌زند؛ یادآوری دیرهنگام فقط مزاحم است.
            if (cal.timeInMillis <= now) return@forEach
            val pi = pending(context, t.id, t.title, create = true) ?: return@forEach
            runCatching {
                val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                scheduled.add(t.id)
            }
        }
    }

    fun cancel(context: Context, id: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        runCatching { pending(context, id, "", create = false)?.let { am.cancel(it) } }
        scheduled.remove(id)
    }
}

class TaskAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getIntExtra("task_id", 0) ?: 0
        val title = intent?.getStringExtra("task_title").orEmpty()
        if (title.isBlank()) return
        Notifications.notifyTaskDue(context, id, title)
    }
}
