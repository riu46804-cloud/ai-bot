package ir.studying.app.player

import android.content.Context
import android.media.MediaPlayer
import ir.studying.app.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

/** A single ambient sound definition. */
data class AmbientSound(
    val key: String,
    val label: String,
    val emoji: String,
    val rawResId: Int,
)

/** Global looping ambient-sound mixer. Multiple sounds play simultaneously,
 *  each with an independent volume, and keep playing across screens. */
object AmbientMixer {

    val sounds: List<AmbientSound> = listOf(
        AmbientSound("rain", "باران", "🌧️", R.raw.amb_rain),
        AmbientSound("fire", "آتش", "🔥", R.raw.amb_fire),
        AmbientSound("thunder", "رعد و برق", "⛈️", R.raw.amb_thunder),
        AmbientSound("wind", "باد", "🍃", R.raw.amb_wind),
        AmbientSound("ocean", "موج دریا", "🌊", R.raw.amb_ocean),
        AmbientSound("forest", "جنگل", "🌲", R.raw.amb_forest),
        AmbientSound("night", "شب", "🌙", R.raw.amb_night),
        AmbientSound("cafe", "کافه", "☕", R.raw.amb_cafe),
        AmbientSound("noise", "نویز سفید", "📻", R.raw.amb_whitenoise),
    )

    data class SoundState(val active: Boolean = false, val volume: Float = 0.6f)

    private val players = HashMap<String, MediaPlayer>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    /** کلیدهایی که همین حالا در حال آماده‌سازی‌اند؛ جلوی تپ‌های پشت‌سرهم را می‌گیرد. */
    private val loading = java.util.Collections.synchronizedSet(HashSet<String>())

    private val _states = MutableStateFlow(sounds.associate { it.key to SoundState() })
    val states: StateFlow<Map<String, SoundState>> get() = _states

    val activeCount: StateFlow<Int> = _states
        .map { m -> m.values.count { it.active } }
        .stateIn(scope, SharingStarted.Eagerly, 0)

    fun stateOf(key: String): SoundState = _states.value[key] ?: SoundState()

    /**
     * روشن/خاموش کردن یک صدا.
     *
     * چرا در پس‌زمینه: `MediaPlayer.create` فایل ogg را همان‌جا باز و دیکود
     * می‌کند؛ روی رشتهٔ اصلی یعنی چند صد میلی‌ثانیه فریز و همان «پرش» که در
     * اتاق مطالعه دیده می‌شد. ضمناً اگر ساخت پخش‌کننده شکست بخورد، دیگر وضعیت
     * را «روشن» نشان نمی‌دهیم و دکمه گیر نمی‌کند.
     */
    fun toggle(context: Context, key: String) {
        val app = context.applicationContext
        val cur = stateOf(key)
        if (cur.active) {
            update(key) { it.copy(active = false) }
            val mp = players.remove(key)
            scope.launch { releaseSafely(mp) }
            return
        }
        if (!loading.add(key)) return          // تپ دوباره تا وقتی اولی تمام نشده
        update(key) { it.copy(active = true) } // بازخورد فوری برای کاربر
        scope.launch {
            val res = sounds.find { it.key == key }
            val mp = if (res == null) null else runCatching {
                MediaPlayer.create(app, res.rawResId)?.apply {
                    isLooping = true
                    setVolume(cur.volume, cur.volume)
                    start()
                }
            }.getOrNull()
            if (mp == null) {
                update(key) { it.copy(active = false) }
            } else if (stateOf(key).active) {
                players[key] = mp
            } else {
                // کاربر وسط آماده‌سازی دوباره خاموشش کرد
                releaseSafely(mp)
            }
            loading.remove(key)
        }
    }

    fun setVolume(key: String, volume: Float) {
        val v = volume.coerceIn(0f, 1f)
        runCatching { players[key]?.setVolume(v, v) }
        update(key) { it.copy(volume = v) }
    }

    fun stopAll() {
        val all = players.values.toList()
        players.clear()
        _states.value = sounds.associate { it.key to SoundState() }
        scope.launch { all.forEach { releaseSafely(it) } }
    }

    /** stop روی پخش‌کنندهٔ در حال آماده‌سازی IllegalState می‌دهد؛ همه را می‌بلعیم. */
    private fun releaseSafely(mp: MediaPlayer?) {
        if (mp == null) return
        runCatching { if (mp.isPlaying) mp.stop() }
        runCatching { mp.reset() }
        runCatching { mp.release() }
    }

    private inline fun update(key: String, block: (SoundState) -> SoundState) {
        val m = _states.value.toMutableMap()
        m[key] = block(m[key] ?: SoundState())
        _states.value = m
    }
}
