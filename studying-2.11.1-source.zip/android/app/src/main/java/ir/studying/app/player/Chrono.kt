package ir.studying.app.player

import ir.studying.app.core.Store
import ir.studying.app.core.TimerPersist

/** Count-up stopwatch backed by the persisted timer in Store. */
object Chrono {
    private fun notifySync() = runCatching { ir.studying.app.notify.StudyNotifier.sync(ir.studying.app.App.instance) }
    /** بیش از این دیگر مطالعه نیست؛ تایمرِ فراموش‌شده است. */
    const val CAP_MS = 12L * 60L * 60L * 1000L

    /** از این مقدار به بالا قبل از ثبت از کاربر تأیید گرفته می‌شود. */
    const val CONFIRM_MS = 4L * 60L * 60L * 1000L

    /**
     * FIX: مدت، روی ساعت دیواری حساب می‌شد. سینک NTP، تغییر دستی ساعت یا
     * تغییر تایم‌زون می‌توانست کرنومتر را بپراند (حتی منفی کند). حالا پرش
     * معکوس صفر می‌شود و کل مدت سقف دارد — معادل CATCHUP_CAP در پومودورو،
     * که قبلاً فقط پومودورو داشت و کرنومتر بی‌سقف بود.
     */
    fun elapsedMs(): Long {
        val t = Store.timer.value
        val live = if (t.running) (System.currentTimeMillis() - t.startEpochMs) else 0L
        val safeLive = live.coerceIn(0L, CAP_MS)
        return (t.accumMs.coerceIn(0L, CAP_MS) + safeLive).coerceAtMost(CAP_MS)
    }

    /** true وقتی مدت آن‌قدر بلند است که احتمالاً تایمر فراموش شده. */
    fun needsConfirm(): Boolean = elapsedMs() >= CONFIRM_MS

    val running: Boolean get() = Store.timer.value.running

    fun start() {
        if (running) return
        // کرنومتر و پومودورو هرگز همزمان فعال نمی‌شوند
        if (Pomodoro.state.value.running) Pomodoro.pause()
        val t = Store.timer.value
        Store.saveTimer(TimerPersist(true, System.currentTimeMillis(), t.accumMs, t.courseId))
        notifySync()
    }

    fun pause() {
        val t = Store.timer.value
        if (t.running) {
            Store.saveTimer(t.copy(running = false, accumMs = elapsedMs(), endEpochMs = System.currentTimeMillis()))
        }
        notifySync()
    }

    fun reset() { Store.saveTimer(TimerPersist(false, 0L, 0L, Store.timer.value.courseId)); notifySync() }

    fun setCourse(courseId: Int?) = Store.saveTimer(Store.timer.value.copy(courseId = courseId))
}
