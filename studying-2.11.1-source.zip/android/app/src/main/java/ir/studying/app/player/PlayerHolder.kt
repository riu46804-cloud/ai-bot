package ir.studying.app.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import ir.studying.app.core.Api
import ir.studying.app.data.MusicTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** App-wide media controller bound to [PlaybackService]. */
object PlayerHolder {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    var controller: MediaController? = null
        private set

    private val _queue = MutableStateFlow<List<MusicTrack>>(emptyList())
    val queue: StateFlow<List<MusicTrack>> get() = _queue

    private val _currentId = MutableStateFlow<Int?>(null)
    val currentId: StateFlow<Int?> get() = _currentId

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> get() = _isPlaying

    private val _shuffleOn = MutableStateFlow(false)
    val shuffleOn: StateFlow<Boolean> get() = _shuffleOn

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> get() = _repeatMode

    fun init(context: Context) {
        if (controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                controller = c
                // اگر کاربر قبل از اتصال روی آهنگی زده بود، همان را پخش کن
                pending?.let { (list, idx) -> pending = null; play(list, idx) }
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) {
                        _isPlaying.value = player.isPlaying
                        _currentId.value = player.currentMediaItem?.mediaId?.toIntOrNull()
                        _shuffleOn.value = player.shuffleModeEnabled
                        _repeatMode.value = player.repeatMode
                    }
                })
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun currentTrack(): MusicTrack? = _currentId.value?.let { id -> _queue.value.find { it.id == id } }

    private fun MusicTrack.toMediaItem(): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist.ifBlank { username })
            .apply { Api.mediaUrl(cover)?.let { setArtworkUri(Uri.parse(it)) } }
            .build()
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(Api.mediaUrl(filepath))
            .setMediaMetadata(meta)
            .build()
    }

    /** درخواستی که قبل از وصل‌شدن کنترلر رسیده؛ به‌محض اتصال اجرا می‌شود. */
    private var pending: Pair<List<MusicTrack>, Int>? = null

    /**
     * پخش لیست از یک ایندکس.
     *
     * قبلاً اگر کنترلر هنوز به سرویس وصل نشده بود (اولین تپ بعد از باز شدن اپ)
     * تابع بی‌صدا برمی‌گشت و کاربر فکر می‌کرد پخش‌کننده خراب است. حالا درخواست
     * ذخیره و پس از اتصال اجرا می‌شود. همهٔ فراخوانی‌ها هم داخل runCatching‌اند
     * تا خطای سرویس مدیا اپ را نبندد.
     */
    fun play(tracks: List<MusicTrack>, index: Int) {
        if (tracks.isEmpty() || index !in tracks.indices) return
        _queue.value = tracks
        val c = controller
        if (c == null) {
            pending = tracks to index
            runCatching { init(ir.studying.app.App.instance) }
            return
        }
        runCatching {
            c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
            c.prepare()
            c.play()
        }
    }

    fun toggle() {
        runCatching { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    }

    fun next() { runCatching { controller?.seekToNextMediaItem() } }
    fun prev() { runCatching { controller?.seekToPreviousMediaItem() } }
    fun seekTo(positionMs: Long) { runCatching { controller?.seekTo(positionMs) } }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun position(): Pair<Long, Long> = runCatching {
        val c = controller ?: return@runCatching 0L to 0L
        c.currentPosition.coerceAtLeast(0L) to c.duration.coerceAtLeast(0L)
    }.getOrDefault(0L to 0L)

    fun stopAndClear() {
        pending = null
        runCatching {
            controller?.let {
                it.stop()
                it.clearMediaItems()
            }
        }
        _queue.value = emptyList()
        _currentId.value = null
        _isPlaying.value = false
    }
}
