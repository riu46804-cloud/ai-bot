package ir.studying.app.player

import android.content.Context
import android.media.MediaPlayer
import ir.studying.app.R
import ir.studying.app.core.PomodoroPersist
import ir.studying.app.core.Store
import ir.studying.app.core.StudyPending
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Global Pomodoro focus timer. Keeps running across screens.
 *
 * The clock is driven by an absolute wall-clock deadline, never by counting
 * ticks. A coroutine that is throttled in the background (Doze, or simply a
 * dispatcher that does not get scheduled for a few minutes) used to make the
 * countdown fall behind real time, so a 25 minute block took 27 minutes and the
 * recorded study time was wrong. Every tick now recomputes the remaining time
 * from the deadline, so the display self-corrects the instant the app is
 * touched again and finished blocks are always credited in full.
 */
object Pomodoro {
    private fun sync() = runCatching { ir.studying.app.notify.StudyNotifier.sync(ir.studying.app.App.instance) }

    enum class Phase { IDLE, WORK, BREAK, LONG_BREAK }

    data class Config(
        val workMin: Int = 25,
        val breakMin: Int = 5,
        val longBreakMin: Int = 15,
        val cyclesBeforeLong: Int = 4,
    )

    data class State(
        val phase: Phase = Phase.IDLE,
        val remainingSec: Int = 25 * 60,
        val running: Boolean = false,
        val completedWork: Int = 0,
        val config: Config = Config(),
    )

    /**
     * Ceiling on minutes handed out by a single catch-up. A phone left on the
     * desk overnight must not turn into an eight hour study record; anything
     * past this is treated as "the user walked away" and is not credited.
     */
    private const val CATCHUP_CAP_MIN = 240

    /** Past this gap the timer is parked instead of silently resumed. */
    private const val CATCHUP_MAX_GAP_MS = 12L * 60L * 60L * 1000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ticker: kotlinx.coroutines.Job? = null

    /** Absolute end of the current phase. Zero while paused. */
    private var deadlineMs: Long = 0L

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> get() = _state

    private val _workCompleted = MutableSharedFlow<Int>(extraBufferCapacity = 8)
    val workCompleted: SharedFlow<Int> get() = _workCompleted

    private fun phaseLenMin(phase: Phase, c: Config): Int = when (phase) {
        Phase.WORK, Phase.IDLE -> c.workMin
        Phase.BREAK -> c.breakMin
        Phase.LONG_BREAK -> c.longBreakMin
    }

    private fun leftSecFrom(now: Long): Int {
        if (deadlineMs <= 0L) return 0
        val ms = deadlineMs - now
        return if (ms <= 0L) 0 else ((ms + 999L) / 1000L).toInt()
    }

    private fun persist(credits: List<StudyPending.Block> = emptyList()) {
        val s = _state.value
        Store.savePomodoro(PomodoroPersist(
            phase = s.phase.name, running = s.running,
            endEpochMs = if (s.running) deadlineMs else System.currentTimeMillis(),
            remainingSec = s.remainingSec, completedWork = s.completedWork,
            workMin = s.config.workMin, breakMin = s.config.breakMin,
            longBreakMin = s.config.longBreakMin, cyclesBeforeLong = s.config.cyclesBeforeLong,
        ), credits)
        if (credits.isNotEmpty()) _workCompleted.tryEmit(credits.sumOf { it.minutes })
    }

    /**
     * Restores a timer that was interrupted by a process kill or a reboot.
     *
     * The old version credited exactly one work block no matter how long the
     * app had been dead, so a user who started a session and locked the phone
     * for two hours lost every part but the first. The elapsed time is now
     * replayed phase by phase, and each work phase that genuinely finished is
     * credited.
     */
    fun restore(context: Context) {
        ticker?.cancel()
        val saved = Store.pomodoro.value
        val phase0 = runCatching { Phase.valueOf(saved.phase) }.getOrDefault(Phase.IDLE)
        if (phase0 == Phase.IDLE) {
            deadlineMs = 0L
            _state.value = State(remainingSec = saved.workMin.coerceIn(1, 240) * 60, config = Config(saved.workMin.coerceIn(1, 240), saved.breakMin.coerceIn(1, 240), saved.longBreakMin.coerceIn(1, 240), saved.cyclesBeforeLong.coerceIn(1, 100)))
            ir.studying.app.notify.PomodoroAlarm.cancel(context.applicationContext)
            return
        }

        // The preset is restored from disk, so a 90 minute block is never
        // credited as the default 25.
        val c = Config(
            workMin = saved.workMin.coerceIn(1, 240),
            breakMin = saved.breakMin.coerceIn(1, 240),
            longBreakMin = saved.longBreakMin.coerceIn(1, 240),
            cyclesBeforeLong = saved.cyclesBeforeLong.coerceIn(1, 100),
        )

        if (!saved.running || saved.endEpochMs <= 0L) {
            val remaining = if (saved.remainingSec > 0) saved.remainingSec else phaseLenMin(phase0, c) * 60
            deadlineMs = 0L
            _state.value = State(phase0, remaining, false, saved.completedWork, c)
            ir.studying.app.notify.PomodoroAlarm.cancel(context.applicationContext)
            return
        }

        val now = System.currentTimeMillis()
        val gap = now - saved.endEpochMs
        var phase = phase0
        var done = saved.completedWork
        var deadline = saved.endEpochMs
        val credits = mutableListOf<StudyPending.Block>()
        var credited = 0
        var guard = 0
        while (deadline <= now && guard < 4000) {
            guard++
            if (phase == Phase.WORK) {
                if (credited + c.workMin <= CATCHUP_CAP_MIN) {
                    credited += c.workMin
                    credits.add(StudyPending.Block(c.workMin, deadline))
                }
                done += 1
                val long = done % c.cyclesBeforeLong == 0
                phase = if (long) Phase.LONG_BREAK else Phase.BREAK
                deadline += (if (long) c.longBreakMin else c.breakMin) * 60_000L
            } else {
                phase = Phase.WORK
                deadline += c.workMin * 60_000L
            }
        }

        if (gap > CATCHUP_MAX_GAP_MS) {
            deadlineMs = 0L
            _state.value = State(phase, phaseLenMin(phase, c) * 60, false, done, c)
            ir.studying.app.notify.PomodoroAlarm.cancel(context.applicationContext)
            persist(credits)
            sync()
            return
        }

        deadlineMs = deadline
        _state.value = State(phase, leftSecFrom(now).coerceAtLeast(1), true, done, c)
        runTicker(context.applicationContext)
        arm(context.applicationContext)
        persist(credits)
        sync()
    }

    fun setConfig(c: Config) {
        val s = _state.value
        // A preset change must not revalue an already-running/paused work block.
        if (s.phase != Phase.IDLE) return
        require(c.workMin in 1..240 && c.breakMin in 1..240 && c.longBreakMin in 1..240 && c.cyclesBeforeLong in 1..100)
        _state.value = s.copy(
            config = c,
            remainingSec = if (s.running) s.remainingSec else phaseLenMin(s.phase, c) * 60,
        )
        persist()
    }

    fun start(context: Context) {
        if (_state.value.running) return
        // کرنومتر و پومودورو هرگز همزمان فعال نمی‌شوند
        if (Chrono.running) Chrono.pause()
        val s = _state.value
        val phase = if (s.phase == Phase.IDLE) Phase.WORK else s.phase
        val left = if (s.phase == Phase.IDLE || s.remainingSec <= 0) phaseLenMin(phase, s.config) * 60 else s.remainingSec
        deadlineMs = System.currentTimeMillis() + left * 1000L
        _state.value = s.copy(phase = phase, remainingSec = left, running = true)
        runTicker(context.applicationContext)
        arm(context.applicationContext)
        persist()
        sync()
    }

    fun pause() {
        if (!_state.value.running) return
        if (deadlineMs > 0L && deadlineMs <= System.currentTimeMillis())
            advancePhase(ir.studying.app.App.instance, skipped = false)
        ticker?.cancel()
        val left = leftSecFrom(System.currentTimeMillis())
        val s = _state.value
        deadlineMs = 0L
        _state.value = s.copy(running = false, remainingSec = if (left > 0) left else s.remainingSec)
        ir.studying.app.notify.PomodoroAlarm.cancel(ir.studying.app.App.instance)
        persist()
        sync()
    }

    fun reset() {
        ticker?.cancel()
        val c = _state.value.config
        deadlineMs = 0L
        _state.value = State(config = c, remainingSec = c.workMin * 60)
        ir.studying.app.notify.PomodoroAlarm.cancel(ir.studying.app.App.instance)
        persist()
        sync()
    }

    /**
     * رد کردن مرحلهٔ فعلی.
     *
     * باگی که درست شد: تا امروز اگر وسط یک پومودورو «بعدی» را می‌زدی، دقیقه‌های
     * خوانده‌شده‌ات کاملاً دور ریخته می‌شد — چون فقط پومودورویِ تمام‌شده اعتبار
     * می‌گرفت. حالا همان مقدار که واقعاً خوانده‌ای (دقیقه‌های کامل) به
     * [StudyPending] اضافه می‌شود و برای ثبت می‌ماند. تعداد پومودوروهای
     * کامل‌شده عمداً زیاد نمی‌شود، چون این پومودورو تمام نشده است.
     *
     * @return چند دقیقه ذخیره شد (برای پیام دادن به کاربر).
     */
    fun skip(context: Context): Int {
        val s = _state.value
        val credit = if (s.phase == Phase.WORK) elapsedWorkMin(s) else 0
        advancePhase(context.applicationContext, skipped = true, skipCreditMin = credit)
        return credit
    }

    /** چند دقیقهٔ کامل از بلوک مطالعهٔ فعلی گذشته است. */
    private fun elapsedWorkMin(s: State): Int {
        val total = s.config.workMin * 60
        val left = if (s.running && deadlineMs > 0L)
            leftSecFrom(System.currentTimeMillis()).coerceAtLeast(0)
        else s.remainingSec.coerceAtLeast(0)
        return ((total - left) / 60).coerceIn(0, s.config.workMin)
    }

    private fun runTicker(context: Context) {
        ticker?.cancel()
        ticker = scope.launch {
            while (_state.value.running) {
                delay(1000)
                if (!_state.value.running) break
                val left = leftSecFrom(System.currentTimeMillis())
                if (left > 0) {
                    if (left != _state.value.remainingSec) {
                        _state.value = _state.value.copy(remainingSec = left)
                    }
                } else {
                    advancePhase(context, skipped = false)
                    break
                }
            }
        }
    }

    /**
     * Moves to the next phase. The loop matters: if the app was frozen in the
     * background long enough for several phases to elapse, every one of them is
     * settled in this single pass instead of one per second.
     */
    private fun advancePhase(context: Context, skipped: Boolean, skipCreditMin: Int = 0) {
        val now = System.currentTimeMillis()
        var s = _state.value
        val c = s.config
        var chime = false
        val credits = mutableListOf<StudyPending.Block>()
        var creditMin = 0
        val abandoned = !skipped && deadlineMs > 0L && now - deadlineMs > CATCHUP_MAX_GAP_MS
        var guard = 0

        do {
            guard++
            val base = if (skipped || deadlineMs <= 0L) now else deadlineMs
            when (s.phase) {
                Phase.WORK -> {
                    if (!skipped) {
                        if (creditMin + c.workMin <= CATCHUP_CAP_MIN) {
                            creditMin += c.workMin
                            credits.add(StudyPending.Block(c.workMin, base))
                        }
                        chime = true
                    } else if (skipCreditMin > 0 && creditMin + skipCreditMin <= CATCHUP_CAP_MIN) {
                        // نصفهٔ خوانده‌شده هم وقتِ مطالعه است؛ نباید پاک شود.
                        creditMin += skipCreditMin
                        credits.add(StudyPending.Block(skipCreditMin, base))
                    }
                    val done = s.completedWork + (if (skipped) 0 else 1)
                    val long = done > 0 && done % c.cyclesBeforeLong == 0
                    val len = (if (long) c.longBreakMin else c.breakMin) * 60
                    deadlineMs = base + len * 1000L
                    s = s.copy(
                        phase = if (long) Phase.LONG_BREAK else Phase.BREAK,
                        remainingSec = len,
                        completedWork = done,
                    )
                }
                Phase.BREAK, Phase.LONG_BREAK -> {
                    if (!skipped) chime = true
                    val len = c.workMin * 60
                    deadlineMs = base + len * 1000L
                    s = s.copy(phase = Phase.WORK, remainingSec = len)
                }
                Phase.IDLE -> {
                    val len = c.workMin * 60
                    deadlineMs = base + len * 1000L
                    s = s.copy(phase = Phase.WORK, remainingSec = len)
                }
            }
        } while (!skipped && s.running && deadlineMs <= now && guard < 500)

        if (abandoned) s = s.copy(running = false)
        if (s.running) {
            s = s.copy(remainingSec = leftSecFrom(now).coerceAtLeast(1))
        } else {
            deadlineMs = 0L
        }
        _state.value = s
        persist(credits)
        if (chime) playChime(context)
        if (s.running) runTicker(context)
        arm(context)
        sync()
    }

    /** Keeps the phase-end alarm in sync with the current deadline. */
    private fun arm(context: Context) {
        val ctx = context.applicationContext
        if (_state.value.running && deadlineMs > 0L) {
            ir.studying.app.notify.PomodoroAlarm.schedule(ctx, deadlineMs)
        } else {
            ir.studying.app.notify.PomodoroAlarm.cancel(ctx)
        }
    }

    /**
     * Entry point for the phase-end alarm.
     *
     * Double crediting is the danger here: when the process is still alive the
     * ticker settles the phase from the very same absolute deadline. Both run on
     * the main thread, so they cannot interleave, and this only advances when the
     * deadline has genuinely passed -- after which the deadline points at the
     * next phase and the ticker finds nothing left to do.
     */
    fun onAlarm(context: Context) {
        val ctx = context.applicationContext
        if (!_state.value.running) {
            ir.studying.app.notify.PomodoroAlarm.cancel(ctx)
            return
        }
        if (deadlineMs > 0L) {
            if (leftSecFrom(System.currentTimeMillis()) <= 0) advancePhase(ctx, skipped = false) else arm(ctx)
        } else {
            // Process was killed and rebuilt without App.onCreate having a saved
            // deadline in memory yet; replay from disk instead.
            restore(ctx)
        }
    }

    private fun playChime(context: Context) {
        runCatching {
            val mp = MediaPlayer.create(context.applicationContext, R.raw.chime) ?: return
            mp.setOnCompletionListener { it.release() }
            mp.start()
        }
    }
}
