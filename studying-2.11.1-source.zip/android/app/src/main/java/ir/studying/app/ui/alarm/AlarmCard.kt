package ir.studying.app.ui.alarm

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AlarmAdd
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.alarm.Alarm
import ir.studying.app.alarm.AlarmStore
import ir.studying.app.ui.components.GlowSwitch
import ir.studying.app.ui.components.OrbitRing
import ir.studying.app.ui.components.RollingText
import ir.studying.app.ui.components.bouncyClick

/**
 * کارت زنگ در صفحهٔ اصلی.
 *
 * چرا در خانه: بیداری صبح اولین حلقهٔ همهٔ عادت‌های این اپ است. زنگی که در
 * عمق تنظیمات پنهان باشد، شب که کاربر گوشی را می‌گذارد کنار، یادش نمی‌آید
 * روشنش کند. اینجا هم زنگ بعدی دیده می‌شود و هم با یک کلید خاموش/روشن است.
 *
 * ظاهر ۲.۹: نسخهٔ کوچکِ همان حلقهٔ مداری صفحهٔ زنگ دور آیکن می‌چرخد و ساعت
 * غلتان است؛ کلید هم همان کلید درخشان بخش زنگ.
 */
@Composable
fun AlarmHomeCard(onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val alarms by AlarmStore.alarms.collectAsState()
    var tick by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        AlarmStore.init(ctx)
        /* هر دقیقه یک بار «۳ ساعت دیگر» را تازه می‌کند. */
        while (true) {
            tick = System.currentTimeMillis()
            kotlinx.coroutines.delay(60_000)
        }
    }

    val next = remember(alarms, tick) { nextAlarmOf(alarms) }
    AlarmHomeCardBody(next, onOpen = onOpen, onToggle = { a, on -> AlarmStore.setEnabled(ctx, a.id, on) })
}

/** بدنهٔ بی‌حالت کارت خانه؛ جدا شده تا پیش‌نمایش و آزمون بدون انبار زنگ هم ممکن باشد. */
@Composable
internal fun AlarmHomeCardBody(
    next: Pair<Alarm, Long>?,
    onOpen: () -> Unit,
    onToggle: (Alarm, Boolean) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(lerp(cs.surface, cs.primary, 0.12f), lerp(cs.surface, NightViolet, 0.06f)),
                ),
            )
            .border(1.dp, cs.primary.copy(alpha = 0.22f), shape)
            .bouncyClick(pressedScale = 0.97f, onClick = onOpen),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                if (next != null) {
                    val remain = (next.second - System.currentTimeMillis()).coerceAtLeast(0L)
                    OrbitRing(
                        progress = 1f - (remain / (24f * 3_600_000f)).coerceIn(0f, 1f),
                        modifier = Modifier.fillMaxSize(),
                        stroke = 3.dp,
                        track = cs.primary.copy(alpha = 0.14f),
                        colors = listOf(cs.primary, DawnPink),
                        satellite = false,
                    )
                    WobblingBell(tint = cs.primary, size = 19.dp, icon = Icons.Rounded.Alarm, periodMs = 4200)
                } else {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.AlarmAdd, null, tint = cs.primary, modifier = Modifier.size(19.dp)) }
                }
            }
            Spacer(Modifier.width(10.dp))

            Column(Modifier.weight(1f)) {
                if (next == null) {
                    /*
                     * بدون زنگ فقط یک خط: توضیح تبلیغاتی سرِ صفحهٔ خانه جای
                     * درستی ندارد، خودِ صفحهٔ زنگ آن را می‌گوید.
                     */
                    Text("زنگ بیدارباش", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text("تنظیم نشده · برای ساختن لمس کن", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                } else {
                    val (alarm, at) = next
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RollingText(
                            clock(alarm.hour, alarm.minute),
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 22.sp, fontWeight = FontWeight.Black),
                            color = cs.onSurface,
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            periodEmoji(alarm.hour) + " " + dayOfLabel(at),
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    Text(untilLabel(at), style = MaterialTheme.typography.labelSmall, color = cs.primary)
                }
            }

            if (next != null) {
                GlowSwitch(
                    checked = next.first.enabled,
                    onCheckedChange = { onToggle(next.first, it) },
                    icon = Icons.Rounded.Alarm,
                )
            } else {
                Icon(Icons.Rounded.ChevronLeft, null, tint = cs.onSurfaceVariant.copy(alpha = 0.7f))
            }
        }
    }
}
