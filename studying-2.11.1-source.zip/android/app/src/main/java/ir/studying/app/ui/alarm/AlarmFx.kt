package ir.studying.app.ui.alarm

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.alarm.Alarm
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AuroraBackdrop
import ir.studying.app.ui.components.GlassPill
import ir.studying.app.ui.components.GlowSwitch
import ir.studying.app.ui.components.OrbitRing
import ir.studying.app.ui.components.RollingText
import ir.studying.app.ui.components.StarField
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.shine
import ir.studying.app.ui.theme.brandGradient

/**
 * زبان بصری بخش زنگ (نسخهٔ ۲.۹).
 *
 * ایده: زنگ بیدارباش یعنی «شب → صبح». پس قابِ اصلی یک آسمان شبِ زنده است
 * (شفق شناور، ستاره‌های چشمک‌زن، ماه هلالی) و حلقهٔ مداری دورِ زنگوله، هر چه
 * به زمان زنگ نزدیک‌تر شوی پرتر می‌شود. کارت‌ها شیشه‌ای‌اند و کلیدها درخشان.
 */

/* ---------------------------- رنگ‌های آسمان ---------------------------- */

internal val NightTop = Color(0xFF070B1F)
internal val NightMid = Color(0xFF141238)
internal val NightViolet = Color(0xFF8B5CF6)
internal val DawnPink = Color(0xFFF472B6)
internal val DawnGold = Color(0xFFFBBF24)

/** زمینهٔ آسمان شب، کمی متمایل به رنگ تم کاربر. */
@Composable
internal fun NightSky(modifier: Modifier = Modifier, stars: Int = 46, seed: Int = 11, intensity: Float = 1f) {
    val cs = MaterialTheme.colorScheme
    Box(modifier) {
        AuroraBackdrop(
            Modifier.fillMaxSize(),
            base = listOf(NightTop, NightMid, lerp(Color(0xFF0E1B3A), cs.primary, 0.22f)),
            blobs = listOf(
                cs.primary.copy(alpha = 0.30f * intensity),
                NightViolet.copy(alpha = 0.30f * intensity),
                cs.secondary.copy(alpha = 0.22f * intensity),
            ),
        )
        StarField(Modifier.fillMaxSize(), count = stars, seed = seed)
    }
}

/** ماه هلالی با هالهٔ نرم که آرام بالا و پایین می‌رود. */
@Composable
internal fun CrescentMoon(modifier: Modifier = Modifier, size: Dp = 46.dp, color: Color = Color(0xFFFDE68A)) {
    val t = rememberInfiniteTransition(label = "moon")
    val bob by t.animateFloat(
        -3f, 3f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "moonBob",
    )
    val glow by t.animateFloat(
        0.55f, 1f,
        infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "moonGlow",
    )
    Canvas(modifier.size(size).graphicsLayer { translationY = bob * density }) {
        val c = center
        val r = this.size.minDimension * 0.30f
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.34f * glow), Color.Transparent), center = c, radius = r * 2.3f),
            radius = r * 2.3f, center = c,
        )
        val moon = Path().apply { addOval(Rect(c, r)) }
        val cut = Path().apply { addOval(Rect(c + Offset(r * 0.52f, -r * 0.34f), r * 0.86f)) }
        val crescent = Path().apply { op(moon, cut, PathOperation.Difference) }
        drawPath(crescent, Brush.linearGradient(listOf(Color.White, color), start = c - Offset(r, r), end = c + Offset(r, r)))
    }
}

/** «z z z» شناور بالای ماه، برای وقتی هیچ زنگی روشن نیست. */
@Composable
internal fun SleepyZs(modifier: Modifier = Modifier, color: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "zzz")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "zP")
    Box(modifier.size(54.dp)) {
        for (i in 0..2) {
            val f = (p + i / 3f) % 1f
            Text(
                "z",
                color = color.copy(alpha = (1f - f) * 0.85f),
                fontSize = (11 + i * 4).sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .graphicsLayer {
                        translationX = (f * 22f + i * 6f) * density
                        translationY = -(f * 40f) * density
                        rotationZ = -12f + f * 18f
                    },
            )
        }
    }
}

/** زنگوله‌ای که هر چند ثانیه یک بار تند می‌لرزد. */
@Composable
internal fun WobblingBell(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    size: Dp = 26.dp,
    icon: ImageVector = Icons.Rounded.NotificationsActive,
    periodMs: Int = 3200,
) {
    val t = rememberInfiniteTransition(label = "bell")
    val rot by t.animateFloat(
        0f, 0f,
        infiniteRepeatable(
            keyframes {
                durationMillis = periodMs
                0f at 0
                -16f at 90
                14f at 190
                -11f at 290
                8f at 390
                -4f at 480
                0f at 580
                0f at periodMs
            },
        ),
        label = "bellRot",
    )
    Icon(
        icon, null, tint = tint,
        modifier = modifier.size(size).graphicsLayer {
            rotationZ = rot
            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0.12f)
        },
    )
}

/* ------------------------------ قاب زنگ بعدی ------------------------------ */

/**
 * کارت شاخصِ بالای صفحه: آسمان شب + ساعت غلتان + حلقهٔ مداریِ نزدیک‌شدن.
 *
 * پرشدن حلقه نسبت به ۲۴ ساعت آینده حساب می‌شود؛ یعنی زنگی که سه ساعت دیگر
 * می‌زند تقریباً پر است و زنگ سه روز بعد تازه اول راه.
 */
@Composable
internal fun NextAlarmHero(next: Pair<Alarm, Long>?, onCreate: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(30.dp)
    Box(
        modifier
            .fillMaxWidth()
            .height(if (next == null) 214.dp else 236.dp)
            .graphicsLayer {
                this.shape = shape
                clip = true
                shadowElevation = 10.dp.toPx()
            }
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.04f))), shape),
    ) {
        NightSky(Modifier.fillMaxSize())
        if (next == null) {
            EmptyHeroContent(onCreate)
        } else {
            val (alarm, at) = next
            val remainMs = (at - System.currentTimeMillis()).coerceAtLeast(0L)
            val progress = 1f - (remainMs / (24f * 3_600_000f)).coerceIn(0f, 1f)
            CrescentMoon(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 120.dp), size = 40.dp)
            Row(
                Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    LiveDotLabel("زنگ بعدی · " + dayOfLabel(at))
                    Spacer(Modifier.height(6.dp))
                    RollingText(
                        clock(alarm.hour, alarm.minute),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 54.sp, fontWeight = FontWeight.Black, letterSpacing = 0.sp,
                        ),
                        color = Color.White,
                    )
                    Text(
                        periodEmoji(alarm.hour) + "  " + periodLabel(alarm.hour) +
                            (if (alarm.label.isNotBlank()) " · " + alarm.label else ""),
                        color = Color.White.copy(alpha = 0.78f),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        GlassPill(untilLabel(at), leading = "⏳", style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.height(6.dp))
                    GlassPill(missionLabel(alarm), leading = missionEmoji(alarm), style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(124.dp), contentAlignment = Alignment.Center) {
                    OrbitRing(
                        progress = progress,
                        modifier = Modifier.fillMaxSize(),
                        stroke = 7.dp,
                        track = Color.White.copy(alpha = 0.12f),
                        colors = listOf(MaterialTheme.colorScheme.primary, DawnPink),
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        WobblingBell(tint = Color.White, size = 24.dp)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            compactRemain(remainMs),
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                        )
                        Text("مانده", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHeroContent(onCreate: () -> Unit) {
    Row(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            LiveDotLabel("هیچ زنگی مسلح نیست", live = false)
            Spacer(Modifier.height(8.dp))
            Text(
                "صبحِ فردا را\nاز همین حالا بساز",
                color = Color.White,
                fontSize = 23.sp,
                lineHeight = 32.sp,
                fontWeight = FontWeight.Black,
            )
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.primary, DawnPink)))
                    .shine()
                    .bouncyClick(onClick = onCreate)
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("ساخت زنگ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
        Box(Modifier.size(118.dp), contentAlignment = Alignment.Center) {
            CrescentMoon(size = 104.dp)
            SleepyZs(Modifier.align(Alignment.TopEnd).offset(x = (-4).dp, y = 2.dp))
        }
    }
}

/** برچسب کوچک با نقطهٔ نبض‌دار؛ نشانهٔ «مسلح بودن». */
@Composable
internal fun LiveDotLabel(text: String, live: Boolean = true, color: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "liveDot")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "liveP")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp), contentAlignment = Alignment.Center) {
            val dot = if (live) Color(0xFF4ADE80) else color.copy(alpha = 0.4f)
            if (live) {
                Box(
                    Modifier.size(14.dp).graphicsLayer {
                        scaleX = 0.4f + p * 0.9f; scaleY = 0.4f + p * 0.9f; alpha = 1f - p
                    }.background(dot.copy(alpha = 0.6f), CircleShape),
                )
            }
            Box(Modifier.size(7.dp).background(dot, CircleShape))
        }
        Spacer(Modifier.width(6.dp))
        Text(text, color = color.copy(alpha = 0.82f), style = MaterialTheme.typography.labelMedium)
    }
}

/* ------------------------------ کارت هر زنگ ------------------------------ */

/**
 * کارت شیشه‌ای یک زنگ.
 *
 * روشن: زمینهٔ گرادیانی، حاشیهٔ رنگی و برچسبِ «چقدر مانده». خاموش: همه‌چیز
 * کم‌رنگ و بی‌حاشیه، تا با یک نگاه معلوم باشد کدام مسلح است.
 */
@Composable
internal fun AlarmCard(
    alarm: Alarm,
    nextAt: Long?,
    onToggle: (Boolean) -> Unit,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val k by animateFloatAsState(if (alarm.enabled) 1f else 0f, tween(420), label = "cardOn")
    val shape = RoundedCornerShape(26.dp)
    val bgTop = lerp(cs.surfaceVariant.copy(alpha = 0.38f), lerp(cs.surface, cs.primary, 0.15f), k)
    val bgBottom = lerp(cs.surfaceVariant.copy(alpha = 0.30f), lerp(cs.surface, cs.secondary, 0.05f), k)
    val timeColor = lerp(cs.onSurfaceVariant.copy(alpha = 0.55f), cs.onSurface, k)

    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(bgTop, bgBottom)))
            .border(
                BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            lerp(cs.outlineVariant, cs.primary.copy(alpha = 0.65f), k),
                            lerp(cs.outlineVariant, cs.secondary.copy(alpha = 0.18f), k),
                        ),
                    ),
                ),
                shape,
            )
            .bouncyClick(pressedScale = 0.97f, onClick = onClick),
    ) {
        /* درخشش ملایم گوشهٔ کارت روشن. */
        if (k > 0.01f) {
            Box(
                Modifier.matchParentSize().drawBehind {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(cs.primary.copy(alpha = 0.16f * k), Color.Transparent),
                            center = Offset(size.width, 0f),
                            radius = size.width * 0.7f,
                        ),
                        radius = size.width * 0.7f,
                        center = Offset(size.width, 0f),
                    )
                },
            )
        }
        Column(Modifier.padding(start = 18.dp, end = 16.dp, top = 16.dp, bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            clock(alarm.hour, alarm.minute),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            color = timeColor,
                        )
                        Spacer(Modifier.width(10.dp))
                        PeriodChip(alarm.hour, k)
                    }
                    if (alarm.label.isNotBlank()) {
                        Text(
                            alarm.label,
                            style = MaterialTheme.typography.bodyMedium,
                            color = lerp(cs.onSurfaceVariant.copy(alpha = 0.6f), cs.onSurfaceVariant, k),
                            maxLines = 1,
                        )
                    }
                    AnimatedVisibility(
                        visible = alarm.enabled && nextAt != null,
                        enter = fadeIn(tween(260)) + expandVertically(),
                        exit = fadeOut(tween(160)) + shrinkVertically(),
                    ) {
                        Text(
                            "⏳ " + (nextAt?.let { untilLabel(it) } ?: ""),
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.primary,
                            modifier = Modifier.padding(top = 2.dp),
                        )
                    }
                }
                GlowSwitch(
                    checked = alarm.enabled,
                    onCheckedChange = onToggle,
                    icon = Icons.Rounded.Alarm,
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Alarm.weekOrder.forEach { (num, fa) ->
                        DayDot(fa, alarm.days.contains(num), k)
                    }
                }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(cs.error.copy(alpha = 0.10f))
                        .bouncyClick(onClick = onDelete),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.DeleteOutline, "حذف", tint = cs.error, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoTag(missionEmoji(alarm), missionLabel(alarm), k)
                InfoTag(if (alarm.days.isEmpty()) "1️⃣" else "🔁", daysLabel(alarm).let { if (it.length > 16) alarm.days.size.fa() + " روز در هفته" else it }, k)
            }
        }
    }
}

@Composable
private fun PeriodChip(hour: Int, k: Float) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .clip(CircleShape)
            .background(lerp(cs.surfaceVariant.copy(alpha = 0.5f), cs.primary.copy(alpha = 0.14f), k))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(periodEmoji(hour), fontSize = 11.sp)
        Spacer(Modifier.width(3.dp))
        Text(
            periodLabel(hour),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = lerp(cs.onSurfaceVariant, cs.primary, k),
        )
    }
}

/** دایرهٔ روزِ هفته: روزهای فعال با گرادیان پر می‌شوند. */
@Composable
private fun DayDot(letter: String, on: Boolean, k: Float) {
    val cs = MaterialTheme.colorScheme
    val s by animateFloatAsState(if (on) 1f else 0.9f, spring(dampingRatio = 0.5f), label = "dayDot")
    Box(
        Modifier
            .size(26.dp)
            .graphicsLayer { scaleX = s; scaleY = s }
            .clip(CircleShape)
            .then(
                if (on) Modifier.background(
                    Brush.linearGradient(
                        listOf(
                            lerp(cs.onSurfaceVariant.copy(alpha = 0.35f), cs.primary, k),
                            lerp(cs.onSurfaceVariant.copy(alpha = 0.25f), cs.secondary, k),
                        ),
                    ),
                ) else Modifier.border(1.dp, cs.outlineVariant.copy(alpha = 0.8f), CircleShape),
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            letter,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (on) lerp(cs.surface, cs.onPrimary, k) else cs.onSurfaceVariant.copy(alpha = 0.5f),
        )
    }
}

@Composable
private fun InfoTag(emoji: String, text: String, k: Float) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .clip(CircleShape)
            .background(lerp(cs.surfaceVariant.copy(alpha = 0.45f), cs.surface.copy(alpha = 0.75f), k))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 11.sp)
        Spacer(Modifier.width(5.dp))
        Text(text, fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

/* ------------------------------- دکمهٔ شناور ------------------------------- */

/** دکمهٔ «زنگ تازه»: گرادیان برند، نوار نور و سایهٔ رنگی. */
@Composable
internal fun NewAlarmFab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier
            .graphicsLayer {
                shadowElevation = 14.dp.toPx()
                shape = CircleShape
                clip = true
                spotShadowColor = cs.primary
                ambientShadowColor = cs.primary
            }
            .background(brandGradient())
            .shine()
            .bouncyClick(onClick = onClick)
            .padding(start = 16.dp, end = 20.dp, top = 15.dp, bottom = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Add, null, tint = cs.onPrimary, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(9.dp))
        Text("زنگ تازه", color = cs.onPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
    }
}

/* ------------------------------- اعلان‌ها ------------------------------- */

/**
 * کارت هشدارِ تنظیمات (آلارم دقیق، بهینه‌سازی باتری).
 *
 * آیکن با موج آرام تپش دارد تا دیده شود، ولی رنگ کارت ملایم است؛ این‌ها
 * توصیه‌اند، نه خطای قرمز وسط صفحه.
 */
@Composable
internal fun AlarmNotice(
    icon: ImageVector,
    tint: Color,
    title: String,
    body: String,
    action: String,
    onAction: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(lerp(cs.surface, tint, 0.16f), lerp(cs.surface, tint, 0.05f))))
            .border(1.dp, tint.copy(alpha = 0.32f), shape)
            .padding(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
            ir.studying.app.ui.components.RippleRings(Modifier.fillMaxSize(), color = tint, rings = 2, periodMs = 2600, strokeWidth = 1.5.dp)
            Box(
                Modifier.size(32.dp).clip(CircleShape).background(tint.copy(alpha = 0.20f)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(3.dp))
            Text(body, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, lineHeight = 19.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                action,
                color = if (tint.luminance() > 0.55f) Color(0xFF1F1300) else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(tint)
                    .bouncyClick(onClick = onAction)
                    .padding(horizontal = 14.dp, vertical = 7.dp),
            )
        }
    }
}

private fun Color.luminance(): Float = 0.2126f * red + 0.7152f * green + 0.0722f * blue

/* ------------------------------- سرتیتر بخش ------------------------------- */

@Composable
internal fun AlarmSectionHeader(title: String, count: Int, active: Int) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(top = 6.dp, start = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 2.dp),
        ) { Text(count.fa(), color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.weight(1f))
        if (count > 0) {
            Text(
                if (active == 0) "همه خاموش" else active.fa() + " روشن",
                style = MaterialTheme.typography.labelMedium,
                color = cs.onSurfaceVariant,
            )
        }
    }
}

/* -------------------------------- برچسب‌ها -------------------------------- */

internal fun periodLabel(hour: Int): String = when (hour) {
    in 0..4 -> "بامداد"
    in 5..11 -> "صبح"
    in 12..15 -> "ظهر"
    in 16..19 -> "عصر"
    else -> "شب"
}

internal fun periodEmoji(hour: Int): String = when (hour) {
    in 0..4 -> "🌙"
    in 5..8 -> "🌅"
    in 9..15 -> "☀️"
    in 16..19 -> "🌇"
    else -> "🌙"
}

internal fun missionEmoji(alarm: Alarm): String = when {
    alarm.mission == Alarm.MISSION_NONE || alarm.problems <= 0 -> "🔕"
    alarm.mission == Alarm.MISSION_SHAKE -> "📳"
    alarm.mission == Alarm.MISSION_TYPING -> "⌨️"
    else -> "🧮"
}

/** «۷:۴۵» برای مرکز حلقه؛ بیش از یک روز: «۲ روز». */
internal fun compactRemain(ms: Long): String {
    val mins = (ms / 60_000L).toInt()
    val h = mins / 60
    val m = mins % 60
    return when {
        h >= 24 -> (h / 24).fa() + " روز"
        else -> h.fa() + ":" + (if (m < 10) "0$m" else "$m").fa()
    }
}
