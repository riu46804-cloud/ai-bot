package ir.studying.app.ui.alarm

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryAlert
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.alarm.AlarmLog
import ir.studying.app.core.fa
import ir.studying.app.ui.components.CountUpText
import ir.studying.app.ui.components.bouncyClick
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SolvedGreen = Color(0xFF10B981)
private val MissedRose = Color(0xFFFB7185)
private val SnoozeAmber = Color(0xFFF59E0B)

/**
 * گزارش زنگ.
 *
 * چرا: «زنگ گذاشتم» یک ادعاست؛ این کارت آن را به عدد تبدیل می‌کند — چند بار
 * زنگ خورد، چند بار واقعاً بیدار شدی، چقدر طول کشید، چند بار تعویق زدی و
 * مهم‌تر از همه چند زنگ اصلاً به گوشت نرسید (که تقصیر تنظیمات باتری است، نه تو).
 *
 * ظاهر ۲.۹: دونات موفقیت با شمارش بالارونده، کاشی‌های آماری با ایموجی، تب
 * لغزان ۷/۳۰ روز و رویدادها روی یک خط زمانی.
 */
@Composable
fun AlarmReportCard() {
    val ctx = LocalContext.current
    val events by AlarmLog.events.collectAsState()
    var days by remember { mutableIntStateOf(7) }
    var all by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { AlarmLog.init(ctx) }

    val cs = MaterialTheme.colorScheme
    val report = remember(events, days) { AlarmLog.report(days) }
    val shape = RoundedCornerShape(26.dp)

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(cs.surfaceVariant.copy(alpha = 0.42f), cs.surfaceVariant.copy(alpha = 0.22f))))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.55f), shape)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center,
            ) { Text("📊", fontSize = 16.sp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("گزارش بیدارباش", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Text(
                    "عملکرد " + days.fa() + " روز اخیر",
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                )
            }
            PeriodToggle(days) { days = it }
        }
        Spacer(Modifier.height(14.dp))

        if (report.fired == 0 && report.missed == 0) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(cs.surface.copy(alpha = 0.55f))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.25f), DawnPink.copy(alpha = 0.18f)))),
                    contentAlignment = Alignment.Center,
                ) { Text("🌤️", fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Text(
                    "هنوز در این بازه زنگی ثبت نشده؛ بعد از اولین بیدارباش اینجا پر می‌شود.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                    lineHeight = 19.sp,
                )
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SuccessDonut(report.successRate, Modifier.size(112.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    LegendRow(cs.primary, "زنگ خورده", report.fired)
                    LegendRow(SolvedGreen, "بیداری موفق", report.solved)
                    LegendRow(MissedRose, "از دست رفته", report.missed)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat(Modifier.weight(1f), "💤", "تعویق", report.snoozes.fa(), SnoozeAmber)
                Stat(Modifier.weight(1f), "⚡", "میانگین حل", dur(report.avgSolveSec), cs.tertiary)
                Stat(Modifier.weight(1f), "🌅", "میانگین بیداری", hm(report.avgWakeMinute), cs.secondary)
            }
            if (report.bestSolveSec > 0) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "🏆 سریع‌ترین بیداری: " + dur(report.bestSolveSec),
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(10.dp))
            val arrow by animateFloatAsState(if (all) 180f else 0f, spring(dampingRatio = 0.6f), label = "evArrow")
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(cs.primary.copy(alpha = 0.10f))
                    .bouncyClick { all = !all }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (all) "بستن رویدادها" else "رویدادهای اخیر",
                    color = cs.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                )
                Spacer(Modifier.width(4.dp))
                Icon(
                    Icons.Rounded.KeyboardArrowDown, null, tint = cs.primary,
                    modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = arrow },
                )
            }
            AnimatedVisibility(
                visible = all,
                enter = fadeIn(tween(220)) + expandVertically(tween(320)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(260)),
            ) {
                Column {
                    Spacer(Modifier.height(10.dp))
                    EventList()
                }
            }
        }
    }
}

/** تب دوگانهٔ ۷/۳۰ روز با نشانگر لغزان. */
@Composable
private fun PeriodToggle(days: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val itemW = 58.dp
    val x by animateDpAsState(if (days == 7) 0.dp else itemW, spring(dampingRatio = 0.7f, stiffness = 500f), label = "periodX")
    Box(
        Modifier
            .clip(CircleShape)
            .background(cs.surface.copy(alpha = 0.7f))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
            .padding(3.dp),
    ) {
        Box(
            Modifier
                .offset(x = x)
                .size(itemW, 28.dp)
                .clip(CircleShape)
                .background(ir.studying.app.ui.theme.brandGradient()),
        )
        Row {
            listOf(7 to "۷ روز", 30 to "۳۰ روز").forEach { (d, t) ->
                val on = days == d
                Box(
                    Modifier.size(itemW, 28.dp).clip(CircleShape).bouncyClick { onPick(d) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        t, fontSize = 12.sp,
                        color = if (on) cs.onPrimary else cs.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

/** دونات نرخ موفقیت؛ با ورود، از صفر تا مقدار واقعی پر می‌شود. */
@Composable
private fun SuccessDonut(rate: Int, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val anim = remember { Animatable(0f) }
    LaunchedEffect(rate) { anim.animateTo(rate / 100f, tween(1100, easing = FastOutSlowInEasing)) }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 11.dp.toPx()
            val inset = sw / 2f + 2.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val tl = Offset(inset, inset)
            drawArc(cs.onSurfaceVariant.copy(alpha = 0.14f), 0f, 360f, false, tl, arcSize, style = Stroke(sw))
            val sweep = 360f * anim.value
            if (sweep > 0.5f) {
                rotate(-90f) {
                    drawArc(
                        Brush.sweepGradient(listOf(SolvedGreen, Color(0xFF4ADE9F), Color(0xFF22D3EE), SolvedGreen)),
                        0f, sweep, false, tl, arcSize, style = Stroke(sw, cap = StrokeCap.Round),
                    )
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CountUpText(
                target = rate,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
                color = cs.onSurface,
                suffix = "٪",
            )
            Text("موفقیت", fontSize = 11.sp, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun LegendRow(color: Color, title: String, value: Int) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 13.sp, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
        CountUpText(
            target = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
            color = color,
        )
    }
}

@Composable
private fun Stat(modifier: Modifier, emoji: String, title: String, value: String, tint: Color) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.14f), cs.surface.copy(alpha = 0.6f))))
            .border(1.dp, tint.copy(alpha = 0.20f), shape)
            .padding(vertical = 11.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 15.sp)
        Spacer(Modifier.height(3.dp))
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = tint, maxLines = 1)
        Text(title, fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

/** رویدادهای اخیر روی یک خط زمانی عمودی. */
@Composable
private fun EventList() {
    val cs = MaterialTheme.colorScheme
    val ev by AlarmLog.events.collectAsState()
    val items = remember(ev) { AlarmLog.recent(20) }
    Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
        items.forEachIndexed { i, e ->
            Row(Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                Box(Modifier.width(18.dp).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                    if (i < items.lastIndex) {
                        Box(
                            Modifier.padding(top = 14.dp).width(2.dp).fillMaxHeight()
                                .background(cs.outlineVariant.copy(alpha = 0.7f)),
                        )
                    }
                    Box(
                        Modifier.padding(top = 9.dp).size(11.dp).clip(CircleShape)
                            .background(kindColor(e.kind).copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center,
                    ) { Box(Modifier.size(6.dp).clip(CircleShape).background(kindColor(e.kind))) }
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f).padding(vertical = 5.dp)) {
                    Text(kindLabel(e), fontSize = 13.sp)
                    Text(stamp(e.at), fontSize = 11.sp, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}

private fun kindColor(kind: String): Color = when (kind) {
    AlarmLog.SOLVED -> Color(0xFF10B981)
    AlarmLog.MISSED -> Color(0xFFFB7185)
    AlarmLog.SNOOZED -> Color(0xFFF59E0B)
    else -> Color(0xFF60A5FA)
}

private fun kindLabel(e: AlarmLog.Event): String {
    val name = if (e.label.isBlank()) "زنگ" else e.label
    return when (e.kind) {
        AlarmLog.FIRED -> if (e.wakeCheck) "چک بیداری شروع شد" else "$name زنگ خورد"
        AlarmLog.SOLVED ->
            (if (e.wakeCheck) "چک بیداری پاس شد" else "$name خاموش شد") +
                (if (e.seconds > 0) " · " + dur(e.seconds) else "")
        AlarmLog.SNOOZED -> "$name تعویق خورد"
        AlarmLog.MISSED -> "$name بی‌جواب ماند"
        else -> name
    }
}

private fun dur(seconds: Int): String {
    if (seconds <= 0) return "—"
    if (seconds < 60) return seconds.fa() + "ث"
    val m = seconds / 60
    val s = seconds % 60
    return m.fa() + "د" + (if (s > 0) " " + s.fa() + "ث" else "")
}

private fun hm(minuteOfDay: Int): String {
    if (minuteOfDay < 0) return "—"
    val h = minuteOfDay / 60
    val m = minuteOfDay % 60
    return (if (h < 10) "۰" + h.fa() else h.fa()) + ":" + (if (m < 10) "۰" + m.fa() else m.fa())
}

private fun stamp(at: Long): String =
    SimpleDateFormat("MM/dd HH:mm", Locale.US).format(Date(at)).fa()

/**
 * بهینه‌سازی باتری، دشمن شمارهٔ یک زنگ.
 *
 * روی خیلی از گوشی‌ها (شیائومی، سامسونگ، هواوی) سیستم اپ را در خواب عمیق
 * می‌برد و آلارم دقیق هم دیر می‌رسد. اگر اپ در لیست مستثنی نباشد، همین‌جا
 * راهش را نشان می‌دهیم.
 */
@Composable
fun AlarmBatteryBanner() {
    val ctx = LocalContext.current
    val pm = ctx.getSystemService(PowerManager::class.java)
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
    val ignoring = remember { pm?.isIgnoringBatteryOptimizations(ctx.packageName) ?: true }
    if (ignoring) return
    AlarmNotice(
        icon = Icons.Rounded.BatteryAlert,
        tint = Color(0xFFFBBF24),
        title = "زنگ را از بهینه‌سازی باتری مستثنی کن",
        body = "وگرنه گوشی اپ را در خواب عمیق نگه می‌دارد و زنگ ممکن است دیر یا اصلاً نخورد.",
        action = "اجازه می‌دهم",
        onAction = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        },
    )
}
