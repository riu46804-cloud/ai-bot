package ir.studying.app.ui.alarm

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.studying.app.alarm.Alarm
import ir.studying.app.alarm.AlarmDismiss
import ir.studying.app.alarm.AlarmService
import ir.studying.app.alarm.AlarmStore
import ir.studying.app.alarm.RingScreen

/**
 * زنگ، روی خودِ اپ.
 *
 * چرا لازم شد: تا حالا فقط یک اکتیویتیِ جدا صفحهٔ زنگ را نشان می‌داد و
 * اندروید ۱۰ به بعد گاهی اجازهٔ اجرای آن را از پس‌زمینه نمی‌دهد (سازنده‌های
 * چینی سخت‌گیرترند). نتیجه: صدا می‌آمد ولی مأموریتی برای خاموش‌کردنش دیده
 * نمی‌شد. حالا اگر کاربر داخل اپ باشد، همان صفحه به‌صورت پوششِ غیرقابل‌بستن
 * روی اپ می‌آید — بدون هیچ مجوزی، چون خودِ اپ جلوی چشم است.
 *
 * بستنش هم ممکن نیست: نه با دکمهٔ بازگشت، نه با ضربه بیرون؛ فقط با انجام
 * مأموریت یا تعویق.
 */
@Composable
fun AlarmRingOverlay() {
    val ctx = LocalContext.current
    val ringing by AlarmService.ringing.collectAsState()
    val state = ringing ?: return

    LaunchedEffect(Unit) { AlarmStore.init(ctx) }
    /*
     * تا این پوشش جلوی چشم است، نگهبانِ سرویس اکتیویتی را جلو نیندازد.
     *
     * شرطش «resumed بودن» است نه صرفاً ساخته‌شدن: کامپوزیشن با رفتن اپ به
     * پس‌زمینه از بین نمی‌رود، و اگر فقط به وجودِ این تابع تکیه می‌کردیم،
     * زنگ در پس‌زمینه بی‌صفحه می‌ماند.
     */
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            when (e) {
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> AlarmService.overlayVisible = true
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE -> AlarmService.overlayVisible = false
                else -> Unit
            }
        }
        AlarmService.overlayVisible = owner.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            AlarmService.overlayVisible = false
        }
    }
    val alarm = remember(state.id) { AlarmStore.of(state.id) ?: Alarm(id = state.id, hour = 7, minute = 0) }

    Dialog(
        onDismissRequest = { },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
        ),
    ) {
        Box(Modifier.fillMaxSize().background(Color(0xFF0B1220))) {
            RingScreen(
                alarm = alarm,
                wakeCheck = state.wakeCheck,
                onSolved = { AlarmDismiss.solve(ctx, alarm, state.wakeCheck) },
                onSnooze = { AlarmDismiss.snooze(ctx, alarm) },
            )
        }
    }
}
