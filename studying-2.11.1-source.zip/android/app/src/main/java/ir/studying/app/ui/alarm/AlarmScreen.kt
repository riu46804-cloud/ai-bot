@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
)

package ir.studying.app.ui.alarm

import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BatteryAlert
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.studying.app.alarm.Alarm
import ir.studying.app.alarm.AlarmScheduler
import ir.studying.app.alarm.AlarmStore
import ir.studying.app.alarm.MathMission
import ir.studying.app.core.fa
import ir.studying.app.ui.components.GlowSwitch
import ir.studying.app.ui.components.TimeDial
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.riseIn
import ir.studying.app.ui.components.shine
import ir.studying.app.ui.theme.brandGradient
import java.util.Calendar

/**
 * صفحهٔ زنگ‌های بیدارباش.
 *
 * بازطراحی ۲.۹: بالای صفحه یک «آسمان شبِ» زنده است که زنگ بعدی را با ساعت
 * غلتان و حلقهٔ مداریِ نزدیک‌شدن نشان می‌دهد؛ زنگ‌ها کارت‌های شیشه‌ای با
 * کلید درخشان‌اند و با ورود پلکانی ظاهر می‌شوند؛ ویرایشگر تمام‌صفحه زیر همان
 * آسمان باز می‌شود و دکمهٔ ذخیره همیشه پایین صفحه در دسترس است.
 *
 * منطق دست نخورده: ذخیره، روشن/خاموش، حذف و زمان‌بندی همان مسیر قبلی است.
 * انتخاب ساعت هنوز همان چرخ اختصاصی است که همیشه ساعت را چپ و دقیقه را راست
 * می‌گذارد (TimePicker متریال در راست‌به‌چپ آینه می‌شد).
 */
@Composable
fun AlarmScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val alarms by AlarmStore.alarms.collectAsState()
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var tick by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        AlarmStore.init(ctx)
        while (true) {
            tick = System.currentTimeMillis()
            kotlinx.coroutines.delay(30_000)
        }
    }

    val next = remember(alarms, tick) { nextAlarmOf(alarms) }
    val newAlarm = { editing = Alarm(id = 0, hour = 6, minute = 30) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = { AlarmTopBar(onBack, alarms.count { it.enabled }) },
        floatingActionButton = { NewAlarmFab(onClick = newAlarm) },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "hero") { NextAlarmHero(next, onCreate = newAlarm, modifier = Modifier.riseIn(0)) }
            item(key = "exact") { ExactAlarmBanner() }
            /* پایداری زنگ به تنظیمات باتری گره خورده؛ اگر مشکلی هست همین‌جا دیده شود. */
            item(key = "battery") { AlarmBatteryBanner() }

            if (alarms.isNotEmpty()) {
                item(key = "header") {
                    AlarmSectionHeader("زنگ‌های من", alarms.size, alarms.count { it.enabled })
                }
            }
            itemsIndexed(alarms, key = { _, a -> a.id }) { i, a ->
                val at = remember(a, tick) { if (a.enabled) AlarmScheduler.nextTrigger(a) else null }
                AlarmCard(
                    alarm = a,
                    nextAt = at,
                    onToggle = { AlarmStore.setEnabled(ctx, a.id, it) },
                    onClick = { editing = a },
                    onDelete = { AlarmStore.remove(ctx, a.id) },
                    modifier = Modifier.animateItemPlacement().riseIn(i + 1),
                )
            }
            item(key = "report") { Box(Modifier.riseIn(alarms.size + 1)) { AlarmReportCard() } }
        }
    }

    editing?.let { draft ->
        AlarmEditor(
            initial = draft,
            onDismiss = { editing = null },
            onSave = { AlarmStore.save(ctx, it); editing = null },
        )
    }
}

/** نوار بالا: دکمهٔ بازگشت شیشه‌ای، عنوان و شمار زنگ‌های روشن. */
@Composable
private fun AlarmTopBar(onBack: () -> Unit, active: Int) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .windowInsetsPadding(TopAppBarDefaults.windowInsets)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(cs.surfaceVariant.copy(alpha = 0.6f))
                .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
                .bouncyClick(onClick = onBack),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.ArrowBack, "بازگشت", modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("زنگ بیدارباش", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(
                if (active == 0) "هیچ زنگی روشن نیست" else active.fa() + " زنگ آماده‌باش",
                style = MaterialTheme.typography.labelMedium,
                color = cs.onSurfaceVariant,
            )
        }
        WobblingBell(tint = cs.primary, size = 24.dp, periodMs = 4200)
        Spacer(Modifier.width(6.dp))
    }
}

/**
 * بدون اجازهٔ «آلارم دقیق»، اندروید زنگ را چند دقیقه جابه‌جا می‌کند.
 *
 * برای یک زنگ بیدارباش این فاجعه است، پس اگر اجازه نبود همان‌جا راه گرفتنش
 * را نشان می‌دهیم — و اپ بی‌اجازه هم کار می‌کند، فقط بی‌دقت‌تر.
 */
@Composable
private fun ExactAlarmBanner() {
    val ctx = LocalContext.current
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
    val am = ctx.getSystemService(android.app.AlarmManager::class.java) ?: return
    if (am.canScheduleExactAlarms()) return
    AlarmNotice(
        icon = Icons.Rounded.Timer,
        tint = Color(0xFFFB7185),
        title = "اجازهٔ آلارم دقیق را بده",
        body = "بدون این اجازه اندروید زنگ را تا چند دقیقه جابه‌جا می‌کند.",
        action = "باز کردن تنظیمات",
        onAction = {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        .setData(android.net.Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        },
    )
}

/* ------------------------------- ویرایشگر ------------------------------- */

@Composable
private fun AlarmEditor(initial: Alarm, onDismiss: () -> Unit, onSave: (Alarm) -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            AlarmEditorContent(initial, onDismiss, onSave)
        }
    }
}

/** بدنهٔ ویرایشگر، بیرون از Dialog تا پیش‌نمایش و آزمونش هم ممکن باشد. */
@Composable
internal fun AlarmEditorContent(initial: Alarm, onDismiss: () -> Unit, onSave: (Alarm) -> Unit) {
    var hour by remember { mutableIntStateOf(initial.hour) }
    var minute by remember { mutableIntStateOf(initial.minute) }
    var days by remember { mutableStateOf(initial.days) }
    var label by remember { mutableStateOf(initial.label) }
    var difficulty by remember { mutableIntStateOf(initial.difficulty) }
    var problems by remember { mutableIntStateOf(initial.problems) }
    var snooze by remember { mutableIntStateOf(initial.snoozeMinutes) }
    var snoozeLimit by remember { mutableIntStateOf(initial.snoozeLimit) }
    var wakeCheck by remember { mutableIntStateOf(initial.wakeCheckMinutes) }
    var vibrate by remember { mutableStateOf(initial.vibrate) }
    var report by remember { mutableStateOf(initial.reportWakeup) }
    var mission by remember { mutableStateOf(initial.mission) }
    var soundUri by remember { mutableStateOf(initial.soundUri) }
    var soundName by remember { mutableStateOf(soundTitle(initial.soundUri)) }
    var volume by remember { mutableIntStateOf(initial.volumePercent) }
    var rampSec by remember { mutableIntStateOf(initial.rampSeconds) }
    var autoSilence by remember { mutableIntStateOf(initial.autoSilenceMinutes) }
    val ctx = LocalContext.current

    /*
     * انتخاب آهنگ از خودِ گوشی با همان پنجرهٔ سیستمی.
     *
     * ساختن لیست آهنگ‌ها داخل اپ یعنی مجوز خواندن حافظه؛ این راه نه مجوز
     * می‌خواهد نه لیست دست‌ساز، و هر چیزی که کاربر روی گوشی دارد قابل انتخاب است.
     */
    val ringtonePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { res ->
        val uri = res.data?.getParcelableExtra<android.net.Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        if (uri != null) {
            soundUri = uri.toString()
            soundName = runCatching { RingtoneManager.getRingtone(ctx, uri)?.getTitle(ctx) }.getOrNull()
                ?: "آهنگ انتخابی"
        }
    }

    val save = {
        onSave(
            initial.copy(
                hour = hour,
                minute = minute,
                days = days,
                enabled = true,
                label = label.trim(),
                mission = if (problems <= 0) Alarm.MISSION_NONE else mission,
                difficulty = difficulty,
                problems = problems.coerceAtLeast(1),
                snoozeMinutes = snooze,
                snoozeLimit = snoozeLimit,
                wakeCheckMinutes = wakeCheck,
                vibrate = vibrate,
                gentleRamp = rampSec > 0,
                reportWakeup = report,
                soundUri = soundUri,
                volumePercent = volume,
                rampSeconds = rampSec,
                autoSilenceMinutes = autoSilence,
            ),
        )
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            EditorHero(
                title = if (initial.id > 0) "ویرایش زنگ" else "زنگ تازه",
                hour = hour,
                minute = minute,
                days = days,
                onHour = { hour = it },
                onMinute = { minute = it },
                onClose = onDismiss,
                onSave = save,
            )

            Column(
                Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                EditorSection("📅", "روزهای تکرار", "خالی بگذاری، فقط یک بار زنگ می‌زند") {
                    DayPicker(days) { days = it }
                }

                EditorSection("🏷️", "برچسب", null) {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it.take(40) },
                        placeholder = { Text("مثلاً: مرور صبحگاهی") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.35f),
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                EditorSection("🎯", "مأموریت خاموش‌کردن", "تا این کار انجام نشود، صدا قطع نمی‌شود") {
                    val sel = when (mission) {
                        Alarm.MISSION_TYPING -> 1
                        Alarm.MISSION_SHAKE -> 2
                        else -> 0
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MissionTile("🧮", "ریاضی", "حل چند سؤال", sel == 0, Modifier.weight(1f)) { mission = Alarm.MISSION_MATH }
                        MissionTile("⌨️", "تایپ", "نوشتن جمله", sel == 1, Modifier.weight(1f)) { mission = Alarm.MISSION_TYPING }
                        MissionTile("📳", "تکان", "تکان دادن گوشی", sel == 2, Modifier.weight(1f)) { mission = Alarm.MISSION_SHAKE }
                    }
                    Spacer(Modifier.height(12.dp))
                    LabeledRow(if (mission == Alarm.MISSION_SHAKE) "دفعات" else "تعداد") {
                        ChipRow(
                            options = listOf(0 to "بدون", 1 to "۱", 3 to "۳", 5 to "۵", 8 to "۸"),
                            selected = problems,
                            onSelect = { problems = it },
                        )
                    }
                    AnimatedVisibility(visible = problems > 0) {
                        Column {
                            Spacer(Modifier.height(10.dp))
                            LabeledRow("سختی") {
                                ChipRow(
                                    options = listOf(1 to "😌 ساده", 2 to "🙂 متوسط", 3 to "🔥 سخت"),
                                    selected = difficulty,
                                    onSelect = { difficulty = it },
                                )
                            }
                        }
                    }
                }

                EditorSection("💤", "تعویق", null) {
                    ChipRow(
                        options = listOf(0 to "ممنوع", 3 to "۳ دقیقه", 5 to "۵ دقیقه", 10 to "۱۰ دقیقه"),
                        selected = snooze,
                        onSelect = { snooze = it },
                    )
                    AnimatedVisibility(visible = snooze > 0) {
                        Column {
                            Spacer(Modifier.height(10.dp))
                            LabeledRow("سقف تعویق") {
                                ChipRow(
                                    options = listOf(1 to "۱ بار", 2 to "۲ بار", 3 to "۳ بار", 9 to "بی‌نهایت"),
                                    selected = snoozeLimit,
                                    onSelect = { snoozeLimit = it },
                                )
                            }
                        }
                    }
                }

                EditorSection("👀", "چک بیداری", "بعد از خاموش کردن، دوباره می‌پرسد بیدار مانده‌ای") {
                    ChipRow(
                        options = listOf(0 to "خاموش", 5 to "۵ دقیقه", 10 to "۱۰ دقیقه", 20 to "۲۰ دقیقه"),
                        selected = wakeCheck,
                        onSelect = { wakeCheck = it },
                    )
                }

                EditorSection("🎵", "صدای زنگ", soundName) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Alarm.builtInSounds.forEach { (key, title) ->
                            SoundChip(title, soundEmoji(key), soundUri == key) { soundUri = key; soundName = title }
                        }
                        val custom = soundUri.isNotBlank() && Alarm.builtInSounds.none { it.first == soundUri }
                        SoundChip(if (custom) soundName else "از گوشی", null, custom, icon = true) {
                            val i = android.content.Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "صدای زنگ")
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            runCatching { ringtonePicker.launch(i) }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    SliderRow(
                        title = "بلندی صدا",
                        value = volume,
                        range = 20f..100f,
                        steps = 7,
                        suffix = "٪",
                        onChange = { volume = it },
                    )
                    SliderRow(
                        title = "رسیدن تدریجی به بلندی کامل",
                        value = rampSec,
                        range = 0f..120f,
                        steps = 7,
                        suffix = " ثانیه",
                        zeroLabel = "بدون تدریج",
                        onChange = { rampSec = it },
                    )
                    ToggleLine("لرزش", vibrate) { vibrate = it }
                }

                EditorSection("🔇", "خاموشی خودکار", "اگر کسی جواب ندهد، صدا بی‌نهایت ادامه پیدا نکند") {
                    ChipRow(
                        options = listOf(5 to "۵ دقیقه", 10 to "۱۰ دقیقه", 15 to "۱۵ دقیقه", 30 to "۳۰ دقیقه"),
                        selected = autoSilence,
                        onSelect = { autoSilence = it },
                    )
                }

                EditorSection("📈", "ثبت", null) {
                    ToggleLine("ثبت ساعت بیداری در حسابم", report) { report = it }
                }
                Spacer(Modifier.height(6.dp))
            }
        }

        /* دکمهٔ ذخیره همیشه پایین صفحه در دسترس است. */
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, MaterialTheme.colorScheme.background),
                        endY = 40f,
                    ),
                )
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .graphicsLayer {
                        shadowElevation = 10.dp.toPx()
                        shape = CircleShape
                        clip = true
                    }
                    .background(brandGradient())
                    .shine()
                    .bouncyClick(pressedScale = 0.97f, onClick = save),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    "ذخیره و روشن کردن زنگ",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                )
            }
        }
    }
}

/**
 * سرِ ویرایشگر: همان آسمان شبِ صفحهٔ اصلی، چرخ ساعت و یک جملهٔ زنده که
 * می‌گوید این زنگ دقیقاً کی می‌زند — تا قبل از ذخیره اشتباه «۶ عصر به‌جای ۶
 * صبح» دیده شود.
 */
@Composable
private fun EditorHero(
    title: String,
    hour: Int,
    minute: Int,
    days: Set<Int>,
    onHour: (Int) -> Unit,
    onMinute: (Int) -> Unit,
    onClose: () -> Unit,
    onSave: () -> Unit,
) {
    val shape = RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp)
    Box(Modifier.fillMaxWidth().clip(shape)) {
        NightSky(Modifier.matchParentSize(), stars = 54, seed = 23)
        Column(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp).padding(top = 8.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                        .bouncyClick(onClick = onClose),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, "بی‌خیال", tint = Color.White, modifier = Modifier.size(20.dp)) }
                Spacer(Modifier.weight(1f))
                Text(title, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text(
                    "ذخیره",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                        .bouncyClick(onClick = onSave)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
            Spacer(Modifier.height(10.dp))
            TimeDial(hour = hour, minute = minute, onHour = onHour, onMinute = onMinute, onDark = true)
            Spacer(Modifier.height(10.dp))
            val at = remember(hour, minute, days) {
                AlarmScheduler.nextTrigger(Alarm(id = 0, hour = hour, minute = minute, days = days))
            }
            AnimatedContent(
                targetState = periodEmoji(hour) + "  " + dayOfLabel(at) + " " + periodLabel(hour) + " · " + untilLabel(at),
                transitionSpec = { fadeIn(tween(220)).togetherWith(fadeOut(tween(120))) },
                label = "editorUntil",
            ) { s ->
                Text(
                    s,
                    color = Color.White.copy(alpha = 0.86f),
                    style = MaterialTheme.typography.labelLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.10f))
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                )
            }
        }
    }
}

/** انتخاب روزها: هفت دایره + میان‌برهای رایج. */
@Composable
private fun DayPicker(days: Set<Int>, onChange: (Set<Int>) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val all = Alarm.weekOrder.map { it.first }.toSet()
    val workdays = setOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY)
    val weekend = setOf(Calendar.THURSDAY, Calendar.FRIDAY)
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Alarm.weekOrder.forEach { (num, fa) ->
                val on = days.contains(num)
                val s by animateFloatAsState(if (on) 1f else 0.9f, spring(dampingRatio = 0.45f, stiffness = 600f), label = "dayScale")
                Box(
                    Modifier
                        .weight(1f)
                        .height(46.dp)
                        .graphicsLayer { scaleX = s; scaleY = s }
                        .clip(CircleShape)
                        .then(
                            if (on) Modifier.background(brandGradient())
                            else Modifier.background(cs.surface.copy(alpha = 0.6f)).border(1.dp, cs.outlineVariant, CircleShape),
                        )
                        .bouncyClick(role = androidx.compose.ui.semantics.Role.Checkbox) {
                            onChange(if (on) days - num else days + num)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        fa,
                        color = if (on) cs.onPrimary else cs.onSurfaceVariant,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PresetChip("هر روز", days == all) { onChange(all) }
            PresetChip("شنبه تا چهارشنبه", days == workdays) { onChange(workdays) }
            PresetChip("آخر هفته", days == weekend) { onChange(weekend) }
            PresetChip("فقط یک بار", days.isEmpty()) { onChange(emptySet()) }
        }
    }
}

@Composable
private fun PresetChip(text: String, on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (on) cs.primary.copy(alpha = 0.18f) else cs.surface.copy(alpha = 0.5f), tween(200), label = "preset")
    Text(
        text,
        fontSize = 12.sp,
        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
        color = if (on) cs.primary else cs.onSurfaceVariant,
        modifier = Modifier
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, if (on) cs.primary.copy(alpha = 0.5f) else cs.outlineVariant.copy(alpha = 0.7f), CircleShape)
            .bouncyClick(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}

/** کاشی انتخاب نوع مأموریت؛ انتخاب‌شده با گرادیان و پرش کوچک ایموجی. */
@Composable
private fun MissionTile(
    emoji: String,
    title: String,
    hint: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val k by animateFloatAsState(if (selected) 1f else 0f, tween(260), label = "tileK")
    val pop by animateFloatAsState(if (selected) 1.18f else 1f, spring(dampingRatio = 0.35f, stiffness = 500f), label = "tilePop")
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        lerp(cs.surface.copy(alpha = 0.6f), lerp(cs.surface, cs.primary, 0.22f), k),
                        lerp(cs.surface.copy(alpha = 0.6f), lerp(cs.surface, cs.secondary, 0.10f), k),
                    ),
                ),
            )
            .border(if (selected) 1.5.dp else 1.dp, lerp(cs.outlineVariant, cs.primary, k), shape)
            .bouncyClick(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 24.sp, modifier = Modifier.graphicsLayer { scaleX = pop; scaleY = pop })
        Spacer(Modifier.height(6.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = lerp(cs.onSurface, cs.primary, k))
        Text(hint, fontSize = 10.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center, maxLines = 1)
    }
}

/** تراشهٔ صدا؛ صدای انتخاب‌شده یک اکولایزر زنده دارد. */
@Composable
private fun SoundChip(title: String, emoji: String?, selected: Boolean, icon: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (selected) cs.primary.copy(alpha = 0.18f) else cs.surface.copy(alpha = 0.55f), tween(220), label = "soundBg")
    Row(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .border(1.dp, if (selected) cs.primary.copy(alpha = 0.55f) else cs.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
            .bouncyClick(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when {
            selected -> EqualizerBars(cs.primary)
            icon -> Icon(Icons.Rounded.LibraryMusic, null, tint = cs.primary, modifier = Modifier.size(16.dp))
            emoji != null -> Text(emoji, fontSize = 14.sp)
        }
        Spacer(Modifier.width(7.dp))
        Text(
            title,
            fontSize = 12.sp,
            maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) cs.primary else cs.onSurfaceVariant,
        )
    }
}

/** سه میلهٔ رقصان؛ نشانهٔ «این صدا انتخاب شده». */
@Composable
internal fun EqualizerBars(color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse), label = "eqA")
    val b by t.animateFloat(1f, 0.35f, infiniteRepeatable(tween(530, easing = LinearEasing), RepeatMode.Reverse), label = "eqB")
    val c by t.animateFloat(0.45f, 0.95f, infiniteRepeatable(tween(360, easing = LinearEasing), RepeatMode.Reverse), label = "eqC")
    Row(modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(a, b, c).forEach { h ->
            Box(Modifier.width(3.dp).height(16.dp * h).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

private fun soundEmoji(key: String): String = when (key) {
    "" -> "📱"
    "raw:chime" -> "🔔"
    "raw:amb_thunder" -> "⛈️"
    "raw:amb_ocean" -> "🌊"
    "raw:amb_rain" -> "🌧️"
    else -> "🎵"
}

/** یک ردیف با برچسب کوچک در بالا و گزینه‌ها در ادامه. */
@Composable
private fun LabeledRow(label: String, content: @Composable () -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

/** لغزندهٔ عددی با عنوان و مقدار خوانا. */
@Composable
private fun SliderRow(
    title: String,
    value: Int,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    suffix: String,
    zeroLabel: String? = null,
    onChange: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(top = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(
                if (value == 0 && zeroLabel != null) zeroLabel else value.fa() + suffix,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = cs.primary,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(cs.primary.copy(alpha = 0.12f))
                    .padding(horizontal = 9.dp, vertical = 3.dp),
            )
        }
        Slider(
            value = value.toFloat().coerceIn(range.start, range.endInclusive),
            onValueChange = { onChange(it.toInt()) },
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = cs.primary,
                activeTrackColor = cs.primary,
                inactiveTrackColor = cs.primary.copy(alpha = 0.16f),
                activeTickColor = cs.onPrimary.copy(alpha = 0.5f),
                inactiveTickColor = cs.primary.copy(alpha = 0.35f),
            ),
        )
    }
}

/** نام خواندنی صدای ذخیره‌شده، برای وقتی ویرایشگر باز می‌شود. */
private fun soundTitle(uri: String): String =
    Alarm.builtInSounds.firstOrNull { it.first == uri }?.second ?: "آهنگ انتخابی"

/** کارت یک بخش از ویرایشگر؛ کاشی ایموجی + عنوان + توضیح کوتاه + محتوا. */
@Composable
private fun EditorSection(emoji: String, title: String, hint: String?, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surfaceVariant.copy(alpha = 0.38f))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.55f), shape)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center,
            ) { Text(emoji, fontSize = 16.sp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
                if (hint != null) {
                    Text(hint, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 2)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

/** ردیف انتخاب چندگزینه‌ای: گزینهٔ فعال با گرادیان برند و پرش فنری. */
@Composable
private fun ChipRow(options: List<Pair<Int, String>>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (value, text) ->
            val on = value == selected
            val s by animateFloatAsState(if (on) 1f else 0.96f, spring(dampingRatio = 0.45f, stiffness = 600f), label = "chipScale")
            Box(
                Modifier
                    .weight(1f)
                    .graphicsLayer { scaleX = s; scaleY = s }
                    .clip(RoundedCornerShape(14.dp))
                    .then(
                        if (on) Modifier.background(brandGradient())
                        else Modifier.background(cs.surface.copy(alpha = 0.6f)).border(1.dp, cs.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(14.dp)),
                    )
                    .bouncyClick(role = androidx.compose.ui.semantics.Role.RadioButton) { onSelect(value) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text,
                    fontSize = 12.sp,
                    maxLines = 1,
                    fontWeight = if (on) FontWeight.Black else FontWeight.Normal,
                    color = if (on) cs.onPrimary else cs.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ToggleLine(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        GlowSwitch(checked = checked, onCheckedChange = onChange)
    }
}

internal fun clock(hour: Int, minute: Int): String =
    (if (hour < 10) "0$hour" else "$hour").fa() + ":" + (if (minute < 10) "0$minute" else "$minute").fa()

internal fun daysLabel(alarm: Alarm): String {
    if (alarm.days.isEmpty()) return "یک‌بار"
    if (alarm.days.size == 7) return "هر روز"
    return Alarm.weekOrder.filter { alarm.days.contains(it.first) }.joinToString("، ") { it.second }
}

internal fun missionLabel(alarm: Alarm): String = when {
    alarm.mission == Alarm.MISSION_NONE || alarm.problems <= 0 -> "بدون مأموریت"
    alarm.mission == Alarm.MISSION_SHAKE -> "تکان دادن · " + MathMission.label(alarm.difficulty)
    alarm.mission == Alarm.MISSION_TYPING -> alarm.problems.fa() + " جملهٔ تایپی"
    else -> alarm.problems.fa() + " سؤال " + MathMission.label(alarm.difficulty)
}

/** فاصلهٔ زمانی تا زنگ بعدی، برای کارت خانه. */
internal fun untilLabel(atMs: Long): String {
    val diff = (atMs - System.currentTimeMillis()).coerceAtLeast(0L)
    val mins = (diff / 60_000L).toInt()
    val h = mins / 60
    val m = mins % 60
    return when {
        h > 24 -> (h / 24).fa() + " روز دیگر"
        h > 0 && m > 0 -> h.fa() + " ساعت و " + m.fa() + " دقیقه دیگر"
        h > 0 -> h.fa() + " ساعت دیگر"
        else -> m.fa() + " دقیقه دیگر"
    }
}

/** روزِ زنگ بعدی به فارسی، برای وقتی که زنگ فردا یا پس‌فردا است. */
internal fun dayOfLabel(atMs: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = atMs }
    val names = mapOf(
        Calendar.SATURDAY to "شنبه", Calendar.SUNDAY to "یک‌شنبه", Calendar.MONDAY to "دوشنبه",
        Calendar.TUESDAY to "سه‌شنبه", Calendar.WEDNESDAY to "چهارشنبه",
        Calendar.THURSDAY to "پنج‌شنبه", Calendar.FRIDAY to "جمعه",
    )
    return names[c.get(Calendar.DAY_OF_WEEK)] ?: ""
}

/** نزدیک‌ترین زنگ روشن؛ برای کارت خانه و هر جای دیگری که لازم شود. */
internal fun nextAlarmOf(alarms: List<Alarm>): Pair<Alarm, Long>? = AlarmScheduler.nextAcross(alarms)
