package ir.studying.app.ui.anatomy

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri

/** Open the atlas in stable Chrome only; never silently fall back to a different browser. */
internal object AnatomyChromeTabs {
    const val CHROME_PACKAGE = "com.android.chrome"
    const val ATLAS_URL = "https://studying.ir/anatomi/atlas-3d-badan-ensan.html"
    private const val CUSTOM_TABS_SERVICE = "android.support.customtabs.action.CustomTabsService"

    enum class Result { OPENED, CHROME_UNAVAILABLE, LAUNCH_FAILED }

    fun canOpen(hasActivity: Boolean, hasService: Boolean): Boolean = hasActivity && hasService

    fun launch(context: Context): Result {
        val activity = context.findActivity() ?: return Result.LAUNCH_FAILED
        return try {
            val pm = activity.packageManager
            val uri = Uri.parse(ATLAS_URL)
            @Suppress("DEPRECATION")
            val viewer = pm.resolveActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
                .setPackage(CHROME_PACKAGE), 0)
            @Suppress("DEPRECATION")
            val service = pm.resolveService(Intent(CUSTOM_TABS_SERVICE).setPackage(CHROME_PACKAGE), 0)
            if (!canOpen(viewer != null, service != null)) return Result.CHROME_UNAVAILABLE

            // Internal launcher binds only Chrome and opens a verified TWA when possible.
            activity.startActivity(Intent(activity, AnatomyTwaActivity::class.java))
            Result.OPENED
        } catch (_: ActivityNotFoundException) {
            Result.CHROME_UNAVAILABLE
        } catch (_: SecurityException) {
            Result.LAUNCH_FAILED
        }
    }

    private fun Context.findActivity(): Activity? {
        var current = this
        while (current is ContextWrapper) {
            if (current is Activity) return current
            val next = current.baseContext
            if (next === current) break
            current = next
        }
        return current as? Activity
    }
}
