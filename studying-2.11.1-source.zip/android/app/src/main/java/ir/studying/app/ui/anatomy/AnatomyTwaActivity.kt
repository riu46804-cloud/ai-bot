package ir.studying.app.ui.anatomy

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.browser.customtabs.CustomTabsCallback
import androidx.browser.customtabs.CustomTabsClient
import androidx.browser.customtabs.CustomTabsServiceConnection
import androidx.browser.customtabs.CustomTabsSession
import androidx.browser.trusted.TrustedWebActivityDisplayMode
import androidx.browser.trusted.TrustedWebActivityIntentBuilder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Launch-only Activity. Chrome owns content, domain verification and browser UI. */
class AnatomyTwaActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var connection: CustomTabsServiceConnection? = null
    private var worker: ExecutorService? = null
    private var bound = false
    private var launched = false
    private var leftAfterLaunch = false
    private var resumed = false
    private var closed = false
    private var pendingError = false
    private var token = 0
    private var readySession: CustomTabsSession? = null
    private var dialog: AlertDialog? = null
    private var timeoutTask: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState?.getBoolean("launched") == true) { finish(); return }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(5, 11, 23))
            addView(ProgressBar(context))
            addView(TextView(context).apply {
                text = "در حال باز کردن اطلس با کروم…"
                setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
                setPadding(24, 30, 24, 10)
            })
        })
        connect()
    }

    private fun connect() {
        if (closed || isFinishing) return
        disconnect()
        dialog?.dismiss(); dialog = null; pendingError = false; readySession = null
        val attempt = ++token
        worker = Executors.newSingleThreadExecutor { task -> Thread(task, "AtlasChromeSession").apply { isDaemon = true } }
        val conn = object : CustomTabsServiceConnection() {
            override fun onCustomTabsServiceConnected(name: ComponentName, client: CustomTabsClient) {
                if (closed || attempt != token || isFinishing) return
                // Binder may stall: keep the main/UI thread free for timeout and Back.
                worker?.execute {
                    val session = try { client.warmup(0L); client.newSession(CustomTabsCallback()) }
                        catch (_: RuntimeException) { null }
                    handler.post {
                        if (closed || attempt != token || isFinishing) return@post
                        if (session == null) fail(attempt)
                        else { readySession = session; cancelTimeout(); if (resumed) launchReady(attempt) }
                    }
                }
            }
            override fun onServiceDisconnected(name: ComponentName) {
                if (!launched) fail(attempt)
            }
        }
        connection = conn
        bound = try { CustomTabsClient.bindCustomTabsService(this, AnatomyChromeTabs.CHROME_PACKAGE, conn) }
            catch (_: RuntimeException) { false }
        if (!bound) { fail(attempt); return }
        if (resumed) scheduleTimeout(attempt)
    }

    private fun cancelTimeout() {
        timeoutTask?.let { handler.removeCallbacks(it) }
        timeoutTask = null
    }
    private fun scheduleTimeout(attempt: Int) {
        cancelTimeout()
        timeoutTask = Runnable { if (resumed && !launched && attempt == token && !closed) fail(attempt) }
        handler.postDelayed(timeoutTask!!, 12_000)
    }

    private fun launchReady(attempt: Int) {
        if (!resumed || launched || closed || isFinishing || attempt != token) return
        val session = readySession ?: return
        try {
            val builder = TrustedWebActivityIntentBuilder(Uri.parse(AnatomyChromeTabs.ATLAS_URL))
                .setDisplayMode(TrustedWebActivityDisplayMode.ImmersiveMode(
                    true, WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT))
            val twa = builder.build(session)
            // Browser-side DAL verification is never bypassed. Chrome may show its toolbar.
            twa.intent.setPackage(AnatomyChromeTabs.CHROME_PACKAGE)
            twa.launchTrustedWebActivity(this)
            launched = true; readySession = null
            cancelTimeout()
        } catch (_: RuntimeException) { fail(attempt) }
    }

    private fun disconnect() {
        val conn = connection
        if (bound && conn != null) runCatching { unbindService(conn) }
        bound = false; connection = null
        worker?.shutdownNow(); worker = null
    }

    private fun fail(attempt: Int) {
        if (closed || isFinishing || attempt != token || launched) return
        token++; readySession = null; handler.removeCallbacksAndMessages(null); disconnect()
        if (!resumed) { pendingError = true; return }
        if (dialog?.isShowing == true) return
        dialog = AlertDialog.Builder(this)
            .setTitle("کروم باز نشد")
            .setMessage("Google Chrome را فعال و به‌روز کن و دوباره تلاش کن.")
            .setPositiveButton("تلاش دوباره") { _, _ -> connect() }
            .setNegativeButton("بازگشت") { _, _ -> finish() }
            .setOnCancelListener { finish() }.show()
    }

    override fun onPause() {
        resumed = false
        cancelTimeout()
        if (launched) leftAfterLaunch = true
        super.onPause()
    }
    override fun onResume() {
        super.onResume(); resumed = true
        if (launched && leftAfterLaunch) { finish(); return }
        if (pendingError) { pendingError = false; fail(token); return }
        if (!launched && readySession != null) launchReady(token)
        else if (!launched && bound) scheduleTimeout(token)
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("launched", launched)
        super.onSaveInstanceState(outState)
    }
    override fun onDestroy() {
        closed = true; token++
        handler.removeCallbacksAndMessages(null)
        dialog?.dismiss(); dialog = null; readySession = null
        disconnect()
        super.onDestroy()
    }
}
