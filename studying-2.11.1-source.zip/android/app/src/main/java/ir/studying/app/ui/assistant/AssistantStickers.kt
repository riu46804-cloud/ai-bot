package ir.studying.app.ui.assistant

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.roundToInt
import kotlin.random.Random

/*
 * استیکرهای اختصاصی دانا.
 *
 * همه از همان جغدِ اپ ساخته شده‌اند، بدون هیچ فایل تصویری تازه: یک نشان گرد با
 * قاب سفید (مثل استیکرهای واقعی)، جغد داخلش، و چند تکهٔ متحرک دورش. انیمیشن‌ها
 * فقط لایهٔ گرافیکی را عوض می‌کنند (نه چیدمان را) تا گفت‌وگو روان بماند.
 */

/** کلیدهایی که سرور می‌شناسد (ai_sticker_set). */
val StickerKeys = listOf("hi", "love", "celebrate", "fire", "proud", "cheer", "thinking", "wow", "sleepy", "coffee", "oops", "study", "hug")

private class StickerLook(val caption: String, val light: Color, val deep: Color, val periodMs: Int, val owl: Int)

private const val OWL_IDLE = 0
private const val OWL_STUDY = 1
private const val OWL_SLEEP = 2

private fun look(key: String): StickerLook = when (key) {
    "love" -> StickerLook("قربونت!", Color(0xFFFDA4AF), Color(0xFFF43F5E), 2000, OWL_IDLE)
    "celebrate" -> StickerLook("ایول!", Color(0xFFF0ABFC), Color(0xFFA855F7), 1700, OWL_IDLE)
    "fire" -> StickerLook("داغ داغ!", Color(0xFFFDBA74), Color(0xFFF97316), 1500, OWL_IDLE)
    "proud" -> StickerLook("آفرین!", Color(0xFFFDE68A), Color(0xFFF59E0B), 2200, OWL_IDLE)
    "cheer" -> StickerLook("تو می‌تونی!", Color(0xFF93C5FD), Color(0xFF3B82F6), 1300, OWL_IDLE)
    "thinking" -> StickerLook("هوم…", Color(0xFFC7D2FE), Color(0xFF6366F1), 2400, OWL_STUDY)
    "wow" -> StickerLook("واای!", Color(0xFFFEF08A), Color(0xFFEAB308), 1600, OWL_IDLE)
    "sleepy" -> StickerLook("خسته نباشی", Color(0xFFA5B4FC), Color(0xFF3730A3), 3000, OWL_SLEEP)
    "coffee" -> StickerLook("یه استراحت؟", Color(0xFFFCD9B6), Color(0xFFB45309), 2600, OWL_IDLE)
    "oops" -> StickerLook("اوه اوه!", Color(0xFFA5F3FC), Color(0xFF0891B2), 1800, OWL_IDLE)
    "study" -> StickerLook("بزن بریم!", Color(0xFFBBF7D0), Color(0xFF16A34A), 2000, OWL_STUDY)
    "hug" -> StickerLook("بغل!", Color(0xFFFECDD3), Color(0xFFFB7185), 2200, OWL_IDLE)
    else -> StickerLook("سلام!", Color(0xFF6EE7B7), Color(0xFF10B981), 2000, OWL_IDLE)
}

/** متن دسترس‌پذیری و برچسب کوچک زیر هر استیکر. */
fun stickerCaption(key: String): String = look(key).caption

private fun wave(x: Float) = sin(2f * PI.toFloat() * x)
private fun frac(x: Float) = x - floor(x)
private fun bump(x: Float) = sin(PI.toFloat() * x.coerceIn(0f, 1f))

/**
 * یک استیکر جغد.
 *
 * @param fresh وقتی پیام همین الان رسیده؛ استیکر با پرش وارد می‌شود.
 * @param caption برچسب کوچک زیرش («ایول!»، «سلام!»…).
 */
@Composable
fun OwlSticker(key: String, size: Dp, modifier: Modifier = Modifier, fresh: Boolean = false, caption: Boolean = true) {
    val k = if (key in StickerKeys) key else "hi"
    val lk = look(k)
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val enter = remember { Animatable(if (fresh) 0f else 1f) }
    val tap = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (enter.value < 1f) enter.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = 240f))
    }
    val t = rememberInfiniteTransition(label = "sticker_$k")
    val loop = t.animateFloat(0f, 1f, infiniteRepeatable(tween(lk.periodMs, easing = LinearEasing)), label = "loop")
    var blink by remember { mutableStateOf(false) }
    LaunchedEffect(k) {
        if (lk.owl != OWL_IDLE) return@LaunchedEffect
        while (true) {
            delay(2400L + Random.nextLong(2400L))
            blink = true; delay(130); blink = false
        }
    }
    val badge = size * 0.74f
    val emoji = with(LocalDensity.current) { (size * 0.2f).toSp() }
    val small = with(LocalDensity.current) { (size * 0.14f).toSp() }

    Box(
        modifier
            .size(size)
            .graphicsLayer {
                val e = enter.value
                val s = (0.3f + 0.7f * e) * (1f + 0.12f * tap.value)
                scaleX = s; scaleY = s
                alpha = e.coerceIn(0f, 1f)
                rotationZ = (1f - e) * -16f + tap.value * 6f
            }
            .clickable(remember { MutableInteractionSource() }, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                scope.launch { tap.snapTo(1f); tap.animateTo(0f, spring(dampingRatio = 0.3f, stiffness = 320f)) }
            }
            .semantics { contentDescription = "استیکر جغد: " + lk.caption },
        contentAlignment = Alignment.Center,
    ) {
        BackProps(k, loop, lk)

        Box(
            Modifier
                .size(badge)
                .graphicsLayer { badgeMotion(k, loop.value, this) }
                .shadow(8.dp, CircleShape, ambientColor = lk.deep, spotColor = lk.deep)
                .border(3.dp, Color.White, CircleShape)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(lk.light, lk.deep))),
            contentAlignment = Alignment.Center,
        ) {
            when (lk.owl) {
                OWL_SLEEP -> Image(
                    painterResource(R.drawable.char_owl_sleeping), null,
                    Modifier.requiredSize(badge * 1.15f).absoluteOffset(x = badge * 0.06f, y = -badge * 0.13f),
                    contentScale = ContentScale.Fit,
                )
                OWL_STUDY -> Image(
                    painterResource(R.drawable.char_owl_studying), null,
                    Modifier.requiredSize(badge * 1.3f).offset(y = badge * 0.09f), contentScale = ContentScale.Fit,
                )
                else -> {
                    val img = Modifier.requiredSize(badge * 1.3f).offset(y = badge * 0.09f)
                    Image(painterResource(R.drawable.char_owl_idle), null, img.alpha(if (blink) 0f else 1f), contentScale = ContentScale.Fit)
                    Image(painterResource(R.drawable.char_owl_blink), null, img.alpha(if (blink) 1f else 0f), contentScale = ContentScale.Fit)
                }
            }
        }

        FrontProps(k, loop, size, emoji, small)

        if (caption) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .graphicsLayer {
                        rotationZ = -4f
                        val e = enter.value
                        scaleX = e; scaleY = e
                    }
                    .shadow(3.dp, RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(lk.deep, lerpColor(lk.deep, lk.light, 0.35f))), RoundedCornerShape(50))
                    .border(1.5.dp, Color.White, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 2.dp),
            ) {
                Text(lk.caption, color = Color.White, fontWeight = FontWeight.Black, fontSize = small * 0.9f, maxLines = 1)
            }
        }
    }
}

private fun lerpColor(a: Color, b: Color, f: Float) = Color(
    red = a.red + (b.red - a.red) * f, green = a.green + (b.green - a.green) * f,
    blue = a.blue + (b.blue - a.blue) * f, alpha = 1f,
)

/** حرکت خودِ نشانِ جغد. */
private fun badgeMotion(k: String, x: Float, g: GraphicsLayerScope) {
    with(g) { motion(k, x) }
}

private fun GraphicsLayerScope.motion(k: String, x: Float) {
    when (k) {
        "hi" -> rotationZ = 6f * wave(x)
        "love" -> { val b = 1f + 0.06f * (wave(x * 2f).coerceAtLeast(0f)); scaleX = b; scaleY = b }
        "celebrate" -> { translationY = -abs(sin(PI.toFloat() * 2f * x)) * size.height * 0.08f; rotationZ = 4f * wave(x) }
        "fire" -> { val b = 1f + 0.03f * wave(x * 2f); scaleX = b; scaleY = b }
        "proud" -> { rotationZ = 3f * wave(x); translationY = -size.height * 0.02f * (1f + wave(x)) }
        "cheer" -> {
            val b = abs(sin(PI.toFloat() * x))
            translationY = -b * size.height * 0.09f
            scaleY = 1f + 0.05f * b; scaleX = 1f - 0.03f * b
            transformOrigin = TransformOrigin(0.5f, 1f)
        }
        "thinking" -> { rotationZ = -5f + 3f * wave(x); translationX = size.width * 0.01f * wave(x) }
        "wow" -> { val p = (1f - x); val b = 1f + 0.09f * p * p * p; scaleX = b; scaleY = b }
        "sleepy" -> { val b = 1f + 0.025f * wave(x); scaleX = b; scaleY = b }
        "coffee" -> translationY = size.height * 0.015f * wave(x)
        "oops" -> { val env = (1f - x).let { it * it }; rotationZ = 9f * sin(2f * PI.toFloat() * 4f * x) * env }
        "study" -> translationY = size.height * 0.02f * wave(x * 2f)
        "hug" -> { val b = abs(wave(x)); scaleX = 1f + 0.07f * b; scaleY = 1f - 0.04f * b }
    }
}

/** تکه‌های پشت نشان (هاله، پرتو، کاغذرنگی). */
@Composable
private fun BoxScope.BackProps(k: String, loop: State<Float>, lk: StickerLook) {
    when (k) {
        "celebrate" -> Canvas(Modifier.matchParentSize()) {
            val colors = listOf(Color(0xFFF472B6), Color(0xFFFBBF24), Color(0xFF34D399), Color(0xFF60A5FA), Color(0xFFA78BFA))
            val c = center
            val r0 = size.minDimension * 0.34f
            for (i in 0 until 14) {
                val p = frac(loop.value + i * 0.137f)
                val ang = i * (2f * PI.toFloat() / 14f) + p * 0.8f
                val r = r0 + size.minDimension * 0.16f * p
                val pos = Offset(c.x + cos(ang) * r, c.y + sin(ang) * r)
                rotate(p * 540f + i * 40f, pos) {
                    drawRect(colors[i % colors.size].copy(alpha = (1f - p).coerceIn(0f, 1f)), topLeft = Offset(pos.x - 4f, pos.y - 7f), size = Size(8f, 14f))
                }
            }
        }
        "wow" -> Canvas(Modifier.matchParentSize()) {
            val p = 1f - loop.value
            val c = center
            for (i in 0 until 12) {
                val ang = i * (2f * PI.toFloat() / 12f)
                val r1 = size.minDimension * 0.40f
                val r2 = r1 + size.minDimension * (0.04f + 0.08f * p)
                drawLine(
                    Color(0xFFF59E0B).copy(alpha = 0.35f + 0.55f * p),
                    Offset(c.x + cos(ang) * r1, c.y + sin(ang) * r1), Offset(c.x + cos(ang) * r2, c.y + sin(ang) * r2),
                    strokeWidth = size.minDimension * 0.025f, cap = StrokeCap.Round,
                )
            }
        }
        "fire", "proud", "love", "hug" -> Canvas(Modifier.matchParentSize()) {
            val glow = when (k) { "fire" -> Color(0xFFFB923C); "proud" -> Color(0xFFFCD34D); else -> lk.light }
            val a = 0.28f + 0.14f * wave(loop.value)
            drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = a), Color.Transparent), center, size.minDimension * 0.52f), size.minDimension * 0.52f, center)
        }
        "coffee" -> Canvas(Modifier.matchParentSize()) {
            // بخار فنجان، بالای گوشهٔ پایین‌راست
            val baseX = size.width * 0.80f
            val baseY = size.height * 0.62f
            for (j in 0 until 2) {
                val p = frac(loop.value + j * 0.5f)
                val path = Path()
                val x0 = baseX + (j - 0.5f) * size.width * 0.05f
                val y0 = baseY - p * size.height * 0.16f
                path.moveTo(x0, y0)
                for (s in 1..6) {
                    val yy = y0 - s * size.height * 0.022f
                    val xx = x0 + sin((s + p * 6f) * 1.2f) * size.width * 0.018f
                    path.lineTo(xx, yy)
                }
                drawPath(path, Color.White.copy(alpha = 0.75f * bump(p)), style = Stroke(width = size.minDimension * 0.018f, cap = StrokeCap.Round))
            }
        }
    }
}

/**
 * یک ایموجی متحرک.
 *
 * جابه‌جایی‌های بلند (قلب‌هایی که بالا می‌روند، Zها، قطره‌ها) با [move] در مرحلهٔ
 * چیدمان انجام می‌شود، نه با translation لایه: لایه‌ای که هم شفاف است و هم جابه‌جا،
 * روی بوم نرم‌افزاری (اسکرین‌شات، بعضی گوشی‌های قدیمی) به قاب اولش بریده می‌شود.
 */
@Composable
private fun BoxScope.Prop(
    text: String,
    align: Alignment,
    fontSize: androidx.compose.ui.unit.TextUnit,
    dx: Dp = 0.dp,
    dy: Dp = 0.dp,
    move: (Density.() -> Offset)? = null,
    layer: GraphicsLayerScope.() -> Unit,
) {
    var m = Modifier.align(align).offset(dx, dy)
    if (move != null) m = m.absoluteOffset { move(this).let { IntOffset(it.x.roundToInt(), it.y.roundToInt()) } }
    Text(text, fontSize = fontSize, modifier = m.graphicsLayer(layer))
}

@Composable
private fun BoxScope.FrontProps(k: String, loop: State<Float>, size: Dp, emoji: androidx.compose.ui.unit.TextUnit, small: androidx.compose.ui.unit.TextUnit) {
    val u = size / 100f
    when (k) {
        "hi" -> Prop("👋", Alignment.TopEnd, emoji, dx = -u * 2, dy = u * 10) {
            transformOrigin = TransformOrigin(0.2f, 0.9f)
            rotationZ = 24f * wave(loop.value * 2f)
        }
        "love" -> {
            val hearts = listOf("❤️", "💕", "💖")
            hearts.forEachIndexed { i, h ->
                Prop(h, Alignment.BottomEnd, if (i == 0) emoji else small, dx = -u * 10, dy = -u * 26, move = {
                    val p = frac(loop.value + i / 3f)
                    Offset(sin(p * 2f * PI.toFloat() + i) * u.toPx() * 7f - i * u.toPx() * 8f, -p * u.toPx() * 52f)
                }) {
                    val p = frac(loop.value + i / 3f)
                    alpha = (1f - p) * (p * 5f).coerceAtMost(1f)
                    val s = 0.6f + 0.6f * p; scaleX = s; scaleY = s
                }
            }
        }
        "celebrate" -> {
            Prop("🎉", Alignment.TopStart, emoji, dx = u * 2, dy = u * 4) { rotationZ = -18f + 12f * wave(loop.value) }
            Prop("✨", Alignment.TopEnd, small, dx = -u * 6, dy = u * 6) { val s = 0.4f + 0.6f * abs(wave(loop.value)); scaleX = s; scaleY = s }
        }
        "fire" -> {
            Prop("🔥", Alignment.BottomStart, emoji, dx = u * 4, dy = -u * 16) {
                transformOrigin = TransformOrigin(0.5f, 1f)
                val s = 0.9f + 0.22f * abs(wave(loop.value * 3f)); scaleX = s; scaleY = s
            }
            Prop("🔥", Alignment.BottomEnd, emoji, dx = -u * 4, dy = -u * 16) {
                transformOrigin = TransformOrigin(0.5f, 1f)
                val s = 0.9f + 0.22f * abs(wave(loop.value * 3f + 0.4f)); scaleX = s; scaleY = s
            }
            Prop("🔥", Alignment.TopEnd, small, dx = -u * 10, dy = u * 4) {
                transformOrigin = TransformOrigin(0.5f, 1f)
                val s = 0.8f + 0.3f * abs(wave(loop.value * 2f + 0.2f)); scaleX = s; scaleY = s
            }
        }
        "proud" -> {
            Prop("🏅", Alignment.BottomEnd, emoji, dx = -u * 4, dy = -u * 18) {
                transformOrigin = TransformOrigin(0.5f, 0f)
                rotationZ = 14f * wave(loop.value)
            }
            listOf(Triple(Alignment.TopStart, 6, 0f), Triple(Alignment.TopEnd, -8, 0.33f), Triple(Alignment.CenterStart, 0, 0.66f)).forEach { (al, d, ph) ->
                Prop("✨", al, small, dx = u * d, dy = u * 6) {
                    val s = wave(loop.value + ph).coerceAtLeast(0f); scaleX = s; scaleY = s
                }
            }
        }
        "cheer" -> {
            Prop("💪", Alignment.CenterEnd, emoji, dx = u * 2, dy = u * 6) {
                transformOrigin = TransformOrigin(0.2f, 0.9f)
                rotationZ = -12f + 22f * abs(sin(PI.toFloat() * loop.value))
            }
            Prop("⭐", Alignment.TopStart, small, dx = u * 8, dy = u * 6) { val s = 0.5f + 0.5f * abs(wave(loop.value)); scaleX = s; scaleY = s }
        }
        "thinking" -> {
            Prop("💭", Alignment.TopEnd, emoji, dx = u * 2, dy = -u * 2) { translationY = u.toPx() * 3f * wave(loop.value) }
            Prop("؟", Alignment.TopEnd, small, dx = -u * 7, dy = u * 1, move = { Offset(0f, u.toPx() * 3f * wave(loop.value)) }) {
                alpha = bump(frac(loop.value * 1.0f))
            }
        }
        "wow" -> {
            Prop("😮", Alignment.TopEnd, emoji, dx = -u * 2, dy = u * 4) { val s = 1f + 0.15f * (1f - loop.value); scaleX = s; scaleY = s }
            Prop("❗", Alignment.TopStart, small, dx = u * 8, dy = u * 6) { rotationZ = -15f + 10f * wave(loop.value * 2f) }
        }
        "sleepy" -> repeat(3) { i ->
            Text(
                "Z",
                fontSize = small * (0.7f + 0.25f * i),
                fontWeight = FontWeight.Black,
                color = Color(0xFF6366F1),
                modifier = Modifier.align(Alignment.TopEnd).offset(-u * 22, u * 26)
                    .absoluteOffset {
                        val p = frac(loop.value + i / 3f)
                        IntOffset((p * u.toPx() * 16f).roundToInt(), (-p * u.toPx() * 26f).roundToInt())
                    }
                    .graphicsLayer { alpha = bump(frac(loop.value + i / 3f)) },
            )
        }
        "coffee" -> Prop("☕", Alignment.BottomEnd, emoji, dx = -u * 6, dy = -u * 16) { rotationZ = 4f * wave(loop.value) }
        "oops" -> {
            Prop("💦", Alignment.TopStart, small, dx = u * 12, dy = u * 10, move = { Offset(0f, frac(loop.value) * u.toPx() * 12f) }) {
                alpha = 1f - frac(loop.value)
            }
            Prop("🙈", Alignment.BottomEnd, emoji, dx = -u * 4, dy = -u * 16) { rotationZ = 8f * wave(loop.value * 2f) }
        }
        "study" -> {
            Prop("📚", Alignment.BottomStart, emoji, dx = u * 4, dy = -u * 16) { rotationZ = -6f }
            Prop("✏️", Alignment.BottomEnd, emoji, dx = -u * 4, dy = -u * 18) {
                translationX = u.toPx() * 4f * wave(loop.value * 2f)
                rotationZ = 10f * wave(loop.value * 2f)
            }
        }
        "hug" -> {
            Prop("🤗", Alignment.TopEnd, emoji, dx = -u * 2, dy = u * 4) { rotationZ = 8f * wave(loop.value) }
            for (i in 0 until 2) {
                Prop("💗", Alignment.Center, small, move = {
                    val ang = 2f * PI.toFloat() * loop.value + i * PI.toFloat()
                    Offset(cos(ang) * u.toPx() * 42f, sin(ang) * u.toPx() * 30f)
                }) {
                    val ang = 2f * PI.toFloat() * loop.value + i * PI.toFloat()
                    alpha = 0.6f + 0.4f * sin(ang).coerceAtLeast(0f)
                }
            }
        }
    }
}

/* ============================== کاغذرنگی تمام‌صفحه ============================== */

private class Bit(val x: Float, val vx: Float, val vy: Float, val spin: Float, val rot: Float, val w: Float, val h: Float, val color: Color, val sway: Float)

/** با هر عدد تازهٔ [trigger] یک بار کاغذرنگی از بالای صفحه می‌بارد. لمس را نمی‌گیرد. */
@Composable
fun ConfettiBurst(trigger: Int, modifier: Modifier = Modifier) {
    if (trigger <= 0) return
    val prog = remember(trigger) { Animatable(0f) }
    LaunchedEffect(trigger) { prog.animateTo(1f, tween(2600, easing = LinearEasing)) }
    val bits = remember(trigger) {
        val rnd = Random(trigger * 7919)
        val colors = listOf(Color(0xFFF472B6), Color(0xFFFBBF24), Color(0xFF34D399), Color(0xFF60A5FA), Color(0xFFA78BFA), Color(0xFFFB7185))
        List(72) {
            Bit(
                x = rnd.nextFloat(), vx = (rnd.nextFloat() - 0.5f) * 0.35f, vy = 0.35f + rnd.nextFloat() * 0.5f,
                spin = (rnd.nextFloat() - 0.5f) * 4f, rot = rnd.nextFloat() * 360f,
                w = 9f + rnd.nextFloat() * 8f, h = 14f + rnd.nextFloat() * 10f, color = colors[it % colors.size], sway = rnd.nextFloat() * 6f,
            )
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val p = prog.value
        if (p >= 1f) return@Canvas
        val fade = if (p > 0.8f) (1f - p) / 0.2f else 1f
        for (b in bits) {
            val t = p * 1.6f
            val x = (b.x + b.vx * t) * size.width + sin(t * 5f + b.sway) * 18f
            val y = -40f + (b.vy * t + 0.55f * t * t) * size.height
            if (y > size.height + 40f) continue
            rotate(b.rot + b.spin * 360f * t, Offset(x, y)) {
                drawRect(b.color.copy(alpha = fade), topLeft = Offset(x - b.w / 2f, y - b.h / 2f), size = Size(b.w, b.h))
            }
        }
    }
}
