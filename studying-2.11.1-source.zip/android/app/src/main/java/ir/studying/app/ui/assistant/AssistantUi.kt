@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package ir.studying.app.ui.assistant

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import ir.studying.app.R
import ir.studying.app.core.Api
import ir.studying.app.core.Assistant
import ir.studying.app.core.Fmt
import ir.studying.app.core.IranTime
import ir.studying.app.core.StudyReportMath
import ir.studying.app.core.Store
import ir.studying.app.core.boolish
import ir.studying.app.core.fa
import ir.studying.app.core.int
import ir.studying.app.core.intOrNull
import ir.studying.app.core.objects
import ir.studying.app.core.str
import ir.studying.app.core.strings
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro
import ir.studying.app.ui.components.ProgressRow
import ir.studying.app.ui.theme.brandGradient
import ir.studying.app.ui.theme.courseColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/*
 * رابط دستیار هوشمند: دکمهٔ شناور جغد در خانه + صفحهٔ گفت‌وگو.
 *
 * صفحهٔ گفت‌وگو عمداً پوششی داخل همان پنجرهٔ اپ است، نه Dialog: کیبورد و
 * لبه‌به‌لبه دقیقاً مثل صفحهٔ پیام‌ها رفتار می‌کنند و دکمهٔ برگشت فقط آن را می‌بندد.
 *
 * ۲.۹: پس‌زمینهٔ زنده، استیکرهای جغد، ری‌اکشن روی پیام کاربر، نوشتهٔ «الان دارم
 * چه کار می‌کنم»، کارت نتیجهٔ کارهای روی گوشی و کارت خطای خودمانی با کد پیگیری.
 */

private const val KEY_BUBBLE_DAY = "assistant_bubble_day"

private val GradeColors = listOf(
    listOf(Color(0xFFFB7185), Color(0xFFE11D48)),
    listOf(Color(0xFFFBBF24), Color(0xFFF97316)),
    listOf(Color(0xFF4ADE9F), Color(0xFF10B981)),
    listOf(Color(0xFF38BDF8), Color(0xFF2563EB)),
)
private val Good = Color(0xFF10B981)
private val Bad = Color(0xFFE11D48)
private val Warn = Color(0xFFF59E0B)

private val DeviceTypes = setOf("set_goal", "timer", "alarm", "reminder", "ambient", "theme")

@Composable
private fun Rtl(content: @Composable () -> Unit) =
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, content = content)

@Composable
private fun Ltr(content: @Composable () -> Unit) =
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr, content = content)

/* ============================== جغد ============================== */

enum class OwlMood { IDLE, THINKING, SLEEPING }

/** جغدِ اپ در یک دایره؛ گاهی پلک می‌زند، موقع فکر کردن می‌نویسد و وقتی سهمیه تمام شده خواب است. */
@Composable
fun OwlAvatar(size: Dp, modifier: Modifier = Modifier, mood: OwlMood = OwlMood.IDLE) {
    var blink by remember { mutableStateOf(false) }
    LaunchedEffect(mood) {
        blink = false
        if (mood != OwlMood.IDLE) return@LaunchedEffect
        try {
            while (true) {
                delay(2300L + Random.nextLong(2700L))
                blink = true; delay(140); blink = false
                if (Random.nextInt(4) == 0) { delay(170); blink = true; delay(120); blink = false }
            }
        } finally {
            blink = false
        }
    }
    val primary = MaterialTheme.colorScheme.primary
    val bg = remember(primary) { Brush.radialGradient(listOf(lerp(primary, Color.White, 0.55f), primary)) }
    Box(modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        // تصویر جغد پایین قاب نشسته؛ کمی بزرگ‌تر و پایین‌تر کشیده می‌شود تا صورتش وسط دایره بیفتد.
        val img = Modifier.requiredSize(size * 1.3f).offset(y = size * 0.09f)
        when (mood) {
            OwlMood.THINKING -> Image(painterResource(R.drawable.char_owl_studying), null, img, contentScale = ContentScale.Fit)
            // جغد خواب پایین و کمی چپِ تصویر دراز کشیده؛ قابش جدا تنظیم شده تا سرش وسط دایره باشد.
            OwlMood.SLEEPING -> Image(
                painterResource(R.drawable.char_owl_sleeping), null,
                Modifier.requiredSize(size * 1.15f).absoluteOffset(x = size * 0.06f, y = -size * 0.13f),
                contentScale = ContentScale.Fit,
            )
            OwlMood.IDLE -> {
                Image(painterResource(R.drawable.char_owl_idle), null, img.alpha(if (blink) 0f else 1f), contentScale = ContentScale.Fit)
                Image(painterResource(R.drawable.char_owl_blink), null, img.alpha(if (blink) 1f else 0f), contentScale = ContentScale.Fit)
            }
        }
    }
}

/* ============================== دکمهٔ شناور خانه ============================== */

@Composable
fun AssistantFab(modifier: Modifier = Modifier) {
    val status by Assistant.status.collectAsState()
    LaunchedEffect(Unit) { Assistant.refreshStatus() }

    // وقتی قرص تایمر پایین صفحه پیداست، جغد کمی بالاتر می‌نشیند.
    var timerVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            timerVisible = Pomodoro.state.value.running || Chrono.running
            delay(1000)
        }
    }
    val lift by animateDpAsState(if (timerVisible) 58.dp else 0.dp, label = "owlLift")

    // سلام کوتاه، روزی یک بار.
    var bubble by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(status.enabled) {
        if (!status.enabled) return@LaunchedEffect
        val day = IranTime.todayIso()
        if (Store.getString(KEY_BUBBLE_DAY) == day) return@LaunchedEffect
        delay(1400)
        bubble = greetLine(status.name)
        Store.putString(KEY_BUBBLE_DAY, day)
        delay(7000)
        bubble = null
    }

    AnimatedVisibility(
        visible = status.enabled,
        modifier = modifier.padding(bottom = lift),
        enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = 380f)) + fadeIn(),
        exit = scaleOut() + fadeOut(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedVisibility(
                visible = bubble != null,
                enter = fadeIn() + expandHorizontally(),
                exit = fadeOut() + shrinkHorizontally(),
            ) {
                GreetBubble(bubble.orEmpty()) { bubble = null; Assistant.openChat() }
            }
            OwlFab(sleeping = status.exhausted) { bubble = null; Assistant.openChat() }
        }
    }
}

private fun greetLine(name: String): String {
    val h = Calendar.getInstance(IranTime.ZONE).get(Calendar.HOUR_OF_DAY)
    return when (h) {
        in 5..11 -> "صبح بخیر رفیق! ☀️ یه پومودوروی صبحگاهی بزنیم؟"
        in 12..16 -> "سلام سلام! 👋 $name اینجاست؛ گزارش امروزت رو بگم؟"
        in 17..20 -> "عصر بخیر! 🌇 چندتا فلش‌کارت با هم مرور کنیم؟"
        else -> "شب بخیر! 🌙 بگم امروز چقدر ترکوندی؟"
    }
}

@Composable
private fun GreetBubble(text: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 4.dp, bottomStart = 18.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.35f)),
        shadowElevation = 6.dp,
        modifier = Modifier.padding(bottom = 22.dp).widthIn(max = 230.dp),
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurface,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
        )
    }
}

@Composable
private fun OwlFab(sleeping: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.45f, stiffness = 700f), label = "owlPress")
    val t = rememberInfiniteTransition(label = "owl")
    val bob by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "pulse")
    val primary = MaterialTheme.colorScheme.primary
    Box(
        Modifier.padding(start = 4.dp, end = 14.dp, top = 6.dp, bottom = 12.dp).size(74.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(60.dp)
                .graphicsLayer {
                    val s = 1f + 0.34f * pulse
                    scaleX = s; scaleY = s
                    alpha = (1f - pulse) * 0.42f
                }
                .background(primary, CircleShape)
        )
        Box(
            Modifier
                .graphicsLayer {
                    translationY = -bob * 4.dp.toPx()
                    scaleX = press; scaleY = press
                }
                .shadow(10.dp, CircleShape)
                .border(2.5.dp, Color.White.copy(alpha = 0.92f), CircleShape)
                .clickable(interaction, indication = null) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                }
                .semantics { contentDescription = "دستیار هوشمند" },
        ) {
            OwlAvatar(60.dp, mood = if (sleeping) OwlMood.SLEEPING else OwlMood.IDLE)
        }
        Box(
            Modifier
                .align(Alignment.TopStart)
                .graphicsLayer { translationY = -bob * 4.dp.toPx() }
                .size(24.dp)
                .shadow(3.dp, CircleShape)
                .background(MaterialTheme.colorScheme.surface, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text(if (sleeping) "💤" else "✨", fontSize = 12.sp) }
    }
}

/* ============================== صفحهٔ گفت‌وگو ============================== */

@Composable
fun AssistantOverlay() {
    val open by Assistant.open.collectAsState()
    BackHandler(enabled = open) { Assistant.close() }
    // مبدأ بزرگ‌شدن: گوشهٔ پایین‌چپ، همان‌جا که جغد نشسته.
    val origin = TransformOrigin(0.12f, 0.92f)
    AnimatedVisibility(
        visible = open,
        enter = fadeIn(tween(200)) + scaleIn(tween(280, easing = FastOutSlowInEasing), initialScale = 0.9f, transformOrigin = origin),
        exit = fadeOut(tween(170)) + scaleOut(tween(200), targetScale = 0.94f, transformOrigin = origin),
    ) {
        AssistantChat()
    }
}

@Composable
private fun AssistantChat() {
    val msgs by Assistant.messages.collectAsState()
    val sending by Assistant.sending.collectAsState()
    val status by Assistant.status.collectAsState()
    val stage by Assistant.stage.collectAsState()
    var input by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue("")) }
    val inputFocus = remember { FocusRequester() }
    var draftTick by remember { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val keyboard = LocalSoftwareKeyboardController.current
    val haptic = LocalHapticFeedback.current
    val canWrite = status.enabled && !status.exhausted

    // پیام‌هایی که از قبل بودند انیمیشن ورود ندارند؛ فقط تازه‌ها می‌پرند و جشن می‌گیرند.
    val initial = remember { msgs.map { it.id }.toHashSet() }
    var confetti by remember { mutableIntStateOf(0) }
    val lastId = msgs.lastOrNull()?.id
    LaunchedEffect(lastId) {
        val last = msgs.lastOrNull() ?: return@LaunchedEffect
        if (last.id in initial) return@LaunchedEffect
        when (last.role) {
            Assistant.Role.BOT -> {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                if (last.sticker == "celebrate" || last.sticker == "proud") confetti++
            }
            Assistant.Role.ERROR -> haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            Assistant.Role.USER -> {}
        }
    }

    val count = 1 + msgs.size + (if (sending) 1 else 0)
    var firstScroll by remember { mutableStateOf(true) }
    LaunchedEffect(msgs.size, sending) {
        if (count <= 0) return@LaunchedEffect
        val last = msgs.lastOrNull()
        when {
            firstScroll -> list.scrollToItem(count - 1, 100_000)
            // جواب تازه: از اول پیام نشان داده می‌شود تا کارت گزارش از بالا خوانده شود.
            !sending && last?.role == Assistant.Role.BOT -> list.animateScrollToItem(count - 1)
            else -> list.animateScrollToItem(count - 1, 100_000)
        }
        firstScroll = false
    }

    fun submit(text: String) {
        if (text.isBlank() || sending || !canWrite) return
        Assistant.send(text)
        input = TextFieldValue("")
    }

    /** میان‌برهایی که جزئیات شخصی دارند (ساعت زنگ، متن تسک) فقط پیش‌نویس می‌شوند تا کاربر عوضشان کند. */
    fun draft(text: String) {
        if (!canWrite) return
        input = TextFieldValue(text, TextRange(text.length))
        draftTick++
    }
    LaunchedEffect(draftTick) {
        if (draftTick == 0) return@LaunchedEffect
        runCatching { inputFocus.requestFocus() }
        keyboard?.show()
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize()) {
            ChatBackdrop()
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                ChatHeader(
                    status = status,
                    sending = sending,
                    stage = stage,
                    canClear = msgs.isNotEmpty(),
                    onClear = { confirmClear = true },
                    onClose = { keyboard?.hide(); Assistant.close() },
                )
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(
                        state = list,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        item(key = "greet") {
                            if (msgs.isEmpty()) {
                                WelcomeHero(status, enabled = canWrite && !sending, sleeping = !canWrite, onDraft = { draft(it) }) { submit(it) }
                            } else {
                                BotRow(mood = if (canWrite) OwlMood.IDLE else OwlMood.SLEEPING) {
                                    Bubble(mine = false) { RichText(status.greeting.ifBlank { defaultGreeting(status.name) }) }
                                }
                            }
                        }
                        items(msgs, key = { it.id }) { m ->
                            val fresh = m.id !in initial
                            Appear(fresh, fromEnd = m.role == Assistant.Role.USER) {
                                when (m.role) {
                                    Assistant.Role.USER -> UserRow(m)
                                    Assistant.Role.BOT -> BotMessage(m, busy = sending, fresh = fresh)
                                    Assistant.Role.ERROR -> ErrorRow(m, busy = sending)
                                }
                            }
                        }
                        if (sending) item(key = "typing") { TypingRow(status.name, stage) }
                    }
                    ImeFollower(list, count)
                }
                val lastBot = msgs.lastOrNull()?.takeIf { it.role == Assistant.Role.BOT }
                AnimatedVisibility(visible = !sending && canWrite && lastBot != null && lastBot.suggestions.isNotEmpty()) {
                    SuggestionStrip(lastBot?.suggestions.orEmpty()) { submit(it) }
                }
                if (!canWrite) QuotaNote(status)
                InputBar(
                    value = input,
                    onChange = { v -> input = if (v.text.length <= 1500) v else v.copy(text = v.text.take(1500), selection = TextRange(1500)) },
                    focus = inputFocus,
                    enabled = canWrite,
                    canSend = canWrite && !sending && input.text.isNotBlank(),
                    placeholder = if (canWrite) "به ${status.name} بگو…" else "فعلاً نمی‌شه پیام فرستاد",
                    onSend = { submit(input.text) },
                )
            }
            ConfettiBurst(confetti)
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("گفت‌وگوی تازه؟") },
            text = { Text("پیام‌های این گفت‌وگو از روی گوشی پاک می‌شوند. گزارش‌ها، تسک‌ها و فلش‌کارت‌هایت دست نمی‌خورند.") },
            confirmButton = { TextButton(onClick = { Assistant.clear(); confirmClear = false }) { Text("شروع تازه") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("انصراف") } },
        )
    }
}

/** پس‌زمینهٔ زنده: چند لکهٔ رنگی نرم که خیلی آرام جابه‌جا می‌شوند. */
@Composable
private fun ChatBackdrop() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "bg")
    val a = t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing)), label = "drift")
    val c1 = cs.primary
    val c2 = cs.tertiary
    val c3 = cs.secondary
    Canvas(Modifier.fillMaxSize()) {
        val k = a.value * 2f * PI.toFloat()
        val w = size.width
        val h = size.height
        fun blob(c: Color, alpha: Float, x: Float, y: Float, r: Float) {
            val center = Offset(x, y)
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = alpha), Color.Transparent), center, r), r, center)
        }
        blob(c1, 0.16f, w * (0.18f + 0.08f * sin(k)), h * (0.16f + 0.05f * cos(k)), w * 0.62f)
        blob(c2, 0.11f, w * (0.88f + 0.06f * cos(k)), h * (0.52f + 0.06f * sin(k)), w * 0.6f)
        blob(c3, 0.09f, w * (0.30f + 0.07f * cos(k + 1f)), h * (0.94f + 0.03f * sin(k)), w * 0.55f)
        // چند نقطهٔ ریز چشمک‌زن، مثل آسمان شب مطالعه
        for (i in 0 until 14) {
            val px = ((i * 0.618f) % 1f) * w
            val py = ((i * 0.377f + 0.11f) % 1f) * h
            val tw = (sin(k * 2f + i * 1.7f) + 1f) / 2f
            drawCircle(c1.copy(alpha = 0.06f + 0.10f * tw), radius = 2.2f + 1.6f * tw, center = Offset(px, py))
        }
    }
}

/** وقتی کیبورد باز می‌شود، آخر گفت‌وگو جلوی چشم بماند. جدا شده تا فقط همین‌جا با انیمیشن کیبورد بازسازی شود. */
@Composable
private fun ImeFollower(list: LazyListState, count: Int) {
    val imeShown = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    LaunchedEffect(imeShown) {
        if (imeShown && count > 0) {
            delay(120)
            list.animateScrollToItem(count - 1, 100_000)
        }
    }
}

private fun defaultGreeting(name: String) =
    "سلام رفیق! 🦉 من $name‌ام، رفیق درس‌خونیت.\nگزارش کارت رو می‌گم، باهات فلش‌کارت مرور می‌کنم، تایمر و زنگ و تسک‌هات رو برات تنظیم می‌کنم و هر جای اپ بخوای می‌برمت."

private val defaultStarters = listOf("گزارش امروزم", "یه پومودورو ۲۵ دقیقه‌ای شروع کن", "بیا فلش‌کارت مرور کنیم", "تسک‌های امروزم چیه؟")

private class Quick(val emoji: String, val label: String, val prompt: String, val sendNow: Boolean)

/**
 * کارهای سریع زیر سلام اول. آن‌هایی که جزئیات شخصی دارند (ساعت زنگ، متن تسک، مقدار هدف)
 * فقط در جعبهٔ پیام پیش‌نویس می‌شوند تا کاربر قبل از فرستادن عوضشان کند.
 */
private val quickActions = listOf(
    Quick("⏱️", "پومودورو", "یه پومودوروی ۲۵ دقیقه‌ای شروع کن", true),
    Quick("🎧", "صدای بارون", "صدای بارون پخش کن", true),
    Quick("⏰", "بیدارم کن", "فردا ساعت ۶:۳۰ بیدارم کن", false),
    Quick("✅", "تسک تازه", "یه تسک برای امروز اضافه کن: ", false),
    Quick("🌙", "تم تیره", "تم اپ رو تیره کن", true),
    Quick("🎯", "هدف روزانه", "هدف روزانه‌م رو ۴ ساعت کن", false),
)

@Composable
private fun ChatHeader(status: Assistant.Status, sending: Boolean, stage: String?, canClear: Boolean, onClear: () -> Unit, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(color = cs.surface.copy(alpha = 0.9f), shadowElevation = 2.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = "بستن") }
            Box {
                OwlAvatar(
                    44.dp,
                    mood = when {
                        sending -> OwlMood.THINKING
                        !status.enabled || status.exhausted -> OwlMood.SLEEPING
                        else -> OwlMood.IDLE
                    },
                )
                if (status.enabled && !status.exhausted) {
                    val t = rememberInfiniteTransition(label = "online")
                    val p = t.animateFloat(0.75f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dot")
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .size(13.dp)
                            .graphicsLayer { scaleX = p.value; scaleY = p.value }
                            .border(2.dp, cs.surface, CircleShape)
                            .background(if (sending) Warn else Good, CircleShape)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(status.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                val sub = when {
                    sending -> "داره برات می‌نویسه… ✍️"
                    !status.enabled -> "فعلاً در دسترس نیست"
                    status.exhausted -> "سهمیهٔ امروز تموم شد 😴"
                    status.limit > 0 && status.remaining >= 0 -> "آنلاین · ${status.remaining.fa()} پیام تا فردا"
                    else -> "آنلاین · رفیق درس‌خونیت ✨"
                }
                Crossfade(targetState = sub, label = "sub") { s ->
                    Text(s, style = MaterialTheme.typography.labelSmall, color = if (sending) cs.primary else cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (canClear) {
                IconButton(onClick = onClear) { Icon(Icons.Rounded.AddComment, contentDescription = "گفت‌وگوی تازه", tint = cs.primary) }
            }
        }
    }
}

/* ============================== ردیف‌ها و حباب‌ها ============================== */

/** ورود نرم پیام تازه: از پایین و از سمت گوینده، با کمی فنر. */
@Composable
private fun Appear(fresh: Boolean, fromEnd: Boolean, content: @Composable () -> Unit) {
    val a = remember { Animatable(if (fresh) 0f else 1f) }
    LaunchedEffect(Unit) { if (a.value < 1f) a.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 360f)) }
    Box(
        Modifier.graphicsLayer {
            val v = a.value
            alpha = v.coerceIn(0f, 1f)
            translationY = (1f - v) * 26.dp.toPx()
            val s = 0.9f + 0.1f * v
            scaleX = s; scaleY = s
            transformOrigin = TransformOrigin(if (fromEnd) 1f else 0f, 1f)
        }
    ) { content() }
}

/** جغد سمت چپ، محتوا کنارش (مثل پیام طرف مقابل در گفت‌وگوهای اپ). */
@Composable
private fun BotRow(mood: OwlMood = OwlMood.IDLE, avatar: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Ltr {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            if (avatar) OwlAvatar(32.dp, mood = mood) else Spacer(Modifier.width(32.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start, content = content)
            Spacer(Modifier.width(18.dp))
        }
    }
}

@Composable
private fun UserRow(m: Assistant.Msg) {
    val initialReaction = remember(m.id) { m.reaction }
    val pad by animateDpAsState(if (m.reaction != null) 15.dp else 0.dp, spring(dampingRatio = 0.6f), label = "rxPad")
    Ltr {
        Row(Modifier.fillMaxWidth().padding(start = 52.dp), horizontalArrangement = Arrangement.End) {
            Box(Modifier.padding(bottom = pad)) {
                Bubble(mine = true) {
                    val g = m.fcGraded
                    if (g != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(Brush.linearGradient(GradeColors[g.second.coerceIn(0, 3)]), CircleShape))
                            Spacer(Modifier.width(6.dp))
                            Text(m.text, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Text(m.text, style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 23.sp))
                    }
                }
                m.reaction?.let { r ->
                    ReactionBadge(r, animate = r != initialReaction, modifier = Modifier.align(Alignment.BottomStart).offset(x = (-6).dp, y = 15.dp))
                }
            }
        }
    }
}

/** ری‌اکشن دانا روی پیام کاربر؛ وقتی تازه می‌رسد با فنر و چند جرقه می‌پرد. */
@Composable
private fun ReactionBadge(emoji: String, animate: Boolean, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val pop = remember { Animatable(if (animate) 0f else 1f) }
    val burst = remember { Animatable(1f) }
    LaunchedEffect(emoji) {
        if (!animate) return@LaunchedEffect
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        pop.snapTo(0f)
        burst.snapTo(0f)
        launch { burst.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        pop.animateTo(1f, spring(dampingRatio = 0.32f, stiffness = 520f))
    }
    val sparks = listOf(Color(0xFFF472B6), Color(0xFFFBBF24), Color(0xFF34D399), Color(0xFF60A5FA))
    Box(modifier.size(30.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.requiredSize(70.dp)) {
            val b = burst.value
            if (b <= 0f || b >= 1f) return@Canvas
            drawCircle(cs.primary.copy(alpha = (1f - b) * 0.5f), radius = size.minDimension * (0.16f + 0.28f * b), style = Stroke(width = 2.5f + 3f * (1f - b)))
            for (i in 0 until 8) {
                val ang = i * (2f * PI.toFloat() / 8f) + 0.3f
                val r = size.minDimension * (0.2f + 0.27f * b)
                drawCircle(sparks[i % sparks.size].copy(alpha = 1f - b), radius = 1.5f + 3.5f * (1f - b), center = Offset(center.x + cos(ang) * r, center.y + sin(ang) * r))
            }
        }
        Box(
            Modifier
                .size(30.dp)
                .graphicsLayer {
                    val s = pop.value
                    scaleX = s; scaleY = s
                    rotationZ = (1f - pop.value.coerceIn(0f, 1f)) * -35f
                }
                .shadow(3.dp, CircleShape)
                .background(cs.surface, CircleShape)
                .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
                .semantics { contentDescription = "ری‌اکشن $emoji" },
            contentAlignment = Alignment.Center,
        ) { Text(emoji, fontSize = 15.sp) }
    }
}

/** حباب؛ باید در بافت چپ‌به‌راست صدا زده شود تا گوشهٔ تیز سمت درست بیفتد. محتوا راست‌به‌چپ است. */
@Composable
private fun Bubble(mine: Boolean, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = if (mine) RoundedCornerShape(22.dp, 6.dp, 22.dp, 22.dp) else RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp)
    val bg = if (mine) Brush.linearGradient(listOf(lerp(cs.primaryContainer, cs.primary, 0.12f), lerp(cs.primaryContainer, cs.tertiaryContainer, 0.7f)))
    else SolidColor(cs.surface.copy(alpha = 0.94f))
    Column(
        Modifier
            .widthIn(max = 320.dp)
            .shadow(if (mine) 2.dp else 1.dp, shape, ambientColor = cs.primary.copy(alpha = 0.3f), spotColor = cs.primary.copy(alpha = 0.3f))
            .clip(shape)
            .background(bg)
            .border(1.dp, if (mine) cs.primary.copy(alpha = 0.18f) else cs.outlineVariant.copy(alpha = 0.45f), shape)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        val scope = this
        Rtl { scope.content() }
    }
}

@Composable
private fun RichText(text: String) {
    val accent = MaterialTheme.colorScheme.primary
    val rich = remember(text, accent) { richText(text, accent) }
    Text(rich, style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 24.sp))
}

/** مارک‌داون خیلی سبک: **پررنگ**، تیترهای #، و فهرست‌های - یا *. */
private fun richText(src: String, accent: Color): AnnotatedString = buildAnnotatedString {
    val lines = src.replace("\r", "").trim().split("\n")
    val heading = Regex("^#{1,6}\\s+")
    val bullet = Regex("^\\s*[-*•]\\s+")
    lines.forEachIndexed { i, raw ->
        var line = raw.trimEnd()
        val h = heading.find(line)
        if (h != null) line = line.substring(h.range.last + 1)
        val b = bullet.find(line)
        if (b != null) {
            pushStyle(SpanStyle(color = accent, fontWeight = FontWeight.Bold))
            append("• ")
            pop()
            line = line.substring(b.range.last + 1)
        }
        if (h != null) pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
        val parts = line.replace("`", "").replace("__", "").split("**")
        val balanced = parts.size % 2 == 1
        parts.forEachIndexed { idx, p ->
            if (idx % 2 == 1) {
                if (balanced || idx != parts.lastIndex) {
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                    append(p)
                    pop()
                } else {
                    append("**"); append(p)
                }
            } else append(p)
        }
        if (h != null) pop()
        if (i < lines.lastIndex) append('\n')
    }
}

@Composable
private fun BotMessage(m: Assistant.Msg, busy: Boolean, fresh: Boolean) {
    BotRow(mood = if (m.sticker == "sleepy") OwlMood.SLEEPING else OwlMood.IDLE) {
        if (m.text.isNotBlank()) Bubble(mine = false) { RichText(m.text) }
        m.sticker?.let { k ->
            if (m.text.isNotBlank()) Spacer(Modifier.height(2.dp))
            OwlSticker(k, 124.dp, fresh = fresh)
        }
        m.cards.forEach { c ->
            Spacer(Modifier.height(8.dp))
            when (c.str("type")) {
                "report" -> ReportCard(c)
                "flashcard" -> FlashcardCard(m, c, graded = m.graded[c.int("card_id")], busy = busy)
            }
        }
        if (m.actions.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            ActionList(m)
        }
    }
}

@Composable
private fun ErrorRow(m: Assistant.Msg, busy: Boolean) {
    val cs = MaterialTheme.colorScheme
    val sticker = when (m.errorKind) {
        "limit", "off" -> "sleepy"
        "slow" -> "coffee"
        else -> "oops"
    }
    BotRow(avatar = false) {
        Surface(
            shape = RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp),
            color = lerp(cs.surface, cs.error, 0.07f),
            border = BorderStroke(1.dp, cs.error.copy(alpha = 0.25f)),
            shadowElevation = 1.dp,
        ) {
            Rtl {
                Row(Modifier.widthIn(max = 330.dp).padding(start = 8.dp, end = 14.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OwlSticker(sticker, 66.dp, caption = false, fresh = true)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f, fill = false)) {
                        Text(m.text, style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 23.sp), color = cs.onSurface)
                        if (m.retry) {
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { Assistant.retry() },
                                enabled = !busy,
                                shape = CircleShape,
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("دوباره بفرست", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        m.errorRef?.let {
                            Spacer(Modifier.height(6.dp))
                            Text("کد پیگیری: $it", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant.copy(alpha = 0.7f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingRow(name: String, stage: String?) {
    var secs by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1000); secs++ } }
    val t = rememberInfiniteTransition(label = "typing")
    val phase = t.animateFloat(0f, 3.6f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "phase")
    val sweep = t.animateFloat(-0.4f, 1.4f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "sweep")
    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val text = stage ?: when {
        secs >= 45 -> "هنوز روشم! کار بزرگیه ولی ولش نمی‌کنم 💪"
        secs >= 18 -> "یه کم بیشتر طول کشید؛ الان می‌رسه ⏳"
        secs >= 6 -> "دارم اطلاعاتت رو نگاه می‌کنم… 🔎"
        else -> "$name داره فکر می‌کنه…"
    }
    BotRow(mood = OwlMood.THINKING) {
        Bubble(mine = false) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ltr {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        repeat(3) { i ->
                            Box(
                                Modifier
                                    .padding(horizontal = 2.dp)
                                    .size(7.dp)
                                    .graphicsLayer {
                                        val x = phase.value - i * 0.6f
                                        val k = if (x in 0f..1f) sin(PI * x).toFloat() else 0f
                                        translationY = -k * 5.dp.toPx()
                                        alpha = 0.35f + 0.65f * k
                                    }
                                    .background(primary, CircleShape)
                            )
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Crossfade(targetState = text, label = "stage") { s ->
                    Text(s, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
            // نوار براقِ «در حال کار»
            Canvas(Modifier.width(150.dp).height(4.dp).clip(CircleShape)) {
                drawRect(primary.copy(alpha = 0.12f))
                val x = sweep.value * size.width
                drawRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, primary.copy(alpha = 0.75f), Color.Transparent), startX = x - size.width * 0.35f, endX = x + size.width * 0.35f),
                )
            }
        }
    }
}

/* ============================== نتیجهٔ کارها ============================== */

private fun hm(h: Int, m: Int) = (h.toString().padStart(2, '0') + ":" + m.toString().padStart(2, '0')).fa()

private fun deviceTitle(a: Assistant.Action): Pair<String, String> {
    val r = a.raw
    return when (a.type) {
        "timer" -> if (r.str("op") == "stop") "⏸️" to "توقف تایمر" else "⏱️" to a.label.ifBlank { "تایمر مطالعه" }
        "alarm" -> "⏰" to ("زنگ " + hm(r.int("hour"), r.int("minute")) + r.str("label").takeIf { it.isNotBlank() && it != "بیدارباش" }?.let { " · $it" }.orEmpty())
        "reminder" -> if (r.optBoolean("enabled", true)) "🔔" to ("یادآور روزانه" + (if (r.has("hour")) " · " + hm(r.int("hour"), r.int("minute")) else ""))
        else "🔕" to "خاموش کردن یادآور"
        "ambient" -> if (r.str("op") == "stop") "🔇" to "قطع صدای محیطی" else "🎧" to "صدای محیطی"
        "theme" -> "🎨" to "تم اپ"
        "set_goal" -> "🎯" to buildList {
            if (a.daily > 0) add("هدف روزانه " + Fmt.minutes(a.daily))
            if (a.weekly > 0) add("هفتگی " + Fmt.minutes(a.weekly))
        }.joinToString(" · ").ifBlank { "هدف مطالعه" }
        else -> "✨" to a.label
    }
}

@Composable
private fun ActionList(m: Assistant.Msg) {
    val device = m.actions.withIndex().filter { it.value.type in DeviceTypes }
    val links = m.actions.withIndex().filter { it.value.type == "navigate" || it.value.type == "link" }
    Rtl {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (device.isNotEmpty()) DeviceReceipt(m, device)
            if (links.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    links.forEach { (i, a) -> LinkChip(m, i, a) }
                }
            }
        }
    }
}

/** کارت «انجام شد»: هر کار روی گوشی یک ردیف، با تیک سبز، علامت هشدار یا چرخندهٔ در حال انجام. */
@Composable
private fun DeviceReceipt(m: Assistant.Msg, rows: List<IndexedValue<Assistant.Action>>) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = cs.surface.copy(alpha = 0.96f),
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.5f)),
        shadowElevation = 1.dp,
        modifier = Modifier.widthIn(max = 320.dp),
    ) {
        Column(Modifier.padding(vertical = 4.dp)) {
            rows.forEachIndexed { n, (i, a) ->
                if (n > 0) HorizontalDivider(Modifier.padding(horizontal = 12.dp), color = cs.outlineVariant.copy(alpha = 0.35f))
                val (emoji, title) = deviceTitle(a)
                val out = m.outcomes[i]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { Assistant.runAction(m, i) }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(34.dp).background(cs.primary.copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Text(emoji, fontSize = 17.sp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val detail = when {
                            out == null -> null
                            out.ok == null -> "در حال انجام…"
                            out.text.isNotBlank() -> out.text
                            else -> null
                        }
                        if (detail != null) {
                            Text(
                                detail + if (out?.ok == false && out.fixScreen.isNotBlank()) " · بزن تا درستش کنیم" else "",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (out?.ok == false) Warn else cs.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    StatusMark(out?.ok, known = out != null)
                }
            }
        }
    }
}

@Composable
private fun StatusMark(ok: Boolean?, known: Boolean) {
    if (!known) return
    if (ok == null) {
        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        return
    }
    val s = remember { Animatable(0.4f) }
    LaunchedEffect(ok) { s.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = 500f)) }
    Box(
        Modifier
            .size(24.dp)
            .graphicsLayer { scaleX = s.value; scaleY = s.value }
            .background(if (ok) Good else Warn, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (ok) Icon(Icons.Rounded.Check, contentDescription = "انجام شد", tint = Color.White, modifier = Modifier.size(16.dp))
        else Text("!", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
    }
}

@Composable
private fun LinkChip(m: Assistant.Msg, idx: Int, a: Assistant.Action) {
    val cs = MaterialTheme.colorScheme
    val out = m.outcomes[idx]
    val failed = out?.ok == false
    Surface(
        onClick = { Assistant.runAction(m, idx) },
        shape = CircleShape,
        color = if (failed) Warn.copy(alpha = 0.12f) else cs.primary.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, if (failed) Warn.copy(alpha = 0.45f) else cs.primary.copy(alpha = 0.32f)),
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "↖ " + a.label.ifBlank { "باز کردن صفحه" },
                style = MaterialTheme.typography.labelLarge,
                color = if (failed) Warn else cs.primary,
            )
            when (out?.ok) {
                true -> { Spacer(Modifier.width(6.dp)); Text("✓", color = Good, fontWeight = FontWeight.Black) }
                false -> { Spacer(Modifier.width(6.dp)); Text("دوباره بزن", style = MaterialTheme.typography.labelSmall, color = Warn) }
                null -> {}
            }
        }
    }
}

/* ============================== شروع گفت‌وگو و ورودی ============================== */

private fun starterEmoji(s: String): String = when {
    "گزارش" in s -> "📊"
    "پومودورو" in s || "تایمر" in s || "کرنومتر" in s -> "⏱️"
    "فلش" in s || "مرور" in s -> "🃏"
    "زنگ" in s || "بیدار" in s -> "⏰"
    "صدا" in s || "بارون" in s -> "🎧"
    "تم" in s -> "🎨"
    "تسک" in s || "کار" in s -> "✅"
    "هدف" in s -> "🎯"
    "تمرکز" in s -> "🔒"
    "امکانات" in s || "اپ" in s || "راهنما" in s -> "💡"
    else -> "✨"
}

/** سلام اول: استیکر بزرگ، معرفی و چند کار آماده. */
@Composable
private fun WelcomeHero(status: Assistant.Status, enabled: Boolean, sleeping: Boolean, onDraft: (String) -> Unit, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Rtl {
        Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            OwlSticker(if (sleeping) "sleepy" else "hi", 148.dp, fresh = true)
            Spacer(Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = cs.surface.copy(alpha = 0.94f),
                border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.5f)),
                shadowElevation = 1.dp,
            ) {
                Box(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    RichText(status.greeting.ifBlank { defaultGreeting(status.name) })
                }
            }
            if (status.proto >= 2 && !sleeping) {
                Spacer(Modifier.height(12.dp))
                FlowRow(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    quickActions.forEach { q ->
                        Surface(
                            onClick = { if (q.sendNow) onPick(q.prompt) else onDraft(q.prompt) },
                            enabled = enabled,
                            shape = CircleShape,
                            color = cs.surface.copy(alpha = 0.9f),
                            border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.25f)),
                        ) {
                            Text(q.emoji + " " + q.label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Starters(status.suggestions.ifEmpty { defaultStarters }, enabled = enabled, onPick = onPick)
        }
    }
}

@Composable
private fun Starters(items: List<String>, enabled: Boolean, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.take(4).chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { s ->
                    Surface(
                        onClick = { onPick(s) },
                        enabled = enabled,
                        shape = RoundedCornerShape(20.dp),
                        color = cs.surface.copy(alpha = 0.92f),
                        border = BorderStroke(1.dp, Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.45f), cs.tertiary.copy(alpha = 0.25f)))),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
                            Box(
                                Modifier.size(34.dp).background(Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.22f), cs.tertiary.copy(alpha = 0.16f))), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) { Text(starterEmoji(s), fontSize = 17.sp) }
                            Spacer(Modifier.height(6.dp))
                            Text(s, style = MaterialTheme.typography.labelLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SuggestionStrip(items: List<String>, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items.forEach { s ->
            Surface(
                onClick = { onPick(s) },
                shape = CircleShape,
                color = cs.surface.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.32f)),
                shadowElevation = 1.dp,
            ) {
                Text(
                    starterEmoji(s) + " " + s,
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.primary,
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun QuotaNote(status: Assistant.Status) {
    val cs = MaterialTheme.colorScheme
    Surface(color = cs.surfaceVariant.copy(alpha = 0.7f), modifier = Modifier.fillMaxWidth()) {
        Text(
            if (!status.enabled) "${status.name} فعلاً در دسترس نیست؛ کمی بعد دوباره سر بزن 🙏"
            else "سهمیهٔ امروزت با ${status.name} تموم شد 😴 فردا دوباره بیدار می‌شم!",
            style = MaterialTheme.typography.labelMedium,
            color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun InputBar(
    value: TextFieldValue,
    onChange: (TextFieldValue) -> Unit,
    focus: FocusRequester,
    enabled: Boolean,
    canSend: Boolean,
    placeholder: String,
    onSend: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val field = remember { MutableInteractionSource() }
    val focused by field.collectIsFocusedAsState()
    val ready by animateFloatAsState(if (canSend) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "send")
    Surface(color = cs.surface.copy(alpha = 0.95f), shadowElevation = 8.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            TextField(
                value = value,
                onValueChange = onChange,
                enabled = enabled,
                interactionSource = field,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus)
                    .heightIn(min = 50.dp)
                    .border(1.dp, if (focused) cs.primary.copy(alpha = 0.55f) else cs.outlineVariant.copy(alpha = 0.35f), RoundedCornerShape(25.dp)),
                placeholder = { Text(placeholder, maxLines = 1) },
                maxLines = 5,
                shape = RoundedCornerShape(25.dp),
                textStyle = MaterialTheme.typography.bodyLarge,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (canSend) onSend() }),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    focusedContainerColor = cs.surfaceVariant.copy(alpha = 0.55f),
                    unfocusedContainerColor = cs.surfaceVariant.copy(alpha = 0.55f),
                    disabledContainerColor = cs.surfaceVariant.copy(alpha = 0.3f),
                ),
            )
            Spacer(Modifier.width(8.dp))
            val sendBg = if (canSend) brandGradient() else SolidColor(cs.onSurface.copy(alpha = 0.10f))
            Box(
                Modifier
                    .padding(bottom = 1.dp)
                    .size(48.dp)
                    .graphicsLayer {
                        val s = 0.88f + 0.12f * ready
                        scaleX = s; scaleY = s
                    }
                    .shadow((6f * ready).dp, CircleShape)
                    .clip(CircleShape)
                    .background(sendBg)
                    .clickable(enabled = canSend) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSend()
                    }
                    .semantics { contentDescription = "ارسال" },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Send,
                    contentDescription = null,
                    tint = if (canSend) cs.onPrimary else cs.onSurface.copy(alpha = 0.35f),
                    modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = -20f * (1f - ready) },
                )
            }
        }
    }
}

/* ============================== کارت گزارش ============================== */

private fun shortMin(m: Int): String {
    if (m < 60) return "${m.fa()} دقیقه"
    val h = m / 60
    val r = m % 60
    return if (r == 0) "${h.fa()} ساعت" else "${h.fa()}:${r.toString().padStart(2, '0').fa()}"
}

private fun colorOf(key: String): Color {
    if (key.startsWith("#")) runCatching { return Color(android.graphics.Color.parseColor(key)) }
    return courseColor(key)
}

@Composable
private fun ReportCard(c: JSONObject) {
    val cs = MaterialTheme.colorScheme
    val total = c.int("total_minutes")
    val days = c.int("days").coerceAtLeast(1)
    val sessions = c.int("sessions")
    val goal = c.int("goal_minutes")
    val delta = c.intOrNull("delta_percent")
    Rtl {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = cs.surface,
            border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.55f)),
            shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column {
                Box(Modifier.fillMaxWidth().background(brandGradient()).padding(16.dp)) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📊", fontSize = 17.sp)
                            Spacer(Modifier.width(6.dp))
                            Text(c.str("title"), style = MaterialTheme.typography.titleSmall, color = cs.onPrimary, modifier = Modifier.weight(1f))
                            Text(c.str("subtitle"), style = MaterialTheme.typography.labelSmall, color = cs.onPrimary.copy(alpha = 0.85f), maxLines = 1)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (total > 0) Fmt.minutes(total) else "هنوز مطالعه‌ای ثبت نشده",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            color = cs.onPrimary,
                        )
                        if (delta != null && c.int("prev_minutes") > 0) {
                            Spacer(Modifier.height(6.dp))
                            val up = delta >= 0
                            Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.22f)) {
                                Text(
                                    (if (up) "▲ " else "▼ ") + kotlin.math.abs(delta).fa() + "٪ " + (if (up) "بیشتر" else "کمتر") + " از دورهٔ قبل",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = cs.onPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                )
                            }
                        }
                        if (goal > 0) {
                            Spacer(Modifier.height(10.dp))
                            val frac = (total.toFloat() / goal).coerceIn(0f, 1f)
                            val anim by animateFloatAsState(frac, tween(800, easing = FastOutSlowInEasing), label = "goal")
                            Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))) {
                                Box(Modifier.fillMaxWidth(anim.coerceAtLeast(0.02f)).height(8.dp).clip(CircleShape).background(Color.White))
                            }
                            Spacer(Modifier.height(5.dp))
                            val pct = if (goal > 0) (total * 100f / goal).roundToInt() else 0
                            Text(
                                (if (pct >= 100) "🎉 " else "") + "${pct.fa()}٪ از هدف " + Fmt.minutes(goal),
                                style = MaterialTheme.typography.labelMedium,
                                color = cs.onPrimary,
                            )
                        }
                    }
                }
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (days > 1) {
                            Pill("${c.int("active_days").fa()} از ${days.fa()}", "روز فعال", Modifier.weight(1f))
                            Pill(shortMin(c.int("avg_minutes")), "میانگین روز فعال", Modifier.weight(1f))
                            Pill(sessions.fa(), "پارت", Modifier.weight(1f))
                        } else {
                            Pill(sessions.fa(), "پارت", Modifier.weight(1f))
                            val first = c.str("first_start")
                            val last = c.str("last_end")
                            if (first.isNotBlank()) Pill(Fmt.hm(first), "شروع", Modifier.weight(1f))
                            if (last.isNotBlank()) Pill(Fmt.hm(last), "پایان", Modifier.weight(1f))
                            if (first.isBlank() && last.isBlank() && sessions > 0) Pill(shortMin(total / sessions), "میانگین پارت", Modifier.weight(1f))
                        }
                    }

                    val daily = (c.optJSONArray("daily") ?: JSONArray()).objects()
                    if (days > 1 && daily.size > 1 && total > 0) {
                        Spacer(Modifier.height(14.dp))
                        DailyBars(daily, c.optJSONObject("best_day")?.str("date").orEmpty())
                    }

                    val courses = (c.optJSONArray("courses") ?: JSONArray()).objects()
                    if (courses.isNotEmpty() && total > 0) {
                        Spacer(Modifier.height(12.dp))
                        SmallTitle("سهم درس‌ها")
                        val max = courses.maxOf { it.int("minutes") }.coerceAtLeast(1)
                        courses.forEach { co ->
                            ProgressRow(
                                icon = co.str("icon").ifBlank { "📘" },
                                name = co.str("name"),
                                minutes = co.int("minutes"),
                                maxMinutes = max,
                                // درصد اول می‌آید تا جهت متن (و جای علامت ٪) در همهٔ ردیف‌ها یکسان بماند.
                                valueText = co.int("share").fa() + "٪ · " + shortMin(co.int("minutes")),
                                color = colorOf(co.str("color")),
                            )
                        }
                    }

                    val tests = c.optJSONObject("tests")
                    if (tests != null && tests.int("total") + tests.int("correct") + tests.int("wrong") + tests.int("blank") > 0) {
                        Spacer(Modifier.height(10.dp))
                        SmallTitle("تست‌ها")
                        TestsRow(tests)
                    }

                    val act = c.optJSONObject("activities")
                    val actChips = buildList {
                        if (act != null) {
                            if (act.int("video") > 0) add("🎬 ویدئو " + shortMin(act.int("video")))
                            if (act.int("test") > 0) add("✍️ تست " + shortMin(act.int("test")))
                            if (act.int("book") > 0) add("📗 کتاب " + shortMin(act.int("book")))
                            if (act.int("review") > 0) add("🔁 مرور " + shortMin(act.int("review")))
                            if (act.int("learn") > 0) add("🧠 یادگیری " + shortMin(act.int("learn")))
                        }
                    }
                    val extra = buildList {
                        c.optJSONObject("tasks")?.let { if (it.int("total") > 0) add("✅ تسک ${it.int("done").fa()} از ${it.int("total").fa()}") }
                        c.optJSONObject("flashcards")?.let { if (it.int("cards") > 0) add("🃏 ${it.int("cards").fa()} کارت مرور شد") }
                        c.optJSONObject("focus")?.let { if (it.int("sessions") > 0) add("🔒 تمرکز " + shortMin(it.int("minutes"))) }
                        c.str("wakeup").takeIf { it.isNotBlank() }?.let { add("⏰ بیداری " + Fmt.hm(it)) }
                        c.optJSONObject("best_day")?.let { if (it.int("minutes") > 0) add("🏆 بهترین روز: " + it.str("label")) }
                        c.intOrNull("streak")?.let { if (it > 0) add("🔥 استریک ${it.fa()} روز") }
                    }
                    if (actChips.isNotEmpty() || extra.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            (actChips + extra).forEach { InfoChip(it) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 2.dp),
    )
}

@Composable
private fun Pill(value: String, label: String, modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = accent.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f)),
    ) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleSmall, color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MiniStat(value: String, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleSmall, color = color, maxLines = 1, softWrap = false)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun InfoChip(text: String) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)) {
        Text(text, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

/** نمودار ستونی کوچک روزها؛ بهترین روز پررنگ‌تر. */
@Composable
private fun DailyBars(daily: List<JSONObject>, bestDate: String) {
    val cs = MaterialTheme.colorScheme
    val max = daily.maxOf { it.int("minutes") }.coerceAtLeast(1)
    val short = daily.size <= 7
    val today = IranTime.todayIso()
    Column(Modifier.fillMaxWidth()) {
        // روزها از راست به چپ (اول دوره سمت راست)، مثل تقویم فارسی.
        Row(
            Modifier.fillMaxWidth().height(70.dp),
            horizontalArrangement = Arrangement.spacedBy(if (short) 8.dp else 2.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            daily.forEach { d ->
                val m = d.int("minutes")
                val frac = if (m <= 0) 0f else (m.toFloat() / max).coerceIn(0.06f, 1f)
                val anim by animateFloatAsState(frac, tween(700, easing = FastOutSlowInEasing), label = "bar")
                val strong = d.str("date") == bestDate || d.str("date") == today
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(if (m <= 0) 0.04f else anim)
                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 2.dp, bottomEnd = 2.dp))
                            .background(
                                if (m <= 0) SolidColor(cs.onSurface.copy(alpha = 0.10f))
                                else if (strong) Brush.verticalGradient(listOf(cs.secondary, cs.primary))
                                else SolidColor(cs.primary.copy(alpha = 0.45f))
                            )
                    )
                }
            }
        }
        if (short) {
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                daily.forEach { d ->
                    Text(
                        d.str("weekday").take(1).ifBlank { "·" },
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        } else {
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                Text(daily.first().str("label"), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Text(daily.last().str("label"), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun TestsRow(t: JSONObject) {
    val cs = MaterialTheme.colorScheme
    val percent = t.optDouble("percent", Double.NaN)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pill(t.int("total").fa(), "تست", Modifier.weight(1f))
        if (!percent.isNaN()) Pill(StudyReportMath.formatPercent(percent) + "٪", "درصد (با منفی)", Modifier.weight(1.3f))
        Surface(
            modifier = Modifier.weight(1.7f),
            shape = RoundedCornerShape(16.dp),
            color = cs.surfaceVariant.copy(alpha = 0.6f),
        ) {
            Row(Modifier.padding(horizontal = 4.dp, vertical = 9.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                MiniStat(t.int("correct").fa(), "درست", Good)
                MiniStat(t.int("wrong").fa(), "غلط", cs.error)
                MiniStat(t.int("blank").fa(), "نزده", cs.onSurfaceVariant)
            }
        }
    }
}

/* ============================== کارت فلش‌کارت ============================== */

@Composable
private fun FlashcardCard(m: Assistant.Msg, c: JSONObject, graded: Int?, busy: Boolean) {
    val cs = MaterialTheme.colorScheme
    val cardId = c.int("card_id")
    val type = c.str("card_type").ifBlank { "basic" }
    val choices = (c.optJSONArray("choices") ?: JSONArray()).strings()
    val correct = (c.optJSONArray("correct") ?: JSONArray()).strings().toSet()
    var revealed by rememberSaveable(m.id, cardId) { mutableStateOf(false) }
    var chosen by rememberSaveable(m.id, cardId) { mutableStateOf<String?>(null) }
    val open = revealed || graded != null
    Rtl {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = lerp(cs.background, cs.primary, 0.06f),
            border = BorderStroke(1.5.dp, cs.primary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(c.str("deck_icon").ifBlank { "🃏" }, fontSize = 16.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        c.str("deck_name").ifBlank { "فلش‌کارت" },
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    if (c.boolish("is_new")) {
                        Surface(shape = CircleShape, color = cs.tertiary.copy(alpha = 0.18f)) {
                            Text("تازه", style = MaterialTheme.typography.labelSmall, color = cs.tertiary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                val image = c.str("image")
                if (image.isNotBlank()) {
                    AsyncImage(
                        model = Api.mediaUrl(image),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 190.dp).clip(RoundedCornerShape(16.dp)),
                    )
                    Spacer(Modifier.height(10.dp))
                }
                val audio = c.str("audio")
                if (audio.isNotBlank()) {
                    AudioButton(Api.mediaUrl(audio))
                    Spacer(Modifier.height(8.dp))
                }
                val front = c.str("front")
                if (front.isNotBlank()) {
                    Text(
                        front,
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center,
                        lineHeight = 28.sp,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    )
                }

                if (type == "mcq" && choices.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    choices.forEach { ch ->
                        val ok = ch in correct
                        val tint = when {
                            !open -> cs.surface
                            ok -> Good.copy(alpha = 0.2f)
                            chosen == ch -> Bad.copy(alpha = 0.18f)
                            else -> cs.surface
                        }
                        val shape = RoundedCornerShape(14.dp)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(shape)
                                .background(tint)
                                .border(1.dp, if (open && ok) Good.copy(alpha = 0.5f) else cs.outlineVariant.copy(alpha = 0.6f), shape)
                                .clickable(enabled = !open) { chosen = ch; revealed = true }
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val mark = when {
                                open && ok -> "✓"
                                open && chosen == ch -> "✗"
                                else -> "○"
                            }
                            Text(mark, color = if (open && ok) Good else if (open && chosen == ch) Bad else cs.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text(ch, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                if (open) {
                    val main: String
                    val sub: String
                    when (type) {
                        "mcq" -> { main = ""; sub = c.str("back") }
                        "cloze" -> { main = c.str("revealed").ifBlank { c.str("answer") }; sub = "پاسخ: " + c.str("answer") }
                        else -> { main = c.str("back").ifBlank { c.str("answer") }; sub = c.str("note") }
                    }
                    if (main.isNotBlank() || sub.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Surface(shape = RoundedCornerShape(16.dp), color = Good.copy(alpha = 0.10f), border = BorderStroke(1.dp, Good.copy(alpha = 0.3f)), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                if (main.isNotBlank()) Text(main, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center)
                                if (sub.isNotBlank()) {
                                    if (main.isNotBlank()) Spacer(Modifier.height(4.dp))
                                    Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                when {
                    graded != null -> {
                        val g = graded.coerceIn(0, 3)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(Brush.linearGradient(GradeColors[g]), CircleShape))
                            Spacer(Modifier.width(6.dp))
                            Text("ثبت شد: " + Assistant.gradeLabels[g], style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                        }
                    }
                    !open -> {
                        Text(
                            if (type == "mcq") "یک گزینه رو بزن یا جوابت رو بنویس ✍️" else "جوابت رو بنویس تا بررسی کنم، یا خودت پاسخ رو ببین 👇",
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { revealed = true },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(16.dp),
                        ) { Text("نمایش پاسخ", fontWeight = FontWeight.Bold) }
                    }
                    else -> {
                        val suggested = if (type == "mcq" && chosen != null) (if (chosen in correct) 2 else 0) else -1
                        Text(
                            "چقدر خوب یادت بود؟",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (0..3).forEach { q ->
                                GradeButton(
                                    label = Assistant.gradeLabels[q],
                                    colors = GradeColors[q],
                                    highlight = q == suggested,
                                    enabled = !busy,
                                    modifier = Modifier.weight(1f),
                                ) { Assistant.gradeCard(m, cardId, q) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GradeButton(label: String, colors: List<Color>, highlight: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(15.dp)
    Box(
        modifier
            .height(46.dp)
            .alpha(if (enabled) 1f else 0.5f)
            .then(if (highlight) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), shape) else Modifier)
            .padding(if (highlight) 3.dp else 0.dp)
            .clip(shape)
            .background(Brush.linearGradient(colors))
            .clickable(enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun AudioButton(url: String?) {
    if (url.isNullOrBlank()) return
    val ctx = LocalContext.current
    var playing by remember(url) { mutableStateOf(false) }
    var failed by remember(url) { mutableStateOf(false) }
    var player by remember(url) { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(url) {
        onDispose {
            runCatching { player?.reset(); player?.release() }
            player = null
        }
    }
    AssistChip(
        onClick = {
            val p = player
            if (playing && p != null) {
                runCatching { p.pause() }
                playing = false
            } else if (p != null) {
                runCatching { p.start(); playing = true }.onFailure { failed = true }
            } else {
                failed = false
                runCatching {
                    val mp = MediaPlayer()
                    mp.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    mp.setDataSource(ctx, Uri.parse(url))
                    mp.setOnPreparedListener { it.start(); playing = true }
                    mp.setOnCompletionListener { playing = false }
                    mp.setOnErrorListener { _, _, _ -> playing = false; failed = true; true }
                    player = mp
                    mp.prepareAsync()
                }.onFailure { failed = true }
            }
        },
        label = { Text(if (failed) "پخش نشد؛ دوباره بزن" else if (playing) "در حال پخش" else "پخش صدا") },
        leadingIcon = { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = null) },
    )
}
