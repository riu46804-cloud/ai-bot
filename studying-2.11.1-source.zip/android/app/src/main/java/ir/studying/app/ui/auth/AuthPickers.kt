@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.studying.app.data.Edu

/**
 * انتخابگرهای مرحلهٔ پروفایلِ ثبت‌نام.
 *
 * چرا جدا شد: صفحهٔ ثبت‌نام باید کوتاه بماند. با ردیف افقی آواتار و منوی
 * بازشوی پایه، همهٔ سؤال‌ها در یک صفحه جا می‌شوند و کاربر مجبور نیست میان
 * ده‌ها چیپ اسکرول کند.
 */

@Composable
fun AvatarPickerRow(
    selectedKey: String?,
    photoUri: android.net.Uri?,
    onSelect: (String) -> Unit,
    onGallery: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("کاراکترت را انتخاب کن", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Text(
                "بچرخان یا از گالری عکس بگذار",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(8.dp))
        /*
         * نسخهٔ ۲.۹: به‌جای ردیف دایره‌های کوچک، چرخ‌فلک سه‌بعدی کوتاه. با
         * ایستادن روی هر کاراکتر همان انتخاب می‌شود؛ عکس گالری هم همان‌جا
         * روی صحنه پیش‌نمایش داده می‌شود و بعد از ساخت حساب آپلود می‌شود.
         */
        ir.studying.app.ui.profile.AvatarStudio(
            selectedKey = selectedKey,
            onSelect = onSelect,
            photoUri = photoUri,
            onGallery = onGallery,
            compact = true,
        )
    }
}

/** دو گزینهٔ کنار هم — برای جنسیت، جایی که فقط دو انتخاب هست. */
@Composable
fun AuthChoiceRow(
    label: String,
    items: List<Edu.Item>,
    selected: String?,
    onSelect: (String) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach { it ->
                val on = it.key == selected
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(
                        if (on) 1.5.dp else 1.dp,
                        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    ),
                    modifier = Modifier.weight(1f).clickable { onSelect(it.key) },
                ) {
                    Text(
                        (it.emoji + " " + it.label).trim(),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(vertical = 11.dp, horizontal = 10.dp),
                    )
                }
            }
        }
    }
}

/**
 * منوی بازشو — پایهٔ تحصیلی سیزده گزینه دارد و به شکل چیپ نصف صفحه را می‌گرفت.
 */
@Composable
fun AuthDropdown(
    label: String,
    items: List<Edu.Item>,
    selected: String?,
    placeholder: String = "انتخاب کن",
    onSelect: (String) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val current = items.firstOrNull { it.key == selected }
    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Box {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                border = BorderStroke(
                    if (current != null) 1.5.dp else 1.dp,
                    if (current != null) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outlineVariant,
                ),
                modifier = Modifier.fillMaxWidth().clickable { open = true },
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        current?.let { (it.emoji + " " + it.label).trim() } ?: placeholder,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (current != null) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(Icons.Rounded.ExpandMore, contentDescription = null)
                }
            }
            androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                items.forEach { it ->
                    DropdownMenuItem(
                        text = { Text((it.emoji + " " + it.label).trim()) },
                        onClick = { onSelect(it.key); open = false },
                    )
                }
            }
        }
    }
}
