package ir.studying.app.ui.community

import androidx.compose.runtime.Composable
import ir.studying.app.ui.feed.FeedScreen

/** تب اجتماع = شبکه اجتماعی کامل (سبک توییتر). */
@Composable
fun CommunityScreen() {
    FeedScreen()
}
