@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.community

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import ir.studying.app.R
import ir.studying.app.core.Api
import ir.studying.app.core.EmojiText
import ir.studying.app.core.Fmt
import ir.studying.app.core.Icon3D
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.data.GroupDetail
import ir.studying.app.data.GroupMember
import ir.studying.app.data.GroupMessage
import ir.studying.app.data.Reaction
import ir.studying.app.data.StudyGroup
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.components.SectionTitle
import ir.studying.app.ui.components.userColor
import ir.studying.app.ui.messages.AttachSheet
import ir.studying.app.ui.messages.ChatComposer
import ir.studying.app.ui.messages.ChatEmpty
import ir.studying.app.ui.messages.ChatKind
import ir.studying.app.ui.messages.ChatMedia
import ir.studying.app.ui.messages.ChatMusicPicker
import ir.studying.app.ui.messages.ChatStatus
import ir.studying.app.ui.messages.ChatSurface
import ir.studying.app.ui.messages.ChatSync
import ir.studying.app.ui.messages.ChatTopBar
import ir.studying.app.ui.messages.ImageViewerDialog
import ir.studying.app.ui.messages.MentionBar
import ir.studying.app.ui.messages.MenuAction
import ir.studying.app.ui.messages.OutMsg
import ir.studying.app.ui.messages.ReplyDraft
import ir.studying.app.ui.messages.ServerMsg
import ir.studying.app.ui.messages.SideFab
import ir.studying.app.ui.messages.StickerPickerSheet
import ir.studying.app.ui.messages.UiMsg
import ir.studying.app.ui.messages.UserProfileSheet
import ir.studying.app.ui.messages.restoreDeliveryDraft
import ir.studying.app.ui.messages.timelineChat
import ir.studying.app.ui.messages.SendState
import ir.studying.app.ui.messages.pendingMenu
import ir.studying.app.ui.messages.preview
import ir.studying.app.ui.messages.rememberChatController
import ir.studying.app.ui.messages.toUi
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.brandGradient
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.abs

class GroupsViewModel : ViewModel() {
    val groups = MutableStateFlow<List<StudyGroup>>(emptyList())
    val loading = MutableStateFlow(true)
    val detail = MutableStateFlow<GroupDetail?>(null)
    val messages = MutableStateFlow<List<GroupMessage>>(emptyList())
    val chatLoading = MutableStateFlow(true)
    val uploadPercent = MutableStateFlow<Int?>(null)
    /** Deleted here, not yet gone from the server's list. */
    val removed = MutableStateFlow<Set<Int>>(emptySet())
    /** Optimistic sending and reactions (Telegram style). */
    val sync = ChatSync(viewModelScope, { Store.session.value }) { Store.username ?: "" }
    private fun target(id: Int) = mapOf("group_id" to id.toString())

    fun refresh() {
        viewModelScope.launch {
            runCatching { StudyGroup.list(Api.arr(Api.get("group_list"))) }
                .onSuccess { groups.value = it; loading.value = false }.onFailure { loading.value = false }
        }
    }
    fun create(name: String, username: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { runCatching { Api.post("group_create", JSONObject().put("name", name).put("username", username)) }.onSuccess { onResult(null); refresh() }.onFailure { onResult(it.message ?: "خطا") } }
    }
    fun join(username: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { runCatching { Api.post("group_join", JSONObject().put("username", username)) }.onSuccess { onResult(null); refresh() }.onFailure { onResult(it.message ?: "خطا") } }
    }
    fun loadDetail(id: Int) { viewModelScope.launch { runCatching { GroupDetail.from(Api.obj(Api.get("group_detail", "id" to id.toString()))) }.onSuccess { detail.value = it } } }
    fun leave(id: Int, onDone: () -> Unit) { viewModelScope.launch { runCatching { Api.post("group_leave", JSONObject().put("group_id", id)) }; refresh(); onDone() } }
    fun deleteGroup(id: Int, onDone: () -> Unit) { viewModelScope.launch { runCatching { Api.get("group_delete", "id" to id.toString()) }; refresh(); onDone() } }
    fun kick(id: Int, username: String) {
        // The row leaves at once; the next detail load is the truth.
        detail.update { d -> if (d?.id == id) d.copy(members = d.members.filterNot { it.username == username }, memberCount = (d.memberCount - 1).coerceAtLeast(0)) else d }
        viewModelScope.launch { runCatching { Api.post("group_kick", JSONObject().put("group_id", id).put("username", username)) }.onFailure { AppSnack.show(it.message ?: "حذف عضو انجام نشد") }; loadDetail(id) }
    }
    fun rename(id: Int, name: String) { viewModelScope.launch { runCatching { Api.post("group_update", JSONObject().put("group_id", id).put("name", name)) }; loadDetail(id); refresh() } }

    private var activeChatId: Int? = null
    fun pollChat(id: Int) {
        if (activeChatId != id) {
            activeChatId = id; sync.clear(); messages.value = emptyList(); removed.value = emptySet(); chatLoading.value = true
        }
        val gen = sync.beginPoll()
        val session = Store.session.value
        viewModelScope.launch {
            runCatching { GroupMessage.list(Api.arr(Api.getForSession("group_chat", session, "group_id" to id.toString()))) }
                .onSuccess { list ->
                    val me = Store.username ?: ""
                    if (activeChatId != id || session != Store.session.value || !sync.publishPoll(gen, list.map { it.toUi(me, "m${it.id}", it.reactions) })) return@onSuccess
                    messages.value = list
                    chatLoading.value = false
                    if (removed.value.isNotEmpty()) {
                        val ids = list.mapTo(HashSet()) { it.id }
                        removed.update { r -> r.filterTo(HashSet()) { it in ids } }
                    }
                }
                .onFailure { chatLoading.value = false }
        }
    }

    /** Shows up at once with a clock; the server's id turns it into a tick. */
    fun sendChat(id: Int, text: String, replyTo: Int?, replySender: String?, replyPreview: String?, onErr: (String) -> Unit) {
        val t = text.trim(); if (t.isEmpty()) return
        val session = Store.session.value
        sync.queue(t, replyTo, replySender, replyPreview, afterId = lastId(), send = { o -> post(id, o, session) }, onErr = onErr, after = { pollChat(id) })
    }
    fun retry(id: Int, localId: Long, onErr: (String) -> Unit) {
        val session = Store.session.value
        sync.retry(localId, lastId(), send = { o -> post(id, o, session) }, onErr = onErr, after = { pollChat(id) })
    }
    fun discard(localId: Long) = sync.discard(localId)
    private fun lastId(): Int = messages.value.maxOfOrNull { it.id } ?: 0
    private suspend fun post(id: Int, o: OutMsg, session: ir.studying.app.core.SessionState): Int? {
        val b = JSONObject().put("group_id", id).put("message", o.text)
        if (o.replyTo != null) b.put("reply_to", o.replyTo)
        return ChatSync.idOf(Api.postForSession("group_chat", b, session))
    }

    fun react(gid: Int, msgId: Int, current: List<Reaction>, emoji: String) {
        sync.react(msgId, current, emoji, call = {
            Api.post("react", JSONObject().put("scope", "group").put("id", msgId).put("emoji", emoji))
        }, after = { pollChat(gid) })
    }

    fun deleteMsg(id: Int, msgId: Int, onErr: (String) -> Unit = {}) {
        removed.update { it + msgId }
        viewModelScope.launch {
            runCatching { Api.delete("group_chat", "group_id" to id.toString(), "id" to msgId.toString()) }
                .onFailure { removed.update { s -> s - msgId }; onErr(it.message ?: "حذف نشد") }
            pollChat(id)
        }
    }
    private fun sendMediaUri(ctx: Context, id: Int, type: String, uri: Uri, onErr: (String) -> Unit) {
        viewModelScope.launch { uploadPercent.value = 0; val e = ChatMedia.sendMedia(ctx, "group", target(id), type, uri, null) { uploadPercent.value = it }; uploadPercent.value = null; if (e != null) onErr(e); pollChat(id) }
    }
    fun sendImage(ctx: Context, id: Int, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, id, "image", uri, onErr)
    fun sendFile(ctx: Context, id: Int, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, id, "file", uri, onErr)
    fun sendMusicFile(ctx: Context, id: Int, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, id, "music", uri, onErr)
    fun sendMusic(id: Int, musicId: Int, onErr: (String) -> Unit) { viewModelScope.launch { ChatMedia.sendRef("group", target(id), "music", musicId = musicId)?.let(onErr); pollChat(id) } }
    fun sendSticker(id: Int, stickerId: Int, onErr: (String) -> Unit) { viewModelScope.launch { ChatMedia.sendRef("group", target(id), "sticker", stickerId = stickerId)?.let(onErr); pollChat(id) } }
}

private sealed class GRoute(val depth: Int) {
    object List : GRoute(0)
    data class Detail(val id: Int) : GRoute(1)
    data class Chat(val id: Int, val name: String) : GRoute(2)
}

@Composable
fun GroupsTab(vm: GroupsViewModel = viewModel(), initialGroupId: Int? = null, onExit: (() -> Unit)? = null) {
    var route by remember {
        mutableStateOf<GRoute>(
            if (initialGroupId != null) GRoute.Detail(initialGroupId) else GRoute.List,
        )
    }
    LaunchedEffect(Unit) { vm.refresh() }
    AnimatedContent(
        targetState = route,
        transitionSpec = {
            // RTL: a deeper page comes in from the left.
            val dir = if (targetState.depth >= initialState.depth) -1 else 1
            (slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 5 * dir } + fadeIn(tween(240)))
                .togetherWith(slideOutHorizontally(tween(220)) { -it / 8 * dir } + fadeOut(tween(160)))
        },
        label = "groupsRoute",
    ) { r ->
        when (r) {
            is GRoute.List -> GroupsList(vm, onOpen = { route = GRoute.Detail(it) }, onExit = onExit)
            is GRoute.Detail -> { BackHandler { route = GRoute.List }; GroupDetailScreen(vm, r.id, onBack = { route = GRoute.List }, onChat = { name -> route = GRoute.Chat(r.id, name) }) }
            is GRoute.Chat -> { BackHandler { route = GRoute.Detail(r.id) }; GroupChatScreen(r.id, r.name, onBack = { route = GRoute.Detail(r.id) }) }
        }
    }
}

/* ============================================================== list == */

@Composable
private fun GroupsList(vm: GroupsViewModel, onOpen: (Int) -> Unit, onExit: (() -> Unit)? = null) {
    val groups by vm.groups.collectAsState()
    val loading by vm.loading.collectAsState()
    var showCreate by remember { mutableStateOf(false) }
    var showJoin by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Refreshable(onRefresh = { vm.refresh() }) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp, top = 14.dp,
            bottom = 24.dp + LocalBottomBarPadding.current.calculateBottomPadding(),
        ), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (onExit != null) item(key = "exit") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(onClick = onExit, shape = CircleShape, color = cs.surfaceVariant.copy(alpha = 0.7f)) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "بازگشت", Modifier.padding(9.dp).size(20.dp), tint = cs.onSurface)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("پیام‌ها", style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant, fontWeight = FontWeight.Bold)
                }
            }
            item(key = "hero") { FadeSlideIn(0) { GroupsHero(groups.size, groups.sumOf { it.memberCount }, groups.count { it.isOwner }) } }
            item(key = "actions") {
                FadeSlideIn(1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ActionTile("✨", stringResource(R.string.groups_001), "گروه خودت رو راه بنداز", cs.primary, Modifier.weight(1f)) { showCreate = true }
                        ActionTile("🔗", stringResource(R.string.groups_016), "با شناسه‌ی گروه", Color(0xFF7C6CF2), Modifier.weight(1f)) { showJoin = true }
                    }
                }
            }
            when {
                loading && groups.isEmpty() -> items(3) { GroupCardSkeleton() }
                groups.isEmpty() -> item(key = "empty") {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        ChatEmpty("🤝", "هنوز عضو گروهی نیستی", "یه گروه بساز و دوستات رو دعوت کن، یا با شناسه‌ی یه گروه عضو شو",
                            actionLabel = "✨ ساخت اولین گروه", onAction = { showCreate = true })
                    }
                }
                else -> {
                    item(key = "title") { SectionTitle("گروه‌های من") }
                    itemsIndexed(groups, key = { _, g -> g.id }) { i, g -> FadeSlideIn(i + 2) { GroupCard(g) { onOpen(g.id) } } }
                }
            }
        }
    }
    if (showCreate) CreateGroupSheet(onDismiss = { showCreate = false }, onCreate = { n, u, done ->
        vm.create(n, u) { err -> AppSnack.show(err ?: "گروه ساخته شد ✅"); done(err == null); if (err == null) showCreate = false }
    })
    if (showJoin) JoinGroupSheet(onDismiss = { showJoin = false }, onJoin = { u, done ->
        vm.join(u) { err -> AppSnack.show(err ?: "عضو شدی 🎉"); done(err == null); if (err == null) showJoin = false }
    })
}

private fun androidx.compose.foundation.lazy.LazyListScope.items(count: Int, content: @Composable () -> Unit) {
    repeat(count) { i -> item(key = "sk$i") { content() } }
}

@Composable
private fun GroupsHero(count: Int, members: Int, owned: Int) {
    val cs = MaterialTheme.colorScheme
    val on = cs.onPrimary
    val t = rememberInfiniteTransition(label = "hero")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse), label = "heroDrift")
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(brandGradient())) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.12f), radius = size.minDimension * 0.62f,
                center = Offset(size.width * (0.08f + 0.06f * drift), size.height * 0.02f))
            drawCircle(Color.White.copy(alpha = 0.08f), radius = size.minDimension * 0.45f,
                center = Offset(size.width * (0.98f - 0.05f * drift), size.height * 1.02f))
            drawCircle(Color.White.copy(alpha = 0.10f), radius = size.minDimension * 0.08f,
                center = Offset(size.width * 0.45f, size.height * (0.2f + 0.1f * drift)))
        }
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.messages_screen_001), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = on)
                Spacer(Modifier.height(4.dp))
                Text("با دوستات هم‌مسیر شو؛ مطالعه‌ی هم رو ببینید و با هم جلو برید", style = MaterialTheme.typography.bodySmall, color = on.copy(alpha = 0.86f))
                Spacer(Modifier.height(12.dp))
                @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    HeroChip("💬", "${count.fa()} گروه", on)
                    HeroChip("🧑‍🎓", "${members.fa()} عضو", on)
                    if (owned > 0) HeroChip("👑", "${owned.fa()} مدیر", on)
                }
            }
            Spacer(Modifier.width(8.dp))
            HeroArt(drift)
        }
    }
}

@Composable
private fun HeroChip(emoji: String, text: String, on: Color) {
    Row(Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.2f)).padding(start = 6.dp, end = 10.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon3D(emoji, 18.dp)
        Spacer(Modifier.width(4.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = on, maxLines = 1, softWrap = false)
    }
}

/** Big handshake with a book and a sparkle orbiting it. */
@Composable
private fun HeroArt(drift: Float) {
    Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
        AnimatedEmoji("🤝", 74.dp, idle = true, repeatEveryMs = 3400)
        Box(Modifier.align(Alignment.TopStart).offset(x = (2 + 6 * drift).dp, y = (4 - 6 * drift).dp)) { Icon3D("📚", 28.dp) }
        Box(Modifier.align(Alignment.BottomEnd).offset(x = (-2 * drift).dp, y = (-4 * drift).dp)) { Icon3D("✨", 22.dp) }
    }
}

@Composable
private fun pressScale(interaction: MutableInteractionSource): Float {
    val pressed by interaction.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.965f else 1f, spring(dampingRatio = 0.5f, stiffness = 800f), label = "press")
    return s
}

@Composable
private fun ActionTile(emoji: String, title: String, subtitle: String, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val scale = pressScale(interaction)
    val haptic = LocalHapticFeedback.current
    var play by remember { mutableIntStateOf(0) }
    Surface(
        shape = RoundedCornerShape(24.dp), color = cs.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale },
    ) {
        Box(Modifier.background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.13f), Color.Transparent)))
            .clickable(interaction, indication = null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); play++; onClick() }) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(accent, lerp(accent, Color.Black, 0.28f)))), contentAlignment = Alignment.Center) {
                    AnimatedEmoji(emoji, 32.dp, playKey = play, burst = false)
                }
                Spacer(Modifier.height(10.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

private val groupEmojis = listOf("📚", "🚀", "🧠", "🎯", "🔥", "⭐", "🏆", "💡", "🎓", "📖", "✏️", "🧪", "🌱", "⚡")

private fun groupEmojiOf(key: String): String = groupEmojis[abs(key.hashCode()) % groupEmojis.size]

/** Group picture, or a 3D emoji on the group's own gradient. */
@Composable
internal fun GroupAvatar(avatar: String?, key: String, size: Dp) {
    val url = Api.mediaUrl(avatar)
    val shape = RoundedCornerShape(size * 0.34f)
    if (url != null) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(size).clip(shape))
    else {
        val c = userColor(key)
        Box(Modifier.size(size).clip(shape).background(Brush.linearGradient(listOf(lerp(c, Color.White, 0.12f), lerp(c, Color.Black, 0.32f)))),
            contentAlignment = Alignment.Center) {
            Icon3D(groupEmojiOf(key), size * 0.6f)
        }
    }
}

@Composable
private fun GroupCard(g: StudyGroup, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = userColor(g.username)
    val interaction = remember { MutableInteractionSource() }
    val scale = pressScale(interaction)
    val haptic = LocalHapticFeedback.current
    Surface(
        shape = RoundedCornerShape(24.dp), color = cs.surface, shadowElevation = 1.dp,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale },
    ) {
        Box(Modifier
            .background(Brush.horizontalGradient(listOf(Color.Transparent, c.copy(alpha = 0.14f))))
            .clickable(interaction, indication = null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                GroupAvatar(g.avatar, g.username, 56.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EmojiText(g.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        if (g.isOwner) { Spacer(Modifier.width(5.dp)); Icon3D("👑", 17.dp) }
                    }
                    Text("@${g.username}", style = MaterialTheme.typography.labelMedium, color = lerp(c, cs.onSurface, 0.35f), maxLines = 1)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MemberDots(g.username, g.memberCount)
                        Spacer(Modifier.width(6.dp))
                        Text("${g.memberCount.fa()} ${stringResource(R.string.groups_003)}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        if (!g.isOwner && g.ownerName.isNotBlank()) {
                            Text("  ·  مدیر: ${g.ownerName}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(32.dp).clip(CircleShape).background(c.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = lerp(c, cs.onSurface, 0.3f), modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

/** Overlapping coloured dots standing in for the members. */
@Composable
private fun MemberDots(seed: String, count: Int) {
    val n = count.coerceIn(1, 4)
    val bg = MaterialTheme.colorScheme.surface
    Box(Modifier.width((14 + (n - 1) * 9).dp).height(14.dp)) {
        repeat(n) { i ->
            Box(Modifier.offset(x = (i * 9).dp).size(14.dp).clip(CircleShape).background(bg).padding(1.5.dp)
                .clip(CircleShape).background(userColor(seed + i)))
        }
    }
}

@Composable
private fun GroupCardSkeleton() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "gsk")
    val a by t.animateFloat(0.35f, 0.8f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "gskA")
    Surface(shape = RoundedCornerShape(24.dp), color = cs.surface, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.4f))) {
        Row(Modifier.fillMaxWidth().padding(14.dp).graphicsLayer { alpha = a }, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(19.dp)).background(cs.surfaceVariant))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Box(Modifier.fillMaxWidth(0.55f).height(13.dp).clip(CircleShape).background(cs.surfaceVariant))
                Box(Modifier.fillMaxWidth(0.35f).height(10.dp).clip(CircleShape).background(cs.surfaceVariant))
                Box(Modifier.fillMaxWidth(0.45f).height(10.dp).clip(CircleShape).background(cs.surfaceVariant))
            }
        }
    }
}

/* ============================================================ detail == */

@Composable
private fun GroupDetailScreen(vm: GroupsViewModel, id: Int, onBack: () -> Unit, onChat: (String) -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val detail by vm.detail.collectAsState()
    LaunchedEffect(id) { vm.loadDetail(id) }
    val d = detail?.takeIf { it.id == id }
    var showEdit by remember { mutableStateOf(false) }
    var memberProfile by remember { mutableStateOf<String?>(null) }
    var confirmKick by remember { mutableStateOf<String?>(null) }
    var confirmLeave by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "بازگشت") }
            EmojiText(d?.name ?: "گروه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (d != null) IconButton(onClick = { shareGroup(ctx, d) }) { Icon(Icons.Rounded.Share, "دعوت", tint = cs.onSurfaceVariant) }
        }
        if (d == null) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { repeat(3) { GroupCardSkeleton() } }
        } else {
            val ranked = remember(d.members) { d.members.sortedByDescending { it.todayMinutes } }
            val maxM = (ranked.firstOrNull()?.todayMinutes ?: 0).coerceAtLeast(1)
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp,
                bottom = 24.dp + LocalBottomBarPadding.current.calculateBottomPadding()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item(key = "hero") {
                    FadeSlideIn(0) {
                        DetailHero(d, onEdit = { showEdit = true }, onChat = { onChat(d.name) }, onInvite = { shareGroup(ctx, d) },
                            onCopy = { clip.setText(AnnotatedString("@" + d.username)); AppSnack.show("شناسه‌ی گروه کپی شد") })
                    }
                }
                item(key = "stats") {
                    FadeSlideIn(1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatTile("🧑‍🎓", d.memberCount.fa(), "عضو", cs.primary, Modifier.weight(1f))
                            StatTile("🟢", d.members.count { it.isOnline }.fa(), "آنلاین", Color(0xFF22C55E), Modifier.weight(1f))
                            StatTile("⏱️", Fmt.minutes(d.members.sumOf { it.todayMinutes }), "مطالعه‌ی امروز", Color(0xFFFF8A3D), Modifier.weight(1f))
                        }
                    }
                }
                if (ranked.count { it.todayMinutes > 0 } >= 2) item(key = "podium") {
                    FadeSlideIn(2) { Podium(ranked.take(3), onClick = { memberProfile = it }) }
                }
                item(key = "membersTitle") { SectionTitle(stringResource(R.string.groups_005)) }
                itemsIndexed(ranked, key = { _, m -> m.username }) { i, m ->
                    FadeSlideIn(i + 3) {
                        MemberRow(rank = i + 1, m = m, maxMinutes = maxM, owner = m.username == d.ownerName,
                            canKick = d.isOwner && m.username != d.ownerName,
                            onClick = { memberProfile = m.username }, onKick = { confirmKick = m.username })
                    }
                }
                item(key = "danger") {
                    Spacer(Modifier.height(4.dp))
                    Surface(shape = RoundedCornerShape(20.dp), color = cs.error.copy(alpha = 0.08f), border = BorderStroke(1.dp, cs.error.copy(alpha = 0.25f)),
                        onClick = { confirmLeave = true }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Icon(if (d.isOwner) Icons.Rounded.Delete else Icons.AutoMirrored.Rounded.Logout, null, tint = cs.error)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(if (d.isOwner) R.string.groups_006 else R.string.groups_007), color = cs.error, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
    if (memberProfile != null) {
        val pu = memberProfile!!
        UserProfileSheet(username = pu, onDismiss = { memberProfile = null }, onMessage = { memberProfile = null; ir.studying.app.core.NavBus.requestDm(pu) })
    }
    if (showEdit && d != null) {
        var name by remember { mutableStateOf(d.name) }
        AlertDialog(onDismissRequest = { showEdit = false }, title = { Text(stringResource(R.string.groups_008)) },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(stringResource(R.string.groups_009)) }, singleLine = true, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) vm.rename(id, name.trim()); showEdit = false }) { Text(stringResource(R.string.groups_010)) } },
            dismissButton = { TextButton(onClick = { showEdit = false }) { Text(stringResource(R.string.groups_011)) } })
    }
    confirmKick?.let { u ->
        AlertDialog(onDismissRequest = { confirmKick = null },
            icon = { Icon3D("🚪", 40.dp) },
            title = { Text("حذف $u از گروه؟") },
            text = { Text("$u دیگر پیام‌ها و آمار گروه را نمی‌بیند. می‌تواند دوباره با شناسه عضو شود.") },
            confirmButton = { TextButton(onClick = { vm.kick(id, u); confirmKick = null }) { Text("حذف عضو", color = cs.error) } },
            dismissButton = { TextButton(onClick = { confirmKick = null }) { Text(stringResource(R.string.groups_011)) } })
    }
    if (confirmLeave && d != null) {
        AlertDialog(onDismissRequest = { confirmLeave = false },
            icon = { Icon3D(if (d.isOwner) "🗑️" else "👋", 40.dp) },
            title = { Text(if (d.isOwner) "حذف گروه «${d.name}»؟" else "خروج از «${d.name}»؟") },
            text = { Text(if (d.isOwner) "گروه برای همه‌ی اعضا حذف می‌شود و برگشت‌پذیر نیست." else "می‌توانی بعداً دوباره با شناسه‌ی گروه عضو شوی.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLeave = false
                    if (d.isOwner) vm.deleteGroup(d.id) { onBack() } else vm.leave(d.id) { onBack() }
                }) { Text(stringResource(if (d.isOwner) R.string.groups_006 else R.string.groups_007), color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text(stringResource(R.string.groups_011)) } })
    }
}

private fun shareGroup(ctx: Context, d: GroupDetail) {
    val text = "به گروه مطالعه‌ی «${d.name}» در اپ استادیینگ بپیوند! 📚\nشناسه‌ی گروه: @${d.username}"
    runCatching {
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "دعوت به گروه")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
private fun DetailHero(d: GroupDetail, onEdit: () -> Unit, onChat: () -> Unit, onInvite: () -> Unit, onCopy: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = userColor(d.username)
    val t = rememberInfiniteTransition(label = "ring")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "ringSpin")
    Surface(shape = RoundedCornerShape(30.dp), color = cs.surface, shadowElevation = 2.dp, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.5f))) {
        Box(Modifier.background(Brush.verticalGradient(listOf(c.copy(alpha = 0.22f), Color.Transparent)))) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(104.dp).graphicsLayer { rotationZ = spin }) {
                        drawCircle(Brush.sweepGradient(listOf(c, cs.primary, cs.tertiary, c)), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
                    }
                    GroupAvatar(d.avatar, d.username, 88.dp)
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EmojiText(d.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    if (d.isOwner) IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.Edit, "ویرایش", modifier = Modifier.size(18.dp), tint = cs.onSurfaceVariant) }
                }
                Surface(shape = CircleShape, color = c.copy(alpha = 0.14f), onClick = onCopy) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("@${d.username}", style = MaterialTheme.typography.labelLarge, color = lerp(c, cs.onSurface, 0.35f), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Rounded.ContentCopy, "کپی", modifier = Modifier.size(14.dp), tint = lerp(c, cs.onSurface, 0.35f))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon3D("👑", 16.dp)
                    Spacer(Modifier.width(4.dp))
                    Text("مدیر: ${d.ownerName}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HeroButton("💬", stringResource(R.string.groups_004), primary = true, modifier = Modifier.weight(1.3f), onClick = onChat)
                    HeroButton("💌", "دعوت دوستان", primary = false, modifier = Modifier.weight(1f), onClick = onInvite)
                }
            }
        }
    }
}

@Composable
private fun HeroButton(emoji: String, label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val scale = pressScale(interaction)
    val haptic = LocalHapticFeedback.current
    Row(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape)
            .then(if (primary) Modifier.background(brandGradient()) else Modifier.background(cs.surfaceVariant.copy(alpha = 0.8f)))
            .clickable(interaction, indication = null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
            .padding(vertical = 12.dp, horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        Icon3D(emoji, 22.dp)
        Spacer(Modifier.width(7.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = if (primary) cs.onPrimary else cs.onSurface, maxLines = 1)
    }
}

@Composable
private fun StatTile(emoji: String, value: String, label: String, accent: Color, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(20.dp), color = accent.copy(alpha = 0.10f), border = BorderStroke(1.dp, accent.copy(alpha = 0.22f)), modifier = modifier) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon3D(emoji, 26.dp)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
        }
    }
}

/** Today's top three on a little animated podium. */
@Composable
private fun Podium(top: List<GroupMember>, onClick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(26.dp), color = cs.surface, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.5f))) {
        Column(Modifier.fillMaxWidth().padding(top = 14.dp, start = 12.dp, end = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon3D("🏆", 22.dp)
                Spacer(Modifier.width(6.dp))
                Text("قهرمان‌های امروز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            // Rtl row: the first child sits on the right. 2nd | 1st | 3rd.
            val order = listOfNotNull(top.getOrNull(1)?.let { it to 2 }, top.getOrNull(0)?.let { it to 1 }, top.getOrNull(2)?.let { it to 3 })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                order.forEach { (m, rank) -> PodiumColumn(m, rank, Modifier.weight(1f)) { onClick(m.username) } }
            }
        }
    }
}

@Composable
private fun PodiumColumn(m: GroupMember, rank: Int, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val medal = when (rank) { 1 -> "🥇"; 2 -> "🥈"; else -> "🥉" }
    val tone = when (rank) { 1 -> Color(0xFFFFC53D); 2 -> Color(0xFFB8C4D6); else -> Color(0xFFE59866) }
    val pillar = when (rank) { 1 -> 92.dp; 2 -> 68.dp; else -> 52.dp }
    val grow = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(120L * (4 - rank)); grow.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 140f)) }
    Column(modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.TopCenter) {
            Box(Modifier.padding(top = 14.dp)) { Avatar(m.username, null, size = if (rank == 1) 58.dp else 48.dp, online = m.isOnline, avatarUrl = m.avatar) }
            if (rank == 1) Icon3D("👑", 26.dp, Modifier.graphicsLayer { translationY = -6.dp.toPx(); rotationZ = -12f })
        }
        Spacer(Modifier.height(4.dp))
        Text(m.username, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 96.dp))
        Text(Fmt.minutes(m.todayMinutes), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier.fillMaxWidth(0.82f).height(pillar * grow.value.coerceAtLeast(0.05f))
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(Brush.verticalGradient(listOf(tone, lerp(tone, Color.Black, 0.3f)))),
            contentAlignment = Alignment.TopCenter,
        ) {
            AnimatedEmoji(medal, 30.dp, autoPlay = true, burst = rank == 1, modifier = Modifier.padding(top = 6.dp).graphicsLayer { alpha = grow.value.coerceIn(0f, 1f) })
        }
    }
}

@Composable
private fun MemberRow(rank: Int, m: GroupMember, maxMinutes: Int, owner: Boolean, canKick: Boolean, onClick: () -> Unit, onKick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = userColor(m.username)
    val target = if (maxMinutes <= 0) 0f else (m.todayMinutes.toFloat() / maxMinutes).coerceIn(0f, 1f)
    val grow = remember { Animatable(0f) }
    LaunchedEffect(target) { grow.animateTo(target, tween(900, easing = FastOutSlowInEasing)) }
    Surface(shape = RoundedCornerShape(20.dp), color = cs.surface, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.4f)), onClick = onClick) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
                when (rank) {
                    1 -> Icon3D("🥇", 26.dp); 2 -> Icon3D("🥈", 26.dp); 3 -> Icon3D("🥉", 26.dp)
                    else -> Text(rank.fa(), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.width(6.dp))
            Avatar(m.username, m.mood, size = 42.dp, online = m.isOnline, avatarUrl = m.avatar)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.username, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false))
                    if (owner) { Spacer(Modifier.width(4.dp)); Icon3D("👑", 15.dp) }
                    Spacer(Modifier.weight(1f))
                    Text(if (m.todayMinutes > 0) Fmt.minutes(m.todayMinutes) else "هنوز شروع نکرده", style = MaterialTheme.typography.labelMedium,
                        color = if (m.todayMinutes > 0) lerp(c, cs.onSurface, 0.3f) else cs.onSurfaceVariant)
                }
                Spacer(Modifier.height(7.dp))
                Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(cs.surfaceVariant.copy(alpha = 0.8f))) {
                    if (grow.value > 0.001f) Box(Modifier.fillMaxWidth(grow.value.coerceAtLeast(0.03f)).height(7.dp).clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(lerp(c, Color.Black, 0.15f), c))))
                }
            }
            if (canKick) {
                Spacer(Modifier.width(4.dp))
                IconButton(onClick = onKick, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.PersonRemove, "حذف عضو", tint = cs.error.copy(alpha = 0.8f), modifier = Modifier.size(19.dp)) }
            }
        }
    }
}

/* ============================================================== chat == */

/** Reusable group chat screen (also opened from the Messages tab). */
@Composable
fun GroupChatScreen(id: Int, name: String, onBack: () -> Unit, vm: GroupsViewModel = viewModel(key = "grpchat_" + id)) {
    val ctx = LocalContext.current
    val me = Store.username ?: ""
    val messages by vm.messages.collectAsState()
    val loading by vm.chatLoading.collectAsState()
    val uploadPercent by vm.uploadPercent.collectAsState()
    val removed by vm.removed.collectAsState()
    val sessionForChat by Store.session.collectAsState()
    LaunchedEffect(sessionForChat) { vm.sync.ensureSession() }
    val timeline by vm.sync.timeline.collectAsState()
    val pending = timeline.pending
    val rx by vm.sync.reactions.map.collectAsState()
    val prefs by Store.prefs.collectAsState()
    val msgs = remember(timeline, rx, removed, me) {
        timelineChat(timeline, me, removed) { id, reactions -> vm.sync.reactions.view(id, reactions) }
    }
    val chat = rememberChatController(msgs, loading)
    val clip = LocalClipboardManager.current
    val muteKey = "grp:$id"; val muted = prefs.muted.contains(muteKey)
    var input by rememberSaveable(id) { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<UiMsg?>(null) }
    var profileUser by remember { mutableStateOf<String?>(null) }
    val detail by vm.detail.collectAsState()
    LaunchedEffect(id) { if (detail?.id != id) vm.loadDetail(id) }
    val d = detail?.takeIf { it.id == id }
    // «دیده‌شده» روی خود دستگاه ذخیره می‌شود تا با بستن و باز کردن چت دوباره ظاهر نشود
    var mentionSeenId by remember { mutableIntStateOf(0) }
    LaunchedEffect(id) { mentionSeenId = Store.groupSeen(id) }
    // تشخیص «@در حال تایپ» برای پیشنهاد اعضا (تلگرامی)
    val mentionQuery = remember(input) { mentionRe.find(input)?.groupValues?.get(1) }
    var showAttach by remember { mutableStateOf(false) }
    var showStickers by remember { mutableStateOf(false) }
    var showMusic by remember { mutableStateOf(false) }
    var viewImage by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.sendImage(ctx, id, uri) { AppSnack.show(it) } }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.sendFile(ctx, id, uri) { AppSnack.show(it) } }
    val musicFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.sendMusicFile(ctx, id, uri) { AppSnack.show(it) } }

    LaunchedEffect(id) { vm.pollChat(id) }
    LaunchedEffect(id) { while (true) { vm.pollChat(id); delay(3000) } }

    val meIdx = msgs.indexOfLast { !it.mine && it.id > 0 && (it.replySender == me || (it.text?.contains("@$me") == true)) }
    val meMsgId = if (meIdx >= 0) msgs[meIdx].id else 0
    // اگر خود پیام در صفحه دیده شد → منشن دیده‌شده حساب می‌شود و دکمه محو می‌شود
    LaunchedEffect(meMsgId, chat.listState) {
        if (meMsgId > 0) snapshotFlow { chat.listState.layoutInfo.visibleItemsInfo.map { it.key } }
            .collect { vis ->
                val key = msgs.getOrNull(meIdx)?.key
                if (key != null && key in vis && meMsgId > mentionSeenId) {
                    mentionSeenId = meMsgId
                    Store.setGroupSeen(id, meMsgId)
                }
            }
    }

    val online = d?.members?.count { it.isOnline } ?: 0
    val title = d?.name ?: name.ifBlank { "گروه" }
    ChatSurface(
        chat = chat, kind = ChatKind.GROUP, me = me, msgs = msgs, loading = loading,
        empty = { ChatEmpty("💬", "گروه ساکته!", "اولین پیام گروه رو بفرست و بقیه رو صدا بزن", actionLabel = "👋 سلام به همه", onAction = {
            vm.sendChat(id, "سلام به همه 👋", null, null, null) { AppSnack.show(it) }
        }) },
        topBar = {
            ChatTopBar(
                onBack = onBack, title = title,
                leading = { GroupAvatar(d?.avatar, d?.username ?: title, 42.dp) },
                subtitle = {
                    ChatStatus(if (d != null) "${d.memberCount.fa()} عضو" + (if (online > 0) " · ${online.fa()} آنلاین" else "") else "گروه مطالعه",
                        typing = false, highlight = online > 0)
                },
                actions = {
                    IconButton(onClick = { Store.toggleMute(muteKey); AppSnack.show(if (!muted) "بی‌صدا شد 🔕" else "صدادار شد 🔔") }) {
                        Icon(if (muted) Icons.Rounded.NotificationsOff else Icons.Rounded.NotificationsActive, if (muted) "صدادار کردن" else "بی‌صدا کردن",
                            tint = if (muted) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    }
                },
            )
        },
        bottomBar = {
            val cands = remember(mentionQuery, d) {
                if (mentionQuery == null || d == null) emptyList()
                else d.members.filter { it.username != me && (mentionQuery.isEmpty() || it.username.contains(mentionQuery, true)) }
                    .take(8).map { it.username to it.avatar }
            }
            ChatComposer(
                value = input, onValueChange = { input = it }, placeholder = "پیام گروه…",
                onSend = {
                    val t = input.trim()
                    if (t.isNotEmpty()) {
                        val r = replyTo
                        vm.sendChat(id, t, r?.id?.takeIf { it > 0 }, r?.sender, r?.preview()) { AppSnack.show(it) }
                        input = ""; replyTo = null
                    }
                },
                onAttach = { showAttach = true },
                reply = replyTo?.let { ReplyDraft(it.sender, it.preview()) },
                onCancelReply = { replyTo = null },
                top = {
                    AnimatedVisibility(visible = cands.isNotEmpty(), enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                        var last by remember { mutableStateOf(cands) }
                        if (cands.isNotEmpty()) last = cands
                        MentionBar(last) { u -> input = input.replace(mentionRe, "@$u ") }
                    }
                },
            )
        },
        menuFor = { m ->
            if (m.pending) pendingMenu(m,
                copy = { clip.setText(AnnotatedString(it)) },
                retry = { m.localId?.let { lid -> vm.retry(id, lid) { e -> AppSnack.show(e) } } },
                discard = { m.localId?.let { lid -> vm.discard(lid) } })
            else buildList {
                add(MenuAction(Icons.AutoMirrored.Rounded.Reply, "پاسخ") { replyTo = m })
                if (!m.mine) add(MenuAction(Icons.Rounded.Person, "پروفایل ${m.sender}") { profileUser = m.sender })
                if (!m.text.isNullOrBlank() && m.type == "text") add(MenuAction(Icons.Rounded.ContentCopy, "کپی متن") { clip.setText(AnnotatedString(m.text)) })
                if (m.mine) add(MenuAction(Icons.Rounded.Delete, "حذف پیام", danger = true) {
                    if (replyTo?.key == m.key) replyTo = null
                    vm.deleteMsg(id, m.id) { AppSnack.show(it) }
                })
            }
        },
        onReact = { m, e -> if (!m.pending) vm.react(id, m.id, m.reactions, e) },
        onAvatar = { u -> if (u != me) profileUser = u },
        onImage = { viewImage = it },
        onRetry = { m -> m.localId?.let { lid -> vm.retry(id, lid) { e -> AppSnack.show(e) } } },
        onSwipeReply = { m -> if (!m.pending) replyTo = m },
        uploadPercent = uploadPercent,
        delivery = pending.filter { it.state == SendState.FAILED },
        onRestoreDelivery = { o ->
            val draft = restoreDeliveryDraft(o, input, replyTo, msgs)
            if (draft != null) {
                input = draft.text; replyTo = draft.reply; vm.discard(o.localId)
            } else AppSnack.show("کادر و پاسخ فعلی را خالی کن؛ برای پاسخ قبلی، پیام اصلی هم باید در گفتگو موجود باشد")
        },
        onDiscardDelivery = { o -> vm.discard(o.localId) },
        listOverlay = {
            SideFab(
                visible = meIdx >= 0 && meMsgId > mentionSeenId,
                raised = chat.awayFromBottom,
                onClick = {
                    mentionSeenId = meMsgId
                    Store.setGroupSeen(id, meMsgId)
                    chat.jumpTo(meIdx)
                },
            ) { Text("@", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary) }
        },
    )

    if (showAttach) AttachSheet(onImage = { showAttach = false; imagePicker.launch("image/*") }, onFile = { showAttach = false; filePicker.launch("*/*") }, onMusic = { showAttach = false; showMusic = true }, onMusicDevice = { showAttach = false; musicFilePicker.launch("audio/*") }, onSticker = { showAttach = false; showStickers = true }, onDismiss = { showAttach = false })
    if (showStickers) StickerPickerSheet(onPick = { st -> showStickers = false; vm.sendSticker(id, st.id) { AppSnack.show(it) } }, onDismiss = { showStickers = false })
    if (showMusic) ChatMusicPicker(onPick = { t -> showMusic = false; vm.sendMusic(id, t.id) { AppSnack.show(it) } }, onDismiss = { showMusic = false })
    viewImage?.let { ImageViewerDialog(it) { viewImage = null } }
    if (profileUser != null) {
        val pu = profileUser!!
        UserProfileSheet(username = pu, onDismiss = { profileUser = null }, onMessage = { profileUser = null; ir.studying.app.core.NavBus.requestDm(pu) })
    }
}

private val mentionRe = Regex("@([\\w\\u0600-\\u06FF]*)$")

/* =========================================================== sheets == */

@Composable
private fun SheetHeader(emoji: String, title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedEmoji(emoji, 72.dp, autoPlay = true, idle = true)
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SheetButton(label: String, enabled: Boolean, busy: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val a by animateFloatAsState(if (enabled) 1f else 0.45f, label = "sheetBtn")
    Box(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a }.clip(CircleShape).background(brandGradient())
            .clickable(enabled = enabled && !busy) { onClick() }.padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (busy) ir.studying.app.ui.components.FlameLoader(size = 24.dp)
        else Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onPrimary)
    }
}

private fun cleanId(s: String) = s.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' }

@Composable
private fun CreateGroupSheet(onDismiss: () -> Unit, onCreate: (String, String, (Boolean) -> Unit) -> Unit) {
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val ok = name.isNotBlank() && username.length >= 3
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
            SheetHeader("✨", stringResource(R.string.groups_001), "یه اسم خوب انتخاب کن و شناسه‌ش رو برای دوستات بفرست")
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text(stringResource(R.string.groups_009)) }, singleLine = true,
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = username, onValueChange = { username = cleanId(it).take(24) }, label = { Text(stringResource(R.string.groups_013)) }, singleLine = true,
                prefix = { Text("@") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
            Text(stringResource(R.string.groups_014), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp, start = 4.dp))
            Spacer(Modifier.height(18.dp))
            SheetButton(stringResource(R.string.groups_015), enabled = ok, busy = busy) {
                busy = true
                onCreate(name.trim(), username.trim()) { success -> if (!success) busy = false }
            }
        }
    }
}

@Composable
private fun JoinGroupSheet(onDismiss: () -> Unit, onJoin: (String, (Boolean) -> Unit) -> Unit) {
    var username by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
            SheetHeader("🔗", stringResource(R.string.groups_016), stringResource(R.string.groups_018))
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = username, onValueChange = { username = cleanId(it.removePrefix("@")).take(24) }, label = { Text(stringResource(R.string.groups_017)) },
                singleLine = true, prefix = { Text("@") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            SheetButton(stringResource(R.string.groups_002), enabled = username.length >= 3, busy = busy) {
                busy = true
                onJoin(username.trim()) { success -> if (!success) busy = false }
            }
        }
    }
}
