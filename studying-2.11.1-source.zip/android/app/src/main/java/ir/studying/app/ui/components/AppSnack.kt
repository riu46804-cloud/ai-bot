package ir.studying.app.ui.components

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * App-wide, themed feedback channel.
 *
 * Replaces android.widget.Toast everywhere. Toast is throttled and mostly
 * suppressed from Android 13 on, ignores the app palette, lays out left to
 * right regardless of locale, and — most importantly — cannot carry an action,
 * so every destructive tap needed a blocking confirm dialog instead.
 *
 * A snackbar solves all four: it is drawn by our own Material theme inside the
 * RTL tree, and it can offer "undo", which lets delete flows act immediately
 * and stay reversible instead of interrupting the user with a dialog.
 */
object AppSnack {

    data class Message(
        val text: String,
        val actionLabel: String? = null,
        val long: Boolean = false,
        val onAction: (() -> Unit)? = null,
        val onDismissed: (() -> Unit)? = null,
    )

    private val _messages = MutableSharedFlow<Message>(
        replay = 0,
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    val messages = _messages.asSharedFlow()

    /** Plain confirmation or error text. */
    fun show(text: String, long: Boolean = false) {
        if (text.isBlank()) return
        _messages.tryEmit(Message(text, long = long))
    }

    /**
     * Optimistic, reversible action.
     *
     * [onAction] runs when the user taps undo; [onDismissed] runs when the bar
     * goes away untouched, which is where the real commit belongs.
     */
    fun undoable(
        text: String,
        actionLabel: String = "\u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u062F\u0646",
        onUndo: () -> Unit,
        onCommit: (() -> Unit)? = null,
    ) {
        _messages.tryEmit(Message(text, actionLabel, long = true, onAction = onUndo, onDismissed = onCommit))
    }
}

/** Bridges [AppSnack] into a Material3 [SnackbarHostState]. Hosted once in MainScaffold. */
fun CoroutineScope.collectAppSnacks(host: SnackbarHostState) {
    launch {
        AppSnack.messages.collect { m ->
            val result = host.showSnackbar(
                message = m.text,
                actionLabel = m.actionLabel,
                withDismissAction = m.actionLabel == null,
                duration = if (m.long) SnackbarDuration.Long else SnackbarDuration.Short,
            )
            when (result) {
                SnackbarResult.ActionPerformed -> m.onAction?.invoke()
                SnackbarResult.Dismissed -> m.onDismissed?.invoke()
            }
        }
    }
}
