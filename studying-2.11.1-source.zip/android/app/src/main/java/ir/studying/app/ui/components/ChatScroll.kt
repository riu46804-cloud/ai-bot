package ir.studying.app.ui.components

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable

/**
 * وضعیت اسکرول صفحه‌های گفتگو.
 *
 * قبلاً لیست از پیام اول ساخته می‌شد و بعد با انیمیشن تا آخر پایین می‌رفت؛ کاربر
 * هر بار باز کردن چت، سُر خوردن کل گفتگو را می‌دید. حالا لیست از همان فریم اول
 * روی آخرین پیام ساخته می‌شود (بدون هیچ انیمیشنی) و فقط برای پیام‌های تازه
 * دنبال می‌کند:
 *  - اگر پیام تازه مال خود کاربر باشد، همیشه پایین می‌رود؛
 *  - اگر کاربر پایین گفتگو بوده، نرم پایین می‌رود؛
 *  - اگر کاربر بالا رفته تا پیام‌های قبلی را بخواند، جایش عوض نمی‌شود
 *    (دکمه‌ی «پرش به پایین» همان‌جا هست).
 *
 * @param count تعداد آیتم‌های پیام در لیست (ایندکس آخرین پیام = count - 1)
 * @param lastKey کلید یکتای آخرین پیام؛ فقط تغییر آن یعنی «پیام تازه»
 * @param lastIsMine آخرین پیام را خود کاربر فرستاده؟
 * @param visible لیست همین حالا روی صفحه هست؟ (مثلاً در حالت لودینگ نیست)
 */
@Composable
fun rememberChatListState(
    count: Int,
    lastKey: Any?,
    lastIsMine: Boolean,
    visible: Boolean = count > 0,
): LazyListState {
    // با ظاهر شدن لیست، وضعیت تازه‌ای درست می‌شود که از قبل روی آخرین پیام است.
    val state = rememberSaveable(visible, saver = LazyListState.Saver) {
        LazyListState(firstVisibleItemIndex = if (visible) (count - 1).coerceAtLeast(0) else 0)
    }
    val tracker = remember(state) { FollowTracker(count, lastKey) }
    LaunchedEffect(state, lastKey) {
        val prevCount = tracker.count
        val prevKey = tracker.key
        tracker.count = count
        tracker.key = lastKey
        if (!visible || count <= 0 || lastKey == prevKey) return@LaunchedEffect
        val lastVisible = state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: return@LaunchedEffect
        val wasAtBottom = lastVisible >= prevCount - 2
        if (lastIsMine || wasAtBottom) runCatching { state.animateScrollToItem(count - 1) }
    }
    return state
}

private class FollowTracker(var count: Int, var key: Any?)
