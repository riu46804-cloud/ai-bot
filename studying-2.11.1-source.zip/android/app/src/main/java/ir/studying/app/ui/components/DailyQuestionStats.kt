package ir.studying.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.QuestionTotals
import ir.studying.app.core.fa

/** A two-format scorecard, not a percentage or a study target. Shared by report and feed. */
@Composable
fun DailyQuestionStats(totals: QuestionTotals?, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Column(modifier.fillMaxWidth()) {
        if (LocalDensity.current.fontScale > 1.3f) {
            Column {
                Text("کارنامهٔ تمرین", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("ثبت‌شده در این روز", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("کارنامهٔ تمرین", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("ثبت‌شده در این روز", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(10.dp))
        if (totals == null) {
            Surface(shape = RoundedCornerShape(18.dp), color = cs.surfaceVariant.copy(alpha = 0.45f)) {
                Text("آمار سؤال‌ها در دسترس نیست؛ اتصال و نسخهٔ سرور را بررسی کنید.",
                    modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val cyan = if (dark) Color(0xFF67D9FF) else Color(0xFF0369A1)
            val violet = if (dark) Color(0xFFC4B5FD) else Color(0xFF6D28D9)
            val largeText = LocalDensity.current.fontScale > 1.3f
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                if (maxWidth < 300.dp || largeText) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuestionMetric("تست", "درست + غلط + نزده", totals.tests, Icons.Rounded.FactCheck, cyan, Modifier.fillMaxWidth())
                        QuestionMetric("سؤال تشریحی", "پاسخ‌های نوشتاری", totals.descriptive, Icons.Rounded.EditNote, violet, Modifier.fillMaxWidth())
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuestionMetric("تست", "درست + غلط + نزده", totals.tests, Icons.Rounded.FactCheck, cyan, Modifier.weight(1f))
                        QuestionMetric("سؤال تشریحی", "پاسخ‌های نوشتاری", totals.descriptive, Icons.Rounded.EditNote, violet, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun QuestionMetric(title: String, subtitle: String, count: Int, icon: ImageVector, accent: Color, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier.semantics(mergeDescendants = true) { contentDescription = "${count.fa()} $title" },
        shape = RoundedCornerShape(20.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
    ) {
        Column(Modifier.background(Brush.linearGradient(listOf(accent.copy(alpha = 0.16f), accent.copy(alpha = 0.025f))))
            .padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(10.dp), color = accent.copy(alpha = 0.13f)) {
                    Icon(icon, null, tint = accent, modifier = Modifier.padding(6.dp).size(19.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onSurface)
            }
            Spacer(Modifier.height(12.dp))
            Text(count.fa(), color = accent, fontWeight = FontWeight.Black,
                fontSize = (if (count >= 1_000_000) 25 else if (count >= 100_000) 29 else 36).sp, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
    }
}
