package ir.studying.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import ir.studying.app.core.Icon3D
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * Living 3D emoji.
 *
 * Every emoji gets a motion that matches what it means: hearts beat, a thumbs
 * up hops, fire flickers, a laugh wobbles like jelly, a prayer bows. A burst of
 * particles in the emoji's own colours goes off on top. Everything is drawn on
 * the graphics layer, so nothing here ever triggers a relayout.
 */

enum class EmojiMotion { BEAT, BOUNCE, SHAKE, FLICKER, SPIN, JELLY, POP, BOW, WAVE }

private val beat = setOf("❤", "💔", "💘", "💖", "💗", "💓", "💕", "💞", "💝", "💟", "❣", "🥰", "😍", "😘", "💋", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "😻", "🫶")
private val bounce = setOf("👍", "👏", "👌", "🙌", "💪", "🤝", "🏆", "🥇", "🤩", "😎", "🆒", "✌", "🤞", "👊", "✊", "🫰", "🤟", "🤘", "🥳", "🐳", "🦄", "🤗")
private val shake = setOf("👎", "😡", "🤬", "😠", "🤮", "😱", "😨", "🖕", "😤", "💩", "🤯", "😰", "🤢", "😖", "🥶", "😵")
private val flicker = setOf("🔥", "⚡", "✨", "💥", "🌟", "💫", "🎇", "🎆", "☄")
private val spin = setOf("💯", "⭐", "🎯", "🍓", "🌚", "🌝", "🍌", "🌀", "🎡", "🪙", "🗿", "👻", "🤡", "🌭", "🍾", "💊")
private val jelly = setOf("😂", "🤣", "😁", "😆", "😹", "🤪", "😜", "😝", "😛", "🥴", "😄", "😃", "😀", "🙃", "😅")
private val bow = setOf("🙏", "🫡", "🙇", "🤓", "😇", "😴", "🥱", "😐", "🤔", "🤨", "🧐", "😢", "😭", "🥺", "🥹", "😔", "🕊")
private val wave = setOf("👋", "🤙", "💅", "✍", "🫵", "☝", "👆", "🎅", "🎄", "🎃", "👀", "🙈", "🙉", "🙊")

private fun baseOf(emoji: String): String {
    if (emoji.isEmpty()) return emoji
    val cp = emoji.codePointAt(0)
    return String(Character.toChars(cp))
}

fun motionFor(emoji: String): EmojiMotion {
    val b = baseOf(emoji)
    return when {
        b in beat || emoji.startsWith("❤") -> EmojiMotion.BEAT
        b in flicker -> EmojiMotion.FLICKER
        b in bounce -> EmojiMotion.BOUNCE
        b in shake -> EmojiMotion.SHAKE
        b in jelly -> EmojiMotion.JELLY
        b in spin -> EmojiMotion.SPIN
        b in bow -> EmojiMotion.BOW
        b in wave -> EmojiMotion.WAVE
        else -> EmojiMotion.POP
    }
}

/** Particle colours that belong to the emoji. */
fun burstColorsFor(emoji: String, fallback: List<Color>): List<Color> {
    val b = baseOf(emoji)
    return when {
        b in beat || emoji.startsWith("❤") -> listOf(Color(0xFFFF4D6D), Color(0xFFFF8FA3), Color(0xFFFFC2D1), Color(0xFFE11D48))
        b in flicker -> listOf(Color(0xFFFFB703), Color(0xFFFB8500), Color(0xFFFFE066), Color(0xFFFF5400))
        b == "😂" || b == "🤣" || b == "😹" || b == "😭" || b == "😢" -> listOf(Color(0xFF4CC9F0), Color(0xFFFFD60A), Color(0xFF90E0EF), Color(0xFFFFC300))
        b in bounce -> listOf(Color(0xFFFFC300), Color(0xFF4CC9F0), Color(0xFF80ED99), Color(0xFFFFE066))
        b in shake -> listOf(Color(0xFFEF476F), Color(0xFF9D4EDD), Color(0xFFFF7B00), Color(0xFF6C757D))
        b == "🍓" || b == "🍒" -> listOf(Color(0xFFE63946), Color(0xFF52B788), Color(0xFFFF8FA3))
        b == "🍌" || b == "💯" || b == "⭐" -> listOf(Color(0xFFFFD60A), Color(0xFFFFB703), Color(0xFFEF476F))
        b == "🎉" || b == "🎊" || b == "🥳" -> listOf(Color(0xFFFF006E), Color(0xFF3A86FF), Color(0xFFFFBE0B), Color(0xFF8338EC), Color(0xFF06D6A0))
        else -> fallback
    }
}

/** One-shot transform of [motion] at progress [p] (0..1). Values in units of the emoji size. */
private class Pose(var sx: Float = 1f, var sy: Float = 1f, var rot: Float = 0f, var rotX: Float = 0f,
                   var dx: Float = 0f, var dy: Float = 0f, var ox: Float = 0.5f, var oy: Float = 0.5f)

private fun bump(p: Float, a: Float, b: Float): Float =
    if (p <= a || p >= b) 0f else sin(PI.toFloat() * (p - a) / (b - a))

private fun poseOf(motion: EmojiMotion, p: Float, out: Pose) {
    out.sx = 1f; out.sy = 1f; out.rot = 0f; out.rotX = 0f; out.dx = 0f; out.dy = 0f; out.ox = 0.5f; out.oy = 0.5f
    if (p <= 0f || p >= 1f) return
    val pi = PI.toFloat()
    val fade = 1f - p
    when (motion) {
        EmojiMotion.BEAT -> {
            val s = 1f + 0.34f * bump(p, 0f, 0.34f) + 0.24f * bump(p, 0.38f, 0.72f) + 0.06f * bump(p, 0.74f, 1f)
            out.sx = s; out.sy = s
        }
        EmojiMotion.BOUNCE -> {
            out.oy = 0.92f
            val up = min(p / 0.62f, 1f)
            out.dy = -0.30f * sin(pi * up)
            out.rot = -16f * sin(pi * up)
            val land = bump(p, 0.62f, 1f)
            out.sy = 1f - 0.16f * land + 0.08f * sin(pi * up)
            out.sx = 1f + 0.12f * land
        }
        EmojiMotion.SHAKE -> {
            out.rot = 17f * sin(p * pi * 6f) * fade
            out.dx = 0.07f * sin(p * pi * 8f) * fade
            val s = 1f + 0.12f * sin(pi * p)
            out.sx = s; out.sy = s
        }
        EmojiMotion.FLICKER -> {
            out.oy = 0.95f
            out.sy = 1f + 0.30f * sin(pi * p) + 0.07f * sin(p * pi * 10f) * fade
            out.sx = 1f + 0.12f * sin(pi * p) - 0.05f * sin(p * pi * 10f) * fade
            out.rot = 7f * sin(p * pi * 6f) * fade
        }
        EmojiMotion.SPIN -> {
            val e = if (p < 0.5f) 4f * p * p * p else 1f - (-2f * p + 2f).let { it * it * it } / 2f
            out.rot = 360f * e
            val s = 1f + 0.26f * sin(pi * p)
            out.sx = s; out.sy = s
        }
        EmojiMotion.JELLY -> {
            out.oy = 0.9f
            out.sx = 1f + 0.22f * sin(p * pi * 4f) * fade
            out.sy = 1f - 0.20f * sin(p * pi * 4f) * fade
            out.rot = 9f * sin(p * pi * 6f) * fade
            out.dy = -0.10f * sin(pi * p)
        }
        EmojiMotion.POP -> {
            val s = 1f + 0.36f * sin(pi * p) * (1f - 0.3f * p)
            out.sx = s; out.sy = s
            out.rot = 10f * sin(p * pi * 2f) * fade
        }
        EmojiMotion.BOW -> {
            out.oy = 0.95f
            out.rotX = 38f * bump(p, 0f, 0.5f) + 18f * bump(p, 0.5f, 0.9f)
            val s = 1f + 0.08f * sin(pi * p)
            out.sx = s; out.sy = s
        }
        EmojiMotion.WAVE -> {
            out.ox = 0.72f; out.oy = 0.9f
            out.rot = 24f * sin(p * pi * 5f) * (1f - 0.5f * p)
            val s = 1f + 0.1f * sin(pi * p)
            out.sx = s; out.sy = s
        }
    }
}

private class Spark(val angle: Float, val dist: Float, val radius: Float, val color: Color, val star: Boolean, val spin: Float)

private fun sparksFor(seed: Int, colors: List<Color>, count: Int): List<Spark> {
    val r = java.util.Random(seed.toLong() * 7919L + 17L)
    return List(count) { i ->
        val a = (i.toFloat() / count) * 2f * PI.toFloat() + (r.nextFloat() - 0.5f) * 0.5f
        Spark(
            angle = a,
            dist = 0.55f + r.nextFloat() * 0.55f,
            radius = 0.045f + r.nextFloat() * 0.05f,
            color = colors[i % colors.size],
            star = r.nextFloat() < 0.4f,
            spin = (r.nextFloat() - 0.5f) * 360f,
        )
    }
}

private fun DrawScope.drawSparks(sparks: List<Spark>, b: Float, sizePx: Float) {
    if (b <= 0f || b >= 1f) return
    val c = Offset(size.width / 2f, size.height / 2f)
    // ease out: fast start, soft landing
    val travel = 1f - (1f - b) * (1f - b) * (1f - b)
    val alpha = if (b < 0.7f) 1f else (1f - (b - 0.7f) / 0.3f)
    for (s in sparks) {
        val d = sizePx * (0.18f + s.dist * travel * 0.75f)
        val p = Offset(c.x + cos(s.angle) * d, c.y + sin(s.angle) * d)
        val rad = sizePx * s.radius * (1f - 0.55f * b)
        if (s.star) {
            rotate(s.spin * b, p) { drawPath(starPath(p, rad * 1.6f), s.color.copy(alpha = alpha)) }
        } else drawCircle(s.color.copy(alpha = alpha), rad, p)
    }
}

private fun starPath(c: Offset, r: Float): Path = Path().apply {
    val i = r * 0.32f
    moveTo(c.x, c.y - r)
    quadraticBezierTo(c.x + i * 0.4f, c.y - i * 0.4f, c.x + r, c.y)
    quadraticBezierTo(c.x + i * 0.4f, c.y + i * 0.4f, c.x, c.y + r)
    quadraticBezierTo(c.x - i * 0.4f, c.y + i * 0.4f, c.x - r, c.y)
    quadraticBezierTo(c.x - i * 0.4f, c.y - i * 0.4f, c.x, c.y - r)
    close()
}

/**
 * A 3D emoji that plays its own motion.
 *
 * @param playKey changing this replays the motion (pass a counter or the emoji).
 * @param autoPlay play once when first shown.
 * @param idle gentle endless floating, for hero spots.
 * @param repeatEveryMs replay the motion periodically (0 = never).
 * @param burst particle burst on every play.
 * @param onClick tapping replays the motion too.
 */
@Composable
fun AnimatedEmoji(
    emoji: String,
    size: Dp,
    modifier: Modifier = Modifier,
    playKey: Any? = null,
    autoPlay: Boolean = false,
    idle: Boolean = false,
    repeatEveryMs: Long = 0L,
    burst: Boolean = true,
    motion: EmojiMotion = remember(emoji) { motionFor(emoji) },
    onClick: (() -> Unit)? = null,
) {
    val p = remember { Animatable(0f) }
    val b = remember { Animatable(0f) }
    var shots by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val cs = MaterialTheme.colorScheme
    val colors = remember(emoji, cs.primary) { burstColorsFor(emoji, listOf(cs.primary, cs.secondary, cs.tertiary, Color(0xFFFFD166))) }
    val sparks = remember(emoji, shots) { sparksFor(emoji.hashCode() + shots, colors, 12) }
    val pose = remember { Pose() }

    suspend fun play() {
        shots++
        scope.launch {
            if (burst) { b.snapTo(0f); b.animateTo(1f, tween(720, easing = LinearEasing)) }
        }
        p.snapTo(0f)
        p.animateTo(1f, tween(if (motion == EmojiMotion.SPIN) 820 else 760, easing = LinearEasing))
    }

    LaunchedEffect(playKey) { if (playKey != null) play() }
    LaunchedEffect(Unit) { if (autoPlay && playKey == null) { delay(120); play() } }
    if (repeatEveryMs > 0) LaunchedEffect(repeatEveryMs) {
        while (true) { delay(repeatEveryMs); play() }
    }

    val floatY = if (idle) {
        val t = rememberInfiniteTransition(label = "emojiIdle")
        val v by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "emojiIdleV")
        v
    } else 0f

    val click = if (onClick != null) Modifier.clickable(remember { MutableInteractionSource() }, indication = null) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        scope.launch { play() }
        onClick()
    } else Modifier

    Box(
        modifier
            .size(size)
            .then(click)
            .drawWithContent {
                drawContent()
                if (burst) drawSparks(sparks, b.value, this.size.minDimension)
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon3D(
            emoji, size,
            modifier = Modifier.graphicsLayer {
                poseOf(motion, p.value, pose)
                val px = size.toPx()
                val idleDy = if (idle) sin(floatY * 2f * PI.toFloat()) * px * 0.05f else 0f
                val idleS = if (idle) 1f + 0.025f * sin(floatY * 4f * PI.toFloat()) else 1f
                scaleX = pose.sx * idleS
                scaleY = pose.sy * idleS
                rotationZ = pose.rot
                rotationX = pose.rotX
                translationX = pose.dx * px
                translationY = pose.dy * px + idleDy
                transformOrigin = TransformOrigin(pose.ox, pose.oy)
                cameraDistance = 12f * density
            },
        )
    }
}

/** Particle burst on its own, e.g. on top of a reaction chip. Replays when [key] changes. */
@Composable
fun SparkBurst(key: Any?, emoji: String, modifier: Modifier = Modifier) {
    val b = remember { Animatable(1f) }
    val cs = MaterialTheme.colorScheme
    val colors = remember(emoji) { burstColorsFor(emoji, listOf(cs.primary, cs.secondary, cs.tertiary, Color(0xFFFFD166))) }
    val sparks = remember(key, emoji) { sparksFor((key?.hashCode() ?: 0) + emoji.hashCode(), colors, 10) }
    LaunchedEffect(key) { if (key != null) { b.snapTo(0f); b.animateTo(1f, tween(650, easing = LinearEasing)) } }
    Box(modifier.drawWithContent { drawSparks(sparks, b.value, max(this.size.minDimension, 1f)) })
}
