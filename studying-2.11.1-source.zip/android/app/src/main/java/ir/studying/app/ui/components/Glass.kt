package ir.studying.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** منوی شیشه‌ای تلگرامی: کارت نیمه‌شفاف با حاشیه نور، ورود فنری و آیتم‌های پلکانی. */
@Composable
fun GlassMenu(onDismiss: () -> Unit, content: @Composable ColumnScopeGlass.() -> Unit) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { on = true }
    val scale by animateFloatAsState(if (on) 1f else 0.86f, spring(dampingRatio = 0.66f, stiffness = 760f), label = "glassScale")
    val alpha by animateFloatAsState(if (on) 1f else 0f, spring(stiffness = 1200f), label = "glassAlpha")
    val lift by animateFloatAsState(if (on) 0f else 1f, spring(dampingRatio = 0.8f, stiffness = 520f), label = "glassLift")
    val cs = MaterialTheme.colorScheme
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.graphicsLayer {
            scaleX = scale; scaleY = scale; this.alpha = alpha
            translationY = lift * 28.dp.toPx()
        }) {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = cs.surface.copy(alpha = 0.9f),
                border = BorderStroke(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.05f)))),
                shadowElevation = 22.dp,
                modifier = Modifier.widthIn(min = 250.dp, max = 320.dp),
            ) {
                Box {
                    // soft brand glow at the top edge
                    Box(Modifier.matchParentSize().background(Brush.verticalGradient(
                        0f to cs.primary.copy(alpha = 0.08f), 0.35f to Color.Transparent)))
                    Column(Modifier.padding(vertical = 8.dp)) { ColumnScopeGlass(onDismiss).content() }
                }
            }
        }
    }
}

class ColumnScopeGlass(val dismiss: () -> Unit) {
    internal var counter = 0
}

/** Each row slides up a little after the previous one, like Telegram's menus. */
@Composable
private fun ColumnScopeGlass.staggered(): Modifier {
    val i = remember { counter++ }
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(30L + i * 34L)
        a.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 520f))
    }
    return Modifier.graphicsLayer {
        alpha = a.value.coerceIn(0f, 1f)
        translationY = (1f - a.value) * 16.dp.toPx()
        val s = 0.94f + 0.06f * a.value
        scaleX = s; scaleY = s
    }
}

/** آیتم منوی شیشه‌ای. */
@Composable
fun ColumnScopeGlass.GlassAction(icon: ImageVector, label: String, danger: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tint = if (danger) cs.error else cs.onSurface
    val accent = if (danger) cs.error else cs.primary
    val inter = remember { MutableInteractionSource() }
    val pressed by inter.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 1f else 0f, spring(stiffness = 900f), label = "gaPress")
    Surface(
        color = Color.Transparent,
        onClick = { onClick(); dismiss() },
        interactionSource = inter,
        modifier = Modifier.fillMaxWidth().then(staggered()),
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(34.dp)
                    .graphicsLayer { val s = 1f - 0.1f * press; scaleX = s; scaleY = s }
                    .clip(RoundedCornerShape(11.dp))
                    .background(accent.copy(alpha = 0.12f + 0.1f * press)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, tint = accent, modifier = Modifier.size(19.dp)) }
            Spacer(Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, color = tint, fontWeight = FontWeight.Medium)
        }
    }
}

/** ردیف ری‌اکشن‌های تلگرامی: ایموجی‌های بزرگ در کپسول شیشه‌ای با فشار فنری. */
@Composable
fun ColumnScopeGlass.GlassReactions(mineEmoji: String?, onPick: (String) -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth().then(staggered()),
    ) {
        Column(Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
            listOf(
                listOf("❤️", "👍", "👎", "😂", "🔥", "🍓"),
                listOf("🍌", "🖕", "😢", "🤯", "💯", "🙏"),
            ).forEach { emojis ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically, ) {
            emojis.forEachIndexed { idx, em ->
                // هر ری‌اکشن انیمیشن اختصاصی خودش را دارد
                AnimatedReaction(
                    emoji = em,
                    index = idx,
                    mine = mineEmoji == em,
                ) { onPick(em); dismiss() }
            }
        }
            }
        }
    }
}

/** جداکننده ظریف منو. */
@Composable
fun ColumnScopeGlass.GlassDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
        Box(Modifier.fillMaxWidth().height(1.dp).then(staggered())
            .background(Brush.horizontalGradient(listOf(Color.Transparent, MaterialTheme.colorScheme.outlineVariant, Color.Transparent))))
    }
}
