package ir.studying.app.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * جعبه‌ابزار حرکت — مشترک میان زنگ، قفل، شبکهٔ اجتماعی و کاراکترها.
 *
 * چرا یک فایل: نسخهٔ ۲.۹ چهار بخش را با یک زبان بصری بازطراحی می‌کند (آسمان
 * شب، حلقهٔ مداری، کلید درخشان، ورود پلکانی). اگر هر بخش نسخهٔ خودش را
 * می‌ساخت، سرعت و منحنی انیمیشن‌ها از هم جدا می‌افتاد و اپ تکه‌تکه حس می‌شد.
 * همه‌چیز این‌جا فقط با Canvas و graphicsLayer کشیده می‌شود: نه تصویری،
 * نه کتابخانه‌ای، و روی گوشی ضعیف هم فقط مرحلهٔ «draw» تکرار می‌شود.
 */

private const val TAU = (2.0 * PI).toFloat()

private class Star(val x: Float, val y: Float, val r: Float, val phase: Float, val speed: Int)

/**
 * آسمان پرستاره با چشمک آرام.
 *
 * سرعت هر ستاره عدد صحیح است تا در لحظهٔ تکرارِ چرخه پرش نور دیده نشود.
 */
@Composable
fun StarField(
    modifier: Modifier = Modifier,
    count: Int = 42,
    seed: Int = 7,
    color: Color = Color.White,
    maxAlpha: Float = 0.9f,
) {
    val stars = remember(count, seed) {
        val rnd = kotlin.random.Random(seed)
        List(count) {
            Star(
                x = rnd.nextFloat(),
                y = rnd.nextFloat(),
                r = 0.5f + rnd.nextFloat() * rnd.nextFloat() * 1.9f,
                phase = rnd.nextFloat() * TAU,
                speed = 1 + rnd.nextInt(3),
            )
        }
    }
    val t = rememberInfiniteTransition(label = "stars")
    val time by t.animateFloat(
        0f, TAU,
        infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "starTime",
    )
    Canvas(modifier) {
        stars.forEach { s ->
            val a = (0.18f + 0.82f * (0.5f + 0.5f * sin(time * s.speed + s.phase))) * maxAlpha
            val c = Offset(s.x * size.width, s.y * size.height)
            val r = s.r * density
            drawCircle(color.copy(alpha = a), radius = r, center = c)
            if (s.r > 1.45f) {
                /* ستاره‌های درشت‌تر یک صلیب نوری ظریف هم دارند. */
                val l = r * 3.2f
                val sw = 0.7f * density
                drawLine(color.copy(alpha = a * 0.55f), c - Offset(l, 0f), c + Offset(l, 0f), sw, StrokeCap.Round)
                drawLine(color.copy(alpha = a * 0.55f), c - Offset(0f, l), c + Offset(0f, l), sw, StrokeCap.Round)
            }
        }
    }
}

/**
 * شفق: چند لکهٔ نور شعاعی که آرام روی زمینه شناورند.
 *
 * [base] گرادیان عمودی زمینه است و [blobs] رنگ لکه‌ها (بهتر است نیمه‌شفاف باشند).
 */
@Composable
fun AuroraBackdrop(
    modifier: Modifier = Modifier,
    base: List<Color>,
    blobs: List<Color>,
    periodMs: Int = 16000,
) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        0f, TAU,
        infiniteRepeatable(tween(periodMs, easing = LinearEasing)),
        label = "auroraPhase",
    )
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(base))
        blobs.forEachIndexed { i, c ->
            val ang = p * (if (i % 2 == 0) 1f else -1f) + i * 2.1f
            val cx = size.width * (0.5f + 0.42f * cos(ang))
            val cy = size.height * (0.32f + 0.30f * sin(ang + i))
            val r = size.maxDimension * (0.52f + 0.10f * sin(ang * 2f))
            drawCircle(
                Brush.radialGradient(listOf(c, c.copy(alpha = 0f)), center = Offset(cx, cy), radius = r),
                radius = r,
                center = Offset(cx, cy),
            )
        }
    }
}

/**
 * حلقهٔ پیشرفتِ مداری با سرِ درخشان.
 *
 * سرِ کمان یک هالهٔ نرم دارد و یک ماهوارهٔ کوچک دورِ حلقه می‌گردد تا معلوم
 * باشد چیزی «زنده» و در جریان است. پیشرفت از ساعت ۱۲ و ساعتگرد کشیده می‌شود.
 */
@Composable
fun OrbitRing(
    progress: Float,
    modifier: Modifier = Modifier,
    stroke: Dp = 8.dp,
    track: Color = Color.White.copy(alpha = 0.12f),
    colors: List<Color> = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary),
    satellite: Boolean = true,
    glow: Boolean = true,
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "orbitP")
    val t = rememberInfiniteTransition(label = "orbit")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "orbitSpin")
    val breathe by t.animateFloat(
        0.55f, 1f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "orbitGlow",
    )
    Canvas(modifier) {
        val sw = stroke.toPx()
        val inset = sw / 2f + sw * 0.9f
        val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
        val tl = Offset(inset, inset)
        val radius = arcSize.width / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        drawArc(track, 0f, 360f, false, tl, arcSize, style = Stroke(sw))

        val sweep = 360f * p
        if (sweep > 0.5f) {
            rotate(-90f, center) {
                val brush = Brush.sweepGradient(
                    colorStops = arrayOf(0f to colors.first(), (p.coerceAtLeast(0.01f)) to colors.last()),
                    center = center,
                )
                if (glow) {
                    drawArc(
                        colors.last().copy(alpha = 0.18f * breathe), 0f, sweep, false, tl, arcSize,
                        style = Stroke(sw * 2.6f, cap = StrokeCap.Round),
                    )
                }
                drawArc(brush, 0f, sweep, false, tl, arcSize, style = Stroke(sw, cap = StrokeCap.Round))
                /* درپوشِ ابتدای کمان؛ گرادیان جاروبی در زاویهٔ صفر درز دارد. */
                drawCircle(colors.first(), sw / 2f, Offset(center.x + radius, center.y))
                val a = Math.toRadians(sweep.toDouble())
                val head = Offset(center.x + radius * cos(a).toFloat(), center.y + radius * sin(a).toFloat())
                if (glow) {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(colors.last().copy(alpha = 0.55f * breathe), Color.Transparent),
                            center = head, radius = sw * 2.4f,
                        ),
                        radius = sw * 2.4f, center = head,
                    )
                }
                drawCircle(Color.White, sw * 0.32f, head)
            }
        }
        if (satellite) {
            val a = Math.toRadians((spin - 90f).toDouble())
            val r2 = radius + sw * 1.35f
            val sat = Offset(center.x + r2 * cos(a).toFloat(), center.y + r2 * sin(a).toFloat())
            drawCircle(colors.first().copy(alpha = 0.35f), sw * 0.55f, sat)
            drawCircle(Color.White.copy(alpha = 0.85f), sw * 0.22f, sat)
        }
    }
}

/**
 * کلید روشن/خاموشِ درخشان.
 *
 * دستهٔ کلید در حرکت کمی کش می‌آید (مثل قطرهٔ ژله) و در حالت روشن یک هالهٔ
 * رنگی پشت ریل می‌افتد. جهت با چیدمان راست‌به‌چپ هماهنگ است: روشن = سمت پایان.
 */
@Composable
fun GlowSwitch(
    checked: Boolean,
    onCheckedChange: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier,
    accent: Color = MaterialTheme.colorScheme.primary,
    accent2: Color = MaterialTheme.colorScheme.secondary,
    enabled: Boolean = true,
    icon: ImageVector? = null,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val pos by animateFloatAsState(
        if (checked) 1f else 0f,
        spring(dampingRatio = 0.58f, stiffness = 520f),
        label = "switchPos",
    )
    /* کشیدگی: وسط مسیر بیشترین است. */
    val stretch = 1f + 0.38f * (1f - kotlin.math.abs(pos * 2f - 1f))
    val w = 52.dp
    val h = 30.dp
    val thumb = 22.dp
    val pad = 4.dp
    Box(
        modifier
            .size(w, h)
            .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
            .drawBehind {
                if (pos > 0.02f) {
                    drawRoundRect(
                        Brush.horizontalGradient(listOf(accent.copy(alpha = 0.34f * pos), accent2.copy(alpha = 0.30f * pos))),
                        topLeft = Offset(-6.dp.toPx(), -5.dp.toPx()),
                        size = Size(size.width + 12.dp.toPx(), size.height + 10.dp.toPx()),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height),
                        alpha = 0.55f,
                    )
                }
            }
            .clip(CircleShape)
            .background(cs.surfaceVariant)
            .background(
                Brush.horizontalGradient(listOf(accent, accent2)),
                alpha = pos,
            )
            .border(1.dp, cs.outline.copy(alpha = 0.30f * (1f - pos)), CircleShape)
            .then(
                if (onCheckedChange != null) {
                    Modifier.toggleable(
                        value = checked,
                        enabled = enabled,
                        role = Role.Switch,
                        onValueChange = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onCheckedChange(it)
                        },
                    )
                } else Modifier,
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        val travel = w - thumb - pad * 2
        Box(
            Modifier
                .offset { IntOffset(((pad + travel * pos).toPx()).roundToInt(), 0) }
                .size(thumb * stretch, thumb)
                .graphicsLayer { shadowElevation = 4.dp.toPx(); shape = CircleShape; clip = true }
                .background(Color.White),
            contentAlignment = Alignment.Center,
        ) {
            if (icon != null) {
                Icon(
                    icon, null,
                    tint = lerp(cs.onSurfaceVariant.copy(alpha = 0.6f), accent, pos),
                    modifier = Modifier.size(13.dp),
                )
            }
        }
    }
}

/** نوار نوری که هر چند ثانیه از روی سطح عبور می‌کند — برای دکمه‌های اصلی. */
fun Modifier.shine(
    enabled: Boolean = true,
    periodMs: Int = 2800,
    color: Color = Color.White.copy(alpha = 0.32f),
): Modifier = if (!enabled) this else composed {
    val t = rememberInfiniteTransition(label = "shine")
    val p by t.animateFloat(
        -0.5f, 1.5f,
        infiniteRepeatable(tween(periodMs, delayMillis = 1200, easing = FastOutSlowInEasing)),
        label = "shineP",
    )
    drawWithContent {
        drawContent()
        val band = size.width * 0.32f
        val x = p * (size.width + band) - band
        drawRect(
            Brush.linearGradient(
                listOf(Color.Transparent, color, Color.Transparent),
                start = Offset(x, 0f),
                end = Offset(x + band, size.height),
            ),
        )
    }
}

/** فشردن فنری: سطح زیر انگشت کمی فرو می‌رود و با فنر برمی‌گردد. */
fun Modifier.bouncyClick(
    enabled: Boolean = true,
    pressedScale: Float = 0.95f,
    role: Role? = Role.Button,
    onClick: () -> Unit,
): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed && enabled) pressedScale else 1f,
        spring(dampingRatio = 0.45f, stiffness = 700f),
        label = "bouncy",
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interaction, indication = null, enabled = enabled, role = role, onClick = onClick)
}

/**
 * ورود پلکانی: کارت‌ها یکی‌یکی از پایین بالا می‌آیند.
 *
 * فقط بار اول اجرا می‌شود؛ وضعیتش ذخیره می‌شود تا ردیفی که با اسکرول از
 * لیست تنبل بیرون رفته و برگشته، دوباره نرقصد.
 */
fun Modifier.riseIn(index: Int = 0, distance: Dp = 26.dp): Modifier = composed {
    var played by rememberSaveable { mutableStateOf(false) }
    val anim = remember { Animatable(if (played) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!played) {
            kotlinx.coroutines.delay(index.coerceIn(0, 9) * 60L)
            anim.animateTo(1f, tween(460, easing = FastOutSlowInEasing))
            played = true
        }
    }
    graphicsLayer {
        val v = anim.value
        alpha = v
        translationY = (1f - v) * distance.toPx()
        val s = 0.965f + 0.035f * v
        scaleX = s
        scaleY = s
    }
}

/**
 * متن غلتان: هر نویسه که عوض شود، عمودی می‌غلتد (مثل ساعت‌های فرودگاهی).
 *
 * عمداً چپ‌به‌راست چیده می‌شود؛ در ردیف راست‌به‌چپ «۰۶:۳۰» برعکس می‌افتاد.
 */
@Composable
fun RollingText(text: String, style: TextStyle, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(modifier) {
            text.forEachIndexed { i, ch ->
                AnimatedContent(
                    targetState = ch,
                    transitionSpec = {
                        (slideInVertically(tween(320)) { it } + fadeIn(tween(220)))
                            .togetherWith(slideOutVertically(tween(320)) { -it } + fadeOut(tween(160)))
                            .using(SizeTransform(clip = true))
                    },
                    label = "roll$i",
                ) { c -> Text(c.toString(), style = style, color = color) }
            }
        }
    }
}

/** موج‌های هم‌مرکز که از مرکز بیرون می‌زنند — برای زنگ در حال نواختن و دکمه‌های زنده. */
@Composable
fun RippleRings(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    rings: Int = 3,
    periodMs: Int = 2400,
    strokeWidth: Dp = 2.dp,
    filled: Boolean = false,
) {
    val t = rememberInfiniteTransition(label = "ripples")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(periodMs, easing = LinearEasing)), label = "rippleP")
    Canvas(modifier) {
        val maxR = size.minDimension / 2f
        for (i in 0 until rings) {
            val f = (p + i.toFloat() / rings) % 1f
            val r = maxR * (0.35f + 0.65f * f)
            val a = (1f - f) * 0.7f
            if (filled) drawCircle(color.copy(alpha = a * 0.35f), r)
            drawCircle(color.copy(alpha = a), r, style = Stroke(strokeWidth.toPx()))
        }
    }
}

/** جرقه‌های کوچک چهارپر که دور یک سوژه سوسو می‌زنند. */
@Composable
fun Sparkles(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    count: Int = 7,
    seed: Int = 3,
) {
    val pts = remember(count, seed) {
        val rnd = kotlin.random.Random(seed)
        List(count) {
            Triple(Offset(rnd.nextFloat(), rnd.nextFloat()), rnd.nextFloat() * TAU, 0.6f + rnd.nextFloat() * 0.8f)
        }
    }
    val t = rememberInfiniteTransition(label = "sparkles")
    val time by t.animateFloat(0f, TAU, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "sparkT")
    Canvas(modifier) {
        pts.forEachIndexed { i, (o, ph, sc) ->
            val k = 0.5f + 0.5f * sin(time * (1 + i % 2) + ph)
            if (k < 0.12f) return@forEachIndexed
            val c = Offset(o.x * size.width, o.y * size.height)
            val r = 5.dp.toPx() * sc * k
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(c.x, c.y - r)
                quadraticBezierTo(c.x, c.y, c.x + r, c.y)
                quadraticBezierTo(c.x, c.y, c.x, c.y + r)
                quadraticBezierTo(c.x, c.y, c.x - r, c.y)
                quadraticBezierTo(c.x, c.y, c.x, c.y - r)
                close()
            }
            drawPath(path, color.copy(alpha = 0.35f + 0.65f * k))
        }
    }
}

/** پیل کوچکِ شیشه‌ای با آیکن/ایموجی — برچسب‌های اطلاعاتی روی زمینه‌های تیره. */
@Composable
fun GlassPill(
    text: String,
    modifier: Modifier = Modifier,
    leading: String? = null,
    tint: Color = Color.White,
    container: Color = Color.White.copy(alpha = 0.12f),
    style: TextStyle = MaterialTheme.typography.labelMedium,
) {
    Row(
        modifier
            .clip(CircleShape)
            .background(container)
            .border(1.dp, tint.copy(alpha = 0.16f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            Text(leading, style = style)
            Box(Modifier.size(5.dp))
        }
        Text(text, style = style, color = tint)
    }
}
