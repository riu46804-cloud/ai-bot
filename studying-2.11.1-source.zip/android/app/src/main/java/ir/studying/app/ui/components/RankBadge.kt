package ir.studying.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Game
import ir.studying.app.core.Ranks
import ir.studying.app.core.fa

/**
 * نشان لقب — «کیومرث»، «رستمِ دستان»، «سیمرغ» …
 *
 * چرا نشان جدا شد: قبلاً سطح فقط یک متن خشک بود («سطح ۴ · کوشا») و در سه صفحه با
 * سه شکل مختلف نوشته می‌شد. لقب‌های شاهنامه‌ای ارزش دیده‌شدن دارند، پس یک نشانِ
 * رنگی داریم که همه‌جا یکسان است و رنگش از خودِ رده می‌آید.
 */
@Composable
fun RankBadge(
    level: Int,
    title: String,
    emoji: String,
    modifier: Modifier = Modifier,
    levelKey: String? = null,
    compact: Boolean = false,
) {
    val c = Ranks.colorOf(level, levelKey, title)
    Row(
        modifier
            .clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(c.copy(alpha = 0.22f), c.copy(alpha = 0.08f))))
            .border(1.dp, c.copy(alpha = 0.35f), CircleShape)
            .padding(horizontal = if (compact) 8.dp else 11.dp, vertical = if (compact) 3.dp else 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = if (compact) 12.sp else 15.sp)
        Spacer(Modifier.width(5.dp))
        Text(
            title,
            style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
        )
        if (!compact) {
            Spacer(Modifier.width(6.dp))
            Text(
                ("سطح " + level.fa()),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * کارت «لقب من»: لقب، سطح، پیشرفت تا سطح بعد و لقب بعدی.
 *
 * عمداً فقط داده نشان می‌دهد؛ جملهٔ تبلیغاتی و توضیح ساختگی ندارد.
 * [onOpenLadder] نردبان کامل را باز می‌کند.
 */
@Composable
fun RankCard(g: Game.State, modifier: Modifier = Modifier, onOpenLadder: () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    val c = Ranks.colorOf(g.level, g.levelKey, g.levelTitle)
    val progress by animateFloatAsState(g.levelProgress, tween(600), label = "rankProgress")

    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(c.copy(alpha = 0.20f), c.copy(alpha = 0.05f))))
            .border(1.dp, c.copy(alpha = 0.28f), RoundedCornerShape(22.dp))
            .clickable(onClick = onOpenLadder)
            .padding(18.dp),
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(c.copy(alpha = 0.20f)),
                    contentAlignment = Alignment.Center,
                ) { Text(g.rankEmoji, fontSize = 26.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(g.rankTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        ("رده " + g.rankIndex.fa() + " از " + g.rankCount.fa()),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(g.level.fa(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = c)
                    Text("سطح", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.fillMaxWidth().height(9.dp).clip(CircleShape)
                    .background(cs.onSurfaceVariant.copy(alpha = 0.14f)),
            ) {
                Box(
                    Modifier.fillMaxWidth(progress).height(9.dp).clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(c.copy(alpha = 0.65f), c))),
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    ("تا سطح بعد: " + (g.nextLevelXp - g.xp).coerceAtLeast(0).fa() + " امتیاز"),
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    (g.xp.fa() + " امتیاز"),
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                )
            }

            if (g.nextRankTitle.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    ("لقب بعدی: " + g.nextRankTitle + " — از سطح " + g.nextRankLevel.fa()),
                    style = MaterialTheme.typography.labelMedium,
                    color = c,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}

/** نردبان کامل لقب‌ها: باز‌شده‌ها رنگی، قفل‌شده‌ها خاکستری با شرطشان. */
@Composable
fun RankLadderDialog(level: Int, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("نردبان لقب‌ها") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Ranks.all.forEach { t ->
                    val open = level >= t.minLevel
                    val mine = Ranks.of(level).key == t.key
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (mine) t.color.copy(alpha = 0.18f)
                                else if (open) cs.surfaceVariant
                                else cs.surfaceVariant.copy(alpha = 0.45f),
                            )
                            .border(
                                1.dp,
                                if (mine) t.color.copy(alpha = 0.45f) else cs.outlineVariant,
                                RoundedCornerShape(14.dp),
                            )
                            .padding(horizontal = 11.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (open) {
                            Text(t.emoji, fontSize = 18.sp)
                        } else {
                            Icon(
                                Icons.Rounded.Lock,
                                null,
                                tint = cs.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                t.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (mine) FontWeight.Bold else FontWeight.Normal,
                                color = if (open) cs.onSurface else cs.onSurfaceVariant,
                            )
                            Text(
                                ("از سطح " + t.minLevel.fa()),
                                style = MaterialTheme.typography.labelSmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        if (mine) {
                            Text(
                                "لقب فعلی",
                                style = MaterialTheme.typography.labelSmall,
                                color = t.color,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}
