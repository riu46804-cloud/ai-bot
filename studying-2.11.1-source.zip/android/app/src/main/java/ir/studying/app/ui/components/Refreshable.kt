@file:Suppress("DEPRECATION")
@file:OptIn(androidx.compose.material.ExperimentalMaterialApi::class)

package ir.studying.app.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.delay

/**
 * Pull to refresh, available to every list screen.
 *
 * Only the feed had this gesture, so on Home, Messages, Tasks, Library,
 * Community and Profile the habitual downward tug did nothing and the user had
 * to leave and re-enter the tab to force a reload. One wrapper now gives them
 * all the same behaviour with the app palette.
 *
 * [onRefresh] is fire and forget: the existing view models refresh through their
 * own coroutines and expose no completion signal, so the spinner is held for a
 * short, fixed beat. That is deliberate — a spinner that vanishes instantly
 * reads as "nothing happened".
 */
@Composable
fun Refreshable(
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    refreshing: Boolean? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    var selfRefreshing by remember { mutableStateOf(false) }
    val busy = refreshing ?: selfRefreshing

    val state = rememberPullRefreshState(busy, {
        onRefresh()
        if (refreshing == null) selfRefreshing = true
    })

    LaunchedEffect(selfRefreshing) {
        if (selfRefreshing) {
            delay(750)
            selfRefreshing = false
        }
    }

    Box(modifier.fillMaxSize().pullRefresh(state)) {
        content()
        PullRefreshIndicator(
            refreshing = busy,
            state = state,
            modifier = Modifier.align(Alignment.TopCenter),
            backgroundColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
        )
    }
}
