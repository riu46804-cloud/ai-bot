package ir.studying.app.ui.components

import ir.studying.app.R
import androidx.compose.ui.res.stringResource
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Jalali
import ir.studying.app.core.fa
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Flame1 = Color(0xFFFF7043)
private val Flame2 = Color(0xFFFFC107)
private val Ash = Color(0xFF3A2A20)

private val MILESTONES = listOf(3, 7, 14, 30, 60, 100, 200, 365)

private data class DayDot(val label: String, val active: Boolean, val isToday: Boolean)

/**
 * تنها کارت «وضعیت من» در پروفایل: شعلهٔ استریک، هفت روز گذشته، لقب و سطح،
 * امتیاز و سکه، رتبهٔ رقابتی و بهترین استریک.
 *
 * پیش از این دو کارت جدا بود (یکی «امتیاز و رقابت»، یکی «استریک من») که هر دو
 * XP و سکه و نشان لقب را تکرار می‌کردند و نیم صفحه را می‌خوردند؛ یکی شدند.
 */
@Composable
fun StreakCard(
    streak: Int,
    todayMinutes: Int,
    byDate: Map<String, Int> = emptyMap(),
    onClick: () -> Unit = {},
    xp: Int = 0,
    level: Int = 0,
    levelTitle: String = "",
    /* لقب اسطوره‌ای: ایموجی و کلیدِ رده برای رنگ درست نشان. */
    levelEmoji: String = "",
    levelKey: String = "",
    levelProgress: Float = 0f,
    coins: Int = 0,
    /** رتبهٔ کاربر در جدول رقابت؛ صفر یعنی هنوز رتبه‌ای ندارد. */
    rank: Int = 0,
    bestStreak: Int = 0,
    onOpenLadder: (() -> Unit)? = null,
    /* امتیاز تا سطح بعد و لقب بعدی؛ قبلاً فقط نوار پیشرفت بود و عدد مشخص نبود. */
    xpToNext: Int = 0,
    nextLevel: Int = 0,
    nextRankTitle: String = "",
    nextRankLevel: Int = 0,
    /** امتیاز جمع‌شده از دستاوردها؛ روی تراشهٔ «دستاوردها» نشان داده می‌شود. */
    awardXp: Int = 0,
    /** باز کردن پنجرهٔ دستاوردها؛ null یعنی تراشه نشان داده نشود. */
    onOpenAwards: (() -> Unit)? = null,
    missedDays: List<String> = emptyList(),
    reviveCost: Int = 0,
    onRevive: (String) -> Unit = {},
) {
    val next = MILESTONES.firstOrNull { it > streak } ?: (streak + 1)
    val prev = MILESTONES.lastOrNull { it <= streak } ?: 0
    val target = if (next > prev) ((streak - prev).toFloat() / (next - prev)).coerceIn(0f, 1f) else 0f
    val frac by animateFloatAsState(target, tween(900), label = "streakRing")

    val tier = when {
        streak <= 0 -> "شعله خاموشه"
        streak < 3 -> "جرقه"
        streak < 7 -> "شعله"
        streak < 14 -> "آتش"
        streak < 30 -> "کوره"
        streak < 100 -> "آتشفشان"
        else -> "افسانه"
    }
    val emoji = when {
        streak <= 0 -> "🌱"
        streak < 7 -> "🔥"
        streak < 30 -> "🔥"
        streak < 100 -> "🌋"
        else -> "🏆"
    }

    val t = rememberInfiniteTransition(label = "streak")
    val pulse by t.animateFloat(1f, 1.14f, infiniteRepeatable(tween(880), RepeatMode.Reverse), label = "pulse")
    val glow by t.animateFloat(0.18f, 0.52f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "glow")

    val dots = remember(byDate, todayMinutes) {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val out = ArrayList<DayDot>()
        for (i in 6 downTo 0) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -i)
            val iso = fmt.format(c.time)
            val label = Jalali.weekDayNames[Jalali.weekDayIndex(c.time)].take(1)
            val active = (byDate[iso] ?: 0) > 0 || (i == 0 && todayMinutes > 0)
            out.add(DayDot(label, active, i == 0))
        }
        out
    }

    val todayDone = todayMinutes > 0 || dots.lastOrNull()?.active == true

    Surface(shape = RoundedCornerShape(22.dp), color = Color.Transparent, onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(Ash, Color(0xFF120C09))))
                .padding(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(96.dp)) {
                    Box(
                        Modifier
                            .size(78.dp)
                            .background(Flame1.copy(alpha = glow * 0.45f), CircleShape)
                            .scale(pulse),
                    )
                    Canvas(Modifier.fillMaxSize()) {
                        val stroke = 7.dp.toPx()
                        drawArc(
                            Color.White.copy(alpha = 0.10f), -90f, 360f, false,
                            style = Stroke(stroke, cap = StrokeCap.Round),
                        )
                        drawArc(
                            Brush.sweepGradient(listOf(Flame1, Flame2, Flame1)),
                            -90f, 360f * frac, false,
                            style = Stroke(stroke, cap = StrokeCap.Round),
                        )
                    }
                    Text(emoji, fontSize = 34.sp, modifier = Modifier.scale(pulse))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            streak.fa(),
                            color = Color.White,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.streak_card_001),
                            color = Color.White.copy(alpha = 0.82f),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                    Surface(shape = CircleShape, color = Flame2.copy(alpha = 0.18f)) {
                        Text(
                            tier,
                            color = Flame2,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (streak >= next) "رکورد تازه!" else "${(next - streak).fa()} روز تا نشان ${next.fa()} روزه",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                dots.forEach { d ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(if (d.isToday) 30.dp else 26.dp)
                                .background(
                                    if (d.active) Flame1.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.08f),
                                    CircleShape,
                                )
                                .border(
                                    if (d.isToday) 2.dp else 0.dp,
                                    if (d.isToday) Flame2 else Color.Transparent,
                                    CircleShape,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (d.active) Text("🔥", fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(d.label, color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (level > 0) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val title = ir.studying.app.core.Ranks.titleFor(level, levelTitle)
                    val badgeEmoji = ir.studying.app.core.Ranks.emojiFor(level, levelEmoji)
                    // نشان لقب همان شکلِ پروفایل و لیدربورد را دارد؛ روی زمینهٔ تیرهٔ کارت.
                    RankBadge(level = level, title = title, emoji = badgeEmoji, levelKey = levelKey, compact = true)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "سطح " + level.fa(),
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                    Spacer(Modifier.weight(1f))
                    Text("⭐ " + xp.fa(), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.width(10.dp))
                    Text("🪙 " + coins.fa(), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelMedium)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).background(Color.White.copy(alpha = 0.08f), CircleShape)) {
                    Box(
                        Modifier
                            .fillMaxWidth(levelProgress.coerceIn(0f, 1f))
                            .height(8.dp)
                            .background(Brush.horizontalGradient(listOf(Flame1, Flame2)), CircleShape),
                    )
                }
                /* زیر نوار: فاصلهٔ دقیق تا سطح بعد و لقب بعدی، به‌جای حدس از طول نوار. */
                if (xpToNext > 0) {
                    Spacer(Modifier.height(6.dp))
                    val nl = if (nextLevel > 0) nextLevel else level + 1
                    val tail = if (nextRankTitle.isNotBlank())
                        " · لقب بعدی: " + nextRankTitle + (if (nextRankLevel > 0) " (سطح " + nextRankLevel.fa() + ")" else "")
                    else ""
                    Text(
                        (xpToNext.fa() + " امتیاز تا سطح " + nl.fa() + tail),
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                if (onOpenAwards != null) {
                    Spacer(Modifier.height(10.dp))
                    Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.10f), onClick = onOpenAwards) {
                        Text(
                            if (awardXp > 0) "🏅 دستاوردها · " + awardXp.fa() + " امتیاز" else "🏅 دستاوردها",
                            color = Color.White.copy(alpha = 0.9f),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                        )
                    }
                }
            }
            if (rank > 0 || bestStreak > 0 || onOpenLadder != null) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (rank > 0) {
                        Surface(shape = CircleShape, color = Flame2.copy(alpha = 0.16f)) {
                            Text(
                                "رتبه " + rank.fa() + " در رقابت",
                                color = Flame2,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    if (bestStreak > 0) {
                        Text(
                            "بهترین: " + bestStreak.fa() + " روز",
                            color = Color.White.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    if (onOpenLadder != null) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.10f),
                            onClick = onOpenLadder,
                        ) {
                            Text(
                                "نردبان لقب‌ها",
                                color = Color.White.copy(alpha = 0.9f),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                            )
                        }
                    }
                }
            }
            if (missedDays.isNotEmpty() && reviveCost > 0) {
                Spacer(Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Flame1.copy(alpha = 0.16f),
                    onClick = { onRevive(missedDays.first()) },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🧯", fontSize = 17.sp)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "استریکِ پریده را احیا کن",
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge,
                            )
                            Text(
                                missedDays.first() + " · " + reviveCost.fa() + " سکه",
                                color = Color.White.copy(alpha = 0.65f),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        Text("احیا", color = Flame2, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.07f), modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (todayDone) "امروز ثبت شد — شعله روشن موند ✅" else "امروز هنوز مطالعه‌ای ثبت نشده؛ نذار شعله خاموش شه",
                    color = if (todayDone) Flame2 else Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.labelMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp, horizontal = 8.dp),
                )
            }
        }
    }
}

@Suppress("unused")
private fun unusedDateHelper(): Date = Date()
