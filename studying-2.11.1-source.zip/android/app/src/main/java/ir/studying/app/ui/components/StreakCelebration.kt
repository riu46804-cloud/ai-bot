package ir.studying.app.ui.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.studying.app.core.Game
import ir.studying.app.core.IranTime
import ir.studying.app.core.fa
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * زمانِ نمایش جشن استریک.
 *
 * دقیقاً یک بار در روز و فقط بعد از اولین پارتی که همان روز ثبت می‌شود.
 *
 * باگی که اینجا رفع شد: عدد نمایش‌داده‌شده مستقیم از `game_state` می‌آمد، ولی
 * ثبتِ مطالعه آفلاین‌اول است و معمولاً هنوز روی سرور ننشسته؛ پس سرور «امروز» را
 * نمی‌دید و همیشه عدد دیروز (یا ۱) برمی‌گشت. حالا دو کار می‌کنیم:
 *  ۱) خودِ اپ زنجیره را محلی هم می‌شمارد و ذخیره می‌کند،
 *  ۲) اگر سرور هنوز امروز را ثبت نکرده باشد، یکی به مقدارش اضافه می‌کنیم.
 */
object StreakFx {
    private const val FILE = "studying_streak_fx"
    private const val K_REVIVE = "revive_dismissed"
    private val _reviveDismissed = MutableStateFlow("")
    private const val K_DAY = "celebrated_day"
    private const val K_LAST_DAY = "last_study_day"
    private const val K_LAST_STREAK = "last_streak"

    private var ctx: Context? = null

    private val _pending = MutableStateFlow(false)
    val pending: StateFlow<Boolean> get() = _pending

    /** حدس محلی زنجیره تا وقتی سرور جواب بدهد؛ هیچ‌وقت صفر یا عقب‌افتاده نیست. */
    private val _localStreak = MutableStateFlow(0)
    val localStreak: StateFlow<Int> get() = _localStreak

    fun init(context: Context) {
        ctx = context.applicationContext
        _localStreak.value = prefs()?.getInt(K_LAST_STREAK, 0) ?: 0
    }

    private fun prefs() = ctx?.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** از مسیر ثبت پارت صدا می‌شود؛ خودش تشخیص می‌دهد اولین پارتِ امروز بوده یا نه. */
    fun onStudyRecorded() {
        val p = prefs() ?: return
        val today = IranTime.todayIso()
        // شمارش محلی: اگر دیروز هم مطالعه بوده زنجیره ادامه دارد، وگرنه از ۱ شروع.
        val lastDay = p.getString(K_LAST_DAY, "") ?: ""
        val lastStreak = p.getInt(K_LAST_STREAK, 0)
        val guess = when (lastDay) {
            today -> lastStreak.coerceAtLeast(1)
            yesterdayIso(today) -> lastStreak + 1
            else -> 1
        }
        p.edit().putString(K_LAST_DAY, today).putInt(K_LAST_STREAK, guess).apply()
        _localStreak.value = guess
        if (p.getString(K_DAY, "") == today) return
        p.edit().putString(K_DAY, today).apply()
        _pending.value = true
    }

    /** مقدار تأییدشدهٔ سرور را نگه می‌داریم تا دفعهٔ بعد حدس محلی دقیق باشد. */
    fun syncFromServer(streak: Int, serverKnowsToday: Boolean) {
        if (streak <= 0) return
        val p = prefs() ?: return
        val today = IranTime.todayIso()
        val value = if (serverKnowsToday) streak else streak + 1
        if (value >= _localStreak.value) {
            _localStreak.value = value
            p.edit().putString(K_LAST_DAY, today).putInt(K_LAST_STREAK, value).apply()
        }
    }

    private fun yesterdayIso(todayIso: String): String = runCatching {
        val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val c = java.util.Calendar.getInstance()
        c.time = f.parse(todayIso)!!
        c.add(java.util.Calendar.DAY_OF_YEAR, -1)
        f.format(c.time)
    }.getOrDefault("")

    /** رد کردن همیشگیِ پیشنهاد احیای یک روز — دوباره نشان داده نمی‌شود. */
    fun dismissRevive(day: String) {
        prefs()?.edit()?.putString(K_REVIVE, day)?.apply()
        _reviveDismissed.value = day
    }

    fun reviveDismissed(day: String): Boolean = _reviveDismissed.value == day

    fun consume() { _pending.value = false }
}

private val Flame = Color(0xFFFF7043)
private val FlameDeep = Color(0xFFE64A19)
private val Gold = Color(0xFFFFC107)

private val FX_MILESTONES = listOf(3, 7, 14, 30, 60, 100, 200, 365)

/**
 * لایهٔ جشن استریک. در [ir.studying.app.ui.nav.MainScaffold] یک بار قرار می‌گیرد.
 */
@Composable
fun StreakCelebrationHost() {
    val pending by StreakFx.pending.collectAsState()
    val local by StreakFx.localStreak.collectAsState()
    val game by Game.state.collectAsState()

    /*
     * چند بار تلاش می‌کنیم: بلافاصله بعد از ثبت، معمولاً سشن هنوز در صف سینک
     * است. هر بار که سرور «امروز» را دید، مقدارش قطعی است و تلاش تمام می‌شود.
     */
    LaunchedEffect(pending) {
        if (!pending) return@LaunchedEffect
        repeat(5) {
            Game.refresh()
            val s = Game.state.value
            if (s.loaded) StreakFx.syncFromServer(s.streak, s.todayMinutes > 0)
            if (s.todayMinutes > 0) return@LaunchedEffect
            delay(2000)
        }
    }

    if (!pending) return

    // اگر سرور امروز را ندیده، عددش یکی عقب است؛ حدس محلی هم همیشه در دسترس است.
    val serverValue = if (game.loaded) {
        if (game.todayMinutes > 0) game.streak else game.streak + 1
    } else 0
    val streak = maxOf(serverValue, local, 1)

    StreakCelebration(streak = streak, xp = game.xp, coins = game.coins) {
        StreakFx.consume()
    }
}

/* =============================================================================
 *  جشن استریک — نسخهٔ سینمایی
 *
 *  بازخورد کاربر: نسخهٔ قبلی «خیلی ساده» بود. حالا یک نمایش چندثانیه‌ایِ
 *  مرحله‌ای داریم: شعلهٔ واقعی (Canvas) که روشن می‌شود و می‌لرزد، شمارش عدد با
 *  تیک‌های لرزشی، نوار هفت‌روزه که یکی‌یکی پر می‌شود و در آخر جوایز و دکمه.
 * ========================================================================== */
@Composable
fun StreakCelebration(
    streak: Int,
    xp: Int = 0,
    coins: Int = 0,
    onDismiss: () -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        val ctx = LocalContext.current
        val pop = remember { Animatable(0f) }      // ورود شعله
        val shake = remember { Animatable(0f) }    // لرزش شعله
        val burst = remember { Animatable(0f) }    // موج ترکش
        var shown by remember { mutableIntStateOf(0) }
        var phase by remember { mutableIntStateOf(0) }   // ۰ شعله، ۱ عدد، ۲ هفته، ۳ جوایز

        /* کارگردانیِ کل نمایش در یک جا تا زمان‌بندی‌ها به‌هم نریزد (~۴ ثانیه). */
        LaunchedEffect(streak) {
            buzz(ctx, longArrayOf(0, 60, 40, 90))
            pop.animateTo(
                1f,
                keyframes {
                    durationMillis = 620
                    0.2f at 0
                    1.18f at 380 using FastOutSlowInEasing
                    0.94f at 500
                    1f at 620
                },
            )
            phase = 1
            // شمارش عدد با تیک لرزشی؛ هرچه استریک بلندتر، تیک‌ها سریع‌تر
            val steps = streak.coerceAtMost(30)
            val step = (streak / steps.coerceAtLeast(1)).coerceAtLeast(1)
            var v = 0
            while (v < streak) {
                v = (v + step).coerceAtMost(streak)
                shown = v
                tick(ctx)
                delay(if (streak > 20) 26L else 60L)
            }
            buzz(ctx, longArrayOf(0, 40, 30, 70, 30, 120))
            burst.animateTo(1f, tween(760, easing = LinearEasing))
            shake.animateTo(
                0f,
                keyframes {
                    durationMillis = 620
                    0f at 0
                    1f at 70
                    (-1f) at 150
                    0.7f at 230
                    (-0.55f) at 320
                    0.3f at 420
                    0f at 620
                },
            )
            phase = 2
            delay(620)
            phase = 3
        }

        val t = rememberInfiniteTransition(label = "fx")
        val flicker by t.animateFloat(
            0f, 1f,
            infiniteRepeatable(tween(760, easing = LinearEasing)), label = "flicker",
        )
        val glow by t.animateFloat(
            0.30f, 0.85f,
            infiniteRepeatable(tween(860, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "glow",
        )
        val spin by t.animateFloat(
            0f, 1f,
            infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "spin",
        )

        val embers = remember {
            List(34) {
                EmberSpec(
                    angle = Random.nextFloat() * 360f,
                    dist = 0.35f + Random.nextFloat() * 0.65f,
                    radius = 2.5f + Random.nextFloat() * 5.5f,
                    speed = 0.6f + Random.nextFloat() * 0.9f,
                    gold = Random.nextBoolean(),
                )
            }
        }

        val next = FX_MILESTONES.firstOrNull { it > streak }

        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(Color(0xFF20140C), Color(0xFF070504)))),
            contentAlignment = Alignment.Center,
        ) {
            // ذرات و موج انفجار
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2f, size.height / 2f - 90f)
                if (burst.value > 0f) {
                    val r = size.minDimension * 0.55f * burst.value
                    drawCircle(
                        color = Gold.copy(alpha = (1f - burst.value) * 0.35f),
                        radius = r, center = c,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f * (1f - burst.value) + 1f),
                    )
                }
                embers.forEach { e ->
                    val rad = Math.toRadians((e.angle + spin * 360f * e.speed).toDouble())
                    val wobble = sin((flicker * 6.28f + e.angle).toDouble()).toFloat() * 8f
                    val radius = size.minDimension * 0.40f * e.dist * pop.value
                    drawCircle(
                        color = (if (e.gold) Gold else Flame).copy(alpha = 0.55f * glow),
                        radius = e.radius * pop.value,
                        center = Offset(
                            c.x + (cos(rad) * radius).toFloat(),
                            c.y + (sin(rad) * radius).toFloat() + wobble,
                        ),
                    )
                }
            }

            Column(
                Modifier.fillMaxWidth().padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // شعلهٔ اصلی: کشیده‌شده با Canvas، با تپش و لرزش
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(190.dp)
                        .scale(pop.value)
                        .rotate(shake.value * 7f),
                ) {
                    Box(
                        Modifier
                            .size(170.dp)
                            .background(
                                Brush.radialGradient(
                                    listOf(Flame.copy(alpha = 0.34f * glow), Color.Transparent),
                                ),
                                CircleShape,
                            ),
                    )
                    FlameCanvas(flicker = flicker, glow = glow, modifier = Modifier.size(150.dp))
                }

                Spacer(Modifier.height(4.dp))
                AnimatedVisibility(visible = phase >= 1, enter = fadeIn(tween(240)) + scaleIn(initialScale = 0.7f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(shown.fa(), color = Gold, fontSize = 74.sp, fontWeight = FontWeight.Black)
                        Text("روز پیاپی!", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(14.dp))
                AnimatedVisibility(
                    visible = phase >= 2,
                    enter = fadeIn(tween(280)) + slideInVertically(tween(320)) { it / 2 },
                ) { WeekStrip(streak) }

                Spacer(Modifier.height(14.dp))
                AnimatedVisibility(
                    visible = phase >= 3,
                    enter = fadeIn(tween(300)) + slideInVertically(tween(340)) { it / 2 },
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            when {
                                streak <= 1 -> "شعله روشن شد — فردا هم بیا!"
                                next != null -> "تا نشان ${next.fa()} روزه فقط ${(next - streak).fa()} روز مانده"
                                else -> "افسانه‌ای! شعله‌ات خاموش‌شدنی نیست"
                            },
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FxPill("⭐ " + xp.fa(), "امتیاز")
                            FxPill("\uD83E\uDE99 " + coins.fa(), "سکه")
                            if (next != null) FxPill((next - streak).fa(), "روز تا نشان " + next.fa())
                        }
                        Spacer(Modifier.height(22.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF241704)),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                        ) { Text("ادامه بدم!", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                    }
                }
            }
        }
    }
}

private data class EmberSpec(
    val angle: Float,
    val dist: Float,
    val radius: Float,
    val speed: Float,
    val gold: Boolean,
)

/** شعلهٔ برداری: دو لایه (بیرونی نارنجی، درونی طلایی) با نوسان زنده. */
@Composable
private fun FlameCanvas(flicker: Float, glow: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val wob = sin((flicker * 2 * Math.PI).toFloat()) * 0.035f
        fun flamePath(scale: Float, lean: Float): Path {
            val p = Path()
            val cx = w / 2f
            val top = h * (0.06f + (1f - scale) * 0.18f)
            val bottom = h * 0.95f
            val half = w * 0.30f * scale
            p.moveTo(cx + lean * w * 0.04f, top)
            p.cubicTo(
                cx + half * 1.15f, h * 0.30f,
                cx + half * 1.35f, h * 0.62f,
                cx + half * 0.55f, bottom,
            )
            p.cubicTo(
                cx, h * 1.02f,
                cx - half * 0.55f, bottom,
                cx - half * 1.30f, h * 0.60f,
            )
            p.cubicTo(
                cx - half * 1.05f, h * 0.30f,
                cx - half * 0.45f, h * 0.24f,
                cx + lean * w * 0.04f, top,
            )
            p.close()
            return p
        }
        drawPath(
            flamePath(1f + wob, sin((flicker * 6.28f).toDouble()).toFloat()),
            brush = Brush.verticalGradient(listOf(Flame, FlameDeep)),
        )
        drawPath(
            flamePath(0.62f - wob, -sin((flicker * 6.28f).toDouble()).toFloat()),
            brush = Brush.verticalGradient(listOf(Color(0xFFFFE082), Gold)),
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.55f * glow),
            radius = w * 0.07f,
            center = Offset(w / 2f, h * 0.78f),
        )
    }
}

/** هفت روز آخر: دایره‌های پرشونده، آخری برجسته. */
@Composable
private fun WeekStrip(streak: Int) {
    val filled = streak.coerceAtMost(7)
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
        (0 until 7).forEach { i ->
            val on = i < filled
            val isLast = i == filled - 1
            var appear by remember(streak, i) { mutableStateOf(false) }
            LaunchedEffect(streak, i) { delay(i * 90L); appear = true }
            val scale by androidx.compose.animation.core.animateFloatAsState(
                if (appear && on) (if (isLast) 1.18f else 1f) else 0.7f,
                spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium),
                label = "day$i",
            )
            Box(
                Modifier
                    .size(if (isLast) 34.dp else 28.dp)
                    .scale(scale)
                    .background(
                        if (on) Brush.verticalGradient(listOf(Gold, Flame))
                        else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.06f))),
                        CircleShape,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (on) "🔥" else "·",
                    fontSize = if (isLast) 17.sp else 13.sp,
                    color = Color.White.copy(alpha = 0.6f),
                )
            }
        }
    }
}

@Composable
private fun FxPill(value: String, label: String) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White.copy(alpha = 0.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
    ) {
        Column(
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(label, color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
        }
    }
}

/* --------------------------------------------------------------------------
 *  لرزش واقعی دستگاه (نه فقط هپتیکِ لمس) — دولینگو هم همین حس را می‌دهد.
 * ------------------------------------------------------------------------ */

private fun vibrator(ctx: Context): Vibrator? = runCatching {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
}.getOrNull()

private fun buzz(ctx: Context, pattern: LongArray) {
    runCatching {
        val v = vibrator(ctx) ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(pattern, -1)
        }
    }
}

/** تیک کوتاه هنگام بالا رفتن عدد. */
private fun tick(ctx: Context) {
    runCatching {
        val v = vibrator(ctx) ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(12, 40))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(12)
        }
    }
}
