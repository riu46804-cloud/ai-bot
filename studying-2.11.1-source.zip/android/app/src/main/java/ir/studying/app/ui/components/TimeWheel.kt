package ir.studying.app.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.fa

/**
 * انتخاب ساعت: ساعت چپ، دقیقه راست — همیشه.
 *
 * `TimePicker` متریال با چیدمان راست‌به‌چپ آینه می‌شود و دقیقه را سمت چپ
 * می‌اندازد؛ برای عددِ ساعت که همه‌جای دنیا «HH:MM» خوانده می‌شود این غلط است.
 * پس این ردیف با `LayoutDirection.Ltr` رسم می‌شود، مستقل از زبان اپ.
 * کشیدن انگشت روی هر ستون عدد را جلو و عقب می‌برد، دو فلش هم برای دقتِ تک‌واحدی.
 *
 * ظاهر ۲.۹: هر ستون یک «استوانهٔ» سه‌بعدی است — عدد قبلی و بعدی روی محور X
 * خم شده‌اند و عدد فعلی داخل یک پنجرهٔ شیشه‌ای می‌غلتد. [onDark] برای وقتی است
 * که چرخ روی آسمان شبِ ویرایشگر زنگ نشسته و رنگ‌ها باید روشن باشند.
 */
@Composable
fun TimeDial(
    hour: Int,
    minute: Int,
    onHour: (Int) -> Unit,
    onMinute: (Int) -> Unit,
    onDark: Boolean = false,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(28.dp)
    val blink by rememberInfiniteTransition(label = "colon").animateFloat(
        1f, 0.25f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "colonBlink",
    )
    Box(
        Modifier
            .fillMaxWidth()
            .then(
                if (onDark) Modifier
                else Modifier
                    .clip(shape)
                    .background(
                        Brush.verticalGradient(
                            listOf(lerp(cs.surface, cs.primary, 0.12f), lerp(cs.surface, cs.secondary, 0.05f)),
                        ),
                    )
                    .border(1.dp, cs.primary.copy(alpha = 0.22f), shape),
            ),
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = if (onDark) 4.dp else 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                TimeWheel(value = hour, range = 24, caption = "ساعت", onDark = onDark, onChange = onHour)
                Text(
                    ":",
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    color = if (onDark) Color.White else cs.primary,
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 18.dp)
                        .graphicsLayer { alpha = blink },
                )
                TimeWheel(value = minute, range = 60, caption = "دقیقه", onDark = onDark, onChange = onMinute)
            }
        }
    }
}

/** یک ستون عدد: عدد قبلی و بعدی خمیده و کم‌رنگ، عدد فعلی درشت و غلتان. */
@Composable
private fun TimeWheel(value: Int, range: Int, caption: String, onDark: Boolean, onChange: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val cur by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    var acc by remember { mutableStateOf(0f) }
    var dir by remember { mutableIntStateOf(1) }

    val ink = if (onDark) Color.White else cs.onSurface
    val faint = if (onDark) Color.White.copy(alpha = 0.38f) else cs.onSurfaceVariant.copy(alpha = 0.42f)
    val window = if (onDark) Color.White.copy(alpha = 0.10f) else cs.surface.copy(alpha = 0.75f)
    val windowBorder = if (onDark) Color.White.copy(alpha = 0.22f) else cs.primary.copy(alpha = 0.35f)
    val shape = RoundedCornerShape(24.dp)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        ArrowButton(up = true, onDark = onDark) { dir = 1; cb((cur + 1) % range) }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .width(112.dp)
                .clip(shape)
                .pointerInput(range) {
                    /* آستانه بر حسب dp حساب می‌شود، نه پیکسل: با پیکسلِ خام،
                       روی نمایشگر پرتراکم چرخ بیش از حد حساس می‌شد. */
                    val step = 16.dp.toPx()
                    detectVerticalDragGestures(
                        onDragEnd = { acc = 0f },
                        onDragCancel = { acc = 0f },
                    ) { _, dy ->
                        /* بالا کشیدن = جلو رفتن. */
                        acc -= dy
                        while (acc >= step) { acc -= step; dir = 1; cb((cur + 1) % range) }
                        while (acc <= -step) { acc += step; dir = -1; cb((cur - 1 + range) % range) }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            /* پنجرهٔ شیشه‌ای وسط، پشت عدد فعلی. */
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(window)
                    .border(1.dp, windowBorder, RoundedCornerShape(20.dp)),
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(vertical = 4.dp)) {
                Text(
                    two((cur - 1 + range) % range),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = faint,
                    modifier = Modifier.graphicsLayer { rotationX = 42f; scaleX = 0.86f; scaleY = 0.86f; cameraDistance = 8f * density },
                )
                AnimatedContent(
                    targetState = cur,
                    transitionSpec = {
                        val up = dir >= 0
                        (slideInVertically(tween(200)) { h -> if (up) h else -h } + fadeIn(tween(160)))
                            .togetherWith(slideOutVertically(tween(200)) { h -> if (up) -h else h } + fadeOut(tween(140)))
                    },
                    label = "wheel",
                ) { v ->
                    Text(two(v), fontSize = 50.sp, fontWeight = FontWeight.Black, color = ink)
                }
                Text(
                    two((cur + 1) % range),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = faint,
                    modifier = Modifier.graphicsLayer { rotationX = -42f; scaleX = 0.86f; scaleY = 0.86f; cameraDistance = 8f * density },
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        ArrowButton(up = false, onDark = onDark) { dir = -1; cb((cur - 1 + range) % range) }
        Spacer(Modifier.height(2.dp))
        Text(
            caption,
            style = MaterialTheme.typography.labelSmall,
            color = if (onDark) Color.White.copy(alpha = 0.65f) else cs.onSurfaceVariant,
        )
    }
}

@Composable
private fun ArrowButton(up: Boolean, onDark: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(width = 46.dp, height = 28.dp)
            .clip(CircleShape)
            .background(if (onDark) Color.White.copy(alpha = 0.10f) else cs.primary.copy(alpha = 0.10f))
            .bouncyClick(pressedScale = 0.88f, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (up) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
            if (up) "بیشتر" else "کمتر",
            tint = if (onDark) Color.White.copy(alpha = 0.8f) else cs.primary,
            modifier = Modifier.size(20.dp),
        )
    }
}

private fun two(v: Int): String = (if (v < 10) "0$v" else "$v").fa()
