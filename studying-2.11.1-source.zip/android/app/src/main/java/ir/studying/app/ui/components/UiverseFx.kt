package ir.studying.app.ui.components

/* =========================================================================
   UiverseFx — بازنویسی کامپوزی افکت‌های Uiverse

   معادل‌های Compose برای:
     • JkHuger / warm-panther-74  → FireworkCheck + SliceText  (چک‌لیست تسک‌ها)
     • catraco / plastic-moth-91  → HeartLike                  (دکمهٔ لایک)
     • catraco play-pause         → PlayPauseToggle            (پخش/توقف ویدئو)
     • catraco microphone         → MicToggle                  (ضبط ویس)
     • catraco clipboard          → CopyButton                 (کپی کردن)
     • vinodjangid07 pin          → PinToggle                  (سنجاق کردن)

   هیچ‌کدام به WebView یا فایل SVG نیاز ندارند؛ مسیرهای SVG با addPathNodes
   به ImageVector تبدیل می‌شوند و انیمیشن‌ها با Animatable بازسازی شده‌اند.
   ========================================================================= */

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.launch

/* ----------------------------------------------------------------------- */
/* مسیرهای SVG (همان path هایی که در طرح‌های Uiverse بود)                    */
/* ----------------------------------------------------------------------- */

private fun svg(path: String, vw: Float, vh: Float): ImageVector =
    ImageVector.Builder(
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = vw,
        viewportHeight = vh,
    ).addPath(addPathNodes(path), fill = SolidColor(Color.White)).build()

private val HeartOutlinePath =
    "M17.5,1.917a6.4,6.4,0,0,0-5.5,3.3,6.4,6.4,0,0,0-5.5-3.3A6.8,6.8,0,0,0,0,8.967c0,4.547,4.786,9.513,8.8,12.88a4.974,4.974,0,0,0,6.4,0C19.214,18.48,24,13.514,24,8.967A6.8,6.8,0,0,0,17.5,1.917Zm-3.585,18.4a2.973,2.973,0,0,1-3.83,0C4.947,16.006,2,11.87,2,8.967a4.8,4.8,0,0,1,4.5-5.05A4.8,4.8,0,0,1,11,8.967a1,1,0,0,0,2,0,4.8,4.8,0,0,1,4.5-5.05A4.8,4.8,0,0,1,22,8.967C22,11.87,19.053,16.006,13.915,20.313Z"

private val HeartFilledPath =
    "M17.5,1.917a6.4,6.4,0,0,0-5.5,3.3,6.4,6.4,0,0,0-5.5-3.3A6.8,6.8,0,0,0,0,8.967c0,4.547,4.786,9.513,8.8,12.88a4.974,4.974,0,0,0,6.4,0C19.214,18.48,24,13.514,24,8.967A6.8,6.8,0,0,0,17.5,1.917Z"

private val PlayPath =
    "M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"

private val PausePath =
    "M48 64C21.5 64 0 85.5 0 112V400c0 26.5 21.5 48 48 48H80c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48H48zm192 0c-26.5 0-48 21.5-48 48V400c0 26.5 21.5 48 48 48h32c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48H240z"

private val MicPath =
    "M192 0C139 0 96 43 96 96V256c0 53 43 96 96 96s96-43 96-96V96c0-53-43-96-96-96zM64 216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 89.1 66.2 162.7 152 174.4V464H120c-13.3 0-24 10.7-24 24s10.7 24 24 24h72 72c13.3 0 24-10.7 24-24s-10.7-24-24-24H216V430.4c85.8-11.7 152-85.3 152-174.4V216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 70.7-57.3 128-128 128s-128-57.3-128-128V216z"

private val MicSlashPath =
    "M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2S-1.2 34.7 9.2 42.9l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7L472.1 344.7c15.2-26 23.9-56.3 23.9-88.7V216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 21.2-5.1 41.1-14.2 58.7L416 300.8V96c0-53-43-96-96-96s-96 43-96 96v54.3L38.8 5.1zM344 430.4c20.4-2.8 39.7-9.1 57.3-18.2l-43.1-33.9C346.1 382 333.3 384 320 384c-70.7 0-128-57.3-128-128v-8.7L144.7 210c-.5 1.9-.7 3.9-.7 6v40c0 89.1 66.2 162.7 152 174.4V464H248c-13.3 0-24 10.7-24 24s10.7 24 24 24h72 72c13.3 0 24-10.7 24-24s-10.7-24-24-24H344V430.4z"

private val ClipboardPath =
    "M280 64h40c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128C0 92.7 28.7 64 64 64h40 9.6C121 27.5 153.3 0 192 0s71 27.5 78.4 64H280zM64 112c-8.8 0-16 7.2-16 16V448c0 8.8 7.2 16 16 16H320c8.8 0 16-7.2 16-16V128c0-8.8-7.2-16-16-16H304v24c0 13.3-10.7 24-24 24H192 104c-13.3 0-24-10.7-24-24V112H64zm128-8a24 24 0 1 0 0-48 24 24 0 1 0 0 48z"

private val ClipboardCheckPath =
    "M192 0c-41.8 0-77.4 26.7-90.5 64H64C28.7 64 0 92.7 0 128V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V128c0-35.3-28.7-64-64-64H282.5C269.4 26.7 233.8 0 192 0zm0 64a32 32 0 1 1 0 64 32 32 0 1 1 0-64zM305 273L177 401c-9.4 9.4-24.6 9.4-33.9 0L79 337c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L271 239c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"

private val IcHeartOutline = svg(HeartOutlinePath, 24f, 24f)
private val IcHeartFilled = svg(HeartFilledPath, 24f, 24f)
private val IcPlay = svg(PlayPath, 384f, 512f)
private val IcPause = svg(PausePath, 320f, 512f)
private val IcMic = svg(MicPath, 384f, 512f)
private val IcMicSlash = svg(MicSlashPath, 640f, 512f)
private val IcClipboard = svg(ClipboardPath, 384f, 512f)
private val IcClipboardCheck = svg(ClipboardCheckPath, 384f, 512f)

/** رنگ قلب طرح اصلی: rgb(255, 91, 137) */
val HeartColor = Color(0xFFFF5B89)

/* =========================================================================
   ۱) FireworkCheck — چک‌باکس تسک با تیک انیمیشنی، ترقه و لرزش ریز
   ========================================================================= */

@Composable
fun FireworkCheck(
    checked: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    busy: Boolean = false,
    boxSize: Dp = 26.dp,
    color: Color = MaterialTheme.colorScheme.primary,
    idleColor: Color = MaterialTheme.colorScheme.outline,
) {
    val haptic = LocalHapticFeedback.current

    // پیشرفت کشیدن دو خط تیک — معادل keyframes check-01 / check-02
    val tick by animateFloatAsState(
        if (checked) 1f else 0f,
        tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "tick",
    )
    val burst = remember { Animatable(0f) }   // @keyframes firework
    val shake = remember { Animatable(0f) }   // لرزش ریز هنگام تیک خوردن
    var firstPass by remember { mutableStateOf(true) }

    LaunchedEffect(checked) {
        if (firstPass) { firstPass = false; return@LaunchedEffect }
        if (checked) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            launch {
                burst.snapTo(0f)
                burst.animateTo(1f, tween(500, delayMillis = 90, easing = LinearEasing))
            }
            launch {
                // سه رفت‌وبرگشت خیلی کوتاه، بعد برگشت به مرکز
                shake.animateTo(
                    0f,
                    keyframes {
                        durationMillis = 260
                        0f at 0
                        1f at 40
                        (-1f) at 85
                        0.7f at 130
                        (-0.5f) at 175
                        0.25f at 215
                        0f at 260
                    },
                )
            }
        } else {
            burst.snapTo(0f)
        }
    }

    val ringColor = if (checked) color else idleColor

    Box(
        modifier
            .size(boxSize + 20.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled && !busy) { onToggle() },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = color)
            return@Box
        }
        Canvas(
            Modifier
                .size(boxSize + 20.dp)
                .graphicsLayer { translationX = shake.value * 2.2f * density },
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val box = boxSize.toPx()
            val r = 8.dp.toPx()
            val stroke = 2.dp.toPx()

            // کادر چک‌باکس
            drawRoundRect(
                color = ringColor,
                topLeft = Offset(cx - box / 2f, cy - box / 2f),
                size = androidx.compose.ui.geometry.Size(box, box),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
                style = androidx.compose.ui.graphics.drawscope.Stroke(stroke),
            )
            if (checked) {
                drawRoundRect(
                    color = color.copy(alpha = 0.16f * tick),
                    topLeft = Offset(cx - box / 2f, cy - box / 2f),
                    size = androidx.compose.ui.geometry.Size(box, box),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
                )
            }

            // تیک: خط کوتاه (۰ تا ۰٫۴۵) و خط بلند (۰٫۴۵ تا ۱)
            if (tick > 0f) {
                val a = Offset(cx - box * 0.24f, cy + box * 0.02f)
                val b = Offset(cx - box * 0.06f, cy + box * 0.20f)
                val c = Offset(cx + box * 0.26f, cy - box * 0.20f)
                val p1 = (tick / 0.45f).coerceIn(0f, 1f)
                val p2 = ((tick - 0.45f) / 0.55f).coerceIn(0f, 1f)
                drawLine(
                    color, a,
                    Offset(a.x + (b.x - a.x) * p1, a.y + (b.y - a.y) * p1),
                    strokeWidth = stroke * 1.25f, cap = StrokeCap.Round,
                )
                if (p2 > 0f) {
                    drawLine(
                        color, b,
                        Offset(b.x + (c.x - b.x) * p2, b.y + (c.y - b.y) * p2),
                        strokeWidth = stroke * 1.25f, cap = StrokeCap.Round,
                    )
                }
            }

            // ترقه: شش نقطه که بیرون می‌پاشند و محو می‌شوند
            val f = burst.value
            if (f > 0f && f < 1f) {
                val dist = (box * 0.55f) + (box * 0.75f) * f
                val dot = (2.4f.dp.toPx()) * (1f - f * 0.6f)
                val alpha = (1f - f).coerceIn(0f, 1f)
                for (i in 0 until 6) {
                    val ang = (PI / 3.0) * i - PI / 2.0
                    drawCircle(
                        color = color.copy(alpha = alpha),
                        radius = dot,
                        center = Offset(cx + (cos(ang) * dist).toFloat(), cy + (sin(ang) * dist).toFloat()),
                    )
                }
            }
        }
    }
}

/* =========================================================================
   ۲) SliceText — خطِ خط‌خوردگی که مثل @keyframes slice روی متن کشیده می‌شود
   ========================================================================= */

@Composable
fun SliceText(
    text: String,
    done: Boolean,
    style: TextStyle,
    activeColor: Color,
    doneColor: Color,
    modifier: Modifier = Modifier,
) {
    val slice by animateFloatAsState(
        if (done) 1f else 0f,
        tween(400, easing = FastOutSlowInEasing),
        label = "slice",
    )
    // معادل @keyframes move: متن موقع تیک خوردن کمی جابه‌جا می‌شود
    val shift by animateFloatAsState(
        if (done) 1f else 0f,
        tween(300, delayMillis = 100, easing = FastOutSlowInEasing),
        label = "move",
    )
    val lineColor = doneColor
    Text(
        text = text,
        style = style,
        color = androidx.compose.ui.graphics.lerp(activeColor, doneColor, slice),
        modifier = modifier
            .graphicsLayer { translationX = -shift * 6f * density }
            .drawWithContent {
                drawContent()
                if (slice > 0f) {
                    val y = size.height / 2f + 1f
                    // در RTL خط از راست به چپ کشیده می‌شود
                    drawLine(
                        color = lineColor,
                        start = Offset(size.width, y),
                        end = Offset(size.width - size.width * slice, y),
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round,
                    )
                }
            },
    )
}

/* =========================================================================
   ۳) HeartLike — قلب با انیمیشن پرشدن و جرقه‌های جشن
   ========================================================================= */

@Composable
fun HeartLike(
    liked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 26.dp,
    color: Color = HeartColor,
    idleColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    val haptic = LocalHapticFeedback.current
    val pop = remember { Animatable(1f) }        // keyframes-svg-filled
    val celebrate = remember { Animatable(0f) }  // keyframes-svg-celebrate
    var firstPass by remember { mutableStateOf(true) }

    LaunchedEffect(liked) {
        if (firstPass) { firstPass = false; return@LaunchedEffect }
        if (liked) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            launch {
                pop.snapTo(0f)
                pop.animateTo(
                    1f,
                    keyframes {
                        durationMillis = 600
                        0f at 0
                        1.25f at 150
                        0.95f at 300
                        1f at 600
                    },
                )
            }
            launch {
                celebrate.snapTo(0f)
                celebrate.animateTo(1f, tween(500, easing = LinearEasing))
            }
        } else {
            celebrate.snapTo(0f)
            pop.snapTo(1f)
        }
    }

    Box(
        modifier
            .size(size + 16.dp)
            .clip(CircleShape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        // جرقه‌ها
        val f = celebrate.value
        if (f > 0f && f < 1f) {
            Canvas(Modifier.size(size + 16.dp)) {
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f
                val base = size.toPx() * 0.55f
                val len = size.toPx() * 0.22f
                val alpha = (1f - f).coerceIn(0f, 1f)
                for (i in 0 until 6) {
                    val ang = (PI / 3.0) * i - PI / 2.0
                    val r0 = base + base * 0.55f * f
                    val sx = cx + (cos(ang) * r0).toFloat()
                    val sy = cy + (sin(ang) * r0).toFloat()
                    val ex = cx + (cos(ang) * (r0 + len)).toFloat()
                    val ey = cy + (sin(ang) * (r0 + len)).toFloat()
                    drawLine(color.copy(alpha = alpha), Offset(sx, sy), Offset(ex, ey), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                }
            }
        }
        Icon(
            imageVector = if (liked) IcHeartFilled else IcHeartOutline,
            contentDescription = "لایک",
            tint = if (liked) color else idleColor,
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    val s = if (liked) pop.value else 1f
                    scaleX = s; scaleY = s
                },
        )
    }
}

/* =========================================================================
   ۴) PlayPauseToggle / MicToggle / CopyButton / PinToggle
   همگی از انیمیشن مشترک keyframes-fill استفاده می‌کنند:
   rotate(-180deg) scale(0) → rotate(-10deg) scale(1.2) → حالت عادی
   ========================================================================= */

@Composable
private fun FillSwapIcon(
    state: Boolean,
    iconOn: ImageVector,
    iconOff: ImageVector,
    tintOn: Color,
    tintOff: Color,
    size: Dp,
    desc: String,
    spin: Boolean,
) {
    val anim = remember { Animatable(1f) }
    var firstPass by remember { mutableStateOf(true) }
    LaunchedEffect(state) {
        if (firstPass) { firstPass = false; return@LaunchedEffect }
        anim.snapTo(0f)
        anim.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
    }
    Icon(
        imageVector = if (state) iconOn else iconOff,
        contentDescription = desc,
        tint = if (state) tintOn else tintOff,
        modifier = Modifier
            .size(size)
            .graphicsLayer {
                val p = anim.value
                val s = if (p < 0.5f) (p / 0.5f) * 1.2f else 1.2f - (p - 0.5f) / 0.5f * 0.2f
                scaleX = s; scaleY = s
                rotationZ = if (spin) (-180f + 180f * p) * (1f - p) * 2f else -10f * (1f - p)
                alpha = (p * 2.2f).coerceAtMost(1f)
            },
    )
}

/** دکمهٔ پخش/توقف ویدئو */
@Composable
fun PlayPauseToggle(
    playing: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 30.dp,
    tint: Color = Color.White,
) {
    Box(
        modifier.clip(CircleShape).clickable { onToggle() }.size(size + 22.dp),
        contentAlignment = Alignment.Center,
    ) {
        FillSwapIcon(
            state = playing,
            iconOn = IcPause, iconOff = IcPlay,
            tintOn = tint, tintOff = tint,
            size = size, desc = if (playing) "توقف" else "پخش", spin = true,
        )
    }
}

/** دکمهٔ ضبط ویس */
@Composable
fun MicToggle(
    recording: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    activeColor: Color = MaterialTheme.colorScheme.error,
    idleColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    Box(
        modifier.clip(CircleShape).clickable { onToggle() }.size(size + 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        FillSwapIcon(
            state = recording,
            iconOn = IcMic, iconOff = IcMicSlash,
            tintOn = activeColor, tintOff = idleColor,
            size = size, desc = if (recording) "در حال ضبط" else "ضبط ویس", spin = false,
        )
    }
}

/** دکمهٔ کپی: بعد از کپی، آیکن به کلیپ‌بورد تیک‌دار تبدیل می‌شود */
@Composable
fun CopyButton(
    value: String,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    doneTint: Color = MaterialTheme.colorScheme.primary,
    onCopied: (() -> Unit)? = null,
) {
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            kotlinx.coroutines.delay(1600)
            copied = false
        }
    }
    Box(
        modifier.clip(CircleShape).clickable {
            clipboard.setText(androidx.compose.ui.text.AnnotatedString(value))
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            copied = true
            onCopied?.invoke()
        }.size(size + 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        FillSwapIcon(
            state = copied,
            iconOn = IcClipboardCheck, iconOff = IcClipboard,
            tintOn = doneTint, tintOff = tint,
            size = size, desc = if (copied) "کپی شد" else "کپی", spin = false,
        )
    }
}

/** دکمهٔ سنجاق کردن */
@Composable
fun PinToggle(
    pinned: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    activeColor: Color = Color(0xFFB38BFF),
    idleColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    val press by animateFloatAsState(if (pinned) 1f else 0f, tween(260), label = "pin")
    Box(
        modifier
            .size(size + 20.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (pinned) activeColor.copy(alpha = 0.12f) else Color.Transparent)
            .clickable { onToggle() },
        contentAlignment = Alignment.Center,
    ) {
        val c = if (pinned) activeColor else idleColor
        Canvas(
            Modifier
                .size(size)
                .graphicsLayer {
                    rotationZ = 35f
                    val s = 1f - 0.08f * press
                    scaleX = s; scaleY = s
                },
        ) {
            val w = this.size.width
            val h = this.size.height
            val sw = 1.8.dp.toPx()
            // سوزن
            drawLine(c, Offset(w * 0.49f, h * 0.64f), Offset(w * 0.49f, h), strokeWidth = sw * 1.4f, cap = StrokeCap.Round)
            // بدنه
            val p = androidx.compose.ui.graphics.Path().apply {
                moveTo(w * 0.22f, h * 0.36f)
                lineTo(w * 0.22f, h * 0.045f)
                lineTo(w * 0.78f, h * 0.045f)
                lineTo(w * 0.78f, h * 0.55f)
                lineTo(w * 0.89f, h * 0.675f)
                lineTo(w * 0.11f, h * 0.675f)
                lineTo(w * 0.22f, h * 0.55f)
                close()
            }
            if (pinned) drawPath(p, c.copy(alpha = 0.9f))
            drawPath(p, c, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
        }
    }
}

/* =========================================================================
   ۵) BookLoader — Uiverse / Nawsome (curly-goose-54)
   کتابی که صفحه‌هاش ورق می‌خورد — لودینگ اصلی اپ
   ========================================================================= */

@Composable
fun BookLoader(
    modifier: Modifier = Modifier,
    label: String? = "در حال بارگزاری…",
    scale: Float = 1f,
) {
    val t = rememberInfiniteTransition(label = "book")
    val p by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "bookPhase",
    )
    val w = 200.dp * scale
    val h = 140.dp * scale
    val pageW = 90.dp * scale
    val pageH = 120.dp * scale

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(width = w, height = h)
                .clip(RoundedCornerShape(13.dp * scale))
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFF23C4F8), Color(0xFF275EFE)),
                    ),
                ),
        ) {
            val pad = 10.dp * scale
            // صفحهٔ ثابت پشتی
            DocPage(
                color = Color.White.copy(alpha = 0.36f),
                modifier = Modifier.padding(start = pad, top = pad).size(pageW, pageH),
            )
            // چهار صفحهٔ ورق‌خورنده (page-2 تا page-5)
            for (i in 0 until 4) {
                val start = 0.15f * i
                val u = ((p - start) / 0.5f).coerceIn(0f, 1f)
                if (u <= 0f || u >= 1f) continue
                val a = when {
                    u < 0.4f -> u / 0.4f
                    u < 0.7f -> 1f
                    else -> ((1f - u) / 0.3f).coerceIn(0f, 1f)
                }
                DocPage(
                    color = Color.White.copy(alpha = 0.52f),
                    modifier = Modifier
                        .padding(start = pad, top = pad)
                        .size(pageW, pageH)
                        .graphicsLayer {
                            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0.5f)
                            cameraDistance = 14f * density
                            rotationY = 180f * (1f - u)
                            alpha = a
                        },
                )
            }
        }
        if (label != null) {
            Spacer(Modifier.size(18.dp))
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** برگٔ سند: مستطیل گوشه‌گرد با سه خط متن. */
@Composable
private fun DocPage(color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val r = size.width * 0.12f
        drawPath(
            androidx.compose.ui.graphics.Path().apply {
                moveTo(size.width, 0f)
                lineTo(size.width, size.height)
                lineTo(r, size.height)
                quadraticBezierTo(0f, size.height, 0f, size.height - r)
                lineTo(0f, r)
                quadraticBezierTo(0f, 0f, r, 0f)
                close()
            },
            color,
        )
        val lw = size.height * 0.04f
        val darker = Color.Black.copy(alpha = 0.16f)
        for (k in 0 until 3) {
            val y = size.height * (0.30f + 0.20f * k)
            drawLine(
                darker,
                Offset(size.width * 0.18f, y),
                Offset(size.width * 0.82f, y),
                strokeWidth = lw,
                cap = StrokeCap.Round,
            )
        }
    }
}

/* =========================================================================
   ۶) FlameLoader — Uiverse / andrew-manzyk
   گوی شعله‌ای چرخان — جایگزین آیکن موقع ضبط ویس
   ========================================================================= */

@Composable
fun FlameLoader(modifier: Modifier = Modifier, size: Dp = 34.dp) {
    val t = rememberInfiniteTransition(label = "flame")
    val spin by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(2000, easing = LinearEasing)),
        label = "flameSpin",
    )
    val pulse by t.animateFloat(
        0.85f, 1.12f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "flamePulse",
    )
    val one = Color(0xFFFFBF48)
    val two = Color(0xFFBE4A1D)
    Canvas(modifier.size(size)) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val r = this.size.minDimension / 2f
        // هاله
        drawCircle(
            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                listOf(one.copy(alpha = 0.28f), two.copy(alpha = 0.0f)),
                center = c, radius = r * 1.5f,
            ),
            radius = r * 1.5f, center = c,
        )
        // حلقهٔ بیرونی
        drawCircle(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(one, two)),
            radius = r, center = c,
            style = androidx.compose.ui.graphics.drawscope.Stroke(r * 0.06f),
        )
        // پره‌های مشعل (معادل polygon های ماسک)
        for (k in 0 until 3) {
            val ang = Math.toRadians((spin + k * 120f).toDouble())
            val rr = r * 0.52f * pulse
            val cx = c.x + (cos(ang) * r * 0.14f).toFloat()
            val cy = c.y + (sin(ang) * r * 0.14f).toFloat()
            val path = androidx.compose.ui.graphics.Path()
            for (v in 0 until 3) {
                val a2 = ang + v * (2.0 * PI / 3.0)
                val x = cx + (cos(a2) * rr).toFloat()
                val y = cy + (sin(a2) * rr).toFloat()
                if (v == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(
                path,
                brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(one.copy(alpha = 0.85f), two.copy(alpha = 0.85f)),
                ),
            )
        }
        drawCircle(one.copy(alpha = 0.9f), radius = r * 0.16f * pulse, center = c)
    }
}

/* =========================================================================
   ۷) CradleLoader — Uiverse / louloudev59 (گهوارهٔ نیوتن)
   و OfflineNotice — حالت قطعی اینترنت
   ========================================================================= */

@Composable
fun CradleLoader(modifier: Modifier = Modifier, width: Dp = 190.dp) {
    val t = rememberInfiniteTransition(label = "cradle")
    val phase by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "cradlePhase",
    )
    val wood = Color(0xFF6F463F)
    val string = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
    Canvas(modifier.size(width = width, height = width * 0.62f)) {
        val w = size.width
        val h = size.height
        val ballR = w * 0.055f
        val pivotY = h * 0.16f
        val len = h * 0.52f
        val gap = ballR * 2.02f
        val cx = w / 2f

        // پایهٔ چوبی بالا و پایین
        drawRoundRect(
            wood,
            topLeft = Offset(w * 0.13f, pivotY - h * 0.035f),
            size = androidx.compose.ui.geometry.Size(w * 0.74f, h * 0.035f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f),
        )
        drawRoundRect(
            wood,
            topLeft = Offset(w * 0.09f, h * 0.90f),
            size = androidx.compose.ui.geometry.Size(w * 0.82f, h * 0.06f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f),
        )
        drawLine(wood, Offset(w * 0.15f, pivotY), Offset(w * 0.15f, h * 0.90f), strokeWidth = w * 0.018f)
        drawLine(wood, Offset(w * 0.85f, pivotY), Offset(w * 0.85f, h * 0.90f), strokeWidth = w * 0.018f)

        val s = sin(2.0 * PI * phase).toFloat()
        val maxA = 0.55f // رادیان
        for (i in 0 until 5) {
            val px = cx + (i - 2) * gap
            val a = when {
                i == 0 && s < 0f -> s * maxA
                i == 4 && s > 0f -> s * maxA
                else -> 0f
            }
            val bx = px + (sin(a.toDouble()) * len).toFloat()
            val by = pivotY + (cos(a.toDouble()) * len).toFloat()
            drawLine(string, Offset(px, pivotY), Offset(bx, by), strokeWidth = w * 0.008f)
            drawCircle(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    listOf(Color(0xFFFF6B6B), Color(0xFFB30000)),
                    center = Offset(bx - ballR * 0.3f, by - ballR * 0.3f),
                    radius = ballR * 1.6f,
                ),
                radius = ballR,
                center = Offset(bx, by),
            )
        }
    }
}

/** حالت قطعی اینترنت: گهواره + پیام اطمینان‌بخش و دکمهٔ تلاش مجدد. */
@Composable
fun OfflineNotice(
    modifier: Modifier = Modifier,
    onRetry: (() -> Unit)? = null,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CradleLoader()
        Spacer(Modifier.size(10.dp))
        Text(
            "یه چیزی درست کار نمی‌کنه — اتصالت قطع شده",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.size(6.dp))
        Text(
            "ولی نگران نباش؛ می‌تونی همین‌جور آفلاین مطالعه کنی و ساعت مطالعه‌ت رو ثبت کنی — بعد از وصل شدن خودبه‌خود سینک می‌شه",
            style = MaterialTheme.typography.bodySmall,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 28.dp),
        )
        if (onRetry != null) {
            Spacer(Modifier.size(14.dp))
            androidx.compose.material3.Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                onClick = onRetry,
            ) {
                Text(
                    "تلاش مجدد",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp),
                )
            }
        }
    }
}
