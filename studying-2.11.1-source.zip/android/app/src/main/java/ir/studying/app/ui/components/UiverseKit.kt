package ir.studying.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/*
 * UiverseKit — قطعه‌های تزئینی و تعاملی اپ (الهام‌گرفته از Uiverse).
 * همه‌چیز با Canvas و انیمیشن‌های Compose بازنویسی شده تا وابستگی خارجی نداشته باشیم.
 */

/* --------------------------------------------------------------- search -- */

/** اینپوت جست‌وجو با حلقه‌ی نوری چرخان. */
@Composable
fun GlowSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    var focused by remember { mutableStateOf(false) }
    val tr = rememberInfiniteTransition(label = "glow")
    val angle by tr.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "glowAngle",
    )
    val glow by animateFloatAsState(if (focused) 1f else 0.45f, tween(300), label = "glowA")
    val ring = listOf(cs.primary, cs.tertiary, cs.secondary, cs.primary)

    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .drawBehind {
                rotate(angle) {
                    drawCircle(
                        brush = Brush.sweepGradient(ring),
                        radius = size.maxDimension,
                        alpha = glow,
                    )
                }
            }
            .padding(1.6.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(cs.surface),
        contentAlignment = Alignment.CenterStart,
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Search, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (value.isEmpty()) {
                    Text(
                        placeholder,
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant.copy(alpha = 0.55f),
                        maxLines = 1,
                    )
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = cs.onSurface),
                    singleLine = true,
                    cursorBrush = SolidColor(cs.primary),
                )
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
        }
    }
}

/* ---------------------------------------------------------------- input -- */

/** اینپوت ورود با خط زیرین متحرک. */
@Composable
fun AccentTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    password: Boolean = false,
    leading: ImageVector? = null,
) {
    val cs = MaterialTheme.colorScheme
    var reveal by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(false) }
    val prog by animateFloatAsState(if (focused) 1f else 0f, tween(240), label = "accUnderline")
    val labelColor by animateColorAsState(
        if (focused) cs.primary else cs.onSurfaceVariant,
        tween(240), label = "accLabel",
    )
    Column(modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = labelColor)
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 11.dp, topEnd = 11.dp, bottomStart = 3.dp, bottomEnd = 3.dp))
                .background(cs.surfaceVariant.copy(alpha = if (focused) 0.85f else 0.55f)),
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (leading != null) {
                    Icon(leading, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(9.dp))
                }
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty() && placeholder != null) {
                        Text(
                            placeholder,
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant.copy(alpha = 0.5f),
                            maxLines = 1,
                        )
                    }
                    BasicTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface),
                        singleLine = true,
                        cursorBrush = SolidColor(cs.primary),
                        visualTransformation =
                            if (password && !reveal) PasswordVisualTransformation() else VisualTransformation.None,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (password) KeyboardType.Password else KeyboardType.Text,
                        ),
                    )
                }
                if (password) {
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        if (reveal) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        null,
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(19.dp).clip(CircleShape).clickable { reveal = !reveal },
                    )
                }
            }
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(1.dp).background(cs.outlineVariant))
            Box(
                Modifier.align(Alignment.BottomCenter)
                    .fillMaxWidth(prog.coerceIn(0.001f, 1f))
                    .height(2.dp)
                    .background(cs.primary),
            )
        }
    }
}

/* ----------------------------------------------------------- selections -- */

/** انتخاب شیشه‌ای با لغزندهٔ فنری — مخصوص حالت روز/شب. */
@Composable
fun GlassRadioGroup(
    options: List<String>,
    selected: Int,
    modifier: Modifier = Modifier,
    height: Dp = 46.dp,
    onSelect: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val n = options.size.coerceAtLeast(1)
        val itemW = maxWidth / n
        val off by animateDpAsState(
            itemW * selected,
            spring(dampingRatio = 0.58f, stiffness = 380f),
            label = "glider",
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(height)
                .clip(RoundedCornerShape(16.dp))
                .background(cs.onSurface.copy(alpha = 0.06f))
                .border(1.dp, Color.White.copy(alpha = 0.13f), RoundedCornerShape(16.dp)),
        ) {
            Box(
                Modifier
                    .offset(x = off)
                    .width(itemW)
                    .fillMaxHeight()
                    .padding(4.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.55f), cs.primary))),
            )
            Row(Modifier.fillMaxWidth().fillMaxHeight()) {
                options.forEachIndexed { i, label ->
                    val fg by animateColorAsState(
                        if (i == selected) Color.White else cs.onSurfaceVariant,
                        tween(280), label = "glassFg",
                    )
                    Box(
                        Modifier
                            .width(itemW)
                            .fillMaxHeight()
                            .clickable(remember { MutableInteractionSource() }, indication = null) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(i)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(label, style = MaterialTheme.typography.labelLarge, color = fg, maxLines = 1)
                    }
                }
            }
        }
    }
}

/** جزیرهٔ فیلتر (روز / هفته / ماه و ...) با نشانگر لغزان. */
@Composable
fun IslandTabs(
    options: List<String>,
    selected: Int,
    modifier: Modifier = Modifier,
    onSelect: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val dark = cs.background.luminance() < 0.5f
    val island = if (dark) Color.Black.copy(alpha = 0.55f) else cs.onSurface.copy(alpha = 0.07f)
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val n = options.size.coerceAtLeast(1)
        val inner = maxWidth - 12.dp
        val itemW = inner / n
        val off by animateDpAsState(itemW * selected, tween(420, easing = FastOutSlowInEasing), label = "island")
        Box(
            Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(island)
                .border(1.dp, cs.outlineVariant.copy(alpha = 0.35f), CircleShape)
                .padding(6.dp),
        ) {
            Box(
                Modifier
                    .offset(x = off)
                    .width(itemW)
                    .height(38.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.85f), cs.primary))),
            )
            Row(Modifier.fillMaxWidth().height(38.dp)) {
                options.forEachIndexed { i, label ->
                    val sel = i == selected
                    val fg by animateColorAsState(
                        if (sel) cs.onPrimary else cs.onSurfaceVariant,
                        tween(280), label = "islandFg",
                    )
                    val sc by animateFloatAsState(if (sel) 1.04f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "islandSc")
                    Box(
                        Modifier
                            .width(itemW)
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .clickable(remember { MutableInteractionSource() }, indication = null) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(i)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelLarge,
                            color = fg,
                            maxLines = 1,
                            modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc },
                        )
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------------- priority -- */

val PriorityHigh = Color(0xFFEF4444)
val PriorityNormal = Color(0xFFF59E0B)
val PriorityLow = Color(0xFF22C55E)

/** رادیوی اولویت‌دار (زیاد / معمولی / کم) با هاله‌ی نئونی. */
@Composable
fun PriorityRadio(
    selected: String,
    modifier: Modifier = Modifier,
    labels: List<String> = listOf("زیاد", "معمولی", "کم"),
    onSelect: (String) -> Unit,
) {
    val keys = listOf("high", "normal", "low")
    val colors = listOf(PriorityHigh, PriorityNormal, PriorityLow)
    val haptic = LocalHapticFeedback.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        keys.forEachIndexed { i, key ->
            val sel = selected == key
            val col = colors[i]
            val f by animateFloatAsState(if (sel) 1f else 0f, spring(dampingRatio = 0.45f, stiffness = 520f), label = "prio")
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(13.dp))
                    .background(col.copy(alpha = 0.06f + 0.10f * f))
                    .clickable(remember { MutableInteractionSource() }, indication = null) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(key)
                    }
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Canvas(Modifier.size(22.dp)) {
                    val r = size.minDimension / 2f
                    drawCircle(col.copy(alpha = 0.22f + 0.5f * f), radius = r * (1f + 0.35f * f), style = Stroke(width = 2f))
                    drawCircle(col, radius = r - 1.5f, style = Stroke(width = 2.5f))
                    if (f > 0f) drawCircle(col, radius = (r - 3f) * f)
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    labels.getOrElse(i) { key },
                    style = MaterialTheme.typography.labelLarge,
                    color = if (sel) col else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

/* -------------------------------------------------------- feed reactions -- */

/** دکمهٔ کامنت: حباب می‌پرد و سه نقطه داخلش موج می‌زند. */
@Composable
fun CommentPop(
    count: String,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    onClick: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val pop = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current
    Row(
        modifier
            .clip(CircleShape)
            .clickable(remember { MutableInteractionSource() }, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                scope.launch {
                    pop.snapTo(0f)
                    pop.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
                }
                onClick()
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val p = pop.value
        val sc = 1f + 0.30f * sin(p * PI.toFloat())
        Canvas(Modifier.size(18.dp).graphicsLayer { scaleX = sc; scaleY = sc }) {
            val w = size.width
            val h = size.height
            val body = androidx.compose.ui.geometry.Size(w, h * 0.78f)
            drawRoundRect(
                color = tint,
                size = body,
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.32f, w * 0.32f),
                style = Stroke(width = 2f),
            )
            val tail = Path()
            tail.moveTo(w * 0.28f, h * 0.76f)
            tail.lineTo(w * 0.20f, h)
            tail.lineTo(w * 0.48f, h * 0.76f)
            drawPath(tail, tint, style = Stroke(width = 2f, cap = StrokeCap.Round))
            var d = 0
            while (d < 3) {
                val ph = (p * 2f - d * 0.18f).coerceIn(0f, 1f)
                val a = if (p == 0f) 0.55f else 0.35f + 0.65f * sin(ph * PI.toFloat())
                drawCircle(
                    tint.copy(alpha = a.coerceIn(0f, 1f)),
                    radius = w * 0.065f,
                    center = Offset(w * (0.28f + d * 0.22f), h * 0.38f),
                )
                d++
            }
        }
        if (count.isNotEmpty()) {
            Spacer(Modifier.width(4.dp))
            Text(count, style = MaterialTheme.typography.labelSmall, color = tint)
        }
    }
}

/** دکمهٔ بازنشر: فلش‌ها یک دور کامل می‌چرخند و سبز می‌شوند. */
@Composable
fun RepostSpin(
    active: Boolean,
    count: String,
    modifier: Modifier = Modifier,
    idleColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    activeColor: Color = Color(0xFF22C55E),
    onClick: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val spin = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current
    val tint by animateColorAsState(if (active) activeColor else idleColor, tween(280), label = "rpTint")
    LaunchedEffect(active) { if (active) { spin.snapTo(0f); spin.animateTo(1f, tween(620, easing = FastOutSlowInEasing)) } }
    Row(
        modifier
            .clip(CircleShape)
            .clickable(remember { MutableInteractionSource() }, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                scope.launch { spin.snapTo(0f); spin.animateTo(1f, tween(620, easing = FastOutSlowInEasing)) }
                onClick()
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val p = spin.value
        val sc = 1f + 0.22f * sin(p * PI.toFloat())
        Canvas(
            Modifier.size(18.dp).graphicsLayer {
                rotationZ = 360f * p
                scaleX = sc
                scaleY = sc
            },
        ) {
            val w = size.width
            val h = size.height
            val sw = 2f
            val top = Path()
            top.moveTo(w * 0.16f, h * 0.40f)
            top.lineTo(w * 0.16f, h * 0.26f)
            top.lineTo(w * 0.74f, h * 0.26f)
            drawPath(top, tint, style = Stroke(width = sw, cap = StrokeCap.Round))
            val arrowUp = Path()
            arrowUp.moveTo(w * 0.60f, h * 0.12f)
            arrowUp.lineTo(w * 0.80f, h * 0.26f)
            arrowUp.lineTo(w * 0.60f, h * 0.40f)
            drawPath(arrowUp, tint, style = Stroke(width = sw, cap = StrokeCap.Round))
            val bottom = Path()
            bottom.moveTo(w * 0.84f, h * 0.60f)
            bottom.lineTo(w * 0.84f, h * 0.74f)
            bottom.lineTo(w * 0.26f, h * 0.74f)
            drawPath(bottom, tint, style = Stroke(width = sw, cap = StrokeCap.Round))
            val arrowDown = Path()
            arrowDown.moveTo(w * 0.40f, h * 0.60f)
            arrowDown.lineTo(w * 0.20f, h * 0.74f)
            arrowDown.lineTo(w * 0.40f, h * 0.88f)
            drawPath(arrowDown, tint, style = Stroke(width = sw, cap = StrokeCap.Round))
        }
        if (count.isNotEmpty()) {
            Spacer(Modifier.width(4.dp))
            Text(count, style = MaterialTheme.typography.labelSmall, color = tint)
        }
    }
}

/** آمار ساده با تپش ملایم هنگام لمس (بازدید و ...). */
@Composable
fun PulseStat(
    icon: ImageVector,
    count: String,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    onClick: () -> Unit = {},
) {
    val scope = rememberCoroutineScope()
    val pulse = remember { Animatable(0f) }
    Row(
        modifier
            .clip(CircleShape)
            .clickable(remember { MutableInteractionSource() }, indication = null) {
                scope.launch { pulse.snapTo(0f); pulse.animateTo(1f, tween(420)) }
                onClick()
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val sc = 1f + 0.25f * sin(pulse.value * PI.toFloat())
        Icon(icon, null, tint = tint, modifier = Modifier.size(17.dp).graphicsLayer { scaleX = sc; scaleY = sc })
        if (count.isNotEmpty()) {
            Spacer(Modifier.width(4.dp))
            Text(count, style = MaterialTheme.typography.labelSmall, color = tint)
        }
    }
}

/**
 * ری‌اکشن‌ها: هر ایموجی انیمیشن اختصاصی خودش را دارد.
 * 0 تپش قلبی، 1 پرش، 2 چرخش، 3 لرزش، 4 شعله‌وار، 5 موجی.
 */
@Composable
fun AnimatedReaction(
    emoji: String,
    index: Int,
    mine: Boolean,
    modifier: Modifier = Modifier,
    onPick: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val play = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current
    val idle = rememberInfiniteTransition(label = "reIdle")
    val breathe by idle.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "reBreathe",
    )
    val p = play.value
    val kind = index % 6
    var sx = 1f
    var sy = 1f
    var rot = 0f
    var dy = 0f
    when (kind) {
        0 -> { // تپش قلب
            val beat = 1f + 0.45f * sin(p * PI.toFloat() * 2f)
            sx = beat; sy = beat
        }
        1 -> { // پرش
            dy = -22f * sin(p * PI.toFloat())
            sx = 1f + 0.16f * sin(p * PI.toFloat())
            sy = sx
        }
        2 -> { // چرخش کامل
            rot = 360f * p
            sx = 1f + 0.22f * sin(p * PI.toFloat()); sy = sx
        }
        3 -> { // لرزش
            rot = 22f * sin(p * PI.toFloat() * 6f)
            sx = 1f + 0.18f * sin(p * PI.toFloat()); sy = sx
        }
        4 -> { // شعله: بزرگ می‌شود و کمی می‌رقصد
            sx = 1f + 0.5f * sin(p * PI.toFloat())
            sy = 1f + 0.62f * sin(p * PI.toFloat())
            rot = 12f * sin(p * PI.toFloat() * 4f)
        }
        else -> { // موج
            sx = 1f + 0.35f * sin(p * PI.toFloat())
            sy = 1f + 0.12f * sin(p * PI.toFloat() * 2f)
            dy = -8f * sin(p * PI.toFloat() * 2f)
        }
    }
    if (mine) {
        sx *= 1f + 0.06f * breathe
        sy *= 1f + 0.06f * breathe
    }
    Surface(
        shape = CircleShape,
        color = if (mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else Color.Transparent,
        modifier = modifier,
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            scope.launch {
                play.snapTo(0f)
                play.animateTo(1f, tween(620, easing = FastOutSlowInEasing))
            }
            onPick()
        },
    ) {
        ir.studying.app.core.Icon3D(
            emoji,
            30.dp,
            modifier = Modifier.padding(4.dp).graphicsLayer {
                scaleX = sx
                scaleY = sy
                rotationZ = rot
                translationY = dy
            },
        )
    }
}

/* ------------------------------------------------------------- nav item -- */

/** آیتم منوی پایین با حبابک متن (استایل themrsami). */
@Composable
fun NavBubbleItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    badge: Int = 0,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val bg by animateColorAsState(
        if (selected) cs.primary.copy(alpha = 0.16f) else Color.Transparent,
        tween(320), label = "navBubbleBg",
    )
    val fg by animateColorAsState(
        if (selected) cs.primary else cs.onSurfaceVariant,
        tween(320), label = "navBubbleFg",
    )
    val sc by animateFloatAsState(
        if (selected) 1.12f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 460f), label = "navBubbleSc",
    )
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(remember { MutableInteractionSource() }, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(bg),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    icon, contentDescription = label, tint = fg,
                    modifier = Modifier.size(21.dp).graphicsLayer { scaleX = sc; scaleY = sc },
                )
            }
            if (badge > 0) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .size(15.dp)
                        .clip(CircleShape)
                        .background(cs.error),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (badge > 9) "9+" else badge.toString(),
                        color = cs.onError,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                    )
                }
            }
        }
        Spacer(Modifier.height(1.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            color = fg,
            maxLines = 1,
        )
    }
}
