@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.ui.text.ExperimentalTextApi::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package ir.studying.app.ui.feed

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.R
import ir.studying.app.core.Avatars
import ir.studying.app.core.fa
import ir.studying.app.data.SocialProfile
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.HeartColor
import ir.studying.app.ui.components.StarField
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.riseIn
import ir.studying.app.ui.components.shine
import ir.studying.app.ui.components.userColor
import ir.studying.app.ui.profile.CharacterAvatar3D
import ir.studying.app.ui.theme.brandGradient
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * زبان بصری شبکهٔ اجتماعی — نسخهٔ ۲.۹.
 *
 * فید از «لیست خط‌کشی‌شدهٔ توییتری» به کارت‌های شناور رسید: هر پست کارتی با
 * رنگ کاراکترِ نویسنده است، ورودش پلکانی است، دوبار لمسش قلب می‌ترکاند و
 * بالای فید ردیف «درس‌خون‌ها» با حلقه‌های چرخان مثل استوری‌ها نشسته است.
 * منطق شبکه (ViewModel، درخواست‌ها، شیت‌ها) دست نخورده؛ این فایل فقط
 * قطعه‌های ظاهری را نگه می‌دارد تا FeedScreen خواناتر بماند.
 */

private const val TAU = (2.0 * PI).toFloat()

/** رنگ شاخص یک نفر: رنگ کاراکترش، وگرنه رنگ ثابتِ نامش. */
internal fun accentOf(username: String, avatar: String?): Color =
    Avatars.characterOfValue(avatar)?.let { Color(it.color) } ?: userColor(username)

// ============================================================ هدر

/**
 * سرصفحهٔ فید: عنوان با برق گرادیانی و دکمهٔ جستجو که با یک لمس به فیلد
 * جستجو باز می‌شود (و تا وقتی متنی هست باز می‌ماند).
 */
@Composable
internal fun FeedHeader(
    query: String,
    onQuery: (String) -> Unit,
    searchOpen: Boolean,
    onSearchOpen: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    AnimatedContent(
        targetState = searchOpen,
        transitionSpec = {
            (fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.94f))
                .togetherWith(fadeOut(tween(140)))
        },
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
        label = "feedHeader",
    ) { open ->
        if (open) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlowSearchField(query, onQuery, Modifier.weight(1f))
                Spacer(Modifier.width(6.dp))
                Text(
                    "بستن",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = cs.primary,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { onQuery(""); onSearchOpen(false) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                )
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    ShimmerTitle("شبکهٔ درس‌خون‌ها")
                    Text(
                        "ببین بقیه امروز چی خوندن ✨",
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
                OrbButton(Icons.Rounded.Search, "جستجو") { onSearchOpen(true) }
            }
        }
    }
}

/** عنوانی که نوار نوری آرام از رویش رد می‌شود. */
@Composable
private fun ShimmerTitle(text: String) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "feedTitle")
    val x by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "feedTitleX",
    )
    val brush = Brush.linearGradient(
        listOf(cs.onSurface, cs.onSurface, cs.primary, cs.secondary, cs.onSurface, cs.onSurface),
        start = Offset(x * 1400f - 700f, 0f),
        end = Offset(x * 1400f - 100f, 40f),
        tileMode = TileMode.Clamp,
    )
    Text(
        text,
        style = MaterialTheme.typography.headlineSmall.merge(TextStyle(brush = brush, fontWeight = FontWeight.Black)),
    )
}

/** فیلد جستجو با حاشیهٔ نوری چرخان. */
@Composable
private fun GlowSearchField(query: String, onQuery: (String) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val t = rememberInfiniteTransition(label = "searchGlow")
    val spin = t.animateFloat(0f, 360f, infiniteRepeatable(tween(3800, easing = LinearEasing)), label = "searchSpin")
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier
            .height(48.dp)
            .clip(shape)
            .background(cs.surfaceVariant.copy(alpha = 0.5f))
            .drawRingBorder(spin, listOf(cs.primary, cs.secondary, cs.primary.copy(alpha = 0.1f), cs.primary), 22.dp)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = cs.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) {
                Text(
                    stringResource(R.string.feed_screen_001),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = cs.onSurface),
                cursorBrush = SolidColor(cs.primary),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        if (query.isNotEmpty()) {
            Icon(
                Icons.Rounded.Close, "پاک کردن",
                tint = cs.onSurfaceVariant,
                modifier = Modifier.size(18.dp).clip(CircleShape).clickable { onQuery("") },
            )
        }
    }
}

/** حاشیهٔ گرادیانی چرخان: خود شکل ثابت است و فقط نور دورش می‌گردد. */
private fun Modifier.drawRingBorder(spin: State<Float>, colors: List<Color>, radius: Dp): Modifier =
    drawWithContent {
        drawContent()
        val sw = 1.6.dp.toPx()
        val a = spin.value * (PI.toFloat() / 180f)
        val c = center
        val brush = Brush.linearGradient(
            colors,
            start = Offset(c.x + cos(a) * size.width / 2f, c.y + sin(a) * size.height / 2f),
            end = Offset(c.x - cos(a) * size.width / 2f, c.y - sin(a) * size.height / 2f),
        )
        drawRoundRect(
            brush,
            topLeft = Offset(sw / 2f, sw / 2f),
            size = Size(size.width - sw, size.height - sw),
            cornerRadius = CornerRadius(radius.toPx(), radius.toPx()),
            style = Stroke(sw),
        )
    }

/** دکمهٔ گرد شیشه‌ای. */
@Composable
internal fun OrbButton(icon: ImageVector, label: String, size: Dp = 44.dp, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(cs.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.5f), CircleShape)
            .bouncyClick(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = label, tint = cs.onSurface, modifier = Modifier.size(20.dp))
    }
}

/** نوار بالای صفحه‌های داخلی شبکه (جزئیات پست، پروفایل). */
@Composable
internal fun FeedTopBar(
    title: String,
    onBack: () -> Unit,
    subtitle: String? = null,
    trailing: @Composable RowScope.() -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .background(cs.background)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OrbButton(Icons.AutoMirrored.Rounded.ArrowBack, "بازگشت", size = 42.dp, onClick = onBack)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
        trailing()
    }
}

// ============================================================ ردیف آدم‌ها

/**
 * ردیف «درس‌خون‌ها» بالای فید — مثل استوری: حلقهٔ رنگیِ چرخان دور هر نفر.
 * اولین حباب خودِ کاربر است با «+» برای پست تازه.
 */
@Composable
internal fun PeopleRow(
    people: List<Pair<String, String?>>,
    me: String,
    meAvatar: String?,
    onCompose: () -> Unit,
    onUser: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = rememberInfiniteTransition(label = "peopleRings")
    val spin = t.animateFloat(0f, 360f, infiniteRepeatable(tween(5600, easing = LinearEasing)), label = "peopleSpin")
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "__me") {
            StoryBubble(me, meAvatar, "پست تازه", plus = true, spin = spin, index = 0, onClick = onCompose)
        }
        itemsIndexed(people, key = { _, it -> it.first }) { i, (u, av) ->
            StoryBubble(u, av, u, plus = false, spin = spin, index = i + 1) { onUser(u) }
        }
    }
}

@Composable
private fun StoryBubble(
    username: String,
    avatar: String?,
    label: String,
    plus: Boolean,
    spin: State<Float>,
    index: Int,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ch = Avatars.characterOfValue(avatar)
    val c1 = ch?.let { Color(it.color) } ?: cs.primary
    val c2 = ch?.let { Color(it.glow) } ?: cs.secondary
    val dash = remember { PathEffect.dashPathEffect(floatArrayOf(10f, 9f)) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .riseIn(index.coerceAtMost(6), distance = 14.dp)
            .bouncyClick(onClick = onClick),
    ) {
        Box(Modifier.size(66.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.matchParentSize()) {
                val sw = 2.6.dp.toPx()
                val r = size.minDimension / 2f - sw
                if (plus) {
                    drawCircle(
                        cs.outline.copy(alpha = 0.7f), r, center,
                        style = Stroke(sw * 0.8f, pathEffect = dash),
                    )
                } else {
                    rotate(spin.value + index * 47f) {
                        drawCircle(
                            Brush.sweepGradient(listOf(c1, c2, lerp(c1, Color.White, 0.35f), c1), center),
                            r, center, style = Stroke(sw),
                        )
                    }
                }
            }
            Avatar(username, size = 50.dp, avatarUrl = avatar)
            if (plus) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(brandGradient())
                        .border(2.dp, cs.background, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Add, null, tint = cs.onPrimary, modifier = Modifier.size(14.dp))
                }
            }
        }
        Spacer(Modifier.height(3.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (plus) cs.primary else cs.onSurface,
            fontWeight = if (plus) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// ============================================================ تب‌ها

/** دو تب فید با قرص گرادیانیِ لغزان و فنری. */
@Composable
internal fun FeedTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val pos by animateFloatAsState(
        selected.toFloat(), spring(dampingRatio = 0.68f, stiffness = 420f), label = "feedTabPos",
    )
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val n = options.size.coerceAtLeast(1)
    Box(
        modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(CircleShape)
            .background(cs.surfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.45f), CircleShape)
            .padding(4.dp),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(1f / n)
                .graphicsLayer { translationX = (if (rtl) -1f else 1f) * pos * size.width }
                .clip(CircleShape)
                .background(brandGradient())
                .shine(periodMs = 4200),
        )
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                val on = i == selected
                val c by animateColorAsState(if (on) cs.onPrimary else cs.onSurfaceVariant, tween(240), label = "tabC$i")
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .clickable(remember { MutableInteractionSource() }, indication = null) { onSelect(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (on) FontWeight.Black else FontWeight.Medium,
                        color = c,
                    )
                }
            }
        }
    }
}

// ============================================================ قلب دوبار لمس

/**
 * قلب بزرگی که با دوبار لمس کارت می‌پرد، کمی بالا می‌رود و محو می‌شود؛ ده
 * ذره دورش می‌پاشند. [progress] از ۰ تا ۱ است و بیرون از این بازه چیزی نمی‌کشد.
 */
@Composable
internal fun HeartBurst(progress: () -> Float, modifier: Modifier = Modifier) {
    val heart = rememberVectorPainter(Icons.Rounded.Favorite)
    val confetti = remember { listOf(HeartColor, Color(0xFFFFD166), Color.White, Color(0xFFA78BFA)) }
    Canvas(modifier) {
        val p = progress()
        if (p <= 0f || p >= 1f) return@Canvas
        val c = center
        val s = when {
            p < 0.3f -> p / 0.3f * 1.25f
            p < 0.5f -> 1.25f - (p - 0.3f) / 0.2f * 0.25f
            else -> 1f
        }
        val fade = if (p < 0.68f) 1f else (1f - (p - 0.68f) / 0.32f).coerceIn(0f, 1f)
        val lift = if (p > 0.5f) (p - 0.5f) * 70.dp.toPx() else 0f
        val sz = 92.dp.toPx() * s
        drawCircle(
            Brush.radialGradient(listOf(HeartColor.copy(alpha = 0.35f * fade), Color.Transparent), c, sz),
            sz, c,
        )
        translate(c.x - sz / 2f, c.y - sz / 2f - lift) {
            with(heart) { draw(Size(sz, sz), alpha = fade, colorFilter = ColorFilter.tint(HeartColor)) }
        }
        for (i in 0 until 12) {
            val ang = i * TAU / 12f + 0.2f
            val d = 34.dp.toPx() + 84.dp.toPx() * p
            val pp = Offset(c.x + cos(ang) * d, c.y + sin(ang) * d - lift * 0.4f)
            drawCircle(
                confetti[i % confetti.size].copy(alpha = (1f - p).coerceIn(0f, 1f)),
                radius = (if (i % 2 == 0) 5.dp else 3.5.dp).toPx() * (1f - p * 0.5f),
                center = pp,
            )
        }
    }
}

// ============================================================ دکمهٔ ساخت

/** دکمهٔ شناور ساخت پست: قرص گرادیانی با برق؛ با اسکرول جمع می‌شود. */
@Composable
internal fun FeedFab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "fab")
    val wob = t.animateFloat(
        -1f, 1f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fabWob",
    )
    Row(
        modifier
            .shadow(16.dp, CircleShape, ambientColor = cs.primary, spotColor = cs.primary)
            .clip(CircleShape)
            .background(brandGradient())
            .shine(periodMs = 3200)
            .bouncyClick(onClick = onClick)
            .animateContentSize(spring(dampingRatio = 0.7f, stiffness = 500f))
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Rounded.Edit, "پست جدید",
            tint = cs.onPrimary,
            modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = wob.value * 9f },
        )
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(tween(200)) + expandHorizontally(),
            exit = fadeOut(tween(120)) + shrinkHorizontally(),
        ) {
            Text(
                "پست تازه",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
                color = cs.onPrimary,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}

// ============================================================ دنبال کردن

/** دکمهٔ دنبال کردن: قرص گرادیانی ↔ قرص آرام با تیک، با جابه‌جایی فنری. */
@Composable
fun FollowChip(following: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AnimatedContent(
        targetState = following,
        transitionSpec = {
            (fadeIn(tween(200)) + scaleIn(spring(dampingRatio = 0.5f, stiffness = 600f), initialScale = 0.8f))
                .togetherWith(fadeOut(tween(120)))
        },
        label = "followChip",
    ) { on ->
        if (on) {
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(cs.surfaceVariant.copy(alpha = 0.7f))
                    .border(1.dp, cs.outlineVariant, CircleShape)
                    .bouncyClick(onClick = onClick)
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Check, null, tint = cs.primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("دنبال می‌کنی", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            }
        } else {
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(brandGradient())
                    .shine(periodMs = 3600)
                    .bouncyClick(onClick = onClick)
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.PersonAdd, null, tint = cs.onPrimary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text(
                    "دنبال کن",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = cs.onPrimary,
                )
            }
        }
    }
}

// ============================================================ پروفایل اجتماعی

/**
 * سرصفحهٔ پروفایل اجتماعی (بی‌حالت): بنر با آسمان پرستاره که در پس‌زمینه
 * محو می‌شود، کاراکتر سه‌بعدی زنده یا عکس با حلقهٔ چرخان، و کاشی‌های آمار
 * که اعدادشان از صفر بالا می‌شمارند.
 */
@Composable
internal fun SocialProfileHeader(
    p: SocialProfile,
    me: String,
    bannerId: String,
    onBanner: () -> Unit,
    onMenu: () -> Unit,
    onDm: () -> Unit,
    onFollow: () -> Unit,
    onFollowList: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val mine = p.username == me
    val unlocked = p.isFollowing || mine
    val accent = accentOf(p.username, p.avatar)
    Box(Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(172.dp)
                .background(bannerBrush(bannerId)),
        ) {
            StarField(Modifier.matchParentSize(), count = 28, seed = 5, maxAlpha = 0.75f)
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Transparent,
                            0.55f to Color.Transparent,
                            1f to cs.background,
                        ),
                    ),
            )
            Row(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.32f))
                    .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape)
                    .bouncyClick { if (mine) onBanner() else onMenu() }
                    .padding(horizontal = if (mine) 12.dp else 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (mine) {
                    Text(stringResource(R.string.feed_screen_007), color = Color.White, style = MaterialTheme.typography.labelSmall)
                } else {
                    Icon(Icons.Rounded.MoreHoriz, "گزینه‌ها", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 96.dp)
                .padding(horizontal = 16.dp),
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                ProfileAvatarBig(p.username, p.avatar, p.mood, p.isOnline, accent)
                Spacer(Modifier.weight(1f))
                if (!mine) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                        Row(
                            Modifier
                                .clip(CircleShape)
                                .background(cs.surfaceVariant.copy(alpha = 0.6f))
                                .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
                                .bouncyClick(onClick = onDm)
                                .padding(horizontal = 14.dp, vertical = 9.dp),
                        ) {
                            Text(stringResource(R.string.feed_screen_008), style = MaterialTheme.typography.labelLarge)
                        }
                        Spacer(Modifier.width(8.dp))
                        FollowChip(p.isFollowing, onFollow)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            /*
             * نام نمایشی تیتر است و شناسه خط دوم؛ اگر نامی نگذاشته، شناسه تیتر
             * می‌ماند تا هیچ‌وقت تیتر خالی یا تکراری دیده نشود.
             */
            val headline = p.displayName?.takeIf { it.isNotBlank() } ?: p.username
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(headline, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                if (!p.mood.isNullOrBlank()) {
                    Spacer(Modifier.width(6.dp))
                    Text(p.mood, fontSize = 20.sp)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!p.displayName.isNullOrBlank()) {
                    Text("@${p.username}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.width(8.dp))
                }
                if (p.isOnline) {
                    LiveDot()
                    Spacer(Modifier.width(4.dp))
                    Text("آنلاین", style = MaterialTheme.typography.labelSmall, color = Color(0xFF22C55E))
                } else if (!p.lastSeenText.isNullOrBlank()) {
                    Text(p.lastSeenText, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            if (!p.statusText.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(p.statusText, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
            if (!p.bio.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(p.bio, style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp)
            }
            /*
             * پایه عمومی است، ولی ساعت بیداری مثل دقیقه‌های مطالعه فقط برای
             * دنبال‌کننده‌ها باز است.
             */
            val wake = p.wakeupTime?.takeIf { it.isNotBlank() }?.take(5)
            val chips = buildList {
                if (p.level > 0) {
                    // لقب اسطوره‌ای؛ اگر سرور قدیمی بود از جدول محلی خوانده می‌شود.
                    add(
                        ir.studying.app.core.Ranks.emojiFor(p.level, null) + " " +
                            ir.studying.app.core.Ranks.titleFor(p.level, p.levelTitle) +
                            " · سطح " + p.level.fa() to true,
                    )
                    add("⭐ امتیاز " + p.xp.fa() to false)
                }
                if (!p.eduLabel.isNullOrBlank()) add("🎓 ${p.eduLabel}" to true)
                if (wake != null) add((if (unlocked) "⏰ بیداری ${wake.fa()}" else "⏰ 🔒") to unlocked)
            }
            if (chips.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                FlowChips(chips)
            }
            if (p.followsMe && !mine) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "🤝 " + stringResource(R.string.feed_screen_009),
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(cs.surfaceVariant.copy(alpha = 0.7f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CountTile(p.following, "دنبال‌شده", Modifier.weight(1f)) { onFollowList("following") }
                CountTile(p.followers, "دنبال‌کننده", Modifier.weight(1f)) { onFollowList("followers") }
                CountTile(p.postsCount, "پست", Modifier.weight(1f)) { }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StudyTile("⏱", "امروز", if (unlocked) minutesNum(p.todayMinutes) else "🔒", Color(0xFF38BDF8), Modifier.weight(1f))
                StudyTile("📅", "این هفته", if (unlocked) minutesNum(p.weekMinutes) else "🔒", Color(0xFFA78BFA), Modifier.weight(1f))
                StudyTile("🔥", "استریک", p.streak.fa(), Color(0xFFFB923C), Modifier.weight(1f))
            }
            if (!unlocked) {
                Text(
                    stringResource(R.string.feed_screen_010),
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable
private fun ProfileAvatarBig(username: String, avatar: String?, mood: String?, online: Boolean, accent: Color) {
    val cs = MaterialTheme.colorScheme
    val key = Avatars.keyOf(avatar)
    if (key != null) {
        /* کاراکتر سه‌بعدی روی بنر می‌نشیند: هاله و سایه‌اش روی پس‌زمینه می‌افتد. */
        CharacterAvatar3D(key, size = 118.dp)
    } else {
        val t = rememberInfiniteTransition(label = "pfRing")
        val spin = t.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "pfSpin")
        Box(Modifier.size(100.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.matchParentSize()) {
                val sw = 3.dp.toPx()
                drawCircle(cs.background, size.minDimension / 2f)
                rotate(spin.value) {
                    drawCircle(
                        Brush.sweepGradient(listOf(accent, cs.primary, cs.secondary, accent), center),
                        size.minDimension / 2f - sw, center, style = Stroke(sw),
                    )
                }
            }
            Avatar(username, mood, size = 82.dp, online = online, avatarUrl = avatar)
        }
    }
}

@Composable
private fun LiveDot() {
    val t = rememberInfiniteTransition(label = "liveDot")
    val a = t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "liveA")
    Canvas(Modifier.size(8.dp)) {
        drawCircle(Color(0xFF22C55E).copy(alpha = 0.3f * a.value), size.minDimension / 2f)
        drawCircle(Color(0xFF22C55E), size.minDimension / 3.2f)
    }
}

@Composable
private fun FlowChips(chips: List<Pair<String, Boolean>>) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        chips.forEach { (text, strong) ->
            Text(
                text,
                style = MaterialTheme.typography.labelMedium,
                color = if (strong) cs.primary else cs.onSurfaceVariant,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(
                        if (strong) cs.primary.copy(alpha = 0.12f) else cs.surfaceVariant.copy(alpha = 0.6f),
                    )
                    .border(
                        1.dp,
                        if (strong) cs.primary.copy(alpha = 0.25f) else Color.Transparent,
                        CircleShape,
                    )
                    .padding(horizontal = 11.dp, vertical = 6.dp),
            )
        }
    }
}

/** کاشی شمارنده که عددش از صفر بالا می‌شمارد. */
@Composable
private fun CountTile(count: Int, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var target by remember { mutableIntStateOf(0) }
    LaunchedEffect(count) { target = count }
    val shown by animateIntAsState(target, tween(900, easing = FastOutSlowInEasing), label = "count$label")
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            .bouncyClick(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(shown.fa(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun StudyTile(emoji: String, label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.2f), tint.copy(alpha = 0.06f))))
            .border(1.dp, tint.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 18.sp)
        Text(
            value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = lerp(tint, cs.onSurface, 0.15f),
            maxLines = 1,
        )
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

// ============================================================ نویسنده

/** حلقهٔ شمارندهٔ نویسه‌ها (مثل توییتر): نزدیک سقف زرد و بعدش قرمز می‌شود. */
@Composable
internal fun CharCounterRing(used: Int, max: Int, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val f by animateFloatAsState((used.toFloat() / max).coerceIn(0f, 1f), tween(220), label = "charF")
    val over = used > max
    val warn = used > max * 0.85f
    val color = when {
        over -> cs.error
        warn -> Color(0xFFF59E0B)
        else -> cs.primary
    }
    Box(modifier.size(30.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val sw = 3.dp.toPx()
            val r = size.minDimension / 2f - sw
            drawCircle(cs.outlineVariant.copy(alpha = 0.6f), r, center, style = Stroke(sw))
            drawArc(
                color, -90f, 360f * f, false,
                topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2, r * 2),
                style = Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
        }
        if (warn) {
            Text((max - used).fa(), style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, color = color)
        }
    }
}

/** چیپ پیوست رنگی در نویسنده. */
@Composable
internal fun AttachChip(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .padding(end = 8.dp)
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.13f))
            .border(1.dp, tint.copy(alpha = 0.3f), CircleShape)
            .bouncyClick(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = tint)
    }
}
