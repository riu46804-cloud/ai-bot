@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material.ExperimentalMaterialApi::class)

package ir.studying.app.ui.feed

import ir.studying.app.R
import androidx.compose.ui.res.stringResource
import ir.studying.app.ui.components.AppSnack
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.FormatQuote
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import ir.studying.app.core.Api
import ir.studying.app.core.Fmt
import ir.studying.app.core.NavBus
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.data.FollowUser
import ir.studying.app.data.MusicTrack
import ir.studying.app.data.Post
import ir.studying.app.data.SocialProfile
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.GlassAction
import ir.studying.app.ui.components.GlassDivider
import ir.studying.app.ui.components.GlassMenu
import ir.studying.app.ui.components.LoadingBox
import ir.studying.app.ui.components.SegmentedTabs
import ir.studying.app.ui.library.fileNameOf
import ir.studying.app.ui.media.MediaViewer
import ir.studying.app.ui.messages.AudioBubble
import ir.studying.app.ui.messages.ChatMedia
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.riseIn
import ir.studying.app.ui.components.shine

// ==================== ViewModel ====================
class FeedViewModel : ViewModel() {
    data class State(
        val loading: Boolean = true,
        val error: String? = null,
        val forYou: List<Post> = emptyList(),
        val following: List<Post> = emptyList(),
        val searchUsers: List<FollowUser> = emptyList(),
        val searchPosts: List<Post> = emptyList(),
        val searching: Boolean = false,
        val posting: Boolean = false,
        val uploadPercent: Int? = null,
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> get() = _state
    private var searchJob: Job? = null

    init {
        refresh()
        viewModelScope.launch { RefreshBus.events.collect { if (it == "feed" || it == "all") refresh(silent = true) } }
        viewModelScope.launch { while (true) { delay(45000); refresh(silent = true) } }
    }

    fun refresh(silent: Boolean = false) {
        viewModelScope.launch {
            if (!silent) _state.value = _state.value.copy(loading = _state.value.forYou.isEmpty(), error = null)
            runCatching {
                val fy = Post.list(Api.arr(Api.get("feed", "tab" to "foryou")))
                val fl = Post.list(Api.arr(Api.get("feed", "tab" to "following")))
                _state.value = _state.value.copy(loading = false, error = null, forYou = fy, following = fl)
                markViewed(fy.take(20).map { it.id })
            }.onFailure { e ->
                _state.value = _state.value.copy(loading = false,
                    error = if (_state.value.forYou.isEmpty()) (e.message ?: "خطا") else null)
            }
        }
    }

    private fun markViewed(ids: List<Int>) {
        if (ids.isEmpty()) return
        viewModelScope.launch { runCatching { Api.post("post_view", JSONObject().put("ids", org.json.JSONArray(ids))) } }
    }

    private fun patchEverywhere(id: Int, f: (Post) -> Post) {
        _state.value = _state.value.copy(
            forYou = _state.value.forYou.map { if (it.id == id) f(it) else it },
            following = _state.value.following.map { if (it.id == id) f(it) else it },
            searchPosts = _state.value.searchPosts.map { if (it.id == id) f(it) else it },
        )
    }

    fun toggleLike(p: Post) {
        patchEverywhere(p.id) { it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0)) }
        viewModelScope.launch { runCatching { Api.post("post_like", JSONObject().put("id", p.id)) } }
    }

    fun repost(p: Post, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            runCatching { Api.post("post_create", JSONObject().put("repost_of", p.repostOf ?: p.id)) }
                .onSuccess { patchEverywhere(p.id) { it.copy(reposted = true, reposts = it.reposts + 1) }; refresh(silent = true); onDone(null) }
                .onFailure { onDone(it.message) }
        }
    }

    fun delete(p: Post, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            runCatching { Api.delete("post_delete", "id" to p.id.toString()) }
                .onSuccess {
                    _state.value = _state.value.copy(
                        forYou = _state.value.forYou.filter { it.id != p.id },
                        following = _state.value.following.filter { it.id != p.id })
                    onDone(null)
                }.onFailure { onDone(it.message) }
        }
    }

    fun search(q: String) {
        searchJob?.cancel()
        if (q.isBlank()) { _state.value = _state.value.copy(searchUsers = emptyList(), searchPosts = emptyList(), searching = false); return }
        searchJob = viewModelScope.launch {
            delay(350)
            _state.value = _state.value.copy(searching = true)
            runCatching {
                val users = FollowUser.list(Api.arr(Api.get("social_search", "q" to q, "kind" to "users")))
                val posts = Post.list(Api.arr(Api.get("social_search", "q" to q, "kind" to "posts")))
                _state.value = _state.value.copy(searchUsers = users, searchPosts = posts, searching = false)
            }.onFailure { _state.value = _state.value.copy(searching = false) }
        }
    }

    fun createPost(ctx: android.content.Context, text: String, mediaUri: Uri?, mediaType: String?, musicId: Int?, replyTo: Int?, repostOf: Int? = null, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(posting = true, uploadPercent = if (mediaUri != null) 0 else null)
            runCatching {
                if (mediaUri != null && mediaType != null) {
                    val bytes = ctx.contentResolver.openInputStream(mediaUri)?.readBytes() ?: throw Exception("خطا در خواندن فایل")
                    val name = fileNameOf(ctx, mediaUri).ifBlank { "media" }
                    val mime = ctx.contentResolver.getType(mediaUri) ?: "application/octet-stream"
                    val fields = HashMap<String, String>()
                    if (text.isNotBlank()) fields["text"] = text
                    fields["media_type"] = mediaType
                    if (replyTo != null) fields["reply_to"] = replyTo.toString()
                    if (repostOf != null) fields["repost_of"] = repostOf.toString()
                    Api.upload("post_create", fields, listOf(Api.FilePart("file", name, bytes, mime))) { p ->
                        _state.value = _state.value.copy(uploadPercent = p)
                    }
                } else {
                    val b = JSONObject()
                    if (text.isNotBlank()) b.put("text", text)
                    if (musicId != null) b.put("music_id", musicId)
                    if (replyTo != null) b.put("reply_to", replyTo)
                    if (repostOf != null) b.put("repost_of", repostOf)
                    Api.post("post_create", b)
                }
            }.onSuccess {
                _state.value = _state.value.copy(posting = false, uploadPercent = null)
                refresh(silent = true); RefreshBus.emit("feed"); onDone(null)
            }.onFailure {
                _state.value = _state.value.copy(posting = false, uploadPercent = null)
                onDone(it.message ?: "خطا در ارسال")
            }
        }
    }
}

class PostDetailViewModel : ViewModel() {
    data class State(val loading: Boolean = true, val post: Post? = null, val replies: List<Post> = emptyList(), val error: String? = null)
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> get() = _state
    private var pid = -1

    fun load(id: Int) {
        pid = id
        viewModelScope.launch {
            runCatching {
                val o = Api.obj(Api.get("post_detail", "id" to id.toString()))
                _state.value = State(loading = false,
                    post = Post.from(o.getJSONObject("post")),
                    replies = o.optJSONArray("replies")?.let { Post.list(it) } ?: emptyList())
            }.onFailure { _state.value = State(loading = false, error = it.message) }
        }
    }
    fun reload() { if (pid > 0) load(pid) }
    fun toggleLike(p: Post) {
        val f = { x: Post -> if (x.id == p.id) x.copy(liked = !x.liked, likes = (x.likes + if (x.liked) -1 else 1).coerceAtLeast(0)) else x }
        _state.value = _state.value.copy(post = _state.value.post?.let(f), replies = _state.value.replies.map(f))
        viewModelScope.launch { runCatching { Api.post("post_like", JSONObject().put("id", p.id)) } }
    }
}

class SocialProfileViewModel : ViewModel() {
    data class State(val loading: Boolean = true, val profile: SocialProfile? = null, val posts: List<Post> = emptyList(), val error: String? = null)
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> get() = _state
    private var user = ""

    fun load(username: String) {
        user = username
        viewModelScope.launch {
            runCatching {
                val o = Api.obj(Api.get("social_profile", "username" to username))
                _state.value = State(loading = false,
                    profile = SocialProfile.from(o),
                    posts = o.optJSONArray("posts")?.let { Post.list(it) } ?: emptyList())
            }.onFailure { _state.value = State(loading = false, error = it.message) }
        }
    }

    fun toggleFollow(onDone: (String?) -> Unit = {}) {
        val p = _state.value.profile ?: return
        _state.value = _state.value.copy(profile = p.copy(
            isFollowing = !p.isFollowing,
            followers = (p.followers + if (p.isFollowing) -1 else 1).coerceAtLeast(0)))
        viewModelScope.launch {
            runCatching { Api.post(if (p.isFollowing) "unfollow" else "follow", JSONObject().put("username", p.username)) }
                .onSuccess { RefreshBus.emit("feed"); RefreshBus.emit("home"); onDone(null) }
                .onFailure { load(user); onDone(it.message) }
        }
    }

    fun toggleLike(p2: Post) {
        _state.value = _state.value.copy(posts = _state.value.posts.map {
            if (it.id == p2.id) it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0)) else it
        })
        viewModelScope.launch { runCatching { Api.post("post_like", JSONObject().put("id", p2.id)) } }
    }
}

// ==================== مسیرهای داخلی ====================
private sealed class FeedRoute {
    object Home : FeedRoute()
    data class Detail(val id: Int) : FeedRoute()
    data class Profile(val username: String) : FeedRoute()
}

// ==================== صفحه اصلی فید ====================
@Composable
fun FeedScreen(vm: FeedViewModel = viewModel()) {
    var route by remember { mutableStateOf<FeedRoute>(FeedRoute.Home) }
    // درخواست باز کردن پروفایل از تب‌های دیگر (مثلاً اتاق مطالعه)
    val userReq by NavBus.openUser.collectAsState()
    LaunchedEffect(userReq) {
        val u = userReq
        if (u != null) { route = FeedRoute.Profile(u); NavBus.consumeUser() }
    }
    // باز کردن یک پست مشخص از اعلان (لایک/پاسخ/بازنشر)
    val postReq by NavBus.openPost.collectAsState()
    LaunchedEffect(postReq) {
        val id = postReq
        if (id != null) { route = FeedRoute.Detail(id); NavBus.consumePost() }
    }
    AnimatedContent(
        targetState = route,
        transitionSpec = {
            (fadeIn(tween(240, easing = FastOutSlowInEasing)) + slideInVertically(tween(240)) { it / 22 })
                .togetherWith(fadeOut(tween(130)))
        }, label = "feedRoute",
    ) { r ->
        when (r) {
            is FeedRoute.Home -> FeedHome(vm,
                onOpenPost = { route = FeedRoute.Detail(it) },
                onOpenUser = { route = FeedRoute.Profile(it) })
            is FeedRoute.Detail -> {
                BackHandler { route = FeedRoute.Home }
                PostDetailScreen(r.id, onBack = { route = FeedRoute.Home }, onOpenUser = { route = FeedRoute.Profile(it) })
            }
            is FeedRoute.Profile -> {
                BackHandler { route = FeedRoute.Home }
                SocialProfileScreen(r.username, onBack = { route = FeedRoute.Home },
                    onOpenPost = { route = FeedRoute.Detail(it) },
                    onOpenUser = { route = FeedRoute.Profile(it) })
            }
        }
    }
}

@Composable
private fun FeedHome(vm: FeedViewModel, onOpenPost: (Int) -> Unit, onOpenUser: (String) -> Unit) {
    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var showComposer by remember { mutableStateOf(false) }
    var replyTarget by remember { mutableStateOf<Post?>(null) }
    var menuPost by remember { mutableStateOf<Post?>(null) }
    var editPost by remember { mutableStateOf<Post?>(null) }
    var quotePost by remember { mutableStateOf<Post?>(null) }
    var likersPost by remember { mutableStateOf<Post?>(null) }
    val me = Store.username ?: ""
    val listState = rememberLazyListState()
    var refreshing by remember { mutableStateOf(false) }
    val scopeRf = androidx.compose.runtime.rememberCoroutineScope()
    val pullState = rememberPullRefreshState(refreshing, {
        refreshing = true
        vm.refresh(silent = true)
        scopeRf.launch { kotlinx.coroutines.delay(900); refreshing = false }
    })

    var searchOpen by rememberSaveable { mutableStateOf(query.isNotBlank()) }
    /* دکمهٔ ساخت فقط بالای فید باز است؛ با اسکرول به دایره جمع می‌شود. */
    val fabExpanded by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }

    Box(Modifier.fillMaxSize().pullRefresh(pullState)) {
        FeedHomeBody(
            state = state,
            me = me,
            meAvatar = Store.prefs.value.avatar,
            tab = tab,
            onTab = { tab = it },
            query = query,
            onQuery = { query = it; vm.search(it) },
            searchOpen = searchOpen,
            onSearchOpen = { searchOpen = it },
            listState = listState,
            onOpenPost = onOpenPost,
            onOpenUser = onOpenUser,
            onLike = { vm.toggleLike(it) },
            onReply = { replyTarget = it; showComposer = true },
            onRepost = { p -> vm.repost(p) { e -> AppSnack.show(e ?: "بازنشر شد 🔁") } },
            onLikers = { likersPost = it },
            onMenu = { menuPost = it },
            onCompose = { replyTarget = null; showComposer = true },
            onRetry = { vm.refresh() },
            search = { SearchResults(state, onOpenUser, onOpenPost, vm) },
        )

        PullRefreshIndicator(refreshing, pullState,
            Modifier.align(Alignment.TopCenter),
            backgroundColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary)

        FeedFab(
            expanded = fabExpanded,
            onClick = { replyTarget = null; showComposer = true },
            modifier = Modifier.align(Alignment.BottomStart).padding(18.dp),
        )
    }

    if (showComposer) {
        ComposerSheet(vm, replyTo = replyTarget, quoteOf = quotePost,
            onDismiss = { showComposer = false; replyTarget = null; quotePost = null })
    }

    editPost?.let { p ->
        EditPostSheet(p, onDismiss = { editPost = null }, onSaved = { editPost = null; vm.refresh(silent = true) })
    }

    likersPost?.let { p ->
        LikersSheet(p.repostOf ?: p.id, onDismiss = { likersPost = null }, onOpenUser = { u -> likersPost = null; onOpenUser(u) })
    }

    menuPost?.let { p ->
        val clip = androidx.compose.ui.platform.LocalClipboardManager.current
        GlassMenu(onDismiss = { menuPost = null }) {
            if (p.username == me) {
                GlassAction(Icons.Rounded.Edit, "ویرایش پست") { editPost = p }
                GlassAction(Icons.Rounded.Delete, "حذف پست", danger = true) {
                    vm.delete(p) { e -> AppSnack.show(e ?: "حذف شد") }
                }
            } else {
                GlassAction(Icons.Rounded.Person, "دیدن پروفایل ${p.username}") { onOpenUser(p.username) }
                GlassAction(Icons.AutoMirrored.Rounded.Send, "پیام خصوصی") { NavBus.requestDm(p.username) }
            }
            GlassDivider()
            GlassAction(Icons.Rounded.FormatQuote, "نقل‌قول با متن") { quotePost = p; showComposer = true }
            if (!p.text.isNullOrBlank()) GlassAction(Icons.Rounded.ContentCopy, "کپی متن") {
                clip.setText(androidx.compose.ui.text.AnnotatedString(ir.studying.app.core.AutoPost.strip(p.text)))
                AppSnack.show("کپی شد")
            }
        }
    }
}

/**
 * بدنهٔ بی‌حالت فید: هدر، ردیف درس‌خون‌ها، تب‌های چسبان و کارت‌های پست.
 *
 * چرا جدا از FeedHome: همهٔ حالت‌ها (شیت‌ها، منوها، ViewModel) بیرون
 * می‌مانند و این تکه فقط داده می‌گیرد؛ هم خواناتر است و هم بی‌شبکه قابل
 * پیش‌نمایش.
 */
@Composable
internal fun FeedHomeBody(
    state: FeedViewModel.State,
    me: String,
    meAvatar: String?,
    tab: Int,
    onTab: (Int) -> Unit,
    query: String,
    onQuery: (String) -> Unit,
    searchOpen: Boolean,
    onSearchOpen: (Boolean) -> Unit,
    listState: LazyListState,
    onOpenPost: (Int) -> Unit,
    onOpenUser: (String) -> Unit,
    onLike: (Post) -> Unit,
    onReply: (Post) -> Unit,
    onRepost: (Post) -> Unit,
    onLikers: (Post) -> Unit,
    onMenu: (Post) -> Unit,
    onCompose: () -> Unit,
    onRetry: () -> Unit,
    search: @Composable () -> Unit,
) {
    val bg = MaterialTheme.colorScheme.background
    Column(Modifier.fillMaxSize()) {
        FeedHeader(query, onQuery, searchOpen || query.isNotBlank(), onSearchOpen)
        if (query.isNotBlank()) {
            search()
            return@Column
        }
        val tabs = listOf("✨ برای شما", "🫂 دنبال‌شده‌ها")
        val posts = if (tab == 0) state.forYou else state.following
        /* آدم‌های ردیف بالا از نویسنده‌های همین فید می‌آیند؛ درخواست جدایی لازم نیست. */
        val people = remember(state.forYou, me) {
            state.forYou.asSequence()
                .filter { it.username != me && it.repostOf == null }
                .map { it.username to it.avatar }
                .distinctBy { it.first }
                .take(14)
                .toList()
        }
        when {
            state.loading -> Column {
                FeedTabs(tabs, tab, onTab, Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                Column(Modifier.padding(16.dp)) { LoadingBox(height = 300.dp) }
            }
            state.error != null -> ErrorState(state.error, onRetry = onRetry)
            else -> LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                item(key = "people") {
                    PeopleRow(
                        people, me, meAvatar,
                        onCompose = onCompose,
                        onUser = onOpenUser,
                        modifier = Modifier.padding(top = 2.dp, bottom = 6.dp),
                    )
                }
                stickyHeader(key = "tabs") {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(bg)
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                    ) { FeedTabs(tabs, tab, onTab) }
                }
                if (posts.isEmpty()) {
                    item(key = "empty$tab") {
                        if (tab == 1) EmptyState("🫂", "هنوز کسی رو دنبال نکردی!\nاز تب «برای شما» درس‌خون‌ها رو پیدا کن")
                        else EmptyState("🌱", "هنوز پستی نیست — اولین نفر باش!")
                    }
                }
                itemsIndexed(posts, key = { _, p -> "p${p.id}" }) { i, p ->
                    PostCard(p, me,
                        onOpen = { onOpenPost(p.id) },
                        onUser = { onOpenUser(it) },
                        onLike = { onLike(p) },
                        onReply = { onReply(p) },
                        onRepost = { onRepost(p) },
                        onLikers = { onLikers(p) },
                        onLongPress = { onMenu(p) },
                        /* فقط کارت‌های صفحهٔ اول پلکانی وارد می‌شوند؛ بقیه با اسکرول بی‌تأخیر. */
                        modifier = Modifier.animateItemPlacement().then(if (i < 7) Modifier.riseIn(i) else Modifier),
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchResults(state: FeedViewModel.State, onOpenUser: (String) -> Unit, onOpenPost: (Int) -> Unit, vm: FeedViewModel) {
    val me = Store.username ?: ""
    LazyColumn(Modifier.fillMaxSize()) {
        if (state.searching) item { LoadingBox(height = 120.dp, modifier = Modifier.padding(16.dp)) }
        if (state.searchUsers.isNotEmpty()) {
            item { Text(stringResource(R.string.feed_screen_003), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
            itemsIndexed(state.searchUsers, key = { _, it -> "u${it.username}" }) { i, u ->
                val acc = accentOf(u.username, u.avatar)
                Box(
                    Modifier
                        .riseIn(i.coerceAtMost(6))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.horizontalGradient(listOf(acc.copy(alpha = 0.12f), MaterialTheme.colorScheme.surface)))
                        .border(1.dp, acc.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                        .clickable { onOpenUser(u.username) },
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.username, u.mood, size = 42.dp, avatarUrl = u.avatar)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(u.username, style = MaterialTheme.typography.titleSmall)
                            Text("امروز ${Fmt.minutes(u.todayMinutes)}" + if (u.followsMe) " · دنبالت می‌کنه" else "",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (u.username != me) FollowChip(u.isFollowing) { }
                    }
                }
            }
        }
        if (state.searchPosts.isNotEmpty()) {
            item { Text(stringResource(R.string.feed_screen_004), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
            items(state.searchPosts, key = { "sp${it.id}" }) { p ->
                PostCard(p, me, onOpen = { onOpenPost(p.id) }, onUser = onOpenUser, onLike = { vm.toggleLike(p) }, onReply = { onOpenPost(p.id) }, onRepost = {}, onLongPress = {})
            }
        }
        if (!state.searching && state.searchUsers.isEmpty() && state.searchPosts.isEmpty()) {
            item { EmptyState("🔍", "چیزی پیدا نشد") }
        }
    }
}

// ==================== کارت پست ====================
/**
 * کارت پست نسخهٔ ۲.۹: کارت شناور با رنگ کاراکتر نویسنده، نوار اکشن قرصی و
 * «دوبار لمس = لایک» با ترکیدن قلب. امضای تابع همان قبلی است.
 */
@Composable
fun PostCard(
    p: Post, me: String,
    onOpen: () -> Unit, onUser: (String) -> Unit, onLike: () -> Unit,
    onReply: () -> Unit, onRepost: () -> Unit, onLongPress: () -> Unit,
    onLikers: () -> Unit = {},
    clickable: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    // بازنشر با متن (نقل‌قول): متن خودِ کاربر بدنه است و پست اصلی در کارت نقل‌قول می‌آید
    val isQuote = p.repostOf != null && !p.text.isNullOrBlank()
    val asOriginal = p.repostOf != null && !isQuote
    val author = if (asOriginal && p.repostUser != null) p.repostUser else p.username
    val bodyText = if (asOriginal) p.repostText else p.text
    val authorAvatar = if (!asOriginal) p.avatar else null
    val character = ir.studying.app.core.Avatars.characterOfValue(authorAvatar)
    val accent = accentOf(author, authorAvatar)
    val burst = remember { Animatable(0f) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val shape = RoundedCornerShape(24.dp)
    Box(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(cs.surface)
                .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.10f), Color.Transparent), endY = 380f))
                .border(
                    1.dp,
                    Brush.verticalGradient(listOf(accent.copy(alpha = 0.34f), cs.outlineVariant.copy(alpha = 0.25f))),
                    shape,
                )
                .combinedClickable(
                    enabled = clickable,
                    onClick = onOpen,
                    onLongClick = onLongPress,
                    onDoubleClick = {
                        if (!p.liked) onLike()
                        scope.launch {
                            burst.snapTo(0f)
                            burst.animateTo(1f, tween(900, easing = LinearEasing))
                        }
                    },
                )
                .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 6.dp),
        ) {
            if (asOriginal) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .padding(bottom = 8.dp)
                        .clip(CircleShape)
                        .background(RepostGreen.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                ) {
                    Icon(Icons.Rounded.Repeat, null, tint = RepostGreen, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("${p.username} بازنشر کرد", style = MaterialTheme.typography.labelSmall, color = RepostGreen)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(CircleShape).clickable { onUser(author) }) {
                    Avatar(author, p.mood.takeIf { !asOriginal }, size = 44.dp, avatarUrl = authorAvatar)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            author,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.clickable { onUser(author) },
                        )
                        if (character != null) {
                            Spacer(Modifier.width(5.dp))
                            Text(character.emoji, fontSize = 12.sp)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(Fmt.relative(p.createdAt), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        if (p.replyTo != null && p.replyToUser != null) {
                            Text(" · ", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            Text("در پاسخ به ${p.replyToUser}", style = MaterialTheme.typography.labelSmall, color = cs.primary)
                        }
                    }
                }
                Box(
                    Modifier.size(34.dp).clip(CircleShape).clickable { onLongPress() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.MoreHoriz, "گزینه‌ها", tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
                }
            }
            val achievement = ir.studying.app.core.AutoPost.parse(bodyText)
            if (achievement != null) {
                AchievementCard(achievement)
            } else if (!bodyText.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(bodyText, style = MaterialTheme.typography.bodyLarge, lineHeight = 25.sp)
            }
            if (isQuote) {
                Spacer(Modifier.height(8.dp))
                QuoteCard(p.repostUser, p.repostText) { p.repostUser?.let { u -> onUser(u) } }
            }
            PostMedia(p)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(cs.onSurface.copy(alpha = 0.04f))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ir.studying.app.ui.components.CommentPop(
                    count = if (p.replies > 0) p.replies.fa() else "",
                    onClick = onReply,
                )
                ir.studying.app.ui.components.RepostSpin(
                    active = p.reposted,
                    count = if (p.reposts > 0) p.reposts.fa() else "",
                    onClick = onRepost,
                )
                LikeStat(p.liked, p.likes, onLike, onCount = { onLikers() })
                ir.studying.app.ui.components.PulseStat(
                    icon = Icons.Rounded.BarChart,
                    count = if (p.views > 0) p.views.fa() else "",
                )
            }
            Spacer(Modifier.height(6.dp))
        }
        HeartBurst(progress = { burst.value }, modifier = Modifier.matchParentSize())
    }
}

private val RepostGreen = Color(0xFF22C55E)

@Composable
private fun QuoteCard(author: String?, text: String?, onAuthor: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(author ?: "?", null, size = 20.dp)
                Spacer(Modifier.width(6.dp))
                Text(author ?: "کاربر", style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.clickable { onAuthor() })
            }
            if (!text.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(text, style = MaterialTheme.typography.bodySmall, lineHeight = 19.sp, maxLines = 6)
            }
        }
    }
}

@Composable
private fun ActionStat(icon: androidx.compose.ui.graphics.vector.ImageVector, count: Int, tint: Color, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clip(CircleShape).clickable { onClick() }.padding(horizontal = 8.dp, vertical = 5.dp)) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(4.dp))
        Text(if (count > 0) count.fa() else "", style = MaterialTheme.typography.labelSmall, color = tint)
    }
}

@Composable
private fun LikeStat(liked: Boolean, count: Int, onClick: () -> Unit, onCount: () -> Unit = {}) {
    val tint = if (liked) ir.studying.app.ui.components.HeartColor else MaterialTheme.colorScheme.onSurfaceVariant
    Row(verticalAlignment = Alignment.CenterVertically) {
        ir.studying.app.ui.components.HeartLike(
            liked = liked,
            onClick = onClick,
            size = 19.dp,
            idleColor = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        // مثل توییتر: کلیک روی عدد → چه کسانی لایک کردند
        Text(if (count > 0) count.fa() else "", style = MaterialTheme.typography.labelSmall, color = tint,
            modifier = Modifier.clip(CircleShape).clickable(enabled = count > 0) { onCount() }.padding(horizontal = 5.dp, vertical = 4.dp))
    }
}

@Composable
private fun PostMedia(p: Post) {
    val ctx = LocalContext.current
    when (p.mediaType) {
        "image" -> {
            var full by remember(p.mediaPath) { mutableStateOf(false) }
            Spacer(Modifier.height(8.dp))
            AsyncImage(model = Api.mediaUrl(p.mediaPath), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant).clickable { full = true })
            if (full) MediaViewer(p.mediaPath, "image") { full = false }
        }
        "video" -> {
            Spacer(Modifier.height(8.dp))
            var vfull by remember(p.mediaPath) { mutableStateOf(false) }
            if (vfull) MediaViewer(p.mediaPath, "video") { vfull = false }
            Box(Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp))
                .background(Color.Black.copy(alpha = 0.85f))
                .clickable { vfull = true }, contentAlignment = Alignment.Center) {
                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.92f)) {
                    Icon(Icons.Rounded.Videocam, "پخش ویدئو", tint = Color.Black, modifier = Modifier.padding(16.dp).size(26.dp))
                }
                Text(stringResource(R.string.feed_screen_005), color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp))
            }
        }
        "music" -> {
            Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)) {
                Column(Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (p.musicCover != null) AsyncImage(model = Api.mediaUrl(p.musicCover), contentDescription = null,
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                        else Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)) {
                            Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(10.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(p.musicTitle ?: "موزیک", style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(p.musicArtist ?: "", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    AudioBubble(Api.mediaUrl(p.mediaPath), 0, "🎵")
                }
            }
        }
    }
}

// ==================== جزئیات پست + پاسخ‌ها ====================
@Composable
fun PostDetailScreen(id: Int, onBack: () -> Unit, onOpenUser: (String) -> Unit, vm: PostDetailViewModel = viewModel(key = "post_$id")) {
    var dMenu by remember { mutableStateOf<Post?>(null) }
    var dEdit by remember { mutableStateOf<Post?>(null) }
    var dLikers by remember { mutableStateOf<Post?>(null) }

    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    val feedVm: FeedViewModel = viewModel()
    var showReply by remember { mutableStateOf(false) }
    val me = Store.username ?: ""
    LaunchedEffect(id) { vm.load(id) }

    Column(Modifier.fillMaxSize()) {
        FeedTopBar(
            title = stringResource(R.string.feed_screen_002),
            subtitle = state.post?.let { "از " + it.username },
            onBack = onBack,
        )
        when {
            state.loading -> Column(Modifier.padding(16.dp)) { LoadingBox(height = 220.dp) }
            state.error != null -> ErrorState(state.error!!, onRetry = { vm.reload() })
            state.post != null -> LazyColumn(Modifier.fillMaxSize()) {
                item {
                    PostCard(state.post!!, me, onOpen = {}, onUser = onOpenUser,
                        onLike = { vm.toggleLike(state.post!!) },
                        onReply = { showReply = true },
                        onRepost = { feedVm.repost(state.post!!) { e -> AppSnack.show(e ?: "بازنشر شد 🔁"); vm.reload() } },
                        onLikers = { dLikers = state.post }, onLongPress = { dMenu = state.post }, clickable = false)
                    /* نوار «پاسخت رو بنویس» — قرص شیشه‌ای با آواتار خودت */
                    Row(
                        Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                            .clickable { showReply = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(me, size = 32.dp, avatarUrl = Store.prefs.value.avatar)
                        Spacer(Modifier.width(10.dp))
                        Text(stringResource(R.string.feed_screen_006), style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        Icon(Icons.AutoMirrored.Rounded.Send, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    if (state.replies.isNotEmpty()) {
                        Text(
                            "پاسخ‌ها · " + state.replies.size.fa(),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 2.dp),
                        )
                    }
                }
                itemsIndexed(state.replies, key = { _, it -> "r${it.id}" }) { i, r ->
                    PostCard(r, me, onOpen = {}, onUser = onOpenUser, onLike = { vm.toggleLike(r) },
                        onReply = { showReply = true }, onRepost = {}, onLikers = { dLikers = r }, onLongPress = { dMenu = r }, clickable = false,
                        modifier = if (i < 6) Modifier.riseIn(i) else Modifier)
                }
                if (state.replies.isEmpty()) item { EmptyState("💬", "هنوز پاسخی نیست — اولین نفر باش!") }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
    if (showReply) ComposerSheet(feedVm, replyTo = state.post, onDismiss = { showReply = false; vm.reload() })

    dMenu?.let { mp ->
        PostGlassMenu(mp, me, onDismiss = { dMenu = null }, onOpenUser = onOpenUser,
            onEdit = { dEdit = it }, onQuote = { }, onDeleted = { onBack() })
    }
    dEdit?.let { ep -> EditPostSheet(ep, onDismiss = { dEdit = null }, onSaved = { dEdit = null; vm.load(id) }) }
    dLikers?.let { lp -> LikersSheet(lp.repostOf ?: lp.id, onDismiss = { dLikers = null }, onOpenUser = { u -> dLikers = null; onOpenUser(u) }) }
}

// ==================== پروفایل کاربر (سبک توییتر) ====================
@Composable
fun SocialProfileScreen(
    username: String, onBack: () -> Unit, onOpenPost: (Int) -> Unit, onOpenUser: (String) -> Unit,
    vm: SocialProfileViewModel = viewModel(key = "soc_$username"),
) {
    var userMenu by remember { mutableStateOf(false) }
    val profScope = androidx.compose.runtime.rememberCoroutineScope()
    var profMenu by remember { mutableStateOf<Post?>(null) }
    var profEdit by remember { mutableStateOf<Post?>(null) }
    var profQuote by remember { mutableStateOf<Post?>(null) }
    var profLikers by remember { mutableStateOf<Post?>(null) }

    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    val feedVm: FeedViewModel = viewModel()
    val me = Store.username ?: ""
    var followList by remember { mutableStateOf<String?>(null) } // "followers" | "following"
    LaunchedEffect(username) { vm.load(username) }

    Column(Modifier.fillMaxSize()) {
        FeedTopBar(
            title = state.profile?.displayName?.takeIf { it.isNotBlank() } ?: username,
            subtitle = state.profile?.let { it.postsCount.fa() + " پست" },
            onBack = onBack,
        )
        when {
            state.loading -> Column(Modifier.padding(16.dp)) { LoadingBox(height = 260.dp) }
            state.error != null -> ErrorState(state.error!!, onRetry = { vm.load(username) })
            state.profile != null -> {
                val p = state.profile!!
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        var showBanner by remember { mutableStateOf(false) }
                        var bannerId by remember(p.banner) { mutableStateOf(p.banner) }
                        SocialProfileHeader(
                            p = p,
                            me = me,
                            bannerId = bannerId,
                            onBanner = { showBanner = true },
                            onMenu = { userMenu = true },
                            onDm = { NavBus.requestDm(p.username) },
                            onFollow = { vm.toggleFollow { e -> if (e != null) AppSnack.show(e) } },
                            onFollowList = { followList = it },
                        )
                        if (showBanner) BannerPickerSheet(bannerId, onPicked = { bannerId = it; showBanner = false }, onDismiss = { showBanner = false })
                    }
                    itemsIndexed(state.posts, key = { _, it -> "pp${it.id}" }) { i, post ->
                        PostCard(post, me, onOpen = { onOpenPost(post.id) }, onUser = { if (it != username) onOpenUser(it) },
                            onLike = { vm.toggleLike(post) }, onReply = { onOpenPost(post.id) },
                            onRepost = { feedVm.repost(post) { e -> AppSnack.show(e ?: "بازنشر شد 🔁") } },
                            onLikers = { profLikers = post },
                            onLongPress = { profMenu = post },
                            modifier = if (i < 5) Modifier.riseIn(i) else Modifier)
                    }
                    if (state.posts.isEmpty()) item { EmptyState("📝", "هنوز پستی نذاشته") }
                    item { Spacer(Modifier.height(40.dp)) }
                }
            }
        }
    }
    followList?.let { kind ->
        FollowListSheet(username = username, kind = kind, onDismiss = { followList = null }, onOpenUser = { u -> followList = null; onOpenUser(u) })
    }

    profMenu?.let { mp ->
        PostGlassMenu(mp, me, onDismiss = { profMenu = null }, onOpenUser = { if (it != username) onOpenUser(it) },
            onEdit = { profEdit = it }, onQuote = { profQuote = it },
            onDeleted = { vm.load(username) })
    }
    profEdit?.let { ep -> EditPostSheet(ep, onDismiss = { profEdit = null }, onSaved = { profEdit = null; vm.load(username) }) }
    profLikers?.let { lp -> LikersSheet(lp.repostOf ?: lp.id, onDismiss = { profLikers = null }, onOpenUser = { u -> profLikers = null; if (u != username) onOpenUser(u) }) }
    profQuote?.let { qp ->
        ComposerSheet(feedVm, replyTo = null, quoteOf = qp, onDismiss = { profQuote = null })
    }

    if (userMenu) {
        val blocked = state.profile?.iBlocked == true
        GlassMenu(onDismiss = { userMenu = false }) {
            GlassAction(Icons.Rounded.Block, if (blocked) "آنبلاک $username" else "بلاک کردن $username", danger = !blocked) {
                profScope.launch {
                    runCatching { Api.post(if (blocked) "unblock" else "block", JSONObject().put("username", username)) }
                        .onSuccess {
                            AppSnack.show(if (blocked) "آنبلاک شد" else "بلاک شد 🚫")
                            vm.load(username)
                        }
                        .onFailure { AppSnack.show(it.message ?: "خطا") }
                }
            }
        }
    }
}

/** لیست فالوورها/فالویینگ‌ها — از پروفایل اپ هم استفاده می‌شود. */
@Composable
fun FollowListSheet(username: String, kind: String, onDismiss: () -> Unit, onOpenUser: (String) -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf<List<FollowUser>?>(null) }
    val me = Store.username ?: ""
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    LaunchedEffect(username, kind) {
        runCatching { FollowUser.list(Api.arr(Api.get(kind, "username" to username))) }
            .onSuccess { list = it }.onFailure { list = emptyList() }
    }
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp)) {
            Text(if (kind == "followers") "دنبال‌کننده‌ها 🫂" else "دنبال‌شده‌ها ✨", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            when {
                list == null -> LoadingBox(height = 140.dp)
                list!!.isEmpty() -> EmptyState("🍃", "هنوز کسی اینجا نیست")
                else -> LazyColumn(Modifier.height(400.dp)) {
                    items(list!!, key = { it.username }) { u ->
                        var isF by remember { mutableStateOf(u.isFollowing) }
                        Row(Modifier.fillMaxWidth().clickable { onOpenUser(u.username) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(u.username, u.mood, size = 40.dp, avatarUrl = u.avatar)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(u.username, style = MaterialTheme.typography.titleSmall)
                                if (u.followsMe) Text(stringResource(R.string.feed_screen_009), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (u.username != me) FollowChip(isF) {
                                isF = !isF
                                scope.launch {
                                    runCatching { Api.post(if (!isF) "unfollow" else "follow", JSONObject().put("username", u.username)) }
                                        .onSuccess { RefreshBus.emit("feed"); RefreshBus.emit("home") }
                                        .onFailure { isF = !isF; AppSnack.show(it.message ?: "خطا") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== کامپوزر پست (سبک توییتر) ====================
@Composable
private fun ComposerSheet(vm: FeedViewModel, replyTo: Post?, quoteOf: Post? = null, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    var text by remember { mutableStateOf("") }
    var mediaUri by remember { mutableStateOf<Uri?>(null) }
    var mediaType by remember { mutableStateOf<String?>(null) }
    var musicPick by remember { mutableStateOf<MusicTrack?>(null) }
    var showMusicPicker by remember { mutableStateOf(false) }
    val me = Store.username ?: ""
    val maxLen = 500

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { mediaUri = u; mediaType = "image"; musicPick = null } }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { mediaUri = u; mediaType = "video"; musicPick = null } }

    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = { if (!state.posting) onDismiss() }) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp).imePadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(ir.studying.app.ui.theme.brandGradient()),
                    contentAlignment = Alignment.Center,
                ) { Text(if (quoteOf != null) "🔁" else if (replyTo != null) "💬" else "✍️", fontSize = 18.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (quoteOf != null) "نقل‌قول" else if (replyTo != null) "پاسخ به ${replyTo.username}" else "پست جدید",
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black,
                    )
                    Text("${text.length.fa()}/${maxLen.fa()} نویسه", style = MaterialTheme.typography.labelSmall,
                        color = if (text.length > maxLen) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                CharCounterRing(text.length, maxLen)
            }
            (quoteOf ?: replyTo)?.let { qp ->
                Spacer(Modifier.height(6.dp))
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)) {
                    val quoted = ir.studying.app.core.AutoPost.strip(qp.text).ifBlank { "📎 رسانه" }
                    Text("${qp.username}: ${quoted.take(80)}", style = MaterialTheme.typography.bodySmall,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(10.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row {
                Avatar(me, size = 38.dp, avatarUrl = Store.prefs.value.avatar)
                Spacer(Modifier.width(10.dp))
                TextField(
                    value = text, onValueChange = { if (it.length <= maxLen + 40) text = it },
                    placeholder = { Text(if (replyTo != null) "پاسخت رو بنویس…" else "چه خبر از درس و مشق؟ 📖") },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent),
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                )
            }
            // پیش‌نمایش مدیا
            AnimatedVisibility(visible = mediaUri != null || musicPick != null, enter = fadeIn() + scaleIn(initialScale = 0.95f), exit = fadeOut() + scaleOut()) {
                Box(Modifier.padding(vertical = 6.dp)) {
                    when {
                        mediaType == "image" && mediaUri != null -> AsyncImage(model = mediaUri, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(16.dp)))
                        mediaType == "music" && mediaUri != null -> Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("🎵 ${fileNameOf(ctx, mediaUri!!)}", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        mediaType == "video" && mediaUri != null -> Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Videocam, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("🎬 ${fileNameOf(ctx, mediaUri!!)}", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        musicPick != null -> Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("🎵 ${musicPick!!.title} — ${musicPick!!.artist}", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.55f),
                        onClick = { mediaUri = null; mediaType = null; musicPick = null },
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                        Icon(Icons.Rounded.Close, "حذف", tint = Color.White, modifier = Modifier.padding(5.dp).size(16.dp))
                    }
                }
            }
            state.uploadPercent?.let {
                LinearProgressIndicator(progress = { it / 100f }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                    AttachChip(Icons.Rounded.Image, "عکس", Color(0xFFEC4899)) { pickImage.launch("image/*") }
                    AttachChip(Icons.Rounded.Videocam, "ویدئو", Color(0xFF3B82F6)) { pickVideo.launch("video/*") }
                    AttachChip(Icons.Rounded.MusicNote, "موزیک", Color(0xFF8B5CF6)) { showMusicPicker = true }
                }
                Spacer(Modifier.width(6.dp))
                val canSend = !state.posting && (text.isNotBlank() || mediaUri != null || musicPick != null) && text.length <= maxLen
                val sendBg = if (canSend) ir.studying.app.ui.theme.brandGradient()
                    else androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.surfaceVariant)
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(sendBg)
                        .shine(enabled = canSend)
                        .bouncyClick(enabled = canSend) {
                            vm.createPost(ctx, text.trim(), mediaUri, mediaType, musicPick?.id, replyTo?.id, repostOf = quoteOf?.let { it.repostOf ?: it.id }) { e ->
                                if (e == null) { AppSnack.show("منتشر شد 🎉"); onDismiss() }
                                else AppSnack.show(e)
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    if (state.posting) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.padding(12.dp).size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                    else Row(Modifier.padding(horizontal = 18.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.feed_screen_011), color = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Rounded.Send, null, modifier = Modifier.size(16.dp),
                            tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    if (showMusicPicker) {
        MusicSourceSheet(
            onLibrary = { t -> musicPick = t; mediaUri = null; mediaType = null; showMusicPicker = false },
            onDevice = { u -> mediaUri = u; mediaType = "music"; musicPick = null; showMusicPicker = false },
            onDismiss = { showMusicPicker = false })
    }
}

/** انتخاب موزیک یکپارچه: از کتابخانه Studying یا فایل‌های دستگاه — یک بخش برای هر دو. */
@Composable
fun MusicSourceSheet(onLibrary: (MusicTrack) -> Unit, onDevice: (Uri) -> Unit, onDismiss: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) onDevice(u) }
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
            Text(stringResource(R.string.feed_screen_012), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            SegmentedTabs(options = listOf("کتابخانه Studying", "فایل‌های دستگاه"), selected = tab) { t ->
                tab = t
                if (t == 1) pickAudio.launch("audio/*")
            }
            Spacer(Modifier.height(8.dp))
            if (tab == 0) {
                ir.studying.app.ui.messages.ChatMusicPickerInline(onPick = onLibrary)
            } else {
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    onClick = { pickAudio.launch("audio/*") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text(stringResource(R.string.feed_screen_013), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

/** لیست لایک‌کننده‌های پست — مثل توییتر. */
@Composable
fun LikersSheet(postId: Int, onDismiss: () -> Unit, onOpenUser: (String) -> Unit) {
    var list by remember { mutableStateOf<List<FollowUser>?>(null) }
    LaunchedEffect(postId) {
        runCatching { FollowUser.list(Api.arr(Api.get("post_likers", "id" to postId.toString()))) }
            .onSuccess { list = it }.onFailure { list = emptyList() }
    }
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp)) {
            Text(stringResource(R.string.feed_screen_014), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            when {
                list == null -> LoadingBox(height = 140.dp)
                list!!.isEmpty() -> EmptyState("💔", "هنوز کسی لایک نکرده")
                else -> LazyColumn(Modifier.height(380.dp)) {
                    items(list!!, key = { it.username }) { u ->
                        Row(Modifier.fillMaxWidth().clickable { onOpenUser(u.username) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(u.username, u.mood, size = 40.dp, avatarUrl = u.avatar)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(u.username, style = MaterialTheme.typography.titleSmall)
                                if (u.followsMe) Text(stringResource(R.string.feed_screen_009), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** ویرایش پست خود کاربر. */
@Composable
fun EditPostSheet(p: Post, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(ir.studying.app.core.AutoPost.strip(p.text)) }
    var saving by remember { mutableStateOf(false) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp).imePadding()) {
            Text(stringResource(R.string.feed_screen_015), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            TextField(value = text, onValueChange = { if (it.length <= 500) text = it },
                modifier = Modifier.fillMaxWidth().height(130.dp), shape = RoundedCornerShape(16.dp),
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent))
            Spacer(Modifier.height(10.dp))
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, onClick = {
                if (text.isBlank() || saving) return@Surface
                saving = true
                scope.launch {
                    runCatching { Api.post("post_edit", JSONObject().put("id", p.id).put("text", text.trim())) }
                        .onSuccess { AppSnack.show("ویرایش شد ✅"); onSaved() }
                        .onFailure { saving = false; AppSnack.show(it.message ?: "خطا") }
                }
            }, modifier = Modifier.align(Alignment.End)) {
                Text(if (saving) "در حال ذخیره…" else "ذخیره", color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp))
            }
        }
    }
}


/** پریست‌های هدر پروفایل — قابل انتخاب توسط کاربر. */
val BannerPresets = listOf(
    "brand" to listOf(Color(0xFF059669), Color(0xFF0EA5E9)),
    "night" to listOf(Color(0xFF312E81), Color(0xFF7C3AED)),
    "sunset" to listOf(Color(0xFFB45309), Color(0xFFE11D48)),
    "ocean" to listOf(Color(0xFF075985), Color(0xFF06B6D4)),
    "rose" to listOf(Color(0xFFBE185D), Color(0xFFF472B6)),
    "gold" to listOf(Color(0xFF92400E), Color(0xFFFBBF24)),
    "forest" to listOf(Color(0xFF14532D), Color(0xFF4ADE80)),
    "mono" to listOf(Color(0xFF1F2937), Color(0xFF6B7280)),
)
fun bannerBrush(id: String): androidx.compose.ui.graphics.Brush {
    val c = BannerPresets.firstOrNull { it.first == id }?.second ?: BannerPresets.first().second
    return androidx.compose.ui.graphics.Brush.linearGradient(c)
}

/** زمان مطالعه به‌صورت عددی خلاصه: «۳:۴۵». */
fun minutesNum(total: Int): String {
    val h = total / 60; val m = total % 60
    return if (h > 0) "${h.fa()}:${m.toString().padStart(2, '0').fa()}" else "${m.fa()} د"
}

/** انتخاب هدر پروفایل. */
@Composable
fun BannerPickerSheet(current: String, onPicked: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 26.dp)) {
            Text(stringResource(R.string.feed_screen_016), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            BannerPresets.chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth()) {
                    rowItems.forEach { (id, colors) ->
                        Box(Modifier.weight(1f).padding(5.dp).height(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(androidx.compose.ui.graphics.Brush.linearGradient(colors))
                            .clickable {
                                scope.launch {
                                    runCatching { Api.post("profile_banner", JSONObject().put("banner", id)) }
                                        .onSuccess { onPicked(id) }
                                        .onFailure { AppSnack.show(it.message ?: "خطا") }
                                }
                            }, contentAlignment = Alignment.Center) {
                            if (current == id) Text("✓", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
            }
        }
    }
}

/** پروفایل اجتماعی به‌صورت دیالوگ تمام‌صفحه — از هر جای اپ (چت، کانال، گروه) باز می‌شود. */
@Composable
fun SocialProfileDialog(username: String, onDismiss: () -> Unit) {
    var postId by remember { mutableStateOf<Int?>(null) }
    var user by remember { mutableStateOf(username) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val pid = postId
            if (pid != null) {
                PostDetailScreen(pid, onBack = { postId = null }, onOpenUser = { user = it; postId = null })
            } else {
                SocialProfileScreen(user, onBack = onDismiss, onOpenPost = { postId = it }, onOpenUser = { user = it })
            }
        }
    }
}


/** منوی شیشه‌ای مشترک پست — در فید، پروفایل و جزئیات پست استفاده می‌شود. */
@Composable
fun PostGlassMenu(p: Post, me: String, onDismiss: () -> Unit,
                  onOpenUser: (String) -> Unit, onEdit: (Post) -> Unit, onQuote: (Post) -> Unit,
                  onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    GlassMenu(onDismiss = onDismiss) {
        if (p.username == me) {
            GlassAction(Icons.Rounded.Edit, "ویرایش پست") { onEdit(p) }
            GlassAction(Icons.Rounded.Delete, "حذف پست", danger = true) {
                scope.launch {
                    runCatching { Api.delete("post_delete", "id" to p.id.toString()) }
                        .onSuccess { AppSnack.show("حذف شد"); onDeleted() }
                        .onFailure { AppSnack.show(it.message ?: "خطا") }
                }
            }
        } else {
            GlassAction(Icons.Rounded.Person, "دیدن پروفایل ${p.username}") { onOpenUser(p.username) }
            GlassAction(Icons.AutoMirrored.Rounded.Send, "پیام خصوصی") { NavBus.requestDm(p.username) }
        }
        GlassDivider()
        GlassAction(Icons.Rounded.FormatQuote, "نقل‌قول با متن") { onQuote(p) }
        if (!p.text.isNullOrBlank()) GlassAction(Icons.Rounded.ContentCopy, "کپی متن") {
            clip.setText(androidx.compose.ui.text.AnnotatedString(ir.studying.app.core.AutoPost.strip(p.text)))
            AppSnack.show("کپی شد")
        }
    }
}


/**
 * Milestone posts — end-of-day totals, reaching the daily goal and round
 * streaks — are deliberately not styled like ordinary posts. They are
 * generated by the app rather than written by a person, so they get a tinted,
 * outlined card with their own icon and colour instead of plain body text.
 */
@Composable
private fun AchievementCard(b: ir.studying.app.core.AutoPost.Badge) {
    val cs = MaterialTheme.colorScheme
    val daily = b.kind == ir.studying.app.core.AutoPost.DAILY
    val accent = when (b.kind) {
        ir.studying.app.core.AutoPost.GOAL -> cs.primary
        ir.studying.app.core.AutoPost.STREAK -> Color(0xFFFB923C)
        else -> Color(0xFF38BDF8)
    }
    val icon = when (b.kind) {
        ir.studying.app.core.AutoPost.GOAL -> Icons.Rounded.Verified
        ir.studying.app.core.AutoPost.STREAK -> Icons.Rounded.LocalFireDepartment
        else -> Icons.Rounded.AutoAwesome
    }
    val label = when (b.kind) {
        ir.studying.app.core.AutoPost.GOAL -> "هدف روزانه محقق شد"
        ir.studying.app.core.AutoPost.STREAK -> "استریک تازه"
        else -> "گزارش پایان روز"
    }

    Spacer(Modifier.height(7.dp))
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = accent.copy(alpha = 0.10f),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, accent.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(30.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp)) }
                Spacer(Modifier.width(8.dp))
                Text(label, style = MaterialTheme.typography.labelMedium, color = accent)
                Spacer(Modifier.weight(1f))
                if (b.streak > 0) Text(b.streak.fa(), style = MaterialTheme.typography.titleMedium, color = accent)
            }
            if (daily && b.minutes > 0) {
                Spacer(Modifier.height(10.dp))
                Text(Fmt.minutes(b.minutes), style = MaterialTheme.typography.headlineSmall, color = accent)
            }
            if (b.body.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(b.body, style = MaterialTheme.typography.bodyMedium, lineHeight = 21.sp)
            }

            if (daily && b.questionTotals != null) {
                Spacer(Modifier.height(12.dp))
                ir.studying.app.ui.components.DailyQuestionStats(b.questionTotals)
            }

            if (daily && b.courses.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                val peak = b.courses.maxOf { it.second }.coerceAtLeast(1)
                b.courses.forEach { (name, mins) ->
                    CourseBar(name, mins, mins.toFloat() / peak, accent)
                }
            }
        }
    }
}

/** One row of the end-of-day per-course breakdown. */
@Composable
private fun CourseBar(name: String, minutes: Int, fraction: Float, accent: Color) {
    Column(Modifier.padding(bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(name, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 1)
            Spacer(Modifier.width(8.dp))
            Text(Fmt.minutes(minutes), style = MaterialTheme.typography.labelSmall, color = accent)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                .background(accent.copy(alpha = 0.15f))
        ) {
            Box(
                Modifier.fillMaxWidth(fraction.coerceIn(0.04f, 1f)).fillMaxHeight()
                    .clip(RoundedCornerShape(3.dp)).background(accent)
            )
        }
    }
}
