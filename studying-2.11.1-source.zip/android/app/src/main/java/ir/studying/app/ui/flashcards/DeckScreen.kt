@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.flashcards

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import ir.studying.app.core.Api
import ir.studying.app.core.EmojiText
import ir.studying.app.core.FlashcardLogic
import ir.studying.app.core.Flashcards
import ir.studying.app.core.Icon3D
import ir.studying.app.core.VoiceRecorder
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.GlassAction
import ir.studying.app.ui.components.GlassDivider
import ir.studying.app.ui.components.GlassMenu
import ir.studying.app.ui.components.GlowSearchField
import ir.studying.app.ui.messages.ChatEmpty
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class CardFilter(val label: String, val emoji: String, val bucket: FlashcardLogic.Bucket?) {
    ALL("همه", "🗂️", null),
    NEW("تازه", "✨", FlashcardLogic.Bucket.NEW),
    LEARNING("در حال یادگیری", "🧠", FlashcardLogic.Bucket.LEARNING),
    REVIEW("در حال مرور", "🔁", FlashcardLogic.Bucket.REVIEW),
    MASTERED("تثبیت‌شده", "🏆", FlashcardLogic.Bucket.MASTERED),
}

@Composable
fun DeckScreen(deckId: Int, onBack: () -> Unit, onReview: (Int) -> Unit) {
    val scope = rememberCoroutineScope()
    val decks by Flashcards.decks.collectAsState()
    val deck = decks.firstOrNull { it.id == deckId }
    var cards by remember { mutableStateOf<List<Flashcards.Card>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf<Flashcards.Card?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showPaste by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var editDeck by remember { mutableStateOf(false) }
    var deleteDeck by remember { mutableStateOf(false) }
    var shareCode by remember { mutableStateOf(deck?.shareCode ?: "") }
    var sharing by remember { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf(CardFilter.ALL) }
    var query by rememberSaveable { mutableStateOf("") }
    var hidden by remember { mutableStateOf(setOf<Int>()) }
    val listState = rememberLazyListState()
    val fabExpanded by remember { derivedStateOf { listState.firstVisibleItemIndex < 2 } }
    val colorKey = deck?.color ?: "mint"
    val colors = deckColors(colorKey)

    suspend fun reload() {
        runCatching { Flashcards.cards(deckId) }
            .onSuccess { cards = it }
            .onFailure { AppSnack.show(it.message ?: "دریافت کارت‌ها ناموفق بود") }
        loading = false
    }

    LaunchedEffect(deckId) {
        reload()
        runCatching { Flashcards.loadDecks() }
    }

    fun share() {
        if (shareCode.isNotBlank()) { sharing = true; return }
        scope.launch {
            runCatching { Flashcards.share(deckId) }
                .onSuccess { shareCode = it; sharing = true }
                .onFailure { AppSnack.show(it.message ?: "ساخت کد ناموفق بود") }
        }
    }

    fun delete(c: Flashcards.Card) {
        hidden = hidden + c.id
        AppSnack.undoable(
            "کارت حذف شد",
            onUndo = { hidden = hidden - c.id },
            onCommit = {
                Flashcards.deleteCardInBackground(c.id) { err ->
                    if (err == null) cards = cards.filterNot { it.id == c.id }
                    else AppSnack.show(err.message ?: "حذف ناموفق بود")
                    hidden = hidden - c.id
                }
            },
        )
    }

    val visible = cards.filter { it.id !in hidden }
    val counts = remember(visible) { visible.groupingBy { it.bucket() }.eachCount() }
    val shown = visible
        .filter { c -> filter.bucket == null || c.bucket() == filter.bucket }
        .filter { c -> query.isBlank() || c.front.contains(query, true) || c.back.contains(query, true) || c.extra.contains(query, true) }

    Box(Modifier.fillMaxSize()) {
        FcBackdrop(colors, Modifier.fillMaxWidth().height(380.dp), strength = 0.55f)
        Column(Modifier.fillMaxSize()) {
            FcTopBar(deck?.name ?: "دسته", if (loading) null else "${visible.size.fa()} کارت", onBack) {
                FcRoundButton(Icons.Rounded.Share, "اشتراک", { share() })
                FcRoundButton(Icons.Rounded.MoreVert, "بیشتر", { showMenu = true })
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item(key = "hero") {
                    FadeSlideIn(0) {
                        DeckHero(
                            name = deck?.name ?: "دسته",
                            description = deck?.description ?: "",
                            icon = deck?.icon ?: "",
                            colorKey = colorKey,
                            progress = deck?.progress ?: 0f,
                            due = deck?.due ?: 0,
                            fresh = deck?.fresh ?: (counts[FlashcardLogic.Bucket.NEW] ?: 0),
                            learning = counts[FlashcardLogic.Bucket.LEARNING] ?: 0,
                            mastered = deck?.mastered ?: (counts[FlashcardLogic.Bucket.MASTERED] ?: 0),
                            onReview = { onReview(deckId) },
                        )
                    }
                }
                if (visible.isNotEmpty()) item(key = "filters") {
                    FilterRow(filter, counts, visible.size, colors) { filter = it }
                }
                if (visible.size > 6) item(key = "search") {
                    GlowSearchField(value = query, onValueChange = { query = it }, placeholder = "جستجو در کارت‌ها", modifier = Modifier.fillMaxWidth())
                }
                when {
                    loading -> items(4, key = { "sk$it" }) { CardTileSkeleton() }
                    visible.isEmpty() -> item(key = "empty") {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            ChatEmpty(
                                "🗂️", "این دسته هنوز خالیه",
                                "اولین کارت رو بساز، یا یه فهرست «سوال، جواب» رو یک‌جا وارد کن",
                                actionLabel = "➕ ساخت کارت", onAction = { editing = null; showEditor = true },
                            )
                            TextButton(onClick = { showPaste = true }) {
                                Icon(Icons.Rounded.UploadFile, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("ورود گروهی از متن یا CSV")
                            }
                        }
                    }
                    shown.isEmpty() -> item(key = "nores") {
                        Box(Modifier.fillMaxWidth().padding(top = 30.dp), contentAlignment = Alignment.Center) {
                            EmojiText("🔍 کارتی با این فیلتر پیدا نشد", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    else -> itemsIndexed(shown, key = { _, c -> c.id }) { i, c ->
                        Box(Modifier.animateItemPlacement()) {
                            FadeSlideIn(i + 1) {
                                CardTile(
                                    card = c,
                                    colors = colors,
                                    onEdit = { editing = c; showEditor = true },
                                    onDelete = { delete(c) },
                                )
                            }
                        }
                    }
                }
            }
        }

        NewCardFab(fabExpanded, colors, Modifier.align(Alignment.BottomEnd).padding(18.dp)) { editing = null; showEditor = true }
    }

    if (showMenu) {
        GlassMenu(onDismiss = { showMenu = false }) {
            GlassAction(Icons.Rounded.Add, "کارت جدید") { editing = null; showEditor = true }
            GlassAction(Icons.Rounded.UploadFile, "ورود گروهی از متن") { showPaste = true }
            GlassAction(Icons.Rounded.Share, "اشتراک با کد") { share() }
            GlassDivider()
            GlassAction(Icons.Rounded.Edit, "ویرایش دسته") { editDeck = true }
            GlassAction(Icons.Rounded.Delete, "حذف دسته", danger = true) { deleteDeck = true }
        }
    }

    if (showEditor) {
        CardEditorSheet(
            deckId = deckId,
            deckName = deck?.name ?: "",
            colors = colors,
            initial = editing,
            onDismiss = { showEditor = false },
            onSaved = { saved, keepOpen ->
                if (!keepOpen) showEditor = false
                cards = if (cards.any { it.id == saved.id }) cards.map { if (it.id == saved.id) saved else it } else cards + saved
                scope.launch { runCatching { Flashcards.loadDecks() } }
            },
        )
    }

    if (showPaste) {
        PasteImportSheet(
            deckId = deckId,
            colors = colors,
            onDismiss = { showPaste = false },
            onDone = { ok ->
                showPaste = false
                scope.launch { reload(); runCatching { Flashcards.loadDecks() } }
                AppSnack.show("${ok.fa()} کارت اضافه شد ✅")
            },
        )
    }

    if (sharing && deck != null && shareCode.isNotBlank()) {
        ShareCodeSheet(deck, shareCode, onDismiss = { sharing = false })
    }

    if (editDeck && deck != null) {
        DeckEditorDialog(
            initialName = deck.name, initialIcon = deck.icon, initialColor = deck.color, initialDescription = deck.description,
            onDismiss = { editDeck = false },
            onSave = { name, icon, color, desc ->
                editDeck = false
                scope.launch {
                    runCatching { Flashcards.saveDeck(id = deck.id, name = name, icon = icon, color = color, description = desc) }
                        .onSuccess { AppSnack.show("دسته به‌روز شد ✅") }
                        .onFailure { AppSnack.show(it.message ?: "ذخیره ناموفق بود") }
                }
            },
        )
    }

    if (deleteDeck && deck != null) {
        FcConfirmDialog(
            emoji = "🗑️",
            title = "حذف دسته",
            text = "«${deck.name}» با همهٔ کارت‌ها و سابقهٔ مرورش برای همیشه حذف می‌شود.",
            confirmLabel = "حذف",
            onConfirm = {
                scope.launch {
                    runCatching { Flashcards.deleteDeck(deck.id) }
                        .onSuccess { AppSnack.show("دسته حذف شد"); onBack() }
                        .onFailure { AppSnack.show(it.message ?: "حذف ناموفق بود") }
                }
            },
            onDismiss = { deleteDeck = false },
        )
    }
}

/* ================================================================ hero == */

@Composable
internal fun DeckHero(
    name: String,
    description: String,
    icon: String,
    colorKey: String,
    progress: Float,
    due: Int,
    fresh: Int,
    learning: Int,
    mastered: Int,
    onReview: () -> Unit,
) {
    val colors = deckColors(colorKey)
    val t = rememberInfiniteTransition(label = "deckHero")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse), label = "deckDrift")
    Box(
        Modifier.fillMaxWidth()
            .graphicsLayer { shadowElevation = 10.dp.toPx(); shape = RoundedCornerShape(30.dp); clip = true }
            .background(Brush.linearGradient(colors)),
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.12f), radius = size.minDimension * 0.7f,
                center = Offset(size.width * (0.02f + 0.08f * drift), 0f))
            drawCircle(Color.White.copy(alpha = 0.08f), radius = size.minDimension * 0.45f,
                center = Offset(size.width * (0.98f - 0.06f * drift), size.height))
        }
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(76.dp).clip(RoundedCornerShape(25.dp)).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                    AnimatedEmoji(deckIconOf(icon), 54.dp, idle = true, autoPlay = true)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black,
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (description.isNotBlank()) {
                        EmojiText(description, color = Color.White.copy(alpha = 0.86f), style = MaterialTheme.typography.bodySmall,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                Spacer(Modifier.width(8.dp))
                ProgressRing(progress, 66.dp, 7.dp, listOf(Color.White, Color.White.copy(alpha = 0.75f)), track = Color.White.copy(alpha = 0.22f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${(progress * 100).toInt().fa()}٪", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall)
                        Text("تثبیت", color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeroStat("🔥", due, "آماده", Modifier.weight(1f))
                HeroStat("✨", fresh, "تازه", Modifier.weight(1f))
                HeroStat("🧠", learning, "یادگیری", Modifier.weight(1f))
                HeroStat("🏆", mastered, "تثبیت", Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            val inter = remember { MutableInteractionSource() }
            val s = pressScale(inter, 0.96f)
            Surface(
                onClick = onReview, interactionSource = inter, shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 6.dp,
                modifier = Modifier.fillMaxWidth().height(54.dp).graphicsLayer { scaleX = s; scaleY = s },
            ) {
                Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon3D(if (due > 0) "▶️" else "🎯", 24.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (due > 0) "شروع مرور ${due.fa()} کارت" else "مرور آزاد این دسته", color = colors.last(),
                        fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall)
                }
            }
        }
    }
}

@Composable
private fun HeroStat(emoji: String, value: Int, label: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.17f)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon3D(emoji, 22.dp)
        Spacer(Modifier.height(2.dp))
        ir.studying.app.ui.components.CountUpText(value, MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black), Color.White)
        Text(label, color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

/* ============================================================= filters == */

@Composable
private fun FilterRow(selected: CardFilter, counts: Map<FlashcardLogic.Bucket, Int>, total: Int, colors: List<Color>, onPick: (CardFilter) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        CardFilter.values().forEach { f ->
            val n = if (f.bucket == null) total else counts[f.bucket] ?: 0
            if (f.bucket != null && n == 0) return@forEach
            val on = f == selected
            val bg by animateColorAsState(if (on) colors.last() else cs.surface, tween(220), label = "fBg")
            val fg by animateColorAsState(if (on) Color.White else cs.onSurface, tween(220), label = "fFg")
            Surface(
                onClick = { onPick(f) }, shape = CircleShape, color = bg,
                border = if (on) null else BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
                shadowElevation = if (on) 3.dp else 0.dp,
            ) {
                Row(Modifier.padding(start = 8.dp, end = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon3D(f.emoji, 18.dp)
                    Spacer(Modifier.width(5.dp))
                    Text(f.label, color = fg, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(5.dp))
                    Text(n.fa(), color = fg.copy(alpha = 0.7f), style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

/* ============================================================ card tile == */

internal fun clozeAnnotated(text: String, reveal: Boolean, accent: Color, blankBg: Color) = buildAnnotatedString {
    FlashcardLogic.clozeParts(text).forEach { (part, hiddenPart) ->
        if (!hiddenPart) append(part)
        else if (reveal) withStyle(SpanStyle(color = accent, fontWeight = FontWeight.Black, background = accent.copy(alpha = 0.14f))) { append(" $part ") }
        else withStyle(SpanStyle(color = Color.Transparent, background = blankBg)) { append("\u00A0" + "\u2007".repeat(part.length.coerceIn(3, 12)) + "\u00A0") }
    }
}

@Composable
internal fun CardTile(card: Flashcards.Card, colors: List<Color>, onEdit: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    val flip by animateFloatAsState(if (open) 180f else 0f, spring(dampingRatio = 0.78f, stiffness = 260f), label = "tileFlip")
    val meta = typeMeta(card.type)
    val b = bucketMeta(card.bucket())
    Surface(
        shape = RoundedCornerShape(22.dp), color = cs.surface, shadowElevation = 1.dp,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(Brush.verticalGradient(listOf(b.color, b.color.copy(alpha = 0.4f)))))
            Column(Modifier.weight(1f).padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 12.dp).animateContentSize()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MiniChip(meta.emoji, meta.label, colors.last())
                    Spacer(Modifier.width(6.dp))
                    MiniChip(b.emoji, b.label, b.color)
                    Spacer(Modifier.weight(1f))
                    if (card.intervalDays > 0) {
                        Text("هر ${card.intervalDays.fa()} روز", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.Edit, "ویرایش", Modifier.size(18.dp), tint = cs.onSurfaceVariant) }
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.DeleteOutline, "حذف", Modifier.size(19.dp), tint = cs.error) }
                }
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier.fillMaxWidth()
                        .graphicsLayer { rotationX = flip; cameraDistance = 18f * density }
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (flip > 90f) colors.first().copy(alpha = 0.12f) else cs.surfaceVariant.copy(alpha = 0.45f))
                        .clickable { open = !open }
                        .padding(12.dp),
                ) {
                    if (flip <= 90f) TileFront(card, colors)
                    else Box(Modifier.graphicsLayer { rotationX = 180f }) { TileBack(card, colors) }
                }
                Spacer(Modifier.height(4.dp))
                Text(if (open) "برای دیدن روی کارت بزن" else "برای دیدن پشت کارت بزن", style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant.copy(alpha = 0.7f), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun MiniChip(emoji: String, label: String, tint: Color) {
    Row(Modifier.clip(CircleShape).background(tint.copy(alpha = 0.12f)).padding(start = 4.dp, end = 8.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon3D(emoji, 14.dp)
        Spacer(Modifier.width(3.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun TileFront(card: Flashcards.Card, colors: List<Color>) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (card.image.isNotBlank()) {
            AsyncImage(model = Api.mediaUrl(card.image), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            when (card.type) {
                "cloze" -> Text(clozeAnnotated(card.front, false, colors.last(), colors.first().copy(alpha = 0.35f)),
                    style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                else -> EmojiText(card.front.ifBlank { if (card.image.isNotBlank()) "کارت تصویری" else "(بدون متن)" },
                    style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            if (card.type == "mcq") Text("${card.choices.size.fa()} گزینه", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
        if (card.audio.isNotBlank()) { Spacer(Modifier.width(6.dp)); Icon3D("🎧", 22.dp) }
    }
}

@Composable
private fun TileBack(card: Flashcards.Card, colors: List<Color>) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth()) {
        when (card.type) {
            "cloze" -> Text(clozeAnnotated(card.front, true, colors.last(), Color.Transparent), style = MaterialTheme.typography.bodyLarge)
            "mcq" -> {
                val right = card.choices.firstOrNull { it.second }?.first
                EmojiText("✅ " + (right ?: "پاسخ درست مشخص نشده"), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
            }
            else -> EmojiText(card.back.ifBlank { "(پشت کارت خالی است)" }, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
        }
        val note = if (card.type == "mcq" || card.type == "cloze") card.back else card.extra
        if (note.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            EmojiText(note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (card.image.isNotBlank() && card.type != "image") {
            Spacer(Modifier.height(8.dp))
            AsyncImage(model = Api.mediaUrl(card.image), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(14.dp)))
        }
    }
}

@Composable
private fun CardTileSkeleton() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "ctsk")
    val a by t.animateFloat(0.35f, 0.85f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "ctskA")
    Surface(shape = RoundedCornerShape(22.dp), color = cs.surface, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.4f))) {
        Column(Modifier.fillMaxWidth().padding(14.dp).graphicsLayer { alpha = a }, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.width(64.dp).height(16.dp).clip(CircleShape).background(cs.surfaceVariant))
                Box(Modifier.width(80.dp).height(16.dp).clip(CircleShape).background(cs.surfaceVariant))
            }
            Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant))
        }
    }
}

@Composable
private fun NewCardFab(expanded: Boolean, colors: List<Color>, modifier: Modifier, onClick: () -> Unit) {
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter, 0.92f)
    Surface(
        onClick = onClick, interactionSource = inter, shape = CircleShape, color = Color.Transparent, shadowElevation = 8.dp,
        modifier = modifier.graphicsLayer { scaleX = s; scaleY = s },
    ) {
        Row(Modifier.background(Brush.linearGradient(colors)).height(56.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(24.dp))
            androidx.compose.animation.AnimatedVisibility(expanded, enter = fadeIn() + expandHorizontally(), exit = fadeOut() + shrinkHorizontally()) {
                Text("کارت جدید", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

/* ========================================================= card editor == */

@Composable
private fun CardEditorSheet(
    deckId: Int,
    deckName: String,
    colors: List<Color>,
    initial: Flashcards.Card?,
    onDismiss: () -> Unit,
    onSaved: (Flashcards.Card, Boolean) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var type by remember { mutableStateOf(initial?.type ?: "basic") }
    var front by remember { mutableStateOf(TextFieldValue(initial?.front ?: "")) }
    var back by remember { mutableStateOf(initial?.back ?: "") }
    var notes by remember { mutableStateOf(if (initial?.type == "mcq") "" else initial?.extra ?: "") }
    val options = remember {
        mutableStateListOf<Pair<String, Boolean>>().apply {
            if (initial?.type == "mcq") addAll(FlashcardLogic.mcqOptions(initial.extra))
            while (size < 4) add("" to false)
        }
    }
    var image by remember { mutableStateOf(initial?.image ?: "") }
    var audio by remember { mutableStateOf(initial?.audio ?: "") }
    var busy by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var elapsed by remember { mutableIntStateOf(0) }
    var savedCount by remember { mutableIntStateOf(0) }
    var previewBack by remember { mutableStateOf(false) }
    val recorder = remember { VoiceRecorder(ctx) }

    DisposableEffect(Unit) { onDispose { if (recording) runCatching { recorder.cancel() } } }
    LaunchedEffect(recording) { elapsed = 0; while (recording) { delay(1000); elapsed++ } }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                runCatching {
                    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                    val mime = ctx.contentResolver.getType(uri) ?: "image/jpeg"
                    Flashcards.uploadImage(bytes, "card.jpg", mime)
                }.onSuccess { image = it }
                    .onFailure { AppSnack.show(it.message ?: "آپلود تصویر ناموفق بود") }
                busy = false
            }
        }
    }

    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && recorder.start()) recording = true
        else if (!granted) AppSnack.show("برای ضبط صدا به اجازهٔ میکروفون نیاز دارم")
    }

    fun toggleRecord() {
        if (recording) {
            val res = recorder.stop()
            recording = false
            if (res != null) {
                scope.launch {
                    busy = true
                    runCatching { Flashcards.uploadAudio(res.first) }
                        .onSuccess { audio = it; AppSnack.show("یادداشت صوتی ذخیره شد 🎧") }
                        .onFailure { AppSnack.show(it.message ?: "آپلود صدا ناموفق بود") }
                    busy = false
                }
            }
        } else {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) { if (recorder.start()) recording = true else AppSnack.show("ضبط شروع نشد") }
            else askMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val clozeBlanks = FlashcardLogic.clozeCount(front.text)
    val problem: String? = when {
        front.text.isBlank() && image.isBlank() && audio.isBlank() -> "روی کارت چیزی بنویس یا تصویر و صدا بگذار"
        type == "mcq" && !FlashcardLogic.mcqValid(options) -> "حداقل دو گزینه بنویس و پاسخ درست رو علامت بزن"
        type == "cloze" && clozeBlanks == 0 -> "حداقل یک بخش از متن رو جای خالی کن"
        else -> null
    }

    fun buildCard() = Flashcards.Card(
        id = initial?.id ?: 0,
        deckId = deckId,
        type = type,
        front = front.text.trim(),
        back = back.trim(),
        extra = if (type == "mcq") FlashcardLogic.mcqExtra(options) else if (type == "cloze") "" else notes.trim(),
        image = image,
        audio = audio,
        position = initial?.position ?: 0,
    )

    fun save(keepOpen: Boolean) {
        scope.launch {
            busy = true
            runCatching { Flashcards.saveCard(buildCard()) }
                .onSuccess { saved ->
                    if (saved == null) { AppSnack.show("ذخیره نشد"); return@onSuccess }
                    onSaved(saved, keepOpen)
                    if (keepOpen) {
                        savedCount++
                        front = TextFieldValue("")
                        back = ""
                        notes = ""
                        image = ""
                        audio = ""
                        previewBack = false
                        for (i in options.indices) options[i] = "" to false
                    }
                }
                .onFailure { AppSnack.show(it.message ?: "ذخیره ناموفق بود") }
            busy = false
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            FcSheetHeader(
                typeMeta(type).emoji,
                if (initial == null) "کارت جدید" else "ویرایش کارت",
                if (savedCount > 0) "✅ ${savedCount.fa()} کارت اضافه شد • $deckName" else deckName.ifBlank { null },
                playKey = type,
            )

            // type picker
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cardTypeMeta.forEach { m ->
                    val on = m.key == type
                    val sc by animateFloatAsState(if (on) 1f else 0.94f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "typeSc")
                    Column(
                        Modifier.width(92.dp).graphicsLayer { scaleX = sc; scaleY = sc }
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (on) colors.first().copy(alpha = 0.16f) else cs.surfaceVariant.copy(alpha = 0.5f))
                            .border(if (on) 2.dp else 1.dp, if (on) colors.last() else cs.outlineVariant.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                            .clickable { type = m.key }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon3D(m.emoji, 30.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(m.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1,
                            color = if (on) colors.last() else cs.onSurface)
                    }
                }
            }
            Text(typeMeta(type).hint, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)

            // live preview
            EditorPreview(
                card = buildCard(),
                colors = colors,
                showBack = previewBack,
                onFlip = { previewBack = !previewBack },
            )

            OutlinedTextField(
                value = front,
                onValueChange = { front = it },
                label = { Text(when (type) { "cloze" -> "متن کارت"; "mcq" -> "صورت سوال"; else -> "روی کارت (سوال)" }) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
            )

            if (type == "cloze") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(
                        onClick = {
                            val (t, cursor) = FlashcardLogic.wrapCloze(front.text, front.selection.start, front.selection.end)
                            front = TextFieldValue(t, TextRange(cursor.coerceIn(0, t.length)))
                        },
                        label = { Text("جای خالی کن") },
                        leadingIcon = { Icon3D("🧩", 18.dp) },
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (clozeBlanks > 0) "${clozeBlanks.fa()} جای خالی" else "کلمه رو انتخاب کن و بزن؛ یا داخل {{ }} بنویس",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    )
                }
            }

            if (type == "mcq") {
                Text("گزینه‌ها — پاسخ درست رو علامت بزن", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
                options.forEachIndexed { i, (text, ok) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = ok, onClick = { for (j in options.indices) options[j] = options[j].first to (j == i) })
                        OutlinedTextField(
                            value = text,
                            onValueChange = { v -> options[i] = v.replace('\n', ' ') to ok },
                            placeholder = { Text("گزینهٔ ${(i + 1).fa()}") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f),
                        )
                        if (options.size > 2) {
                            IconButton(onClick = { options.removeAt(i) }) { Icon(Icons.Rounded.Close, "حذف گزینه", tint = cs.onSurfaceVariant) }
                        }
                    }
                }
                if (options.size < 6) {
                    TextButton(onClick = { options.add("" to false) }) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("افزودن گزینه")
                    }
                }
            }

            if (type != "cloze") {
                OutlinedTextField(
                    value = back,
                    onValueChange = { back = it },
                    label = { Text(if (type == "mcq") "توضیح پاسخ (اختیاری)" else "پشت کارت (پاسخ)") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = if (type == "mcq") 1 else 2,
                )
            } else {
                OutlinedTextField(
                    value = back,
                    onValueChange = { back = it },
                    label = { Text("یادداشت پشت کارت (اختیاری)") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (type != "mcq" && type != "cloze") {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("توضیح تکمیلی (اختیاری)") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // media
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MediaTile(
                    emoji = "🖼️",
                    title = if (image.isBlank()) "افزودن تصویر" else "تغییر تصویر",
                    accent = colors.last(),
                    enabled = !busy,
                    modifier = Modifier.weight(1f),
                    onClick = { pickImage.launch("image/*") },
                    onRemove = if (image.isNotBlank()) ({ image = "" }) else null,
                ) {
                    if (image.isNotBlank()) AsyncImage(model = Api.mediaUrl(image), contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize())
                }
                MediaTile(
                    emoji = if (recording) "🔴" else "🎙️",
                    title = when {
                        recording -> "پایان ضبط • ${String.format(java.util.Locale.US, "%d:%02d", elapsed / 60, elapsed % 60).fa()}"
                        audio.isBlank() -> "یادداشت صوتی"
                        else -> "ضبط دوباره"
                    },
                    accent = if (recording) Color(0xFFE11D48) else colors.last(),
                    enabled = !busy || recording,
                    modifier = Modifier.weight(1f),
                    onClick = { toggleRecord() },
                    onRemove = if (audio.isNotBlank() && !recording) ({ audio = "" }) else null,
                ) {
                    if (recording) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ir.studying.app.ui.components.FlameLoader(size = 30.dp) }
                    else if (audio.isNotBlank()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { AnimatedEmoji("🎧", 34.dp, idle = true, burst = false) }
                }
            }

            AnimatedVisibility(busy, enter = fadeIn(), exit = fadeOut()) { LinearProgressIndicator(Modifier.fillMaxWidth().clip(CircleShape)) }
            AnimatedVisibility(problem != null && (front.text.isNotBlank() || type != "basic"), enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Text(problem ?: "", style = MaterialTheme.typography.labelMedium, color = Color(0xFFD97706))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (initial == null) {
                    OutlinedButton(
                        onClick = { save(keepOpen = true) },
                        enabled = !busy && problem == null,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.weight(1f).height(54.dp),
                    ) { Text("ذخیره و بعدی", fontWeight = FontWeight.Bold) }
                }
                FcPrimaryButton(
                    text = "ذخیرهٔ کارت",
                    emoji = "💾",
                    colors = colors,
                    enabled = problem == null,
                    busy = busy,
                    modifier = Modifier.weight(1.2f),
                ) { save(keepOpen = false) }
            }
        }
    }
}

@Composable
private fun MediaTile(
    emoji: String,
    title: String,
    accent: Color,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onRemove: (() -> Unit)?,
    content: @Composable BoxScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(accent.copy(alpha = 0.08f))
            .border(1.dp, accent.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().height(74.dp).clip(RoundedCornerShape(13.dp)).background(cs.surface.copy(alpha = 0.6f)), contentAlignment = Alignment.Center) {
            Icon3D(emoji, 32.dp)
            content()
            if (onRemove != null) {
                Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(24.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f))
                    .clickable(onClick = onRemove), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Close, "حذف", tint = Color.White, modifier = Modifier.size(15.dp))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = accent, maxLines = 1)
    }
}

/** Mini card in the editor: shows how the card will look and flips on tap. */
@Composable
private fun EditorPreview(card: Flashcards.Card, colors: List<Color>, showBack: Boolean, onFlip: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val rot by animateFloatAsState(if (showBack) 180f else 0f, spring(dampingRatio = 0.75f, stiffness = 240f), label = "prevFlip")
    Box(
        Modifier.fillMaxWidth().heightIn(min = 104.dp)
            .graphicsLayer { rotationY = rot; cameraDistance = 16f * density }
            .clip(RoundedCornerShape(22.dp))
            .background(if (rot > 90f) Brush.linearGradient(colors) else Brush.linearGradient(listOf(cs.surfaceVariant.copy(alpha = 0.7f), cs.surfaceVariant.copy(alpha = 0.35f))))
            .clickable(onClick = onFlip)
            .padding(16.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (rot <= 90f) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("پیش‌نمایش • روی کارت", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                if (card.type == "cloze") Text(clozeAnnotated(card.front.ifBlank { "متن کارت" }, false, colors.last(), colors.first().copy(alpha = 0.4f)),
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                else EmojiText(card.front.ifBlank { "سوالت اینجا دیده می‌شه" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    color = if (card.front.isBlank()) cs.onSurfaceVariant.copy(alpha = 0.6f) else cs.onSurface)
                if (card.type == "mcq") {
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        card.choices.take(4).forEach { (t, _) ->
                            Text(t, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 80.dp).clip(CircleShape).background(cs.surface).padding(horizontal = 8.dp, vertical = 3.dp))
                        }
                    }
                }
            }
        } else {
            Column(Modifier.graphicsLayer { rotationY = 180f }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("پشت کارت", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.height(6.dp))
                val answer = when (card.type) {
                    "cloze" -> FlashcardLogic.clozeParts(card.front).joinToString("") { it.first }
                    "mcq" -> card.choices.firstOrNull { it.second }?.first ?: "پاسخ درست رو علامت بزن"
                    else -> card.back.ifBlank { "پاسخ اینجا دیده می‌شه" }
                }
                EmojiText(answer, color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            }
        }
    }
}

/* ======================================================== paste import == */

@Composable
private fun PasteImportSheet(deckId: Int, colors: List<Color>, onDismiss: () -> Unit, onDone: (Int) -> Unit) {
    var text by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var done by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val parsed = remember(text) { Flashcards.parseCsv(text, deckId) }

    ModalBottomSheet(onDismissRequest = { if (!saving) onDismiss() }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            FcSheetHeader("📋", "ورود گروهی کارت‌ها", "هر خط یک کارت: روی کارت، پشت کارت. خروجی CSV انکی هم پذیرفته می‌شود.")
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().height(190.dp),
                shape = RoundedCornerShape(18.dp),
                placeholder = { Text("apple,سیب\nbook,کتاب") },
                enabled = !saving,
            )
            AnimatedVisibility(parsed.isNotEmpty(), enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    EmojiText("✨ ${parsed.size.fa()} کارت شناسایی شد", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = colors.last())
                    parsed.take(3).forEach { c ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(c.front, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall)
                            Text("  ←  ", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Text(c.back, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant)
                        }
                    }
                    if (parsed.size > 3) Text("و ${(parsed.size - 3).fa()} کارت دیگر…", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            if (saving) {
                val p by animateFloatAsState(if (parsed.isEmpty()) 0f else done.toFloat() / parsed.size, tween(250), label = "pasteProg")
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = colors.last())
                Text("${done.fa()} از ${parsed.size.fa()}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
            FcPrimaryButton(
                text = if (parsed.isEmpty()) "وارد کردن" else "وارد کردن ${parsed.size.fa()} کارت",
                emoji = "📥",
                colors = colors,
                enabled = parsed.isNotEmpty(),
                busy = saving,
                modifier = Modifier.fillMaxWidth(),
            ) {
                scope.launch {
                    saving = true
                    var ok = 0
                    parsed.forEach { c ->
                        runCatching { Flashcards.saveCard(c) }.onSuccess { if (it != null) ok++ }
                        done++
                    }
                    saving = false
                    onDone(ok)
                }
            }
        }
    }
}
