package ir.studying.app.ui.flashcards

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.studying.app.core.EmojiText
import ir.studying.app.core.FlashcardLogic
import ir.studying.app.core.Flashcards
import ir.studying.app.core.Icon3D
import ir.studying.app.ui.components.AnimatedEmoji
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/* ================================================================ meta == */

internal data class CardTypeMeta(val key: String, val label: String, val emoji: String, val hint: String)

internal val cardTypeMeta = listOf(
    CardTypeMeta("basic", "دو رو", "🃏", "سوال این رو، جواب پشت کارت"),
    CardTypeMeta("mcq", "چندگزینه‌ای", "✅", "چند گزینه با یک پاسخ درست"),
    CardTypeMeta("cloze", "جای خالی", "🧩", "بخشی از متن پنهان می‌شود"),
    CardTypeMeta("image", "تصویری", "🖼️", "تصویر روی کارت، پاسخ پشتش"),
    CardTypeMeta("audio", "صوتی", "🎧", "تلفظ یا یادداشت صوتی"),
)

internal fun typeMeta(key: String): CardTypeMeta = cardTypeMeta.firstOrNull { it.key == key } ?: cardTypeMeta[0]

internal data class BucketMeta(val label: String, val emoji: String, val color: Color)

internal fun bucketMeta(b: FlashcardLogic.Bucket): BucketMeta = when (b) {
    FlashcardLogic.Bucket.NEW -> BucketMeta("تازه", "✨", Color(0xFF38BDF8))
    FlashcardLogic.Bucket.LEARNING -> BucketMeta("در حال یادگیری", "🧠", Color(0xFFF59E0B))
    FlashcardLogic.Bucket.REVIEW -> BucketMeta("در حال مرور", "🔁", Color(0xFF8B5CF6))
    FlashcardLogic.Bucket.MASTERED -> BucketMeta("تثبیت‌شده", "🏆", Color(0xFF10B981))
}

internal fun Flashcards.Card.bucket(): FlashcardLogic.Bucket = FlashcardLogic.bucket(state, intervalDays)

internal fun deckIconOf(icon: String?): String = icon?.takeIf { it.isNotBlank() } ?: "📚"

/* ============================================================== chrome == */

/** Flat top bar: round back button, title block, round actions. */
@Composable
internal fun FcTopBar(
    title: String,
    subtitle: String? = null,
    onBack: () -> Unit,
    backIcon: ImageVector = Icons.AutoMirrored.Rounded.ArrowBack,
    modifier: Modifier = Modifier,
    onColor: Color = MaterialTheme.colorScheme.onSurface,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FcRoundButton(backIcon, "بازگشت", onBack, tint = onColor)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = onColor,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!subtitle.isNullOrBlank()) {
                EmojiText(subtitle, style = MaterialTheme.typography.labelMedium, color = onColor.copy(alpha = 0.65f), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically, content = actions)
    }
}

@Composable
internal fun FcRoundButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    container: Color = tint.copy(alpha = 0.08f),
    badge: Boolean = false,
) {
    val inter = remember { MutableInteractionSource() }
    val pressed by inter.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.5f, stiffness = 800f), label = "rbs")
    Box {
        Surface(onClick = onClick, shape = CircleShape, color = container, interactionSource = inter,
            modifier = Modifier.size(42.dp).graphicsLayer { scaleX = s; scaleY = s }) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, desc, tint = tint, modifier = Modifier.size(21.dp)) }
        }
        if (badge) Box(Modifier.align(Alignment.TopEnd).padding(5.dp).size(9.dp).clip(CircleShape).background(Color(0xFFF43F5E)))
    }
}

/** Press feedback shared by the big tappable cards. */
@Composable
internal fun pressScale(inter: MutableInteractionSource, pressed: Float = 0.965f): Float {
    val p by inter.collectIsPressedAsState()
    val s by animateFloatAsState(if (p) pressed else 1f, spring(dampingRatio = 0.55f, stiffness = 650f), label = "press")
    return s
}

/* ============================================================ emblems == */

/** Deck badge: glossy gradient squircle with the deck's 3D emoji. */
@Composable
internal fun DeckEmblem(
    icon: String,
    colorKey: String,
    size: Dp,
    modifier: Modifier = Modifier,
    animated: Boolean = false,
    playKey: Any? = null,
) {
    val colors = deckColors(colorKey)
    val shape = RoundedCornerShape(size * 0.32f)
    Box(
        modifier
            .size(size)
            .graphicsLayer { shadowElevation = 6.dp.toPx(); this.shape = shape; clip = false }
            .clip(shape)
            .background(Brush.linearGradient(colors))
            .drawWithContent {
                drawContent()
                // glossy highlight
                drawCircle(
                    Brush.radialGradient(listOf(Color.White.copy(alpha = 0.45f), Color.Transparent),
                        center = Offset(this.size.width * 0.25f, this.size.height * 0.15f), radius = this.size.width * 0.75f),
                    radius = this.size.width * 0.75f, center = Offset(this.size.width * 0.25f, this.size.height * 0.15f),
                )
            }
            .border(1.dp, Color.White.copy(alpha = 0.35f), shape),
        contentAlignment = Alignment.Center,
    ) {
        val e = deckIconOf(icon)
        if (animated) AnimatedEmoji(e, size * 0.62f, playKey = playKey, idle = true, burst = playKey != null)
        else Icon3D(e, size * 0.6f)
    }
}

/** Ring with an animated sweep; [content] sits in the middle. */
@Composable
internal fun ProgressRing(
    progress: Float,
    size: Dp,
    stroke: Dp,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    track: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(progress) { anim.animateTo(progress.coerceIn(0f, 1f), tween(1100, easing = FastOutSlowInEasing)) }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val inset = sw / 2f
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(sw))
            val sweep = 360f * anim.value
            if (sweep > 0.5f) {
                rotate(-90f) {
                    drawArc(Brush.sweepGradient(colors + colors.first()), 0f, sweep, false, Offset(inset, inset), arcSize,
                        style = Stroke(sw, cap = StrokeCap.Round))
                }
            }
        }
        content()
    }
}

@Composable
internal fun FcPill(emoji: String, text: String, tint: Color, modifier: Modifier = Modifier, onColor: Color? = null) {
    Row(
        modifier.clip(CircleShape).background(tint.copy(alpha = 0.14f)).padding(start = 6.dp, end = 10.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon3D(emoji, 16.dp)
        Spacer(Modifier.width(4.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = onColor ?: tint, maxLines = 1)
    }
}

/* ============================================================ buttons == */

/** Gradient call to action with a soft light sweep and spring press. */
@Composable
internal fun FcPrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    emoji: String? = null,
    colors: List<Color> = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary),
    contentColor: Color = Color.White,
    enabled: Boolean = true,
    busy: Boolean = false,
    height: Dp = 54.dp,
    onClick: () -> Unit,
) {
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter, 0.955f)
    val haptic = LocalHapticFeedback.current
    val sweep = rememberInfiniteTransition(label = "fcBtn")
    val x by sweep.animateFloat(-0.4f, 1.4f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "fcBtnX")
    val shape = RoundedCornerShape(height / 2.6f)
    Box(
        modifier
            .height(height)
            .graphicsLayer { scaleX = s; scaleY = s; alpha = if (enabled) 1f else 0.5f }
            .clip(shape)
            .background(Brush.linearGradient(colors))
            .drawWithContent {
                drawContent()
                if (enabled && !busy) {
                    val w = this.size.width
                    drawRect(Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent),
                        start = Offset(w * x - w * 0.25f, 0f), end = Offset(w * x + w * 0.25f, this.size.height),
                    ))
                }
            }
            .clickable(inter, indication = null, enabled = enabled && !busy) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = contentColor, strokeWidth = 2.5.dp)
        else Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 16.dp)) {
            if (emoji != null) { Icon3D(emoji, 24.dp); Spacer(Modifier.width(8.dp)) }
            Text(text, color = contentColor, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        }
    }
}

/** Big square-ish action with a 3D emoji, used on the home row. */
@Composable
internal fun FcActionTile(emoji: String, title: String, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter)
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, interactionSource = inter, shape = RoundedCornerShape(22.dp),
        color = cs.surface, border = BorderStroke(1.dp, tint.copy(alpha = 0.22f)),
        modifier = modifier.graphicsLayer { scaleX = s; scaleY = s },
    ) {
        Column(
            Modifier.background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.13f), Color.Transparent))).padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AnimatedEmoji(emoji, 34.dp, burst = false, playKey = null, onClick = onClick)
            Spacer(Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1, color = cs.onSurface)
        }
    }
}

@Composable
internal fun FcSheetHeader(emoji: String, title: String, subtitle: String?, playKey: Any? = null) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(cs.primary.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
            AnimatedEmoji(emoji, 38.dp, autoPlay = true, playKey = playKey, burst = playKey != null)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}

/* ========================================================== decoration == */

/** Slowly drifting colour blobs behind heroes and the review session. */
@Composable
internal fun FcBackdrop(colors: List<Color>, modifier: Modifier = Modifier, strength: Float = 1f) {
    val t = rememberInfiniteTransition(label = "fcBlob")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "fcBlobA")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(13000, easing = LinearEasing), RepeatMode.Reverse), label = "fcBlobB")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (!w.isFinite() || !h.isFinite() || w <= 0f || h <= 0f || colors.isEmpty()) return@Canvas
        val c1 = colors.first()
        val c2 = colors.last()
        fun blob(c: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = alpha * strength), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy))
        }
        blob(c1, w * (0.15f + 0.25f * a), h * (0.12f + 0.1f * b), w * 0.75f, 0.30f)
        blob(c2, w * (0.95f - 0.3f * b), h * (0.55f + 0.15f * a), w * 0.7f, 0.24f)
        blob(c1, w * (0.4f + 0.2f * b), h * (1.0f - 0.08f * a), w * 0.6f, 0.18f)
    }
}

/** Three fanned cards that bob gently, with a 3D emoji on the front one. */
@Composable
internal fun FloatingCardsArt(emoji: String, modifier: Modifier = Modifier, size: Dp = 108.dp) {
    val t = rememberInfiniteTransition(label = "fcArt")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "fcArtP")
    val wave = sin(p * 2f * PI.toFloat())
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        val cw = size * 0.62f
        val ch = size * 0.8f
        listOf(-16f, 9f).forEachIndexed { i, base ->
            Box(
                Modifier.size(cw, ch).graphicsLayer {
                    rotationZ = base + wave * (3f + i)
                    translationX = (if (i == 0) -1 else 1) * size.toPx() * 0.13f
                    translationY = wave * 3.dp.toPx() * (if (i == 0) 1 else -1)
                }.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.22f + 0.08f * i))
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(14.dp)),
            )
        }
        Box(
            Modifier.size(cw, ch).graphicsLayer {
                rotationZ = -2f + wave * 2.5f
                translationY = -wave * 5.dp.toPx()
            }.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.95f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon3D(emoji, cw * 0.62f)
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp).width(cw * 0.5f).height(4.dp).clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.08f)))
        }
    }
}

private class Confetto(val x: Float, val vx: Float, val vy: Float, val spin: Float, val color: Color, val w: Float, val h: Float, val delay: Float)

/** One-shot confetti rain; replays when [key] changes. */
@Composable
internal fun ConfettiLayer(key: Any?, modifier: Modifier = Modifier, count: Int = 70) {
    val cs = MaterialTheme.colorScheme
    val palette = listOf(Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFF38BDF8), Color(0xFFF43F5E), Color(0xFFA78BFA), cs.primary)
    val pieces = remember(key) {
        val r = Random(key.hashCode())
        List(count) {
            Confetto(
                x = r.nextFloat(), vx = (r.nextFloat() - 0.5f) * 0.35f, vy = 0.55f + r.nextFloat() * 0.6f,
                spin = (r.nextFloat() - 0.5f) * 1400f, color = palette[r.nextInt(palette.size)],
                w = 5f + r.nextFloat() * 6f, h = 8f + r.nextFloat() * 9f, delay = r.nextFloat() * 0.35f,
            )
        }
    }
    val t = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { t.snapTo(0f); t.animateTo(1f, tween(3200, easing = LinearEasing)) }
    Canvas(modifier) {
        val time = t.value
        if (time <= 0f || time >= 1f) return@Canvas
        pieces.forEach { c ->
            val lt = ((time - c.delay) / (1f - c.delay)).coerceIn(0f, 1f)
            if (lt <= 0f) return@forEach
            val y = -0.08f * size.height + (c.vy * lt + 0.9f * lt * lt) * size.height
            val x = (c.x + c.vx * lt + 0.03f * sin(lt * 12f + c.x * 6f)) * size.width
            if (y > size.height + 20f) return@forEach
            val fade = if (lt > 0.85f) (1f - lt) / 0.15f else 1f
            rotate(c.spin * lt, Offset(x, y)) {
                val squash = cos(lt * 10f + c.x * 5f).let { kotlin.math.abs(it) }.coerceAtLeast(0.25f)
                drawRoundRect(c.color.copy(alpha = fade), Offset(x - c.w / 2f, y - c.h * squash / 2f),
                    Size(c.w.dp.toPx() / 2f, c.h.dp.toPx() * squash / 2f), CornerRadius(2f))
            }
        }
    }
}

/** Little dots used as a decorative row of "cards" in skeletons and empty states. */
@Composable
internal fun FcSkeletonDeck() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "fcsk")
    val a by t.animateFloat(0.35f, 0.85f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "fcskA")
    Box(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Box(Modifier.matchParentSizeOffset().graphicsLayer { alpha = a * 0.5f }.clip(RoundedCornerShape(26.dp)).background(cs.surfaceVariant))
        Surface(shape = RoundedCornerShape(26.dp), color = cs.surface, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.4f))) {
            Row(Modifier.fillMaxWidth().padding(16.dp).graphicsLayer { alpha = a }, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(19.dp)).background(cs.surfaceVariant))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.fillMaxWidth(0.6f).height(14.dp).clip(CircleShape).background(cs.surfaceVariant))
                    Box(Modifier.fillMaxWidth(0.4f).height(10.dp).clip(CircleShape).background(cs.surfaceVariant))
                    Box(Modifier.fillMaxWidth(0.8f).height(30.dp).clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant))
                }
            }
        }
    }
}

private fun Modifier.matchParentSizeOffset(): Modifier = this.then(Modifier.fillMaxWidth().height(20.dp).offset(y = (-6).dp).padding(horizontal = 18.dp))

/** Confirmation dialog with a 3D emoji on top. */
@Composable
internal fun FcConfirmDialog(
    emoji: String,
    title: String,
    text: String,
    confirmLabel: String,
    danger: Boolean = true,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        icon = { AnimatedEmoji(emoji, 56.dp, autoPlay = true) },
        title = { Text(title, fontWeight = FontWeight.Black) },
        text = { Text(text, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant) },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = { onDismiss(); onConfirm() }) {
                Text(confirmLabel, color = if (danger) cs.error else cs.primary, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { Text("انصراف") } },
        shape = RoundedCornerShape(28.dp),
    )
}
