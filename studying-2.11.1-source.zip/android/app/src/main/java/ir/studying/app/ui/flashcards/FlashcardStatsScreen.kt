package ir.studying.app.ui.flashcards

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.FlashcardLogic
import ir.studying.app.core.Flashcards
import ir.studying.app.core.Fmt
import ir.studying.app.core.Icon3D
import ir.studying.app.core.IranTime
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.components.shimmerBrush
import ir.studying.app.ui.report.smoothPath
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.roundToInt

private val Emerald = Color(0xFF10B981)
private val weekdayInitials = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

/**
 * Review statistics. The hero answers "how much of this do I actually know",
 * the tiles show the streak and the last two months, the forecast shows the
 * next two weeks (overdue cards folded into today, because that is when they
 * have to be done), then a 60-day activity map and a 30-day trend you can
 * switch between cards and minutes. Everything taps for details.
 */
@Composable
fun FlashcardStatsScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var stats by remember { mutableStateOf<Flashcards.Stats?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var refreshing by remember { mutableStateOf(false) }
    val decks by Flashcards.decks.collectAsState()
    val today = remember(reloadKey) { IranTime.todayIso() }

    LaunchedEffect(reloadKey) {
        refreshing = true
        error = null
        // The per-deck "new" counts cover cards that were never reviewed, which
        // the stats endpoint does not see, so the deck list is kept fresh too.
        if (reloadKey > 0 || Flashcards.decks.value.isEmpty()) runCatching { Flashcards.loadDecks() }
        runCatching { Flashcards.stats() }
            .onSuccess { stats = it }
            .onFailure { e ->
                if (stats == null) error = e.message ?: "دریافت آمار ناموفق بود"
                else AppSnack.show("به‌روزرسانی آمار ناموفق بود")
            }
        refreshing = false
    }

    // The refresh button keeps turning while a reload is running.
    val spin = remember { Animatable(0f) }
    LaunchedEffect(refreshing) {
        if (refreshing) {
            while (true) spin.animateTo(spin.value + 360f, tween(850, easing = LinearEasing))
        } else {
            spin.animateTo((ceil(spin.value / 360f) * 360f), tween(260))
        }
    }

    Box(Modifier.fillMaxSize()) {
        FcBackdrop(listOf(Emerald, cs.primary), Modifier.fillMaxWidth().height(380.dp), strength = 0.55f)
        Column(Modifier.fillMaxSize()) {
            FcTopBar("آمار فلش‌کارت", "۶۰ روز گذشته و دو هفتهٔ پیش رو", onBack) {
                Box(Modifier.graphicsLayer { rotationZ = spin.value }) {
                    FcRoundButton(Icons.Rounded.Refresh, "تازه‌سازی", { if (!refreshing) reloadKey++ })
                }
            }
            val phase = when {
                stats != null -> 2
                error != null -> 1
                else -> 0
            }
            AnimatedContent(
                targetState = phase,
                transitionSpec = {
                    (fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 14 }) togetherWith fadeOut(tween(160))
                },
                label = "fcStatsPhase",
                modifier = Modifier.fillMaxSize(),
            ) { p ->
                when (p) {
                    0 -> StatsSkeleton()
                    1 -> Box(Modifier.fillMaxSize().padding(16.dp)) {
                        ErrorState(error ?: "دریافت آمار ناموفق بود", onRetry = { reloadKey++ })
                    }
                    else -> stats?.let { s ->
                        StatsBody(s, decks, today, refreshing) { if (!refreshing) reloadKey++ }
                    }
                }
            }
        }
    }
}

/* ================================================================ body == */

@Composable
private fun StatsBody(
    s: Flashcards.Stats,
    decks: List<Flashcards.Deck>,
    today: String,
    refreshing: Boolean,
    onRefresh: () -> Unit,
) {
    val breakdown = remember(s, decks) { FlashcardLogic.breakdown(s.states, s.mastered, decks.sumOf { it.fresh }) }
    val summary = remember(s) { FlashcardLogic.summarize(s.history) }
    val streak = remember(s, today) { FlashcardLogic.streak(s.history.map { it.first to it.second }, today) }
    val forecast = remember(s, today) { FlashcardLogic.forecast(s.forecast, today, 14) }
    val overdue = remember(s, today) { FlashcardLogic.overdue(s.forecast, today) }
    val byDay = remember(s) { s.history.associate { it.first to (it.second to it.third) } }

    Refreshable(onRefresh = onRefresh, refreshing = refreshing) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item(key = "hero") { FadeSlideIn(0) { MasteryHero(breakdown, streak) } }
            item(key = "tiles") { FadeSlideIn(1) { StatTiles(streak, summary) } }
            item(key = "insight") { FadeSlideIn(2) { InsightCard(breakdown, overdue, streak, forecast) } }
            item(key = "forecast") { FadeSlideIn(3) { ForecastCard(forecast, overdue) } }
            item(key = "heat") { FadeSlideIn(4) { ActivityCard(byDay, today, summary) } }
            item(key = "trend") { FadeSlideIn(5) { TrendCard(byDay, today) } }
        }
    }
}

/* ================================================================ hero == */

@Composable
private fun MasteryHero(b: FlashcardLogic.Breakdown, streak: Int) {
    val shape = RoundedCornerShape(30.dp)
    val glow = rememberInfiniteTransition(label = "fcStatsGlow")
    val g by glow.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse), label = "fcStatsGlowT")
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF064E3B), Color(0xFF0F766E), Color(0xFF3730A3))))
            .drawBehind {
                val w = size.width
                val h = size.height
                val c1 = Offset(w * (0.12f + 0.22f * g), h * 0.08f)
                val c2 = Offset(w * (0.92f - 0.18f * g), h * 0.96f)
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFF34D399).copy(alpha = 0.34f), Color.Transparent), center = c1, radius = w * 0.62f),
                    radius = w * 0.62f, center = c1,
                )
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFFA78BFA).copy(alpha = 0.30f), Color.Transparent), center = c2, radius = w * 0.56f),
                    radius = w * 0.56f, center = c2,
                )
            }
            .padding(18.dp),
    ) {
        if (b.total == 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FloatingCardsArt("🧠", size = 96.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("هنوز آماری نداری", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "اولین دسته رو بساز و چند کارت مرور کن؛ پیشرفتت همین‌جا جون می‌گیره.",
                        color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        } else {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        progress = b.share(b.mastered),
                        size = 118.dp,
                        stroke = 11.dp,
                        colors = listOf(Color(0xFF6EE7B7), Color(0xFFFDE68A), Color(0xFF34D399)),
                        track = Color.White.copy(alpha = 0.16f),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            AnimatedEmoji("🏆", 34.dp, autoPlay = true, idle = true)
                            CountUp(
                                b.percent(b.mastered),
                                MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                Color.White, suffix = "٪",
                            )
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("تسلط بر مجموعه", style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.75f))
                        Row(verticalAlignment = Alignment.Bottom) {
                            CountUp(b.mastered, MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black), Color.White)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "کارت تثبیت‌شده", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.padding(bottom = 5.dp), maxLines = 1,
                            )
                        }
                        Text(
                            "از ${b.total.fa()} کارت؛ کارتی که فاصلهٔ مرورش به ۲۱ روز برسد تثبیت‌شده است",
                            style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.7f),
                        )
                        if (streak > 0) {
                            Spacer(Modifier.height(8.dp))
                            FcPill("🔥", "${streak.fa()} روز پیاپی", Color.White, onColor = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                val parts = listOf(
                    FlashcardLogic.Bucket.NEW to b.fresh,
                    FlashcardLogic.Bucket.LEARNING to b.learning,
                    FlashcardLogic.Bucket.REVIEW to b.review,
                    FlashcardLogic.Bucket.MASTERED to b.mastered,
                )
                SegmentBar(parts.map { it.second to bucketMeta(it.first).color })
                Spacer(Modifier.height(14.dp))
                parts.chunked(2).forEachIndexed { r, row ->
                    if (r > 0) Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (bucket, n) -> LegendCell(bucketMeta(bucket), n, b.percent(n), Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

/** Stacked share bar; the segments grow in from the start edge. */
@Composable
private fun SegmentBar(parts: List<Pair<Int, Color>>) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(parts) {
        reveal.snapTo(0f)
        reveal.animateTo(1f, tween(1200, easing = FastOutSlowInEasing))
    }
    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        val r = size.height / 2f
        drawRoundRect(Color.White.copy(alpha = 0.14f), cornerRadius = CornerRadius(r, r))
        val visible = parts.filter { it.first > 0 }
        val total = visible.sumOf { it.first }
        if (total <= 0) return@Canvas
        val gap = 3.dp.toPx()
        val usable = size.width - gap * (visible.size - 1).coerceAtLeast(0)
        val t = reveal.value
        var x = 0f
        visible.forEach { (v, c) ->
            val w = (usable * v / total * t).coerceAtLeast(0f)
            if (w > 0.5f) {
                val left = if (rtl) size.width - x - w else x
                drawRoundRect(
                    Brush.verticalGradient(listOf(c, c.copy(alpha = 0.78f))),
                    topLeft = Offset(left, 0f), size = Size(w, size.height), cornerRadius = CornerRadius(r, r),
                )
            }
            x += w + gap * t
        }
    }
}

@Composable
private fun LegendCell(meta: BucketMeta, count: Int, pct: Int, modifier: Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.09f))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(meta.color.copy(alpha = 0.26f)), contentAlignment = Alignment.Center) {
            Icon3D(meta.emoji, 19.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                meta.label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                CountUp(count, MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black), Color.White)
                Spacer(Modifier.width(5.dp))
                Text("${pct.fa()}٪", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
            }
        }
        Box(Modifier.size(8.dp).clip(CircleShape).background(meta.color))
    }
}

/* =============================================================== tiles == */

private data class TileData(val emoji: String, val value: Int, val label: String, val caption: String, val tint: Color)

@Composable
private fun StatTiles(streak: Int, h: FlashcardLogic.HistorySummary) {
    val items = listOf(
        TileData(
            "🔥", streak, "روز پیاپی",
            if (streak > 0) "زنجیره رو امروز هم حفظ کن" else "با یک مرور، زنجیره شروع می‌شه",
            Color(0xFFF97316),
        ),
        TileData("🃏", h.cards, "کارت مرورشده", "در ۶۰ روز گذشته", Color(0xFF8B5CF6)),
        TileData(
            "⏱️", h.minutes, "دقیقه مرور",
            if (h.cards > 0) "حدود ${h.secondsPerCard.fa()} ثانیه برای هر کارت" else "هنوز زمانی ثبت نشده",
            Color(0xFF0EA5E9),
        ),
        TileData(
            "📅", h.activeDays, "روز فعال",
            if (h.activeDays > 0) "میانگین ${h.perActiveDay.fa()} کارت در هر روز فعال" else "از امروز شروع کن",
            Emerald,
        ),
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { StatTile(it, Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun StatTile(d: TileData, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter)
    var play by remember { mutableIntStateOf(0) }
    Surface(
        onClick = { play++ },
        interactionSource = inter,
        shape = RoundedCornerShape(24.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, d.tint.copy(alpha = 0.22f)),
        modifier = modifier.graphicsLayer { scaleX = s; scaleY = s },
    ) {
        Column(
            Modifier
                .background(Brush.verticalGradient(listOf(d.tint.copy(alpha = 0.16f), Color.Transparent)))
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedEmoji(d.emoji, 30.dp, playKey = play, autoPlay = true, burst = play > 0)
                Spacer(Modifier.weight(1f))
                CountUp(d.value, MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black), d.tint)
            }
            Spacer(Modifier.height(8.dp))
            Text(d.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1)
            Text(
                d.caption, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/* ============================================================= insight == */

@Composable
private fun InsightCard(b: FlashcardLogic.Breakdown, overdue: Int, streak: Int, forecast: List<Pair<String, Int>>) {
    val cs = MaterialTheme.colorScheme
    val (emoji, text) = remember(b, overdue, streak, forecast) { insightOf(b, overdue, streak, forecast) }
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.13f), cs.tertiary.copy(alpha = 0.09f))))
            .border(1.dp, cs.primary.copy(alpha = 0.18f), shape)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AnimatedEmoji(emoji, 38.dp, autoPlay = true, idle = true, burst = false)
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = cs.onSurface, modifier = Modifier.weight(1f))
    }
}

private fun insightOf(
    b: FlashcardLogic.Breakdown,
    overdue: Int,
    streak: Int,
    forecast: List<Pair<String, Int>>,
): Pair<String, String> {
    val week = forecast.take(7)
    val peak = week.maxByOrNull { it.second }
    val avg = if (week.isEmpty()) 0f else week.sumOf { it.second } / week.size.toFloat()
    return when {
        b.total == 0 -> "💡" to "با ساختن اولین دسته و مرور روزانه، نمودارهای این صفحه کم‌کم پر می‌شن."
        overdue > 0 -> "⏰" to "${overdue.fa()} کارت از روزهای قبل منتظر مرورند؛ یک جلسهٔ کوتاه امروز عقب‌افتادگی رو صاف می‌کنه."
        streak >= 3 -> "🔥" to "${streak.fa()} روز پشت سر هم مرور کردی! زنجیره رو امروز هم نشکن."
        peak != null && peak.second >= 10 && peak.second >= avg * 2f ->
            "📌" to "${Fmt.jalaliWithDay(peak.first)} با ${peak.second.fa()} کارت شلوغ‌ترین روز هفتهٔ پیش روست؛ از قبل براش وقت بذار."
        b.share(b.mastered) >= 0.5f -> "🏆" to "بیش از نیمی از کارت‌هات تثبیت شده‌اند؛ حافظه‌ات داره کارش رو خوب انجام می‌ده."
        b.fresh > 0 -> "✨" to "${b.fresh.fa()} کارت تازه هنوز دیده نشده؛ روزی چند کارت جدید کافیه تا مرورها سنگین نشن."
        else -> "💡" to "مرورهای کوتاه و هر روزه از یک جلسهٔ طولانی و نامنظم ماندگارترند."
    }
}

/* ============================================================ forecast == */

private fun dayName(i: Int, iso: String): String = when (i) {
    0 -> "امروز"
    1 -> "فردا"
    else -> Fmt.jalaliWithDay(iso)
}

@Composable
private fun ForecastCard(days: List<Pair<String, Int>>, overdue: Int) {
    val cs = MaterialTheme.colorScheme
    val total = days.sumOf { it.second }
    var selected by remember(days) { mutableStateOf<Int?>(null) }
    StatsCard {
        CardTitle("🗓️", "دو هفتهٔ پیش رو", "کارت‌هایی که موعد مرورشان می‌رسد") {
            FcPill("📌", "${total.fa()} کارت", cs.primary)
        }
        if (overdue > 0) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF59E0B).copy(alpha = 0.13f))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon3D("⏰", 20.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    "${overdue.fa()} کارت عقب‌افتاده روی امروز جمع شده",
                    style = MaterialTheme.typography.labelLarge, color = cs.onSurface,
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        if (total == 0) {
            Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedEmoji("🌴", 48.dp, autoPlay = true, idle = true)
                Spacer(Modifier.height(6.dp))
                Text("دو هفتهٔ آینده مروری در پیش نیست", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
        } else {
            val sel = selected
            val info = if (sel != null) {
                val (iso, n) = days[sel]
                "${dayName(sel, iso)}: ${if (n > 0) "${n.fa()} کارت" else "بدون مرور"}"
            } else {
                val peakIndex = days.indices.maxByOrNull { days[it].second } ?: 0
                "شلوغ‌ترین روز: ${dayName(peakIndex, days[peakIndex].first)} با ${days[peakIndex].second.fa()} کارت"
            }
            AnimatedContent(
                targetState = info,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
                label = "fcForecastInfo",
            ) { t ->
                Text(
                    t, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
                    color = if (sel != null) cs.primary else cs.onSurfaceVariant,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(10.dp))
            ForecastBars(days, selected) { i -> selected = if (selected == i) null else i }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniMetric("این هفته", days.take(7).sumOf { it.second }, Modifier.weight(1f))
                MiniMetric("هفتهٔ بعد", days.drop(7).sumOf { it.second }, Modifier.weight(1f))
                MiniMetric("میانگین روزانه", (total + days.size / 2) / days.size.coerceAtLeast(1), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ForecastBars(days: List<Pair<String, Int>>, selected: Int?, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val max = (days.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(days) {
        reveal.snapTo(0f)
        reveal.animateTo(1f, tween(1100, easing = LinearEasing))
    }
    val barArea = 112.dp
    val small = MaterialTheme.typography.labelSmall
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Bottom) {
        days.forEachIndexed { i, (iso, n) ->
            val isSel = selected == i
            val isToday = i == 0
            val lift by animateFloatAsState(if (isSel) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = 520f), label = "fcBarLift")
            val barShape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = 4.dp, bottomEnd = 4.dp)
            Column(
                Modifier.weight(1f).clickableNoRipple { onSelect(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    if (n > 0) n.fa() else "",
                    style = small.copy(fontSize = 9.sp), fontWeight = FontWeight.Bold, maxLines = 1,
                    color = if (isSel || isToday) cs.primary else cs.onSurfaceVariant,
                    modifier = Modifier.graphicsLayer { alpha = stagger(reveal.value, i, days.size) },
                )
                Spacer(Modifier.height(2.dp))
                Box(Modifier.fillMaxWidth().height(barArea), contentAlignment = Alignment.BottomCenter) {
                    val h = (barArea * (n.toFloat() / max)).coerceAtLeast(5.dp)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(h)
                            .graphicsLayer {
                                transformOrigin = TransformOrigin(0.5f, 1f)
                                scaleY = stagger(reveal.value, i, days.size).coerceAtLeast(0.02f)
                                scaleX = 1f + 0.1f * lift
                            }
                            .clip(barShape)
                            .background(
                                when {
                                    n == 0 -> SolidColor(cs.onSurface.copy(alpha = 0.08f))
                                    isToday -> Brush.verticalGradient(listOf(Color(0xFFFB7185), Color(0xFFF97316)))
                                    else -> Brush.verticalGradient(listOf(cs.primary, cs.primary.copy(alpha = 0.5f)))
                                },
                            )
                            .then(if (isSel) Modifier.border(2.dp, cs.onSurface.copy(alpha = 0.65f), barShape) else Modifier),
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    weekdayInitials[ReportStats.weekdayIndex(iso)],
                    style = small.copy(fontSize = 9.sp), color = cs.onSurfaceVariant.copy(alpha = 0.8f), maxLines = 1,
                )
                Text(
                    ReportStats.jalaliOf(iso)?.day?.fa() ?: "",
                    style = small.copy(fontSize = 10.sp), maxLines = 1,
                    fontWeight = if (isToday || isSel) FontWeight.Black else FontWeight.Medium,
                    color = if (isToday) cs.primary else cs.onSurface,
                )
            }
        }
    }
}

@Composable
private fun MiniMetric(label: String, value: Int, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(cs.surfaceVariant.copy(alpha = 0.55f))
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CountUp(value, MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black), cs.onSurface)
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

/* ============================================================ activity == */

private fun heat(level: Int, cs: ColorScheme): Color = when (level) {
    0 -> cs.onSurface.copy(alpha = 0.07f)
    1 -> Emerald.copy(alpha = 0.32f)
    2 -> Emerald.copy(alpha = 0.55f)
    3 -> Emerald.copy(alpha = 0.78f)
    else -> Emerald
}

private fun durationText(seconds: Int): String = when {
    seconds <= 0 -> ""
    seconds < 60 -> "${seconds.fa()} ثانیه"
    else -> "${((seconds + 30) / 60).fa()} دقیقه"
}

/**
 * Sixty days as a calendar grid: one column per week (Saturday on top), the
 * oldest week at the start edge. Taps show the day underneath.
 */
@Composable
private fun ActivityCard(byDay: Map<String, Pair<Int, Int>>, today: String, h: FlashcardLogic.HistorySummary) {
    val cs = MaterialTheme.colorScheme
    val start = remember(today) { ReportStats.weekStart(ReportStats.shift(today, -59)) }
    val weeks = remember(start, today) { ((ReportStats.daysBetween(start, today) ?: 0) / 7) + 1 }
    val scale = remember(byDay) { ReportStats.heatScale(byDay.values.map { it.first }) }
    var selected by remember(byDay) { mutableStateOf<String?>(null) }
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(byDay) {
        reveal.snapTo(0f)
        reveal.animateTo(1f, tween(1200, easing = LinearEasing))
    }

    StatsCard {
        CardTitle("🔥", "نقشهٔ فعالیت", "${h.activeDays.fa()} روز فعال در ۶۰ روز گذشته")
        Spacer(Modifier.height(14.dp))
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val labelW = 16.dp
            val gap = 4.dp
            val cell = ((maxWidth - labelW - gap * weeks) / weeks).coerceIn(0.dp, 26.dp)
            val cellShape = RoundedCornerShape(cell * 0.3f)
            Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(gap)) {
                Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                    weekdayInitials.forEach { d ->
                        Box(Modifier.width(labelW).height(cell), contentAlignment = Alignment.Center) {
                            Text(d, fontSize = 9.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
                for (c in 0 until weeks) {
                    Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                        for (r in 0 until 7) {
                            val index = c * 7 + r
                            val iso = ReportStats.shift(start, index)
                            val future = iso > today
                            val cards = byDay[iso]?.first ?: 0
                            val level = ReportStats.heatLevel(cards, scale)
                            val isSel = selected == iso
                            Box(
                                Modifier
                                    .size(cell)
                                    .graphicsLayer {
                                        val t = stagger(reveal.value, index, weeks * 7, 0.6f)
                                        val k = 0.35f + 0.65f * t
                                        scaleX = k
                                        scaleY = k
                                        alpha = if (future) 0f else t
                                    }
                                    .clip(cellShape)
                                    .background(heat(level, cs))
                                    .then(if (iso == today) Modifier.border(1.5.dp, cs.primary, cellShape) else Modifier)
                                    .then(if (isSel) Modifier.border(2.dp, cs.onSurface, cellShape) else Modifier)
                                    .then(
                                        if (future) Modifier
                                        else Modifier.clickableNoRipple { selected = if (selected == iso) null else iso },
                                    ),
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = selected,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                label = "fcHeatSel",
                modifier = Modifier.weight(1f),
            ) { iso ->
                val text = if (iso == null) {
                    "روی هر خانه بزن تا جزئیاتش رو ببینی"
                } else {
                    val (n, sec) = byDay[iso] ?: (0 to 0)
                    val day = if (iso == today) "امروز" else Fmt.jalaliWithDay(iso)
                    if (n > 0) "$day: ${n.fa()} کارت" + durationText(sec).let { if (it.isEmpty()) "" else " در $it" }
                    else "$day: مروری ثبت نشده"
                }
                Text(
                    text, style = MaterialTheme.typography.labelMedium,
                    color = if (iso == null) cs.onSurfaceVariant else cs.onSurface,
                    fontWeight = if (iso == null) FontWeight.Normal else FontWeight.Bold,
                )
            }
            Spacer(Modifier.width(8.dp))
            Text("کم", fontSize = 9.sp, color = cs.onSurfaceVariant)
            Spacer(Modifier.width(3.dp))
            (0..4).forEach { lv ->
                Box(Modifier.padding(horizontal = 1.5.dp).size(10.dp).clip(RoundedCornerShape(3.dp)).background(heat(lv, cs)))
            }
            Spacer(Modifier.width(3.dp))
            Text("زیاد", fontSize = 9.sp, color = cs.onSurfaceVariant)
        }
    }
}

/* =============================================================== trend == */

@Composable
private fun TrendCard(byDay: Map<String, Pair<Int, Int>>, today: String) {
    val cs = MaterialTheme.colorScheme
    var minutes by rememberSaveable { mutableStateOf(false) }
    val dates = remember(today) { ReportStats.window(today, 30) }
    val values = remember(byDay, dates, minutes) {
        dates.map { d -> byDay[d]?.let { if (minutes) (it.second + 30) / 60 else it.first } ?: 0 }
    }
    val total = values.sum()
    val avg = if (values.isEmpty()) 0f else total.toFloat() / values.size
    StatsCard {
        CardTitle("📈", "روند مرور", "۳۰ روز اخیر") {
            MetricToggle(minutes) { minutes = it }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            CountUp(total, MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black), cs.onSurface)
            Spacer(Modifier.width(6.dp))
            Text(
                if (minutes) "دقیقه در ۳۰ روز" else "کارت در ۳۰ روز",
                style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 4.dp).weight(1f),
            )
            if (total > 0) FcPill("📊", "میانگین ${oneDecimal(avg)}", cs.tertiary)
        }
        Spacer(Modifier.height(8.dp))
        if (total == 0) {
            Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedEmoji("🌱", 46.dp, autoPlay = true, idle = true)
                Spacer(Modifier.height(6.dp))
                Text("هنوز مروری در این بازه ثبت نشده", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
        } else {
            TrendChart(values, dates, avg)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                Text(Fmt.jalaliShort(dates.first()), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Text("امروز", style = MaterialTheme.typography.labelSmall, color = cs.primary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun oneDecimal(v: Float): String {
    val s = String.format(Locale.US, "%.1f", v)
    return (if (s.endsWith(".0")) s.dropLast(2) else s).replace('.', '٫').fa()
}

@Composable
private fun MetricToggle(minutes: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.clip(CircleShape).background(cs.surfaceVariant.copy(alpha = 0.75f)).padding(3.dp)) {
        listOf(false to "کارت", true to "دقیقه").forEach { (key, label) ->
            val on = minutes == key
            val bg by animateColorAsState(if (on) cs.primary else Color.Transparent, tween(220), label = "fcToggleBg")
            val fg by animateColorAsState(if (on) cs.onPrimary else cs.onSurfaceVariant, tween(220), label = "fcToggleFg")
            Text(
                label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = fg,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(bg)
                    .clickable { onChange(key) }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

/** Smooth area chart; draws in from the start edge, taps show a tooltip. */
@Composable
private fun TrendChart(values: List<Int>, dates: List<String>, avg: Float) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val tm = rememberTextMeasurer()
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(values) {
        reveal.snapTo(0f)
        reveal.animateTo(1f, tween(1300, easing = FastOutSlowInEasing))
    }
    var sel by remember(values) { mutableStateOf<Int?>(null) }
    val pulse = rememberInfiniteTransition(label = "fcTrendPulse")
    val pr by pulse.animateFloat(0f, 1f, infiniteRepeatable(tween(1700, easing = LinearEasing)), label = "fcTrendPulseT")
    val line = cs.primary
    val accent = cs.tertiary
    val gridColor = cs.onSurface.copy(alpha = 0.08f)
    val tipBg = cs.inverseSurface
    val tipFg = cs.inverseOnSurface
    val labelStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold)
    val n = values.size
    val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(176.dp)
            .pointerInput(values, rtl) {
                detectTapGestures { pos ->
                    if (n == 0) return@detectTapGestures
                    val padX = 10.dp.toPx()
                    val w = size.width - padX * 2
                    if (!w.isFinite() || w <= 0f) return@detectTapGestures
                    val step = if (n > 1) w / (n - 1) else w
                    val fromStart = if (rtl) size.width - padX - pos.x else pos.x - padX
                    val i = (fromStart / step).roundToInt().coerceIn(0, n - 1)
                    sel = if (sel == i) null else i
                }
            },
    ) {
        if (n == 0) return@Canvas
        val padX = 10.dp.toPx()
        val top = 30.dp.toPx()
        val bottom = size.height - 6.dp.toPx()
        val w = size.width - padX * 2
        if (!w.isFinite() || w <= 0f || bottom <= top) return@Canvas
        val step = if (n > 1) w / (n - 1) else w
        fun x(i: Int) = if (rtl) size.width - padX - i * step else padX + i * step
        fun y(v: Float) = bottom - (bottom - top) * (v / max)

        for (k in 0..3) {
            val gy = top + (bottom - top) * k / 3f
            drawLine(
                gridColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f)),
            )
        }
        val pts = values.mapIndexed { i, v -> Offset(x(i), y(v.toFloat())) }
        val path = smoothPath(pts)
        val area = smoothPath(pts).apply {
            lineTo(pts.last().x, bottom)
            lineTo(pts.first().x, bottom)
            close()
        }
        val t = reveal.value
        val revealW = size.width * t
        val clipLeft = if (rtl) size.width - revealW else 0f
        clipRect(left = clipLeft, top = 0f, right = clipLeft + revealW, bottom = size.height) {
            drawPath(area, Brush.verticalGradient(listOf(line.copy(alpha = 0.30f), line.copy(alpha = 0.02f)), startY = top, endY = bottom))
            drawPath(
                path,
                Brush.horizontalGradient(if (rtl) listOf(line, accent) else listOf(accent, line)),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        if (avg > 0f) {
            val ay = y(avg)
            drawLine(
                accent.copy(alpha = 0.65f * t), Offset(0f, ay), Offset(size.width, ay), strokeWidth = 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)),
            )
        }
        if (t > 0.97f) {
            val last = pts.last()
            drawCircle(line.copy(alpha = 0.35f * (1f - pr)), radius = 6.dp.toPx() + 11.dp.toPx() * pr, center = last)
            drawCircle(Color.White, radius = 5.5.dp.toPx(), center = last)
            drawCircle(line, radius = 3.5.dp.toPx(), center = last)
        }
        sel?.let { i ->
            val p = pts[i]
            drawLine(tipBg.copy(alpha = 0.25f), Offset(p.x, top - 4.dp.toPx()), Offset(p.x, bottom), strokeWidth = 1.dp.toPx())
            drawCircle(Color.White, 6.dp.toPx(), p)
            drawCircle(accent, 4.dp.toPx(), p)
            val label = "${Fmt.jalaliShort(dates[i])} · ${values[i].fa()}"
            val layout = tm.measure(label, labelStyle)
            val bw = layout.size.width + 16.dp.toPx()
            val bh = layout.size.height + 8.dp.toPx()
            val bx = (p.x - bw / 2f).coerceIn(0f, (size.width - bw).coerceAtLeast(0f))
            drawRoundRect(tipBg, topLeft = Offset(bx, 0f), size = Size(bw, bh), cornerRadius = CornerRadius(bh / 2f, bh / 2f))
            drawText(layout, color = tipFg, topLeft = Offset(bx + 8.dp.toPx(), 4.dp.toPx()))
        }
    }
}

/* ============================================================== pieces == */

@Composable
private fun StatsCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.45f)),
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun CardTitle(emoji: String, title: String, subtitle: String?, trailing: (@Composable () -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(cs.primary.copy(alpha = 0.09f)),
            contentAlignment = Alignment.Center,
        ) {
            AnimatedEmoji(emoji, 27.dp, autoPlay = true, burst = false)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

/** A number that counts up to its value. */
@Composable
private fun CountUp(value: Int, style: TextStyle, color: Color, modifier: Modifier = Modifier, suffix: String = "") {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(value) { anim.animateTo(value.toFloat(), tween(950, easing = FastOutSlowInEasing)) }
    Text(anim.value.roundToInt().fa() + suffix, style = style, color = color, modifier = modifier, maxLines = 1)
}

/** Staggered 0..1 progress for item [i] of [n] while the shared [t] runs 0..1. */
private fun stagger(t: Float, i: Int, n: Int, spread: Float = 0.45f): Float {
    if (n <= 1) return FastOutSlowInEasing.transform(t.coerceIn(0f, 1f))
    val start = spread * i / (n - 1)
    val p = ((t - start) / (1f - spread)).coerceIn(0f, 1f)
    return FastOutSlowInEasing.transform(p)
}

@Composable
private fun StatsSkeleton() {
    val brush = shimmerBrush()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(30.dp)).background(brush))
        repeat(2) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(2) { Box(Modifier.weight(1f).height(112.dp).clip(RoundedCornerShape(24.dp)).background(brush)) }
            }
        }
        Box(Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(26.dp)).background(brush))
    }
}
