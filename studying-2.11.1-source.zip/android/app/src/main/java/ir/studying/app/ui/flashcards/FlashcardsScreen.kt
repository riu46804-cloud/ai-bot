@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.flashcards

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.ApiException
import ir.studying.app.core.EmojiText
import ir.studying.app.core.Flashcards
import ir.studying.app.core.Icon3D
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.GlassAction
import ir.studying.app.ui.components.GlassDivider
import ir.studying.app.ui.components.GlassMenu
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.messages.ChatEmpty
import kotlinx.coroutines.launch

/** The six deck colors. Stored as a plain key so the server stays dumb. */
val deckPalette: List<Pair<String, List<Color>>> = listOf(
    "mint" to listOf(Color(0xFF4ADE9F), Color(0xFF10B981)),
    "ocean" to listOf(Color(0xFF38BDF8), Color(0xFF2563EB)),
    "grape" to listOf(Color(0xFFA78BFA), Color(0xFF7C3AED)),
    "sunset" to listOf(Color(0xFFFBBF24), Color(0xFFF97316)),
    "rose" to listOf(Color(0xFFFB7185), Color(0xFFE11D48)),
    "gold" to listOf(Color(0xFFFCD34D), Color(0xFFD97706)),
)

fun deckColors(key: String): List<Color> =
    deckPalette.firstOrNull { it.first == key }?.second ?: deckPalette[0].second

fun deckGradient(key: String): Brush = Brush.linearGradient(deckColors(key))

private val heroColors = listOf(Color(0xFF8B5CF6), Color(0xFF6366F1), Color(0xFF3B82F6))

@Composable
fun FlashcardsScreen(
    onBack: () -> Unit,
    onOpenDeck: (Int) -> Unit,
    onReview: (Int) -> Unit,
    onStats: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val decks by Flashcards.decks.collectAsState()
    val dueTotal by Flashcards.dueTotal.collectAsState()
    val pending by Flashcards.pendingSync.collectAsState()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Flashcards.Deck?>(null) }
    var deleting by remember { mutableStateOf<Flashcards.Deck?>(null) }
    var menuFor by remember { mutableStateOf<Flashcards.Deck?>(null) }
    var sharing by remember { mutableStateOf<Pair<Flashcards.Deck, String>?>(null) }
    var syncing by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val fabExpanded by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }

    suspend fun refresh() {
        error = null
        runCatching { Flashcards.loadDecks() }
            .onFailure { error = (it as? ApiException)?.message ?: "خطا در دریافت دسته‌ها" }
        loading = false
    }

    LaunchedEffect(Unit) { refresh() }

    fun share(d: Flashcards.Deck) {
        if (d.shareCode.isNotBlank()) { sharing = d to d.shareCode; return }
        scope.launch {
            runCatching { Flashcards.share(d.id) }
                .onSuccess { sharing = d to it }
                .onFailure { AppSnack.show(it.message ?: "ساخت کد ناموفق بود") }
        }
    }

    Box(Modifier.fillMaxSize()) {
        FcBackdrop(heroColors, Modifier.fillMaxWidth().height(360.dp), strength = 0.55f)
        Column(Modifier.fillMaxSize()) {
            FcTopBar("فلش‌کارت", "مرور هوشمند با تکرار فاصله‌دار", onBack) {
                FcRoundButton(Icons.Rounded.QrCode2, "افزودن با کد", { showImport = true })
                FcRoundButton(Icons.Rounded.Insights, "آمار", onStats)
            }
            Refreshable(onRefresh = { scope.launch { refresh() } }) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item(key = "hero") {
                        FadeSlideIn(0) {
                            DueHero(
                                due = dueTotal,
                                decks = decks.size,
                                mastered = decks.sumOf { it.mastered },
                                fresh = decks.sumOf { it.fresh },
                                onStart = { onReview(0) },
                            )
                        }
                    }
                    item(key = "sync") {
                        androidx.compose.animation.AnimatedVisibility(pending > 0, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                            SyncBanner(pending, syncing) {
                                scope.launch { syncing = true; runCatching { Flashcards.flush() }; syncing = false }
                            }
                        }
                    }
                    item(key = "actions") {
                        FadeSlideIn(1) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                FcActionTile("✨", "دستهٔ جدید", Color(0xFF8B5CF6), Modifier.weight(1f)) { showNew = true }
                                FcActionTile("🔗", "افزودن با کد", Color(0xFF0EA5E9), Modifier.weight(1f)) { showImport = true }
                                FcActionTile("📊", "آمار و پیشرفت", Color(0xFF10B981), Modifier.weight(1f)) { onStats() }
                            }
                        }
                    }
                    item(key = "title") {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp, start = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("دسته‌های من", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                            if (decks.isNotEmpty()) {
                                Text(
                                    "${decks.size.fa()} دسته • ${decks.sumOf { it.total }.fa()} کارت",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    when {
                        loading && decks.isEmpty() -> items(3, key = { "sk$it" }) { FcSkeletonDeck() }
                        error != null && decks.isEmpty() -> item(key = "error") {
                            ErrorState(error!!, onRetry = { scope.launch { loading = true; refresh() } })
                        }
                        decks.isEmpty() -> item(key = "empty") {
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                ChatEmpty(
                                    "🧠", "هنوز دسته‌ای نساخته‌ای",
                                    "لغت، فرمول یا هر چیزی که باید بمونه تو ذهنت رو کارت کن؛ بقیه‌اش با ماست",
                                    actionLabel = "✨ ساخت اولین دسته", onAction = { showNew = true },
                                )
                            }
                        }
                        else -> itemsIndexed(decks, key = { _, d -> d.id }) { i, d ->
                            Box(Modifier.animateItemPlacement()) {
                                FadeSlideIn(i + 2) {
                                    DeckCard(
                                        deck = d,
                                        onOpen = { onOpenDeck(d.id) },
                                        onReview = { onReview(d.id) },
                                        onMenu = { menuFor = d },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        NewDeckFab(
            expanded = fabExpanded,
            onClick = { showNew = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp),
        )
    }

    menuFor?.let { d ->
        GlassMenu(onDismiss = { menuFor = null }) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                DeckEmblem(d.icon, d.color, 40.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${d.total.fa()} کارت", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            GlassDivider()
            GlassAction(Icons.Rounded.Style, "کارت‌ها") { onOpenDeck(d.id) }
            GlassAction(Icons.Rounded.Edit, "ویرایش دسته") { editing = d }
            GlassAction(Icons.Rounded.Share, "اشتراک با کد") { share(d) }
            GlassDivider()
            GlassAction(Icons.Rounded.Delete, "حذف دسته", danger = true) { deleting = d }
        }
    }

    deleting?.let { d ->
        FcConfirmDialog(
            emoji = "🗑️",
            title = "حذف دسته",
            text = "«${d.name}» با همهٔ کارت‌ها و سابقهٔ مرورش برای همیشه حذف می‌شود.",
            confirmLabel = "حذف",
            onConfirm = {
                scope.launch {
                    runCatching { Flashcards.deleteDeck(d.id) }
                        .onSuccess { AppSnack.show("دسته حذف شد") }
                        .onFailure { AppSnack.show(it.message ?: "حذف ناموفق بود") }
                }
            },
            onDismiss = { deleting = null },
        )
    }

    if (showNew) {
        DeckEditorDialog(
            onDismiss = { showNew = false },
            onSave = { name, icon, color, desc ->
                showNew = false
                scope.launch {
                    runCatching { Flashcards.saveDeck(name = name, icon = icon, color = color, description = desc) }
                        .onSuccess { AppSnack.show("دسته ساخته شد ✨") }
                        .onFailure { AppSnack.show(it.message ?: "ذخیره ناموفق بود") }
                }
            },
        )
    }

    editing?.let { d ->
        DeckEditorDialog(
            initialName = d.name, initialIcon = d.icon, initialColor = d.color, initialDescription = d.description,
            onDismiss = { editing = null },
            onSave = { name, icon, color, desc ->
                editing = null
                scope.launch {
                    runCatching { Flashcards.saveDeck(id = d.id, name = name, icon = icon, color = color, description = desc) }
                        .onSuccess { AppSnack.show("دسته به‌روز شد ✅") }
                        .onFailure { AppSnack.show(it.message ?: "ذخیره ناموفق بود") }
                }
            },
        )
    }

    if (showImport) {
        ImportDeckSheet(onDismiss = { showImport = false })
    }

    sharing?.let { (d, code) -> ShareCodeSheet(d, code, onDismiss = { sharing = null }) }
}

/* ================================================================ hero == */

@Composable
internal fun DueHero(due: Int, decks: Int, mastered: Int, fresh: Int, onStart: () -> Unit) {
    val t = rememberInfiniteTransition(label = "dueHero")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Reverse), label = "dueDrift")
    val glow by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "dueGlow")
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { shadowElevation = 10.dp.toPx(); shape = RoundedCornerShape(30.dp); clip = true }
            .background(Brush.linearGradient(heroColors)),
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.10f), radius = size.minDimension * 0.75f,
                center = Offset(size.width * (0.05f + 0.08f * drift), size.height * 0.05f))
            drawCircle(Color.White.copy(alpha = 0.07f), radius = size.minDimension * 0.5f,
                center = Offset(size.width * (0.95f - 0.06f * drift), size.height * 1.05f))
            // tiny stars
            for (i in 0 until 7) {
                val x = size.width * ((i * 0.137f + 0.07f + drift * 0.02f * (i % 3)) % 1f)
                val y = size.height * ((i * 0.29f + 0.11f) % 1f)
                drawCircle(Color.White.copy(alpha = 0.25f + 0.25f * ((i + 1) % 2) * glow), radius = (1.5f + i % 3).dp.toPx(), center = Offset(x, y))
            }
        }
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(
                    Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.18f)).padding(start = 6.dp, end = 10.dp, top = 3.dp, bottom = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon3D(if (due > 0) "🔥" else "🎉", 16.dp)
                    Spacer(Modifier.width(4.dp))
                    Text("مرور امروز", color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                if (due > 0) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        ir.studying.app.ui.components.CountUpText(due, MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black), Color.White)
                        Spacer(Modifier.width(6.dp))
                        Text("کارت آماده", color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
                    }
                } else {
                    Text("همه‌چیز مرور شده!", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "${decks.fa()} دسته • ${mastered.fa()} تثبیت‌شده • ${fresh.fa()} تازه",
                    color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(14.dp))
                val inter = remember { MutableInteractionSource() }
                val s = pressScale(inter, 0.94f)
                Surface(
                    onClick = onStart, interactionSource = inter, shape = CircleShape, color = Color.White,
                    shadowElevation = (6 * glow).dp,
                    modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s },
                ) {
                    Row(Modifier.padding(start = 10.dp, end = 18.dp, top = 9.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon3D(if (due > 0) "▶️" else "🎯", 22.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(if (due > 0) "شروع مرور" else "مرور آزاد", color = Color(0xFF4C1D95), fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            FloatingCardsArt(if (due > 0) "🧠" else "🏆", size = 116.dp)
        }
    }
}

@Composable
private fun SyncBanner(pending: Int, syncing: Boolean, onSync: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onSync, shape = RoundedCornerShape(18.dp), color = Color(0xFFF59E0B).copy(alpha = 0.12f),
        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.3f))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (syncing) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFFD97706))
            else Icon(Icons.Rounded.CloudOff, null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("${pending.fa()} مرور هنوز همگام نشده", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onSurface)
                Text("مرورها روی گوشی محفوظ‌اند؛ برای ارسال بزن", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
    }
}

/* =========================================================== deck card == */

@Composable
internal fun DeckCard(deck: Flashcards.Deck, onOpen: () -> Unit, onReview: () -> Unit, onMenu: () -> Unit) {
    val colors = deckColors(deck.color)
    val cs = MaterialTheme.colorScheme
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter)
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    Box(Modifier.fillMaxWidth().padding(top = 10.dp).graphicsLayer { scaleX = s; scaleY = s }) {
        // the deck's other cards peeking out above
        Box(Modifier.matchParentSize().padding(horizontal = 26.dp).offset(y = (-10).dp).clip(RoundedCornerShape(26.dp))
            .background(colors.last().copy(alpha = 0.16f)))
        Box(Modifier.matchParentSize().padding(horizontal = 13.dp).offset(y = (-5).dp).clip(RoundedCornerShape(26.dp))
            .background(colors.first().copy(alpha = 0.32f)))
        Surface(
            shape = RoundedCornerShape(26.dp), color = cs.surface, shadowElevation = 3.dp,
            border = BorderStroke(1.dp, colors.first().copy(alpha = 0.22f)),
            modifier = Modifier.fillMaxWidth().combinedClickableNoRipple(inter, onClick = onOpen, onLongClick = {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); onMenu()
            }),
        ) {
            Column(Modifier.background(Brush.verticalGradient(listOf(colors.first().copy(alpha = 0.10f), Color.Transparent)))) {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        DeckEmblem(deck.icon, deck.color, 58.dp)
                        if (deck.due > 0) DueBadge(deck.due, Modifier.align(Alignment.TopStart).offset(x = (-6).dp, y = (-6).dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(deck.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        EmojiText(
                            deck.description.ifBlank { if (deck.total == 0) "هنوز کارتی نداره" else "${deck.total.fa()} کارت در این دسته" },
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FcPill("🃏", "${deck.total.fa()} کارت", colors.last())
                            if (deck.fresh > 0) FcPill("✨", "${deck.fresh.fa()} تازه", Color(0xFF0EA5E9))
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    ProgressRing(deck.progress, 56.dp, 6.dp, colors, track = colors.first().copy(alpha = 0.14f)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${(deck.progress * 100).toInt().fa()}٪", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
                            Text("تثبیت", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    FcPrimaryButton(
                        text = if (deck.due > 0) "مرور ${deck.due.fa()} کارت" else "مرور آزاد",
                        emoji = if (deck.due > 0) "🔥" else "🎯",
                        colors = colors,
                        height = 46.dp,
                        modifier = Modifier.weight(1f),
                        onClick = onReview,
                    )
                    Spacer(Modifier.width(6.dp))
                    FcRoundButton(Icons.Rounded.MoreHoriz, "بیشتر", onMenu, tint = cs.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun DueBadge(n: Int, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "dueBadge")
    val s by t.animateFloat(1f, 1.12f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dueBadgeS")
    Box(
        modifier.graphicsLayer { scaleX = s; scaleY = s }.clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFFFB7185), Color(0xFFE11D48))))
            .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            .padding(horizontal = 7.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) { Text(n.fa(), color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall) }
}

private fun Modifier.combinedClickableNoRipple(inter: MutableInteractionSource, onClick: () -> Unit, onLongClick: () -> Unit): Modifier =
    this.combinedClickable(interactionSource = inter, indication = null, onClick = onClick, onLongClick = onLongClick)

@Composable
private fun NewDeckFab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter, 0.92f)
    Surface(
        onClick = onClick, interactionSource = inter, shape = CircleShape, color = Color.Transparent, shadowElevation = 8.dp,
        modifier = modifier.graphicsLayer { scaleX = s; scaleY = s },
    ) {
        Row(
            Modifier.background(Brush.linearGradient(heroColors)).height(56.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(24.dp))
            AnimatedVisibility(expanded, enter = fadeIn() + expandHorizontally(), exit = fadeOut() + shrinkHorizontally()) {
                Text("دستهٔ جدید", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

/* ======================================================== deck editor == */

private val deckIcons = listOf(
    "📚", "🧠", "🔤", "🧮", "🧪", "🌍", "💻", "🩺",
    "🧬", "⚛️", "📐", "🎨", "🎵", "🏛️", "🗣️", "💡",
)

/** Create or edit a deck; a live preview shows the result while typing. */
@Composable
fun DeckEditorDialog(
    initialName: String = "",
    initialIcon: String = "",
    initialColor: String = "mint",
    initialDescription: String = "",
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit,
) {
    var name by remember { mutableStateOf(initialName) }
    var icon by remember { mutableStateOf(initialIcon.ifBlank { "📚" }) }
    var color by remember { mutableStateOf(initialColor.ifBlank { "mint" }) }
    var desc by remember { mutableStateOf(initialDescription) }
    val cs = MaterialTheme.colorScheme
    val colors = deckColors(color)
    val creating = initialName.isBlank()

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(if (creating) "دستهٔ جدید" else "ویرایش دسته", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            // live preview
            Box(
                Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(colors)),
                contentAlignment = Alignment.Center,
            ) {
                FcBackdrop(listOf(Color.White, Color.White), Modifier.matchParentSize(), strength = 0.6f)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(78.dp).clip(RoundedCornerShape(25.dp)).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                        AnimatedEmoji(icon, 56.dp, playKey = icon, idle = true)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(name.ifBlank { "نام دسته" }, color = Color.White.copy(alpha = if (name.isBlank()) 0.6f else 1f),
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (desc.isNotBlank()) Text(desc, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 24.dp))
                }
            }
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(60) }, label = { Text("نام دسته") }, singleLine = true,
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = desc, onValueChange = { desc = it.take(140) }, label = { Text("توضیح کوتاه (اختیاری)") },
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(), maxLines = 2,
            )
            Text("آیکن", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                deckIcons.chunked(8).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        row.forEach { e ->
                            val sel = e == icon
                            val sc by animateFloatAsState(if (sel) 1.12f else 1f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "icSel")
                            Box(
                                Modifier.size(38.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(RoundedCornerShape(13.dp))
                                    .background(if (sel) colors.first().copy(alpha = 0.25f) else cs.surfaceVariant.copy(alpha = 0.6f))
                                    .border(if (sel) 2.dp else 0.dp, if (sel) colors.last() else Color.Transparent, RoundedCornerShape(13.dp))
                                    .clickableNoRipple { icon = e },
                                contentAlignment = Alignment.Center,
                            ) { Icon3D(e, 26.dp) }
                        }
                    }
                }
            }
            Text("رنگ", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                deckPalette.forEach { (key, c) ->
                    val sel = key == color
                    val sz by animateDpAsState(if (sel) 42.dp else 34.dp, spring(dampingRatio = 0.5f, stiffness = 500f), label = "colSel")
                    Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(sz).clip(CircleShape).background(Brush.linearGradient(c))
                                .border(if (sel) 3.dp else 0.dp, if (sel) cs.surface else Color.Transparent, CircleShape)
                                .clickableNoRipple { color = key },
                            contentAlignment = Alignment.Center,
                        ) {
                            androidx.compose.animation.AnimatedVisibility(sel, enter = scaleIn(spring(dampingRatio = 0.4f)) + fadeIn(), exit = fadeOut()) {
                                Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
            FcPrimaryButton(
                text = if (creating) "ساخت دسته" else "ذخیرهٔ تغییرات",
                emoji = if (creating) "✨" else "✅",
                colors = colors,
                enabled = name.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) { onSave(name.trim(), icon, color, desc.trim()) }
        }
    }
}

/* ============================================================ import == */

private fun normalizeCode(s: String): String = s.uppercase().map { c ->
    when (c) {
        in '۰'..'۹' -> '0' + (c - '۰')
        in '٠'..'٩' -> '0' + (c - '٠')
        else -> c
    }
}.filter { it in 'A'..'Z' || it in '0'..'9' }.joinToString("").take(7)

@Composable
private fun ImportDeckSheet(onDismiss: () -> Unit) {
    var code by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<Flashcards.Preview?>(null) }
    var checking by remember { mutableStateOf(false) }
    var notFound by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(code) {
        preview = null
        notFound = false
        if (code.length == 7) {
            checking = true
            runCatching { Flashcards.preview(code) }.onSuccess { preview = it }.onFailure { notFound = true }
            checking = false
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FcSheetHeader("🔗", "افزودن دسته با کد", "کد ۷ حرفی‌ای که دوستت فرستاده رو وارد کن", playKey = preview?.shareCode)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                BasicTextField(
                    value = code,
                    onValueChange = { code = normalizeCode(it) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, keyboardType = KeyboardType.Ascii),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box {
                            Box(Modifier.size(1.dp).graphicsLayer { alpha = 0f }) { inner() }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                repeat(7) { i -> CodeCell(code.getOrNull(i), focused = i == code.length, error = notFound, modifier = Modifier.weight(1f)) }
                            }
                        }
                    },
                )
            }
            AnimatedVisibility(checking, enter = fadeIn(), exit = fadeOut()) {
                LinearProgressIndicator(Modifier.fillMaxWidth().clip(CircleShape))
            }
            AnimatedVisibility(notFound, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                EmojiText("🤔 دسته‌ای با این کد پیدا نشد", color = cs.error, style = MaterialTheme.typography.bodySmall)
            }
            AnimatedVisibility(
                preview != null,
                enter = fadeIn(tween(260)) + expandVertically(spring(dampingRatio = 0.7f)) + scaleIn(initialScale = 0.9f),
                exit = fadeOut() + shrinkVertically(),
            ) {
                val p = preview
                if (p != null) {
                    val colors = deckColors(p.color)
                    Surface(shape = RoundedCornerShape(22.dp), color = colors.first().copy(alpha = 0.1f), border = BorderStroke(1.dp, colors.first().copy(alpha = 0.3f))) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            DeckEmblem(p.icon, p.color, 56.dp, animated = true, playKey = p.shareCode)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${p.total.fa()} کارت • ساختهٔ ${p.ownerName}", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                                if (p.description.isNotBlank()) EmojiText(p.description, style = MaterialTheme.typography.bodySmall, maxLines = 2,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            FcPrimaryButton(
                text = "افزودن به دسته‌های من",
                emoji = "📥",
                enabled = preview != null,
                busy = importing,
                modifier = Modifier.fillMaxWidth(),
            ) {
                scope.launch {
                    importing = true
                    runCatching { Flashcards.import(code) }
                        .onSuccess { AppSnack.show("«${it.name}» به دسته‌هایت اضافه شد 🎉"); onDismiss() }
                        .onFailure { AppSnack.show(it.message ?: "کد نامعتبر است") }
                    importing = false
                }
            }
        }
    }
}

@Composable
private fun CodeCell(ch: Char?, focused: Boolean, error: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val pop by animateFloatAsState(if (ch != null) 1f else 0.6f, spring(dampingRatio = 0.4f, stiffness = 600f), label = "cellPop")
    val t = rememberInfiniteTransition(label = "caret")
    val caret by t.animateFloat(0f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "caretA")
    val border = when {
        error -> cs.error
        focused -> cs.primary
        ch != null -> cs.primary.copy(alpha = 0.45f)
        else -> cs.outlineVariant
    }
    Box(
        modifier.aspectRatio(0.82f).clip(RoundedCornerShape(14.dp))
            .background(if (ch != null) cs.primary.copy(alpha = 0.08f) else cs.surfaceVariant.copy(alpha = 0.5f))
            .border(if (focused) 2.dp else 1.dp, border, RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center,
    ) {
        if (ch != null) Text(ch.toString(), fontSize = 22.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace,
            modifier = Modifier.graphicsLayer { scaleX = pop; scaleY = pop })
        else if (focused) Box(Modifier.width(2.dp).height(22.dp).graphicsLayer { alpha = caret }.background(cs.primary))
    }
}

/* ============================================================= share == */

@Composable
internal fun ShareCodeSheet(deck: Flashcards.Deck, code: String, onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val colors = deckColors(deck.color)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            FcSheetHeader("🔗", "اشتراک «${deck.name}»", "دوستات با این کد یه نسخه از دسته رو می‌گیرن")
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    code.forEachIndexed { i, ch ->
                        var on by remember { mutableStateOf(false) }
                        LaunchedEffect(Unit) { kotlinx.coroutines.delay(60L * i); on = true }
                        val s by animateFloatAsState(if (on) 1f else 0.3f, spring(dampingRatio = 0.45f, stiffness = 420f), label = "codeIn")
                        Box(
                            Modifier.weight(1f).aspectRatio(0.82f).graphicsLayer { scaleX = s; scaleY = s; alpha = s.coerceIn(0f, 1f) }
                                .clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(colors)),
                            contentAlignment = Alignment.Center,
                        ) { Text(ch.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace) }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(code)); AppSnack.show("کد کپی شد ✅") },
                    shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f).height(52.dp),
                ) {
                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("کپی کد", fontWeight = FontWeight.Bold)
                }
                FcPrimaryButton("ارسال برای دوستان", emoji = "💌", colors = colors, height = 52.dp, modifier = Modifier.weight(1.3f)) {
                    val text = "دستهٔ فلش‌کارت «${deck.name}» رو با کد $code در اپ استادینگ اضافه کن 📚"
                    runCatching {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
                    }
                }
            }
        }
    }
}

/** A tap target without the ripple, used by the small color and icon chips. */
@Composable
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    return this.clickable(interactionSource = source, indication = null, onClick = onClick)
}
