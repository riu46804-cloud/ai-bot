@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.flashcards

import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import ir.studying.app.core.Api
import ir.studying.app.core.EmojiText
import ir.studying.app.core.FlashcardLogic
import ir.studying.app.core.Flashcards
import ir.studying.app.core.Icon3D
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.SparkBurst
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/**
 * The review session.
 *
 * The card flips in 3D rather than cross fading because the flip is the moment
 * the user judges themselves, and a physical gesture makes that judgement feel
 * deliberate. Once the answer is visible the card can also be swiped away
 * (right good, left again, up easy) or graded with the buttons. Grades are
 * handed to Flashcards.review, which never blocks, so the next card, already
 * waiting in the stack behind, slides forward instantly even with no signal.
 */
private class Flying(val id: Int, val card: Flashcards.Card, val revealed: Boolean, val chosen: String?, val grade: Int, val from: Offset)

private data class GradeDef(val label: String, val emoji: String, val colors: List<Color>)

private val grades = listOf(
    GradeDef("دوباره", "😵", listOf(Color(0xFFFB7185), Color(0xFFE11D48))),
    GradeDef("سخت", "😓", listOf(Color(0xFFFBBF24), Color(0xFFF97316))),
    GradeDef("خوب", "🙂", listOf(Color(0xFF4ADE9F), Color(0xFF10B981))),
    GradeDef("آسان", "😎", listOf(Color(0xFF38BDF8), Color(0xFF2563EB))),
)

@Composable
fun ReviewScreen(deckId: Int, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val decks by Flashcards.decks.collectAsState()
    val deck = decks.firstOrNull { it.id == deckId }
    val colors = deckColors(deck?.color ?: "grape")
    var queue by remember { mutableStateOf<List<Flashcards.Card>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var startedAt by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var reviewed by remember { mutableIntStateOf(0) }
    var again by remember { mutableIntStateOf(0) }
    var combo by remember { mutableIntStateOf(0) }
    var bestCombo by remember { mutableIntStateOf(0) }
    var totalSecs by remember { mutableIntStateOf(0) }
    var loadKey by remember { mutableIntStateOf(0) }
    var serial by remember { mutableIntStateOf(0) }
    val flying = remember { mutableStateListOf<Flying>() }

    LaunchedEffect(deckId, loadKey) {
        loading = true
        error = null
        index = 0; reviewed = 0; again = 0; combo = 0; bestCombo = 0; totalSecs = 0
        flipped = false; chosen = null
        runCatching { Flashcards.due(deckId) }
            .onSuccess { queue = it }
            .onFailure { error = it.message ?: "دریافت کارت‌ها ناموفق بود" }
        loading = false
        startedAt = System.currentTimeMillis()
    }

    val card = queue.getOrNull(index)
    val done = !loading && error == null && card == null
    val revealed = if (card?.type == "mcq") chosen != null else flipped
    val suggestion = if (card?.type == "mcq" && chosen != null) {
        if (card.choices.any { it.first == chosen && it.second }) 2 else 0
    } else null

    fun grade(quality: Int, from: Offset = Offset.Zero) {
        val c = card ?: return
        val secs = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
        scope.launch { runCatching { Flashcards.review(c.id, quality, secs) } }
        haptic.performHapticFeedback(if (quality == 0) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
        totalSecs += secs.coerceIn(0, 600)
        reviewed++
        if (quality == 0) { again++; combo = 0 } else { combo++; bestCombo = max(bestCombo, combo) }
        flying.add(Flying(serial++, c, revealed, chosen, quality, from))
        flipped = false
        chosen = null
        startedAt = System.currentTimeMillis()
        if (quality == 0) {
            // A forgotten card goes to the back of today's queue instead of
            // disappearing, which is what makes a session actually finish
            // with everything remembered at least once.
            queue = queue.toMutableList().also { it.add(it.removeAt(index)) }
        } else {
            index++
        }
    }

    Box(Modifier.fillMaxSize()) {
        FcBackdrop(colors, Modifier.fillMaxSize(), strength = 0.8f)
        Column(Modifier.fillMaxSize()) {
            FcTopBar(
                title = deck?.name ?: "مرور همهٔ دسته‌ها",
                subtitle = when {
                    loading -> "در حال آماده‌سازی…"
                    queue.isEmpty() || done -> null
                    else -> "کارت ${(index + 1).coerceAtMost(queue.size).fa()} از ${queue.size.fa()}" +
                        if (again > 0) " • ${again.fa()} تکرار" else ""
                },
                onBack = onBack,
                backIcon = Icons.Rounded.Close,
            ) { ComboChip(combo) }

            if (!done && error == null) {
                val target = if (queue.isEmpty()) 0f else index.toFloat() / queue.size
                SessionProgress(target, colors, Modifier.padding(horizontal = 20.dp))
            }

            when {
                loading -> StackSkeleton(Modifier.weight(1f))
                error != null -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ErrorState(error!!, Modifier.padding(24.dp), onRetry = { loadKey++ })
                }
                done -> Box(Modifier.weight(1f).fillMaxWidth()) {
                    SessionSummary(reviewed, again, totalSecs, bestCombo, colors, onBack = onBack, onAgain = { loadKey++ })
                }
                else -> {
                    Box(
                        Modifier.weight(1f).fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 10.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        val stack = (0 until 3).mapNotNull { d -> queue.getOrNull(index + d)?.let { d to it } }
                            .distinctBy { it.second.id }
                            .reversed()
                        stack.forEach { (depth, c) ->
                            key(c.id) {
                                val d by animateFloatAsState(depth.toFloat(), spring(dampingRatio = 0.72f, stiffness = 320f), label = "stackDepth")
                                Box(
                                    Modifier.fillMaxSize().graphicsLayer {
                                        transformOrigin = TransformOrigin(0.5f, 0f)
                                        val s = 1f - 0.06f * d
                                        scaleX = s; scaleY = s
                                        translationY = -d * 14.dp.toPx()
                                        alpha = (1f - 0.18f * d).coerceIn(0f, 1f)
                                    },
                                ) {
                                    if (depth == 0) {
                                        ActiveCard(
                                            card = c,
                                            colors = colors,
                                            flipped = flipped,
                                            chosen = chosen,
                                            revealed = revealed,
                                            onChoose = { chosen = it },
                                            onFlip = { flipped = !flipped },
                                            onSwipe = { q, from -> grade(q, from) },
                                        )
                                    } else {
                                        CardFace(c, back = false, chosen = null, colors = colors, interactive = false, onChoose = {})
                                    }
                                }
                            }
                        }
                        flying.toList().forEach { f ->
                            key("fly${f.id}") { FlyingCard(f, colors) { flying.remove(f) } }
                        }
                    }
                    GradeBar(
                        revealed = revealed,
                        isMcq = card?.type == "mcq",
                        suggestion = suggestion,
                        colors = colors,
                        onGrade = { grade(it) },
                        onShow = { flipped = true },
                    )
                }
            }
        }
    }
}

/* ============================================================ chrome == */

@Composable
private fun ComboChip(combo: Int) {
    val pop = remember { Animatable(1f) }
    LaunchedEffect(combo) { if (combo >= 3) { pop.snapTo(1.35f); pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 500f)) } }
    androidx.compose.animation.AnimatedVisibility(
        combo >= 3,
        enter = scaleIn(spring(dampingRatio = 0.45f)) + fadeIn(),
        exit = scaleOut() + fadeOut(),
    ) {
        Row(
            Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }.clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFFF97316), Color(0xFFE11D48))))
                .padding(start = 6.dp, end = 10.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon3D("🔥", 18.dp)
            Spacer(Modifier.width(3.dp))
            Text("×${combo.fa()}", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun SessionProgress(target: Float, colors: List<Color>, modifier: Modifier) {
    val p by animateFloatAsState(target.coerceIn(0f, 1f), spring(dampingRatio = 0.8f, stiffness = 120f), label = "sessProg")
    val t = rememberInfiniteTransition(label = "sessGlow")
    val glow by t.animateFloat(0.4f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "sessGlowA")
    Box(modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(p.coerceAtLeast(0.02f)).clip(CircleShape).background(Brush.horizontalGradient(colors))) {
            Box(Modifier.align(Alignment.CenterEnd).padding(end = 2.dp).size(6.dp).clip(CircleShape).background(Color.White.copy(alpha = glow)))
        }
    }
}

/* ============================================================= cards == */

@Composable
private fun ActiveCard(
    card: Flashcards.Card,
    colors: List<Color>,
    flipped: Boolean,
    chosen: String?,
    revealed: Boolean,
    onChoose: (String) -> Unit,
    onFlip: () -> Unit,
    onSwipe: (Int, Offset) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val rot by animateFloatAsState(if (flipped) 180f else 0f, spring(dampingRatio = 0.7f, stiffness = 210f), label = "flip")
    val drag = remember(card.id) { Animatable(Offset.Zero, Offset.VectorConverter) }
    // a little bounce when the card becomes the front one
    val enter = remember(card.id) { Animatable(0.96f) }
    LaunchedEffect(card.id) { enter.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 400f)) }
    var w by remember { mutableFloatStateOf(1f) }
    var h by remember { mutableFloatStateOf(1f) }

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                w = size.width; h = size.height
                translationX = drag.value.x
                translationY = drag.value.y
                rotationZ = drag.value.x / size.width.coerceAtLeast(1f) * 14f
                scaleX = enter.value; scaleY = enter.value
            }
            .pointerInput(card.id, revealed) {
                if (!revealed) return@pointerInput
                detectDragGestures(
                    onDragEnd = {
                        val v = drag.value
                        val th = size.width * 0.28f
                        when {
                            v.x > th -> onSwipe(2, v)
                            v.x < -th -> onSwipe(0, v)
                            v.y < -size.height * 0.2f && abs(v.x) < th -> onSwipe(3, v)
                            else -> scope.launch { drag.animateTo(Offset.Zero, spring(dampingRatio = 0.55f, stiffness = 380f)) }
                        }
                    },
                    onDragCancel = { scope.launch { drag.animateTo(Offset.Zero, spring(dampingRatio = 0.55f)) } },
                ) { change, amount ->
                    change.consume()
                    scope.launch { drag.snapTo(drag.value + amount) }
                }
            },
    ) {
        if (card.type == "mcq") {
            CardFace(card, back = false, chosen = chosen, colors = colors, interactive = true, onChoose = onChoose)
        } else {
            Box(
                Modifier.fillMaxSize().graphicsLayer { rotationY = rot; cameraDistance = 16f * density }
                    .clickable(remember { MutableInteractionSource() }, indication = null) { onFlip() },
            ) {
                if (rot <= 90f) CardFace(card, back = false, chosen = null, colors = colors, interactive = true, onChoose = {})
                else Box(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }) {
                    CardFace(card, back = true, chosen = null, colors = colors, interactive = true, onChoose = {})
                }
                // glare sweeping across mid-flip
                val glare = sin(rot / 180f * PI.toFloat()).coerceIn(0f, 1f)
                if (glare > 0.02f) {
                    Box(Modifier.matchParentSize().clip(RoundedCornerShape(32.dp)).background(Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.45f * glare), Color.Transparent))))
                }
            }
        }
        SwipeStamp(drag.value, w, h)
    }
}

/** Grade stamp that fades in while the card is dragged. */
@Composable
private fun BoxScope.SwipeStamp(d: Offset, w: Float, h: Float) {
    val right = (d.x / (w * 0.28f)).coerceIn(0f, 1f)
    val left = (-d.x / (w * 0.28f)).coerceIn(0f, 1f)
    val up = if (abs(d.x) < w * 0.28f) (-d.y / (h * 0.2f)).coerceIn(0f, 1f) else 0f
    val (g, a) = when {
        right > 0.05f && right >= up -> grades[2] to right
        left > 0.05f && left >= up -> grades[0] to left
        up > 0.05f -> grades[3] to up
        else -> return
    }
    Box(Modifier.matchParentSize().clip(RoundedCornerShape(32.dp)).background(g.colors.last().copy(alpha = 0.16f * a)))
    Row(
        Modifier.align(Alignment.TopCenter).padding(top = 26.dp)
            .graphicsLayer { alpha = a; scaleX = 0.7f + 0.3f * a; scaleY = 0.7f + 0.3f * a; rotationZ = if (g == grades[2]) -10f else if (g == grades[0]) 10f else 0f }
            .clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(g.colors))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon3D(g.emoji, 28.dp)
        Spacer(Modifier.width(6.dp))
        Text(g.label, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun FlyingCard(f: Flying, colors: List<Color>, onEnd: () -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(f.id) { p.animateTo(1f, tween(430, easing = FastOutLinearInEasing)); onEnd() }
    val dir = when (f.grade) {
        0 -> Offset(-1f, 0.12f)
        1 -> Offset(0f, 1f)
        2 -> Offset(1f, 0.12f)
        else -> Offset(0.15f, -1f)
    }
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            val w = size.width
            val h = size.height
            translationX = f.from.x + dir.x * w * 1.5f * p.value
            translationY = f.from.y + dir.y * h * 1.3f * p.value
            rotationZ = f.from.x / w.coerceAtLeast(1f) * 14f + dir.x * 24f * p.value
            alpha = 1f - 0.5f * p.value
        },
    ) {
        val back = f.revealed && f.card.type != "mcq"
        CardFace(f.card, back = back, chosen = f.chosen, colors = colors, interactive = false, onChoose = {})
    }
}

@Composable
private fun CardFace(
    card: Flashcards.Card,
    back: Boolean,
    chosen: String?,
    colors: List<Color>,
    interactive: Boolean,
    onChoose: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(32.dp)
    val meta = typeMeta(card.type)
    val onBack = Color.White
    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { shadowElevation = 14.dp.toPx(); this.shape = shape; clip = true }
            .background(if (back) Brush.linearGradient(colors) else Brush.verticalGradient(listOf(cs.surface, cs.surface)))
            .border(1.dp, if (back) Color.White.copy(alpha = 0.3f) else colors.first().copy(alpha = 0.28f), shape),
    ) {
        if (!back) {
            Box(Modifier.fillMaxWidth().height(110.dp).background(Brush.verticalGradient(listOf(colors.first().copy(alpha = 0.14f), Color.Transparent))))
        }
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val chipTint = if (back) onBack else colors.last()
                Row(Modifier.clip(CircleShape).background(chipTint.copy(alpha = if (back) 0.2f else 0.12f)).padding(start = 5.dp, end = 10.dp, top = 3.dp, bottom = 3.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon3D(if (back) "💡" else meta.emoji, 18.dp)
                    Spacer(Modifier.width(4.dp))
                    Text(if (back) "پاسخ" else meta.label, color = chipTint, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.weight(1f))
                if (!back) {
                    val b = bucketMeta(card.bucket())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon3D(b.emoji, 16.dp)
                        Spacer(Modifier.width(3.dp))
                        Text(b.label, style = MaterialTheme.typography.labelSmall, color = b.color, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (back && card.type != "cloze" && card.front.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                EmojiText(card.front, color = onBack.copy(alpha = 0.75f), style = MaterialTheme.typography.bodyMedium, maxLines = 3,
                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, onBack.copy(alpha = 0.45f), Color.Transparent))))
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                if (!back && card.image.isNotBlank()) {
                    AsyncImage(
                        model = Api.mediaUrl(card.image), contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 190.dp).clip(RoundedCornerShape(22.dp)),
                    )
                    Spacer(Modifier.height(14.dp))
                }
                if (card.audio.isNotBlank()) {
                    AudioButton(Api.mediaUrl(card.audio), onDark = back, enabled = interactive)
                    Spacer(Modifier.height(14.dp))
                }
                when {
                    card.type == "cloze" -> {
                        val txt = buildAnnotatedString {
                            FlashcardLogic.clozeParts(card.front).forEach { (part, hiddenPart) ->
                                when {
                                    !hiddenPart -> append(part)
                                    back -> withStyle(SpanStyle(color = colors.last(), background = Color.White, fontWeight = FontWeight.Black)) { append(" $part ") }
                                    else -> withStyle(SpanStyle(color = Color.Transparent, background = colors.first().copy(alpha = 0.3f))) {
                                        append("\u00A0" + "\u2007".repeat(part.length.coerceIn(3, 12)) + "\u00A0")
                                    }
                                }
                            }
                        }
                        Text(txt, fontSize = if (card.front.length > 90) 18.sp else 23.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center, color = if (back) onBack else cs.onSurface)
                    }
                    back -> {
                        val answer = card.back.ifBlank { "—" }
                        EmojiText(answer, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, color = onBack,
                            style = MaterialTheme.typography.headlineSmall.copy(fontSize = if (answer.length > 90) 18.sp else 24.sp, lineHeight = 34.sp))
                    }
                    else -> {
                        val q = card.front.ifBlank { if (card.image.isNotBlank()) "این تصویر چیه؟" else "" }
                        if (q.isNotBlank()) EmojiText(q, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, color = cs.onSurface,
                            style = MaterialTheme.typography.headlineSmall.copy(fontSize = if (q.length > 90) 18.sp else 24.sp, lineHeight = 34.sp))
                    }
                }

                if (card.type == "mcq") {
                    Spacer(Modifier.height(16.dp))
                    McqChoices(card, chosen, colors, interactive, onChoose)
                    if (chosen != null && card.back.isNotBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(colors.first().copy(alpha = 0.12f)).padding(12.dp)) {
                            Icon3D("💡", 20.dp)
                            Spacer(Modifier.width(8.dp))
                            EmojiText(card.back, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                val note = when (card.type) {
                    "cloze" -> card.back
                    "mcq" -> ""
                    else -> card.extra
                }
                if (back && note.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.16f)).padding(12.dp)) {
                        EmojiText(note, color = onBack, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            if (card.type != "mcq") {
                if (!back) TapHint(colors.last()) else SwipeHint()
            }
        }
    }
}

@Composable
private fun TapHint(tint: Color) {
    val t = rememberInfiniteTransition(label = "tap")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "tapP")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon3D("👆", 22.dp, Modifier.graphicsLayer {
            val k = sin(p * 2f * PI.toFloat())
            translationY = k * 3.dp.toPx(); scaleX = 1f - 0.08f * k; scaleY = 1f - 0.08f * k
        })
        Spacer(Modifier.width(6.dp))
        Text("برای دیدن پاسخ ضربه بزن", style = MaterialTheme.typography.labelMedium, color = tint, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SwipeHint() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        // physical directions: drag left = again, right = good
        Text("→ خوب", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
        Text("↑ آسان", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
        Text("دوباره ←", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
    }
}

private val choiceLetters = listOf("الف", "ب", "ج", "د", "ه", "و")

@Composable
private fun McqChoices(card: Flashcards.Card, chosen: String?, colors: List<Color>, interactive: Boolean, onChoose: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        card.choices.forEachIndexed { i, (label, correct) ->
            val state = when {
                chosen == null -> 0
                correct -> 1
                chosen == label -> 2
                else -> 3
            }
            val green = Color(0xFF10B981)
            val red = Color(0xFFE11D48)
            val bg by animateColorAsState(
                when (state) { 1 -> green.copy(alpha = 0.16f); 2 -> red.copy(alpha = 0.14f); else -> cs.surfaceVariant.copy(alpha = 0.55f) },
                tween(260), label = "mcqBg",
            )
            val border by animateColorAsState(
                when (state) { 1 -> green; 2 -> red; else -> cs.outlineVariant.copy(alpha = 0.5f) }, tween(260), label = "mcqBorder",
            )
            val shake = remember { Animatable(0f) }
            val pop = remember { Animatable(1f) }
            LaunchedEffect(state) {
                if (state == 2) shake.animateTo(0f, keyframes {
                    durationMillis = 420
                    -14f at 60; 12f at 130; -9f at 200; 6f at 270; -3f at 340
                })
                if (state == 1) { pop.snapTo(1.06f); pop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = 500f)) }
            }
            Box {
                Row(
                    Modifier.fillMaxWidth()
                        .graphicsLayer { translationX = shake.value.dp.toPx(); scaleX = pop.value; scaleY = pop.value; alpha = if (state == 3) 0.55f else 1f }
                        .clip(RoundedCornerShape(18.dp)).background(bg)
                        .border(if (state == 1 || state == 2) 2.dp else 1.dp, border, RoundedCornerShape(18.dp))
                        .clickable(enabled = interactive && chosen == null) { onChoose(label) }
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(30.dp).clip(CircleShape).background(
                        when (state) { 1 -> green; 2 -> red; else -> colors.last().copy(alpha = 0.14f) }), contentAlignment = Alignment.Center) {
                        when (state) {
                            1 -> Icon3D("✅", 22.dp)
                            2 -> Icon3D("❌", 20.dp)
                            else -> Text(choiceLetters.getOrElse(i) { (i + 1).fa() }, style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Black, color = colors.last())
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    EmojiText(label, style = MaterialTheme.typography.bodyLarge, fontWeight = if (state == 1) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f))
                }
                if (state == 1) SparkBurst(chosen, "✨", Modifier.matchParentSize())
            }
        }
    }
}

@Composable
private fun AudioButton(url: String?, onDark: Boolean, enabled: Boolean) {
    if (url.isNullOrBlank()) return
    val ctx = LocalContext.current
    var playing by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(url) {
        onDispose { runCatching { player?.reset(); player?.release() }; player = null }
    }
    val tint = if (onDark) Color.White else MaterialTheme.colorScheme.primary
    val t = rememberInfiniteTransition(label = "eq")
    val eq by t.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing)), label = "eqP")
    Row(
        Modifier.clip(CircleShape).background(tint.copy(alpha = if (onDark) 0.2f else 0.1f))
            .clickable(enabled = enabled) {
                if (playing) {
                    runCatching { player?.pause() }
                    playing = false
                } else {
                    runCatching {
                        val p = player ?: MediaPlayer().also { mp ->
                            mp.setDataSource(ctx, Uri.parse(url))
                            mp.prepare()
                            mp.setOnCompletionListener { playing = false }
                            player = mp
                        }
                        p.start()
                        playing = true
                    }.onFailure { AppSnack.show("پخش صدا ناموفق بود") }
                }
            }
            .padding(start = 8.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon3D(if (playing) "🔊" else "🔈", 24.dp)
        Spacer(Modifier.width(6.dp))
        if (playing) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(4) { i ->
                    val k = (sin((eq + i * 0.23f) * 2f * PI.toFloat()) + 1f) / 2f
                    Box(Modifier.width(3.dp).height((6 + 10 * k).dp).clip(CircleShape).background(tint))
                }
            }
            Spacer(Modifier.width(6.dp))
        }
        Text(if (playing) "در حال پخش" else "پخش صدا", color = tint, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun StackSkeleton(modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "stSk")
    val a by t.animateFloat(0.4f, 0.9f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "stSkA")
    Box(modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 96.dp), contentAlignment = Alignment.Center) {
        for (d in 2 downTo 0) {
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    transformOrigin = TransformOrigin(0.5f, 0f)
                    val s = 1f - 0.06f * d; scaleX = s; scaleY = s
                    translationY = -d * 14.dp.toPx()
                    alpha = a * (1f - 0.25f * d)
                }.clip(RoundedCornerShape(32.dp)).background(cs.surfaceVariant),
            )
        }
        AnimatedEmoji("🃏", 72.dp, idle = true, repeatEveryMs = 1600, burst = false)
    }
}

/* ============================================================ grading == */

@Composable
private fun GradeBar(
    revealed: Boolean,
    isMcq: Boolean,
    suggestion: Int?,
    colors: List<Color>,
    onGrade: (Int) -> Unit,
    onShow: () -> Unit,
) {
    AnimatedContent(
        targetState = revealed,
        transitionSpec = {
            (slideInVertically(spring(dampingRatio = 0.75f, stiffness = 420f)) { it / 2 } + fadeIn(tween(200)))
                .togetherWith(slideOutVertically(tween(160)) { it / 2 } + fadeOut(tween(120)))
        },
        label = "grades",
    ) { show ->
        if (!show) {
            Box(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 18.dp), contentAlignment = Alignment.Center) {
                if (isMcq) {
                    Row(
                        Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)).padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon3D("🤔", 22.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("یکی از گزینه‌ها رو انتخاب کن", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                } else {
                    FcPrimaryButton("نمایش پاسخ", emoji = "👀", colors = colors, height = 58.dp, modifier = Modifier.fillMaxWidth(), onClick = onShow)
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                grades.forEachIndexed { q, g ->
                    GradeButton(g, index = q, highlighted = suggestion == q, modifier = Modifier.weight(1f)) { onGrade(q) }
                }
            }
        }
    }
}

@Composable
private fun GradeButton(g: GradeDef, index: Int, highlighted: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val inter = remember { MutableInteractionSource() }
    val s = pressScale(inter, 0.9f)
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(index * 45L); appear.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 420f)) }
    val t = rememberInfiniteTransition(label = "gradeHi")
    val ring by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "gradeRing")
    Box(
        modifier
            .height(74.dp)
            .graphicsLayer {
                val a = appear.value
                scaleX = s * (0.6f + 0.4f * a); scaleY = s * (0.6f + 0.4f * a)
                alpha = a.coerceIn(0f, 1f)
                translationY = (1f - a) * 24.dp.toPx()
            }
            .graphicsLayer { shadowElevation = 6.dp.toPx(); shape = RoundedCornerShape(22.dp); clip = true }
            .background(Brush.linearGradient(g.colors))
            .then(if (highlighted) Modifier.border((2 + 2 * ring).dp, Color.White.copy(alpha = 0.6f + 0.4f * ring), RoundedCornerShape(22.dp)) else Modifier)
            .clickable(inter, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon3D(g.emoji, 28.dp)
            Spacer(Modifier.height(3.dp))
            Text(g.label, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelLarge)
        }
    }
}

/* ============================================================ summary == */

@Composable
private fun SessionSummary(
    reviewed: Int,
    again: Int,
    seconds: Int,
    bestCombo: Int,
    colors: List<Color>,
    onBack: () -> Unit,
    onAgain: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize()) {
        if (reviewed > 0) ConfettiLayer(reviewed, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            if (reviewed == 0) {
                AnimatedEmoji("🎉", 120.dp, autoPlay = true, idle = true, repeatEveryMs = 3200)
                Spacer(Modifier.height(14.dp))
                Text("کارتی برای مرور نمانده", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(6.dp))
                Text("همه‌چیز سر جاشه؛ فردا برگرد یا کارت تازه بساز", color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                Spacer(Modifier.height(22.dp))
                FcPrimaryButton("بازگشت", emoji = "🏠", colors = colors, modifier = Modifier.fillMaxWidth(0.7f), onClick = onBack)
            } else {
                val accuracy = FlashcardLogic.accuracy(reviewed, again)
                AnimatedEmoji(if (accuracy >= 80) "🏆" else "💪", 110.dp, autoPlay = true, idle = true, repeatEveryMs = 3400)
                Spacer(Modifier.height(10.dp))
                Text(if (accuracy >= 80) "آفرین! جلسه تموم شد" else "جلسه تموم شد؛ داری قوی‌تر می‌شی", style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                EmojiText(
                    if (again == 0) "بدون حتی یک فراموشی؛ عالی بود ✨" else "${again.fa()} بار کارت‌ها رو دوباره دیدی تا خوب بمونن تو ذهنت",
                    color = cs.onSurfaceVariant, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(20.dp))
                ProgressRing(accuracy / 100f, 150.dp, 14.dp, colors, track = colors.first().copy(alpha = 0.15f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        ir.studying.app.ui.components.CountUpText(accuracy, MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black), suffix = "٪")
                        Text("دقت یادآوری", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryTile("🃏", reviewed.fa(), "مرور", 0, Modifier.weight(1f))
                    SummaryTile("⏱️", if (seconds < 60) "${seconds.fa()} ثانیه" else "${(seconds / 60).fa()} دقیقه", "زمان", 1, Modifier.weight(1f))
                    SummaryTile("🔥", bestCombo.fa(), "بهترین زنجیره", 2, Modifier.weight(1f))
                }
                Spacer(Modifier.height(24.dp))
                FcPrimaryButton("بازگشت", emoji = "🏠", colors = colors, modifier = Modifier.fillMaxWidth(), onClick = onBack)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onAgain) { Text("دور بعدی مرور", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun SummaryTile(emoji: String, value: String, label: String, index: Int, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(250L + index * 110L); a.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 380f)) }
    Surface(
        shape = RoundedCornerShape(20.dp), color = cs.surface, shadowElevation = 2.dp,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.4f)),
        modifier = modifier.graphicsLayer { scaleX = 0.5f + 0.5f * a.value; scaleY = 0.5f + 0.5f * a.value; alpha = a.value.coerceIn(0f, 1f) },
    ) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon3D(emoji, 28.dp)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
