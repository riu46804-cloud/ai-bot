package ir.studying.app.ui.focus

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.InstalledApps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * صفحهٔ انتخاب اپ‌های قفل‌شدنی.
 *
 * نسخهٔ قبلی یک دیالوگ لیستِ متنی بود و دقیقاً همین پاره «ابتدایی» بود. اینجا:
 * آیکن واقعی اپ، جستجو، مرتب‌سازی بر اساس مصرف ۷ روز گذشته، انتخاب گروهی
 * و پیشنهاد هوشمند.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppPickerScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cfg by FocusLock.config.collectAsState()
    var all by remember { mutableStateOf<List<InstalledApps.Entry>?>(null) }
    var q by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        all = withContext(Dispatchers.IO) { InstalledApps.list(ctx, withIcons = true) }
    }

    val list = remember(all, q) {
        val src = all ?: emptyList()
        if (q.isBlank()) src
        else src.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("اپ‌های قفل‌شدنی") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowForward, contentDescription = "بازگشت")
                    }
                },
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                label = { Text("جستجوی اپ") },
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AssistChip(
                    onClick = {
                        val s = InstalledApps.suggest(all ?: emptyList())
                        FocusLock.updateConfig { it.copy(blocked = it.blocked + s, blockApps = true) }
                    },
                    label = { Text("پیشنهاد هوشمند") },
                )
                AssistChip(
                    onClick = {
                        val all2 = (all ?: emptyList()).map { it.pkg }.toSet()
                        FocusLock.updateConfig { it.copy(blocked = all2, blockApps = true) }
                    },
                    label = { Text("همه") },
                )
                AssistChip(
                    onClick = { FocusLock.updateConfig { it.copy(blocked = emptySet()) } },
                    label = { Text("هیچ‌کدام") },
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                (cfg.blocked.size.toString() + " اپ انتخاب شده").fa(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Spacer(Modifier.height(8.dp))

            if (all == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.pkg }) { e ->
                        val checked = cfg.blocked.contains(e.pkg)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    FocusLock.updateConfig { c ->
                                        val next = if (checked) c.blocked - e.pkg else c.blocked + e.pkg
                                        c.copy(blocked = next, blockApps = next.isNotEmpty() || c.blockApps)
                                    }
                                }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(e)
                            Spacer(Modifier.size(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    e.label,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium,
                                )
                                Text(
                                    if (e.weekMinutes > 0)
                                        ("این هفته: " + usageLabel(e.weekMinutes)).fa()
                                    else e.pkg,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Checkbox(checked = checked, onCheckedChange = null)
                        }
                    }
                }
            }
        }
    }
}

private fun usageLabel(minutes: Int): String =
    if (minutes >= 60) (minutes / 60).toString() + " ساعت و " + (minutes % 60).toString() + " دقیقه"
    else minutes.toString() + " دقیقه"

/** آیکن واقعی اپ؛ Drawable را یک بار به بیت‌مپ تبدیل می‌کنیم تا اسکرول نلغزد. */
@Composable
private fun AppIcon(e: InstalledApps.Entry) {
    val bmp = remember(e.pkg) {
        try { e.icon?.toBitmap(96, 96)?.asImageBitmap() } catch (_: Exception) { null }
    }
    Box(
        Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            androidx.compose.foundation.Image(
                bitmap = bmp,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
            )
        } else {
            Text(e.label.take(1), style = MaterialTheme.typography.titleMedium)
        }
    }
}
