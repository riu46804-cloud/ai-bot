package ir.studying.app.ui.focus

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.focus.FocusMode
import ir.studying.app.ui.components.AuroraBackdrop
import ir.studying.app.ui.components.StarField
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.shine
import kotlin.math.cos
import kotlin.math.sin

/**
 * زبان بصری بخش قفل — نسخهٔ ۲.۹: «گاوصندوق».
 *
 * چرا جدا شد: پیش از این، هر جا حالت قفل انتخاب می‌شد (تنظیمات، دیالوگ شروع،
 * چالش) شکل دیگری داشت. حالا همه از همین قطعه‌ها استفاده می‌کنند: رنگ دوتایی هر
 * حالت، قفلِ متحرکی که واقعاً بسته و باز می‌شود، صفحهٔ مدرج گاوصندوق برای شمارش
 * معکوس و دکمه‌های درخشان/شیشه‌ای. هر چیزی که «قفل» است، یک شکل دارد.
 */

/* ------------------------------ رنگ‌ها ------------------------------ */

/** رنگ اختصاصی هر حالت — از ملایم به تند، هم‌راستا با شدت قفل. */
fun focusModeColor(mode: FocusMode): Color = when (mode) {
    FocusMode.APPS -> Color(0xFF38BDF8)
    FocusMode.ALL_BUT_CALLS -> Color(0xFFFB923C)
    FocusMode.TOTAL -> Color(0xFFF43F5E)
}

/** رنگ دوم هر حالت؛ دو سرِ گرادیانِ همهٔ سطح‌های قفل. */
fun focusModeColor2(mode: FocusMode): Color = when (mode) {
    FocusMode.APPS -> Color(0xFF818CF8)
    FocusMode.ALL_BUT_CALLS -> Color(0xFFF472B6)
    FocusMode.TOTAL -> Color(0xFFA855F7)
}

/** گرادیان نرمِ پشت کارتِ انتخاب‌شده. */
fun focusModeBrush(mode: FocusMode, alpha: Float = 0.16f): Brush =
    Brush.horizontalGradient(
        listOf(focusModeColor(mode).copy(alpha = alpha), focusModeColor2(mode).copy(alpha = alpha * 0.35f)),
    )

/** رنگ‌های استراحت: گرم و آرام، تا با نگاه معلوم باشد قفل موقتاً برداشته شده. */
internal val BreakA = Color(0xFFFBBF24)
internal val BreakB = Color(0xFFFB7185)

/** زمینهٔ تیرهٔ گاوصندوق. */
internal val VaultTop = Color(0xFF060914)
internal val VaultMid = Color(0xFF0C1124)
internal val VaultBottom = Color(0xFF141A36)

/** سبز «ماندن»: برای دکمه‌هایی که کاربر را سر درس نگه می‌دارند. */
internal val StayA = Color(0xFF34D399)
internal val StayB = Color(0xFF22D3EE)

/* ------------------------------ زمینه ------------------------------ */

/** آسمان تیرهٔ گاوصندوق با شفقِ رنگِ حالت و ستاره‌های کم‌نور. */
@Composable
fun VaultBackdrop(accent: Color, accent2: Color, modifier: Modifier = Modifier, stars: Int = 34, seed: Int = 5) {
    // لکه‌های شفق عمداً بزرگ‌تر از قاب‌اند؛ بدون برش، روی محتوای زیر سربرگ هم می‌ریختند.
    Box(modifier.clipToBounds()) {
        AuroraBackdrop(
            Modifier.matchParentSize(),
            base = listOf(VaultTop, VaultMid, VaultBottom),
            blobs = listOf(accent.copy(alpha = 0.30f), accent2.copy(alpha = 0.24f), Color(0xFF22D3EE).copy(alpha = 0.06f)),
            periodMs = 18000,
        )
        if (stars > 0) StarField(Modifier.matchParentSize(), count = stars, seed = seed, maxAlpha = 0.6f)
    }
}

/** قاب کارت‌های تیرهٔ قفل: گوشه‌گرد، سایه‌دار، با لبهٔ گرادیانی. */
@Composable
internal fun VaultCard(
    accent: Color,
    accent2: Color,
    modifier: Modifier = Modifier,
    corner: Dp = 30.dp,
    stars: Int = 34,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.shape = shape
                clip = true
                shadowElevation = 10.dp.toPx()
            }
            .border(
                1.dp,
                Brush.linearGradient(listOf(accent.copy(alpha = 0.55f), Color.White.copy(alpha = 0.06f), accent2.copy(alpha = 0.45f))),
                shape,
            ),
    ) {
        VaultBackdrop(accent, accent2, Modifier.matchParentSize(), stars = stars)
        content()
    }
}

/* ------------------------------ قفلِ متحرک ------------------------------ */

/**
 * قفلِ آویزِ کشیده‌شده با Canvas.
 *
 * [open] از ۰ (بسته) تا ۱ (باز): کمانِ قفل بالا می‌آید و حول پایهٔ راستش
 * می‌چرخد. با [animate] تغییرِ حالت با فنر انجام می‌شود (کمی جهش در لحظهٔ
 * بسته شدن، مثل «کلیک» واقعی)؛ برای انیمیشن‌های فریم‌به‌فریم خاموشش کن.
 * سوراخ کلید در حالت بسته آرام نفس می‌کشد و یک برق نوری از روی بدنه رد می‌شود.
 */
@Composable
fun AnimatedPadlock(
    open: Float,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    colors: List<Color> = listOf(Color(0xFFFDE68A), Color(0xFFF59E0B), Color(0xFFD97706)),
    shackle: List<Color> = listOf(Color.White, Color(0xFFCBD5E1), Color(0xFF94A3B8)),
    glow: Color = colors.last(),
    animate: Boolean = true,
) {
    val sprung by animateFloatAsState(
        open.coerceIn(0f, 1f),
        spring(dampingRatio = 0.42f, stiffness = 300f),
        label = "padlockOpen",
    )
    val o = if (animate) sprung else open.coerceIn(0f, 1f)
    val t = rememberInfiniteTransition(label = "padlock")
    val glint by t.animateFloat(
        -0.7f, 1.7f,
        infiniteRepeatable(tween(2600, delayMillis = 1500, easing = FastOutSlowInEasing)),
        label = "padlockGlint",
    )
    val breathe by t.animateFloat(
        0.45f, 1f,
        infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "padlockBreathe",
    )
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val bodyW = w * 0.76f
        val bodyH = h * 0.50f
        val bodyLeft = (w - bodyW) / 2f
        val bodyTop = h * 0.44f
        val sw = w * 0.12f
        val shW = bodyW * 0.60f
        val shLeft = (w - shW) / 2f
        val shRight = shLeft + shW
        val legBottom = bodyTop + sw
        val arcTop = h * 0.10f
        val bodyCenter = Offset(w / 2f, bodyTop + bodyH / 2f)

        // هالهٔ پشت قفل
        drawCircle(
            Brush.radialGradient(
                listOf(glow.copy(alpha = 0.40f * breathe * (1f - 0.5f * o)), Color.Transparent),
                center = bodyCenter,
                radius = w * 0.62f,
            ),
            radius = w * 0.62f,
            center = bodyCenter,
        )

        // کمان قفل
        withTransform({
            translate(top = -o * h * 0.13f)
            rotate(-o * 32f, Offset(shRight, legBottom))
        }) {
            val path = Path().apply {
                moveTo(shLeft, legBottom)
                lineTo(shLeft, arcTop + shW / 2f)
                arcTo(Rect(shLeft, arcTop, shRight, arcTop + shW), 180f, 180f, false)
                lineTo(shRight, legBottom)
            }
            drawPath(
                path,
                Brush.horizontalGradient(shackle, startX = shLeft - sw, endX = shRight + sw),
                style = Stroke(sw, cap = StrokeCap.Round),
            )
            drawPath(
                path,
                Color.White.copy(alpha = 0.35f),
                style = Stroke(sw * 0.22f, cap = StrokeCap.Round),
            )
        }

        // بدنه
        val corner = CornerRadius(bodyW * 0.22f)
        val bodyPath = Path().apply {
            addRoundRect(androidx.compose.ui.geometry.RoundRect(bodyLeft, bodyTop, bodyLeft + bodyW, bodyTop + bodyH, corner))
        }
        drawPath(bodyPath, Brush.verticalGradient(colors, startY = bodyTop, endY = bodyTop + bodyH))
        clipPath(bodyPath) {
            // براقیِ نیمهٔ بالا
            drawRoundRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0f)),
                    startY = bodyTop,
                    endY = bodyTop + bodyH * 0.55f,
                ),
                topLeft = Offset(bodyLeft + bodyW * 0.07f, bodyTop + bodyH * 0.07f),
                size = Size(bodyW * 0.86f, bodyH * 0.40f),
                cornerRadius = CornerRadius(bodyW * 0.16f),
            )
            // برق رونده
            val band = bodyW * 0.35f
            val x = bodyLeft + glint * (bodyW + band) - band
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.50f), Color.Transparent),
                    start = Offset(x, bodyTop),
                    end = Offset(x + band, bodyTop + bodyH),
                ),
                topLeft = Offset(bodyLeft, bodyTop),
                size = Size(bodyW, bodyH),
            )
            // سایهٔ پایین بدنه
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.22f)),
                    startY = bodyTop + bodyH * 0.6f,
                    endY = bodyTop + bodyH,
                ),
                topLeft = Offset(bodyLeft, bodyTop),
                size = Size(bodyW, bodyH),
            )
        }

        // سوراخ کلید
        val kc = Offset(w / 2f, bodyTop + bodyH * 0.42f)
        val kr = bodyW * 0.095f
        val keyColor = Color(0xFF111827).copy(alpha = 0.82f)
        drawCircle(keyColor, kr, kc)
        val slot = Path().apply {
            moveTo(kc.x - kr * 0.45f, kc.y)
            lineTo(kc.x + kr * 0.45f, kc.y)
            lineTo(kc.x + kr * 0.75f, kc.y + kr * 2.5f)
            lineTo(kc.x - kr * 0.75f, kc.y + kr * 2.5f)
            close()
        }
        drawPath(slot, keyColor)
        drawCircle(glow.copy(alpha = 0.85f * breathe * (1f - o)), kr * 0.42f, kc)
    }
}

/* ------------------------------ صفحهٔ مدرج ------------------------------ */

/**
 * صفحهٔ مدرجِ گاوصندوق برای شمارش معکوس.
 *
 * سه لایه: قاب بیرونیِ خط‌چینی که آرام می‌چرخد، ۶۰ درجه که به اندازهٔ پیشرفت
 * روشن می‌شوند (مثل ثانیه‌شمار) و حلقهٔ پیشرفتِ درخشان با سرِ نورانی. وسطش یک
 * دیسک شیشه‌ای است برای [content].
 */
@Composable
fun VaultDial(
    progress: Float,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    ticks: Int = 60,
    content: @Composable BoxScope.() -> Unit,
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "dialP")
    val t = rememberInfiniteTransition(label = "dial")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(48000, easing = LinearEasing)), label = "dialSpin")
    val breathe by t.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dialBreathe",
    )
    val c1 = colors.first()
    val c2 = colors.last()
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val ctr = center
            val r = size.minDimension / 2f

            drawCircle(
                Brush.radialGradient(listOf(c1.copy(alpha = 0.22f * breathe), Color.Transparent), center = ctr, radius = r),
                radius = r,
                center = ctr,
            )

            // قاب چرخان
            rotate(spin, ctr) {
                drawCircle(
                    Color.White.copy(alpha = 0.16f),
                    r * 0.975f,
                    ctr,
                    style = Stroke(
                        1.2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.dp.toPx(), 7.dp.toPx())),
                    ),
                )
                for (k in 0 until 4) {
                    val a = Math.toRadians(k * 90.0)
                    drawCircle(
                        c2.copy(alpha = 0.85f),
                        2.3.dp.toPx(),
                        Offset(ctr.x + r * 0.975f * cos(a).toFloat(), ctr.y + r * 0.975f * sin(a).toFloat()),
                    )
                }
            }

            // درجه‌ها
            for (i in 0 until ticks) {
                val f = i.toFloat() / ticks
                val a = Math.toRadians((f * 360f - 90f).toDouble())
                val long = i % 5 == 0
                val r1 = r * 0.83f
                val r2 = r * (if (long) 0.92f else 0.885f)
                val lit = f < p || p >= 0.999f
                val col = if (lit) lerp(c1, c2, f) else Color.White.copy(alpha = if (long) 0.28f else 0.14f)
                val cs = cos(a).toFloat()
                val sn = sin(a).toFloat()
                drawLine(
                    col,
                    Offset(ctr.x + r1 * cs, ctr.y + r1 * sn),
                    Offset(ctr.x + r2 * cs, ctr.y + r2 * sn),
                    (if (long) 2.6f else 1.5f) * density,
                    StrokeCap.Round,
                )
            }

            // حلقهٔ پیشرفت
            val sw = 7.dp.toPx()
            val rr = r * 0.74f
            val tl = Offset(ctr.x - rr, ctr.y - rr)
            val arc = Size(rr * 2f, rr * 2f)
            drawCircle(Color.White.copy(alpha = 0.09f), rr, ctr, style = Stroke(sw))
            val sweep = 360f * p
            if (sweep > 0.5f) {
                rotate(-90f, ctr) {
                    val brush = Brush.sweepGradient(
                        colorStops = arrayOf(0f to c1, p.coerceAtLeast(0.01f) to c2),
                        center = ctr,
                    )
                    drawArc(
                        c2.copy(alpha = 0.22f * breathe), 0f, sweep, false, tl, arc,
                        style = Stroke(sw * 2.6f, cap = StrokeCap.Round),
                    )
                    drawArc(brush, 0f, sweep, false, tl, arc, style = Stroke(sw, cap = StrokeCap.Round))
                    drawCircle(c1, sw / 2f, Offset(ctr.x + rr, ctr.y))
                    val ha = Math.toRadians(sweep.toDouble())
                    val head = Offset(ctr.x + rr * cos(ha).toFloat(), ctr.y + rr * sin(ha).toFloat())
                    drawCircle(
                        Brush.radialGradient(listOf(c2.copy(alpha = 0.6f * breathe), Color.Transparent), center = head, radius = sw * 2.6f),
                        radius = sw * 2.6f,
                        center = head,
                    )
                    drawCircle(Color.White, sw * 0.34f, head)
                }
            }

            // دیسک شیشه‌ای
            val rd = r * 0.63f
            drawCircle(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.11f), Color.White.copy(alpha = 0.02f)),
                    center = Offset(ctr.x, ctr.y - rd * 0.35f),
                    radius = rd * 1.3f,
                ),
                radius = rd,
                center = ctr,
            )
            drawCircle(Color.White.copy(alpha = 0.10f), rd, ctr, style = Stroke(1.dp.toPx()))
        }
        content()
    }
}

/* ------------------------------ دکمه‌ها و برچسب‌ها ------------------------------ */

/** دکمهٔ اصلیِ گرادیانی با برق رونده و فشردگی فنری. */
@Composable
fun FocusGlowButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    colors: List<Color>,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    height: Dp = 52.dp,
) {
    Row(
        modifier
            .bouncyClick(enabled = enabled, onClick = onClick)
            .graphicsLayer { alpha = if (enabled) 1f else 0.42f }
            .height(height)
            .clip(CircleShape)
            .background(Brush.horizontalGradient(colors))
            .shine(enabled)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** دکمهٔ شیشه‌ای برای کارهای فرعی روی زمینهٔ تیره. */
@Composable
fun FocusGlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    tint: Color = Color.White,
    enabled: Boolean = true,
    height: Dp = 48.dp,
) {
    Row(
        modifier
            .bouncyClick(enabled = enabled, onClick = onClick)
            .graphicsLayer { alpha = if (enabled) 1f else 0.42f }
            .height(height)
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.10f))
            .border(1.dp, tint.copy(alpha = 0.24f), CircleShape)
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
        }
        Text(text, color = tint, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * کاشی عمودیِ عمل (آیکن بالا، برچسب پایین) — سه‌تایش در یک ردیف هم جا می‌شود
 * بدون این‌که برچسب‌ها بریده شوند. با [colors] گرادیانی و پررنگ می‌شود.
 */
@Composable
fun FocusActionTile(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    colors: List<Color>? = null,
) {
    val shape = RoundedCornerShape(20.dp)
    val fg = if (colors != null) Color.White else tint
    Column(
        modifier
            .bouncyClick(pressedScale = 0.93f, onClick = onClick)
            .height(66.dp)
            .clip(shape)
            .then(
                if (colors != null) Modifier.background(Brush.horizontalGradient(colors)).shine()
                else Modifier.background(tint.copy(alpha = 0.10f)).border(1.dp, tint.copy(alpha = 0.22f), shape),
            )
            .padding(horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** نقطهٔ زنده با موج — نشانهٔ «در جریان است». */
@Composable
internal fun PulseDot(color: Color, modifier: Modifier = Modifier, dot: Dp = 8.dp) {
    val t = rememberInfiniteTransition(label = "pulseDot")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "pulseDotP")
    Canvas(modifier.size(dot * 2.4f)) {
        val r = dot.toPx() / 2f
        val max = size.minDimension / 2f
        drawCircle(color.copy(alpha = (1f - p) * 0.55f), r + (max - r) * p)
        drawCircle(color, r)
    }
}

/** کاشی آماری شیشه‌ای روی زمینهٔ تیره. */
@Composable
internal fun GlassStat(value: String, label: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
            .padding(vertical = 9.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = valueColor, fontWeight = FontWeight.Black, fontSize = 16.sp, maxLines = 1)
        Text(label, color = Color.White.copy(alpha = 0.62f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** سه میلهٔ شدت؛ پرشده به اندازهٔ [FocusMode.order]، با پرشدنِ پلکانی. */
@Composable
fun FocusIntensityBars(mode: FocusMode, modifier: Modifier = Modifier, track: Color = Color.Unspecified) {
    val c1 = focusModeColor(mode)
    val c2 = focusModeColor2(mode)
    val off = if (track == Color.Unspecified) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.18f) else track
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        for (i in 1..3) {
            val on by animateFloatAsState(
                if (i <= mode.order) 1f else 0f,
                tween(280, delayMillis = i * 70),
                label = "bar$i",
            )
            Box(
                Modifier
                    .width(5.dp)
                    .height((6 + i * 4).dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(off),
                contentAlignment = Alignment.BottomCenter,
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(on)
                        .background(Brush.verticalGradient(listOf(c2, c1))),
                )
            }
        }
    }
}

/** چیپ کوچک اطلاعاتی — برای «چه چیزی باز می‌ماند» و «چه دسترسی لازم است». */
@Composable
fun FocusInfoChip(
    text: String,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    warn: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier
            .clip(shape)
            .background(tint.copy(alpha = if (warn) 0.14f else 0.09f))
            .border(1.dp, tint.copy(alpha = 0.20f), shape)
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (warn) {
            Icon(Icons.Rounded.WarningAmber, null, tint = tint, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}

/* ------------------------------ کارت حالت ------------------------------ */

/**
 * کارت یک حالت قفل.
 *
 * [missing] لیست دسترسی‌های نداشته است؛ اگر خالی نباشد کارت یک هشدار نرم نشان
 * می‌دهد ولی همچنان قابل انتخاب می‌ماند — بستنِ راهِ انتخاب باعث می‌شد کاربر
 * نفهمد چرا حالت دلخواهش در دسترس نیست.
 *
 * انتخاب شدن با فنر دیده می‌شود: نشانِ ایموجی پر از گرادیانِ حالت می‌شود،
 * لبهٔ کارت رنگی می‌شود و تیکِ تأیید با جهش ظاهر می‌شود.
 */
@Composable
fun FocusModeCard(
    mode: FocusMode,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    missing: List<String> = emptyList(),
    compact: Boolean = false,
) {
    val cs = MaterialTheme.colorScheme
    val c1 = focusModeColor(mode)
    val c2 = focusModeColor2(mode)
    val k by animateFloatAsState(
        if (selected) 1f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "modeSel",
    )
    val shape = RoundedCornerShape(20.dp)

    Box(
        modifier
            .fillMaxWidth()
            .bouncyClick(pressedScale = 0.97f, onClick = onClick)
            .clip(shape)
            .background(cs.surfaceVariant.copy(alpha = 0.55f))
            .background(
                Brush.linearGradient(
                    listOf(c1.copy(alpha = 0.22f * k.coerceIn(0f, 1f)), c2.copy(alpha = 0.08f * k.coerceIn(0f, 1f))),
                ),
            )
            .border(
                if (selected) 1.5.dp else 1.dp,
                if (selected) Brush.linearGradient(listOf(c1, c2)) else SolidColor(cs.outlineVariant.copy(alpha = 0.7f)),
                shape,
            )
            .padding(horizontal = 14.dp, vertical = if (compact) 10.dp else 13.dp),
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(if (compact) 40.dp else 46.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    c1.copy(alpha = (0.16f + 0.84f * k).coerceIn(0f, 1f)),
                                    c2.copy(alpha = (0.10f + 0.90f * k).coerceIn(0f, 1f)),
                                ),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        mode.emoji,
                        fontSize = if (compact) 19.sp else 22.sp,
                        modifier = Modifier.graphicsLayer {
                            val s = 1f + 0.10f * k
                            scaleX = s
                            scaleY = s
                        },
                    )
                }

                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        mode.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    )
                    Text(
                        mode.blurb,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }

                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
                        if (k > 0.02f) {
                            Box(
                                Modifier
                                    .size(24.dp)
                                    .graphicsLayer {
                                        scaleX = k
                                        scaleY = k
                                        alpha = k.coerceIn(0f, 1f)
                                    }
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(c1, c2))),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(15.dp)) }
                        } else {
                            Box(
                                Modifier
                                    .size(22.dp)
                                    .border(1.5.dp, cs.outlineVariant, CircleShape),
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    FocusIntensityBars(mode)
                }
            }

            // چیپ «چه چیزی باز می‌ماند» حذف شد: همان حرفِ زیرنویسِ بالا را دوباره
            // می‌گفت و کارت را بی‌دلیل بلند می‌کرد. فقط هشدار دسترسی می‌ماند چون
            // خبرِ تازه است.
            if (!compact && missing.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                FocusInfoChip("دسترسی ناقص: " + mode.needs, cs.error, warn = true)
            }
        }
    }
}

/** ستونی از کارت‌های حالت — تنها جایی که ترتیب حالت‌ها تعیین می‌شود. */
@Composable
fun FocusModePicker(
    selected: FocusMode,
    onSelect: (FocusMode) -> Unit,
    modifier: Modifier = Modifier,
    missingOf: (FocusMode) -> List<String> = { emptyList() },
    compact: Boolean = false,
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (m in FocusMode.entries) {
            FocusModeCard(
                mode = m,
                selected = selected == m,
                onClick = { onSelect(m) },
                missing = missingOf(m),
                compact = compact,
            )
        }
    }
}
