package ir.studying.app.ui.focus

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusMode
import ir.studying.app.focus.FocusRules
import ir.studying.app.focus.FocusSession
import ir.studying.app.ui.components.GlassPill
import ir.studying.app.ui.components.RippleRings
import ir.studying.app.ui.components.RollingText
import kotlinx.coroutines.delay

/**
 * جایگزین بخش چت/شبکهٔ اجتماعی در زمان قفل.
 *
 * تب عمداً از نوار پایین حذف نمی‌شود: ناوبری و پدینگ به چهار تب متکی است و حذف
 * ناگهانی تب وسط نشست، هم جای بقیه را جابجا می‌کند و هم همین صفحهٔ آموزشی را
 * غیرقابل‌دسترس می‌کند.
 */
@Composable
fun FocusLockedScreen(title: String, onGoStudy: () -> Unit) {
    val remaining by FocusLock.remaining.collectAsState()
    val session by FocusLock.session.collectAsState()
    FocusLockedBody(title = title, s = session, remaining = remaining, onGoStudy = onGoStudy)
}

/** جمله‌های کوتاهی که در صفحه‌های قفل آرام عوض می‌شوند. */
internal val FocusTips = listOf(
    "💡 هر نشستِ کامل، یک قدم واقعی به هدفت نزدیک‌تره",
    "🧠 هر بار سر زدن به گوشی، برگشتن به تمرکز عمیق کلی زمان می‌بره",
    "🌱 الان بهترین وقته که سراغ سخت‌ترین مبحث بری",
    "💧 یه لیوان آب بخور، یه نفس عمیق بکش و برگرد سر درس",
    "🏆 آخر نشست، نشان تمرکز منتظرته",
)

@Composable
internal fun FocusLockedBody(title: String, s: FocusSession?, remaining: Long, onGoStudy: () -> Unit) {
    val c1 = s?.let { focusModeColor(it.mode) } ?: MaterialTheme.colorScheme.primary
    val c2 = s?.let { focusModeColor2(it.mode) } ?: MaterialTheme.colorScheme.tertiary
    val total = if (s != null) (s.endAt - s.startAt).coerceAtLeast(1L) else 1L
    val done = if (s != null) ((total - remaining).toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    val clockText = FocusRules.clock(remaining).fa()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        VaultBackdrop(c1, c2, Modifier.matchParentSize(), stars = 56, seed = 13)
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = maxHeight)
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            if (s != null) GlassPill(s.mode.title, leading = s.mode.emoji)
            Spacer(Modifier.height(14.dp))
            VaultDial(progress = done, colors = listOf(c1, c2), modifier = Modifier.size(256.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AnimatedPadlock(
                        open = 0f,
                        size = 46.dp,
                        colors = listOf(lerp(c1, Color.White, 0.45f), c1, lerp(c2, Color.Black, 0.12f)),
                        glow = c2,
                    )
                    Spacer(Modifier.height(2.dp))
                    RollingText(
                        clockText,
                        style = TextStyle(
                            fontSize = if (clockText.length > 5) 34.sp else 44.sp,
                            fontWeight = FontWeight.Black,
                        ),
                        color = Color.White,
                    )
                    Text("تا پایان نشست", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "$title در حالت تمرکز قفل است",
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "پیام‌ها جایی نمی‌روند؛ بعد از نشست همه را یک‌جا می‌بینی.",
                color = Color.White.copy(alpha = 0.72f),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(18.dp))
            TipTicker(FocusTips)
            Spacer(Modifier.height(22.dp))
            FocusGlowButton(
                "برگشت به مطالعه",
                onClick = onGoStudy,
                modifier = Modifier.fillMaxWidth(),
                colors = listOf(c1, c2),
                icon = Icons.AutoMirrored.Rounded.MenuBook,
            )
        }
    }
}

/** نوار نکته‌ها: هر چند ثانیه با لغزش نرم عوض می‌شود. */
@Composable
internal fun TipTicker(tips: List<String>, modifier: Modifier = Modifier, periodMs: Long = 4500L) {
    var i by remember { mutableIntStateOf(0) }
    LaunchedEffect(tips) {
        while (true) {
            delay(periodMs)
            i = (i + 1) % tips.size
        }
    }
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = i,
            transitionSpec = {
                (fadeIn(tween(420)) + slideInVertically(tween(420)) { it / 2 })
                    .togetherWith(fadeOut(tween(220)) + slideOutVertically(tween(220)) { -it / 2 })
            },
            label = "tips",
        ) { idx ->
            Text(
                tips[idx],
                color = Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/**
 * صفحهٔ سدِ اپ‌های قفل‌شده (روی اپ مزاحم می‌نشیند).
 *
 * لحظهٔ ورود، قفل یک بار «نه» می‌گوید (لرزش افقی) و موج‌های سرخ از پشتش بیرون
 * می‌زنند؛ بعد آرام می‌شود و فقط شمارش معکوس و راه برگشت می‌ماند.
 */
@Composable
internal fun FocusBlockScene(
    appLabel: String?,
    mode: FocusMode?,
    remaining: Long,
    progress: Float,
    onStudy: () -> Unit,
    onHome: () -> Unit,
) {
    val c1 = Color(0xFFF43F5E)
    val c2 = mode?.let { focusModeColor2(it) } ?: Color(0xFFA855F7)
    val shake = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(250L)
        for (x in listOf(10f, -10f, 8f, -8f, 5f, -5f, 2f, 0f)) shake.animateTo(x, tween(55))
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        VaultBackdrop(c1, c2, Modifier.matchParentSize(), stars = 50, seed = 17)
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = maxHeight)
                .padding(horizontal = 28.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
                RippleRings(Modifier.matchParentSize(), color = c1, rings = 3, periodMs = 2600, strokeWidth = 2.dp)
                AnimatedPadlock(
                    open = 0f,
                    size = 92.dp,
                    colors = listOf(Color(0xFFFECDD3), c1, Color(0xFFBE123C)),
                    glow = c1,
                    modifier = Modifier.graphicsLayer { translationX = shake.value * density },
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                if (appLabel.isNullOrBlank()) "این اپ الان قفل است" else "«$appLabel» الان قفل است",
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "خودت خواستی تمرکز کنی. برگرد سر درس.",
                color = Color.White.copy(alpha = 0.72f),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(22.dp))
            // کپسول زمان
            val shape = RoundedCornerShape(26.dp)
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Color.White.copy(alpha = 0.07f))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                RollingText(
                    FocusRules.clock(remaining).fa(),
                    style = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.Black),
                    color = Color.White,
                )
                Text("تا پایان نشست", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.10f)),
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(progress.coerceIn(0f, 1f))
                            .height(7.dp)
                            .clip(RoundedCornerShape(50))
                            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(StayA, StayB))),
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
            FocusGlowButton(
                "برگشت به مطالعه",
                onClick = onStudy,
                modifier = Modifier.fillMaxWidth(),
                colors = listOf(StayA, StayB),
                icon = Icons.AutoMirrored.Rounded.MenuBook,
            )
            Spacer(Modifier.height(10.dp))
            FocusGlassButton(
                "رفتن به صفحهٔ خانه",
                onClick = onHome,
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Rounded.Home,
            )

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "تا پایان نشست راهی برای باز کردن قفل نیست — خودت این قول را دادی 🔒",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.width(300.dp),
                )
            }
        }
    }
}
