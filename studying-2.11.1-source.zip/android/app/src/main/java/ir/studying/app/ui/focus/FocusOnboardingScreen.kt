package ir.studying.app.ui.focus

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.studying.app.core.fa
import ir.studying.app.focus.DeviceLock
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusMode
import ir.studying.app.focus.FocusPerms
import ir.studying.app.focus.FocusScheduler

/**
 * ویزارد راه‌اندازی قفل.
 *
 * فلسفهٔ طراحی: کاربر نباید با لیستی از ده دسترسی تنها گذاشته شود. یک مرحله،
 * یک توضیح ساده، یک دکمهٔ «دادن دسترسی»؛ و تیک سبزِ لحطه‌ای وقتی برمی‌گردد
 * (به لطف [rememberPermState] دیگر لازم نیست روی چیزی کلیک کند تا فهمیده شود).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusOnboardingScreen(
    onBack: () -> Unit,
    onDone: () -> Unit,
    onPickApps: () -> Unit,
) {
    val ctx = LocalContext.current
    val perms by rememberPermState()
    val cfg by FocusLock.config.collectAsState()
    var step by remember { mutableIntStateOf(0) }

    val steps = 5

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("راه‌نمای راه‌اندازی قفل") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowForward, contentDescription = "بازگشت")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            LinearProgressIndicator(
                progress = { (step + 1).toFloat() / steps.toFloat() },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                ("مرحلهٔ " + (step + 1).toString() + " از " + steps.toString()).fa(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))

            when (step) {
                0 -> StepCard(
                    emoji = "🧱",
                    title = "قفل چطور کار می‌کند؟",
                    body = "سه حالت داری، از ملایم به سخت:\n" +
                        "۱) قفل اپ‌های منتخب — اپ‌هایی که خودت انتخاب می‌کنی باز نمی‌شوند؛ بقیهٔ گوشی آزاد است.\n" +
                        "۲) همه‌چیز جز تماس و پیامک — حتی منوی گوشی هم باز نمی‌شود.\n" +
                        "۳) قفل کامل گوشی — صفحه روشن شود، بی‌درنگ خاموش می‌شود.\n\n" +
                        "روی هر حالت می‌توانی «حبس در اتاق مطالعه» را هم روشن کنی تا خودِ اپ روی صفحه پین شود.",
                    done = true,
                )

                1 -> StepCard(
                    emoji = "👁️",
                    title = "موتور تشخیص اپ (مهم‌ترین)",
                    body = "برای اینکه اپ بفهمد چه برنامه‌ای باز شده، یکی از این دو راه کافی است. سرویس دسترسی‌پذیری دقیق‌تر و سریع‌تر است (پیشنهاد ما)؛ راه دوم آمار مصرف + نمایش روی اپ‌هاست.",
                    done = perms.appEngineReady,
                    actions = listOf(
                        GrantAction("سرویس دسترسی‌پذیری", perms.accessibility) { FocusPerms.openAccessibility(ctx) },
                        GrantAction("آمار مصرف اپ‌ها", perms.usage) { FocusPerms.openUsageAccess(ctx) },
                        GrantAction("نمایش روی اپ‌های دیگر", perms.overlay) { FocusPerms.openOverlay(ctx) },
                    ),
                    note = "اگر پیام «این دسترسی محدود است» یا «App was denied access» دیدی: تنطیمات گوشی ▸ برنامه‌ها ▸ Studying ▸ منوی سه‌نقطه ▸ «اجازهٔ تنطیمات محدود» (Allow restricted settings) را بزن، بعد دوباره همین دکمه را بزن. این محدودیت از اندروید ۱۳ به بعد برای اپ‌های خارج از گوگل‌پلی طبیعی است.",
                )

                2 -> StepCard(
                    emoji = "🔇",
                    title = "سکوت اعلان‌ها",
                    body = "در زمان قفل، اعلان بقیهٔ اپ‌ها با مزاحمت نکن؛ برای این کار به دسترسی «مزاحمت نکنید» نیاز است. خواندن اعلان‌ها اختیاری است و فقط برای سکوت گزینشی اپ‌به‌اپ لازم است.",
                    done = perms.dnd,
                    actions = listOf(
                        GrantAction("مزاحمت نکنید", perms.dnd) { FocusPerms.openDndAccess(ctx) },
                        GrantAction("خواندن اعلان‌ها (اختیاری)", perms.notifListener) { FocusPerms.openNotifListener(ctx) },
                    ),
                )

                3 -> StepCard(
                    emoji = "🔒",
                    title = "قفل کامل گوشی (اختیاری)",
                    body = "اگر می‌خواهی در حالت قفل کامل، به محض روشن شدن صفحه گوشی خاموش شود، اپ به نقش «مدیر دستگاه» نیاز دارد. تنها اختیاری که گرفته می‌شود «قفل صفحه» است؛ هیچ داده‌ای خوانده یا پاک نمی‌شود.",
                    done = perms.deviceAdmin,
                    actions = listOf(
                        GrantAction("فعال‌سازی مدیر دستگاه", perms.deviceAdmin) { DeviceLock.request(ctx) },
                    ),
                    note = "برای خروج از قفل کامل، باید متن تعهد را تایپ کنی و ۶۰ ثانیه صبر کنی. همیشه راه فرار وجود دارد.",
                )

                else -> StepCard(
                    emoji = "🔋",
                    title = "دوام قفل و لیست اپ‌ها",
                    body = "برای اینکه گوشی، نگهبان قفل را نکشد (خصوصاً شاومی، هواوی، سامسونگ)، معافیت باتری و اجازهٔ اجرای خودکار را بده. در آخر، لیست اپ‌های مزاحم را بساز.",
                    done = perms.batteryExempt,
                    actions = listOf(
                        GrantAction("معافیت باتری", perms.batteryExempt) { FocusPerms.openBatteryExempt(ctx) },
                        GrantAction("اجازهٔ اجرای خودکار", false) { FocusPerms.openAutoStart(ctx) },
                        GrantAction("آلارم دقیق (برای زمان‌بندی)", FocusScheduler.canExact(ctx)) {
                            FocusScheduler.openExactAlarmSettings(ctx)
                        },
                    ),
                )
            }

            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (step > 0) {
                    OutlinedButton(onClick = { step -= 1 }, modifier = Modifier.weight(1f)) {
                        Text("قبلی")
                    }
                }
                Button(
                    onClick = {
                        if (step < steps - 1) step += 1
                        else {
                            FocusLock.updateConfig { it.copy(onboarded = true) }
                            onDone()
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text(if (step < steps - 1) "بعدی" else "تمام") }
            }
            if (step == steps - 1) {
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = onPickApps, modifier = Modifier.fillMaxWidth()) {
                    Text(("انتخاب اپ‌های مزاحم (" + cfg.blocked.size.toString() + " اپ)").fa())
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private data class GrantAction(val label: String, val granted: Boolean, val onClick: () -> Unit)

@Composable
private fun StepCard(
    emoji: String,
    title: String,
    body: String,
    done: Boolean,
    actions: List<GrantAction> = emptyList(),
    note: String? = null,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.size(10.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                if (done) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(body, style = MaterialTheme.typography.bodyMedium)
            if (actions.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                for (a in actions) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(a.label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        if (a.granted) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                                Spacer(Modifier.size(6.dp))
                                Text("داده شد", style = MaterialTheme.typography.bodySmall)
                            }
                        } else {
                            Button(onClick = a.onClick) { Text("دادن دسترسی") }
                        }
                    }
                }
            }
            if (note != null) {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(12.dp),
                ) {
                    Row {
                        Icon(Icons.Rounded.Info, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text(note, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
