package ir.studying.app.ui.focus

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Coffee
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusConfig
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusMode
import ir.studying.app.focus.FocusRules
import ir.studying.app.focus.FocusSession
import ir.studying.app.focus.PermState
import ir.studying.app.ui.components.GlassPill
import ir.studying.app.ui.components.RollingText
import ir.studying.app.ui.components.Sparkles
import ir.studying.app.ui.components.bouncyClick
import kotlin.math.PI
import kotlin.math.sin

/**
 * کارت قفل سریع — بالای «مرکز فرماندهی قفل» می‌نشیند.
 *
 * [compact] برای صفحهٔ اصلی است: یک ردیف کوتاه و فقط وقتی قفل غیرفعال است. در زمان
 * قفل، صفحهٔ اصلی چیزی نشان نمی‌دهد (وضعیت و خروج در اعلان پیش‌زمینه و بخش مطالعه هست).
 *
 * طراحی نسخهٔ ۲.۹ («گاوصندوق»): در زمان قفل، کارت یک صفحهٔ مدرجِ تیره است با
 * قفلِ واقعیِ بسته، زمانِ غلتان و درجه‌هایی که با گذشت زمان روشن می‌شوند؛ در
 * استراحت قفل باز می‌شود و رنگ‌ها گرم. پیش از شروع، قفلی که مدام «کلیک» می‌کند
 * دعوت به شروع است. منطق دکمه‌ها همان نسخهٔ قبل است.
 */
@Composable
fun FocusQuickCard(
    onOpenSettings: () -> Unit,
    onOpenPhoneMenu: () -> Unit = {},
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    val ctx = LocalContext.current
    val cfg by FocusLock.config.collectAsState()
    val session by FocusLock.session.collectAsState()
    val remaining by FocusLock.remaining.collectAsState()
    var showUnlock by remember { mutableStateOf(false) }
    var showStart by remember { mutableStateOf(false) }

    val active = FocusRules.isActive(session)
    val s = session

    // صفحهٔ اصلی: در زمان قفل هیچ کارتی نشان نده.
    if (compact && active) return

    if (compact) {
        FocusCompactRow(cfg.mode, onStart = { showStart = true }, modifier = modifier)
        if (showStart) FocusStartDialog(onDismiss = { showStart = false })
        return
    }

    if (active && s != null) {
        val inBreak = FocusRules.inBreak(s)
        FocusActiveHero(
            s = s,
            remaining = remaining,
            inBreak = inBreak,
            breakRemaining = if (inBreak) FocusRules.breakRemainingMs(s) else 0L,
            onBreak = { FocusLock.startBreak() },
            onEndBreak = { FocusLock.endBreak() },
            onPhone = onOpenPhoneMenu,
            onExit = {
                if (FocusLock.unlockNeedsChallenge()) showUnlock = true else FocusLock.breakOut()
            },
            modifier = modifier,
        )
    } else {
        val missing = remember(cfg.mode, PermState.state.value) {
            PermState.current(ctx).missingFor(cfg.mode)
        }
        // فقط یک دکمه: «تنظیمات» قبلی هم همین دیالوگ شروع را باز می‌کرد،
        // یعنی دو دکمه با یک کار — حذف شد.
        FocusIdleHero(cfg = cfg, missing = missing, onStart = { showStart = true }, modifier = modifier)
    }

    if (showStart) FocusStartDialog(onDismiss = { showStart = false })
    if (showUnlock) {
        UnlockChallengeDialog(
            onDismiss = { showUnlock = false },
            onUnlocked = {
                showUnlock = false
                FocusLock.breakOut()
            },
        )
    }
}

/* ------------------------------ در زمان قفل ------------------------------ */

/**
 * گاوصندوقِ در حال شمارش. بی‌حالت است تا پیش‌نمایش و تست بتوانند هر لحظه‌ای را بسازند.
 */
@Composable
internal fun FocusActiveHero(
    s: FocusSession,
    remaining: Long,
    inBreak: Boolean,
    breakRemaining: Long,
    onBreak: () -> Unit,
    onEndBreak: () -> Unit,
    onPhone: () -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val a1 by animateColorAsState(if (inBreak) BreakA else focusModeColor(s.mode), tween(600), label = "heroA1")
    val a2 by animateColorAsState(if (inBreak) BreakB else focusModeColor2(s.mode), tween(600), label = "heroA2")
    val total = (s.endAt - s.startAt).coerceAtLeast(1L)
    val done = ((total - remaining).toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val breakTotal = (s.config.breakSeconds * 1000L).coerceAtLeast(1L)
    val dial = if (inBreak) (1f - breakRemaining.toFloat() / breakTotal.toFloat()).coerceIn(0f, 1f) else done
    val clockText = FocusRules.clock(if (inBreak) breakRemaining else remaining).fa()
    val elapsedMin = ((total - remaining).coerceAtLeast(0L) / 60_000L).toInt()
    val breaksLeft = FocusRules.breaksLeft(s)

    VaultCard(a1, a2, modifier) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PulseDot(if (inBreak) BreakA else Color(0xFF4ADE80))
                Spacer(Modifier.width(4.dp))
                Text(
                    if (inBreak) "استراحت کوتاه" else "قفل فعال است",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                )
                Spacer(Modifier.weight(1f))
                GlassPill(
                    if (inBreak) "قفل موقتاً برداشته شده" else s.mode.title,
                    leading = if (inBreak) "☕" else s.mode.emoji,
                    style = MaterialTheme.typography.labelSmall,
                )
            }

            Spacer(Modifier.height(4.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                VaultDial(progress = dial, colors = listOf(a1, a2), modifier = Modifier.size(240.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AnimatedPadlock(
                            open = if (inBreak) 1f else 0f,
                            size = 40.dp,
                            colors = listOf(lerp(a1, Color.White, 0.45f), a1, lerp(a2, Color.Black, 0.12f)),
                            glow = a2,
                        )
                        Spacer(Modifier.height(2.dp))
                        RollingText(
                            clockText,
                            style = TextStyle(
                                fontSize = if (clockText.length > 5) 33.sp else 42.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.sp,
                            ),
                            color = Color.White,
                        )
                        Text(
                            if (inBreak) "تا برگشت خودکار به قفل" else "تا پایان نشست",
                            color = Color.White.copy(alpha = 0.62f),
                            fontSize = 11.sp,
                        )
                    }
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassStat(elapsedMin.fa(), "دقیقه گذشته", Modifier.weight(1f))
                GlassStat(s.plannedMinutes.fa(), "دقیقهٔ برنامه", Modifier.weight(1f))
                GlassStat(
                    if (FocusRules.breaksAllowed(s)) (breaksLeft.toString() + " از " + s.config.breakLimit.toString()).fa() else "—",
                    "استراحت مانده",
                    Modifier.weight(1f),
                )
            }

            if (!FocusRules.canExit(s)) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.07f))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("🔐", fontSize = 15.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "این نشست بدون خروج شروع شده؛ تا پایان زمان باز نمی‌شود.",
                        color = Color.White.copy(alpha = 0.78f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!inBreak && FocusRules.breaksAllowed(s) && breaksLeft > 0) {
                    FocusActionTile(
                        ("استراحت (" + breaksLeft.toString() + ")").fa(),
                        icon = Icons.Rounded.Coffee,
                        onClick = onBreak,
                        modifier = Modifier.weight(1f),
                        tint = Color(0xFFFDE68A),
                    )
                }
                if (inBreak) {
                    FocusActionTile(
                        "برگشت به قفل",
                        icon = Icons.Rounded.Lock,
                        onClick = onEndBreak,
                        modifier = Modifier.weight(1f),
                        colors = listOf(focusModeColor(s.mode), focusModeColor2(s.mode)),
                    )
                }
                if (s.mode == FocusMode.ALL_BUT_CALLS || s.mode == FocusMode.TOTAL) {
                    FocusActionTile(
                        "تماس/پیامک",
                        icon = Icons.Rounded.Phone,
                        onClick = onPhone,
                        modifier = Modifier.weight(1f),
                    )
                }
                /* نشستی که کاربر پیش از شروع «بدون خروج» انتخاب کرده، دکمهٔ
                   خروج هم ندارد؛ نمایش دکمه‌ای که کار نمی‌کند فقط گیج‌کننده است.
                   خروج عمداً شیشه‌ای و کم‌رنگ است، نه پررنگ‌ترین دکمهٔ کارت. */
                if (FocusRules.canExit(s)) {
                    FocusActionTile(
                        "خروج",
                        icon = Icons.Rounded.LockOpen,
                        onClick = onExit,
                        modifier = Modifier.weight(1f),
                        tint = Color(0xFFFDA4AF),
                    )
                }
            }
        }
    }
}

/* ------------------------------ پیش از شروع ------------------------------ */

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun FocusIdleHero(
    cfg: FocusConfig,
    missing: List<String>,
    onStart: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val mode = cfg.mode
    val c1 by animateColorAsState(focusModeColor(mode), tween(500), label = "idleC1")
    val c2 by animateColorAsState(focusModeColor2(mode), tween(500), label = "idleC2")

    VaultCard(c1, c2, modifier) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    GlassPill("قفل تمرکز", leading = "🎯", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "گوشی رو قفل کن،\nذهنت رو آزاد",
                        color = Color.White,
                        fontSize = 22.sp,
                        lineHeight = 31.sp,
                        fontWeight = FontWeight.Black,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "یه نشست بی‌مزاحمت فقط یه لمس فاصله داره",
                        color = Color.White.copy(alpha = 0.68f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Spacer(Modifier.width(6.dp))
                LockingPadlockScene(c1, c2, Modifier.size(116.dp))
            }

            Spacer(Modifier.height(14.dp))
            IdleModeRow(mode, onClick = onStart)
            if (missing.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                FocusInfoChip("دسترسی ناقص: " + mode.needs, Color(0xFFFCA5A5), warn = true)
            }

            Spacer(Modifier.height(10.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                val small = MaterialTheme.typography.labelSmall
                GlassPill((cfg.defaultMinutes.toString() + " دقیقه").fa(), leading = "⏱", style = small)
                GlassPill(
                    if (cfg.allowBreaks && cfg.breakLimit > 0) (cfg.breakLimit.toString() + " استراحت").fa() else "بدون استراحت",
                    leading = "☕",
                    style = small,
                )
                GlassPill(
                    if (cfg.allowExit) "خروج با چالش" else "بدون خروج",
                    leading = if (cfg.allowExit) "🚪" else "⛔",
                    style = small,
                )
            }

            Spacer(Modifier.height(14.dp))
            FocusGlowButton(
                "شروع قفل",
                onClick = onStart,
                modifier = Modifier.fillMaxWidth(),
                colors = listOf(c1, c2),
                icon = Icons.Rounded.Lock,
            )
        }
    }
}

/** ردیف شیشه‌ای حالت فعلی؛ لمسش همان دیالوگ شروع را باز می‌کند تا حالت عوض شود. */
@Composable
private fun IdleModeRow(mode: FocusMode, onClick: () -> Unit) {
    val c1 = focusModeColor(mode)
    val c2 = focusModeColor2(mode)
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .bouncyClick(pressedScale = 0.97f, onClick = onClick)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, Brush.linearGradient(listOf(c1.copy(alpha = 0.6f), Color.White.copy(alpha = 0.08f))), shape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(c1, c2))),
            contentAlignment = Alignment.Center,
        ) { Text(mode.emoji, fontSize = 21.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(mode.title, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            Text(mode.keepsOpen, color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.bodySmall)
        }
        FocusIntensityBars(mode, track = Color.White.copy(alpha = 0.16f))
        Spacer(Modifier.width(10.dp))
        Text("تغییر", color = lerp(c1, Color.White, 0.35f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}

/**
 * صحنهٔ «کلیک»: قفل باز است، بسته می‌شود، موج نوری بیرون می‌زند و دوباره باز
 * می‌شود. یک حلقهٔ ۳.۶ ثانیه‌ای که بدون هیچ متنی می‌گوید این دکمه چه می‌کند.
 */
@Composable
internal fun LockingPadlockScene(c1: Color, c2: Color, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "lockScene")
    val ms by tr.animateFloat(0f, 3600f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "lockSceneT")
    val open = when {
        ms < 900f -> 1f
        ms < 1200f -> 1f - FastOutSlowInEasing.transform((ms - 900f) / 300f)
        ms < 3000f -> 0f
        else -> FastOutSlowInEasing.transform((ms - 3000f) / 600f)
    }
    val flash = if (ms in 1200f..2100f) (ms - 1200f) / 900f else -1f
    val bump = if (ms in 1200f..1500f) sin(PI.toFloat() * (ms - 1200f) / 300f) * 0.09f else 0f
    val bob = sin(ms / 3600f * 2f * PI.toFloat()) * 3f

    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val r = size.minDimension / 2f
            drawCircle(Brush.radialGradient(listOf(c1.copy(alpha = 0.32f), Color.Transparent), radius = r), r)
            if (flash >= 0f) {
                drawCircle(
                    c2.copy(alpha = (1f - flash) * 0.85f),
                    r * (0.42f + 0.56f * flash),
                    style = Stroke(2.dp.toPx()),
                )
                drawCircle(
                    c1.copy(alpha = (1f - flash) * 0.5f),
                    r * (0.30f + 0.45f * flash),
                    style = Stroke(1.2.dp.toPx()),
                )
            }
        }
        Sparkles(Modifier.matchParentSize(), color = lerp(c2, Color.White, 0.4f), count = 6, seed = 9)
        AnimatedPadlock(
            open = open,
            size = 64.dp,
            colors = listOf(lerp(c1, Color.White, 0.45f), c1, lerp(c2, Color.Black, 0.10f)),
            glow = c2,
            animate = false,
            modifier = Modifier.graphicsLayer {
                translationY = bob * density
                val sc = 1f + bump
                scaleX = sc
                scaleY = sc
            },
        )
    }
}

/** ردیف جمع‌وجور صفحهٔ اصلی. */
@Composable
private fun FocusCompactRow(mode: FocusMode, onStart: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val c1 = focusModeColor(mode)
    val c2 = focusModeColor2(mode)
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier
            .fillMaxWidth()
            .bouncyClick(pressedScale = 0.98f, onClick = onStart)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(c1.copy(alpha = 0.16f), c2.copy(alpha = 0.06f))))
            .border(1.dp, Brush.horizontalGradient(listOf(c1.copy(alpha = 0.45f), c2.copy(alpha = 0.15f))), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(c1, c2))),
            contentAlignment = Alignment.Center,
        ) {
            AnimatedPadlock(
                open = 0f,
                size = 24.dp,
                colors = listOf(Color.White, Color(0xFFF1F5F9), Color(0xFFE2E8F0)),
                shackle = listOf(Color.White, Color(0xFFF8FAFC), Color(0xFFE2E8F0)),
                glow = Color.White,
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("قفل تمرکز", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            Text(mode.title, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
        FocusIntensityBars(mode)
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(c1, c2)))
                .padding(horizontal = 14.dp, vertical = 7.dp),
        ) { Text("شروع", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
    }
}
