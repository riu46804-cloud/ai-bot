package ir.studying.app.ui.focus

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusRecap
import ir.studying.app.ui.components.RippleRings
import ir.studying.app.ui.components.Sparkles

/**
 * کارت پایان نشست.
 *
 * مهم‌ترین تکهٔ تجربه است: قفلی که فقط چیزها را می‌بندد حس تنبیه می‌دهد؛ قفلی که
 * آخرش نشان می‌دهد چقدر مزاحمت را گرفته، حس برد می‌دهد. از نسخهٔ ۲.۹ این حسِ برد
 * دیده هم می‌شود: جام می‌پرد، دقیقه‌ها از صفر بالا می‌روند و آمار در کاشی‌ها.
 */
@Composable
fun FocusRecapDialog() {
    val recap by FocusLock.recap.collectAsState()
    val badges by FocusLock.badges.collectAsState()
    val r = recap ?: return

    Dialog(onDismissRequest = { FocusLock.clearRecap() }) {
        FocusRecapBody(r = r, badges = badges, onDone = { FocusLock.clearRecap() })
    }
}

@Composable
internal fun FocusRecapBody(r: FocusRecap, badges: Int, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val a1 = if (r.broke) Color(0xFF94A3B8) else Color(0xFFFBBF24)
    val a2 = if (r.broke) Color(0xFFFB7185) else Color(0xFF34D399)
    val shape = RoundedCornerShape(30.dp)

    val count = remember { Animatable(0f) }
    LaunchedEffect(r.minutes) {
        count.animateTo(r.minutes.toFloat(), tween(1300, easing = FastOutSlowInEasing))
    }
    val pop = remember { Animatable(0.4f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = 0.38f, stiffness = 260f)) }
    val t = rememberInfiniteTransition(label = "recap")
    val bob by t.animateFloat(
        -4f, 4f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "recapBob",
    )

    Column(
        Modifier
            .widthIn(max = 460.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surface)
            .border(1.dp, Brush.linearGradient(listOf(a1.copy(alpha = 0.55f), cs.outlineVariant.copy(alpha = 0.3f), a2.copy(alpha = 0.45f))), shape),
    ) {
        Box(Modifier.fillMaxWidth().height(178.dp), contentAlignment = Alignment.Center) {
            VaultBackdrop(a1, a2, Modifier.matchParentSize(), stars = 30, seed = 41)
            if (!r.broke) {
                RippleRings(Modifier.size(170.dp), color = a1, rings = 3, periodMs = 2800)
                Sparkles(Modifier.size(180.dp), color = Color(0xFFFDE68A), count = 9, seed = 4)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (r.broke) "🔓" else "🏆",
                    fontSize = 52.sp,
                    modifier = Modifier.graphicsLayer {
                        scaleX = pop.value
                        scaleY = pop.value
                        translationY = bob * density
                    },
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (r.broke) "نشست نیمه‌کاره ماند \uD83D\uDD13"
                    else "نشست تمرکز تمام شد \uD83C\uDF89",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                )
            }
        }

        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    count.value.toInt().fa(),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    color = cs.onSurface,
                )
                Text(
                    "  دقیقه تمرکز",
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RecapTile("🔕", r.suppressedNotifs.fa(), "اعلانِ ساکت", Modifier.weight(1f), a1)
                RecapTile("🛡️", r.blockedOpens.fa(), "بار برگشتی", Modifier.weight(1f), a2)
                RecapTile("🏅", badges.fa(), "نشان تمرکز", Modifier.weight(1f), a1)
            }
            Spacer(Modifier.height(12.dp))
            if (r.suppressedNotifs > 0) {
                Text(
                    "${r.suppressedNotifs} اعلان را جلویش گرفتم تا حواست پرت نشود".fa(),
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
            }
            if (r.blockedOpens > 0) {
                Text(
                    "${r.blockedOpens} بار سراغ اپ‌های قفل‌شده رفتی و برگشتی".fa(),
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (r.broke) "نشان این نشست سوخت، ولی مهم همین دقیقه‌هایی بود که خواندی."
                else "یک نشان تمرکز گرفتی — جمعاً $badges نشان".fa(),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            FocusGlowButton(
                "باشه",
                onClick = onDone,
                modifier = Modifier.fillMaxWidth(),
                colors = if (r.broke) listOf(Color(0xFF64748B), Color(0xFF94A3B8)) else listOf(Color(0xFFF59E0B), StayA),
                icon = Icons.Rounded.Check,
            )
        }
    }
}

@Composable
private fun RecapTile(emoji: String, value: String, label: String, modifier: Modifier, tint: Color) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .clip(shape)
            .background(tint.copy(alpha = 0.10f))
            .border(1.dp, tint.copy(alpha = 0.25f), shape)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 18.sp)
        Text(value, fontWeight = FontWeight.Black, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
