package ir.studying.app.ui.focus

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Help
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.studying.app.core.fa
import ir.studying.app.focus.DeviceLock
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusMode
import ir.studying.app.focus.FocusPerms
import ir.studying.app.focus.FocusRules
import ir.studying.app.focus.FocusSchedule
import ir.studying.app.focus.FocusScheduler
import ir.studying.app.ui.settings.SettingsGroup
import ir.studying.app.ui.settings.SettingsRow
import ir.studying.app.ui.settings.SettingsSwitchRow
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import ir.studying.app.ui.components.GlowSwitch
import ir.studying.app.ui.components.bouncyClick
import java.util.Calendar

/**
 * مرکز فرماندهی قفل تمرکز.
 *
 * ساختار عمدی: اول حالت قفل، بعد چیزهایی که قبل از شروع لازم است (اپ‌ها، استراحت،
 * سختی خروج)، بعد زمان‌بندی، و در انتها دسترسی‌ها که حالا لحطه‌ای بروز می‌شوند.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusSettingsScreen(
    onBack: () -> Unit,
    onOpenApps: () -> Unit = {},
    onOpenGuide: () -> Unit = {},
    onOpenPhoneMenu: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val cfg by FocusLock.config.collectAsState()
    val session by FocusLock.session.collectAsState()
    val perms by rememberPermState()
    var showStart by remember { mutableStateOf(false) }
    var editSchedule by remember { mutableStateOf<FocusSchedule?>(null) }

    val missing = perms.missingFor(cfg.mode)

    // اولین ورود به بخش قفل: راهنمای کامل باید قبل از هر کاری دیده شود
    LaunchedEffect(Unit) { if (!cfg.onboarded) onOpenGuide() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("قفل تمرکز") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowForward, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = onOpenGuide) {
                        Icon(Icons.Rounded.Help, contentDescription = "راهنما")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
        ) {
            FocusQuickCard(
                onOpenSettings = { showStart = true },
                onOpenPhoneMenu = onOpenPhoneMenu,
                modifier = Modifier.padding(16.dp),
            )

            if (!cfg.onboarded || missing.isNotEmpty()) {
                SetupNotice(
                    onboarded = cfg.onboarded,
                    missing = missing,
                    onGrant = { FocusPerms.openFirstMissing(ctx, cfg.mode) },
                    onGuide = onOpenGuide,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Spacer(Modifier.height(8.dp))
            }

            /* ---------- حالت قفل ---------- */
            SettingsGroup(title = "حالت قفل") {
                FocusModePicker(
                    selected = cfg.mode,
                    onSelect = { m -> FocusLock.updateConfig { it.copy(mode = m) } },
                    missingOf = { m -> perms.missingFor(m) },
                    modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 6.dp),
                )
            }

            /* ---------- اپ‌ها ---------- */
            SettingsGroup(title = "اپ‌های مزاحم") {
                SettingsRow(
                    icon = Icons.Rounded.Apps,
                    title = "انتخاب اپ‌ها",
                    subtitle = (cfg.blocked.size.toString() + " اپ انتخاب شده").fa(),
                    onClick = onOpenApps,
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "قفل اپ‌های دیگر",
                    subtitle = "در حالت «قفل اپ‌های منتخب» فعال می‌شود",
                    checked = cfg.blockApps,
                    onChange = { v -> FocusLock.updateConfig { it.copy(blockApps = v) } },
                )
                /*
                 * پین صفحه از نسخهٔ ۲.۷ یک تقویت‌کنندهٔ مستقل است و با «قفل اپ‌های منتخب»
                 * و «همه‌چیز جز تماس» جمع می‌شود. در «قفل کامل» پنهان می‌شود چون آنجا
                 * صفحه خاموش می‌ماند و پین هیچ کاری نمی‌کند.
                 */
                if (cfg.mode != FocusMode.TOTAL) {
                    SettingsSwitchRow(
                        icon = Icons.Rounded.Bolt,
                        title = "حبس در اتاق مطالعه (پین صفحه)",
                        subtitle = "خودِ اپ روی صفحه پین می‌شود؛ بیرون رفتن یک مرحله سخت‌تر",
                        checked = cfg.pinScreen,
                        onChange = { v -> FocusLock.updateConfig { it.copy(pinScreen = v) } },
                    )
                }
            }

            /* ---------- استراحت ---------- */
            SettingsGroup(title = "استراحت کوتاه") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(
                        ("طول هر استراحت: " + secLabel(cfg.breakSeconds)).fa(),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = cfg.breakSeconds.toFloat(),
                        onValueChange = { v ->
                            val step = (v / 30f).toInt() * 30
                            FocusLock.updateConfig { it.copy(breakSeconds = step.coerceIn(30, 300)) }
                        },
                        valueRange = 30f..300f,
                        steps = 8,
                    )
                    Text(
                        ("تعداد مجاز در هر نشست: " + cfg.breakLimit.toString()).fa(),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = cfg.breakLimit.toFloat(),
                        onValueChange = { v ->
                            FocusLock.updateConfig { it.copy(breakLimit = v.toInt().coerceIn(0, 10)) }
                        },
                        valueRange = 0f..10f,
                        steps = 9,
                    )
                }
            }

            /* ---------- سختی خروج ---------- */
            SettingsGroup(title = "باز کردن قفل") {
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "تایپ متن تعهد برای خروج",
                    subtitle = "خروج با یک تپ ممکن نمی‌شود",
                    checked = cfg.unlockTyping,
                    onChange = { v -> FocusLock.updateConfig { it.copy(unlockTyping = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "امکان خروج اضطراری",
                    subtitle = "خاموش یعنی نشست تا پایان زمان باز نمی‌شود (در شروع هر نشست هم قابل تغییر است)",
                    checked = cfg.allowExit,
                    onChange = { v -> FocusLock.updateConfig { it.copy(allowExit = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "متن تعهد فارسی باشد",
                    subtitle = "خاموش = متن انگلیسی ساده؛ تایپش روی هر کیبوردی راحت‌تر است",
                    checked = cfg.unlockPersianText,
                    onChange = { v -> FocusLock.updateConfig { it.copy(unlockPersianText = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "بستن راه‌های فرار در استراحت",
                    subtitle = "جلوگیری از حذف اپ و پس گرفتن دسترسی‌ها، حتی وقتی در استراحت هستی",
                    checked = cfg.guardEscape,
                    onChange = { v -> FocusLock.updateConfig { it.copy(guardEscape = v) } },
                )
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(
                        ("تأخیر پس از تایپ درست: " + cfg.unlockDelaySec.toString() + " ثانیه").fa(),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = cfg.unlockDelaySec.toFloat(),
                        onValueChange = { v ->
                            val step = (v / 15f).toInt() * 15
                            FocusLock.updateConfig { it.copy(unlockDelaySec = step.coerceIn(0, 300)) }
                        },
                        valueRange = 0f..300f,
                        steps = 19,
                    )
                }
            }

            /* ---------- اعلان‌ها ---------- */
            SettingsGroup(title = "اعلان‌ها") {
                SettingsSwitchRow(
                    icon = Icons.Rounded.NotificationsOff,
                    title = "مزاحمت نکنید در زمان قفل",
                    subtitle = "اعلان بقیهٔ اپ‌ها ساکت می‌شود",
                    checked = cfg.useDnd,
                    onChange = { v -> FocusLock.updateConfig { it.copy(useDnd = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.NotificationsOff,
                    title = "سکوت گزینشی اپ‌به‌اپ",
                    subtitle = "نیاز به دسترسی خواندن اعلان‌ها",
                    checked = cfg.perAppSilence,
                    onChange = { v -> FocusLock.updateConfig { it.copy(perAppSilence = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "قفل چت درون اپ",
                    subtitle = "پیام‌ها در زمان قفل باز نمی‌شوند",
                    checked = cfg.lockChat,
                    onChange = { v -> FocusLock.updateConfig { it.copy(lockChat = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Groups,
                    title = "قفل شبکهٔ اجتماعی اپ",
                    subtitle = "فید و جامعه در زمان قفل باز نمی‌شوند",
                    checked = cfg.lockSocial,
                    onChange = { v -> FocusLock.updateConfig { it.copy(lockSocial = v) } },
                )
            }

            /* ---------- زمان‌بندی ---------- */
            SettingsGroup(title = "زمان‌بندی خودکار") {
                for (s in cfg.schedules) {
                    ScheduleRow(
                        s = s,
                        onOpen = { editSchedule = s },
                        onToggle = { v ->
                            FocusLock.updateConfig { c ->
                                c.copy(schedules = c.schedules.map { if (it.id == s.id) it.copy(enabled = v) else it })
                            }
                            FocusLock.syncSchedules(ctx)
                        },
                        onDelete = {
                            FocusLock.updateConfig { c -> c.copy(schedules = c.schedules.filter { it.id != s.id }) }
                            FocusLock.syncSchedules(ctx)
                        },
                    )
                }
                SettingsRow(
                    icon = Icons.Rounded.Add,
                    title = "افزودن زمان‌بندی",
                    subtitle = if (FocusScheduler.canExact(ctx)) "سر ساعت مقرر خودکار قفل می‌شود"
                    else "برای دقت بیشتر، اجازهٔ آلارم دقیق را بده",
                    onClick = {
                        val ids = cfg.schedules.map { it.id }
                        val id = (0..11).firstOrNull { !ids.contains(it) } ?: 0
                        editSchedule = FocusSchedule(
                            id = id,
                            minuteOfDay = 21 * 60,
                            minutes = cfg.defaultMinutes,
                            mode = cfg.mode,
                        )
                    },
                )
            }

            /* ---------- دسترسی‌ها ---------- */
            SettingsGroup(title = "دسترسی‌ها") {
                PermRow("سرویس دسترسی‌پذیری (بهترین)", perms.accessibility) { FocusPerms.openAccessibility(ctx) }
                PermRow("آمار مصرف اپ‌ها", perms.usage) { FocusPerms.openUsageAccess(ctx) }
                PermRow("نمایش روی اپ‌ها", perms.overlay) { FocusPerms.openOverlay(ctx) }
                PermRow("مزاحمت نکنید", perms.dnd) { FocusPerms.openDndAccess(ctx) }
                PermRow("خواندن اعلان‌ها (اختیاری)", perms.notifListener) { FocusPerms.openNotifListener(ctx) }
                PermRow("مدیر دستگاه (قفل کامل)", perms.deviceAdmin) { DeviceLock.request(ctx) }
                PermRow("معافیت باتری", perms.batteryExempt) { FocusPerms.openBatteryExempt(ctx) }
            }

            SettingsGroup(title = "اشتراک‌گذاری") {
                SettingsSwitchRow(
                    icon = Icons.Rounded.Groups,
                    title = "اشتراک نشست‌ها با سرور",
                    subtitle = "برای آمار و رتبه‌بندی",
                    checked = cfg.shareToServer,
                    onChange = { v -> FocusLock.updateConfig { it.copy(shareToServer = v) } },
                )
                SettingsSwitchRow(
                    icon = Icons.Rounded.Lock,
                    title = "انتشار گزارش قفل در صفحهٔ اجتماعی",
                    subtitle = "فقط نشست‌های بالای ۲ ساعت منتشر می‌شوند",
                    checked = cfg.shareReports,
                    onChange = { v -> FocusLock.updateConfig { it.copy(shareReports = v) } },
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    if (showStart) FocusStartDialog(onDismiss = { showStart = false })

    val editing = editSchedule
    if (editing != null) {
        ScheduleDialog(
            initial = editing,
            onDismiss = { editSchedule = null },
            onSave = { s ->
                FocusLock.updateConfig { c ->
                    val others = c.schedules.filter { it.id != s.id }
                    c.copy(schedules = (others + s).sortedBy { it.minuteOfDay })
                }
                FocusLock.syncSchedules(ctx)
                editSchedule = null
            },
        )
    }
}

private fun secLabel(sec: Int): String =
    if (sec >= 60) (sec / 60).toString() + " دقیقه" + (if (sec % 60 != 0) " و " + (sec % 60).toString() + " ثانیه" else "")
    else sec.toString() + " ثانیه"

@Composable
private fun PermRow(title: String, granted: Boolean, onClick: () -> Unit) {
    val ok = Color(0xFF10B981)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(10.dp))
                .background((if (granted) ok else Color(0xFFF59E0B)).copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.Lock,
                contentDescription = null,
                tint = if (granted) ok else Color(0xFFF59E0B),
                modifier = Modifier.size(17.dp),
            )
        }
        Spacer(Modifier.size(12.dp))
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        if (granted) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(ok.copy(alpha = 0.12f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("✓ داده شد", style = MaterialTheme.typography.labelMedium, color = ok, fontWeight = FontWeight.Bold)
            }
        } else {
            Box(
                Modifier
                    .bouncyClick(onClick = onClick)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFFB7185))))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
            ) {
                Text("دادن دسترسی", style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** کارت راه‌اندازی/دسترسی ناقص بالای صفحه. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SetupNotice(
    onboarded: Boolean,
    missing: List<String>,
    onGrant: () -> Unit,
    onGuide: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val amber = Color(0xFFF59E0B)
    val rose = Color(0xFFFB7185)
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(amber.copy(alpha = 0.16f), rose.copy(alpha = 0.07f))))
            .border(1.dp, Brush.linearGradient(listOf(amber.copy(alpha = 0.55f), rose.copy(alpha = 0.25f))), shape)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(amber, rose))),
                contentAlignment = Alignment.Center,
            ) { Text(if (!onboarded) "🧭" else "🔑", fontSize = 19.sp) }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (!onboarded) "راهنمای راه‌اندازی را یک بار ببین"
                    else "برای این حالت، دسترسی کامل نیست",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    if (!onboarded) "دو دقیقه وقت می‌گیرد و قفل را محکم می‌کند"
                    else "بدون این دسترسی‌ها، قفل فقط نیمه‌کاره کار می‌کند",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (missing.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                missing.forEach { FocusInfoChip(it, MaterialTheme.colorScheme.error, warn = true) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (missing.isNotEmpty()) {
                FocusGlowButton(
                    "دادن دسترسی در تنظیمات",
                    onClick = onGrant,
                    colors = listOf(amber, rose),
                    height = 42.dp,
                )
            }
            TextButton(onClick = onGuide) { Text("راهنما") }
        }
    }
}

/** یک زمان‌بندی: ساعت درشت در نشانِ رنگِ حالت، روزها و کلید. */
@Composable
private fun ScheduleRow(s: FocusSchedule, onOpen: () -> Unit, onToggle: (Boolean) -> Unit, onDelete: () -> Unit) {
    val c1 = focusModeColor(s.mode)
    val c2 = focusModeColor2(s.mode)
    val k = if (s.enabled) 1f else 0.45f
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(c1.copy(alpha = 0.9f * k), c2.copy(alpha = 0.9f * k))))
                .padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(s.clock().fa(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                (s.minutes.toString() + " دقیقه · " + s.mode.emoji + " " + s.mode.title).fa(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                FocusScheduler.daysLabel(s.days).fa(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        GlowSwitch(checked = s.enabled, onCheckedChange = onToggle, accent = c1, accent2 = c2)
        IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "حذف") }
    }
}

/** ویرایش یک زمان‌بندی: ساعت، مدت، روزها و حالت. */
@Composable
private fun ScheduleDialog(
    initial: FocusSchedule,
    onDismiss: () -> Unit,
    onSave: (FocusSchedule) -> Unit,
) {
    var hour by remember { mutableIntStateOf(initial.hour) }
    var minute by remember { mutableIntStateOf(initial.minute) }
    var minutes by remember { mutableIntStateOf(initial.minutes) }
    var mode by remember { mutableStateOf(initial.mode) }
    var days by remember { mutableStateOf(initial.days) }

    val dayList = listOf(
        Calendar.SATURDAY to "ش",
        Calendar.SUNDAY to "ی",
        Calendar.MONDAY to "د",
        Calendar.TUESDAY to "س",
        Calendar.WEDNESDAY to "چ",
        Calendar.THURSDAY to "پ",
        Calendar.FRIDAY to "ج",
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("زمان‌بندی قفل") },
        text = {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                Text(("ساعت: " + pad(hour) + ":" + pad(minute)).fa())
                Slider(
                    value = hour.toFloat(),
                    onValueChange = { hour = it.toInt().coerceIn(0, 23) },
                    valueRange = 0f..23f,
                    steps = 22,
                )
                Slider(
                    value = minute.toFloat(),
                    onValueChange = { minute = (it.toInt() / 5) * 5 },
                    valueRange = 0f..55f,
                    steps = 10,
                )
                Spacer(Modifier.height(6.dp))
                Text(("مدت: " + minutes.toString() + " دقیقه").fa())
                Slider(
                    value = minutes.toFloat(),
                    onValueChange = { minutes = ((it.toInt() / 5) * 5).coerceIn(5, 480) },
                    valueRange = 5f..480f,
                )
                Spacer(Modifier.height(6.dp))
                Text("روزها", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for ((d, label) in dayList) {
                        FilterChip(
                            selected = days.contains(d),
                            onClick = { days = if (days.contains(d)) days - d else days + d },
                            label = { Text(label) },
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("حالت", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                FocusModePicker(selected = mode, onSelect = { mode = it }, compact = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    initial.copy(
                        minuteOfDay = hour * 60 + minute,
                        minutes = minutes,
                        mode = mode,
                        days = days,
                        enabled = true,
                    ),
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

private fun pad(v: Int): String = if (v < 10) "0" + v.toString() else v.toString()
