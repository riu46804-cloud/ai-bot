package ir.studying.app.ui.focus

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusMode
import ir.studying.app.focus.FocusPerms
import ir.studying.app.ui.components.GlassPill
import ir.studying.app.ui.components.GlowSwitch
import ir.studying.app.ui.components.RollingText
import ir.studying.app.ui.components.bouncyClick
import java.util.Calendar
import java.util.Locale

/**
 * دیالوگ شروع نشست تمرکز.
 *
 * دو انتخاب: مدت (چند گزینهٔ سریع + عدد دلخواه از ۵ تا ۴۸۰ دقیقه) و حالت قفل.
 * پروفایل‌های نرم/متمرکز/بی‌رحم حذف شدند: دو لایهٔ موازی برای شدت قفل، فقط گیجی می‌ساخت.
 *
 * نسخهٔ ۲.۹: سربرگِ گاوصندوقی با قفلی که «کلیک» می‌کند، عدد غلتانِ مدت با
 * دکمه‌های کم/زیاد، ساعتِ پایانِ نشست و کلیدهای درخشان. منطق شروع دست نخورده.
 */
@Composable
fun FocusStartDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cfg by FocusLock.config.collectAsState()
    var minutes by remember { mutableIntStateOf(cfg.defaultMinutes) }
    var custom by remember { mutableStateOf(cfg.defaultMinutes.toString()) }
    var mode by remember { mutableStateOf(cfg.mode) }
    /* این دو انتخاب مخصوص همین نشست‌اند: در لحظهٔ وسوسه تصمیم‌گرفتن بی‌فایده
       است، پس قبل از شروع پرسیده می‌شود. */
    var allowExit by remember { mutableStateOf(cfg.allowExit) }
    var allowBreaks by remember { mutableStateOf(cfg.allowBreaks && cfg.breakLimit > 0) }

    val engine = remember { FocusPerms.engine(ctx) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        FocusStartBody(
            minutes = minutes,
            custom = custom,
            onMinutes = { m ->
                minutes = m
                custom = m.toString()
            },
            onCustom = { raw ->
                // ارقام فارسی را هم قبول کن.
                val en = raw.map { ch ->
                    when (ch) {
                        in '\u06F0'..'\u06F9' -> ('0' + (ch - '\u06F0'))
                        in '\u0660'..'\u0669' -> ('0' + (ch - '\u0660'))
                        else -> ch
                    }
                }.joinToString("").filter { it.isDigit() }.take(3)
                custom = en
                en.toIntOrNull()?.let { minutes = it }
            },
            mode = mode,
            onMode = { mode = it },
            allowExit = allowExit,
            onAllowExit = { allowExit = it },
            allowBreaks = allowBreaks,
            onAllowBreaks = { allowBreaks = it },
            breakLimit = cfg.breakLimit,
            engineMissing = engine == FocusPerms.Engine.NONE && mode.needsAppEngine,
            onStart = {
                val m = minutes.coerceIn(FocusLock.MIN_MINUTES, FocusLock.MAX_MINUTES)
                FocusLock.updateConfig {
                    it.copy(
                        defaultMinutes = m,
                        mode = mode,
                        allowExit = allowExit,
                        allowBreaks = allowBreaks,
                    )
                }
                FocusLock.start(ctx, m, mode = mode)
                onDismiss()
            },
            onDismiss = onDismiss,
        )
    }
}

private val PRESETS = listOf(15, 25, 50, 90, 120)

/** بدنهٔ بی‌حالتِ دیالوگ شروع. */
@Composable
internal fun FocusStartBody(
    minutes: Int,
    custom: String,
    onMinutes: (Int) -> Unit,
    onCustom: (String) -> Unit,
    mode: FocusMode,
    onMode: (FocusMode) -> Unit,
    allowExit: Boolean,
    onAllowExit: (Boolean) -> Unit,
    allowBreaks: Boolean,
    onAllowBreaks: (Boolean) -> Unit,
    breakLimit: Int,
    engineMissing: Boolean,
    onStart: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val a1 by animateColorAsState(focusModeColor(mode), tween(450), label = "startA1")
    val a2 by animateColorAsState(focusModeColor2(mode), tween(450), label = "startA2")
    val shape = RoundedCornerShape(30.dp)
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.92f).dp
    val safe = minutes.coerceIn(FocusLock.MIN_MINUTES, FocusLock.MAX_MINUTES)
    val endClock = remember(safe) {
        val c = Calendar.getInstance().apply { add(Calendar.MINUTE, safe) }
        String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    Column(
        modifier
            .padding(horizontal = 14.dp)
            .widthIn(max = 520.dp)
            .fillMaxWidth()
            .heightIn(max = maxH)
            .clip(shape)
            .background(cs.surface)
            .border(1.dp, Brush.linearGradient(listOf(a1.copy(alpha = 0.55f), cs.outlineVariant.copy(alpha = 0.3f), a2.copy(alpha = 0.45f))), shape),
    ) {
        /* ---------- سربرگ ---------- */
        Box(Modifier.fillMaxWidth().height(132.dp)) {
            VaultBackdrop(a1, a2, Modifier.matchParentSize(), stars = 22)
            Row(Modifier.fillMaxSize().padding(start = 20.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("شروع حالت تمرکز", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        ("قفل تا ساعت " + endClock + " می‌مونه").fa(),
                        color = Color.White.copy(alpha = 0.74f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    GlassPill(mode.title, leading = mode.emoji, style = MaterialTheme.typography.labelSmall)
                }
                LockingPadlockScene(a1, a2, Modifier.size(100.dp))
            }
        }

        /* ---------- محتوا ---------- */
        // سه کارتِ حالت جا را پر می‌کنند؛ بدون اسکرول، روی گوشی‌های کوچک دکمه‌ها بیرون می‌افتند.
        Column(
            Modifier
                .weight(1f, fill = false)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
        ) {
            SectionLabel("⏱", "چقدر؟")
            Spacer(Modifier.height(8.dp))
            DurationStepper(minutes = minutes, onSet = onMinutes, a1 = a1, a2 = a2)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PRESETS.forEach { m ->
                    PresetChip(m.fa(), selected = minutes == m, a1 = a1, a2 = a2, modifier = Modifier.weight(1f)) { onMinutes(m) }
                }
            }

            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = custom,
                onValueChange = onCustom,
                label = { Text("یا زمان دلخواه (دقیقه)") },
                supportingText = {
                    Text(
                        ("بین " + FocusLock.MIN_MINUTES + " تا " + FocusLock.MAX_MINUTES + " دقیقه").fa(),
                        style = MaterialTheme.typography.bodySmall,
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(10.dp))
            SectionLabel("🛡️", "چه نوع قفلی؟")
            Spacer(Modifier.height(8.dp))
            // همان کارت‌های بخش تنظیمات، فقط جمع‌وجورتر — تا انتخاب حالت همه‌جا یک شکل باشد.
            FocusModePicker(selected = mode, onSelect = onMode, compact = true)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FocusIntensityBars(mode)
                Spacer(Modifier.width(8.dp))
                Text(mode.keepsOpen, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }

            Spacer(Modifier.height(16.dp))
            SectionLabel("🚪", "راه‌های برگشت")
            Spacer(Modifier.height(6.dp))
            StartToggleRow(
                emoji = "🆘",
                title = "امکان خروج اضطراری",
                subtitle = if (allowExit) "با چالش خروج می‌توانی نشست را نیمه‌کاره تمام کنی"
                else "هیچ راه خروجی نیست؛ نشست فقط با پایان زمان تمام می‌شود",
                checked = allowExit,
                onChange = onAllowExit,
                a1 = a1,
                a2 = a2,
            )
            StartToggleRow(
                emoji = "☕",
                title = "امکان استراحت کوتاه",
                subtitle = if (allowBreaks) "تا " + breakLimit.toString().fa() + " استراحت در این نشست"
                else "بدون استراحت",
                checked = allowBreaks,
                onChange = onAllowBreaks,
                a1 = a1,
                a2 = a2,
            )
            AnimatedVisibility(
                visible = !allowExit,
                enter = expandVertically(tween(260)) + fadeIn(tween(220)),
                exit = shrinkVertically(tween(200)) + fadeOut(tween(150)),
            ) {
                WarnBox("حواست باشد: با خاموش بودن خروج، تا پایان زمان هیچ‌کس نمی‌تواند قفل را باز کند.")
            }
            if (engineMissing) {
                WarnBox("الان فقط بخش‌های خودِ اپ قفل می‌شوند. برای قفل اپ‌های دیگر، از تنظیمات قفل دسترسی بده.")
            }
        }

        /* ---------- دکمه‌ها ---------- */
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 18.dp, top = 4.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TextButton(onClick = onDismiss) { Text("انصراف") }
            FocusGlowButton(
                ("شروع قفل " + safe.toString() + " دقیقه‌ای").fa(),
                onClick = onStart,
                modifier = Modifier.weight(1f),
                colors = listOf(a1, a2),
                icon = Icons.Rounded.Lock,
            )
        }
    }
}

@Composable
private fun SectionLabel(emoji: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 14.sp)
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

/** عدد درشتِ غلتان با دکمه‌های کم/زیاد (گام‌های ۵ دقیقه‌ای). */
@Composable
private fun DurationStepper(minutes: Int, onSet: (Int) -> Unit, a1: Color, a2: Color) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    val min = FocusLock.MIN_MINUTES
    val max = FocusLock.MAX_MINUTES
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(a1.copy(alpha = 0.13f), a2.copy(alpha = 0.06f))))
            .border(1.dp, a1.copy(alpha = 0.28f), shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StepButton(Icons.Rounded.Remove, "کمتر", enabled = minutes > min, tint = a1) {
            onSet((((minutes - 1) / 5) * 5).coerceIn(min, max))
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            RollingText(
                minutes.coerceAtLeast(0).toString().fa(),
                style = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.Black, letterSpacing = 0.sp),
                color = cs.onSurface,
            )
            Text(durationWords(minutes), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
        StepButton(Icons.Rounded.Add, "بیشتر", enabled = minutes < max, tint = a2) {
            onSet((((minutes / 5) + 1) * 5).coerceIn(min, max))
        }
    }
}

private fun durationWords(m: Int): String {
    if (m < 60) return "دقیقه"
    val h = m / 60
    val r = m % 60
    return ("دقیقه · " + h.toString() + " ساعت" + (if (r > 0) " و " + r.toString() + " دقیقه" else "")).fa()
}

@Composable
private fun StepButton(icon: ImageVector, label: String, enabled: Boolean, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .bouncyClick(enabled = enabled, pressedScale = 0.88f, onClick = onClick)
            .graphicsLayer { alpha = if (enabled) 1f else 0.35f }
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.16f))
            .border(1.dp, tint.copy(alpha = 0.35f), CircleShape),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun PresetChip(label: String, selected: Boolean, a1: Color, a2: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val k by animateFloatAsState(if (selected) 1f else 0f, tween(220), label = "preset")
    Box(
        modifier
            .bouncyClick(pressedScale = 0.92f, onClick = onClick)
            .clip(CircleShape)
            .background(cs.surfaceVariant.copy(alpha = 0.75f * (1f - k)))
            .background(Brush.horizontalGradient(listOf(a1.copy(alpha = k), a2.copy(alpha = k))))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f * (1f - k)), CircleShape)
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = lerp(cs.onSurface, Color.White, k),
            fontWeight = if (selected) FontWeight.Black else FontWeight.Medium,
            fontSize = 15.sp,
        )
    }
}

/** ردیف کلید روشن/خاموش در دیالوگ شروع. */
@Composable
private fun StartToggleRow(
    emoji: String,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    a1: Color,
    a2: Color,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(shape)
            .background(cs.surfaceVariant.copy(alpha = 0.5f))
            .clickable { onChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(a1.copy(alpha = if (checked) 0.20f else 0.10f)),
            contentAlignment = Alignment.Center,
        ) { Text(emoji, fontSize = 16.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        GlowSwitch(checked = checked, onCheckedChange = onChange, accent = a1, accent2 = a2)
    }
}

@Composable
internal fun WarnBox(text: String, color: Color = MaterialTheme.colorScheme.error) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(shape)
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.25f), shape)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.WarningAmber, null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = color)
    }
}
