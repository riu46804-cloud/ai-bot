package ir.studying.app.ui.focus

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import ir.studying.app.focus.PermState
import kotlinx.coroutines.delay

/**
 * وضعیت دسترسی‌ها به شکل زنده.
 *
 * مشکل نسخهٔ قبلی: کاربر دسترسی را در تنطیمات می‌داد، برمی‌گشت، و اپ هنوز
 * می‌گفت «داده نشده». اینجا هر بار که صفحه به جلو می‌آید (ON_RESUME) و همچنین
 * هر ۱ ثانیه تا زمانی که صفحه باز است، واقعیت را از سیستم می‌خوانیم.
 */
@Composable
fun rememberPermState(): State<PermState.Snap> {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current

    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                PermState.invalidate()
                PermState.refresh(ctx)
            }
        }
        owner.lifecycle.addObserver(obs)
        PermState.refresh(ctx)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(Unit) {
        while (true) {
            PermState.refresh(ctx)
            delay(1000L)
        }
    }

    return PermState.state.collectAsState()
}
