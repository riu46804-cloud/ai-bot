package ir.studying.app.ui.focus

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.focus.FocusMode
import ir.studying.app.focus.PhoneShortcuts
import ir.studying.app.ui.components.RippleRings
import ir.studying.app.ui.components.bouncyClick

/**
 * منوی اضطراری در حالت «همه‌چیز جز تماس و پیامک».
 *
 * اپ عمداً هیچ مخاطب، پیامک یا تاریخچهٔ تماسی را نمی‌خواند — هیچ دسترسی حساسی
 * هم ندارد. فقط اپ تلفن/پیامک پیش‌فرض گوشی را باز می‌کند، و این دو اپ در این
 * حالت از لیست قفل معافند.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneMenuScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var number by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تماس و پیامک") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowForward, contentDescription = "بازگشت")
                    }
                },
            )
        },
    ) { padding ->
        PhoneMenuBody(
            number = number,
            onNumber = { number = it.filter { c -> c.isDigit() || c == '+' || c == '*' || c == '#' } },
            onDialer = { PhoneShortcuts.openDialer(ctx) },
            onSms = { PhoneShortcuts.openSms(ctx) },
            onDial = { PhoneShortcuts.dial(ctx, number) },
            modifier = Modifier.padding(padding),
        )
    }
}

@Composable
internal fun PhoneMenuBody(
    number: String,
    onNumber: (String) -> Unit,
    onDialer: () -> Unit,
    onSms: () -> Unit,
    onDial: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c1 = focusModeColor(FocusMode.ALL_BUT_CALLS)
    val c2 = focusModeColor2(FocusMode.ALL_BUT_CALLS)
    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        VaultCard(c1, c2, corner = 26.dp, stars = 20) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "در این حالت فقط تماس و پیامک باز می‌شود",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "اپ مخاطبین و پیامک‌های تو را نمی‌خواند؛ فقط برنامهٔ تلفن و پیامکِ خود گوشی را برایت باز می‌کند.",
                        color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text("📵", fontSize = 40.sp)
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigActionTile("تماس", Icons.Rounded.Call, listOf(Color(0xFF34D399), Color(0xFF059669)), onDialer, Modifier.weight(1f))
            BigActionTile("پیامک", Icons.Rounded.Chat, listOf(Color(0xFF60A5FA), Color(0xFF6366F1)), onSms, Modifier.weight(1f))
        }

        Spacer(Modifier.height(22.dp))
        Text("تماس سریع با شماره", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = number,
                onValueChange = onNumber,
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                label = { Text("شماره") },
            )
            FocusGlowButton(
                "شماره‌گیری",
                onClick = onDial,
                enabled = number.length >= 3,
                colors = listOf(Color(0xFF34D399), Color(0xFF22D3EE)),
                icon = Icons.Rounded.Call,
                height = 52.dp,
            )
        }
    }
}

@Composable
private fun BigActionTile(label: String, icon: ImageVector, colors: List<Color>, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .bouncyClick(pressedScale = 0.94f, onClick = onClick)
            .height(132.dp)
            .clip(shape)
            .background(Brush.linearGradient(colors))
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
            RippleRings(Modifier.matchParentSize(), color = Color.White, rings = 2, periodMs = 2400, strokeWidth = 1.5.dp)
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
    }
}
