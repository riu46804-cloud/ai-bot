package ir.studying.app.ui.focus

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.UnlockTexts
import ir.studying.app.ui.components.RollingText
import kotlinx.coroutines.delay

/**
 * چالش باز کردن قفل.
 *
 * دو مرحله: اول باید متن تعهد را دقیق تایپ کنی (کپی/پیست هم فایده‌ای ندارد چون
 * بعدش شمارش معکوس می‌آید)، بعد باید تا پایان تأخیر صبر کنی.
 *
 * فلسفه: خروج باید سخت باشد ولی غیرممکن نه. قفلی که واقعاً باز نشود، روزی که
 * کاربر واقعاً به گوشیش نیاز دارد می‌شود فاجعه.
 *
 * نسخهٔ ۲.۹: متن تعهد همان‌طور که تایپ می‌شود سبز می‌شود و اولین نویسهٔ غلط
 * قرمز؛ قفل با هر اشتباه می‌لرزد و در مرحلهٔ صبر کم‌کم باز می‌شود. پررنگ‌ترین
 * دکمه عمداً «منصرف شدم» است.
 */
@Composable
fun UnlockChallengeDialog(
    onDismiss: () -> Unit,
    onUnlocked: () -> Unit,
) {
    val expected = remember { FocusLock.unlockText() }
    val delaySec = remember { FocusLock.unlockDelaySec() }
    var typed by remember { mutableStateOf("") }
    var waiting by remember { mutableStateOf(false) }
    var left by remember { mutableIntStateOf(delaySec) }

    LaunchedEffect(waiting) {
        if (!waiting) return@LaunchedEffect
        while (left > 0) {
            delay(1000L)
            left -= 1
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        UnlockChallengeBody(
            expected = expected,
            typed = typed,
            onTyped = { typed = it },
            waiting = waiting,
            left = left,
            delaySec = delaySec,
            onContinue = { if (delaySec <= 0) onUnlocked() else waiting = true },
            onUnlock = onUnlocked,
            onDismiss = onDismiss,
        )
    }
}

private val DangerA = Color(0xFFFB7185)
private val DangerB = Color(0xFFF97316)
private val OkGreen = Color(0xFF10B981)

/**
 * چند نویسه از ابتدای متن اصلی درست تایپ شده، و آیا بعد از آن اشتباهی هست.
 *
 * مقایسه روی همان شکلِ ساده‌شدهٔ [UnlockTexts.normalize] انجام می‌شود (بزرگی و
 * کوچکی، فاصله‌های پشت‌سرهم، نویسه‌های عربی/فارسی) تا رنگ‌ها دقیقاً با چیزی
 * که دکمهٔ «ادامه» را فعال می‌کند هم‌خوان باشند.
 */
internal fun typedProgress(expected: String, typed: String): Pair<Int, Boolean> {
    val e = UnlockTexts.normalize(expected)
    val t = UnlockTexts.normalize(typed)
    var k = 0
    while (k < e.length && k < t.length && e[k] == t[k]) k++
    val error = k < t.length
    // نگاشت طول نرمال‌شده به اندیسِ متن اصلی
    var n = 0
    var i = 0
    var lastSep = true
    while (i < expected.length && n < k) {
        val ch = expected[i]
        val sep = ch.isWhitespace() || ch == '\u200C' || ch in ".,!?؟«»\"'()\u060C\u061B"
        if (sep) {
            if (!lastSep) {
                n++
                lastSep = true
            }
        } else {
            n++
            lastSep = false
        }
        i++
    }
    return i.coerceAtMost(expected.length) to error
}

/** بدنهٔ بی‌حالتِ چالش؛ برای پیش‌نمایش هم استفاده می‌شود. */
@Composable
internal fun UnlockChallengeBody(
    expected: String,
    typed: String,
    onTyped: (String) -> Unit,
    waiting: Boolean,
    left: Int,
    delaySec: Int,
    onContinue: () -> Unit,
    onUnlock: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val ok = UnlockTexts.matches(expected, typed)
    val (matched, error) = remember(expected, typed) { typedProgress(expected, typed) }
    val frac = if (expected.isEmpty()) 0f else (matched.toFloat() / expected.length).coerceIn(0f, 1f)
    val typedFrac by animateFloatAsState(if (ok) 1f else frac, tween(260), label = "typedFrac")
    val waitFrac = if (delaySec <= 0) 1f else (1f - left.toFloat() / delaySec.toFloat()).coerceIn(0f, 1f)
    val shape = RoundedCornerShape(30.dp)
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.92f).dp

    // لرزش قفل با هر اشتباه
    val shake = remember { Animatable(0f) }
    LaunchedEffect(error, typed.length) {
        if (error) {
            for (x in listOf(7f, -7f, 5f, -5f, 2f, 0f)) shake.animateTo(x, tween(45))
        }
    }

    Column(
        modifier
            .padding(horizontal = 14.dp)
            .widthIn(max = 520.dp)
            .fillMaxWidth()
            .heightIn(max = maxH)
            .clip(shape)
            .background(cs.surface)
            .border(1.dp, Brush.linearGradient(listOf(DangerA.copy(alpha = 0.5f), cs.outlineVariant.copy(alpha = 0.3f), DangerB.copy(alpha = 0.4f))), shape),
    ) {
        /* ---------- سربرگ ---------- */
        Box(Modifier.fillMaxWidth().height(124.dp)) {
            VaultBackdrop(DangerA, DangerB, Modifier.matchParentSize(), stars = 18, seed = 21)
            Row(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = waiting,
                        transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(160)) },
                        label = "unlockTitle",
                    ) { w ->
                        Text(
                            if (w) "کمی صبر کن…" else "باز کردن قفل",
                            color = Color.White,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Black,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    StepTrack(step = if (waiting) 2 else 1)
                }
                Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                    AnimatedPadlock(
                        open = if (waiting) waitFrac else 0.08f * typedFrac,
                        size = 64.dp,
                        colors = listOf(Color(0xFFFECDD3), DangerA, Color(0xFFBE123C)),
                        glow = DangerB,
                        modifier = Modifier.graphicsLayer { translationX = shake.value * density },
                    )
                }
            }
        }

        /* ---------- محتوا ---------- */
        Column(
            Modifier
                .weight(1f, fill = false)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
        ) {
            if (!waiting) {
                Text(
                    "برای شکستن قفل، این متن را دقیق تایپ کن (بزرگی/کوچکی حروف و نقطه‌گذاری مهم نیست):",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                val annotated = buildAnnotatedString {
                    withStyle(SpanStyle(color = OkGreen)) { append(expected.substring(0, matched)) }
                    if (matched < expected.length) {
                        withStyle(
                            SpanStyle(
                                color = if (error) cs.error else cs.onSurface,
                                background = (if (error) cs.error else DangerB).copy(alpha = 0.18f),
                                textDecoration = TextDecoration.Underline,
                            ),
                        ) { append(expected.substring(matched, matched + 1)) }
                        withStyle(SpanStyle(color = cs.onSurfaceVariant)) { append(expected.substring(matched + 1)) }
                    }
                }
                val cardShape = RoundedCornerShape(18.dp)
                Text(
                    annotated,
                    style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 26.sp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(cardShape)
                        .background(cs.surfaceVariant.copy(alpha = 0.6f))
                        .border(1.dp, (if (error) cs.error else if (ok) OkGreen else cs.outlineVariant).copy(alpha = 0.5f), cardShape)
                        .padding(14.dp),
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .weight(1f)
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(cs.onSurfaceVariant.copy(alpha = 0.12f)),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(typedFrac)
                                .fillMaxHeight()
                                .clip(CircleShape)
                                .background(Brush.horizontalGradient(listOf(StayA, OkGreen))),
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        ((typedFrac * 100).toInt().toString() + "٪").fa(),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (ok) OkGreen else cs.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = typed,
                    onValueChange = onTyped,
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    isError = typed.isNotBlank() && error,
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("متن را اینجا تایپ کن") },
                    /* کیبورد باید در همین صفحه بماند؛ قبلاً باز شدن کیبورد
                       «اپ غریبه» تشخیص داده می‌شد و اپ بسته می‌شد. آن ایراد
                       در نگهبان رفع شد و این‌جا فقط تایپ چندخطی ساده است. */
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        autoCorrect = false,
                        capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.None,
                    ),
                )
                if (delaySec > 0) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        ("⏳ پس از تایپ درست، " + delaySec.toString() + " ثانیه تأخیر هم دارد.").fa(),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    VaultBackdrop(DangerB, DangerA, Modifier.matchParentSize(), stars = 16, seed = 31)
                    VaultDial(
                        progress = waitFrac,
                        colors = listOf(DangerB, DangerA),
                        modifier = Modifier.padding(vertical = 12.dp).size(210.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            RollingText(
                                left.coerceAtLeast(0).toString().fa(),
                                style = TextStyle(fontSize = 46.sp, fontWeight = FontWeight.Black),
                                color = Color.White,
                            )
                            Text("ثانیه تا پایان تأخیر", color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "اگر نظرت عوض شد، همین الان ببند و برگرد سر درس.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        /* ---------- دکمه‌ها ---------- */
        Row(
            Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, top = 4.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FocusGlowButton(
                "منصرف شدم",
                onClick = onDismiss,
                modifier = Modifier.weight(1f),
                colors = listOf(StayA, StayB),
                icon = Icons.Rounded.Shield,
            )
            if (!waiting) {
                TextButton(enabled = ok, onClick = onContinue) { Text("ادامه") }
            } else {
                TextButton(enabled = left <= 0, onClick = onUnlock) { Text("باز کن") }
            }
        }
    }
}

/** دو مرحلهٔ چالش: «تایپ تعهد» و «صبر». */
@Composable
private fun StepTrack(step: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        StepBubble(1, "تایپ تعهد", active = step == 1, done = step > 1)
        Box(
            Modifier
                .padding(horizontal = 6.dp)
                .width(22.dp)
                .height(2.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = if (step > 1) 0.8f else 0.25f)),
        )
        StepBubble(2, "صبر", active = step == 2, done = false)
    }
}

@Composable
private fun StepBubble(n: Int, label: String, active: Boolean, done: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(if (active || done) Color.White else Color.White.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (done) "✓" else n.fa(),
                color = if (active || done) DangerA else Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
            )
        }
        Spacer(Modifier.width(5.dp))
        Text(
            label,
            color = Color.White.copy(alpha = if (active) 1f else 0.6f),
            fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
        )
    }
}
