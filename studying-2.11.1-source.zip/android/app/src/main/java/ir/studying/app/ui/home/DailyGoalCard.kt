package ir.studying.app.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Goals
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AppCard
import ir.studying.app.ui.theme.AppRadius

/**
 * هدف امروز — نوار پیشرفتِ زنده.
 *
 * چرا دوباره عوض شد: نسخهٔ قبلی یک حلقهٔ ۶۶ پیکسلی داشت که کارت را بلند
 * می‌کرد و بالای صفحهٔ خانه جای زیادی می‌گرفت، در حالی که پیشرفت روز یک عدد
 * خطی است و نوار برایش گویاتر از حلقه است. حالا کارت کوتاه‌تر است و نوار
 * پیشرفت جان دارد: پرشدنش انیمیشن دارد، یک برقِ متحرک رویش می‌لغزد، سرِ نوار
 * یک گویِ نورانی دارد و نشانه‌های ۲۵٪ / ۵۰٪ / ۷۵٪ رویش دیده می‌شود.
 */
@Composable
fun DailyGoalCard(todayMinutes: Int) {
    val goal by Goals.daily.collectAsState()
    var picking by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    AppCard {
        if (goal <= 0) {
            /* هدف پیش‌فرض نداریم: تا کاربر خودش عدد را نگوید، اپ عددی از خودش
               درنمی‌آورد. کارت به‌جای نمودار، دعوت به تعیین هدف است. */
            Row(
                Modifier.fillMaxWidth().clickable { picking = true }.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(38.dp).background(cs.primary.copy(alpha = 0.14f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Flag, null, tint = cs.primary, modifier = Modifier.size(19.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("هدف روزانه نداری", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "امروز " + Goals.label(todayMinutes) + " خوانده‌ای",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                Surface(shape = CircleShape, color = cs.primary) {
                    Text(
                        "تعیین هدف",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimary,
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
                    )
                }
            }
        } else {
            val pct = Goals.progress(todayMinutes, goal)
            val frac by animateFloatAsState(pct, tween(900, easing = FastOutSlowInEasing), label = "goalBar")
            val left = Goals.remaining(todayMinutes, goal)
            val done = left == 0

            // درصدِ نوشته‌شده هم‌قدمِ خودِ نوار بالا می‌رود تا عدد و تصویر یکی باشند.
            val shownPct = (frac * 100).toInt()

            Column(
                Modifier.fillMaxWidth().clickable { picking = true }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (done) Icons.Rounded.EmojiEvents else Icons.Rounded.Flag,
                        null,
                        tint = if (done) cs.tertiary else cs.primary,
                        modifier = Modifier.size(17.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (done) "هدف امروز کامل شد" else "هدف امروز",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        shownPct.fa() + "٪",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = if (done) cs.tertiary else cs.primary,
                    )
                }

                Spacer(Modifier.height(9.dp))
                GoalProgressBar(frac = frac, done = done)
                Spacer(Modifier.height(7.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        Goals.label(todayMinutes) + " از " + Goals.label(goal),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (done) "هر دقیقهٔ بعدی امتیاز اضافه است" else Goals.label(left) + " مانده",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (done) cs.tertiary else cs.onSurfaceVariant,
                    )
                }
            }
        }
    }

    if (picking) GoalPickerSheet(onDismiss = { picking = false })
}

/**
 * نوار پیشرفتِ هدف.
 *
 * چهار چیز رویش حرکت می‌کند و همین «زنده» نشانش می‌دهد:
 * ۱) پرشدن با انیمیشن نرم، ۲) برقی که مدام از چپ به راستِ بخش پرشده می‌لغزد،
 * ۳) گویِ نورانی سرِ نوار که آرام نفس می‌کشد، ۴) خط‌های ۲۵/۵۰/۷۵ درصد.
 * وقتی هدف کامل شد رنگ عوض می‌شود و کل نوار یک درخشش ملایم می‌گیرد.
 */
@Composable
private fun GoalProgressBar(frac: Float, done: Boolean) {
    val cs = MaterialTheme.colorScheme
    val inf = rememberInfiniteTransition(label = "goalBarAnim")
    val sweep by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1900, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep",
    )
    val glow by inf.animateFloat(
        0.75f, 1.15f,
        infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow",
    )

    val c1 = if (done) cs.tertiary else cs.primary
    val c2 = if (done) cs.primary else cs.secondary
    val track = cs.onSurfaceVariant.copy(alpha = 0.16f)

    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        val h = size.height
        val r = h / 2f
        val w = size.width

        // ریل خالی
        drawRoundRect(track, size = Size(w, h), cornerRadius = CornerRadius(r, r))

        val fw = (w * frac.coerceIn(0f, 1f)).coerceAtLeast(if (frac > 0f) h else 0f)
        if (fw > 0f) {
            clipRect(right = fw) {
                drawRoundRect(
                    Brush.horizontalGradient(listOf(c1, c2, c1), startX = 0f, endX = w),
                    size = Size(w, h),
                    cornerRadius = CornerRadius(r, r),
                )
                // برقِ متحرک: یک باند روشن که فقط داخل بخش پرشده دیده می‌شود
                val bandW = h * 3.2f
                val x = -bandW + (fw + bandW * 2) * sweep
                drawRoundRect(
                    Brush.horizontalGradient(
                        listOf(Color.White.copy(alpha = 0f), Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0f)),
                        startX = x,
                        endX = x + bandW,
                    ),
                    topLeft = Offset(x, 0f),
                    size = Size(bandW, h),
                    cornerRadius = CornerRadius(r, r),
                )
            }

            // گویِ نورانی سرِ نوار
            val cx = fw.coerceIn(r, w - r)
            drawCircle(c2.copy(alpha = 0.30f), radius = r * 1.75f * glow, center = Offset(cx, r))
            drawCircle(Color.White, radius = r * 0.62f, center = Offset(cx, r))
        }

        // نشانه‌های ربع‌ها؛ روی بخش پرشده سفیدِ کم‌رنگ و بیرونش خاکستری
        listOf(0.25f, 0.5f, 0.75f).forEach { t ->
            val x = w * t
            val inside = x < fw
            drawLine(
                if (inside) Color.White.copy(alpha = 0.40f) else cs.onSurfaceVariant.copy(alpha = 0.28f),
                start = Offset(x, h * 0.26f),
                end = Offset(x, h * 0.74f),
                strokeWidth = 2f,
                cap = StrokeCap.Round,
            )
        }
    }
}

/** انتخاب هدف روزانه؛ شیت پایین‌صفحه، هم‌شکل بقیهٔ انتخاب‌های اپ. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun GoalPickerSheet(onDismiss: () -> Unit) {
    val current by Goals.daily.collectAsState()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.padding(horizontal = 18.dp).padding(bottom = 28.dp)) {
            Text("هدف روزانه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "هر روز چقدر می‌خواهی بخوانی؟ هر وقت خواستی عوضش کن.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GoalChoiceGrid(current = current) { Goals.setDaily(it); onDismiss() }
            }
        }
    }
}

/** شبکهٔ گزینه‌های آماده. عدد آزاد در «تنظیمات ← هدف مطالعه» تعیین می‌شود. */
@Composable
fun GoalChoiceGrid(current: Int, onPick: (Int) -> Unit) {
    val choices = listOf(30, 60, 90, 120, 180, 240, 300, 360, 480)
    choices.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { m ->
                val selected = m == current
                Surface(
                    shape = AppRadius.chip,
                    color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.weight(1f).clickable { onPick(m) },
                ) {
                    Box(Modifier.padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                        Text(
                            Goals.label(m),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}
