package ir.studying.app.ui.home

import ir.studying.app.ui.components.AppSnack
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Api
import ir.studying.app.data.Course
import ir.studying.app.core.DayExport
import ir.studying.app.core.Fmt
import ir.studying.app.core.fa
import ir.studying.app.data.CourseMinutes
import ir.studying.app.data.HourlyPart
import ir.studying.app.data.StudyHistory
import ir.studying.app.data.StudyToday
import ir.studying.app.data.TaskItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

/** Everything known about one day, gathered from the endpoints that cover it. */
private data class DayProgram(
    val tasks: List<TaskItem> = emptyList(),
    val courses: List<CourseMinutes> = emptyList(),
    val sessions: List<HourlyPart> = emptyList(),
    /** Set when the breakdown is unavailable for this particular day. */
    val note: String? = null,
)

/**
 * The full programme for one calendar day, opened by tapping that day.
 *
 * A past day shows the study total, the per-course split, the session
 * timeline and the tasks. A future day has no history, so it deliberately
 * shows the planned tasks only rather than a misleading "zero minutes".
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun DayDetailSheet(
    dateIso: String,
    minutes: Int?,
    onDismiss: () -> Unit,
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var data by remember { mutableStateOf<DayProgram?>(null) }
    var busy by remember { mutableStateOf(false) }

    /* Editing a part has to refresh the day it belongs to, hence the reload key. */
    var reloadKey by remember { mutableStateOf(0) }
    var partMenu by remember { mutableStateOf<HourlyPart?>(null) }
    var partDetail by remember { mutableStateOf<HourlyPart?>(null) }
    var partPick by remember { mutableStateOf<HourlyPart?>(null) }
    var courses by remember { mutableStateOf<List<Course>>(emptyList()) }

    val fmt = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayIso = remember { fmt.format(Date()) }
    val yesterdayIso = remember {
        fmt.format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.time)
    }
    val isFuture = dateIso > todayIso
    val isToday = dateIso == todayIso

    LaunchedEffect(dateIso, reloadKey) {
        data = null
        val loaded = withContext(Dispatchers.IO) {
            // Tasks are split across three endpoints by tense, so all three are
            // merged and then filtered; whichever owns this day supplies it.
            val merged = LinkedHashMap<Int, TaskItem>()
            for (action in listOf("tasks", "tasks_history", "tasks_upcoming")) {
                runCatching { TaskItem.list(Api.arr(Api.get(action))) }
                    .getOrDefault(emptyList())
                    .forEach { merged[it.id] = it }
            }
            val tasks = merged.values
                .filter { it.date.take(10) == dateIso }
                .sortedBy { if (it.done) 1 else 0 }

            var courses = emptyList<CourseMinutes>()
            var sessions = emptyList<HourlyPart>()
            var note: String? = null

            // Every past day is now served in full by StudyHistory, which
            // asks the server for that exact date and falls back to window
            // differencing when the server has not been upgraded yet.
            if (!isFuture) {
                val d = runCatching { StudyHistory.forDate(dateIso) }.getOrNull()
                if (d != null) {
                    courses = d.courses
                    sessions = d.sessions
                    if (d.totalMinutes > 0 && !d.hasSessionTimeline) {
                        note = "خط زمانی جلسات برای این روز ثبت نشده"
                    }
                }
            }
            DayProgram(tasks, courses, sessions, note)
        }
        data = loaded
    }

    fun buildCard(d: DayProgram): DayExport.DayCard {
        val doneCount = d.tasks.count { it.done }
        val stats = buildList {
            if (!isFuture) add(DayExport.Stat("\u062f\u0631\u0633", d.courses.size.fa()))
            add(DayExport.Stat("\u062a\u0633\u06a9", d.tasks.size.fa()))
            if (d.tasks.isNotEmpty()) add(DayExport.Stat("\u0627\u0646\u062c\u0627\u0645\u200c\u0634\u062f\u0647", doneCount.fa()))
            if (!isFuture && d.sessions.isNotEmpty()) {
                add(DayExport.Stat("\u062c\u0644\u0633\u0647", d.sessions.size.fa()))
            }
        }
        return DayExport.DayCard(
            dayTitle = Fmt.jalaliWithDay(dateIso),
            daySubtitle = dateIso,
            totalLabel = if (isFuture) null else Fmt.minutes(minutes ?: 0),
            stats = stats,
            bars = d.courses.map { DayExport.Bar(it.name, it.minutes) },
            sessions = d.sessions.map {
                DayExport.Session(it.course, it.start + " - " + it.end, it.minutes)
            },
            tasks = d.tasks.map { DayExport.Task(it.title, it.done) },
            note = d.note,
        )
    }

    fun export(pdf: Boolean, d: DayProgram) {
        if (busy) return
        busy = true
        scope.launch {
            runCatching {
                val card = buildCard(d)
                val f = withContext(Dispatchers.IO) {
                    if (pdf) DayExport.writePdf(ctx, card, "studying-" + dateIso)
                    else DayExport.writePng(ctx, card, "studying-" + dateIso)
                }
                DayExport.share(ctx, f, if (pdf) "application/pdf" else "image/png")
            }.onFailure {
                AppSnack.show("\u062e\u0631\u0648\u062c\u06cc \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062f")
            }
            busy = false
        }
    }

    val menuPart = partMenu
    if (menuPart != null) {
        AlertDialog(
            onDismissRequest = { partMenu = null },
            title = { Text(menuPart.course) },
            text = {
                Column {
                    Text(
                        Fmt.minutes(menuPart.minutes) + " · " + menuPart.start + " - " + menuPart.end,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if ((menuPart.courseId ?: 0) > 0) TextButton(onClick = {
                        partMenu = null
                        partDetail = menuPart
                    }) { Text("ویرایش گزارش مطالعه") }
                    else Text("برای ثبت جزئیات، اول درس این پارت را مشخص کن.", style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val part = menuPart
                    partMenu = null
                    scope.launch {
                        runCatching {
                            courses = ir.studying.app.core.CourseCache.peek()
                                .ifEmpty { ir.studying.app.core.CourseCache.refresh() }
                        }
                        partPick = part
                    }
                }) { Text("تغییر درس") }
            },
            dismissButton = {
                TextButton(onClick = {
                    val id = menuPart.id
                    partMenu = null
                    scope.launch {
                        val r = withContext(Dispatchers.IO) {
                            runCatching { Api.get("study_part_delete", "id" to id.toString()) }
                        }
                        if (r.isSuccess) {
                            AppSnack.show("پارت حذف شد")
                            ir.studying.app.core.RefreshBus.emit("study")
                            reloadKey += 1
                        } else {
                            AppSnack.show("حذف نشد")
                        }
                    }
                }) { Text("حذف پارت") }
            },
        )
    }

    partDetail?.let { part ->
        ir.studying.app.ui.study.StudyDetailSheet(
            courseId = part.courseId ?: 0,
            minutes = part.minutes,
            initial = part.detail ?: ir.studying.app.data.StudyDetail(),
            confirmText = "ذخیرهٔ تغییرات گزارش",
            onDismiss = { partDetail = null },
            onConfirm = { _, detail ->
                partDetail = null
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching { ir.studying.app.data.TopicRepo.updatePart(part.id, detail) }
                    }
                    if (result.isSuccess) {
                        StudyHistory.invalidate()
                        ir.studying.app.core.RefreshBus.emit("study")
                        reloadKey += 1
                        AppSnack.show("گزارش ویرایش شد")
                    } else AppSnack.show("ویرایش ذخیره نشد؛ دوباره تلاش کن")
                }
            },
        )
    }

    val pickPart = partPick
    if (pickPart != null) {
        AlertDialog(
            onDismissRequest = { partPick = null },
            title = { Text("درس این پارت") },
            text = {
                Column(
                    Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    val apply: (Int?) -> Unit = { cid ->
                        val id = pickPart.id
                        partPick = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                runCatching {
                                    Api.get(
                                        "study_part_course",
                                        "id" to id.toString(),
                                        "course_id" to (cid?.toString() ?: "0"),
                                    )
                                }
                            }
                            if (r.isSuccess) {
                                AppSnack.show("درس پارت عوض شد")
                                ir.studying.app.core.RefreshBus.emit("study")
                                reloadKey += 1
                            } else {
                                AppSnack.show("تغییر درس نشد")
                            }
                        }
                    }
                    courses.forEach { c ->
                        TextButton(onClick = { apply(c.id) }) {
                            Text(c.icon + "  " + c.name)
                        }
                    }
                    TextButton(onClick = { apply(null) }) { Text("➖ بدون درس") }
                }
            },
            confirmButton = {
                TextButton(onClick = { partPick = null }) { Text("بستن") }
            },
        )
    }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 26.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column {
                Text(
                    Fmt.jalaliWithDay(dateIso),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    when {
                        isToday -> "\u0627\u0645\u0631\u0648\u0632"
                        isFuture -> "\u0631\u0648\u0632 \u067e\u06cc\u0634\u200c\u0631\u0648"
                        else -> "\u0631\u0648\u0632 \u06af\u0630\u0634\u062a\u0647"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                )
            }

            if (!isFuture) {
                Surface(shape = RoundedCornerShape(18.dp), color = cs.surfaceVariant.copy(alpha = 0.55f)) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.Schedule, null, tint = cs.primary, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "\u0645\u0637\u0627\u0644\u0639\u0647\u0654 \u0627\u06cc\u0646 \u0631\u0648\u0632",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            Fmt.minutes(minutes ?: 0),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if ((minutes ?: 0) > 0) cs.primary else cs.onSurfaceVariant,
                        )
                    }
                }
            }

            val d = data
            if (d == null) {
                Box(
                    Modifier.fillMaxWidth().height(90.dp),
                    contentAlignment = Alignment.Center,
                ) { CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(22.dp)) }
            } else {
                // ---- per-course split
                if (d.courses.isNotEmpty()) {
                    Text(
                        "\u062f\u0631\u0633\u200c\u0647\u0627",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    val maxM = d.courses.maxOf { it.minutes }.coerceAtLeast(1)
                    d.courses.forEach { cm ->
                        ir.studying.app.ui.components.ProgressRow(
                            cm.icon, cm.name, cm.minutes, maxM, Fmt.minutes(cm.minutes), cs.primary,
                        )
                    }
                }

                // ---- session timeline
                if (d.sessions.isNotEmpty()) {
                    Text(
                        "\u062e\u0637 \u0632\u0645\u0627\u0646\u06cc",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    d.sessions.forEach { s ->
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(7.dp).background(cs.primary, CircleShape))
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.course, style = MaterialTheme.typography.bodyMedium)
                                /* سرفصل و جزئیات گزارش، اگر ثبت شده باشد. */
                                if (s.topic.isNotBlank()) {
                                    Text(
                                        s.topic,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = cs.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    )
                                }
                                s.detail?.let { dt ->
                                    val bits = buildList {
                                        if (dt.qTotal > 0) {
                                            add("${dt.qTotal.fa()} تست · آزمون (منفی یک‌سوم): ${ir.studying.app.core.StudyReportMath.formatPercent(dt.examPercent)}٪")
                                        }
                                        if (dt.qDescriptive > 0) add("${dt.qDescriptive.fa()} سؤال تشریحی")
                                        if (dt.minVideo > 0) add("🎬 ${dt.minVideo.fa()}")
                                        if (dt.minTest > 0) add("✍️ ${dt.minTest.fa()}")
                                        if (dt.minBook > 0) add("📗 ${dt.minBook.fa()}")
                                        if (dt.minReview > 0) add("🔁 ${dt.minReview.fa()}")
                                        if (dt.minLearn > 0) add("🧠 ${dt.minLearn.fa()}")
                                        if (dt.focus > 0) add("تمرکز ${dt.focus.fa()}٪")
                                    }
                                    if (bits.isNotEmpty()) {
                                        Text(
                                            bits.joinToString(" · "),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = cs.primary,
                                            maxLines = 2,
                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                        )
                                    }
                                }
                            }
                            Text(
                                s.start + " - " + s.end,
                                style = MaterialTheme.typography.labelSmall,
                                color = cs.onSurfaceVariant,
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                Fmt.minutes(s.minutes),
                                style = MaterialTheme.typography.labelSmall,
                                color = cs.primary,
                            )
                            /* Only a part the server can address by id is editable. */
                            if (s.id > 0) {
                                TextButton(
                                    onClick = { partMenu = s },
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp),
                                ) { Text("⋯", style = MaterialTheme.typography.titleMedium) }
                            }
                        }
                    }
                }

                // ---- tasks
                Text(
                    "\u062a\u0633\u06a9\u200c\u0647\u0627\u06cc \u0627\u06cc\u0646 \u0631\u0648\u0632",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
                if (d.tasks.isEmpty()) {
                    Text(
                        "\u062a\u0633\u06a9\u06cc \u0628\u0631\u0627\u06cc \u0627\u06cc\u0646 \u0631\u0648\u0632 \u062b\u0628\u062a \u0646\u0634\u062f\u0647",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                } else {
                    d.tasks.forEach { t ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (t.done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                null,
                                tint = if (t.done) cs.primary else cs.onSurfaceVariant,
                                modifier = Modifier.size(19.dp),
                            )
                            Spacer(Modifier.width(9.dp))
                            Text(
                                t.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (t.done) cs.onSurfaceVariant else cs.onSurface,
                                textDecoration = if (t.done) TextDecoration.LineThrough else null,
                                modifier = Modifier.weight(1f),
                            )
                            if (t.priority == "high") {
                                Box(Modifier.size(7.dp).background(cs.error, CircleShape))
                            }
                        }
                    }
                }

                d.note?.let {
                    Text(it, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }

                Spacer(Modifier.height(2.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { export(false, d) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.Image, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("\u062e\u0631\u0648\u062c\u06cc \u0639\u06a9\u0633")
                    }
                    OutlinedButton(
                        onClick = { export(true, d) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("\u062e\u0631\u0648\u062c\u06cc PDF")
                    }
                }
            }
        }
    }
}
