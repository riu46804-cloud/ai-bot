@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package ir.studying.app.ui.home

import ir.studying.app.R
import androidx.compose.ui.res.stringResource
import ir.studying.app.core.AppIcons
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.components.HomeSkeleton
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.components.AppSnack
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Fmt
import ir.studying.app.core.Icon3D
import ir.studying.app.core.NavBus
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.data.Course
import ir.studying.app.data.CourseMinutes
import ir.studying.app.data.FriendStat
import ir.studying.app.data.StudyGroup
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.FullLoading
import ir.studying.app.ui.components.SectionTitle
import ir.studying.app.ui.theme.brandGradient
import ir.studying.app.ui.theme.courseColor
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

private val GENERAL_MOODS = listOf(
    "📚" to "مطالعه", "📖" to "کتابخوانی", "✏️" to "یادداشت", "🧮" to "ریاضی",
    "🔬" to "علوم", "💻" to "برنامه‌نویسی", "🎯" to "تمرکز", "💪" to "پرتلاش",
    "🔥" to "پر انرژی", "☕" to "قهوه‌ای", "🎵" to "موزیک", "😴" to "خوابالو",
    "🌟" to "عالی", "🚀" to "سریع", "💡" to "ایده‌پرداز", "🌈" to "خلاق",
)
private val BOOK_MOODS = listOf(
    "🧬" to "زیست", "🧪" to "شیمی", "⚡" to "فیزیک", "📐" to "ریاضی",
    "🌍" to "زمین‌شناسی", "📊" to "حسابان", "📏" to "هندسه", "🔢" to "گسسته",
)
private val COURSE_ICONS = listOf("📖", "📚", "✏️", "🧮", "🔬", "💻", "🧬", "🧪", "⚡", "📐", "🌍", "📊", "📏", "🔢", "🧠", "🗒️")

/*
 * Home, redesigned around one question: "what does the student need right now?"
 *
 * Priority order on screen:
 *   1. Header   — greeting, mood, streak, notifications. Status lives here now.
 *   2. Hero     — today's minutes once, big and animated, with the start CTA.
 *   3. Wakeup   — a contextual banner that disappears after check-in.
 *   4. Shortcuts— one compact row; only destinations missing from the bottom bar.
 *   5. Friends  — the people the user follows, with today's progress.
 *   6. Groups   — the user's study groups with unread badges (new on Home).
 *   7. Leaders  — daily leaderboard for the competitive push.
 *
 * Gone: the separate "today study" card (minutes were shown three times), the
 * room/library/profile shortcut duplicates, and the always-visible wakeup card.
 */
@Composable
fun HomeScreen(
    vm: HomeViewModel = viewModel(),
    onOpenFocus: () -> Unit = {},
    onOpenPhoneMenu: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) { vm.refresh() }
    val username = Store.username ?: ""

    var showMood by remember { mutableStateOf(false) }
    var showStatus by remember { mutableStateOf(false) }
    var showCourses by remember { mutableStateOf(false) }
    var showNotifs by remember { mutableStateOf(false) }
    var showCelebrate by remember { mutableStateOf(false) }

    val centerNotifs by ir.studying.app.notify.NotifCenter.notifs.collectAsState()
    val unreadNotif = centerNotifs.count { !it.read }

    val bottomInset = LocalBottomBarPadding.current.calculateBottomPadding()

    // A silhouette of the real layout, not a blank screen with a spinner.
    if (state.loading && state.today.totalMinutes == 0 && state.streak == 0) {
        HomeSkeleton(bottomPadding = bottomInset)
        return
    }
    if (state.error != null && !state.loaded) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Spacer(Modifier.height(20.dp))
            Surface(shape = MaterialTheme.shapes.extraLarge, color = Color.Transparent, onClick = { NavBus.requestStudy() }) {
                Column(Modifier.fillMaxWidth().background(brandGradient()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.home_screen_001), color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text(stringResource(R.string.home_screen_002), color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                }
            }
            ErrorState(state.error ?: "خطا", onRetry = { vm.refresh() })
        }
        return
    }

    Refreshable(onRefresh = { vm.refresh() }) {
    LazyColumn(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp, top = 16.dp, bottom = 16.dp + bottomInset,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {

        /* ۱ ─ هدر فشرده: سلام، مود، استریک، اعلان */
        item(key = "home_header") {
            val focusSession by ir.studying.app.focus.FocusLock.session.collectAsState()
            var showFocusStart by remember { mutableStateOf(false) }
            if (showFocusStart) ir.studying.app.ui.focus.FocusStartDialog(onDismiss = { showFocusStart = false })
            FadeSlideIn(0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("سلام، $username", style = MaterialTheme.typography.headlineSmall)
                        Text(Fmt.todayFull(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (state.statusText.isNotBlank()) {
                            Text(state.statusText, style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.clickable { showStatus = true })
                        } else {
                            Text(stringResource(R.string.home_screen_003), style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                                modifier = Modifier.clickable { showStatus = true })
                        }
                    }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f), onClick = { showMood = true }, modifier = Modifier.size(40.dp)) {
                        Box(contentAlignment = Alignment.Center) { Text(state.mood, fontSize = 17.sp) }
                    }
                    Spacer(Modifier.width(8.dp))
                    FireStreak(state.streak) { showCelebrate = true }
                    Spacer(Modifier.width(2.dp))
                    Box {
                        IconButton(onClick = { if (focusSession != null) onOpenFocus() else showFocusStart = true }) {
                            Icon(Icons.Rounded.Lock, contentDescription = "قفل تمرکز")
                        }
                        if (focusSession != null) {
                            Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(10.dp)
                                .background(Color(0xFF22C55E), CircleShape))
                        }
                    }
                    Box {
                        IconButton(onClick = { showNotifs = true }) {
                            Icon(Icons.Rounded.Notifications, contentDescription = "اعلان‌ها")
                        }
                        if (unreadNotif > 0) {
                            Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(10.dp)
                                .background(Color(0xFFEF4444), CircleShape))
                        }
                    }
                }
            }
        }

        /* رقابت‌های در جریان با دوستان */
        /* ۲ ─ کارت قهرمان: امروز + شروع مطالعه */
        item(key = "home_hero") {
            FadeSlideIn(1) { HeroTodayCard(state.today.totalMinutes, state.today.courses) }
        }

        /* ۲.۵ ─ هدف روزانه: همان عدد امروز، این بار در برابر هدف کاربر */
        item(key = "home_goal") {
            FadeSlideIn(1) { DailyGoalCard(state.today.totalMinutes) }
        }

        /* ۳ ─ بنر بیداری: فقط تا وقتی ثبت نشده */
        if (state.wakeup == null) {
            item(key = "home_wakeup") {
                FadeSlideIn(2) {
                    WakeupBanner(onCheckin = {
                        vm.checkinWakeup { err -> AppSnack.show(err ?: "صبح بخیر ☀️ ساعت بیداری ثبت شد") }
                    })
                }
            }
        }

        /* ۴ ─ میانبرها: یک ردیف چهارتایی، بدون تکرار تب‌های پایین */
        item(key = "home_quick") {
            FadeSlideIn(3) {
                QuickRow(
                    onTasks = { NavBus.requestRoute("tasks") },
                    onLibrary = { NavBus.requestRoute("library") },
                    onCommunity = { NavBus.requestRoute("community") },
                    onCourses = { showCourses = true },
                )
            }
        }

        /*
         * ۴/۰ ─ برنامه‌ریز هوشمند.
         *
         * بالاتر از بقیهٔ ابزارها می‌نشیند چون جواب سؤال «حالا چی بخونم؟» است؛
         * بقیهٔ کارت‌های خانه گزارش گذشته‌اند، این یکی تصمیم امروز را می‌سازد.
         */
        item(key = "home_planner") {
            FadeSlideIn(4) { PlannerEntryCard() }
        }

        /* ۴/۱ ─ فلش‌کارت: کارت‌های امروز */
        item(key = "home_flashcards") {
            FadeSlideIn(4) { FlashcardsEntryCard() }
        }

        /* اطلس بدن انسان، کنار بقیه ابزارهای مطالعه. */
        item(key = "home_anatomy") {
            FadeSlideIn(4) { AnatomyEntryCard() }
        }

        /* ۴/۲ ─ ربات تلگرام */
        item(key = "home_telegram") {
            FadeSlideIn(4) { TelegramEntryCard() }
        }

        /*
         * ۴/۳ ─ زنگ بیدارباش.
         *
         * بالای صفحه نبود چون بالای خانه جای «امروز چقدر خواندم» است؛ زنگ یک
         * ابزار است، نه خبر. اینجا کنار بقیهٔ ابزارها می‌نشیند.
         */
        item(key = "home_alarm") {
            FadeSlideIn(4) {
                ir.studying.app.ui.alarm.AlarmHomeCard(onOpen = { NavBus.requestRoute("alarms") })
            }
        }

        /* ۵ ─ دوستان دنبال‌شده */
        item(key = "home_friends") {
            FadeSlideIn(4) { FriendsSection(state.friends) }
        }

        /* ۶ ─ گروه‌های مطالعه‌ی کاربر */
        item(key = "home_groups") {
            FadeSlideIn(5) { GroupsSection(state.groups, state.groupUnread) }
        }

        /* ۶/۱ ─ رقابت‌های دونفره، در کنار همین بخش‌های اجتماعی */
        item(key = "home_challenges") {
            FadeSlideIn(5) { ir.studying.app.ui.messages.ChallengesSection() }
        }

        /* ۷ ─ برترین‌های امروز */
        item(key = "home_top") {
            FadeSlideIn(6) {
                TopStudiersCard(
                    myMinutes = state.today.totalMinutes,
                    onUser = { u -> NavBus.requestUser(u) },
                    onSeeAll = { NavBus.requestRoom("top") },
                )
            }
        }

        item(key = "home_tail") { Spacer(Modifier.height(4.dp)) }
    }
    }

    // ---- dialogs / sheets ----
    if (showCelebrate) CelebrationDialog(state.streak) { showCelebrate = false }

    if (showNotifs) {
        ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = { showNotifs = false }) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                    Text(stringResource(R.string.home_screen_004), style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(10.dp))
                if (centerNotifs.any { !it.read }) {
                    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        onClick = { ir.studying.app.notify.NotifCenter.markAllRead(ctx) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.DoneAll, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.home_screen_005), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                if (centerNotifs.isEmpty()) EmptyState("🔕", "فعلاً اعلانی نداری")
                /*
                 * هر ردیف حالا کلیک‌پذیر است: تا قبل از این اعلان‌ها فقط متن بودند و
                 * کاربر باید دستی دنبال پست/پروفایل می‌گشت. مقصد را NotifRouter تعیین
                 * می‌کند تا با تپ روی نوتیفیکیشن سیستمی دقیقاً یکی باشد.
                 */
                else centerNotifs.take(30).forEach { n ->
                    Surface(
                        onClick = {
                            ir.studying.app.notify.NotifCenter.markReadLocal(n.id)
                            showNotifs = false
                            ir.studying.app.notify.NotifRouter.open(n)
                        },
                        shape = MaterialTheme.shapes.medium,
                        color = if (!n.read) MaterialTheme.colorScheme.primary.copy(alpha = 0.06f) else Color.Transparent,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    ) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        /* آواتار + حباب ایموجی نوعِ اعلان: قبلاً ایموجی داخل متن
                           بود و بین کلمات گم می‌شد. */
                        Box {
                            Avatar(n.actor, size = 38.dp, avatarUrl = n.actorAvatar)
                            Box(
                                Modifier
                                    .align(Alignment.BottomStart)
                                    .size(17.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(1.dp),
                                contentAlignment = Alignment.Center,
                            ) { Text(n.emoji, style = MaterialTheme.typography.labelSmall) }
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(n.title, style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (!n.read) FontWeight.Bold else null, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (!n.text.isNullOrBlank()) Text(n.text, style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.relative(n.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            if (!n.read) {
                                Box(
                                    Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary),
                                )
                            } else {
                                Icon(Icons.Rounded.ChevronLeft, contentDescription = null, modifier = Modifier.size(15.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f))
                            }
                        }
                    }
                    }
                }
            }
        }
    }

    if (showMood) {
        var tab by remember { mutableStateOf(0) }
        var selected by remember(state.mood) { mutableStateOf(state.mood) }
        ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = { showMood = false }) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                Text(stringResource(R.string.home_screen_006), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text(stringResource(R.string.home_screen_007)) })
                    FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text(stringResource(R.string.home_screen_008)) },
                        leadingIcon = { Icon(AppIcons.Study, contentDescription = null, modifier = Modifier.size(17.dp)) })
                }
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    (if (tab == 0) GENERAL_MOODS else BOOK_MOODS).forEach { (e, l) ->
                        Surface(shape = MaterialTheme.shapes.medium,
                            color = if (selected == e) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            onClick = { selected = e }) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(e, fontSize = 22.sp); Text(l, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.setMood(selected); showMood = false }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = MaterialTheme.shapes.medium) { Text(stringResource(R.string.groups_010)) }
            }
        }
    }

    if (showStatus) {
        var text by remember { mutableStateOf(state.statusText) }
        AlertDialog(onDismissRequest = { showStatus = false }, title = { Text(stringResource(R.string.home_screen_009)) },
            text = {
                Column {
                    OutlinedTextField(value = text, onValueChange = { if (it.length <= 50) text = it }, placeholder = { Text(stringResource(R.string.home_screen_010)) }, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth())
                    Text("${text.length.fa()}/۵۰", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { vm.setStatus(text) { err -> if (err != null) AppSnack.show(err) }; showStatus = false }) { Text(stringResource(R.string.groups_010)) } },
            dismissButton = { TextButton(onClick = { showStatus = false }) { Text(stringResource(R.string.groups_011)) } })
    }

    if (showCourses) CourseManagerSheet(vm, state.courses) { showCourses = false }
}

/* ---------------------------------------------------------------------- */
/*  قهرمان صفحه: دقایق امروز + شروع سریع                                */
/* ---------------------------------------------------------------------- */

/*
 * The one place today's total lives.
 *
 * Before the redesign the same number appeared in the hero badge, in a dedicated
 * "today study" card and again inside the leaderboard. Everything merged here:
 * a big animated counter, up to three per-course mini bars for context, and the
 * two actions that actually start a session. The room is a secondary tonal pill
 * because it already has its own bottom tab.
 */
@Composable
private fun HeroTodayCard(totalMinutes: Int, courses: List<CourseMinutes>) {
    var newestChallenge by remember { mutableStateOf<ir.studying.app.core.Challenges.Active?>(null) }
    /* با هر تغییر در چالش‌ها به‌روز می‌شود؛ پیش از این تا ساخت دوبارهٔ صفحه ثابت می‌ماند. */
    LaunchedEffect(Unit) { newestChallenge = ir.studying.app.core.Challenges.list().firstOrNull() }
    LaunchedEffect(Unit) {
        ir.studying.app.core.RefreshBus.events.collect { tag ->
            if (tag == ir.studying.app.core.Challenges.TAG || tag == "all" || tag == "home") {
                newestChallenge = ir.studying.app.core.Challenges.list().firstOrNull()
            }
        }
    }
    val counted by animateFloatAsState(totalMinutes.toFloat(), tween(900), label = "heroCount")
    Surface(shape = MaterialTheme.shapes.extraLarge, color = Color.Transparent, onClick = { NavBus.requestStudy() }) {
        Column(Modifier.background(brandGradient()).padding(horizontal = 18.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.home_screen_011), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(counted.toInt().fa(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 40.sp, maxLines = 1)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.home_screen_012), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(bottom = 7.dp))
                    }
                }
                val t = rememberInfiniteTransition(label = "heroPulse")
                val pulse by t.animateFloat(1f, 1.09f,
                    infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
                Box(
                    Modifier.size(62.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
                        .background(Color.White.copy(alpha = 0.20f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null,
                        tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }

            if (courses.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                val maxM = courses.maxOf { it.minutes }.coerceAtLeast(1)
                courses.sortedByDescending { it.minutes }.take(3).forEach { c ->
                    val frac by animateFloatAsState(c.minutes.toFloat() / maxM, tween(700), label = "heroBar")
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.icon, fontSize = 13.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(c.name, color = Color.White.copy(alpha = 0.92f), style = MaterialTheme.typography.labelMedium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(88.dp))
                        Box(Modifier.weight(1f).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f))) {
                            Box(Modifier.fillMaxWidth(frac).height(5.dp).clip(CircleShape).background(Color.White))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(Fmt.minutes(c.minutes), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = Color.White, onClick = { NavBus.requestStudy() }, modifier = Modifier.weight(1f)) {
                    Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null,
                            tint = Color(0xFF06231A), modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.home_screen_013), color = Color(0xFF06231A), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                }
                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.40f)), onClick = { NavBus.requestRoom() }) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Groups, contentDescription = null,
                            tint = Color.White, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(stringResource(R.string.home_screen_014), color = Color.White, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
            newestChallenge?.let { c ->
                Spacer(Modifier.height(9.dp))
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.14f),
                    onClick = { NavBus.requestRoute("messages") },
                ) {
                    Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (c.kind == "lock") "🔒" else "⚔️", fontSize = 13.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "جدیدترین: ${c.opponent}" + if (c.status == "pending") " · منتظر شروع" else " · ${c.myMinutes.fa()}–${c.theirMinutes.fa()} دقیقه",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(Icons.Rounded.ChevronLeft, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  بنر شرطی ساعت بیداری                                                  */
/* ---------------------------------------------------------------------- */

/* Shown only until the user checks in; after that it leaves no trace. */
@Composable
private fun WakeupBanner(onCheckin: () -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.WbSunny, contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(21.dp))
            Spacer(Modifier.width(10.dp))
            Text(stringResource(R.string.home_screen_015), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.tertiary, onClick = onCheckin) {
                Text(stringResource(R.string.home_screen_016), color = MaterialTheme.colorScheme.onTertiary, style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp))
            }
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  ورودی برنامه‌ریز هوشمند                                               */
/* ---------------------------------------------------------------------- */

/*
 * کارت عمداً «وضعیت» نشان نمی‌دهد، فقط دعوت می‌کند. شمردن جلسه‌های امروزِ
 * برنامه اینجا یعنی خواندن کش در هر بار ساخت خانه، و خانه همان جایی است که
 * نباید کُند شود؛ عدد واقعی یک تپ آن‌طرف‌تر، داخل خود برنامه‌ریز است.
 *
 * ظاهرش عمداً از بقیهٔ کارت‌های خانه متمایز است: گرادیان نیلی-فیروزه‌ای،
 * هالهٔ نور متحرک و جرقهٔ نبض‌دار. این تنها ورودی ابزارِ «تصمیم امروز» است و
 * باید در اسکرول خانه پیدا شود، نه اینکه مثل بقیه رد شود.
 */
@Composable
private fun PlannerEntryCard() {
    val shape = MaterialTheme.shapes.extraLarge
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "plannerCard")
    val shimmer by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(5200, easing = androidx.compose.animation.core.LinearEasing),
        ),
        label = "shimmer",
    )
    val pulse by t.animateFloat(
        initialValue = 0.82f, targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(1600, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse,
        ),
        label = "pulse",
    )

    Surface(
        shape = shape,
        onClick = { NavBus.requestRoute("planner") },
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Box(
            Modifier
                .clip(shape)
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFF6366F1), Color(0xFF0EA5E9))
                    ),
                )
                // هالهٔ نورِ آرام که روی کارت می‌چرخد؛ یک drawBehind، بدون bitmap.
                .drawBehind {
                    val cx = size.width * (1.15f - 1.5f * shimmer)
                    drawCircle(
                        androidx.compose.ui.graphics.Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.20f), Color.Transparent),
                            center = androidx.compose.ui.geometry.Offset(cx, size.height * 0.2f),
                            radius = size.height * 1.5f,
                        ),
                        radius = size.height * 1.5f,
                        center = androidx.compose.ui.geometry.Offset(cx, size.height * 0.2f),
                    )
                }
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Rounded.AutoAwesome, contentDescription = null,
                        tint = Color.White.copy(alpha = pulse),
                        modifier = Modifier.size(24.dp),
                    )
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "برنامه‌ریز هوشمند", color = Color.White,
                            style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                        )
                        Spacer(Modifier.width(6.dp))
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f))
                                .padding(horizontal = 7.dp, vertical = 1.dp),
                        ) {
                            Text(ir.studying.app.core.PlannerAvailability.BADGE, color = Color.White, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(
                        ir.studying.app.core.PlannerAvailability.MESSAGE,
                        color = Color.White.copy(alpha = 0.88f),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
                Icon(
                    Icons.Rounded.ChevronLeft, contentDescription = null,
                    tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  میانبرها — یک ردیف فشرده                                             */
/* ---------------------------------------------------------------------- */

private data class Shortcut(
    val label: String,
    val icon: ImageVector,
    val tint: Color,
    val onClick: () -> Unit,
)

/*
 * Four tiles, one row. Room and profile are deliberately absent — they already
 * sit one tap away in the bottom bar, so repeating them here was pure noise.
 */
@Composable
private fun QuickRow(onTasks: () -> Unit, onLibrary: () -> Unit, onCommunity: () -> Unit, onCourses: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val items = listOf(
        Shortcut("تسک‌ها", Icons.Rounded.TaskAlt, cs.primary, onTasks),
        Shortcut("کتابخانه", Icons.Rounded.LibraryMusic, cs.tertiary, onLibrary),
        Shortcut("اجتماع", Icons.Rounded.Groups, cs.secondary, onCommunity),
        Shortcut("دروس", Icons.AutoMirrored.Rounded.MenuBook, cs.primary, onCourses),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        items.forEach { sc -> ShortcutTile(sc, modifier = Modifier.weight(1f)) }
    }
}

/*
 * No entrance animation of its own any more.
 *
 * The tile used to scale itself in from zero on first composition, which meant
 * the whole row popped again every time the user scrolled it back into view.
 * The section wrapper already handles the one-shot entrance; the only motion
 * left here is the press feedback, which is exactly what the finger expects.
 */
@Composable
private fun ShortcutTile(sc: Shortcut, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(
        if (pressed) 0.93f else 1f,
        spring(dampingRatio = 0.4f, stiffness = 1000f), label = "tilePress",
    )
    val haptic = LocalHapticFeedback.current
    Surface(
        modifier = modifier
            .graphicsLayer { scaleX = press; scaleY = press }
            .clip(MaterialTheme.shapes.large)
            .clickable(interaction, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                sc.onClick()
            },
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
    ) {
        Column(
            Modifier.padding(vertical = 11.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(sc.tint.copy(alpha = 0.26f), sc.tint.copy(alpha = 0.10f)))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(sc.icon, contentDescription = sc.label, tint = sc.tint, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.height(7.dp))
            Text(
                sc.label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  دوستان دنبال‌شده                                                      */
/* ---------------------------------------------------------------------- */

/*
 * Compact friend cards: avatar with online ring and mood, today's minutes and a
 * slim progress bar relative to the most productive friend — social pressure at
 * a glance. Card tap opens the profile sheet, the pill opens a DM.
 */
@Composable
private fun FriendsSection(friends: List<FriendStat>) {
    Column {
        SectionTitle("رفیق‌های درس‌خون", actionText = "همه ›") { NavBus.requestRoute("community") }
        Spacer(Modifier.height(10.dp))
        if (friends.isEmpty()) {
            Surface(
                shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
                onClick = { NavBus.requestRoute("community") }, modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.PersonAdd, contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.home_screen_017), style = MaterialTheme.typography.titleSmall)
                        Text(stringResource(R.string.home_screen_018), style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("‹", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            val maxM = friends.maxOf { it.todayMinutes }.coerceAtLeast(1)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(friends, key = { it.username }) { f -> FriendCard(f, maxM) }
            }
        }
    }
}

@Composable
private fun FriendCard(f: FriendStat, maxMinutes: Int) {
    val frac by animateFloatAsState((f.todayMinutes.toFloat() / maxMinutes).coerceIn(0f, 1f), tween(700), label = "frBar")
    Surface(
        shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
        onClick = { NavBus.requestUser(f.username) },
    ) {
        Column(Modifier.width(128.dp).padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(f.username, f.mood, size = 46.dp, online = f.isOnline, avatarUrl = f.avatar)
            Spacer(Modifier.height(7.dp))
            Text(f.username, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(Fmt.minutes(f.todayMinutes), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(7.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))) {
                Box(Modifier.fillMaxWidth(frac).height(4.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
            }
            Spacer(Modifier.height(9.dp))
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), onClick = { NavBus.requestDm(f.username) }) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Rounded.Chat, "پیام", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.home_screen_019), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  گروه‌های مطالعه — جدید در صفحه‌ی اصلی                                */
/* ---------------------------------------------------------------------- */

/*
 * The user's study groups were only reachable through the messages tab. They
 * are a core motivator, so they now live on Home with unread badges; one tap
 * jumps straight into the group chat via NavBus. A trailing tile offers create/
 * discover, and the empty state explains why groups matter.
 */
@Composable
private fun GroupsSection(groups: List<StudyGroup>, unread: Map<Int, Int>) {
    Column {
        SectionTitle("گروه‌های مطالعه", actionText = "همه ›") { NavBus.requestGroupsHome() }
        Spacer(Modifier.height(10.dp))
        if (groups.isEmpty()) {
            Surface(
                shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
                onClick = { NavBus.requestGroupsHome() }, modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Groups, contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.home_screen_020), style = MaterialTheme.typography.titleSmall)
                        Text(stringResource(R.string.home_screen_021), style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("‹", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(groups, key = { it.id }) { g -> GroupCard(g, unread[g.id] ?: 0) }
                item(key = "new_group_tile") { NewGroupTile() }
            }
        }
    }
}

/* Home group tiles share one footprint so the trailing create tile lines up
 * exactly with the group cards instead of looking clipped next to them. */
private val GroupTileWidth = 142.dp
private val GroupTileHeight = 118.dp

@Composable
private fun GroupCard(g: StudyGroup, unread: Int) {
    Surface(
        shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
        onClick = { NavBus.requestGroupDetail(g.id, g.name) },
    ) {
        Column(Modifier.width(GroupTileWidth).height(GroupTileHeight).padding(12.dp)) {
            Box {
                Avatar(g.username, size = 40.dp, avatarUrl = g.avatar)
                if (unread > 0) {
                    Surface(
                        shape = CircleShape, color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.align(Alignment.TopStart),
                    ) {
                        Text(unread.fa(), color = MaterialTheme.colorScheme.onError, style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(g.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(g.memberCount.fa() + " عضو", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NewGroupTile() {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)),
        onClick = { NavBus.requestGroupsHome() },
    ) {
        Column(
            Modifier.width(GroupTileWidth).height(GroupTileHeight).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null,
                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.groups_001), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center)
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  استریک                                                                  */
/* ---------------------------------------------------------------------- */

/* The only streak surface on Home; the celebration is opt-in via tap. */
@Composable
private fun FireStreak(streak: Int, onClick: () -> Unit) {
    val alive = streak > 0
    val t = rememberInfiniteTransition(label = "streakChip")
    val flicker by t.animateFloat(
        1f, if (alive) 1.16f else 1f,
        infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "flicker",
    )
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(
        if (pressed) 0.9f else 1f,
        spring(dampingRatio = 0.42f, stiffness = 900f), label = "streakPress",
    )
    val haptic = LocalHapticFeedback.current
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.75f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.35f)),
        modifier = Modifier
            .graphicsLayer { scaleX = press; scaleY = press }
            .clip(CircleShape)
            .clickable(interaction, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.LocalFireDepartment, "استریک",
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(17.dp).graphicsLayer { scaleX = flicker; scaleY = flicker })
            Spacer(Modifier.width(5.dp))
            Text(streak.fa(), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
            Spacer(Modifier.width(3.dp))
            Text(stringResource(R.string.home_screen_022), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.7f))
        }
    }
}

/* ---------------------------------------------------------------------- */
/*  مدیریت دروس                                                            */
/* ---------------------------------------------------------------------- */

@Composable
private fun CourseManagerSheet(vm: HomeViewModel, courses: List<Course>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("green") }
    var icon by remember { mutableStateOf("📖") }
    // جزئیات درس (فصل/بخش/پارت) و درس‌های آمادهٔ سرور
    var topicsFor by remember { mutableStateOf<Course?>(null) }
    var showReady by remember { mutableStateOf(false) }
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(AppIcons.Study, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                Text(stringResource(R.string.home_screen_023), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(stringResource(R.string.home_screen_024)) }, singleLine = true, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("purple" to "بنفش", "red" to "قرمز", "green" to "سبز", "orange" to "نارنجی").forEach { (k, l) ->
                    FilterChip(selected = color == k, onClick = { color = k }, label = { Text(l) },
                        leadingIcon = { Box(Modifier.size(12.dp).background(courseColor(k), CircleShape)) })
                }
            }
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(COURSE_ICONS, key = { it }) { e ->
                    Surface(shape = CircleShape, color = if (icon == e) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), onClick = { icon = e }) {
                        Text(e, fontSize = 20.sp, modifier = Modifier.padding(9.dp))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            /* میان‌بر درس‌های آماده: کاربر لازم نیست فصل‌ها را دستی بنویسد. */
            androidx.compose.material3.OutlinedButton(
                onClick = { showReady = true },
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
            ) { Text("📚  درس‌های آماده پایهٔ من") }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.addCourse(name.trim(), color, icon) { err -> AppSnack.show(err ?: "درس اضافه شد ✅") }; name = "" },
                enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth().height(48.dp), shape = MaterialTheme.shapes.medium) {
                Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.home_screen_025))
            }
            Spacer(Modifier.height(14.dp))
            courses.forEach { c ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(courseColor(c.color), CircleShape))
                    Spacer(Modifier.width(10.dp)); Text(c.icon, fontSize = 18.sp); Spacer(Modifier.width(8.dp))
                    Text(c.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    androidx.compose.material3.TextButton(onClick = { topicsFor = c }) { Text("جزئیات") }
                    IconButton(onClick = { vm.deleteCourse(c.id) }) { Icon(Icons.Rounded.Delete, "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp)) }
                }
            }
            if (courses.isEmpty()) EmptyState("🌱", "اولین درست رو بساز")
        }
    }
    topicsFor?.let { c ->
        ir.studying.app.ui.study.CourseTopicsSheet(course = c, onDismiss = { topicsFor = null })
    }
    if (showReady) {
        ir.studying.app.ui.study.ReadyCoursesSheet(
            onDismiss = { showReady = false },
            onImported = { showReady = false; vm.refreshCourses() },
        )
    }
}

/* ---------------------------------------------------------------------- */
/*  جشن استریک                                                            */
/* ---------------------------------------------------------------------- */

/*
 * Opens only when the streak chip is tapped.
 *
 * Three layers run together: a slowly rotating sweep halo, twenty four confetti
 * pieces on their own ballistic paths, and a spring scaled card. Everything is
 * driven by two Animatables and one infinite transition, so once the entrance
 * settles nothing else recomposes and the dialog stays cheap to keep on screen.
 */
@Composable
private fun CelebrationDialog(streak: Int, onDismiss: () -> Unit) {
    val enter = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { enter.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 260f)) }
        burst.animateTo(1f, tween(2200, easing = LinearEasing))
    }

    val t = rememberInfiniteTransition(label = "cel")
    val spin by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin",
    )
    val pulse by t.animateFloat(
        1f, 1.2f,
        infiniteRepeatable(tween(760, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse",
    )

    val msg = when {
        streak <= 0 -> "امروز شروع کن تا استریکت بالا بره! 💪"
        streak < 3 -> "شروع خوبیه! ادامه بده تا عادت بشه 🌱"
        streak < 7 -> "داری قوی می‌شی! نذار قطع شه 🔥"
        streak < 30 -> "عالیه! تو یه قهرمان درس‌خونی ⭐"
        else -> "افسانه‌ای! این استریک فوق‌العادهست 🏆"
    }

    val confetti = listOf(
        Color(0xFF4ADE9F), Color(0xFF38BDF8), Color(0xFFFBBF24),
        Color(0xFFFB7185), Color(0xFFA78BFA), Color(0xFFFB923C),
    )

    Dialog(onDismissRequest = onDismiss) {
        Box(contentAlignment = Alignment.Center) {

            Canvas(Modifier.fillMaxWidth().height(430.dp)) {
                val p = burst.value
                if (p < 1f) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val fade = (1f - p).coerceIn(0f, 1f)
                    repeat(24) { i ->
                        val rad = ((i * 37.7f) % 360f) * (3.14159265f / 180f)
                        val speed = 130f + (i % 5) * 46f
                        val x = cx + cos(rad) * speed * p
                        val y = cy + sin(rad) * speed * p + 430f * p * p
                        drawCircle(
                            color = confetti[i % confetti.size].copy(alpha = fade),
                            radius = 5f + (i % 3) * 2.5f,
                            center = Offset(x, y),
                        )
                    }
                }
            }

            Surface(
                shape = MaterialTheme.shapes.extraLarge,
                color = Color.Transparent,
                modifier = Modifier.graphicsLayer {
                    val e = enter.value
                    scaleX = e
                    scaleY = e
                    alpha = e.coerceIn(0f, 1f)
                },
            ) {
                Column(
                    Modifier.background(brandGradient()).padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            Modifier
                                .size(150.dp)
                                .graphicsLayer { rotationZ = spin }
                                .background(
                                    Brush.sweepGradient(
                                        listOf(
                                            Color.White.copy(alpha = 0f),
                                            Color.White.copy(alpha = 0.30f),
                                            Color.White.copy(alpha = 0f),
                                            Color.White.copy(alpha = 0.22f),
                                            Color.White.copy(alpha = 0f),
                                        )
                                    ),
                                    CircleShape,
                                )
                        )
                        Icon3D("🔥", size = 92.dp, modifier = Modifier.scale(pulse))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        streak.fa() + " روز پیاپی!",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        msg,
                        color = Color.White.copy(alpha = 0.92f),
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(18.dp))
                    Surface(shape = CircleShape, color = Color.White, onClick = onDismiss) {
                        Text(stringResource(R.string.home_screen_026),
                            color = Color(0xFF06231A),
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(horizontal = 26.dp, vertical = 12.dp),
                        )
                    }
                }
            }
        }
    }
}

/**
 * Home entry for flashcards. It only ever shows a number the user can act on:
 * cards due right now. When nothing is due it becomes an invitation instead of
 * a dead widget, so the row never feels like clutter.
 */
@Composable
private fun FlashcardsEntryCard() {
    val decks by ir.studying.app.core.Flashcards.decks.collectAsState()
    val due by ir.studying.app.core.Flashcards.dueTotal.collectAsState()
    LaunchedEffect(Unit) { runCatching { ir.studying.app.core.Flashcards.loadDecks() } }

    val pulse = androidx.compose.animation.core.rememberInfiniteTransition(label = "fc")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = if (due > 0) 1.06f else 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(1400),
            androidx.compose.animation.core.RepeatMode.Reverse,
        ),
        label = "scale",
    )

    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        onClick = { NavBus.requestRoute("flashcards") },
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFFA78BFA), Color(0xFF7C3AED))
                    ),
                    MaterialTheme.shapes.extraLarge,
                )
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .scale(scale)
                    .background(Color.White.copy(alpha = 0.22f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("\uD83E\uDDE0", fontSize = 22.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (due > 0) "${due.fa()} کارت آمادهٔ مرور است" else "فلش‌کارت",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    if (decks.isEmpty()) "اولین دسته‌ات را بساز و هوشمند مرور کن"
                    else "${decks.size.fa()} دسته • یادآوری هوشمند SM-2",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White)
        }
    }
}

/** اطلس با Chrome Trusted Web Activity در تسک اپ باز می‌شود. */
@Composable
private fun AnatomyEntryCard() {
    val ctx = LocalContext.current
    var chromeError by remember { mutableStateOf<ir.studying.app.ui.anatomy.AnatomyChromeTabs.Result?>(null) }
    chromeError?.let { problem ->
        AlertDialog(
            onDismissRequest = { chromeError = null },
            title = { Text(if (problem == ir.studying.app.ui.anatomy.AnatomyChromeTabs.Result.CHROME_UNAVAILABLE) "کروم در دسترس نیست" else "باز کردن اطلس ممکن نشد") },
            text = { Text(if (problem == ir.studying.app.ui.anatomy.AnatomyChromeTabs.Result.CHROME_UNAVAILABLE)
                "برای باز کردن آناتومی داخل برنامه، Google Chrome را نصب یا فعال و به‌روز کن؛ سپس دوباره تلاش کن."
                else "تب کروم باز نشد. دوباره تلاش کن و وضعیت کروم را بررسی کن.") },
            confirmButton = { TextButton(onClick = { chromeError = null }) { Text("متوجه شدم") } },
        )
    }
    Surface(shape = MaterialTheme.shapes.extraLarge,
        onClick = {
            val result = ir.studying.app.ui.anatomy.AnatomyChromeTabs.launch(ctx)
            if (result != ir.studying.app.ui.anatomy.AnatomyChromeTabs.Result.OPENED) chromeError = result
        },
        color = Color.Transparent, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.background(Brush.linearGradient(listOf(Color(0xFF157B88), Color(0xFF2851A4))),
            MaterialTheme.shapes.extraLarge).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(Color.White.copy(alpha = 0.22f), CircleShape),
                contentAlignment = Alignment.Center) { Text("🫀", fontSize = 23.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("آناتومی", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("اطلس سه‌بعدی بدن انسان", color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium)
            }
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White)
        }
    }
}

/** Home entry for the Telegram bot, so the feature is discoverable at all. */
@Composable
private fun TelegramEntryCard() {
    /* وقتی ربات وصل است، بنر دیگر جایی در صفحهٔ اصلی ندارد. */
    var tgLinked by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching { tgLinked = ir.studying.app.core.Store.getString("tg_linked") == "1" }
        runCatching {
            val on = ir.studying.app.core.Api.obj(ir.studying.app.core.Api.get("tg_status")).optInt("linked", 0) == 1
            tgLinked = on
            ir.studying.app.core.Store.putString("tg_linked", if (on) "1" else "0")
        }
    }
    if (tgLinked) return

    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        onClick = { NavBus.requestRoute("settings_telegram") },
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFF38BDF8), Color(0xFF2563EB))
                    ),
                    MaterialTheme.shapes.extraLarge,
                )
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(46.dp).background(Color.White.copy(alpha = 0.22f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Send, contentDescription = null, tint = Color.White) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("ربات تلگرام", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(
                    "گزارش روزانه، یادآوری و جدول گروه در تلگرام",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            Icon(Icons.Rounded.ChevronLeft, contentDescription = null, tint = Color.White)
        }
    }
}
