package ir.studying.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.core.Cache
import ir.studying.app.core.Goals
import ir.studying.app.core.Store
import ir.studying.app.core.TimerPersist
import ir.studying.app.core.int
import ir.studying.app.core.str
import ir.studying.app.core.strOrNull
import ir.studying.app.core.humanizeError
import ir.studying.app.data.Course
import ir.studying.app.data.FriendStat
import ir.studying.app.data.StudyGroup
import ir.studying.app.data.NotificationItem
import ir.studying.app.data.StudyToday
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

class HomeViewModel : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val loaded: Boolean = false,
        val error: String? = null,
        val today: StudyToday = StudyToday(0, emptyList()),
        val streak: Int = 0,
        val wakeup: String? = null,
        val statusText: String = "",
        val mood: String = "😊",
        val friends: List<FriendStat> = emptyList(),
        val groups: List<StudyGroup> = emptyList(),
        val groupUnread: Map<Int, Int> = emptyMap(),
        val courses: List<Course> = emptyList(),
        val notifications: List<NotificationItem> = emptyList(),
    )

    val state = MutableStateFlow(State())

    // Timer UI state (persisted through Store)
    val timerElapsedSec = MutableStateFlow(0L)
    val timerRunning = MutableStateFlow(false)
    val timerCourseId = MutableStateFlow<Int?>(null)

    private var refreshJob: kotlinx.coroutines.Job? = null
    private var shownDay = ir.studying.app.core.IranTime.todayIso()

    init {
        /*
         * FIX: ایموجی حالت هیچ‌وقت از دیسک یا سرور خوانده نمی‌شد: مقدار اولیهٔ
         * State همیشه 😊 بود، refresh() هم mood را ست نمی‌کرد و acceptServerMood کد
         * مرده بود (هیچ فراخوانی نداشت). پس هر بار که ViewModel از نو ساخته
         * می‌شد — رفتن و برگشتن به خانه، باز شدن مجدد اپ، کشته شدن پروسه در
         * پس‌زمینه — ایموجی به پیش‌فرض برمی‌گشت، در حالی که مقدار درست روی
         * سرور ذخیره بود. اول مقدار لوکال (فوری) خوانده می‌شود، بعد سرور.
         */
        viewModelScope.launch {
            runCatching { Store.getString(KEY_MOOD) }.getOrNull()
                ?.takeIf { it.isNotBlank() }
                ?.let { m -> state.update { s -> s.copy(mood = m) } }
        }
        refresh()
        viewModelScope.launch {
            Store.session.collect {
                refreshJob?.cancel()
                state.value = State()
                refresh()
            }
        }
        // آپدیت لحظه‌ای: هر تغییری در اپ (ثبت مطالعه، تسک و…) خانه را تازه می‌کند
        viewModelScope.launch { ir.studying.app.core.RefreshBus.events.collect { refresh() } }
        // رفرش دوره‌ای برای داده‌های زنده (دوستان آنلاین، اعلان‌ها، استریک)
        viewModelScope.launch { while (true) { kotlinx.coroutines.delay(25000); refresh() } }
        viewModelScope.launch {
            while (true) {
                val t = Store.timer.value
                val elapsedMs = ir.studying.app.player.Chrono.elapsedMs()
                timerElapsedSec.value = elapsedMs / 1000
                timerRunning.value = t.running
                timerCourseId.value = t.courseId
                delay(300)
            }
        }
    }

    /**
     * Read-through cache for a single endpoint.
     *
     * Home used to sit on a spinner for the entire network timeout whenever the
     * connection was bad, which on a phone in a classroom is most of the time.
     * The last good payload is stored per endpoint, so the screen paints real
     * numbers immediately and the network result replaces them when it lands.
     */
    private suspend fun cached(action: String, key: String): String {
        val session = Store.session.value
        val day = ir.studying.app.core.IranTime.todayIso()
        return try {
            val text = Api.get(action)
            if (Store.session.value != session || ir.studying.app.core.IranTime.todayIso() != day)
                throw kotlinx.coroutines.CancellationException("Study snapshot changed")
            Cache.put(key, text, session.username, day)
            text
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            if (Store.session.value != session || (e as? ir.studying.app.core.ApiException)?.code in listOf(401, 403)) throw e
            Cache.get(key, owner = session.username, day = day) ?: throw e
        }
    }

    fun refresh() {
        val day = ir.studying.app.core.IranTime.todayIso()
        if (shownDay != day) {
            shownDay = day
            state.update { it.copy(today = StudyToday(0, emptyList()), streak = 0) }
        }
        if (refreshJob?.isActive == true) return
        val session = Store.session.value
        if (session.token.isNullOrBlank()) return
        refreshJob = viewModelScope.launch {
            state.update { it.copy(error = null) }
            try {
                coroutineScope {
                    val todayD = async { StudyToday.from(Api.obj(cached("study_today", Cache.STUDY_TODAY))) }
                    val streakD = async { runCatching { Api.obj(cached("streak", Cache.STREAK)).int("streak") }.getOrDefault(0) }
                    val wakeD = async { runCatching { Api.obj(Api.get("wakeup")).strOrNull("wakeup_time") }.getOrNull() }
                    val statusD = async { runCatching { Api.obj(Api.get("status")).str("status_text") }.getOrDefault("") }
                    val friendsD = async { runCatching { FriendStat.list(Api.arr(Api.get("following_stats"))) }.getOrDefault(emptyList()) }
                    val groupsD = async { runCatching { StudyGroup.list(Api.arr(cached("group_list", Cache.GROUPS))) }.getOrDefault(emptyList()) }
                    val groupMetaD = async {
                        runCatching {
                            val meta = Api.obj(Api.get("inbox_meta"))
                            val grs = meta.optJSONArray("groups")
                            val m = mutableMapOf<Int, Int>()
                            if (grs != null) {
                                for (i in 0 until grs.length()) {
                                    val g = grs.getJSONObject(i)
                                    m[g.optInt("group_id")] = g.optInt("unread", 0)
                                }
                            }
                            m
                        }.getOrDefault(emptyMap())
                    }
                    val coursesD = async { runCatching { Course.list(Api.arr(cached("courses", Cache.COURSES))) }.getOrDefault(emptyList()) }
                    val notifD = async { runCatching { NotificationItem.list(Api.arr(Api.get("notifications"))) }.getOrDefault(emptyList()) }
                    // FIX: حالت کاربر از سرور خوانده می‌شود (قبلاً هیچ‌وقت خوانده نمی‌شد).
                    val moodD = async { runCatching { Api.obj(Api.get("mood")).strOrNull("mood") }.getOrNull() }
                    val next = state.value.let { current ->
                        current.copy(
                            loading = false,
                            loaded = true,
                            today = todayD.await(),
                            streak = streakD.await(),
                            wakeup = wakeD.await(),
                            statusText = statusD.await(),
                            friends = friendsD.await(),
                            groups = groupsD.await(),
                            groupUnread = groupMetaD.await(),
                            courses = coursesD.await(),
                            notifications = notifD.await(),
                            mood = acceptServerMood(current.mood, moodD.await()),
                        )
                    }
                    if (Store.session.value != session || ir.studying.app.core.IranTime.todayIso() != day)
                        return@coroutineScope
                    state.value = next
                    /*
                     * The launcher widget runs in another process and cannot call
                     * the API, so the last screen that did talk to the server
                     * leaves the numbers behind for it.
                     */
                    /* حالت روی دیسک می‌ماند تا استارت بعدی هم همان را نشان دهد. */
                    runCatching { Store.putString(KEY_MOOD, state.value.mood) }
                    Goals.saveSnapshot(state.value.today.totalMinutes, state.value.streak, session.username, day)
                    ir.studying.app.widget.StudyWidget.refresh(ir.studying.app.App.instance)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (Store.session.value != session) return@launch
                // Raw exception text ("Failed to connect to …") tells the user nothing useful.
                state.update { it.copy(loading = false, error = humanizeError(e)) }
            }
        }
    }

    // ---------- Timer ----------
    fun startTimer() = ir.studying.app.player.Chrono.start()
    fun pauseTimer() = ir.studying.app.player.Chrono.pause()
    fun resetTimer() = ir.studying.app.player.Chrono.reset()

    fun setTimerCourse(courseId: Int?) {
        Store.saveTimer(Store.timer.value.copy(courseId = courseId))
    }

    // ---------- Actions ----------
    fun submitStudy(minutes: Int, courseId: Int?, onResult: (String?) -> Unit) {
        try {
            ir.studying.app.core.Offline.record(minutes, courseId ?: 0)
            ir.studying.app.notify.SyncWorker.kick(ir.studying.app.App.instance)
            onResult(null)
            refresh()
        } catch (e: Exception) { onResult(humanizeError(e)) }
    }

    fun setWakeup(time: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                Api.post("wakeup", JSONObject().put("wakeup_time", time))
                state.update { it.copy(wakeup = time) }
                onResult(null)
            } catch (e: Exception) {
                onResult(e.message ?: "خطا")
            }
        }
    }

    fun checkinWakeup(onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val res = Api.obj(Api.post("wakeup_checkin", JSONObject()))
                val t = res.optString("wakeup_time", "")
                state.update { it.copy(wakeup = t) }
                onResult(null)
            } catch (e: Exception) {
                onResult(e.message ?: "خطا")
            }
        }
    }

    fun setMood(emoji: String) {
        val previous = state.value.mood
        if (emoji == previous) return
        /*
         * The emoji used to jump: the old value stayed on screen until the
         * request came back, and a refresh landing in between painted the old
         * one again. The pick is applied first and only rolled back if the
         * server actually refuses it. moodTouched keeps a later refresh from
         * overwriting a fresh pick with a stale value.
         */
        moodTouched = System.currentTimeMillis()
        state.update { it.copy(mood = emoji) }
        viewModelScope.launch {
            val r = runCatching { Api.obj(Api.post("mood", JSONObject().put("mood", emoji))) }
            if (r.isFailure) {
                moodTouched = 0L
                state.update { it.copy(mood = previous) }
                ir.studying.app.ui.components.AppSnack.show("حالت ذخیره نشد")
            } else {
                /*
                 * FIX: مقداری که سرور واقعاً ذخیره کرده ملاک است و روی دیسک
                 * می‌نشیند؛ اینطور هیچ رفرشی نمی‌تواند انتخاب کاربر را عقب بزند.
                 */
                val saved = runCatching { r.getOrNull()?.strOrNull("mood") }.getOrNull()
                    ?.takeIf { it.isNotBlank() } ?: emoji
                state.update { it.copy(mood = saved) }
                runCatching { Store.putString(KEY_MOOD, saved) }
            }
        }
    }

    /** When the user last picked a mood by hand. Guards against stale refreshes. */
    private var moodTouched = 0L

    /** Disk slot for the mood emoji, so a cold start paints it instantly. */
    private val KEY_MOOD = "user_mood"

    /** A server value is ignored while a hand-picked mood is still this fresh. */
    fun acceptServerMood(current: String, incoming: String?): String {
        val next = (incoming ?: "").trim()
        if (next.isEmpty()) return current
        if (System.currentTimeMillis() - moodTouched < 90_000L) return current
        return next
    }

    fun setStatus(text: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                Api.post("status", JSONObject().put("status_text", text))
                state.update { it.copy(statusText = text) }
                onResult(null)
            } catch (e: Exception) {
                onResult(e.message ?: "خطا")
            }
        }
    }

    fun addCourse(name: String, color: String, icon: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                Api.post("courses", JSONObject().put("name", name).put("color", color).put("icon", icon))
                onResult(null)
                refreshCourses()
                // every other screen holding a course list reloads now
                ir.studying.app.core.RefreshBus.emit("courses")
            } catch (e: Exception) {
                onResult(e.message ?: "خطا")
            }
        }
    }

    fun deleteCourse(id: Int) {
        viewModelScope.launch {
            runCatching { Api.delete("courses", "id" to id.toString()) }
            refreshCourses()
            ir.studying.app.core.RefreshBus.emit("courses")
        }
    }

    /** بعد از وارد کردن درس آماده هم صدا زده می‌شود، پس دیگر private نیست. */
    fun refreshCourses() {
        viewModelScope.launch {
            runCatching { Course.list(Api.arr(Api.get("courses"))) }
                .onSuccess { list -> state.update { it.copy(courses = list) } }
        }
    }
}
