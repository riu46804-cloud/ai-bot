@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.library

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.data.MusicTrack
import kotlin.math.abs
import kotlin.math.sin

/* =============================================================================
 *  زبان طراحی بخش موزیک
 *
 *  هدف: یک حال‌وهوای «پلیرِ حرفه‌ای» — رنگِ اختصاصی هر آهنگ، صفحهٔ گرامافون
 *  چرخان، اکولایزر زنده، نوار پیشرفت گرادیانی و شیشه‌ای‌بودن سطح‌ها. همهٔ
 *  قطعه‌ها اینجا جمع‌اند تا مینی‌پلیر، پلیر کامل و لیست‌ها یک‌دست بمانند.
 * ========================================================================== */

/** پالت اختصاصی هر آهنگ: از روی id ساخته می‌شود، پس همیشه ثابت و متنوع است. */
fun trackPalette(track: MusicTrack?): Pair<Color, Color> {
    val palettes = listOf(
        Color(0xFF7C3AED) to Color(0xFFEC4899),
        Color(0xFF0EA5E9) to Color(0xFF22D3EE),
        Color(0xFFF97316) to Color(0xFFFACC15),
        Color(0xFF10B981) to Color(0xFF84CC16),
        Color(0xFFEF4444) to Color(0xFFF59E0B),
        Color(0xFF6366F1) to Color(0xFF06B6D4),
    )
    val id = track?.id ?: 0
    return palettes[((id % palettes.size) + palettes.size) % palettes.size]
}

/** اکولایزر زنده؛ وقتی پخش متوقف است میله‌ها آرام می‌گیرند. */
@Composable
fun Equalizer(playing: Boolean, color: Color, modifier: Modifier = Modifier, bars: Int = 4) {
    val t = rememberInfiniteTransition(label = "eq")
    val phase by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(900, easing = LinearEasing)), label = "eqPhase",
    )
    val idle by animateFloatAsState(if (playing) 1f else 0.18f, tween(320), label = "eqIdle")
    Canvas(modifier) {
        val w = size.width / (bars * 2f - 1f)
        repeat(bars) { i ->
            val s = (sin((phase * 2 * Math.PI + i * 1.5).toFloat()) + 1f) / 2f
            val h = size.height * (0.25f + 0.75f * s) * idle
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2 * w, size.height - h),
                size = androidx.compose.ui.geometry.Size(w, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w / 2f, w / 2f),
            )
        }
    }
}

/** صفحهٔ گرامافون: کاور داخل دیسک، با چرخش هنگام پخش. */
@Composable
fun VinylCover(
    track: MusicTrack?,
    size: Dp,
    playing: Boolean,
    modifier: Modifier = Modifier,
) {
    val (c1, c2) = trackPalette(track)
    val t = rememberInfiniteTransition(label = "vinyl")
    val spin by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "spin",
    )
    val speed by animateFloatAsState(if (playing) 1f else 0f, tween(600), label = "spinSpeed")
    val glow by t.animateFloat(
        0.35f, 0.8f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow",
    )
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        // هالهٔ رنگی پشت دیسک
        Box(
            Modifier
                .size(size)
                .background(
                    Brush.radialGradient(listOf(c1.copy(alpha = 0.35f * glow), Color.Transparent)),
                    CircleShape,
                ),
        )
        Box(
            Modifier
                .size(size * 0.92f)
                .rotate(spin * speed)
                .clip(CircleShape)
                .background(Brush.sweepGradient(listOf(Color(0xFF121212), Color(0xFF2A2A2A), Color(0xFF121212)))),
            contentAlignment = Alignment.Center,
        ) {
            // شیارهای دیسک
            Canvas(Modifier.fillMaxSize()) {
                val r = this.size.minDimension / 2f
                listOf(0.95f, 0.86f, 0.77f, 0.68f).forEach { f ->
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        radius = r * f,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f),
                    )
                }
            }
            TrackCover(track, size * 0.58f, corner = size * 0.29f)
            Box(
                Modifier
                    .size(size * 0.08f)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(c1, c2))),
            )
        }
    }
}

/**
 * نوار پیشرفت گرادیانی با دستگیرهٔ کشیدنی.
 *
 * چرا جای Slider استاندارد: می‌خواهیم نوار باریک، لبهٔ گرد و درخشش رنگیِ هم‌خوان
 * با پالت آهنگ داشته باشیم و هنگام کشیدن، عدد جابه‌جا نشود تا تپش نبینیم.
 */
@Composable
fun GradientSeekBar(
    progress: Float,
    colors: Pair<Color, Color>,
    modifier: Modifier = Modifier,
    height: Dp = 6.dp,
    onSeek: (Float) -> Unit,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    var widthPx by remember { mutableFloatStateOf(1f) }
    val shown = if (dragging) dragValue else progress.coerceIn(0f, 1f)
    val thumb by animateFloatAsState(if (dragging) 1.4f else 1f, spring(dampingRatio = 0.45f), label = "thumb")

    Box(
        modifier
            .fillMaxWidth()
            .height(26.dp)
            .pointerInput(Unit) {
                widthPx = size.width.toFloat().coerceAtLeast(1f)
                detectTapGestures { o -> onSeek((o.x / widthPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                widthPx = size.width.toFloat().coerceAtLeast(1f)
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        dragValue = (o.x / widthPx).coerceIn(0f, 1f)
                    },
                    onDragEnd = { dragging = false; onSeek(dragValue) },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, delta ->
                        change.consume()
                        dragValue = (dragValue + delta / widthPx).coerceIn(0f, 1f)
                    },
                )
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(height)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)),
        )
        Box(
            Modifier
                .fillMaxWidth(shown)
                .height(height)
                .clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(colors.first, colors.second))),
        )
        Box(
            Modifier
                .fillMaxWidth(shown)
                .height(height),
            contentAlignment = Alignment.CenterEnd,
        ) {
            Box(
                Modifier
                    .size(13.dp)
                    .scale(thumb)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(3.dp, colors.second, CircleShape),
            )
        }
    }
}

/** دکمهٔ گرد پخش با هالهٔ نبض‌دار. */
@Composable
fun GlowPlayButton(
    playing: Boolean,
    colors: Pair<Color, Color>,
    size: Dp = 72.dp,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    val t = rememberInfiniteTransition(label = "playGlow")
    val pulse by t.animateFloat(
        1f, 1.18f,
        infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.4f, stiffness = 700f), label = "press")
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size * 1.5f)) {
        Box(
            Modifier
                .size(size)
                .scale(if (playing) pulse else 1f)
                .background(
                    Brush.radialGradient(listOf(colors.first.copy(alpha = 0.45f), Color.Transparent)),
                    CircleShape,
                ),
        )
        Box(
            Modifier
                .size(size)
                .scale(press)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(colors.first, colors.second)))
                .clickable { pressed = true; onClick(); pressed = false },
            contentAlignment = Alignment.Center,
        ) { content() }
    }
}

/** سطح شیشه‌ای مشترک لیست‌ها و کارت‌ها. */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    corner: Dp = 20.dp,
    tint: Color = MaterialTheme.colorScheme.surface,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(
                Brush.verticalGradient(
                    listOf(tint.copy(alpha = 0.96f), tint.copy(alpha = 0.80f)),
                ),
            )
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(corner)),
    ) { content() }
}

/** چیپ کوچک با حالت فعال رنگی (شافل/تکرار/فیلتر). */
@Composable
fun MusicChip(
    label: String,
    active: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val bg by animateColorAsState(
        if (active) accent.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        tween(220), label = "chipBg",
    )
    val fg by animateColorAsState(
        if (active) accent else MaterialTheme.colorScheme.onSurfaceVariant,
        tween(220), label = "chipFg",
    )
    Row(
        modifier
            .clip(CircleShape)
            .background(bg)
            .clickable { onClick() }
            .padding(horizontal = 13.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Text(label, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** خط موج ساده برای هدر؛ فقط تزئینی و سبک. */
@Composable
fun WaveLine(color: Color, modifier: Modifier = Modifier, playing: Boolean = true) {
    val t = rememberInfiniteTransition(label = "wave")
    val shift by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "waveShift",
    )
    val amp by animateFloatAsState(if (playing) 1f else 0.25f, tween(400), label = "waveAmp")
    Canvas(modifier) {
        val h = size.height
        val step = 6f
        var x = 0f
        val path = androidx.compose.ui.graphics.Path()
        path.moveTo(0f, h / 2f)
        while (x <= size.width) {
            val y = h / 2f + sin(((x / size.width) * 12.56f) + shift * 6.28f) * (h / 2.6f) * amp *
                (0.45f + 0.55f * abs(sin((x / size.width) * 3.14f)))
            path.lineTo(x, y)
            x += step
        }
        drawPath(
            path,
            brush = Brush.horizontalGradient(listOf(color.copy(alpha = 0.15f), color, color.copy(alpha = 0.15f))),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f, cap = StrokeCap.Round),
        )
    }
}

@Composable
fun SpacerW(w: Dp) = Spacer(Modifier.width(w))
