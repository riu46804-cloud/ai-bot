@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.library

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import ir.studying.app.core.Api
import ir.studying.app.core.fa
import ir.studying.app.data.MusicTrack
import ir.studying.app.player.PlayerHolder
import java.util.Locale
import kotlinx.coroutines.delay

/* =============================================================================
 *  پلیر — بازطراحی کامل
 *
 *  قبل: یک ردیف ساده + شیت با اسلایدر پیش‌فرض. حالا: مینی‌پلیرِ شیشه‌ای با
 *  اکولایزر زنده و نوار پیشرفت مویی، و پلیر کامل با پس‌زمینهٔ بلورِ کاور،
 *  صفحهٔ گرامافون چرخان، سیک‌بار گرادیانی، دکمهٔ پخش نورانی و صف پخش.
 * ========================================================================== */

@Composable
fun TrackCover(track: MusicTrack?, size: androidx.compose.ui.unit.Dp, corner: androidx.compose.ui.unit.Dp = 12.dp) {
    val cover = Api.mediaUrl(track?.cover)
    if (cover != null) {
        AsyncImage(
            model = cover,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(corner))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
    } else {
        val (c1, c2) = trackPalette(track)
        Box(
            Modifier
                .size(size)
                .clip(RoundedCornerShape(corner))
                .background(Brush.linearGradient(listOf(c1, c2))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.92f),
                modifier = Modifier.size(size / 2),
            )
        }
    }
}

@Composable
fun MiniPlayer() {
    val queue by PlayerHolder.queue.collectAsState()
    val currentId by PlayerHolder.currentId.collectAsState()
    val isPlaying by PlayerHolder.isPlaying.collectAsState()
    val track = queue.find { it.id == currentId } ?: return
    var showFull by remember { mutableStateOf(false) }
    val colors = trackPalette(track)

    // نوار پیشرفت موییِ پایین کارت؛ بدون عدد، فقط حس حرکت
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(track.id) {
        while (true) {
            val (p, d) = PlayerHolder.position()
            pos = p; dur = d
            delay(700)
        }
    }
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f

    AnimatedVisibility(
        visible = true,
        enter = fadeIn(tween(240)) + slideInVertically(tween(280)) { it / 2 },
        exit = fadeOut(tween(160)),
    ) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            GlassSurface(corner = 22.dp, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(
                        Modifier
                            .clickable { showFull = true }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        VinylCover(track, 44.dp, playing = isPlaying)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Equalizer(
                                    playing = isPlaying,
                                    color = colors.second,
                                    modifier = Modifier.size(12.dp, 11.dp),
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    track.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f).basicMarquee(),
                                )
                            }
                            Text(
                                track.artist.ifBlank { track.username },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = { PlayerHolder.prev() }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Rounded.SkipPrevious, "قبلی", modifier = Modifier.size(20.dp))
                        }
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(colors.first, colors.second)))
                                .clickable { PlayerHolder.toggle() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                "پخش/توقف", tint = Color.White, modifier = Modifier.size(21.dp),
                            )
                        }
                        IconButton(onClick = { PlayerHolder.next() }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Rounded.SkipNext, "بعدی", modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { PlayerHolder.stopAndClear() }, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Rounded.Close, "بستن", modifier = Modifier.size(15.dp))
                        }
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(2.5.dp)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(frac)
                                .height(2.5.dp)
                                .background(Brush.horizontalGradient(listOf(colors.first, colors.second))),
                        )
                    }
                }
            }
        }
    }

    if (showFull) FullPlayerSheet(onDismiss = { showFull = false })
}

private fun fmtMs(ms: Long): String {
    if (ms <= 0) return "۰:۰۰"
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return String.format(Locale.US, "%d:%02d", m, s).fa()
}

@Composable
fun FullPlayerSheet(onDismiss: () -> Unit) {
    val queue by PlayerHolder.queue.collectAsState()
    val currentId by PlayerHolder.currentId.collectAsState()
    val isPlaying by PlayerHolder.isPlaying.collectAsState()
    val shuffle by PlayerHolder.shuffleOn.collectAsState()
    val repeat by PlayerHolder.repeatMode.collectAsState()
    val track = queue.find { it.id == currentId }
    val colors = trackPalette(track)
    var showQueue by remember { mutableStateOf(false) }

    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            val (p, d) = PlayerHolder.position()
            pos = p; dur = d
            delay(400)
        }
    }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Box(Modifier.fillMaxWidth()) {
            // پس‌زمینه: کاورِ بلورشده + پردهٔ گرادیانی هم‌رنگ آهنگ
            Api.mediaUrl(track?.cover)?.let { url ->
                AsyncImage(
                    model = url,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize().blur(46.dp).background(Color.Black.copy(alpha = 0.2f)),
                )
            }
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                colors.first.copy(alpha = 0.22f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                                MaterialTheme.colorScheme.surface,
                            ),
                        ),
                    ),
            )

            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp)
                    .padding(bottom = 30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(6.dp))
                VinylCover(track, 250.dp, playing = isPlaying)
                Spacer(Modifier.height(12.dp))
                WaveLine(
                    color = colors.second,
                    playing = isPlaying,
                    modifier = Modifier.fillMaxWidth().height(26.dp),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    track?.title ?: "",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    modifier = Modifier.basicMarquee(),
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    (track?.artist?.ifBlank { track.username } ?: ""),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                track?.username?.takeIf { it.isNotBlank() }?.let {
                    Text(
                        "آپلود: @$it",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                    )
                }

                Spacer(Modifier.height(16.dp))
                GradientSeekBar(
                    progress = if (dur > 0) pos.toFloat() / dur else 0f,
                    colors = colors,
                ) { f -> if (dur > 0) PlayerHolder.seekTo((f * dur).toLong()) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmtMs(pos), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fmtMs(dur), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Spacer(Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    IconButton(onClick = { PlayerHolder.toggleShuffle() }) {
                        Icon(
                            Icons.Rounded.Shuffle, "شافل",
                            tint = if (shuffle) colors.second else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { PlayerHolder.next() }) {
                        Icon(Icons.Rounded.SkipNext, "بعدی", modifier = Modifier.size(36.dp))
                    }
                    GlowPlayButton(playing = isPlaying, colors = colors, onClick = { PlayerHolder.toggle() }) {
                        Icon(
                            if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            "پخش/توقف", tint = Color.White, modifier = Modifier.size(34.dp),
                        )
                    }
                    IconButton(onClick = { PlayerHolder.prev() }) {
                        Icon(Icons.Rounded.SkipPrevious, "قبلی", modifier = Modifier.size(36.dp))
                    }
                    IconButton(onClick = { PlayerHolder.cycleRepeat() }) {
                        Icon(
                            if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            "تکرار",
                            tint = if (repeat != Player.REPEAT_MODE_OFF) colors.second else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                // صف پخش: تا حالا اصلاً دیده نمی‌شد و کاربر نمی‌دانست بعدی چیست
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .clip(CircleShape)
                        .clickable { showQueue = !showQueue }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.QueueMusic, null, tint = colors.second, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (showQueue) "بستن صف" else "صف پخش · ${queue.size.fa()}",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.second,
                        fontWeight = FontWeight.Bold,
                    )
                }
                AnimatedVisibility(showQueue, enter = fadeIn(tween(200)), exit = fadeOut(tween(140))) {
                    LazyColumn(
                        Modifier.fillMaxWidth().heightIn(max = 260.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(queue, key = { "q-" + it.id }) { q ->
                            val active = q.id == currentId
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (active) colors.first.copy(alpha = 0.14f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    )
                                    .clickable { PlayerHolder.play(queue, queue.indexOfFirst { it.id == q.id }) }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                TrackCover(q, 34.dp, corner = 10.dp)
                                Spacer(Modifier.width(9.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        q.title,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                        color = if (active) colors.second else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        q.artist.ifBlank { q.username },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                if (active) {
                                    Equalizer(playing = isPlaying, color = colors.second, modifier = Modifier.size(14.dp, 13.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** کارت بزرگ «در حال پخش» برای بالای تب موزیک. */
@Composable
fun NowPlayingBanner(onOpen: () -> Unit) {
    val queue by PlayerHolder.queue.collectAsState()
    val currentId by PlayerHolder.currentId.collectAsState()
    val isPlaying by PlayerHolder.isPlaying.collectAsState()
    val track = queue.find { it.id == currentId } ?: return
    val colors = trackPalette(track)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(colors.first.copy(alpha = 0.22f), colors.second.copy(alpha = 0.10f))))
            .border(1.dp, colors.first.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
            .clickable { onOpen() }
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            VinylCover(track, 60.dp, playing = isPlaying)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("در حال پخش", style = MaterialTheme.typography.labelSmall, color = colors.second, fontWeight = FontWeight.Bold)
                Text(
                    track.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    track.artist.ifBlank { track.username },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(colors.first, colors.second)))
                    .clickable { PlayerHolder.toggle() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    null, tint = Color.White, modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}
