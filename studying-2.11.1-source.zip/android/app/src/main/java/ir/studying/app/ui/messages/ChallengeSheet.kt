@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.messages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Challenges
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.fa
import ir.studying.app.focus.FocusLock
import ir.studying.app.focus.FocusMode
import kotlinx.coroutines.launch

/**
 * برگهٔ «چالش» در منوی پیوست چت.
 *
 * دو نوع پیشنهاد: رقابت مطالعه (مجموع دقیقه در چند روز) و پیشنهاد قفل گوشی
 * (با یکی از سه حالت قفل).
 */
@Composable
fun ChallengeSheet(
    onDismiss: () -> Unit,
    onSend: (kind: String, minutes: Int, days: Int, mode: FocusMode) -> Unit,
) {
    var kind by remember { mutableStateOf("study") }
    var minutes by remember { mutableStateOf("120") }
    var days by remember { mutableStateOf("3") }
    var mode by remember { mutableStateOf(FocusMode.APPS) }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 26.dp),
        ) {
            Text("چالش بده", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = kind == "study",
                    onClick = { kind = "study" },
                    label = { Text("رقابت مطالعه") },
                )
                FilterChip(
                    selected = kind == "lock",
                    onClick = { kind = "lock" },
                    label = { Text("پیشنهاد قفل گوشی") },
                )
            }

            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = minutes,
                onValueChange = { v -> minutes = v.filter { it.isDigit() }.take(4) },
                label = { Text(if (kind == "study") "هدف: دقیقه مطالعه" else "مدت قفل (دقیقه)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            if (kind == "study") {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = days,
                    onValueChange = { v -> days = v.filter { it.isDigit() }.take(2) },
                    label = { Text("در چند روز؟") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            } else {
                Spacer(Modifier.height(10.dp))
                Text("حالت قفل", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                // همان کارت‌های بخش قفل — یک زبان بصری در کل اپ.
                ir.studying.app.ui.focus.FocusModePicker(
                    selected = mode,
                    onSelect = { mode = it },
                    compact = true,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "اگر طرف مقابل بپذیرد، قفل روی گوشیٔ خودش بلافاصله روشن می‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val mins = (minutes.toIntOrNull() ?: 0).coerceIn(5, 1440)
                    val d = (days.toIntOrNull() ?: 1).coerceIn(1, 30)
                    onSend(kind, mins, d, mode)
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ارسال پیشنهاد") }
        }
    }
}

/**
 * کارت پیشنهاد چالش داخل حباب چت.
 *
 * وضعیت کارت از سرور خوانده می‌شود، نه از متن پیام: متن پیام ثابت است، پس
 * پیش از این کارتِ فرستنده تا همیشه «منتظر پاسخ» می‌ماند و کارتِ گیرنده هم
 * فقط خوش‌بینانه «پذیرفتی» نشان می‌داد، حتی وقتی سرور خطا داده بود.
 * پذیرش پیشنهاد قفل، قفل را روی همین دستگاه روشن می‌کند (خواستهٔ کاربر).
 */
@Composable
fun ChallengeCard(offer: Challenges.Offer, isMine: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isLock = offer.kind == "lock"
    var status by remember(offer.id) { mutableStateOf("pending") }
    var busy by remember(offer.id) { mutableStateOf(false) }

    LaunchedEffect(offer.id) {
        Challenges.states(listOf(offer.id))[offer.id]?.let { status = it }
    }
    LaunchedEffect(offer.id) {
        RefreshBus.events.collect { tag ->
            if (tag == Challenges.TAG || tag == "all") {
                Challenges.states(listOf(offer.id))[offer.id]?.let { status = it }
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Text(
            if (isLock) "🔒 پیشنهاد قفل گوشی" else "⚔️ پیشنهاد رقابت مطالعه",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            if (isLock)
                ("حالت: " + FocusMode.of(offer.mode).title + " — " + offer.minutes.toString() + " دقیقه").fa()
            else
                (offer.minutes.toString() + " دقیقه مطالعه در " + offer.days.toString() + " روز").fa(),
            style = MaterialTheme.typography.bodySmall,
        )

        Spacer(Modifier.height(8.dp))
        when {
            status == "pending" && !isMine -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !busy,
                    onClick = {
                        busy = true
                        scope.launch {
                            val err = Challenges.respond(offer.id, true)
                            busy = false
                            if (err != null) {
                                ir.studying.app.ui.components.AppSnack.show(err)
                            } else {
                                status = "accepted"
                                if (isLock) FocusLock.start(ctx, offer.minutes, mode = FocusMode.of(offer.mode))
                            }
                        }
                    },
                ) { Text("پذیرفتن") }
                OutlinedButton(
                    enabled = !busy,
                    onClick = {
                        busy = true
                        scope.launch {
                            val err = Challenges.respond(offer.id, false)
                            busy = false
                            if (err != null) ir.studying.app.ui.components.AppSnack.show(err) else status = "declined"
                        }
                    },
                ) { Text("رد کردن") }
            }

            status == "pending" -> Text(
                "منتظر پاسخ…",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            status == "accepted" -> Text(
                if (isLock) "پذیرفته شد؛ قفل روشن شد." else "پذیرفته شد؛ رقابت در جریان است.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )

            status == "declined" -> Text(
                "رد شد.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            status == "cancelled" -> Text(
                "لغو شد.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            else -> Text(
                "تمام شد.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * بخش «رقابت‌ها» در پایین صفحهٔ اصلی — هم‌شکل با بخش گروه‌ها و دوستان.
 *
 * پیشنهادهای هنوز تاییدنشده هم دیده می‌شوند و همان‌جا مدیریت می‌شوند:
 * پذیرش، رد کردن، لغو پیشنهاد خودی و پایان دادن به رقابت در جریان.
 * اگر چیزی نباشد، هیچ فضایی اشغال نمی‌کند.
 */
@Composable
fun ChallengesSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Challenges.Active>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    /*
     * قبلاً فقط یک بار در ساخت اولیه لیست گرفته می‌شد؛ چالشی که همان لحظه
     * ساخته یا پذیرفته می‌شد تا باز و بستهٔ بعدی اپ اینجا دیده نمی‌شد.
     */
    LaunchedEffect(Unit) { items = Challenges.list() }
    LaunchedEffect(Unit) {
        RefreshBus.events.collect { tag ->
            if (tag == Challenges.TAG || tag == "all" || tag == "home") items = Challenges.list()
        }
    }
    if (items.isEmpty()) return

    Column {
        ir.studying.app.ui.components.SectionTitle("رقابت‌ها")
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.id }) { c ->
                ChallengeRow(
                    c = c,
                    busy = busy,
                    onAccept = {
                        busy = true
                        scope.launch {
                            val err = Challenges.respond(c.id, true)
                            if (err != null) ir.studying.app.ui.components.AppSnack.show(err)
                            else if (c.kind == "lock") FocusLock.start(ctx, c.minutes, mode = FocusMode.of(c.mode))
                            items = Challenges.list(); busy = false
                        }
                    },
                    onDecline = {
                        busy = true
                        scope.launch {
                            val err = Challenges.respond(c.id, false)
                            if (err != null) ir.studying.app.ui.components.AppSnack.show(err)
                            items = Challenges.list(); busy = false
                        }
                    },
                    onCancel = {
                        busy = true
                        scope.launch {
                            val err = Challenges.cancel(c.id)
                            if (err != null) ir.studying.app.ui.components.AppSnack.show(err)
                            items = Challenges.list(); busy = false
                        }
                    },
                    /* رقابتی که به هدفش رسیده، پاداش دارد؛ بدون این دکمه امتیازش گرفته نمی‌شود. */
                    onClaim = {
                        busy = true
                        scope.launch {
                            val (err, got) = Challenges.claim(c.id)
                            if (err != null) ir.studying.app.ui.components.AppSnack.show(err)
                            else ir.studying.app.core.Awards.announce(got)
                            items = Challenges.list(); busy = false
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun ChallengeRow(
    c: Challenges.Active,
    busy: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onCancel: () -> Unit,
    onClaim: () -> Unit = {},
) {
    val pending = c.status == "pending"
    val isLock = c.kind == "lock"
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (pending) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f),
        ),
        modifier = Modifier.width(270.dp),
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ir.studying.app.ui.components.AnimatedEmoji(if (isLock) "🔒" else "⚔️", 30.dp, autoPlay = true, burst = false)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (isLock) "قفل مشترک با " else "رقابت با ") + c.opponent,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        if (isLock)
                            ("حالت " + FocusMode.of(c.mode).title + " · " + c.minutes.toString() + " دقیقه").fa()
                        else
                            ("هدف " + c.minutes.toString() + " دقیقه در " + c.days.toString() + " روز").fa(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (pending) {
                    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)) {
                        Text(
                            if (c.mine) "منتظر تایید" else "پیشنهاد تازه",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        )
                    }
                } else {
                    ir.studying.app.core.Icon3D(if (c.myMinutes >= c.theirMinutes) "🏆" else "⏳", 26.dp)
                }
            }

            if (!pending) {
                Spacer(Modifier.height(8.dp))
                Text(
                    ("تو: " + c.myMinutes.toString() + " دقیقه · او: " + c.theirMinutes.toString() + " دقیقه").fa(),
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (pending && !c.mine) {
                    Button(onClick = onAccept, enabled = !busy) { Text("پذیرفتن") }
                    OutlinedButton(onClick = onDecline, enabled = !busy) { Text("رد کردن") }
                } else if (pending) {
                    OutlinedButton(onClick = onCancel, enabled = !busy) { Text("لغو پیشنهاد") }
                } else {
                    if (c.canClaim) {
                        Button(onClick = onClaim, enabled = !busy) { ir.studying.app.core.EmojiText("دریافت پاداش 🏆") }
                    }
                    TextButton(onClick = onCancel, enabled = !busy) { Text("پایان رقابت") }
                }
            }
        }
    }
}
