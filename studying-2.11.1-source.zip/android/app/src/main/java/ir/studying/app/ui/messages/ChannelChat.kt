@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.messages

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.R
import ir.studying.app.core.Api
import ir.studying.app.core.NavBus
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.data.ChatMessage
import ir.studying.app.data.Reaction
import ir.studying.app.ui.components.AppSnack
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

class ChannelChatViewModel : ViewModel() {
    var channel: String = "public"
    private fun target() = mapOf("channel" to channel)
    val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val loading = MutableStateFlow(true)
    val uploadPercent = MutableStateFlow<Int?>(null)
    val canPost = MutableStateFlow(true)
    /** Deleted here, not yet gone from the server's list. */
    val removed = MutableStateFlow<Set<Int>>(emptySet())
    val sync = ChatSync(viewModelScope, { Store.session.value }) { Store.username ?: "" }

    private var boundChannel: String? = null
    fun bind(ch: String) {
        if (boundChannel != ch) {
            sync.clear(); messages.value = emptyList(); removed.value = emptySet(); loading.value = true
            boundChannel = ch
        }
        channel = ch; canPost.value = (ch != "news") || (Store.username == "habib")
    }

    fun poll() {
        val ch = channel
        val gen = sync.beginPoll()
        val session = Store.session.value
        viewModelScope.launch {
            runCatching { ChatMessage.list(Api.arr(Api.getForSession("chat", session, "channel" to ch))) }
                .onSuccess { list ->
                    val me = Store.username ?: ""
                    if (ch != channel || session != Store.session.value || !sync.publishPoll(gen, list.map { it.toUi(me, "m${it.id}", it.reactions) })) return@onSuccess
                    messages.value = list
                    loading.value = false
                    if (removed.value.isNotEmpty()) {
                        val ids = list.mapTo(HashSet()) { it.id }
                        removed.update { r -> r.filterTo(HashSet()) { it in ids } }
                    }
                }
                .onFailure { loading.value = false }
        }
    }

    /** Shows up at once with a clock; the server answer turns it into a tick. */
    fun send(text: String, replyTo: Int?, replySender: String?, replyPreview: String?, onErr: (String) -> Unit) {
        val t = text.trim(); if (t.isEmpty()) return
        val ch = channel
        val session = Store.session.value
        sync.queue(t, replyTo, replySender, replyPreview, afterId = lastId(), send = { o -> post(ch, o, session) }, onErr = onErr, after = { poll() })
    }

    fun retry(localId: Long, onErr: (String) -> Unit) {
        val ch = channel
        val session = Store.session.value
        sync.retry(localId, lastId(), send = { o -> post(ch, o, session) }, onErr = onErr, after = { poll() })
    }

    fun discard(localId: Long) = sync.discard(localId)

    private fun lastId(): Int = messages.value.maxOfOrNull { it.id } ?: 0

    private suspend fun post(ch: String, o: OutMsg, session: ir.studying.app.core.SessionState): Int? {
        val b = JSONObject().put("message", o.text).put("channel", ch)
        if (o.replyTo != null) b.put("reply_to", o.replyTo)
        // The endpoint may omit an ID; a fresh poll replaces the checked bubble atomically.
        return ChatSync.idOf(Api.postForSession("chat", b, session))
    }

    private fun sendMediaUri(ctx: Context, type: String, uri: Uri, onErr: (String) -> Unit) {
        viewModelScope.launch {
            uploadPercent.value = 0
            val err = ChatMedia.sendMedia(ctx, "channel", target(), type, uri, null) { uploadPercent.value = it }
            uploadPercent.value = null
            if (err != null) onErr(err); poll()
        }
    }
    fun sendImage(ctx: Context, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, "image", uri, onErr)
    fun sendFile(ctx: Context, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, "file", uri, onErr)
    fun sendMusicFile(ctx: Context, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, "music", uri, onErr)
    fun sendMusic(id: Int, onErr: (String) -> Unit) { viewModelScope.launch { ChatMedia.sendRef("channel", target(), "music", musicId = id)?.let(onErr); poll() } }
    fun sendSticker(id: Int, onErr: (String) -> Unit) { viewModelScope.launch { ChatMedia.sendRef("channel", target(), "sticker", stickerId = id)?.let(onErr); poll() } }

    fun react(msgId: Int, current: List<Reaction>, emoji: String) {
        sync.react(msgId, current, emoji, call = {
            Api.post("react", JSONObject().put("scope", "channel").put("id", msgId).put("emoji", emoji))
        }, after = { poll() })
    }

    /** The bubble leaves at once; it comes back if the server says no. */
    fun delete(id: Int, onErr: (String) -> Unit = {}) {
        removed.update { it + id }
        viewModelScope.launch {
            runCatching { Api.delete("chat", "id" to id.toString()) }
                .onFailure { removed.update { s -> s - id }; onErr(it.message ?: "حذف نشد") }
            poll()
        }
    }
}

@Composable
fun ChannelChatScreen(channel: String, title: String, emoji: String, onBack: () -> Unit, onOpenDm: (String) -> Unit = { NavBus.requestDm(it) }, vm: ChannelChatViewModel = viewModel(key = "ch_" + channel)) {
    val ctx = LocalContext.current
    val me = Store.username ?: ""
    val messages by vm.messages.collectAsState()
    val loading by vm.loading.collectAsState()
    val canPost by vm.canPost.collectAsState()
    val uploadPercent by vm.uploadPercent.collectAsState()
    val removed by vm.removed.collectAsState()
    val sessionForChat by Store.session.collectAsState()
    LaunchedEffect(sessionForChat) { vm.sync.ensureSession() }
    val timeline by vm.sync.timeline.collectAsState()
    val pending = timeline.pending
    val rx by vm.sync.reactions.map.collectAsState()
    val prefs by Store.prefs.collectAsState()
    val msgs = remember(timeline, rx, removed, me) {
        timelineChat(timeline, me, removed) { id, reactions -> vm.sync.reactions.view(id, reactions) }
    }
    val chat = rememberChatController(msgs, loading)
    val clip = LocalClipboardManager.current
    val muteKey = "ch:$channel"
    val muted = prefs.muted.contains(muteKey)

    var input by rememberSaveable(channel) { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<UiMsg?>(null) }
    var profileUser by remember { mutableStateOf<String?>(null) }
    var viewImage by remember { mutableStateOf<String?>(null) }
    var showAttach by remember { mutableStateOf(false) }
    var showStickers by remember { mutableStateOf(false) }
    var showMusic by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.sendImage(ctx, uri) { AppSnack.show(it) } }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.sendFile(ctx, uri) { AppSnack.show(it) } }
    val musicFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.sendMusicFile(ctx, uri) { AppSnack.show(it) } }

    LaunchedEffect(channel) { vm.bind(channel); vm.poll() }
    LaunchedEffect(channel) { while (true) { vm.poll(); delay(3000) } }

    // ریپلای «ندیده» — بدون تگ/منشن؛ فقط برای پیام‌هایی که کسی به من ریپلای کرده (تلگرامی، ماندگار روی دستگاه)
    var replySeenId by remember { mutableIntStateOf(0) }
    LaunchedEffect(channel) { replySeenId = Store.channelReplySeen(channel) }
    val replyIdx = msgs.indexOfLast { !it.mine && it.id > 0 && it.replySender == me }
    val replyMsgId = if (replyIdx >= 0) msgs[replyIdx].id else 0
    LaunchedEffect(replyMsgId, chat.listState) {
        if (replyMsgId > 0) snapshotFlow { chat.listState.layoutInfo.visibleItemsInfo.map { it.key } }
            .collect { vis ->
                val key = msgs.getOrNull(replyIdx)?.key
                if (key != null && key in vis && replyMsgId > replySeenId) {
                    replySeenId = replyMsgId
                    Store.setChannelReplySeen(channel, replyMsgId)
                }
            }
    }

    val senders = remember(msgs) { msgs.map { it.sender }.distinct().size }
    val tint = channelTint(channel, MaterialTheme.colorScheme.primary)
    ChatSurface(
        chat = chat, kind = ChatKind.CHANNEL, me = me, msgs = msgs, loading = loading,
        empty = {
            ChatEmpty(emoji, "هنوز پیامی نیست",
                if (canPost) "اولین نفری باش که اینجا می‌نویسه!" else "خبرهای تازه به‌زودی همین‌جا میاد")
        },
        topBar = {
            ChatTopBar(
                onBack = onBack, title = title,
                leading = { EmojiTile(emoji, tint, 42.dp) },
                subtitle = {
                    ChatStatus(
                        when {
                            !canPost -> "کانال اطلاع‌رسانی"
                            senders > 0 -> "${senders.fa()} نفر در این گفتگو"
                            else -> "گفتگوی همگانی"
                        },
                        typing = false, highlight = false,
                    )
                },
                actions = {
                    TopBarIcon(if (muted) Icons.Rounded.NotificationsOff else Icons.Rounded.NotificationsActive, if (muted) "صدادار کردن" else "بی‌صدا کردن",
                        tint = if (muted) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant, size = 22.dp) {
                        Store.toggleMute(muteKey); AppSnack.show(if (!muted) "بی‌صدا شد 🔕" else "صدادار شد 🔔")
                    }
                },
            )
        },
        bottomBar = {
            if (canPost) {
                ChatComposer(
                    value = input, onValueChange = { input = it }, placeholder = "پیامت رو بنویس…",
                    onSend = {
                        val t = input.trim()
                        if (t.isNotEmpty()) {
                            val r = replyTo
                            vm.send(t, r?.id?.takeIf { it > 0 }, r?.sender, r?.preview()) { AppSnack.show(it) }
                            input = ""; replyTo = null
                        }
                    },
                    onAttach = { showAttach = true },
                    reply = replyTo?.let { ReplyDraft(it.sender, it.preview()) },
                    onCancelReply = { replyTo = null },
                )
            } else ReadOnlyNotice(stringResource(R.string.channel_chat_002).removePrefix("📢").trim())
        },
        menuFor = { m ->
            if (m.pending) pendingMenu(m,
                copy = { clip.setText(AnnotatedString(it)) },
                retry = { m.localId?.let { id -> vm.retry(id) { e -> AppSnack.show(e) } } },
                discard = { m.localId?.let { id -> vm.discard(id) } })
            else buildList {
                if (canPost) add(MenuAction(Icons.AutoMirrored.Rounded.Reply, "پاسخ") { replyTo = m })
                if (!m.mine) add(MenuAction(Icons.Rounded.Person, "پروفایل ${m.sender}") { profileUser = m.sender })
                if (!m.text.isNullOrBlank() && m.type == "text") add(MenuAction(Icons.Rounded.ContentCopy, "کپی متن") { clip.setText(AnnotatedString(m.text)) })
                if (m.mine) add(MenuAction(Icons.Rounded.Delete, "حذف پیام", danger = true) {
                    if (replyTo?.key == m.key) replyTo = null
                    vm.delete(m.id) { AppSnack.show(it) }
                })
            }
        },
        onReact = { m, e -> if (!m.pending) vm.react(m.id, m.reactions, e) },
        onAvatar = { u -> if (u != me) profileUser = u },
        onImage = { viewImage = it },
        onRetry = { m -> m.localId?.let { id -> vm.retry(id) { e -> AppSnack.show(e) } } },
        onSwipeReply = if (canPost) ({ m -> if (!m.pending) replyTo = m }) else null,
        uploadPercent = uploadPercent,
        delivery = pending.filter { it.state == SendState.FAILED },
        onRestoreDelivery = { o ->
            val draft = restoreDeliveryDraft(o, input, replyTo, msgs)
            if (draft != null) {
                input = draft.text; replyTo = draft.reply; vm.discard(o.localId)
            } else AppSnack.show("کادر و پاسخ فعلی را خالی کن؛ برای پاسخ قبلی، پیام اصلی هم باید در گفتگو موجود باشد")
        },
        onDiscardDelivery = { o -> vm.discard(o.localId) },
        listOverlay = {
            SideFab(
                visible = replyIdx >= 0 && replyMsgId > replySeenId,
                raised = chat.awayFromBottom,
                onClick = {
                    replySeenId = replyMsgId
                    Store.setChannelReplySeen(channel, replyMsgId)
                    chat.jumpTo(replyIdx)
                },
            ) { Icon(Icons.AutoMirrored.Rounded.Reply, stringResource(R.string.channel_chat_001), tint = MaterialTheme.colorScheme.primary, modifier = Modifier) }
        },
    )

    if (showAttach) AttachSheet(
        onImage = { showAttach = false; imagePicker.launch("image/*") },
        onFile = { showAttach = false; filePicker.launch("*/*") },
        onMusic = { showAttach = false; showMusic = true },
        onMusicDevice = { showAttach = false; musicFilePicker.launch("audio/*") },
        onSticker = { showAttach = false; showStickers = true },
        onDismiss = { showAttach = false })
    if (showStickers) StickerPickerSheet(onPick = { st -> showStickers = false; vm.sendSticker(st.id) { AppSnack.show(it) } }, onDismiss = { showStickers = false })
    if (showMusic) ChatMusicPicker(onPick = { t -> showMusic = false; vm.sendMusic(t.id) { AppSnack.show(it) } }, onDismiss = { showMusic = false })

    viewImage?.let { ImageViewerDialog(it) { viewImage = null } }
    if (profileUser != null) {
        val pu = profileUser!!
        UserProfileSheet(username = pu, onDismiss = { profileUser = null }, onMessage = { profileUser = null; onOpenDm(pu) })
    }
}

@Composable
fun UserProfileSheet(username: String, onDismiss: () -> Unit, onMessage: () -> Unit) {
    // مستقیم صفحه اجتماعی کاربر باز می‌شود — بدون شیت واسطه
    ir.studying.app.ui.feed.SocialProfileDialog(username = username, onDismiss = onDismiss)
}
