package ir.studying.app.ui.messages

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Emoji3D
import ir.studying.app.core.EmojiCatalog
import ir.studying.app.core.EmojiParse
import ir.studying.app.core.EmojiText
import ir.studying.app.core.Icon3D
import ir.studying.app.ui.theme.brandGradient
import kotlinx.coroutines.launch
import kotlin.math.sin

/** What the composer shows above the field when replying. */
data class ReplyDraft(val sender: String, val preview: String)

/**
 * Chat composer: rounded field, 3D emoji keyboard, attach, and a send button
 * that morphs into the microphone when the field is empty.
 */
@Composable
fun ChatComposer(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onSend: () -> Unit,
    onAttach: (() -> Unit)? = null,
    onMic: (() -> Unit)? = null,
    reply: ReplyDraft? = null,
    onCancelReply: () -> Unit = {},
    top: (@Composable () -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val keyboard = LocalSoftwareKeyboardController.current
    val haptic = LocalHapticFeedback.current
    var tfv by remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    LaunchedEffect(value) { if (tfv.text != value) tfv = TextFieldValue(value, TextRange(value.length)) }
    var panel by rememberSaveable { mutableStateOf(false) }
    val fieldInteraction = remember { MutableInteractionSource() }
    val pressed by fieldInteraction.collectIsPressedAsState()
    LaunchedEffect(pressed) { if (pressed) panel = false }
    BackHandler(enabled = panel) { panel = false }

    fun update(n: TextFieldValue) { tfv = n; if (n.text != value) onValueChange(n.text) }

    Column(Modifier.fillMaxWidth().background(cs.surface.copy(alpha = 0.97f))) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, cs.outlineVariant, Color.Transparent))))
        AnimatedVisibility(visible = reply != null, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            var last by remember { mutableStateOf(reply) }
            if (reply != null) last = reply
            last?.let { ReplyStrip(it, onCancelReply) }
        }
        top?.invoke()
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.Bottom) {
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                    .background(cs.surfaceVariant.copy(alpha = 0.62f))
                    .border(1.dp, cs.outlineVariant.copy(alpha = 0.55f), RoundedCornerShape(24.dp)),
                verticalAlignment = Alignment.Bottom,
            ) {
                IconButton(onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    if (panel) { panel = false; keyboard?.show() } else { keyboard?.hide(); panel = true }
                }) {
                    AnimatedContent(targetState = panel, transitionSpec = {
                        (scaleIn(initialScale = 0.4f) + fadeIn()).togetherWith(scaleOut(targetScale = 0.4f) + fadeOut())
                    }, label = "emojiKb") { open ->
                        Icon(if (open) Icons.Rounded.Keyboard else Icons.Rounded.EmojiEmotions, if (open) "صفحه‌کلید" else "ایموجی",
                            tint = if (open) cs.primary else cs.onSurfaceVariant)
                    }
                }
                Box(Modifier.weight(1f).padding(vertical = 13.dp)) {
                    if (tfv.text.isEmpty()) Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant.copy(alpha = 0.75f), maxLines = 1)
                    BasicTextField(
                        value = tfv,
                        onValueChange = { update(it) },
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = cs.onSurface),
                        cursorBrush = SolidColor(cs.primary),
                        maxLines = 5,
                        interactionSource = fieldInteraction,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (onAttach != null) {
                    IconButton(onClick = { panel = false; onAttach() }) {
                        Icon(Icons.Rounded.AttachFile, "پیوست", tint = cs.onSurfaceVariant, modifier = Modifier.graphicsLayer { rotationZ = 35f })
                    }
                } else Spacer(Modifier.width(10.dp))
            }
            Spacer(Modifier.width(7.dp))
            SendMicButton(mic = tfv.text.isBlank() && onMic != null, enabled = tfv.text.isNotBlank() || onMic != null) {
                if (tfv.text.isBlank() && onMic != null) onMic()
                else if (tfv.text.isNotBlank()) { onSend() }
            }
        }
        AnimatedVisibility(visible = panel, enter = expandVertically(tween(220)) + fadeIn(), exit = shrinkVertically(tween(180)) + fadeOut()) {
            EmojiPanel(
                onPick = { e ->
                    val t = tfv
                    val s = t.selection.min
                    val en = t.selection.max
                    val n = t.text.substring(0, s) + e + t.text.substring(en)
                    update(TextFieldValue(n, TextRange(s + e.length)))
                },
                onBackspace = { update(deleteBefore(tfv)) },
            )
        }
    }
}

/** Removes the emoji cluster (or character) before the cursor. */
fun deleteBefore(t: TextFieldValue): TextFieldValue {
    val text = t.text
    if (!t.selection.collapsed) {
        val s = t.selection.min
        return TextFieldValue(text.removeRange(s, t.selection.max), TextRange(s))
    }
    val pos = t.selection.start
    if (pos <= 0) return t
    var i = 0
    var start = 0
    while (i < pos) {
        val end = EmojiParse.clusterEnd(text, i)
        val next = if (end > i) end else i + Character.charCount(text.codePointAt(i))
        start = i
        i = next
    }
    val cut = start.coerceAtMost(pos)
    return TextFieldValue(text.removeRange(cut, pos.coerceAtMost(text.length)), TextRange(cut))
}

@Composable
private fun SendMicButton(mic: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val scope = rememberCoroutineScope()
    val bounce = remember { Animatable(1f) }
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier.size(48.dp)
            .graphicsLayer { scaleX = bounce.value; scaleY = bounce.value; alpha = if (enabled) 1f else 0.5f }
            .clip(CircleShape)
            .background(brandGradient())
            .clickable(enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                scope.launch {
                    bounce.snapTo(0.82f)
                    bounce.animateTo(1f, spring(dampingRatio = 0.38f, stiffness = 600f))
                }
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(targetState = mic, transitionSpec = {
            (scaleIn(initialScale = 0.3f, animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f)) + fadeIn(tween(120)))
                .togetherWith(scaleOut(targetScale = 0.3f, animationSpec = tween(120)) + fadeOut(tween(100)))
        }, label = "sendMic") { m ->
            Icon(if (m) Icons.Rounded.Mic else Icons.AutoMirrored.Rounded.Send, if (m) "ضبط صدا" else "ارسال",
                tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(23.dp)
                    .graphicsLayer { if (!m) rotationZ = 0f })
        }
    }
}

@Composable
fun ReplyStrip(draft: ReplyDraft, onCancel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.AutoMirrored.Rounded.Reply, null, tint = cs.primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.width(3.dp).height(34.dp).clip(CircleShape).background(cs.primary))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("پاسخ به ${draft.sender}", style = MaterialTheme.typography.labelMedium, color = cs.primary, fontWeight = FontWeight.Bold, maxLines = 1)
            EmojiText(draft.preview, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onCancel) { Icon(Icons.Rounded.Close, "لغو پاسخ", modifier = Modifier.size(20.dp)) }
    }
}

/** Telegram style 3D emoji keyboard: one scrolling grid, tabs jump between sections. */
@Composable
fun EmojiPanel(onPick: (String) -> Unit, onBackspace: () -> Unit, height: Dp = 292.dp) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { EmojiCatalog.load() }
    val recent by EmojiCatalog.recent.collectAsState()
    val cats = remember {
        EmojiCatalog.categories.map { c -> c.copy(emojis = c.emojis.filter { Emoji3D.has(ctx, it) }) }.filter { it.emojis.isNotEmpty() }
    }
    val recentList = remember(recent) { recent.filter { Emoji3D.has(ctx, it) } }
    // Section start indexes inside the grid (each section = 1 header + its emoji).
    val sections = remember(cats, recentList) {
        val out = ArrayList<Pair<String, List<String>>>()
        if (recentList.isNotEmpty()) out.add("اخیر" to recentList)
        cats.forEach { out.add(it.title to it.emojis) }
        out
    }
    val starts = remember(sections) {
        var acc = 0
        sections.map { s -> acc.also { acc += 1 + s.second.size } }
    }
    val grid = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val current by remember(starts) { derivedStateOf { starts.indexOfLast { it <= grid.firstVisibleItemIndex }.coerceAtLeast(0) } }
    val tabIcons = remember(sections, cats) {
        val icons = ArrayList<String?>()
        if (recentList.isNotEmpty()) icons.add(null)
        cats.forEach { icons.add(it.icon) }
        icons
    }
    Column(Modifier.fillMaxWidth().height(height).background(cs.surface)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                itemsIndexed(tabIcons) { i, icon ->
                    val sel = i == current
                    Box(
                        Modifier.size(38.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (sel) cs.primary.copy(alpha = 0.16f) else Color.Transparent)
                            .clickable { scope.launch { grid.animateScrollToItem(starts[i]) } },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (icon == null) Icon(Icons.Rounded.History, "اخیر", tint = if (sel) cs.primary else cs.onSurfaceVariant, modifier = Modifier.size(22.dp))
                        else Icon3D(icon, 26.dp, Modifier.graphicsLayer { val s = if (sel) 1.08f else 0.92f; scaleX = s; scaleY = s; alpha = if (sel) 1f else 0.7f })
                    }
                }
            }
            IconButton(onClick = onBackspace) { Icon(Icons.AutoMirrored.Rounded.Backspace, "پاک کردن", tint = cs.onSurfaceVariant) }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(46.dp),
            state = grid,
            modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
        ) {
            sections.forEach { (title, list) ->
                item(span = { GridItemSpan(maxLineSpan) }, contentType = "h") {
                    Text(title, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 6.dp, top = 8.dp, bottom = 4.dp))
                }
                items(list.size, contentType = { "e" }) { i ->
                    EmojiCell(list[i]) { EmojiCatalog.use(list[i]); onPick(list[i]) }
                }
            }
        }
    }
}

@Composable
private fun EmojiCell(emoji: String, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scope = rememberCoroutineScope()
    val pop = remember { Animatable(1f) }
    Box(
        Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
            .clickable(interaction, indication = null) {
                scope.launch { pop.snapTo(1.35f); pop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = 500f)) }
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon3D(emoji, 34.dp, Modifier.graphicsLayer { val s = pop.value * (if (pressed) 0.86f else 1f); scaleX = s; scaleY = s })
    }
}

/** Voice recording strip that replaces the composer while recording. */
@Composable
fun RecordingBar(elapsed: String, onCancel: () -> Unit, onSend: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "rec")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "recPulse")
    val wave by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "recWave")
    Row(Modifier.fillMaxWidth().background(cs.surface).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onCancel) { Icon(Icons.Rounded.Delete, "لغو ضبط", tint = cs.error) }
        Box(Modifier.size(12.dp).graphicsLayer { scaleX = 0.8f + 0.4f * pulse; scaleY = scaleX; alpha = 0.6f + 0.4f * pulse }
            .background(Color(0xFFFF3B5C), CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(elapsed, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(12.dp))
        Row(Modifier.weight(1f).height(28.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(18) { i ->
                val h = 0.25f + 0.75f * ((sin((wave * 6.283f) + i * 0.7f) + 1f) / 2f) * (0.5f + 0.5f * ((i * 37) % 10) / 10f)
                Box(Modifier.width(3.dp).fillMaxHeightFraction(h).clip(CircleShape).background(cs.primary.copy(alpha = 0.75f)))
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(48.dp).clip(CircleShape).background(brandGradient()).clickable { onSend() }, contentAlignment = Alignment.Center) {
            Icon(Icons.AutoMirrored.Rounded.Send, "ارسال صدا", tint = cs.onPrimary, modifier = Modifier.size(22.dp))
        }
    }
}

private fun Modifier.fillMaxHeightFraction(f: Float): Modifier = this.then(Modifier.height((28 * f.coerceIn(0.1f, 1f)).dp))
