@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package ir.studying.app.ui.messages

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Emoji3D
import ir.studying.app.core.EmojiParse
import ir.studying.app.core.EmojiText
import ir.studying.app.core.Fmt
import ir.studying.app.core.Icon3D
import ir.studying.app.core.fa
import ir.studying.app.data.Reaction
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.SparkBurst
import ir.studying.app.ui.components.userColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/* =====================================================================
 * Chat kit: one bubble, one list item, one look for DM, group and channel.
 * ===================================================================== */

enum class Tick { NONE, SENDING, SENT, READ, FAILED }

enum class ChatKind { DM, GROUP, CHANNEL }

/** Everything a bubble needs, whatever chat it came from. */
@Immutable
data class UiMsg(
    val key: String,
    /** Server id, or a negative number for a message that is still pending. */
    val id: Int,
    val sender: String,
    val mine: Boolean,
    val type: String,
    val text: String?,
    val createdAt: String,
    val mediaPath: String? = null,
    val fileName: String? = null,
    val fileSize: Int? = null,
    val duration: Int? = null,
    val replyTo: Int? = null,
    val replySender: String? = null,
    val replyText: String? = null,
    val edited: Boolean = false,
    val reactions: List<Reaction> = emptyList(),
    val tick: Tick = Tick.NONE,
    val avatar: String? = null,
    val mood: String? = null,
    val localId: Long? = null,
) {
    val pending: Boolean get() = localId != null
}

/** Neighbour info for Telegram style grouping of consecutive messages. */
@Immutable
data class Grouping(val top: Boolean, val bottom: Boolean, val newDay: Boolean)

private fun dayOf(m: UiMsg) = m.createdAt.substringBefore(' ')
private fun minuteOf(m: UiMsg): Int {
    val t = m.createdAt.substringAfter(' ', "")
    if (t.length < 5) return 0
    return (t.substring(0, 2).toIntOrNull() ?: 0) * 60 + (t.substring(3, 5).toIntOrNull() ?: 0)
}
private fun near(a: UiMsg, b: UiMsg) = a.sender == b.sender && dayOf(a) == dayOf(b) && abs(minuteOf(a) - minuteOf(b)) <= 6

fun groupingOf(list: List<UiMsg>, i: Int): Grouping {
    val m = list[i]
    val p = list.getOrNull(i - 1)
    val n = list.getOrNull(i + 1)
    val newDay = p == null || dayOf(p) != dayOf(m)
    val top = p != null && !newDay && near(p, m)
    val bottom = n != null && dayOf(n) == dayOf(m) && near(m, n)
    return Grouping(top, bottom, newDay)
}

/* -------------------------------------------------------------- palette -- */

@Immutable
data class BubblePalette(
    val mineA: Color,
    val mineB: Color,
    val onMine: Color,
    val onMineSoft: Color,
    val other: Color,
    val onOther: Color,
    val onOtherSoft: Color,
    val otherBorder: Color,
    val accent: Color,
    val dark: Boolean,
)

@Composable
fun rememberBubblePalette(): BubblePalette {
    val cs = MaterialTheme.colorScheme
    return remember(cs.primary, cs.secondary, cs.background, cs.surface) {
        val dark = cs.background.luminance() < 0.4f
        val a = if (dark) lerp(cs.primary, Color.Black, 0.42f) else lerp(cs.primary, Color.Black, 0.04f)
        val mid = lerp(cs.primary, cs.secondary, 0.6f)
        val b = if (dark) lerp(mid, Color.Black, 0.5f) else lerp(mid, Color.Black, 0.10f)
        val on = if (lerp(a, b, 0.5f).luminance() > 0.6f) Color(0xFF0F1E18) else Color.White
        BubblePalette(
            mineA = a, mineB = b, onMine = on, onMineSoft = on.copy(alpha = 0.72f),
            other = if (dark) lerp(cs.surface, Color.White, 0.07f) else Color.White,
            onOther = cs.onSurface, onOtherSoft = cs.onSurfaceVariant,
            otherBorder = cs.outlineVariant.copy(alpha = if (dark) 0.55f else 0.8f),
            accent = cs.primary, dark = dark,
        )
    }
}

/** Material colours remapped so anything inside a coloured bubble stays readable. */
@Composable
fun MineBubbleTheme(p: BubblePalette, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scheme = remember(cs.primary, cs.secondary, p) {
        cs.copy(
            primary = p.onMine, onPrimary = p.mineA,
            primaryContainer = p.onMine.copy(alpha = 0.18f), onPrimaryContainer = p.onMine,
            secondaryContainer = p.onMine.copy(alpha = 0.2f), onSecondaryContainer = p.onMine,
            onSurface = p.onMine, onSurfaceVariant = p.onMineSoft,
            surface = p.onMine.copy(alpha = 0.14f), surfaceVariant = p.onMine.copy(alpha = 0.16f),
            outlineVariant = p.onMine.copy(alpha = 0.3f),
        )
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalContentColor provides p.onMine) { content() }
    }
}

/* ------------------------------------------------------------ wallpaper -- */

/** Soft gradient wallpaper with study doodles, cached per size. */
fun Modifier.chatWallpaper(base: Color, a: Color, b: Color, dark: Boolean): Modifier = drawWithCache {
    val w = size.width
    val h = size.height
    val bg = Brush.verticalGradient(listOf(lerp(base, a, if (dark) 0.08f else 0.07f), base, lerp(base, b, if (dark) 0.09f else 0.08f)))
    val blobs = listOf(
        Triple(Offset(w * 0.88f, h * 0.10f), w * 0.62f, a.copy(alpha = if (dark) 0.13f else 0.10f)),
        Triple(Offset(w * 0.05f, h * 0.52f), w * 0.70f, b.copy(alpha = if (dark) 0.11f else 0.09f)),
        Triple(Offset(w * 0.78f, h * 0.98f), w * 0.58f, a.copy(alpha = if (dark) 0.10f else 0.08f)),
    )
    val doodles = Path()
    val step = 74.dp.toPx()
    val unit = 7.dp.toPx()
    val rnd = java.util.Random(11)
    var row = 0
    var y = step * 0.4f
    while (y < h + step) {
        var x = if (row % 2 == 0) step * 0.3f else step * 0.8f
        while (x < w + step) {
            val jx = x + (rnd.nextFloat() - 0.5f) * step * 0.35f
            val jy = y + (rnd.nextFloat() - 0.5f) * step * 0.35f
            val s = unit * (0.7f + rnd.nextFloat() * 0.6f)
            when (rnd.nextInt(7)) {
                0 -> doodles.addOval(Rect(jx - s * 0.6f, jy - s * 0.6f, jx + s * 0.6f, jy + s * 0.6f))
                1 -> { doodles.moveTo(jx - s, jy); doodles.lineTo(jx + s, jy); doodles.moveTo(jx, jy - s); doodles.lineTo(jx, jy + s) }
                2 -> { // sparkle
                    doodles.moveTo(jx, jy - s); doodles.quadraticBezierTo(jx, jy, jx + s, jy)
                    doodles.quadraticBezierTo(jx, jy, jx, jy + s); doodles.quadraticBezierTo(jx, jy, jx - s, jy)
                    doodles.quadraticBezierTo(jx, jy, jx, jy - s)
                }
                3 -> { // open book
                    doodles.moveTo(jx, jy - s * 0.5f); doodles.quadraticBezierTo(jx - s * 0.6f, jy - s * 0.9f, jx - s * 1.2f, jy - s * 0.5f)
                    doodles.lineTo(jx - s * 1.2f, jy + s * 0.6f); doodles.quadraticBezierTo(jx - s * 0.6f, jy + s * 0.2f, jx, jy + s * 0.6f)
                    doodles.quadraticBezierTo(jx + s * 0.6f, jy + s * 0.2f, jx + s * 1.2f, jy + s * 0.6f)
                    doodles.lineTo(jx + s * 1.2f, jy - s * 0.5f); doodles.quadraticBezierTo(jx + s * 0.6f, jy - s * 0.9f, jx, jy - s * 0.5f)
                    doodles.lineTo(jx, jy + s * 0.6f)
                }
                4 -> { // squiggle
                    doodles.moveTo(jx - s * 1.2f, jy); doodles.quadraticBezierTo(jx - s * 0.6f, jy - s * 0.8f, jx, jy)
                    doodles.quadraticBezierTo(jx + s * 0.6f, jy + s * 0.8f, jx + s * 1.2f, jy)
                }
                5 -> { // heart
                    doodles.moveTo(jx, jy + s * 0.8f)
                    doodles.cubicTo(jx - s * 1.3f, jy - s * 0.1f, jx - s * 0.6f, jy - s * 1.1f, jx, jy - s * 0.35f)
                    doodles.cubicTo(jx + s * 0.6f, jy - s * 1.1f, jx + s * 1.3f, jy - s * 0.1f, jx, jy + s * 0.8f)
                }
                else -> { // triangle
                    doodles.moveTo(jx, jy - s * 0.8f); doodles.lineTo(jx + s * 0.8f, jy + s * 0.6f); doodles.lineTo(jx - s * 0.8f, jy + s * 0.6f); doodles.close()
                }
            }
            x += step
        }
        y += step * 0.72f
        row++
    }
    val doodleColor = (if (dark) Color.White else lerp(a, Color.Black, 0.3f)).copy(alpha = if (dark) 0.045f else 0.06f)
    val stroke = Stroke(1.3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    onDrawBehind {
        drawRect(bg)
        blobs.forEach { (c, r, col) -> drawCircle(Brush.radialGradient(listOf(col, Color.Transparent), c, r), r, c) }
        drawPath(doodles, doodleColor, style = stroke)
    }
}

/* -------------------------------------------------------------- top bar -- */

@Composable
fun ChatTopBar(
    onBack: () -> Unit,
    title: String,
    leading: @Composable () -> Unit,
    subtitle: @Composable () -> Unit,
    onTitleClick: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth().background(cs.surface.copy(alpha = 0.94f))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "بازگشت") }
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .then(if (onTitleClick != null) Modifier.clickable { onTitleClick() } else Modifier)
                    .padding(vertical = 2.dp, horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                leading()
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    EmojiText(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    subtitle()
                }
            }
            actions()
        }
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(1.dp)
            .background(Brush.horizontalGradient(listOf(Color.Transparent, cs.outlineVariant.copy(alpha = 0.9f), Color.Transparent))))
    }
}

/** Status line under the chat title; typing gets animated dots. */
@Composable
fun ChatStatus(text: String, typing: Boolean, highlight: Boolean) {
    val cs = MaterialTheme.colorScheme
    AnimatedContent(
        targetState = typing to text,
        transitionSpec = { (fadeIn(tween(180)) + slideInVertically { it / 2 }).togetherWith(fadeOut(tween(120)) + slideOutVertically { -it / 2 }) },
        label = "chatStatus",
    ) { (t, s) ->
        if (t) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("در حال نوشتن", style = MaterialTheme.typography.labelSmall, color = cs.primary)
            Spacer(Modifier.width(4.dp))
            TypingDots(cs.primary, 4.dp)
        } else if (s.isNotBlank()) Text(s, style = MaterialTheme.typography.labelSmall,
            color = if (highlight) cs.primary else cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun TypingDots(color: Color, dot: Dp) {
    val t = rememberInfiniteTransition(label = "typing")
    val ph by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1050, easing = LinearEasing)), label = "typingPh")
    Row(horizontalArrangement = Arrangement.spacedBy(dot * 0.7f), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val local = ((ph - i * 0.18f) % 1f + 1f) % 1f
            val lift = if (local < 0.5f) sin(local * 2f * Math.PI.toFloat()) else 0f
            Box(Modifier.size(dot).graphicsLayer {
                translationY = -lift * dot.toPx() * 0.9f
                alpha = 0.45f + 0.55f * lift.coerceAtLeast(0f)
            }.background(color, CircleShape))
        }
    }
}

/* ---------------------------------------------------------- bubble shape -- */

/** Rounded bubble with a Telegram tail on the last message of a group. */
class BubbleShape(
    private val mine: Boolean,
    private val tail: Boolean,
    private val joinTop: Boolean,
    private val joinBottom: Boolean,
    private val radius: Dp = 18.dp,
    private val joined: Dp = 6.dp,
    private val tailWidth: Dp = TailWidth,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val t = with(density) { tailWidth.toPx() }
        val w = size.width
        val h = size.height
        val l = if (mine) 0f else t
        val r = if (mine) w - t else w
        val maxR = min((r - l) / 2f, h / 2f)
        val big = min(with(density) { radius.toPx() }, maxR)
        val small = min(with(density) { joined.toPx() }, maxR)
        val tl = if (!mine && joinTop) small else big
        val tr = if (mine && joinTop) small else big
        val br = if (mine) (if (tail) 0f else if (joinBottom) small else big) else big
        val bl = if (!mine) (if (tail) 0f else if (joinBottom) small else big) else big
        val tailH = min(h * 0.6f, t * 2.1f)
        val p = Path()
        p.moveTo(l + tl, 0f)
        p.lineTo(r - tr, 0f)
        if (tr > 0f) p.arcTo(Rect(r - 2 * tr, 0f, r, 2 * tr), -90f, 90f, false)
        if (mine && tail) {
            p.lineTo(r, h - tailH)
            p.cubicTo(r, h - tailH * 0.32f, r + t * 0.35f, h - 0.8f, w, h)
            p.lineTo(l + bl, h)
        } else {
            p.lineTo(r, h - br)
            if (br > 0f) p.arcTo(Rect(r - 2 * br, h - 2 * br, r, h), 0f, 90f, false)
            p.lineTo(l + bl, h)
        }
        if (!mine && tail) {
            p.lineTo(0f, h)
            p.cubicTo(l - t * 0.35f, h - 0.8f, l, h - tailH * 0.32f, l, h - tailH)
        } else if (bl > 0f) {
            p.arcTo(Rect(l, h - 2 * bl, l + 2 * bl, h), 90f, 90f, false)
        }
        p.lineTo(l, tl)
        if (tl > 0f) p.arcTo(Rect(l, 0f, l + 2 * tl, 2 * tl), 180f, 90f, false)
        p.close()
        return Outline.Generic(p)
    }
}

val TailWidth = 7.dp

/* ---------------------------------------------------------------- ticks -- */

/** Clock while sending, a tick once the server has it, two ticks once read. */
@Composable
fun TickIcon(tick: Tick, color: Color, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    if (tick == Tick.NONE) return
    if (tick == Tick.FAILED) {
        Icon(Icons.Rounded.ErrorOutline, "ارسال نشد — لمس برای تلاش دوباره", tint = Color(0xFFFF5A6E),
            modifier = modifier.size(16.dp).clip(CircleShape)
                .then(if (onRetry != null) Modifier.clickable { onRetry() } else Modifier))
        return
    }
    val sent by animateFloatAsState(if (tick == Tick.SENT || tick == Tick.READ) 1f else 0f, tween(300, easing = FastOutSlowInEasing), label = "tick1")
    val read by animateFloatAsState(if (tick == Tick.READ) 1f else 0f, tween(320, delayMillis = 90, easing = FastOutSlowInEasing), label = "tick2")
    val clock by animateFloatAsState(if (tick == Tick.SENDING) 1f else 0f, tween(200), label = "tickClock")
    Box(modifier.size(width = 17.dp, height = 12.dp), contentAlignment = Alignment.Center) {
        if (clock > 0.01f) SendingClock(color.copy(alpha = color.alpha * clock), Modifier.size(11.dp).graphicsLayer { scaleX = 0.6f + 0.4f * clock; scaleY = scaleX })
        if (sent > 0.001f) Canvas(Modifier.size(width = 17.dp, height = 12.dp)) {
            val w = size.width
            val hh = size.height
            val sw = 1.5.dp.toPx()
            val pm = PathMeasure()
            fun check(dx: Float, progress: Float) {
                if (progress <= 0f) return
                val path = Path().apply {
                    moveTo(dx + w * 0.04f, hh * 0.55f)
                    lineTo(dx + w * 0.25f, hh * 0.88f)
                    lineTo(dx + w * 0.66f, hh * 0.12f)
                }
                pm.setPath(path, false)
                val seg = Path()
                pm.getSegment(0f, pm.length * progress.coerceIn(0f, 1f), seg, true)
                drawPath(seg, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            // A single tick sits centred; the second one slides in beside it.
            val base = w * 0.14f * (1f - read)
            check(base, sent)
            if (read > 0f) check(base + w * 0.30f, read)
        }
    }
}

@Composable
private fun SendingClock(color: Color, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "clock")
    val a by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "clockA")
    Canvas(modifier) {
        val sw = 1.3.dp.toPx()
        val r = size.minDimension / 2f - sw / 2f
        drawCircle(color, r, style = Stroke(sw))
        rotate(a) { drawLine(color, center, Offset(center.x, center.y - r * 0.62f), sw, StrokeCap.Round) }
        rotate(a / 12f + 90f) { drawLine(color, center, Offset(center.x, center.y - r * 0.42f), sw, StrokeCap.Round) }
    }
}

/** Time, "edited" and the ticks. */
@Composable
fun BubbleMeta(time: String, edited: Boolean, tick: Tick, color: Color, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    Row(modifier.padding(top = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        if (edited) {
            Text("ویرایش‌شده", fontSize = 10.sp, color = color, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.width(4.dp))
        }
        Text(time, fontSize = 10.5.sp, color = color, style = MaterialTheme.typography.labelSmall)
        if (tick != Tick.NONE) {
            Spacer(Modifier.width(3.dp))
            TickIcon(tick, color, onRetry = onRetry)
        }
    }
}

/** Meta on a translucent pill, for stickers and big emoji that have no bubble. */
@Composable
fun MetaPill(time: String, tick: Tick, onRetry: (() -> Unit)? = null) {
    Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.32f)) {
        BubbleMeta(time, false, tick, Color.White, Modifier.padding(horizontal = 8.dp, vertical = 2.dp), onRetry)
    }
}

/* ------------------------------------------------------------ rich text -- */

private val mentionRe = Regex("@[\\w\\u0600-\\u06FF]+")
private val urlRe = Regex("https?://\\S+")

/** Emoji drawn in 3D, @mentions and links coloured. */
@Composable
fun rememberRichText(text: String, accent: Color, me: String?): Pair<AnnotatedString, Map<String, InlineTextContent>> {
    val ctx = LocalContext.current
    return remember(text, accent, me) {
        val ids = ArrayList<Int>()
        val segs = EmojiParse.segments(text)
        val out = buildAnnotatedString {
            for (s in segs) {
                val id = if (s.emoji) Emoji3D.resId(ctx, s.text) else 0
                if (id != 0) {
                    appendInlineContent("e${ids.size}", s.text)
                    ids.add(id)
                    continue
                }
                val plain = s.text
                var last = 0
                val spans = (mentionRe.findAll(plain) + urlRe.findAll(plain)).sortedBy { it.range.first }
                for (mt in spans) {
                    if (mt.range.first < last) continue
                    append(plain.substring(last, mt.range.first))
                    val isMe = me != null && mt.value.equals("@$me", ignoreCase = true)
                    withStyle(SpanStyle(color = accent, fontWeight = FontWeight.SemiBold,
                        background = if (isMe) accent.copy(alpha = 0.16f) else Color.Unspecified)) { append(mt.value) }
                    last = mt.range.last + 1
                }
                if (last < plain.length) append(plain.substring(last))
            }
        }
        val inline = ids.mapIndexed { i, resId ->
            "e$i" to InlineTextContent(Placeholder(1.28.em, 1.28.em, PlaceholderVerticalAlign.TextCenter)) {
                androidx.compose.foundation.Image(androidx.compose.ui.res.painterResource(resId), null,
                    modifier = Modifier.fillMaxSize())
            }
        }.toMap()
        out to inline
    }
}

/**
 * Text with the time tucked into the end of the last line when it fits, on its
 * own line when it does not — exactly how Telegram does it.
 */
@Composable
fun TextWithMeta(
    text: AnnotatedString,
    inline: Map<String, InlineTextContent>,
    style: TextStyle,
    color: Color,
    meta: @Composable () -> Unit,
) {
    val holder = remember { arrayOfNulls<TextLayoutResult>(1) }
    Layout(content = {
        Text(text, style = style, color = color, inlineContent = inline, onTextLayout = { holder[0] = it })
        meta()
    }) { ms, c ->
        val tp = ms[0].measure(c.copy(minWidth = 0))
        val mp = ms[1].measure(Constraints())
        val gap = 8.dp.roundToPx()
        val lay = holder[0]
        val rtl = layoutDirection == LayoutDirection.Rtl
        var width = tp.width
        var height = tp.height
        var inlineMeta = false
        if (lay != null && lay.lineCount > 0) {
            val last = lay.lineCount - 1
            val left = lay.getLineLeft(last)
            val right = lay.getLineRight(last)
            val lineW = right - left
            val need = lineW + mp.width + gap
            if (rtl) {
                if (left >= mp.width + gap) inlineMeta = true
                else if (right >= tp.width - 1f && need <= c.maxWidth) { width = max(tp.width, ceil(need).toInt()); inlineMeta = true }
            } else {
                if (tp.width - right >= mp.width + gap) inlineMeta = true
                else if (left <= 1f && need <= c.maxWidth) { width = max(tp.width, ceil(need).toInt()); inlineMeta = true }
            }
        }
        if (!inlineMeta) { width = max(tp.width, mp.width); height = tp.height + mp.height }
        width = width.coerceIn(c.minWidth, c.maxWidth)
        layout(width, height) {
            tp.place(if (rtl) width - tp.width else 0, 0)
            mp.place(if (rtl) 0 else width - mp.width, if (inlineMeta) height - mp.height else tp.height)
        }
    }
}

/* ------------------------------------------------------------ reactions -- */

/**
 * Reaction chips under a message. A chip that appears pops in with a burst;
 * the user's own reaction plays its motion; counts roll like a counter.
 */
@Composable
fun ReactionChips(
    reactions: List<Reaction>,
    onMineBubble: Boolean,
    standalone: Boolean,
    p: BubblePalette,
    modifier: Modifier = Modifier,
    onReact: ((String) -> Unit)? = null,
) {
    if (reactions.isEmpty()) return
    val initial = remember { reactions.map { it.emoji }.toSet() }
    FlowRow(modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        reactions.forEach { r ->
            key(r.emoji) { ReactionChip(r, appearing = r.emoji !in initial, onMineBubble, standalone, p, onReact) }
        }
    }
}

@Composable
private fun ReactionChip(r: Reaction, appearing: Boolean, onMineBubble: Boolean, standalone: Boolean, p: BubblePalette, onReact: ((String) -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val pop = remember { Animatable(if (appearing) 0f else 1f) }
    var playKey by remember { mutableStateOf<Int?>(null) }
    var wasMine by remember { mutableStateOf(r.mine) }
    LaunchedEffect(Unit) {
        if (appearing) {
            pop.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = 520f))
        }
    }
    LaunchedEffect(r.mine) {
        if (r.mine && (!wasMine || appearing)) playKey = (playKey ?: 0) + 1
        wasMine = r.mine
    }
    val (bg, fg) = when {
        standalone -> if (r.mine) p.accent to cs.onPrimary else cs.surface.copy(alpha = 0.92f) to cs.onSurface
        onMineBubble -> if (r.mine) p.onMine.copy(alpha = 0.95f) to p.mineA else p.onMine.copy(alpha = 0.18f) to p.onMine
        else -> if (r.mine) p.accent to cs.onPrimary else p.accent.copy(alpha = 0.12f) to p.accent
    }
    Box(contentAlignment = Alignment.Center) {
        Row(
            Modifier
                .graphicsLayer { scaleX = pop.value; scaleY = pop.value; alpha = pop.value.coerceIn(0f, 1f) }
                .clip(CircleShape)
                .background(bg)
                .then(if (standalone && !r.mine) Modifier.border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), CircleShape) else Modifier)
                .then(if (onReact != null) Modifier.clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onReact(r.emoji)
                } else Modifier)
                .padding(start = 5.dp, end = 8.dp, top = 2.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedEmoji(r.emoji, 20.dp, playKey = playKey, burst = false)
            if (r.count > 1 || standalone) {
                Spacer(Modifier.width(3.dp))
                AnimatedContent(
                    targetState = r.count,
                    transitionSpec = {
                        if (targetState > initialState) (slideInVertically { it } + fadeIn()).togetherWith(slideOutVertically { -it } + fadeOut())
                        else (slideInVertically { -it } + fadeIn()).togetherWith(slideOutVertically { it } + fadeOut())
                    },
                    label = "reactCount",
                ) { c -> Text(c.fa(), color = fg, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
            }
        }
        SparkBurst(key = playKey, emoji = r.emoji, modifier = Modifier.matchParentSize())
    }
}

/* ------------------------------------------------------------- big emoji -- */

@Composable
fun BigEmojiBody(emojis: List<String>, playOnEnter: Boolean, onLongPress: () -> Unit) {
    val size = when (emojis.size) { 1 -> 96.dp; 2 -> 72.dp; else -> 58.dp }
    Row(Modifier.combinedClickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {}, onLongClick = onLongPress),
        horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        emojis.forEachIndexed { i, e ->
            var tap by remember { mutableIntStateOf(0) }
            LaunchedEffect(Unit) { if (playOnEnter) { delay(140L + i * 120L); tap++ } }
            AnimatedEmoji(e, size, playKey = if (tap == 0) null else tap, onClick = {})
        }
    }
}

/* ------------------------------------------------------------- reply box -- */

@Composable
fun ReplyQuote(sender: String?, text: String?, accent: Color, onClick: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.padding(bottom = 4.dp).clip(RoundedCornerShape(8.dp))
            .background(accent.copy(alpha = 0.12f))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(3.dp).height(36.dp).background(accent))
        Spacer(Modifier.width(7.dp))
        Column(Modifier.padding(vertical = 4.dp)) {
            Text(sender ?: "", style = MaterialTheme.typography.labelMedium, color = accent, fontWeight = FontWeight.Bold, maxLines = 1)
            EmojiText(text?.ifBlank { "رسانه" } ?: "رسانه", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/* ---------------------------------------------------------------- bubble -- */

/** Callbacks a chat screen hands to every bubble. */
class BubbleActions(
    val onMenu: (UiMsg, Rect) -> Unit,
    val onReact: (UiMsg, String) -> Unit,
    val onAvatar: (String) -> Unit,
    val onImage: (String) -> Unit,
    val onRetry: (UiMsg) -> Unit,
    val onReplyJump: (UiMsg) -> Unit,
    val onSwipeReply: ((UiMsg) -> Unit)?,
)

/**
 * One list item: optional date divider, then the row with avatar and bubble.
 * [fresh] plays the entrance; [hidden] blanks the bubble while the message
 * menu shows its lifted copy.
 */
@Composable
fun ChatItem(
    m: UiMsg,
    g: Grouping,
    kind: ChatKind,
    p: BubblePalette,
    me: String,
    fresh: Boolean,
    hidden: Boolean,
    highlight: Boolean,
    actions: BubbleActions,
    special: (@Composable () -> Unit)? = null,
) {
    Column(Modifier.fillMaxWidth()) {
        if (g.newDay) DateDivider(Fmt.dayLabel(m.createdAt))
        val flash by animateFloatAsState(if (highlight) 1f else 0f, tween(450), label = "flash")
        val enter = remember { Animatable(if (fresh) 0f else 1f) }
        LaunchedEffect(Unit) { if (fresh) enter.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 380f)) }
        val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
        val menu: () -> Unit = {
            val c = coords[0]
            if (c != null && c.isAttached) actions.onMenu(m, c.boundsInRoot())
        }
        val row: @Composable () -> Unit = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(p.accent.copy(alpha = 0.16f * flash))
                        .padding(top = if (g.top) 1.5.dp else 5.dp, bottom = 0.5.dp)
                        .graphicsLayer {
                            val e = enter.value
                            alpha = e.coerceIn(0f, 1f)
                            translationY = (1f - e) * 30.dp.toPx()
                            scaleX = 0.86f + 0.14f * e
                            scaleY = 0.86f + 0.14f * e
                            transformOrigin = TransformOrigin(if (m.mine) 1f else 0f, 1f)
                        },
                    horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start,
                    verticalAlignment = Alignment.Bottom,
                ) {
                    if (!m.mine && kind != ChatKind.DM) {
                        Box(Modifier.width(40.dp), contentAlignment = Alignment.BottomStart) {
                            if (!g.bottom) Box(Modifier.clip(CircleShape).clickable { actions.onAvatar(m.sender) }) {
                                Avatar(m.sender, null, size = 32.dp, avatarUrl = m.avatar)
                            }
                        }
                    }
                    Box(Modifier
                        .onGloballyPositioned { coords[0] = it }
                        .graphicsLayer { alpha = if (hidden) 0f else 1f }) {
                        BubbleBody(m, g, kind, p, me, fresh, interactive = true, onTap = menu, onLongPress = menu, actions = actions, special = special)
                    }
                }
            }
        }
        val swipe = actions.onSwipeReply
        if (swipe != null && !m.pending) SwipeReply(onReply = { swipe(m) }) { row() } else row()
    }
}

/** The bubble itself. Shared by the list and the lifted copy in the message menu. */
@Composable
fun BubbleBody(
    m: UiMsg,
    g: Grouping,
    kind: ChatKind,
    p: BubblePalette,
    me: String,
    fresh: Boolean,
    interactive: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    actions: BubbleActions?,
    special: (@Composable () -> Unit)? = null,
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val maxW = (LocalConfiguration.current.screenWidthDp * 0.8f).dp.coerceAtMost(420.dp)
    val time = remember(m.createdAt) { Fmt.timeOf(m.createdAt) }
    val retry: (() -> Unit)? = if (actions != null && m.tick == Tick.FAILED) ({ actions.onRetry(m) }) else null
    val react: ((String) -> Unit)? = if (actions != null && interactive && !m.pending) ({ e -> actions.onReact(m, e) }) else null
    val big = remember(m.text, m.type, m.replyTo) {
        if (m.type == "text" && m.replyTo == null && special == null)
            EmojiParse.onlyEmoji(m.text, 3)?.takeIf { l -> l.all { Emoji3D.has(ctx, it) } } else null
    }
    val plainMedia = m.type == "sticker" || m.type == "gif"
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        when {
            big != null || plainMedia -> Column(horizontalAlignment = if (m.mine) Alignment.Start else Alignment.End) {
                // Rtl here: Start is the right edge, where my messages live.
                if (big != null) BigEmojiBody(big, playOnEnter = fresh, onLongPress = onLongPress)
                else Box(Modifier.combinedClickable(onClick = onTap, onLongClick = onLongPress)) {
                    MediaBody(m.type, m.mediaPath, m.fileName, m.fileSize, m.duration, null, { actions?.onImage?.invoke(it) }, onLongPress = onLongPress)
                }
                Spacer(Modifier.height(2.dp))
                MetaPill(time, m.tick, retry)
                ReactionChips(m.reactions, onMineBubble = false, standalone = true, p = p, onReact = react)
            }
            else -> {
                val shape = remember(m.mine, g.top, g.bottom) { BubbleShape(m.mine, tail = !g.bottom, joinTop = g.top, joinBottom = g.bottom) }
                val bg = if (m.mine) Brush.linearGradient(listOf(p.mineA, p.mineB)) else SolidColor(p.other)
                Box(
                    Modifier
                        .widthIn(max = maxW)
                        .then(if (!m.mine) Modifier.shadow(1.dp, shape, clip = false,
                            ambientColor = Color.Black.copy(alpha = 0.18f), spotColor = Color.Black.copy(alpha = 0.18f)) else Modifier)
                        .clip(shape)
                        .background(bg)
                        .then(if (interactive) Modifier.combinedClickable(onClick = onTap, onLongClick = onLongPress) else Modifier)
                        // Rtl: start is the right edge. The tail sits right for mine, left for others.
                        .padding(
                            start = if (m.mine) 10.dp + TailWidth else 11.dp,
                            end = if (m.mine) 11.dp else 10.dp + TailWidth,
                            top = 6.dp, bottom = 5.dp,
                        ),
                ) {
                    val content: @Composable () -> Unit = {
                        BubbleContent(m, g, kind, p, me, time, retry, react, interactive, onLongPress, actions, special)
                    }
                    if (m.mine) MineBubbleTheme(p) { content() } else content()
                }
            }
        }
    }
}

@Composable
private fun BubbleContent(
    m: UiMsg, g: Grouping, kind: ChatKind, p: BubblePalette, me: String, time: String,
    retry: (() -> Unit)?, react: ((String) -> Unit)?, interactive: Boolean, onLongPress: () -> Unit,
    actions: BubbleActions?, special: (@Composable () -> Unit)?,
) {
    val cs = MaterialTheme.colorScheme
    val metaColor = if (m.mine) p.onMineSoft else cs.onSurfaceVariant.copy(alpha = 0.85f)
    val accent = if (m.mine) p.onMine else p.accent
    Column {
        if (!m.mine && kind != ChatKind.DM && !g.top) {
            Text(m.sender, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = userColor(m.sender),
                maxLines = 1, modifier = Modifier.padding(bottom = 1.dp)
                    .then(if (interactive && actions != null) Modifier.clickable { actions.onAvatar(m.sender) } else Modifier))
        }
        if (m.replyTo != null || m.replySender != null) {
            ReplyQuote(m.replySender, m.replyText, if (m.mine) p.onMine else userColor(m.replySender ?: ""),
                onClick = if (interactive && actions != null && m.replyTo != null) ({ actions.onReplyJump(m) }) else null)
        }
        val meta: @Composable () -> Unit = { BubbleMeta(time, m.edited, m.tick, metaColor, onRetry = retry) }
        when {
            special != null -> { special(); Box(Modifier.align(Alignment.End)) { meta() } }
            m.type == "text" -> {
                val (rich, inline) = rememberRichText(m.text ?: "", accent, me)
                TextWithMeta(rich, inline, MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp), if (m.mine) p.onMine else p.onOther, meta)
            }
            else -> {
                MediaBody(m.type, m.mediaPath, m.fileName, m.fileSize, m.duration, m.text, { actions?.onImage?.invoke(it) }, onLongPress = onLongPress)
                Box(Modifier.align(Alignment.End)) { meta() }
            }
        }
        if (m.reactions.isNotEmpty()) ReactionChips(m.reactions, onMineBubble = m.mine, standalone = false, p = p, onReact = react)
    }
}

/* ------------------------------------------------------------ swipe reply -- */

/** Swipe a message to the left to reply, like Telegram. */
@Composable
fun SwipeReply(onReply: () -> Unit, content: @Composable () -> Unit) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val offset = remember { Animatable(0f) }
    var armed by remember { mutableStateOf(false) }
    val threshold = with(androidx.compose.ui.platform.LocalDensity.current) { 64.dp.toPx() }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth()) {
            val prog = (-offset.value / threshold).coerceIn(0f, 1f)
            if (prog > 0.05f) {
                Box(
                    Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).size(32.dp)
                        .graphicsLayer { scaleX = 0.5f + 0.5f * prog; scaleY = scaleX; alpha = prog }
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f + 0.2f * prog), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.AutoMirrored.Rounded.Reply, "پاسخ", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp)) }
            }
            Box(Modifier
                .draggable(
                    state = rememberDraggableState { d ->
                        scope.launch {
                            val next = (offset.value + d).coerceIn(-threshold * 1.4f, 0f)
                            offset.snapTo(next)
                            val nowArmed = -next >= threshold
                            if (nowArmed && !armed) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            armed = nowArmed
                        }
                    },
                    orientation = Orientation.Horizontal,
                    onDragStopped = {
                        if (armed) onReply()
                        armed = false
                        scope.launch { offset.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 500f)) }
                    })
                .graphicsLayer { translationX = offset.value }) { content() }
        }
    }
}

/* ----------------------------------------------------------- list chrome -- */

@Composable
fun DateDivider(label: String) {
    if (label.isBlank()) return
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        DatePill(label)
    }
}

@Composable
fun DatePill(label: String) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f), shadowElevation = 1.dp) {
        Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
    }
}

/** Floating date at the top while the user scrolls, like Telegram. */
@Composable
fun BoxScope.FloatingDate(listState: LazyListState, labelAt: (Int) -> String?) {
    var visible by remember { mutableStateOf(false) }
    val labelFn by androidx.compose.runtime.rememberUpdatedState(labelAt)
    val label by remember(listState) { derivedStateOf { labelFn(listState.firstVisibleItemIndex) ?: "" } }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { s ->
            if (s) visible = true else { delay(1100); visible = false }
        }
    }
    AnimatedVisibility(visible = visible && label.isNotBlank(), enter = fadeIn(tween(150)) + slideInVertically { -it },
        exit = fadeOut(tween(300)), modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp)) {
        DatePill(label)
    }
}

/** Jump to the newest message, with the number of messages below. */
@Composable
fun BoxScope.JumpFab(visible: Boolean, below: Int, onClick: () -> Unit) {
    AnimatedVisibility(visible = visible, enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(), exit = scaleOut() + fadeOut(),
        modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)) {
        Box {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp, onClick = onClick) {
                Icon(Icons.Rounded.KeyboardArrowDown, "پیام‌های تازه", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(10.dp).size(24.dp))
            }
            if (below > 0) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.TopCenter).offset(y = (-12).dp)) {
                    AnimatedContent(targetState = below, label = "below") { n ->
                        Text(if (n > 99) "۹۹+" else n.fa(), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp))
                    }
                }
            }
        }
    }
}

/** Arrival bookkeeping: only messages that arrive while the chat is open animate in. */
class ArrivalTracker {
    private val born = HashMap<String, Long>()
    private var primed = false

    /** [loaded]: the first real answer from the server is in (an empty chat counts). */
    fun update(keys: List<String>, loaded: Boolean = true) {
        val now = System.currentTimeMillis()
        if (!primed) {
            if (!loaded) return
            keys.forEach { born[it] = 0L }
            primed = true
            return
        }
        keys.forEach { if (it !in born) born[it] = now }
    }

    fun isFresh(key: String): Boolean {
        val t = born[key] ?: return false
        return t > 0L && System.currentTimeMillis() - t < 1600L
    }
}

/** Typing bubble for the bottom of a DM. */
@Composable
fun TypingBubble(p: BubblePalette) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            val shape = remember { BubbleShape(mine = false, tail = true, joinTop = false, joinBottom = false) }
            Box(Modifier.shadow(1.dp, shape, clip = false).clip(shape).background(p.other).padding(start = 10.dp + TailWidth, end = 14.dp, top = 12.dp, bottom = 12.dp)) {
                TypingDots(p.onOtherSoft, 7.dp)
            }
        }
    }
}

/** Little 3D emoji in a rounded tile, used for channel avatars. */
@Composable
fun EmojiTile(emoji: String, tint: Color, size: Dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.32f))
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.95f), lerp(tint, Color.Black, 0.28f)))),
        contentAlignment = Alignment.Center,
    ) { Icon3D(emoji, size * 0.66f) }
}
