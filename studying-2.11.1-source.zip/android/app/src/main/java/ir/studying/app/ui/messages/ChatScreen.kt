@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.messages

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import ir.studying.app.core.Api
import ir.studying.app.core.EmojiText
import ir.studying.app.core.Fmt
import ir.studying.app.core.fa
import ir.studying.app.data.ChatMessage
import ir.studying.app.data.DmMessage
import ir.studying.app.data.GroupMessage
import ir.studying.app.data.Reaction
import ir.studying.app.ui.components.AnimatedEmoji
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.EmojiMotion
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max

/* =====================================================================
 * Chat screen frame shared by DM, group and channel chats: wallpaper,
 * message list, floating date, jump button, message menu and splash.
 * ===================================================================== */

/* --------------------------------------------------------------- mapping -- */

fun OutMsg.toUi(me: String): UiMsg = UiMsg(
    key = key, id = -(localId.toInt()), sender = me, mine = true, type = "text", text = text,
    createdAt = createdAt, replyTo = replyTo, replySender = replySender, replyText = replyPreview,
    tick = when (state) { SendState.SENDING -> Tick.SENDING; SendState.SENT -> Tick.SENT; SendState.FAILED -> Tick.FAILED },
    localId = localId,
)

fun DmMessage.toUi(me: String, key: String, reactions: List<Reaction>): UiMsg = UiMsg(
    key = key, id = id, sender = sender, mine = sender == me, type = type, text = message, createdAt = createdAt,
    mediaPath = mediaPath, fileName = fileName, fileSize = fileSize, duration = duration,
    replyTo = replyTo, replySender = replySender,
    replyText = when (replyType) {
        "image" -> "📷 عکس"; "voice" -> "🎤 پیام صوتی"; "file" -> "📎 فایل"; "music" -> "🎵 موزیک"; "sticker" -> "استیکر"
        else -> replyMessage?.let { ir.studying.app.core.Challenges.label(it) }
    },
    edited = edited, reactions = reactions,
    tick = if (sender == me) (if (isRead) Tick.READ else Tick.SENT) else Tick.NONE,
    avatar = senderAvatar,
)

fun ChatMessage.toUi(me: String, key: String, reactions: List<Reaction>): UiMsg = UiMsg(
    key = key, id = id, sender = sender, mine = sender == me, type = type, text = message, createdAt = createdAt,
    mediaPath = mediaPath, fileName = fileName, fileSize = fileSize, duration = duration,
    replyTo = replyTo, replySender = replySender, replyText = replyMessage?.ifBlank { "📎 رسانه" },
    reactions = reactions, tick = if (sender == me) Tick.SENT else Tick.NONE,
    avatar = senderAvatar, mood = senderMood,
)

fun GroupMessage.toUi(me: String, key: String, reactions: List<Reaction>): UiMsg = UiMsg(
    key = key, id = id, sender = sender, mine = sender == me, type = type, text = message, createdAt = createdAt,
    mediaPath = mediaPath, fileName = fileName, fileSize = fileSize, duration = duration,
    replyTo = replyTo, replySender = replySender,
    replyText = if (replyTo != null || replySender != null) (replyMessage?.ifBlank { null } ?: "📎 رسانه") else null,
    reactions = reactions, tick = if (sender == me) Tick.SENT else Tick.NONE,
    avatar = senderAvatar,
)

/** Server history only: local delivery operations never become message rows.
 * Distinct positive server ids remain distinct even for identical text. */
fun serverChat(server: List<UiMsg>): List<UiMsg> = server
    .filter { it.id > 0 }
    .distinctBy { it.id }
    .map { it.copy(key = "m${it.id}", localId = null) }

/** Render a single immutable timeline; an exact acknowledged server ID wins. */
fun timelineChat(timeline: ChatTimeline, me: String, removed: Set<Int> = emptySet(),
    reactions: (Int, List<Reaction>) -> List<Reaction> = { _, value -> value }): List<UiMsg> {
    val server = serverChat(timeline.server.filter { it.id !in removed })
        .map { it.copy(reactions = reactions(it.id, it.reactions)) }
    val ids = server.mapTo(HashSet()) { it.id }
    val pending = timeline.pending.filter { it.state != SendState.FAILED && (it.serverId == null || it.serverId !in ids) }
        .map { it.toUi(me) }
    return server + pending
}

data class RestoredChatDraft(val text: String, val reply: UiMsg?)

/** Restore the original reply context, never borrow a different active draft. */
fun restoreDeliveryDraft(item: OutMsg, currentText: String, currentReply: UiMsg?, rows: List<UiMsg>): RestoredChatDraft? {
    if (currentText.isNotBlank() || currentReply != null) return null
    val reply = item.replyTo?.let { id -> rows.firstOrNull { it.id == id && !it.pending } }
    if (item.replyTo != null && reply == null) return null
    return RestoredChatDraft(item.text, reply)
}

/** Short text for reply strips and previews. */
fun UiMsg.preview(): String = when (type) {
    "image" -> "📷 عکس"; "voice" -> "🎤 پیام صوتی"; "file" -> "📎 ${fileName ?: "فایل"}"
    "music" -> "🎵 ${text ?: "موزیک"}"; "sticker" -> "استیکر"; "gif" -> "GIF"
    else -> ir.studying.app.core.Challenges.label(text)
}

/* ------------------------------------------------------------ controller -- */

@Stable
class ChatController internal constructor(val listState: LazyListState, private val scope: CoroutineScope) {
    var flashKey by mutableStateOf<String?>(null)
        internal set
    internal var msgs: List<UiMsg> = emptyList()

    /** The newest messages are out of sight (the jump button shows). */
    val awayFromBottom: Boolean by derivedStateOf {
        val li = listState.layoutInfo
        li.totalItemsCount > 0 && (li.visibleItemsInfo.lastOrNull()?.index ?: 0) < li.totalItemsCount - 2
    }

    /** Scrolls to the message at [index] and flashes it. */
    fun jumpTo(index: Int) {
        val m = msgs.getOrNull(index) ?: return
        scope.launch {
            runCatching {
                val first = listState.firstVisibleItemIndex
                if (kotlin.math.abs(first - index) > 30) listState.scrollToItem((index + if (index > first) -8 else 8).coerceIn(0, max(0, msgs.size - 1)))
                listState.animateScrollToItem((index - 1).coerceAtLeast(0))
            }
            flashKey = null
            delay(16)
            flashKey = m.key
        }
    }

    /** Jumps to the message with server id [id]; false when it is not loaded. */
    fun jumpToId(id: Int): Boolean {
        val i = msgs.indexOfFirst { it.id == id }
        if (i < 0) return false
        jumpTo(i)
        return true
    }

    /**
     * Jumps to the original of a reply quote. The quoted id is preferred; some
     * backends keep a different id space, so the quoted sender and preview are
     * the fallback before giving up with "not available".
     */
    fun jumpToReply(m: UiMsg): Boolean {
        val target = m.replyTo
        if (target != null && target > 0 && jumpToId(target)) return true
        val hint = m.replyText?.let { Outbox.normalize(it) }
        if (!hint.isNullOrBlank() && !m.pending) {
            val i = msgs.indexOfLast { row ->
                row.id > 0 && row.sender == m.replySender && Outbox.normalize(row.text ?: "") == hint
            }
            if (i >= 0) { jumpTo(i); return true }
        }
        return false
    }

    fun jumpToBottom() {
        val last = msgs.size - 1
        if (last < 0) return
        scope.launch {
            runCatching {
                if (last - listState.firstVisibleItemIndex > 25) listState.scrollToItem(last - 10)
                listState.animateScrollToItem(last)
            }
        }
    }
}

@Composable
fun rememberChatController(msgs: List<UiMsg>, loading: Boolean): ChatController {
    val last = msgs.lastOrNull()
    val listState = ir.studying.app.ui.components.rememberChatListState(
        count = msgs.size,
        lastKey = last?.key,
        lastIsMine = last?.mine == true,
        visible = !loading && msgs.isNotEmpty(),
    )
    val scope = rememberCoroutineScope()
    val c = remember(listState) { ChatController(listState, scope) }
    c.msgs = msgs
    LaunchedEffect(c.flashKey) { if (c.flashKey != null) { delay(1900); c.flashKey = null } }
    return c
}

/* ---------------------------------------------------------------- surface -- */

/**
 * The whole chat page below the app chrome. [bottomBar] is the composer (or
 * a read only notice); [menuFor] lists the actions of the message menu.
 */
@Composable
fun ChatSurface(
    chat: ChatController,
    kind: ChatKind,
    me: String,
    msgs: List<UiMsg>,
    loading: Boolean,
    empty: @Composable () -> Unit,
    topBar: @Composable () -> Unit,
    bottomBar: @Composable () -> Unit,
    menuFor: (UiMsg) -> List<MenuAction>,
    onReact: (UiMsg, String) -> Unit,
    onAvatar: (String) -> Unit,
    onImage: (String) -> Unit,
    onRetry: (UiMsg) -> Unit,
    onSwipeReply: ((UiMsg) -> Unit)?,
    special: ((UiMsg) -> (@Composable () -> Unit)?)? = null,
    uploadPercent: Int? = null,
    delivery: List<OutMsg> = emptyList(),
    onRestoreDelivery: (OutMsg) -> Unit = {},
    onDiscardDelivery: (OutMsg) -> Unit = {},
    listOverlay: @Composable BoxScope.() -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    val palette = rememberBubblePalette()
    val menu = remember { MessageMenuState() }
    val splash = remember { ReactionSplashState() }
    val arrivals = remember { ArrivalTracker() }
    val keys = remember(msgs) { msgs.map { it.key } }
    remember(keys, loading) { arrivals.update(keys, !loading); keys.size }
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val haptic = LocalHapticFeedback.current

    val msgsNow by rememberUpdatedState(msgs)
    val menuForNow by rememberUpdatedState(menuFor)
    val onReactNow by rememberUpdatedState(onReact)
    val onAvatarNow by rememberUpdatedState(onAvatar)
    val onImageNow by rememberUpdatedState(onImage)
    val onRetryNow by rememberUpdatedState(onRetry)
    val onSwipeNow by rememberUpdatedState(onSwipeReply)
    val canSwipe = onSwipeReply != null
    val actions = remember(canSwipe) {
        BubbleActions(
            onMenu = { m, rect ->
                keyboard?.hide(); focus.clearFocus()
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                val list = msgsNow
                val i = list.indexOfFirst { it.key == m.key }
                val g = if (i >= 0) groupingOf(list, i) else Grouping(top = false, bottom = false, newDay = false)
                menu.open(MenuTarget(m, g, rect, menuForNow(m), canReact = !m.pending))
            },
            onReact = { m, e -> onReactNow(m, e) },
            onAvatar = { onAvatarNow(it) },
            onImage = { onImageNow(it) },
            onRetry = { onRetryNow(it) },
            onReplyJump = { m -> if (!chat.jumpToReply(m)) ir.studying.app.ui.components.AppSnack.show("پیام اصلی دیگر در دسترس نیست") },
            onSwipeReply = if (canSwipe) ({ m -> onSwipeNow?.invoke(m) }) else null,
        )
    }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        val blur by animateDpAsState(if (menu.isOpen) 7.dp else 0.dp, tween(240), label = "chatBlur")
        Column(
            Modifier.fillMaxSize()
                .chatWallpaper(cs.background, cs.primary, cs.tertiary, palette.dark)
                .then(if (blur > 0.2.dp) Modifier.blur(blur) else Modifier)
                .imePadding(),
        ) {
            topBar()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val listState = chat.listState
                when {
                    loading && msgs.isEmpty() -> ChatSkeleton()
                    msgs.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { empty() }
                    else -> LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 10.dp, bottom = 12.dp),
                    ) {
                        itemsIndexed(msgs, key = { _, m -> m.key }, contentType = { _, m -> if (m.type == "text") 0 else 1 }) { i, m ->
                            Box(Modifier.animateItemPlacement(spring(dampingRatio = 0.86f, stiffness = Spring.StiffnessMediumLow, visibilityThreshold = IntOffset(1, 1)))) {
                                ChatItem(
                                    m = m, g = groupingOf(msgs, i), kind = kind, p = palette, me = me,
                                    fresh = arrivals.isFresh(m.key),
                                    hidden = menu.shownKey() == m.key,
                                    highlight = chat.flashKey == m.key,
                                    actions = actions,
                                    special = special?.invoke(m),
                                )
                            }
                        }
                    }
                }
                // Keyboard or emoji panel opening: keep the newest message in sight.
                LaunchedEffect(listState) {
                    var prevH = -1
                    var prevBottom = true
                    snapshotFlow { listState.layoutInfo.viewportSize.height to !listState.canScrollForward }
                        .collect { (h, bottom) ->
                            if (prevH > 0 && h in 1 until prevH && prevBottom) {
                                runCatching { listState.scrollBy((prevH - h).toFloat()) }
                                prevBottom = true
                            } else prevBottom = bottom
                            prevH = h
                        }
                }
                if (msgs.isNotEmpty()) FloatingDate(listState) { idx -> msgs.getOrNull(idx)?.let { Fmt.dayLabel(it.createdAt) } }
                val showJump = chat.awayFromBottom
                var anchor by remember { mutableIntStateOf(-1) }
                LaunchedEffect(showJump) { anchor = if (showJump) msgsNow.size else -1 }
                val below = if (anchor >= 0) (msgs.size - anchor).coerceAtLeast(0) else 0
                JumpFab(visible = showJump && !loading, below = below) { chat.jumpToBottom() }
                listOverlay()
            }
            AnimatedVisibility(visible = uploadPercent != null, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                var last by remember { mutableIntStateOf(0) }
                if (uploadPercent != null) last = uploadPercent
                UploadStrip(last)
            }
            DeliveryStatus(delivery, onRestoreDelivery, onDiscardDelivery)
            bottomBar()
        }
        MessageMenuOverlay(menu, kind, palette, me, splash, onReact = { m, e -> onReactNow(m, e) }, special = special)
        ReactionSplashLayer(splash)
    }
}

/** Status is intentionally outside the message history: no second bubble. */
@Composable
private fun DeliveryStatus(items: List<OutMsg>, restore: (OutMsg) -> Unit, discard: (OutMsg) -> Unit) {
    if (items.isEmpty()) return
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().background(cs.surface).padding(horizontal = 12.dp, vertical = 6.dp)) {
        items.filter { it.state == SendState.FAILED }.take(3).forEach { item ->
            Text("وضعیت ارسال مشخص نیست؛ قبل از ارسال دوباره گفتگو را بررسی کن.",
                color = cs.error, style = MaterialTheme.typography.labelSmall)
            Text(item.text.take(80), style = MaterialTheme.typography.bodySmall, maxLines = 2)
            Row {
                androidx.compose.material3.TextButton(onClick = { restore(item) }) { Text("برگرداندن متن به کادر") }
                androidx.compose.material3.TextButton(onClick = { discard(item) }) { Text("بستن هشدار") }
            }
        }
    }
}

/** Upload progress with a moving sheen. */
@Composable
fun UploadStrip(percent: Int) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "upload")
    val sheen by t.animateFloat(-0.3f, 1.3f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "uploadSheen")
    Row(Modifier.fillMaxWidth().background(cs.surface.copy(alpha = 0.96f)).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        ir.studying.app.core.Icon3D("📤", 22.dp)
        Spacer(Modifier.width(8.dp))
        Text("در حال ارسال… ${percent.coerceIn(0, 100).fa()}٪",
            style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(6.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f))) {
            val f = (percent.coerceIn(0, 100) / 100f).coerceAtLeast(0.03f)
            Box(Modifier.fillMaxWidth(f).height(6.dp).clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(cs.primary, cs.tertiary))))
            Box(Modifier.fillMaxWidth(f).height(6.dp).graphicsLayer { alpha = 0.55f }
                .background(Brush.horizontalGradient(
                    0f to Color.Transparent, (sheen - 0.12f).coerceIn(0f, 1f) to Color.Transparent,
                    sheen.coerceIn(0f, 1f) to Color.White.copy(alpha = 0.7f),
                    (sheen + 0.12f).coerceIn(0f, 1f) to Color.Transparent, 1f to Color.Transparent)))
        }
    }
}

/** Shimmering bubble placeholders while the first page loads. */
@Composable
fun ChatSkeleton() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(0.35f, 0.75f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "skeletonA")
    val rows = remember { listOf(0.62f to false, 0.44f to false, 0.55f to true, 0.38f to true, 0.7f to false, 0.5f to true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEach { (w, mine) ->
            androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Box(Modifier.fillMaxWidth(w).height(if (w > 0.6f) 54.dp else 38.dp)
                        .graphicsLayer { alpha = a }
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (mine) cs.primary.copy(alpha = 0.32f) else cs.surfaceVariant))
                }
            }
        }
    }
}

/** Friendly empty chat: a big animated 3D emoji, a title and a hint. */
@Composable
fun ChatEmpty(emoji: String, title: String, text: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(shape = RoundedCornerShape(30.dp), color = cs.surface.copy(alpha = 0.9f), shadowElevation = 3.dp) {
            Column(Modifier.padding(horizontal = 26.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedEmoji(emoji, 92.dp, idle = true, repeatEveryMs = 2600, onClick = onAction)
                Spacer(Modifier.height(10.dp))
                EmojiText(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                EmojiText(text, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                if (actionLabel != null && onAction != null) {
                    Spacer(Modifier.height(12.dp))
                    Surface(shape = CircleShape, color = cs.primary, onClick = onAction) {
                        EmojiText(actionLabel, style = MaterialTheme.typography.labelLarge, color = cs.onPrimary, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp))
                    }
                }
            }
        }
    }
}

/** Notice in place of the composer when the user may not post. */
@Composable
fun ReadOnlyNotice(text: String) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth().background(cs.surface.copy(alpha = 0.97f)).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center) {
        Surface(shape = CircleShape, color = cs.surfaceVariant.copy(alpha = 0.7f)) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                ir.studying.app.core.Icon3D("📢", 20.dp)
                Spacer(Modifier.width(8.dp))
                Text(text, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
    }
}

/* ------------------------------------------------------------ side chips -- */

/** Small round button that sits above the jump button (mentions, replies). */
@Composable
fun BoxScope.SideFab(visible: Boolean, raised: Boolean, badge: String? = null, onClick: () -> Unit, content: @Composable () -> Unit) {
    val lift by animateDpAsState(if (raised) 66.dp else 14.dp, spring(dampingRatio = 0.7f), label = "sideFabLift")
    AnimatedVisibility(visible = visible, enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(), exit = scaleOut() + fadeOut(),
        modifier = Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = lift)) {
        Box {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp, onClick = onClick) {
                Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) { content() }
            }
            if (badge != null) Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.TopCenter).padding(bottom = 0.dp).graphicsLayer { translationY = -10.dp.toPx() }) {
                Text(badge, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp))
            }
        }
    }
}

/** @mention suggestions shown above the composer in group chats. */
@Composable
fun MentionBar(candidates: List<Pair<String, String?>>, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        candidates.forEachIndexed { i, (u, avatar) ->
            val appear = remember(u) { Animatable(0f) }
            LaunchedEffect(u) { delay(30L * i); appear.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 500f)) }
            Surface(shape = CircleShape, color = cs.secondaryContainer, onClick = { onPick(u) },
                modifier = Modifier.graphicsLayer { val v = appear.value; alpha = v.coerceIn(0f, 1f); scaleX = 0.7f + 0.3f * v; scaleY = scaleX }) {
                Row(Modifier.padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(u, null, size = 26.dp, avatarUrl = avatar)
                    Spacer(Modifier.width(6.dp))
                    Text("@$u", style = MaterialTheme.typography.labelLarge, color = cs.onSecondaryContainer)
                }
            }
        }
    }
}

/* --------------------------------------------------------- overflow menu -- */

class MoreItem(val icon: ImageVector, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Composable
fun ChatMoreButton(items: List<MoreItem>) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.MoreVert, "بیشتر", tint = cs.onSurfaceVariant) }
        MaterialTheme(shapes = MaterialTheme.shapes.copy(extraSmall = RoundedCornerShape(18.dp))) {
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                items.forEach { it ->
                    DropdownMenuItem(
                        text = { Text(it.label, color = if (it.danger) cs.error else cs.onSurface) },
                        leadingIcon = { Icon(it.icon, null, tint = if (it.danger) cs.error else cs.onSurfaceVariant) },
                        onClick = { open = false; it.onClick() },
                    )
                }
            }
        }
    }
}

/* ---------------------------------------------------------- image viewer -- */

/** Full screen photo with pinch zoom, double tap zoom and download. */
@Composable
fun ImageViewerDialog(path: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var scale by remember { mutableFloatStateOf(1f) }
        var pan by remember { mutableStateOf(Offset.Zero) }
        val appear = remember { Animatable(0f) }
        LaunchedEffect(Unit) { appear.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 400f)) }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.96f * appear.value.coerceIn(0f, 1f))), contentAlignment = Alignment.Center) {
            AsyncImage(
                model = Api.mediaUrl(path), contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, p, z, _ ->
                            scale = (scale * z).coerceIn(1f, 5f)
                            pan = if (scale > 1f) pan + p else Offset.Zero
                        }
                    }
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { if (scale > 1.1f) { scale = 1f; pan = Offset.Zero } else scale = 2.4f }) }
                    .graphicsLayer {
                        val a = appear.value
                        scaleX = scale * (0.86f + 0.14f * a); scaleY = scaleX
                        translationX = pan.x; translationY = pan.y
                        alpha = a.coerceIn(0f, 1f)
                    },
            )
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = onDismiss, modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.12f))) {
                    Icon(Icons.Rounded.Close, "بستن", tint = Color.White)
                }
                IconButton(onClick = { ChatMedia.download(ctx, Api.mediaUrl(path), "studying_" + System.currentTimeMillis() + ".jpg") },
                    modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.12f))) {
                    Icon(Icons.Rounded.Download, "دانلود", tint = Color.White)
                }
            }
        }
    }
}

/* ------------------------------------------------------------ menu sets -- */

/** Menu of a message that has not reached the server. */
fun pendingMenu(m: UiMsg, copy: (String) -> Unit, retry: () -> Unit, discard: () -> Unit): List<MenuAction> = buildList {
    if (m.tick == Tick.FAILED) add(MenuAction(Icons.Rounded.Refresh, "ارسال دوباره") { retry() })
    if (!m.text.isNullOrBlank()) add(MenuAction(Icons.Rounded.ContentCopy, "کپی متن") { copy(m.text) })
    if (m.tick == Tick.FAILED) add(MenuAction(Icons.Rounded.Delete, "حذف", danger = true) { discard() })
}

/** Accent of the public channels, shared by the inbox and the chat. */
fun channelTint(channel: String, primary: Color): Color = when (channel) {
    "help" -> Color(0xFF4F8DFD)
    "news" -> Color(0xFFFF8A3D)
    else -> primary
}

/** Status line text for a DM partner. */
fun partnerStatus(online: Boolean?, lastSeenText: String?, lastSeen: String?): String = when {
    online == true -> "آنلاین"
    !lastSeenText.isNullOrBlank() -> lastSeenText
    lastSeen != null -> "آخرین بازدید ${Fmt.relative(lastSeen)}"
    else -> ""
}

@Composable
internal fun TopBarIcon(icon: ImageVector, desc: String, tint: Color = MaterialTheme.colorScheme.onSurfaceVariant, size: Dp = 24.dp, onClick: () -> Unit) {
    IconButton(onClick = onClick) { Icon(icon, desc, tint = tint, modifier = Modifier.size(size)) }
}
