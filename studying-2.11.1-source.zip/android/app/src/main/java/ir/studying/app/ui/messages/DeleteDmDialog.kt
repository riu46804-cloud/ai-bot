package ir.studying.app.ui.messages

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.studying.app.data.DmDeleteScope

/** Destructive scope is explicit, opt-in and defaults to this viewer only. */
@Composable
internal fun DeleteDmDialog(
    username: String, conversation: Boolean, busy: Boolean,
    onDismiss: () -> Unit, onConfirm: (DmDeleteScope) -> Unit,
) {
    var both by remember(username, conversation) { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(if (conversation) "حذف گفتگو با $username؟" else "حذف پیام؟") },
        text = {
            Column {
                Text(if (conversation) "پیام‌های فعلی این گفتگو برای تو حذف می‌شوند. پیام‌های جدیدی که بعداً برسند همچنان نمایش داده می‌شوند."
                    else "این پیام برای تو حذف می‌شود.")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().clickable(enabled = !busy) { both = !both },
                    verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = both, enabled = !busy, onCheckedChange = { both = it })
                    Text("برای $username هم حذف شود", modifier = Modifier.weight(1f))
                }
                if (both) Text("پیام‌های انتخاب‌شده از گفتگوی طرف مقابل هم حذف می‌شوند.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(6.dp))
                Text("این کار قابل برگشت نیست.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = { onConfirm(DmDeleteScope.fromBothChecked(both)) }) {
                Text(if (busy) "در حال حذف…" else if (both) "حذف برای هر دو" else "حذف فقط برای من",
                    color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("انصراف") } },
    )
}
