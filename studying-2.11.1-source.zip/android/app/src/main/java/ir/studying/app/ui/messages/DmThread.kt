@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.messages

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.R
import ir.studying.app.core.Api
import ir.studying.app.core.Challenges
import ir.studying.app.core.Store
import ir.studying.app.core.VoiceRecorder
import ir.studying.app.core.fa
import ir.studying.app.data.DmMessage
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.components.LoadingBox
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DmThreadScreen(username: String, onBack: () -> Unit, vm: DmThreadViewModel = viewModel(key = "dm_" + username)) {
    val ctx = LocalContext.current
    val me = Store.username ?: ""
    val state by vm.state.collectAsState()
    val prefs by Store.prefs.collectAsState()
    val sessionForChat by Store.session.collectAsState()
    LaunchedEffect(sessionForChat) { vm.sync.ensureSession() }
    val timeline by vm.sync.timeline.collectAsState()
    val pending = timeline.pending
    val rx by vm.sync.reactions.map.collectAsState()
    val msgs = remember(timeline, rx, me) {
        timelineChat(timeline, me, emptySet()) { id, reactions -> vm.sync.reactions.view(id, reactions) }
    }
    // از فریم اول روی آخرین پیام؛ پیام تازه با انیمیشن از پایین می‌آید
    val chat = rememberChatController(msgs, state.loading)
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val muteKey = "dm:$username"
    val muted = prefs.muted.contains(muteKey)

    var input by rememberSaveable(username) { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<UiMsg?>(null) }
    var forwardMsg by remember { mutableStateOf<UiMsg?>(null) }
    var editMsg by remember { mutableStateOf<UiMsg?>(null) }
    var viewImage by remember { mutableStateOf<String?>(null) }
    var showProfile by remember { mutableStateOf(false) }
    var showAttach by remember { mutableStateOf(false) }
    var showChallenge by remember { mutableStateOf(false) }
    var showStickers by remember { mutableStateOf(false) }
    var showMusic by remember { mutableStateOf(false) }
    var deleteConversationOpen by remember(username) { mutableStateOf(false) }
    var deleteMessage by remember(username) { mutableStateOf<UiMsg?>(null) }

    val recorder = remember { VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recElapsed by remember { mutableIntStateOf(0) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.sendImage(ctx, uri) { AppSnack.show(it) }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.sendFile(ctx, uri) { AppSnack.show(it) }
    }
    val musicFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.sendMusicFile(ctx, uri) { AppSnack.show(it) }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { if (recorder.start()) { recording = true; recElapsed = 0 } } else AppSnack.show("به مجوز میکروفون نیاز است")
    }

    LaunchedEffect(username) { vm.bind(username); vm.poll() }
    LaunchedEffect(username) { while (true) { vm.poll(); delay(4000) } }
    LaunchedEffect(recording) { while (recording) { recElapsed = recorder.elapsedSec(); delay(500) } }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    fun send(text: String) {
        val t = text.trim(); if (t.isEmpty()) return
        val r = replyTo
        vm.sendText(t, r?.id?.takeIf { it > 0 }, r?.sender, r?.preview()) { AppSnack.show(it) }
        replyTo = null
    }

    val partner = state.partner
    ChatSurface(
        chat = chat, kind = ChatKind.DM, me = me, msgs = msgs, loading = state.loading,
        empty = {
            ChatEmpty("👋", "سلام بگو!", "اولین پیام رو بفرست و گفتگو با $username رو شروع کن",
                actionLabel = "👋 سلام بفرست", onAction = { send("👋") })
        },
        topBar = {
            ChatTopBar(
                onBack = onBack, title = username,
                leading = { Avatar(username, partner?.mood, size = 42.dp, online = partner?.isOnline, avatarUrl = partner?.avatar) },
                subtitle = {
                    ChatStatus(partnerStatus(partner?.isOnline, partner?.lastSeenText, partner?.lastSeen),
                        typing = state.partnerTyping, highlight = partner?.isOnline == true)
                },
                onTitleClick = { showProfile = true },
                actions = {
                    if (muted) TopBarIcon(Icons.Rounded.NotificationsOff, "بی‌صدا", tint = MaterialTheme.colorScheme.error, size = 20.dp) {
                        Store.toggleMute(muteKey); AppSnack.show("صدادار شد 🔔")
                    }
                    ChatMoreButton(listOf(
                        MoreItem(Icons.Rounded.Person, "پروفایل $username") { showProfile = true },
                        MoreItem(if (muted) Icons.Rounded.NotificationsActive else Icons.Rounded.NotificationsOff,
                            if (muted) "صدادار کردن" else "بی‌صدا کردن") {
                            Store.toggleMute(muteKey); AppSnack.show(if (!muted) "بی‌صدا شد 🔕" else "صدادار شد 🔔")
                        },
                        MoreItem(Icons.Rounded.Delete, "حذف گفتگو", danger = true) { if (!state.deleting) deleteConversationOpen = true },
                    ))
                },
            )
        },
        bottomBar = {
            if (recording) {
                RecordingBar(clockMin(recElapsed), onCancel = { recorder.cancel(); recording = false }, onSend = {
                    val res = recorder.stop(); recording = false
                    if (res != null) vm.sendVoice(res.first, res.second) { AppSnack.show(it) } else AppSnack.show("ضبط خیلی کوتاه بود")
                })
            } else {
                ChatComposer(
                    value = input,
                    onValueChange = { input = it; if (it.isNotBlank()) vm.notifyTyping() },
                    placeholder = "پیام…",
                    onSend = { send(input); input = "" },
                    onAttach = { showAttach = true },
                    onMic = {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            if (recorder.start()) { recording = true; recElapsed = 0 }
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    reply = replyTo?.let { ReplyDraft(it.sender, it.preview()) },
                    onCancelReply = { replyTo = null },
                )
            }
        },
        menuFor = { m ->
            if (m.pending) pendingMenu(m,
                copy = { clip.setText(AnnotatedString(it)) },
                retry = { m.localId?.let { id -> vm.retry(id) { e -> AppSnack.show(e) } } },
                discard = { m.localId?.let { id -> vm.discard(id) } })
            else buildList {
                add(MenuAction(Icons.AutoMirrored.Rounded.Reply, "پاسخ") { replyTo = m })
                add(MenuAction(Icons.AutoMirrored.Rounded.Send, "هدایت") { forwardMsg = m })
                if (m.type == "text" && !m.text.isNullOrBlank()) add(MenuAction(Icons.Rounded.ContentCopy, "کپی متن") { clip.setText(AnnotatedString(m.text)) })
                if (m.mine && m.type == "text" && Challenges.parse(m.text) == null) add(MenuAction(Icons.Rounded.Edit, "ویرایش") { editMsg = m })
                add(MenuAction(Icons.Rounded.Delete, "حذف پیام", danger = true) { deleteMessage = m })
            }
        },
        onReact = { m, e -> if (!m.pending) vm.react(m.id, m.reactions, e) },
        onAvatar = { showProfile = true },
        onImage = { viewImage = it },
        onRetry = { m -> m.localId?.let { id -> vm.retry(id) { e -> AppSnack.show(e) } } },
        onSwipeReply = { m -> if (!m.pending) replyTo = m },
        special = { m -> challengeBody(m) },
        uploadPercent = state.uploadPercent,
        delivery = pending.filter { it.state == SendState.FAILED },
        onRestoreDelivery = { o ->
            val draft = restoreDeliveryDraft(o, input, replyTo, msgs)
            if (draft != null) {
                input = draft.text; replyTo = draft.reply; vm.discard(o.localId)
            } else AppSnack.show("کادر و پاسخ فعلی را خالی کن؛ برای پاسخ قبلی، پیام اصلی هم باید در گفتگو موجود باشد")
        },
        onDiscardDelivery = { o -> vm.discard(o.localId) },
    )

    if (showAttach) AttachSheet(
        onImage = { showAttach = false; imagePicker.launch("image/*") },
        onFile = { showAttach = false; filePicker.launch("*/*") },
        onMusic = { showAttach = false; showMusic = true },
        onMusicDevice = { showAttach = false; musicFilePicker.launch("audio/*") },
        onSticker = { showAttach = false; showStickers = true },
        onChallenge = { showAttach = false; showChallenge = true },
        onDismiss = { showAttach = false },
    )
    if (showChallenge) ChallengeSheet(
        onDismiss = { showChallenge = false },
        onSend = { kind, mins, days, mode ->
            showChallenge = false
            scope.launch {
                val err = Challenges.create(username, kind, mins, days, mode.id)
                /* پیام خطای خود سرور (مثلاً سقف ۳ رقابت فعال) نشان داده می‌شود، نه یک جملهٔ کلی. */
                if (err != null) AppSnack.show(err) else AppSnack.show("پیشنهاد فرستاده شد ⚔️")
                vm.poll()
            }
        },
    )
    if (showStickers) StickerPickerSheet(onPick = { st -> showStickers = false; vm.sendSticker(st.id) { AppSnack.show(it) } }, onDismiss = { showStickers = false })
    if (showMusic) ChatMusicPicker(onPick = { t -> showMusic = false; vm.sendMusic(t.id) { AppSnack.show(it) } }, onDismiss = { showMusic = false })

    if (deleteConversationOpen) DeleteDmDialog(username = username, conversation = true,
        busy = state.deleting, onDismiss = { deleteConversationOpen = false }, onConfirm = { deletionScope ->
            vm.deleteConversation(deletionScope) { error ->
                if (error != null) AppSnack.show(error)
                else {
                    deleteConversationOpen = false
                    replyTo = null
                    AppSnack.show("گفتگو حذف شد")
                    onBack()
                }
            }
        })
    deleteMessage?.let { message ->
        DeleteDmDialog(username = username, conversation = false, busy = state.deleting,
            onDismiss = { deleteMessage = null }, onConfirm = { deletionScope ->
                vm.delete(message.id, deletionScope) { error ->
                    if (error != null) AppSnack.show(error)
                    else { deleteMessage = null; if (replyTo?.id == message.id) replyTo = null }
                }
            })
    }

    editMsg?.let { em ->
        var text by remember(em.key) { mutableStateOf(em.text ?: "") }
        AlertDialog(onDismissRequest = { editMsg = null }, title = { Text(stringResource(R.string.dm_thread_001)) },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { if (text.isNotBlank()) vm.edit(em.id, text) { AppSnack.show(it) }; editMsg = null }) { Text(stringResource(R.string.groups_010)) } },
            dismissButton = { TextButton(onClick = { editMsg = null }) { Text(stringResource(R.string.groups_011)) } })
    }

    viewImage?.let { ImageViewerDialog(it) { viewImage = null } }

    if (showProfile) {
        UserProfileSheet(username = username, onDismiss = { showProfile = false }, onMessage = { showProfile = false })
    }

    forwardMsg?.let { fm ->
        ForwardSheet(onPick = { toUser ->
            vm.forward(fm.id, toUser) { e -> AppSnack.show(e ?: "هدایت شد ↪") }
            forwardMsg = null
        }, onDismiss = { forwardMsg = null })
    }
}

/** Challenge offers render as an interactive card inside the bubble. */
private fun challengeBody(m: UiMsg): (@Composable () -> Unit)? {
    if (m.type != "text" || m.pending) return null
    val offer = Challenges.parse(m.text) ?: return null
    return { ChallengeCard(offer, m.mine) }
}

/** انتخاب گفتگو برای هدایت پیام (تلگرامی). */
@Composable
fun ForwardSheet(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var convs by remember { mutableStateOf<List<ir.studying.app.data.Conversation>?>(null) }
    LaunchedEffect(Unit) {
        runCatching { ir.studying.app.data.Conversation.list(Api.arr(Api.get("dm_conversations"))) }
            .onSuccess { convs = it }.onFailure { convs = emptyList() }
    }
    ModalBottomSheet(sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp)) {
            Text(stringResource(R.string.dm_thread_002), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            when {
                convs == null -> LoadingBox(height = 120.dp)
                convs!!.isEmpty() -> EmptyState("✉️", "گفتگویی نداری")
                else -> Column(Modifier.height(360.dp).verticalScroll(rememberScrollState())) {
                    convs!!.forEach { c ->
                        Surface(color = Color.Transparent, onClick = { onPick(c.username) }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Avatar(c.username, c.mood, size = 40.dp, avatarUrl = c.avatar)
                                Spacer(Modifier.width(10.dp))
                                Text(c.username, style = MaterialTheme.typography.titleSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** جداکننده تاریخ وسط چت. */
@Composable
fun DateChip(label: String) {
    if (label.isBlank()) return
    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)) {
            Text(label, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
        }
    }
}

/** سوایپ افقی روی حباب برای پاسخ سریع (تلگرامی). */
@Composable
fun SwipeToReply(onReply: () -> Unit, content: @Composable () -> Unit) {
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    val threshold = 130f
    Box(Modifier.fillMaxWidth()) {
        if (offset.value > 20f) {
            Icon(Icons.AutoMirrored.Rounded.Reply, "پاسخ", tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 6.dp).size(22.dp)
                    .alpha((offset.value / threshold).coerceIn(0f, 1f)))
        }
        Box(Modifier
            .draggable(
                state = rememberDraggableState { d ->
                    scope.launch { offset.snapTo((offset.value + d).coerceIn(0f, threshold + 30f)) }
                },
                orientation = Orientation.Horizontal,
                onDragStopped = {
                    if (offset.value > threshold * 0.7f) onReply()
                    scope.launch { offset.animateTo(0f, androidx.compose.animation.core.spring(dampingRatio = 0.6f)) }
                })
            .graphicsLayer { translationX = offset.value }) { content() }
    }
}

fun previewOf(m: DmMessage?): String = when (m?.type) {
    "image" -> "📷 عکس"; "voice" -> "🎤 پیام صوتی"; "file" -> "📎 ${m.fileName ?: "فایل"}"
    "music" -> "🎵 ${m.message ?: "موزیک"}"; "sticker" -> "استیکر"; "gif" -> "GIF"
    else -> ir.studying.app.core.Challenges.label(m?.message)
}

fun clockMin(sec: Int): String = String.format(java.util.Locale.US, "%d:%02d", sec / 60, sec % 60).fa()

@Composable
fun SheetRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, danger: Boolean = false, onClick: () -> Unit) {
    Surface(color = Color.Transparent, onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        }
    }
}
