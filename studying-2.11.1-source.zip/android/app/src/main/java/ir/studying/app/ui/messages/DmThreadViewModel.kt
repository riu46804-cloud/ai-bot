package ir.studying.app.ui.messages

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.data.DmMessage
import ir.studying.app.data.DmPartner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

class DmThreadViewModel : ViewModel() {
    data class State(
        val loading: Boolean = true,
        val partner: DmPartner? = null,
        val messages: List<DmMessage> = emptyList(),
        val uploadPercent: Int? = null,
        val partnerTyping: Boolean = false,
        val deleting: Boolean = false,
    )

    val state = MutableStateFlow(State())
    private var username: String = ""
    private var revision: Long = 0
    private fun target() = mapOf("to" to username)

    /** Optimistic sending and reactions (Telegram style). */
    val sync = ChatSync(viewModelScope, { ir.studying.app.core.Store.session.value }) { ir.studying.app.core.Store.username ?: "" }

    fun bind(user: String) {
        if (username == user) return
        revision++
        username = user
        state.value = State()
        sync.clear()
    }

    fun poll() {
        if (username.isBlank() || state.value.deleting) return
        val peer = username
        val generation = revision
        val rxGen = sync.beginPoll()
        val session = ir.studying.app.core.Store.session.value
        viewModelScope.launch {
            runCatching {
                val o = Api.obj(Api.getForSession("dm_thread", session, "username" to peer))
                val partner = o.optJSONObject("partner")?.let { DmPartner.from(it) }
                val msgs = DmMessage.list(o.optJSONArray("messages") ?: throw IllegalStateException("messages missing"))
                Triple(partner, msgs, o.optInt("partner_typing", 0) == 1)
            }.onSuccess { (p, m, t) ->
                val me = ir.studying.app.core.Store.username ?: ""
                if (generation == revision && peer == username && session == ir.studying.app.core.Store.session.value && sync.publishPoll(rxGen, m.map { it.toUi(me, "m${it.id}", it.reactions) })) {
                    state.update { it.copy(loading = false, partner = p, messages = m, partnerTyping = t) }
                }
            }.onFailure {
                if (generation == revision && peer == username) state.update { it.copy(loading = false) }
            }
        }
    }

    private var lastTypingPing = 0L
    /** اعلام «در حال نوشتن» — حداکثر هر ۳ ثانیه یک‌بار. */
    fun notifyTyping() {
        val now = System.currentTimeMillis()
        if (now - lastTypingPing < 3000 || username.isBlank()) return
        lastTypingPing = now
        viewModelScope.launch { runCatching { Api.post("dm_typing", JSONObject().put("to", username)) } }
    }

    /** ری‌اکشن (تلگرامی) — همان لحظه روی پیام دیده می‌شود؛ سرور toggle می‌کند. */
    fun react(msgId: Int, current: List<ir.studying.app.data.Reaction>, emoji: String) {
        sync.react(msgId, current, emoji, call = {
            Api.post("react", JSONObject().put("scope", "dm").put("id", msgId).put("emoji", emoji))
        }, after = { poll() })
    }

    /** هدایت پیام به یک گفتگوی دیگر. */
    fun forward(msgId: Int, toUser: String, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            runCatching { Api.post("forward", JSONObject().put("source_scope", "dm").put("id", msgId).put("to", toUser)) }
                .onSuccess { onDone(null) }.onFailure { onDone(it.message) }
        }
    }

    /** پیام همان لحظه با ساعت در گفتگو دیده می‌شود و در پس‌زمینه فرستاده می‌شود (تلگرامی). */
    fun sendText(text: String, replyTo: Int?, replySender: String?, replyPreview: String?, onErr: (String) -> Unit) {
        val t = text.trim(); if (t.isEmpty() || username.isBlank()) return
        val peer = username
        val session = ir.studying.app.core.Store.session.value
        sync.queue(t, replyTo, replySender, replyPreview, afterId = lastId(),
            send = { o -> postText(peer, o, session) }, onErr = onErr, after = { poll() })
    }

    fun retry(localId: Long, onErr: (String) -> Unit) {
        val peer = username
        val session = ir.studying.app.core.Store.session.value
        sync.retry(localId, lastId(), send = { o -> postText(peer, o, session) }, onErr = onErr, after = { poll() })
    }

    fun discard(localId: Long) = sync.discard(localId)

    private fun lastId(): Int = state.value.messages.maxOfOrNull { it.id } ?: 0

    private suspend fun postText(peer: String, o: OutMsg, session: ir.studying.app.core.SessionState): Int? {
        val b = JSONObject().put("to", peer).put("message", o.text)
        if (o.replyTo != null) b.put("reply_to", o.replyTo)
        return ChatSync.idOf(Api.postForSession("dm_send", b, session))
    }

    private fun sendMediaUri(ctx: Context, type: String, uri: Uri, duration: Int?, onErr: (String) -> Unit) {
        viewModelScope.launch {
            state.update { it.copy(uploadPercent = 0) }
            val err = ir.studying.app.ui.messages.ChatMedia.sendMedia(ctx, "dm", target(), type, uri, duration) { pct ->
                state.update { it.copy(uploadPercent = pct) }
            }
            state.update { it.copy(uploadPercent = null) }
            if (err != null) onErr(err)
            poll()
        }
    }

    fun sendImage(ctx: Context, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, "image", uri, null, onErr)
    fun sendFile(ctx: Context, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, "file", uri, null, onErr)
    fun sendMusicFile(ctx: Context, uri: Uri, onErr: (String) -> Unit) = sendMediaUri(ctx, "music", uri, null, onErr)

    fun sendVoice(file: File, durationSec: Int, onErr: (String) -> Unit) {
        viewModelScope.launch {
            state.update { it.copy(uploadPercent = 0) }
            val err = ir.studying.app.ui.messages.ChatMedia.sendMedia(App_context(), "dm", target(), "voice", Uri.fromFile(file), durationSec) { pct ->
                state.update { it.copy(uploadPercent = pct) }
            }
            state.update { it.copy(uploadPercent = null) }
            runCatching { file.delete() }
            if (err != null) onErr(err)
            poll()
        }
    }

    private fun App_context(): Context = ir.studying.app.App.instance

    fun sendMusic(musicId: Int, onErr: (String) -> Unit) {
        viewModelScope.launch {
            val err = ir.studying.app.ui.messages.ChatMedia.sendRef("dm", target(), "music", musicId = musicId)
            if (err != null) onErr(err); poll()
        }
    }

    fun sendSticker(stickerId: Int, onErr: (String) -> Unit) {
        viewModelScope.launch {
            val err = ir.studying.app.ui.messages.ChatMedia.sendRef("dm", target(), "sticker", stickerId = stickerId)
            if (err != null) onErr(err); poll()
        }
    }

    fun edit(id: Int, text: String, onErr: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { Api.put("dm_edit", JSONObject().put("id", id).put("message", text.trim())) }.onFailure { onErr(it.message ?: "خطا") }
            poll()
        }
    }

    fun delete(id: Int, scope: ir.studying.app.data.DmDeleteScope, onDone: (String?) -> Unit) {
        deleteAction(id, onDone) { session -> ir.studying.app.data.DmDeletion.message(id, scope, session) }
    }

    fun deleteConversation(scope: ir.studying.app.data.DmDeleteScope, onDone: (String?) -> Unit) {
        val peer = username
        if (peer.isBlank()) { onDone("گفتگو مشخص نیست"); return }
        deleteAction(null, onDone) { session -> ir.studying.app.data.DmDeletion.conversation(peer, scope, session) }
    }

    private fun deleteAction(messageId: Int?, onDone: (String?) -> Unit,
        action: suspend (ir.studying.app.core.SessionState) -> Unit) {
        if (state.value.deleting) return
        val peer = username
        val session = ir.studying.app.core.Store.session.value
        revision++ // Drop stale responses already in flight before the deletion.
        state.update { it.copy(deleting = true) }
        viewModelScope.launch {
            val result = runCatching { action(session) }
            if (username != peer || ir.studying.app.core.Store.session.value != session) return@launch
            revision++
            if (result.isSuccess && messageId == null) sync.clear()
            else if (result.isSuccess && messageId != null) sync.removeServer(messageId)
            state.update { it.copy(deleting = false, loading = false,
                messages = if (!result.isSuccess) it.messages else if (messageId == null) emptyList() else it.messages.filterNot { m -> m.id == messageId }) }
            result.onSuccess { onDone(null) }.onFailure { onDone(it.message ?: "حذف انجام نشد") }
            poll()
        }
    }
}
