package ir.studying.app.ui.messages

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import ir.studying.app.core.EmojiCatalog
import ir.studying.app.ui.components.AnimatedEmoji
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.roundToInt

/* =====================================================================
 * Telegram style message menu: the chat blurs and dims, the bubble lifts
 * out, reactions pop in one by one above it and the actions slide in
 * below. Picking a reaction fires a big 3D splash over the message.
 * ===================================================================== */

class MenuAction(val icon: ImageVector, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Immutable
class MenuTarget(
    val msg: UiMsg,
    val grouping: Grouping,
    val bounds: Rect,
    val actions: List<MenuAction>,
    val canReact: Boolean,
)

@Stable
class MessageMenuState {
    var target by mutableStateOf<MenuTarget?>(null)
        private set
    var closing by mutableStateOf(false)
        private set

    val isOpen: Boolean get() = target != null && !closing
    fun shownKey(): String? = target?.msg?.key

    fun open(t: MenuTarget) { target = t; closing = false }
    fun close() { if (target != null) closing = true }
    internal fun finish() { target = null; closing = false }
}

@Immutable
class Splash(val emoji: String, val center: Offset, val id: Long)

@Stable
class ReactionSplashState {
    var shot by mutableStateOf<Splash?>(null)
    fun fire(emoji: String, center: Offset) { shot = Splash(emoji, center, System.nanoTime()) }
}

@Composable
fun MessageMenuOverlay(
    state: MessageMenuState,
    kind: ChatKind,
    palette: BubblePalette,
    me: String,
    splash: ReactionSplashState,
    onReact: (UiMsg, String) -> Unit,
    special: ((UiMsg) -> (@Composable () -> Unit)?)? = null,
) {
    val t = state.target ?: return
    val haptic = LocalHapticFeedback.current
    val progress = remember(t) { Animatable(0f) }
    LaunchedEffect(t, state.closing) {
        if (!state.closing) progress.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = 420f))
        else { progress.animateTo(0f, tween(170)); state.finish() }
    }
    BackHandler { state.close() }
    var expanded by remember(t) { mutableStateOf(false) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val mineReaction = t.msg.reactions.firstOrNull { it.mine }?.emoji
    val density = LocalDensity.current
    val screenW = LocalConfiguration.current.screenWidthDp

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { alpha = progress.value.coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = if (palette.dark) 0.48f else 0.3f))
                .pointerInput(t) { detectTapGestures { state.close() } },
        )
        Layout(
            modifier = Modifier.fillMaxSize().imePadding()
                .onGloballyPositioned { origin = it.boundsInRoot().topLeft },
            content = {
                Box(Modifier.layoutId("r")) {
                    if (t.canReact) ReactionPanel(
                        mine = mineReaction, expanded = expanded, screenW = screenW,
                        onExpand = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); expanded = true },
                        onPick = { e ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            splash.fire(e, t.bounds.center)
                            onReact(t.msg, e)
                            state.close()
                        },
                    )
                }
                Box(Modifier.layoutId("b").clipToBounds()) {
                    BubbleBody(t.msg, t.grouping, kind, palette, me, fresh = false, interactive = false,
                        onTap = {}, onLongPress = {}, actions = null,
                        special = special?.invoke(t.msg))
                }
                Box(Modifier.layoutId("m")) {
                    if (t.actions.isNotEmpty()) ActionCard(t.actions, alignEnd = t.msg.mine) { a -> state.close(); a.onClick() }
                }
            },
        ) { ms, c ->
            val w = c.maxWidth
            val h = c.maxHeight
            val margin = with(density) { 10.dp.roundToPx() }
            val gap = with(density) { 8.dp.roundToPx() }
            val barH = with(density) { 54.dp.roundToPx() }
            val b = t.bounds.translate(-origin)
            val rP = ms.first { it.layoutId == "r" }.measure(Constraints(maxWidth = w - 2 * margin, maxHeight = h - 2 * margin))
            val mP = ms.first { it.layoutId == "m" }.measure(Constraints(maxWidth = w - 2 * margin, maxHeight = h))
            val rTop = if (t.canReact) barH + gap else 0
            val mBottom = if (mP.height > 0) mP.height + gap else 0
            val bw = b.width.roundToInt().coerceIn(1, w)
            val avail = (h - 2 * margin - rTop - mBottom).coerceAtLeast(with(density) { 56.dp.roundToPx() })
            val bP = ms.first { it.layoutId == "b" }.measure(Constraints(minWidth = 0, maxWidth = bw, minHeight = 0, maxHeight = avail))
            val bh = bP.height
            val topLimit = margin + rTop
            val bottomLimit = h - margin - mBottom - bh
            val origY = b.top.roundToInt()
            val targetY = when {
                origY < topLimit -> topLimit
                origY > bottomLimit -> max(topLimit, bottomLimit)
                else -> origY
            }
            layout(w, h) {
                val pr = progress.value
                val y = (origY + (targetY - origY) * pr).roundToInt()
                val x = b.left.roundToInt()
                bP.placeWithLayer(x, y) {
                    val s = 1f + 0.035f * pr
                    scaleX = s; scaleY = s
                    transformOrigin = TransformOrigin(if (t.msg.mine) 1f else 0f, 0.5f)
                }
                val rx = (if (t.msg.mine) x + bw - rP.width else x).coerceIn(margin, (w - margin - rP.width).coerceAtLeast(margin))
                val ry = (y - gap - barH).coerceIn(margin, (h - margin - rP.height).coerceAtLeast(margin))
                rP.placeWithLayer(rx, ry) {
                    alpha = pr.coerceIn(0f, 1f)
                    val s = 0.55f + 0.45f * pr
                    scaleX = s; scaleY = s
                    transformOrigin = TransformOrigin(if (t.msg.mine) 1f else 0f, 1f)
                }
                val mx = (if (t.msg.mine) x + bw - mP.width else x).coerceIn(margin, (w - margin - mP.width).coerceAtLeast(margin))
                val my = (y + bh + gap).coerceAtMost((h - margin - mP.height).coerceAtLeast(margin))
                mP.placeWithLayer(mx, my) {
                    alpha = if (expanded) 0f else pr.coerceIn(0f, 1f)
                    val s = 0.7f + 0.3f * pr
                    scaleX = s; scaleY = s
                    transformOrigin = TransformOrigin(if (t.msg.mine) 1f else 0f, 0f)
                }
            }
        }
    }
}

@Composable
private fun ReactionPanel(mine: String?, expanded: Boolean, screenW: Int, onExpand: () -> Unit, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val quickCount = ((screenW - 20 - 14 - 36) / 41).coerceIn(5, 8)
    val quick = remember(mine, quickCount) {
        val base = EmojiCatalog.quickReactions.take(quickCount)
        if (mine != null && mine !in base) listOf(mine) + base.dropLast(1) else base
    }
    Surface(
        shape = RoundedCornerShape(if (expanded) 24.dp else 30.dp),
        color = cs.surface,
        shadowElevation = 12.dp,
        modifier = Modifier.animateContentSize(spring(dampingRatio = 0.8f, stiffness = 520f)),
    ) {
        if (!expanded) {
            Row(Modifier.padding(horizontal = 6.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                quick.forEachIndexed { i, e -> ReactionBarItem(e, i, mine == e, onPick) }
                Box(
                    Modifier.padding(start = 2.dp).size(32.dp).clip(CircleShape)
                        .background(cs.surfaceVariant.copy(alpha = 0.8f)).clickable { onExpand() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.KeyboardArrowDown, "همه واکنش‌ها", tint = cs.onSurfaceVariant, modifier = Modifier.size(22.dp)) }
            }
        } else {
            Column(Modifier.width((screenW - 24).coerceAtMost(380).dp).padding(top = 10.dp)) {
                Text("واکنش‌ها", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp))
                LazyVerticalGrid(GridCells.Adaptive(44.dp), Modifier.fillMaxWidth().height(268.dp).padding(6.dp)) {
                    items(EmojiCatalog.allReactions) { e -> ReactionGridItem(e, mine == e, onPick) }
                }
            }
        }
    }
}

@Composable
private fun ReactionBarItem(emoji: String, index: Int, selected: Boolean, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(26L * index + 30L); appear.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = 430f)) }
    var play by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(Unit) { delay(26L * index + 230L); play = 1 }
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        Modifier.size(41.dp)
            .graphicsLayer {
                val a = appear.value
                val s = a * (if (pressed) 1.32f else 1f)
                scaleX = s; scaleY = s
                alpha = a.coerceIn(0f, 1f)
                translationY = (1f - a) * 14.dp.toPx() + (if (pressed) -6.dp.toPx() else 0f)
            }
            .clip(CircleShape)
            .background(if (selected) cs.primary.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(interaction, indication = null) { onPick(emoji) },
        contentAlignment = Alignment.Center,
    ) { AnimatedEmoji(emoji, 31.dp, playKey = play, burst = false) }
}

@Composable
private fun ReactionGridItem(emoji: String, selected: Boolean, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        Modifier.size(44.dp).graphicsLayer { val s = if (pressed) 1.25f else 1f; scaleX = s; scaleY = s }
            .clip(CircleShape)
            .background(if (selected) cs.primary.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(interaction, indication = null) { onPick(emoji) },
        contentAlignment = Alignment.Center,
    ) { ir.studying.app.core.Icon3D(emoji, 32.dp) }
}

@Composable
private fun ActionCard(actions: List<MenuAction>, alignEnd: Boolean, onPick: (MenuAction) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(18.dp), color = cs.surface, shadowElevation = 14.dp, modifier = Modifier.width(232.dp)) {
        Column(Modifier.padding(vertical = 6.dp)) {
            actions.forEachIndexed { i, a ->
                val appear = remember { Animatable(0f) }
                LaunchedEffect(Unit) { delay(22L * i + 40L); appear.animateTo(1f, spring(dampingRatio = 0.75f, stiffness = 520f)) }
                val tint = if (a.danger) cs.error else cs.onSurface
                if (a.danger && i > 0) Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp).height(1.dp).background(cs.outlineVariant.copy(alpha = 0.6f)))
                Row(
                    Modifier.fillMaxWidth()
                        .graphicsLayer {
                            val v = appear.value
                            alpha = v.coerceIn(0f, 1f)
                            translationX = (1f - v) * (if (alignEnd) 18.dp.toPx() else -18.dp.toPx())
                        }
                        .clickable { onPick(a) }
                        .padding(horizontal = 16.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(a.icon, null, tint = tint.copy(alpha = 0.86f), modifier = Modifier.size(21.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(a.label, style = MaterialTheme.typography.bodyLarge, color = tint)
                }
            }
        }
    }
}

/** Big 3D emoji that pops over the message after a reaction is picked. */
@Composable
fun ReactionSplashLayer(state: ReactionSplashState) {
    val s = state.shot ?: return
    val p = remember(s) { Animatable(0f) }
    LaunchedEffect(s) {
        p.animateTo(1f, tween(1000, easing = LinearEasing))
        if (state.shot === s) state.shot = null
    }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val size = 128.dp
    val px = with(LocalDensity.current) { size.toPx() }
    Box(Modifier.fillMaxSize().onGloballyPositioned { origin = it.boundsInRoot().topLeft }) {
        AnimatedEmoji(
            s.emoji, size, playKey = s.id, burst = true,
            modifier = Modifier
                .offset { IntOffset((s.center.x - origin.x - px / 2f).roundToInt(), (s.center.y - origin.y - px / 2f).roundToInt()) }
                .graphicsLayer {
                    val v = p.value
                    val sc = when {
                        v < 0.22f -> 0.3f + (1.15f - 0.3f) * (v / 0.22f)
                        v < 0.7f -> 1.15f - 0.15f * ((v - 0.22f) / 0.48f)
                        else -> 1f - 0.65f * ((v - 0.7f) / 0.3f)
                    }
                    scaleX = sc; scaleY = sc
                    alpha = if (v > 0.72f) (1f - (v - 0.72f) / 0.28f).coerceIn(0f, 1f) else 1f
                    translationY = -(v * 26.dp.toPx())
                },
        )
    }
}
