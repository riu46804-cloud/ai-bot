@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.messages

import ir.studying.app.R
import androidx.compose.ui.res.stringResource
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.components.Refreshable
import androidx.lifecycle.repeatOnLifecycle
import androidx.activity.compose.BackHandler
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Fmt
import ir.studying.app.core.NavBus
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.data.Conversation
import ir.studying.app.data.StudyGroup
import ir.studying.app.data.UserResult
import ir.studying.app.ui.community.GroupChatScreen
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.components.GlassAction
import ir.studying.app.ui.components.GlassMenu
import ir.studying.app.ui.components.LoadingBox
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.interaction.collectIsPressedAsState
import ir.studying.app.core.EmojiText

private sealed class MsgRoute {
    object Inbox : MsgRoute()
    data class Dm(val username: String) : MsgRoute()
    data class Channel(val key: String, val title: String, val emoji: String) : MsgRoute()
    data class Group(val id: Int, val name: String) : MsgRoute()
    data class GroupDetail(val id: Int, val name: String) : MsgRoute()
    object GroupsHome : MsgRoute()
}

@Composable
fun MessagesScreen(vm: MessagesViewModel = viewModel()) {
    val sep = '\u0001'
    var route by rememberSaveable(stateSaver = androidx.compose.runtime.saveable.Saver(
        save = { r -> when (r) {
            is MsgRoute.Dm -> "dm$sep${r.username}"
            is MsgRoute.Channel -> "ch$sep${r.key}$sep${r.title}$sep${r.emoji}"
            is MsgRoute.Group -> "grp$sep${r.id}$sep${r.name}"
            is MsgRoute.GroupDetail -> "grpd$sep${r.id}$sep${r.name}"
            is MsgRoute.GroupsHome -> "grphome"
            else -> "inbox"
        } },
        restore = { s -> runCatching {
            val p = s.split(sep)
            when (p.getOrNull(0)) {
                "dm" -> MsgRoute.Dm(p.getOrElse(1) { "" }).takeIf { it.username.isNotBlank() } ?: MsgRoute.Inbox
                "ch" -> MsgRoute.Channel(p.getOrElse(1) { "public" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" })
                "grphome" -> MsgRoute.GroupsHome
                "grp" -> p.getOrNull(1)?.toIntOrNull()?.let { gid -> MsgRoute.Group(gid, p.getOrElse(2) { "" }) } ?: MsgRoute.Inbox
                "grpd" -> p.getOrNull(1)?.toIntOrNull()?.let { gid -> MsgRoute.GroupDetail(gid, p.getOrElse(2) { "" }) } ?: MsgRoute.Inbox
                else -> MsgRoute.Inbox
            }
        }.getOrDefault(MsgRoute.Inbox) },
    )) { mutableStateOf<MsgRoute>(MsgRoute.Inbox) }

    // React to cross-tab "open DM" requests
    val openDm by NavBus.openDm.collectAsState()
    LaunchedEffect(openDm) {
        val u = openDm
        if (u != null) { route = MsgRoute.Dm(u); NavBus.consumeDm() }
    }
    val openCh by NavBus.openChannel.collectAsState()
    LaunchedEffect(openCh) {
        openCh?.let { route = MsgRoute.Channel(it.first, it.second, it.third); NavBus.consumeChannel() }
    }

    // study-group requests coming from the Home groups section
    val openGrp by NavBus.openGroup.collectAsState()
    LaunchedEffect(openGrp) {
        openGrp?.let { route = MsgRoute.Group(it.first, it.second); NavBus.consumeGroup() }
    }
    val openGrpDetail by NavBus.openGroupDetail.collectAsState()
    LaunchedEffect(openGrpDetail) {
        openGrpDetail?.let { route = MsgRoute.GroupDetail(it.first, it.second); NavBus.consumeGroupDetail() }
    }
    val openGrpHome by NavBus.openGroupsHome.collectAsState()
    LaunchedEffect(openGrpHome) {
        if (openGrpHome) { route = MsgRoute.GroupsHome; NavBus.consumeGroupsHome() }
    }

    androidx.compose.animation.AnimatedContent(
        targetState = route,
        transitionSpec = {
            val enteringChat = targetState !is MsgRoute.Inbox
            val slideDir = if (enteringChat) -1 else 1
            (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(260)) { it / 6 * slideDir } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260)))
                .togetherWith(androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(200)) { -it / 8 * slideDir } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)))
        },
        label = "msgRoute",
    ) { r ->
        when (r) {
            is MsgRoute.Inbox -> InboxScreen(vm,
                onOpenDm = { route = MsgRoute.Dm(it) },
                onOpenChannel = { key, title, emoji -> route = MsgRoute.Channel(key, title, emoji) },
                onOpenGroup = { id, name -> route = MsgRoute.Group(id, name) },
                onOpenGroupsHome = { route = MsgRoute.GroupsHome })
            is MsgRoute.Dm -> { BackHandler { route = MsgRoute.Inbox }; DmThreadScreen(r.username, onBack = { route = MsgRoute.Inbox }) }
            is MsgRoute.Channel -> { BackHandler { route = MsgRoute.Inbox }; ChannelChatScreen(r.key, r.title, r.emoji, onBack = { route = MsgRoute.Inbox }, onOpenDm = { route = MsgRoute.Dm(it) }) }
            is MsgRoute.Group -> { BackHandler { route = MsgRoute.Inbox }; GroupChatScreen(r.id, r.name, onBack = { route = MsgRoute.Inbox }) }
            is MsgRoute.GroupDetail -> {
                // Tapping a group on Home opens study hours and members,
                // not the chat. The chat is one button away from here.
                BackHandler { route = MsgRoute.Inbox }
                ir.studying.app.ui.community.GroupsTab(initialGroupId = r.id, onExit = { route = MsgRoute.Inbox })
            }
            is MsgRoute.GroupsHome -> {
                BackHandler { route = MsgRoute.Inbox }
                ir.studying.app.ui.community.GroupsTab(onExit = { route = MsgRoute.Inbox })
            }
        }
    }
}

@Composable
private fun InboxScreen(vm: MessagesViewModel, onOpenDm: (String) -> Unit, onOpenChannel: (String, String, String) -> Unit, onOpenGroup: (Int, String) -> Unit, onOpenGroupsHome: () -> Unit) {
    val state by vm.state.collectAsState()
    val prefs by ir.studying.app.core.Store.prefs.collectAsState()
    val gMeta by vm.groupMeta.collectAsState()
    var chatMenu by remember { mutableStateOf<String?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    val cs = MaterialTheme.colorScheme
    // Polls only while the inbox is actually on screen, not in the background.
    val inboxLifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current
    LaunchedEffect(inboxLifecycle) {
        inboxLifecycle.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.RESUMED) {
            while (true) { vm.poll(); delay(7000) }
        }
    }
    LaunchedEffect(Unit) { ir.studying.app.core.RefreshBus.events.collect { if (it == "dm" || it == "groups" || it == "all") vm.poll() } }
    LaunchedEffect(state.query) { delay(400); if (state.query.isNotBlank()) vm.search() }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val fabExpanded by remember { androidx.compose.runtime.derivedStateOf { listState.firstVisibleItemIndex == 0 } }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.messages_screen_002), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text(stringResource(R.string.messages_screen_003), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            val unreadAll = state.conversations.sumOf { it.unread } + gMeta.values.sumOf { it.unread }
            Box {
                ir.studying.app.ui.components.AnimatedEmoji("💬", 46.dp, idle = true, playKey = unreadAll)
                if (unreadAll > 0) Box(Modifier.align(Alignment.TopEnd)) { UnreadBadge(unreadAll, cs.primary, muted = false) }
            }
        }
        ir.studying.app.ui.components.GlowSearchField(
            value = state.query,
            onValueChange = { vm.setQuery(it) },
            placeholder = stringResource(R.string.messages_screen_004),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        Spacer(Modifier.size(8.dp))

        val results = state.searchResults
        if (results != null) {
            if (results.isEmpty()) Box(Modifier.fillMaxWidth().padding(top = 24.dp), contentAlignment = Alignment.Center) {
                ChatEmpty("🔍", "کاربری پیدا نشد", "نام کاربری رو دقیق‌تر بنویس")
            }
            else LazyColumn(contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp, top = 12.dp,
                bottom = 16.dp + LocalBottomBarPadding.current.calculateBottomPadding(),
            ), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(results, key = { _, u -> u.username }) { i, u -> ir.studying.app.ui.components.FadeSlideIn(i) { UserRow(u) { vm.clearSearch(); onOpenDm(u.username) } } }
            }
        } else {
            Refreshable(onRefresh = { vm.poll() }) {
            LazyColumn(state = listState, contentPadding = PaddingValues(
                start = 12.dp, end = 12.dp, top = 4.dp,
                bottom = 88.dp + LocalBottomBarPadding.current.calculateBottomPadding(),
            ), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                item(key = "channels") {
                    val meta by vm.channelMeta.collectAsState()
                    fun sub(ch: String, def: String): String {
                        val m = meta[ch] ?: return def
                        return if (m.first != null) "${m.second}: ${m.first}" else def
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChannelCard("💬", "چت همگانی", sub("public", "گفت‌وگوی عمومی همه"), channelTint("public", cs.primary), meta["public"]?.third ?: 0,
                            prefs.muted.contains("ch:public"), 0, Modifier.weight(1f)) { onOpenChannel("public", "چت همگانی", "💬") }
                        ChannelCard("❓", "رفع اشکال", sub("help", "سوال بپرس، کمک کن"), channelTint("help", cs.primary), meta["help"]?.third ?: 0,
                            prefs.muted.contains("ch:help"), 1, Modifier.weight(1f)) { onOpenChannel("help", "رفع اشکال", "❓") }
                        ChannelCard("📢", "اطلاع‌رسانی", sub("news", "اخبار و اطلاعیه‌ها"), channelTint("news", cs.primary), meta["news"]?.third ?: 0,
                            prefs.muted.contains("ch:news"), 2, Modifier.weight(1f)) { onOpenChannel("news", "اطلاع‌رسانی", "📢") }
                    }
                }
                item(key = "title") {
                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(width = 4.dp, height = 16.dp).background(ir.studying.app.ui.theme.brandGradient(), CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.messages_screen_005), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        val n = state.conversations.size + state.groups.size
                        if (n > 0) {
                            Spacer(Modifier.width(6.dp))
                            Text(n.fa(), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                                modifier = Modifier.background(cs.surfaceVariant.copy(alpha = 0.7f), CircleShape).padding(horizontal = 7.dp, vertical = 1.dp))
                        }
                    }
                }
                when {
                    state.loading -> items(5, key = { "sk$it" }) { InboxRowSkeleton() }
                    state.conversations.isEmpty() && state.groups.isEmpty() -> item(key = "empty") {
                        Box(Modifier.fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
                            ChatEmpty("✉️", "هنوز گفتگویی نداری", "یه کاربر رو جستجو کن و اولین پیام رو بفرست")
                        }
                    }
                    else -> {
                        // ادغام تلگرامی: پیوی‌ها و گروه‌ها با هم، مرتب بر اساس آخرین پیام (پین‌ها اول)
                        val entries: List<InboxEntry> =
                            state.conversations.map { c -> InboxEntry.Dm(c, c.lastTime) } +
                            state.groups.map { g -> InboxEntry.Grp(g, gMeta[g.id]?.time) }
                        val sorted = entries.sortedWith(
                            compareByDescending<InboxEntry> { e ->
                                val key = when (e) { is InboxEntry.Dm -> "dm:" + e.c.username; is InboxEntry.Grp -> "grp:" + e.g.id }
                                prefs.pinned.contains(key)
                            }.thenByDescending { it.time ?: "" })
                        itemsIndexed(sorted, key = { _, e -> when (e) { is InboxEntry.Dm -> e.c.username; is InboxEntry.Grp -> "g" + e.g.id } }) { i, e ->
                            Box(Modifier.animateItemPlacement(androidx.compose.animation.core.spring(dampingRatio = 0.85f, stiffness = 380f))) {
                                ir.studying.app.ui.components.FadeSlideIn(i) {
                                    when (e) {
                                        is InboxEntry.Dm -> ConversationRow(e.c, pinned = prefs.pinned.contains("dm:" + e.c.username),
                                            muted = prefs.muted.contains("dm:" + e.c.username),
                                            onClick = { onOpenDm(e.c.username) },
                                            onLongClick = { chatMenu = e.c.username })
                                        is InboxEntry.Grp -> {
                                            val gm = gMeta[e.g.id]
                                            GroupInboxRow(e.g, gm?.sender, gm?.last, gm?.time, gm?.unread ?: 0, gm?.mention == true,
                                                pinned = prefs.pinned.contains("grp:" + e.g.id),
                                                muted = prefs.muted.contains("grp:" + e.g.id),
                                                onClick = { onOpenGroup(e.g.id, e.g.name) },
                                                onLongClick = { chatMenu = "grp:" + e.g.id })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }
    // گروه‌های مطالعه — دکمه شناور با ایموجی سه‌بعدی؛ با اسکرول جمع می‌شود
    GroupsFab(expanded = fabExpanded, onClick = onOpenGroupsHome, modifier = Modifier.align(Alignment.BottomStart).padding(18.dp))

    deleteTarget?.let { peer ->
        DeleteDmDialog(username = peer, conversation = true,
            busy = state.deletingUser == peer, onDismiss = { deleteTarget = null },
            onConfirm = { scope -> vm.deleteConversation(peer, scope) { error ->
                if (error != null) ir.studying.app.ui.components.AppSnack.show(error)
                else { deleteTarget = null; ir.studying.app.ui.components.AppSnack.show("گفتگو حذف شد") }
            } })
    }

    chatMenu?.let { cu ->
        val key = if (cu.startsWith("grp:")) cu else "dm:" + cu
        GlassMenu(onDismiss = { chatMenu = null }) {
            GlassAction(Icons.Rounded.PushPin,
                if (prefs.pinned.contains(key)) "برداشتن پین" else "پین کردن") { ir.studying.app.core.Store.togglePin(key) }
            GlassAction(Icons.Rounded.NotificationsOff,
                if (prefs.muted.contains(key)) "صدادار کردن" else "بی‌صدا کردن") { ir.studying.app.core.Store.toggleMute(key) }
            if (!cu.startsWith("grp:")) {
                GlassAction(Icons.Rounded.Delete, "حذف گفتگو", danger = true) {
                    deleteTarget = cu
                    chatMenu = null
                }
            }
        }
    }
    }
}

@Composable
private fun GroupsFab(expanded: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.93f else 1f, androidx.compose.animation.core.spring(dampingRatio = 0.5f, stiffness = 700f), label = "fab")
    var play by remember { mutableStateOf(0) }
    Surface(shape = CircleShape, color = Color.Transparent, shadowElevation = 10.dp,
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
        Row(
            Modifier.background(ir.studying.app.ui.theme.brandGradient())
                .clickable(interaction, indication = null) { play++; onClick() }
                .animateContentSize(androidx.compose.animation.core.spring(dampingRatio = 0.75f, stiffness = 500f))
                .padding(horizontal = if (expanded) 16.dp else 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ir.studying.app.ui.components.AnimatedEmoji("🤝", 30.dp, playKey = play, burst = false)
            if (expanded) {
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.messages_screen_001), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onPrimary)
            }
        }
    }
}

/** Animated unread counter: pops when the number changes; grey when muted. */
@Composable
private fun UnreadBadge(count: Int, tint: Color, muted: Boolean) {
    val pop = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(count) {
        pop.snapTo(0.6f)
        pop.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.4f, stiffness = 600f))
    }
    val bg = if (muted) MaterialTheme.colorScheme.outline else tint
    androidx.compose.animation.AnimatedContent(
        targetState = count,
        transitionSpec = {
            (androidx.compose.animation.slideInVertically { -it } + androidx.compose.animation.fadeIn())
                .togetherWith(androidx.compose.animation.slideOutVertically { it } + androidx.compose.animation.fadeOut())
        },
        modifier = Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }
            .background(bg, CircleShape).padding(horizontal = 7.dp, vertical = 2.dp),
        label = "unread",
    ) { n ->
        Text(if (n > 999) "۹۹۹+" else n.fa(), color = if (muted) MaterialTheme.colorScheme.surface else contentOn(bg),
            style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

private fun contentOn(c: Color): Color = if (c.luminance() > 0.55f) Color(0xFF10201A) else Color.White

@Composable
private fun ChannelCard(emoji: String, title: String, subtitle: String, tint: Color, unread: Int, muted: Boolean, index: Int, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, androidx.compose.animation.core.spring(dampingRatio = 0.5f, stiffness = 800f), label = "chPress")
    var play by remember { mutableStateOf(0) }
    // The caller's modifier carries RowScope.weight, so it must sit on the outermost
    // node. FadeSlideIn wraps its content in a plain Box, which would swallow the
    // weight and let the first card take the whole row.
    Box(modifier) {
    ir.studying.app.ui.components.FadeSlideIn(index) {
        Surface(
            shape = RoundedCornerShape(22.dp), color = cs.surface,
            border = BorderStroke(1.dp, tint.copy(alpha = 0.28f)), shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale },
        ) {
            Column(
                Modifier.background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.16f), Color.Transparent)))
                    .clickable(interaction, indication = null) { play++; onClick() }
                    .padding(10.dp),
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(tint, lerp(tint, Color.Black, 0.3f)))),
                        contentAlignment = Alignment.Center,
                    ) { ir.studying.app.ui.components.AnimatedEmoji(emoji, 28.dp, playKey = play, burst = false) }
                    Spacer(Modifier.weight(1f))
                    if (unread > 0) UnreadBadge(unread, tint, muted)
                    else if (muted) Icon(Icons.Rounded.NotificationsOff, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(14.dp))
                }
                Spacer(Modifier.size(8.dp))
                Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                EmojiText(subtitle, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.height(32.dp))
            }
        }
    }
    }
}

@Composable
private fun InboxRowSkeleton() {
    val cs = MaterialTheme.colorScheme
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "isk")
    val a by t.animateFloat(0.35f, 0.8f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(800),
        androidx.compose.animation.core.RepeatMode.Reverse), label = "iskA")
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp).graphicsLayer { alpha = a }, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(cs.surfaceVariant))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.fillMaxWidth(0.4f).size(height = 12.dp, width = 0.dp).clip(CircleShape).background(cs.surfaceVariant))
            Box(Modifier.fillMaxWidth(0.75f).size(height = 10.dp, width = 0.dp).clip(CircleShape).background(cs.surfaceVariant))
        }
    }
}

/** Row chrome shared by DMs and groups: press feedback, pinned tint. */
@Composable
private fun InboxRowFrame(pinned: Boolean, onClick: () -> Unit, onLongClick: () -> Unit, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.975f else 1f, androidx.compose.animation.core.spring(dampingRatio = 0.6f, stiffness = 800f), label = "rowPress")
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    Row(
        Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(22.dp))
            .background(if (pinned) cs.primary.copy(alpha = 0.06f) else Color.Transparent)
            .combinedClickable(interactionSource = interaction, indication = androidx.compose.material.ripple.rememberRipple(),
                onClick = onClick,
                onLongClick = { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); onLongClick() })
            .padding(horizontal = 8.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
private fun RowMeta(time: String?, unread: Int, highlight: Boolean, muted: Boolean, pinned: Boolean, mention: Boolean, tint: Color) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.End) {
        if (time != null) Text(Fmt.relative(time), style = MaterialTheme.typography.labelSmall,
            color = if (highlight) cs.primary else cs.onSurfaceVariant, maxLines = 1)
        Spacer(Modifier.size(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (mention) Box(Modifier.size(20.dp).background(cs.primary, CircleShape), contentAlignment = Alignment.Center) {
                Text("@", color = cs.onPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
            }
            if (unread > 0) UnreadBadge(unread, tint, muted)
            else if (pinned) Icon(Icons.Rounded.PushPin, "سنجاق شده", tint = cs.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(15.dp).graphicsLayer { rotationZ = 35f })
        }
    }
}

@Composable
private fun ConversationRow(c: Conversation, pinned: Boolean = false, muted: Boolean = false, onClick: () -> Unit, onLongClick: () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    InboxRowFrame(pinned, onClick, onLongClick) {
        Avatar(c.username, c.mood, size = 54.dp, online = c.isOnline, avatarUrl = c.avatar)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.username, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false))
                if (muted) { Spacer(Modifier.width(4.dp)); Icon(Icons.Rounded.NotificationsOff, "بی‌صدا", tint = cs.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(14.dp)) }
            }
            Spacer(Modifier.size(3.dp))
            InboxPreview(prefix = if (c.lastFromMe) "تو: " else null, text = previewText(c.lastType, c.lastMessage), unread = c.unread > 0)
        }
        Spacer(Modifier.width(8.dp))
        RowMeta(c.lastTime, c.unread, highlight = c.unread > 0 && !muted, muted = muted, pinned = pinned, mention = false, tint = cs.primary)
    }
}

private fun previewText(type: String, text: String): String = when (type) {
    "image" -> "📷 عکس"; "voice" -> "🎤 پیام صوتی"; "file" -> "📎 فایل"; "music" -> "🎵 موزیک"; "sticker" -> "🎨 استیکر"; "gif" -> "GIF"
    else -> ir.studying.app.core.Challenges.label(text)
}

@Composable
private fun InboxPreview(prefix: String?, text: String, unread: Boolean) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (prefix != null) Text(prefix, style = MaterialTheme.typography.bodyMedium, color = cs.primary, maxLines = 1)
        EmojiText(text, style = MaterialTheme.typography.bodyMedium, color = if (unread) cs.onSurface else cs.onSurfaceVariant,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
    }
}

@Composable
private fun UserRow(u: UserResult, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(22.dp), color = cs.surface,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
        onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(u.username, u.mood, size = 46.dp, online = u.isOnline, avatarUrl = u.avatar)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(u.username, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                EmojiText(u.statusText.ifBlank { if (u.isOnline) "آنلاین" else "آفلاین" }, style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.size(38.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.Send, "شروع چت", tint = cs.primary, modifier = Modifier.size(19.dp))
            }
        }
    }
}


/** آیتم اینباکس تلگرامی — پیوی یا گروه. */
sealed class InboxEntry(val time: String?) {
    class Dm(val c: ir.studying.app.data.Conversation, t: String?) : InboxEntry(t)
    class Grp(val g: ir.studying.app.data.StudyGroup, t: String?) : InboxEntry(t)
}

@Composable
private fun GroupInboxRow(g: StudyGroup, sender: String?, last: String?, time: String?, unread: Int, mention: Boolean,
                          pinned: Boolean, muted: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    InboxRowFrame(pinned, onClick, onLongClick) {
        ir.studying.app.ui.community.GroupAvatar(g.avatar, g.username, 54.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Groups, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                EmojiText(g.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false))
                if (muted) { Spacer(Modifier.width(4.dp)); Icon(Icons.Rounded.NotificationsOff, "بی‌صدا", tint = cs.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(14.dp)) }
            }
            Spacer(Modifier.size(3.dp))
            if (last != null) InboxPreview(prefix = (sender ?: "").takeIf { it.isNotBlank() }?.let { "$it: " }, text = last, unread = unread > 0)
            else Text("${g.memberCount.fa()} عضو · گروه مطالعه", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1)
        }
        Spacer(Modifier.width(8.dp))
        RowMeta(time, unread, highlight = unread > 0 && !muted, muted = muted, pinned = pinned, mention = mention, tint = Color(0xFF8B7CF6))
    }
}
