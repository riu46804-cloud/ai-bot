package ir.studying.app.ui.messages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.data.Conversation
import ir.studying.app.data.UserResult
import ir.studying.app.data.StudyGroup
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MessagesViewModel : ViewModel() {
    data class State(
        val loading: Boolean = true,
        val conversations: List<Conversation> = emptyList(),
        val query: String = "",
        val searchResults: List<UserResult>? = null,
        val searching: Boolean = false,
        val groups: List<StudyGroup> = emptyList(),
        val deletingUser: String? = null,
    )

    val state = MutableStateFlow(State())
    private var revision: Long = 0

    /** خلاصه آخرین پیام یک گروه برای لیست گفتگوها. */
    data class GroupMeta(
        val last: String?,
        val sender: String?,
        val time: String?,
        val unread: Int,
        val mention: Boolean,
    )

    /** channel -> (last_message, last_sender, unread) */
    val channelMeta = MutableStateFlow<Map<String, Triple<String?, String?, Int>>>(emptyMap())

    /** group_id -> GroupMeta */
    val groupMeta = MutableStateFlow<Map<Int, GroupMeta>>(emptyMap())

    fun poll() {
        val generation = revision
        viewModelScope.launch {
            runCatching {
                val meta = Api.obj(Api.get("inbox_meta"))
                val chs = meta.optJSONArray("channels")
                if (chs != null) {
                    val m = mutableMapOf<String, Triple<String?, String?, Int>>()
                    for (i in 0 until chs.length()) {
                        val c = chs.getJSONObject(i)
                        m[c.optString("channel")] = Triple(ir.studying.app.core.Challenges.label(c.optString("last_message")).takeIf { it.isNotBlank() && it != "null" }, c.optString("last_sender").takeIf { it.isNotBlank() && it != "null" }, c.optInt("unread", 0))
                    }
                    channelMeta.value = m
                }
                val grs = meta.optJSONArray("groups")
                if (grs != null) {
                    val gm = mutableMapOf<Int, GroupMeta>()
                    for (i in 0 until grs.length()) {
                        val g = grs.getJSONObject(i)
                        gm[g.optInt("group_id")] = GroupMeta(
                            g.optString("last_message").takeIf { it.isNotBlank() && it != "null" },
                            g.optString("last_sender").takeIf { it.isNotBlank() && it != "null" },
                            g.optString("last_time").takeIf { it.isNotBlank() && it != "null" },
                            g.optInt("unread", 0), g.optInt("mention", 0) == 1)
                    }
                    groupMeta.value = gm
                }
            }
            runCatching { Conversation.list(Api.arr(Api.get("dm_conversations"))) }
                .onSuccess { l ->
                    if (generation == revision && state.value.deletingUser == null)
                        state.update { it.copy(loading = false, conversations = l) }
                }.onFailure { if (generation == revision) state.update { it.copy(loading = false) } }
            runCatching { StudyGroup.list(Api.arr(Api.get("group_list"))) }
                .onSuccess { l -> state.update { it.copy(groups = l) } }
        }
    }

    fun deleteConversation(username: String, scope: ir.studying.app.data.DmDeleteScope,
        onDone: (String?) -> Unit) {
        if (state.value.deletingUser != null) return
        val session = ir.studying.app.core.Store.session.value
        revision++
        state.update { it.copy(deletingUser = username) }
        viewModelScope.launch {
            val result = runCatching { ir.studying.app.data.DmDeletion.conversation(username, scope, session) }
            if (ir.studying.app.core.Store.session.value != session) return@launch
            revision++
            state.update { it.copy(deletingUser = null, loading = false,
                conversations = if (result.isSuccess) it.conversations.filterNot { c -> c.username == username } else it.conversations) }
            result.onSuccess { onDone(null) }.onFailure { onDone(it.message ?: "حذف انجام نشد") }
            poll()
        }
    }

    fun setQuery(q: String) {
        state.update { it.copy(query = q, searchResults = if (q.isBlank()) null else it.searchResults) }
    }

    fun search() {
        val q = state.value.query.trim()
        if (q.isEmpty()) { state.update { it.copy(searchResults = null) }; return }
        viewModelScope.launch {
            state.update { it.copy(searching = true) }
            runCatching { UserResult.list(Api.arr(Api.get("user_search", "q" to q))) }
                .onSuccess { l -> state.update { it.copy(searchResults = l, searching = false) } }
                .onFailure { state.update { it.copy(searching = false) } }
        }
    }

    fun clearSearch() {
        state.update { it.copy(query = "", searchResults = null) }
    }
}
