package ir.studying.app.ui.messages

import ir.studying.app.data.Reaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/* Queued messages use a normal bubble; the server takeover is atomic and
 * never guesses identity from message text, time, order or counts. */

enum class SendState { SENDING, SENT, FAILED }

data class OutMsg(
    val localId: Long,
    val text: String,
    val replyTo: Int?,
    val replySender: String?,
    val replyPreview: String?,
    /** yyyy-MM-dd HH:mm:ss, Tehran time like the server's own timestamps. */
    val createdAt: String,
    val state: SendState = SendState.SENDING,
    val serverId: Int? = null,
    /** Newest server id the chat knew about when this was queued. */
    val afterId: Int = 0,
    val sentAtMs: Long = 0L,
) {
    val key: String get() = "l$localId"
}

/** The bits of a server message needed to recognise our own pending one. */
data class ServerMsg(val id: Int, val sender: String, val text: String?)

/** Delivery bookkeeping only. Never infer server identity from text or counts. */
class Outbox(private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val lock = Any()
    private val _items = MutableStateFlow<List<OutMsg>>(emptyList())
    val items: StateFlow<List<OutMsg>> get() = _items
    private var seq = 0L

    /** Server identities are stable and independent of transient delivery state. */
    fun keyFor(serverId: Int): String = "m$serverId"

    fun add(text: String, replyTo: Int?, replySender: String?, replyPreview: String?, afterId: Int,
            createdAt: String = nowTehran(clock())): OutMsg = synchronized(lock) {
        val item = OutMsg(++seq, text, replyTo, replySender, replyPreview, createdAt, afterId = afterId)
        _items.value = _items.value + item
        item
    }

    fun markSent(localId: Long, serverId: Int?) = synchronized(lock) {
        val sid = serverId?.takeIf { it > 0 }
        val now = clock()
        // Keep the checked bubble until an accepted post-ack poll replaces it.
        _items.value = _items.value.map { if (it.localId == localId) it.copy(state = SendState.SENT, serverId = sid, sentAtMs = now) else it }
    }

    fun markFailed(localId: Long) = synchronized(lock) {
        _items.value = _items.value.map { if (it.localId == localId) it.copy(state = SendState.FAILED) else it }
    }

    /** Only explicitly failed operations can be retried; never queue a second active send. */
    fun retry(localId: Long, afterId: Int): OutMsg? = synchronized(lock) {
        val old = _items.value.firstOrNull { it.localId == localId && it.state == SendState.FAILED }
            ?: return@synchronized null
        val next = old.copy(state = SendState.SENDING, afterId = afterId, serverId = null, sentAtMs = 0L)
        _items.value = _items.value.map { if (it.localId == localId) next else it }
        next
    }

    fun remove(localId: Long) = synchronized(lock) { _items.value = _items.value.filterNot { it.localId == localId } }
    fun clear() = synchronized(lock) { _items.value = emptyList() }

    /** Called only for an accepted post-settlement poll, in the timeline transaction. */
    fun reconcile(server: List<ServerMsg>, me: String, retireNoId: Boolean = false) = synchronized(lock) {
        val ids = server.filter { it.sender == me }.mapTo(HashSet()) { it.id }
        _items.value = _items.value.filterNot { item ->
            item.state == SendState.SENT &&
                (item.serverId in ids || (retireNoId && item.serverId == null))
        }
    }

    companion object {
        const val STALE_MS = 20_000L
        // Retained for quoted-text compatibility, never used for server identity.
        fun normalize(s: String): String {
            var t = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&#039;", "'").replace("&#39;", "'").replace("&amp;", "&")
            t = t.replace(Regex("<[^>]*>"), "")
            return t.trim().replace(Regex("\\s+"), " ")
        }
        fun nowTehran(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("Asia/Tehran") }.format(Date(ms))
    }
}

/** Reaction maths that mirrors the server: one reaction per user, same emoji again removes it. */
object Reactions {
    fun toggle(list: List<Reaction>, emoji: String): List<Reaction> {
        val current = list.firstOrNull { it.mine }?.emoji
        val out = list.map { if (it.mine) it.copy(count = it.count - 1, mine = false) else it }
            .filter { it.count > 0 }
            .toMutableList()
        if (current == emoji) return out
        val i = out.indexOfFirst { it.emoji == emoji }
        if (i >= 0) out[i] = out[i].copy(count = out[i].count + 1, mine = true)
        else out.add(Reaction(emoji, 1, true))
        return out
    }
}

/**
 * Optimistic reactions on top of the server's. An override lives until a poll
 * that started after the server confirmed the toggle comes back.
 */
class ReactionOverlay {
    private val _map = MutableStateFlow<Map<Int, List<Reaction>>>(emptyMap())
    val map: StateFlow<Map<Int, List<Reaction>>> get() = _map
    private val settledAt = HashMap<Int, Long>()
    private var generation = 0L

    fun toggle(msgId: Int, server: List<Reaction>, emoji: String): List<Reaction> {
        val base = _map.value[msgId] ?: server
        val next = Reactions.toggle(base, emoji)
        synchronized(settledAt) { settledAt.remove(msgId) }
        _map.update { it + (msgId to next) }
        return next
    }

    /** The server answered the toggle for [msgId]. */
    fun settle(msgId: Int) { synchronized(settledAt) { settledAt[msgId] = generation } }

    /** A poll is starting; returns its generation for [onServer]. */
    fun beginPoll(): Long = synchronized(settledAt) { ++generation }

    /** Fresh server data from the poll started at [pollGeneration]. */
    fun onServer(pollGeneration: Long) {
        val done = synchronized(settledAt) {
            val d = settledAt.filterValues { it < pollGeneration }.keys.toList()
            d.forEach { settledAt.remove(it) }
            d
        }
        if (done.isNotEmpty()) _map.update { it - done.toSet() }
    }

    fun view(msgId: Int, server: List<Reaction>): List<Reaction> = _map.value[msgId] ?: server

    /** The server refused: forget the optimistic state. */
    fun drop(msgId: Int) {
        synchronized(settledAt) { settledAt.remove(msgId) }
        _map.update { it - msgId }
    }

    fun clear() { _map.value = emptyMap(); synchronized(settledAt) { settledAt.clear() } }
}

/**
 * Glue between a chat view model and [Outbox] / [ReactionOverlay]: queues
 * messages, sends them one at a time in order, and settles everything when a
 * poll comes back.
 */
data class ChatTimeline(val server: List<UiMsg> = emptyList(), val pending: List<OutMsg> = emptyList())

class ChatSync(private val scope: CoroutineScope, private val sessionIdentity: () -> Any? = { null }, private val me: () -> String) {
    val outbox = Outbox()
    val reactions = ReactionOverlay()
    private val sendLock = Mutex()
    private val gate = Any()
    private var epoch = 0L
    private var acceptedPoll = 0L
    private var barrier = 0L
    private var ownerSession: Any? = sessionIdentity()
    private val _timeline = MutableStateFlow(ChatTimeline())
    val timeline: StateFlow<ChatTimeline> get() = _timeline

    private fun publishPending() { _timeline.value = _timeline.value.copy(pending = outbox.items.value) }
    fun discard(localId: Long) = synchronized(gate) { outbox.remove(localId); publishPending() }

    fun clear() = synchronized(gate) {
        epoch++
        barrier = reactions.beginPoll()
        acceptedPoll = barrier
        outbox.clear()
        reactions.clear()
        _timeline.value = ChatTimeline()
    }

    /** Drop local history and queues when the authenticated session changes. */
    fun ensureSession() = synchronized(gate) {
        if (ownerSession != sessionIdentity()) { clear(); ownerSession = sessionIdentity() }
    }

    /** Remove a successfully deleted DM immediately; stale polls cannot restore it. */
    fun removeServer(id: Int) = synchronized(gate) {
        barrier = reactions.beginPoll()
        _timeline.value = _timeline.value.copy(server = _timeline.value.server.filterNot { it.id == id })
    }

    /** History and local bubbles are published together; pre-send polls cannot win. */
    fun publishPoll(generation: Long, rows: List<UiMsg>): Boolean = synchronized(gate) {
        if (ownerSession != sessionIdentity() || generation <= acceptedPoll || generation <= barrier || outbox.items.value.any { it.state == SendState.SENDING }) return@synchronized false
        acceptedPoll = generation
        val realRows = serverChat(rows)
        outbox.reconcile(realRows.map { ServerMsg(it.id, it.sender, it.text) }, me(), retireNoId = true)
        _timeline.value = ChatTimeline(realRows, outbox.items.value)
        reactions.onServer(generation)
        true
    }

    /**
     * Shows delivery status for [text] and sends it once in the background.
     * [send] posts the message and returns the new server id when the server tells it.
     */
    fun queue(
        text: String, replyTo: Int?, replySender: String?, replyPreview: String?, afterId: Int,
        send: suspend (OutMsg) -> Int?, onErr: (String) -> Unit, after: () -> Unit,
    ): OutMsg {
        ensureSession()
        val o = synchronized(gate) {
            barrier = reactions.beginPoll()
            outbox.add(text, replyTo, replySender, replyPreview, afterId).also { publishPending() }
        }
        deliver(o, send, onErr, after)
        return o
    }

    fun retry(localId: Long, afterId: Int, send: suspend (OutMsg) -> Int?, onErr: (String) -> Unit, after: () -> Unit) {
        val o = synchronized(gate) {
            outbox.retry(localId, afterId)?.also { barrier = reactions.beginPoll(); publishPending() }
        } ?: return
        deliver(o, send, onErr, after)
    }

    private fun deliver(o: OutMsg, send: suspend (OutMsg) -> Int?, onErr: (String) -> Unit, after: () -> Unit) {
        val generation = synchronized(gate) { epoch }
        val owner = me()
        val session = sessionIdentity()
        fun current() = synchronized(gate) { generation == epoch && owner == me() && session == sessionIdentity() }
        scope.launch {
            val result = sendLock.withLock {
                if (!current()) return@launch
                runCatching { send(o) }
            }
            if (!current()) return@launch
            synchronized(gate) {
                if (!current()) return@launch
                barrier = reactions.beginPoll()
                result.onSuccess { id -> outbox.markSent(o.localId, id) }
                    .onFailure { outbox.markFailed(o.localId) }
                publishPending()
            }
            result.onFailure { onErr("وضعیت ارسال مشخص نیست؛ پیش از ارسال دوباره گفتگو را بررسی کن") }
            after()
        }
    }

    /** Optimistic reaction: the chip changes now, the server catches up. */
    fun react(msgId: Int, server: List<Reaction>, emoji: String, call: suspend () -> Unit, after: () -> Unit) {
        ensureSession()
        val generation = synchronized(gate) { epoch }
        val session = sessionIdentity()
        reactions.toggle(msgId, server, emoji)
        scope.launch {
            val ok = runCatching { call() }.isSuccess
            if (synchronized(gate) { generation != epoch || session != sessionIdentity() }) return@launch
            if (ok) reactions.settle(msgId) else reactions.drop(msgId)
            after()
        }
    }

    fun beginPoll(): Long { ensureSession(); return reactions.beginPoll() }

    companion object {
        /** The "id" a send endpoint answered with, if any. */
        fun idOf(response: String?): Int? = runCatching { org.json.JSONObject(response ?: "").optInt("id", 0) }
            .getOrNull()?.takeIf { it > 0 }
    }
}
