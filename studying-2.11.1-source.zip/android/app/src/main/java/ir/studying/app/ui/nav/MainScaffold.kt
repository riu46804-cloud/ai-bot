package ir.studying.app.ui.nav

import ir.studying.app.core.AppIcons
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import ir.studying.app.ui.components.collectAppSnacks
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ir.studying.app.core.Api
import ir.studying.app.core.NavBus
import ir.studying.app.core.fa
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro
import ir.studying.app.ui.community.CommunityScreen
import ir.studying.app.ui.home.HomeScreen
import ir.studying.app.ui.library.LibraryScreen
import ir.studying.app.ui.library.MiniPlayer
import ir.studying.app.ui.messages.MessagesScreen
import ir.studying.app.ui.profile.ProfileScreen
import ir.studying.app.ui.study.StudySpaceDialog
import ir.studying.app.ui.study.room.StudyRoomScreen
import ir.studying.app.ui.tasks.TasksScreen
import ir.studying.app.ui.theme.brandGradient
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * How much room the floating bottom furniture needs.
 *
 * Provided by [MainScaffold]; every scrolling screen adds it to the bottom of
 * its own contentPadding so the final row clears the nav pill, the mini player
 * and the study chip instead of hiding behind them.
 */
val LocalBottomBarPadding = staticCompositionLocalOf { PaddingValues(0.dp) }

private data class Tab(val route: String, val label: String, val icon: ImageVector)

/*
 * Five tabs, including the study report.
 *
 * Seven pills in one bar left every target under the 48.dp touch minimum and
 * the labels never had room to appear. Tasks, community and library are
 * one tap away from the Home shortcut grid instead, where they get a real
 * label and a comfortable hit area.
 */
private val tabs = listOf(
    Tab("home", "خانه", Icons.Rounded.Home),
    Tab("room", "اتاق", Icons.AutoMirrored.Rounded.MenuBook),
    Tab("report", "گزارش", Icons.Rounded.Insights),
    Tab("messages", "پیام‌ها", Icons.AutoMirrored.Rounded.Chat),
    Tab("profile", "پروفایل", Icons.Rounded.Person),
)

@Composable
fun MainScaffold() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    var unread by remember { mutableIntStateOf(0) }

    /*
     * The badge poll used to be a bare `while (true)` inside LaunchedEffect, so
     * it kept hitting dm_unread every ten seconds while the app sat in the
     * background — wasted battery and pointless server load, since the badge is
     * invisible then anyway. repeatOnLifecycle suspends the loop the moment the
     * activity stops and resumes it on return, and the interval backs off as the
     * session goes quiet instead of staying pinned at ten seconds forever.
     */
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            var intervalMs = 10_000L
            while (true) {
                runCatching { Api.obj(Api.get("dm_unread")).optInt("count", 0) }
                    .onSuccess { fresh ->
                        intervalMs = if (fresh == unread) (intervalMs * 2).coerceAtMost(60_000L) else 10_000L
                        unread = fresh
                    }
                delay(intervalMs)
            }
        }
    }
    LaunchedEffect(Unit) {
        ir.studying.app.core.RefreshBus.events.collect {
            if (it == "dm" || it == "all") runCatching { Api.obj(Api.get("dm_unread")).optInt("count", 0) }.onSuccess { c -> unread = c }
        }
    }

    val openDm by NavBus.openDm.collectAsState()
    val openCh by NavBus.openChannel.collectAsState()
    val openGrp by NavBus.openGroup.collectAsState()
    val openGrpHome by NavBus.openGroupsHome.collectAsState()
    val openGrpDetail by NavBus.openGroupDetail.collectAsState()
    LaunchedEffect(openDm, openCh, openGrp, openGrpHome, openGrpDetail) {
        if ((openDm != null || openCh != null || openGrp != null || openGrpDetail != null || openGrpHome) && currentRoute != "messages") {
            nav.navigate("messages") {
                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true; restoreState = true
            }
        }
    }

    val openUserReq by NavBus.openUser.collectAsState()
    val openPostReq by NavBus.openPost.collectAsState()
    LaunchedEffect(openUserReq, openPostReq) {
        if ((openUserReq != null || openPostReq != null) && currentRoute != "community") {
            nav.navigate("community") {
                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true; restoreState = true
            }
        }
    }

    val openRoomReq by NavBus.openRoom.collectAsState()
    LaunchedEffect(openRoomReq) {
        if (openRoomReq) {
            NavBus.consumeRoom()
            if (currentRoute != "room") {
                nav.navigate("room") {
                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true; restoreState = true
                }
            }
        }
    }

    /*
     * Shortcut tiles on Home (and the assistant) ask for a route that no longer
     * lives in the bar.
     *
     * FIX: restoreState used to be on for every route. Navigation restores the
     * whole saved stack of a destination, ignoring the new arguments, so asking
     * for "fc_deck/5" could bring back deck 3, and "flashcards" could land on a
     * deck that was open last week. Only the bottom tabs restore their state now;
     * every other screen always opens fresh with the arguments it was given.
     */
    fun openRoute(r: String) {
        val tab = r in NavBus.TAB_ROUTES
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = tab
        }
    }

    val routeReq by NavBus.openRoute.collectAsState()
    LaunchedEffect(routeReq) {
        val r = routeReq
        if (r != null) {
            NavBus.consumeRoute()
            if (!NavBus.routeMatches(currentRoute, r) || currentRoute?.contains('{') == true) runCatching { openRoute(r) }
        }
    }

    /* دستیار: ناوبری با رسید — بعد از رفتن، بررسی می‌شود همان صفحه واقعاً باز است. */
    val assistReq by NavBus.assistNav.collectAsState()
    LaunchedEffect(assistReq) {
        val r = assistReq ?: return@LaunchedEffect
        NavBus.consumeAssistNav(r.id)
        val ok = runCatching {
            val here = nav.currentBackStackEntry
            val same = NavBus.routeMatches(here?.destination?.route, r.route) &&
                (here?.destination?.route?.contains('{') != true || here?.arguments?.getString("id")?.let { r.route.endsWith("/$it") } == true)
            if (!same) openRoute(r.route)
            NavBus.routeMatches(nav.currentBackStackEntry?.destination?.route, r.route)
        }.getOrDefault(false)
        NavBus.reportNav(r.id, ok)
    }

    val openStudy by NavBus.openStudy.collectAsState()

    val snackHost = remember { SnackbarHostState() }
    val snackScope = rememberCoroutineScope()
    LaunchedEffect(snackHost) { snackScope.collectAppSnacks(snackHost) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = {
            // Sits above the floating bar instead of underneath it.
            SnackbarHost(snackHost, Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) { data ->
                val cs = MaterialTheme.colorScheme
                androidx.compose.material3.Snackbar(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    containerColor = cs.inverseSurface,
                    contentColor = cs.inverseOnSurface,
                    action = data.visuals.actionLabel?.let { label ->
                        {
                            androidx.compose.material3.TextButton(onClick = { data.performAction() }) {
                                androidx.compose.material3.Text(label, color = cs.inversePrimary)
                            }
                        }
                    },
                ) {
                    // 3D emoji in toasts too ("ذخیره شد ✅" ...)
                    ir.studying.app.core.EmojiText(data.visuals.message, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        bottomBar = {
            Column {
                MiniPlayer()
                FloatingNavBar(currentRoute, unread) { route ->
                    nav.navigate(route) {
                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true; restoreState = true
                    }
                }
            }
        },
    ) { padding ->
        /*
         * Three floating layers can stack at the bottom: the mini player, the
         * pill nav bar and the study chip. Screens used to pad their lists with
         * a flat 16.dp, so the last rows hid behind all of it on short devices.
         * The scaffold already measures the real height — publish it so every
         * list can add it to its own contentPadding.
         */
        val layoutDir = LocalLayoutDirection.current
        CompositionLocalProvider(
            LocalBottomBarPadding provides PaddingValues(
                start = padding.calculateStartPadding(layoutDir),
                end = padding.calculateEndPadding(layoutDir),
                bottom = padding.calculateBottomPadding() + if (currentRoute != "room") 54.dp else 0.dp,
            ),
        ) {
        Box(Modifier.fillMaxSize().padding(padding)) {
            // End-of-session recap, shown above whatever screen is active.
            ir.studying.app.ui.focus.FocusRecapDialog()
            // جشن استریک بعد از اولین پارت روز
            ir.studying.app.ui.components.StreakCelebrationHost()
            NavHost(
                navController = nav, startDestination = "home",
                enterTransition = {
                    fadeIn(tween(260, easing = FastOutSlowInEasing)) +
                            slideInVertically(tween(260, easing = FastOutSlowInEasing)) { it / 24 }
                },
                exitTransition = { fadeOut(tween(150)) },
                popEnterTransition = { fadeIn(tween(240)) },
                popExitTransition = { fadeOut(tween(150)) },
            ) {
                composable("home") {
                    HomeScreen(
                        onOpenFocus = { nav.navigate("focus_settings") },
                        onOpenPhoneMenu = { nav.navigate("focus_phone") },
                    )
                }
                composable("messages") {
                    // During a focus session the in-app chat is part of what gets locked.
                    val locked by ir.studying.app.focus.FocusLock.session.collectAsState()
                    if (ir.studying.app.focus.FocusRules.isRouteLocked("messages", locked)) {
                        ir.studying.app.ui.focus.FocusLockedScreen(
                            title = "گفتگو‌ها",
                            onGoStudy = { nav.navigate("home") { launchSingleTop = true } },
                        )
                    } else MessagesScreen()
                }
                composable("tasks") { TasksScreen() }
                composable("room") { StudyRoomScreen() }
                composable("community") {
                    val locked by ir.studying.app.focus.FocusLock.session.collectAsState()
                    if (ir.studying.app.focus.FocusRules.isRouteLocked("community", locked)) {
                        ir.studying.app.ui.focus.FocusLockedScreen(
                            title = "شبکه‌ اجتماعی",
                            onGoStudy = { nav.navigate("home") { launchSingleTop = true } },
                        )
                    } else CommunityScreen()
                }
                composable("library") { LibraryScreen() }
                composable("report") { ir.studying.app.ui.report.ReportScreen() }
                composable("profile") { ProfileScreen() }
                composable("profile_edit") {
                    ir.studying.app.ui.profile.EditProfileScreen(onBack = { nav.popBackStack() })
                }
                composable("settings") {
                    ir.studying.app.ui.settings.SettingsScreen(
                        // Settings is opened from Profile, so back belongs there —
                        // popBackStack() would drop the user on Home when the
                        // screen was restored from a saved state.
                        onBack = {
                            if (!nav.popBackStack("profile", inclusive = false)) {
                                nav.navigate("profile") {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true; restoreState = true
                                }
                            }
                        },
                        onOpenNotifications = { nav.navigate("settings_notif") },
                        onOpenTelegram = { nav.navigate("settings_telegram") },
                        onOpenDailySms = { nav.navigate("settings_sms") },
                        onOpenFocus = { nav.navigate("focus_settings") },
                    )
                }
                composable("settings_notif") {
                    ir.studying.app.ui.settings.NotificationSettingsScreen(onBack = { nav.popBackStack() })
                }
                composable("focus_settings") {
                    ir.studying.app.ui.focus.FocusSettingsScreen(
                        onBack = { nav.popBackStack() },
                        onOpenApps = { nav.navigate("focus_apps") },
                        onOpenGuide = { nav.navigate("focus_guide") },
                        onOpenPhoneMenu = { nav.navigate("focus_phone") },
                    )
                }
                composable("focus_apps") {
                    ir.studying.app.ui.focus.AppPickerScreen(onBack = { nav.popBackStack() })
                }
                composable("focus_guide") {
                    ir.studying.app.ui.focus.FocusOnboardingScreen(
                        onBack = { nav.popBackStack() },
                        onDone = { nav.popBackStack() },
                        onPickApps = { nav.navigate("focus_apps") },
                    )
                }
                composable("focus_phone") {
                    ir.studying.app.ui.focus.PhoneMenuScreen(onBack = { nav.popBackStack() })
                }
                composable("alarms") {
                    ir.studying.app.ui.alarm.AlarmScreen(onBack = { nav.popBackStack() })
                }
                composable("settings_telegram") {
                    ir.studying.app.ui.settings.TelegramScreen(onBack = { nav.popBackStack() })
                }
                composable("settings_sms") {
                    ir.studying.app.ui.sms.DailySmsScreen(onBack = { nav.popBackStack() })
                }
                composable("flashcards") {
                    ir.studying.app.ui.flashcards.FlashcardsScreen(
                        onBack = { nav.popBackStack() },
                        onOpenDeck = { id -> nav.navigate("fc_deck/$id") },
                        onReview = { id -> nav.navigate("fc_review/$id") },
                        onStats = { nav.navigate("fc_stats") },
                    )
                }
                composable("fc_deck/{id}") { entry ->
                    val id = entry.arguments?.getString("id")?.toIntOrNull() ?: 0
                    ir.studying.app.ui.flashcards.DeckScreen(
                        deckId = id,
                        onBack = { nav.popBackStack() },
                        onReview = { nav.navigate("fc_review/$id") },
                    )
                }
                composable("fc_review/{id}") { entry ->
                    val id = entry.arguments?.getString("id")?.toIntOrNull() ?: 0
                    ir.studying.app.ui.flashcards.ReviewScreen(deckId = id, onBack = { nav.popBackStack() })
                }
                composable("fc_stats") {
                    ir.studying.app.ui.flashcards.FlashcardStatsScreen(onBack = { nav.popBackStack() })
                }
                composable("planner") {
                    ir.studying.app.ui.planner.PlannerScreen(onBack = { nav.popBackStack() })
                }
            }
            // در اتاق مطالعه نوار شناور پنهان می‌شود — آن صفحه تایمر خودش را دارد
            if (currentRoute != "room") {
                StudyFloatingBar(modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)) { NavBus.requestStudy() }
            }
            // جغدِ دستیار هوشمند فقط روی خانه؛ تا سرور آماده نباشد اصلاً دیده نمی‌شود.
            if (currentRoute == "home") {
                ir.studying.app.ui.assistant.AssistantFab(Modifier.align(Alignment.BottomEnd))
            }
        }
        }
    }

    /* صفحهٔ گفت‌وگوی دستیار، روی همه‌چیز (حتی نوار پایین). */
    ir.studying.app.ui.assistant.AssistantOverlay()

    if (openStudy) StudySpaceDialog(onClose = { NavBus.consumeStudy() })

    /* زنگ در حال پخش: پوشش غیرقابل‌بستن روی هر صفحه‌ای که کاربر باز کرده. */
    ir.studying.app.ui.alarm.AlarmRingOverlay()
}

/** نوار ناوبری قرصی شناور — امضای بازطراحی «شب مطالعه». */
@Composable
private fun FloatingNavBar(currentRoute: String?, unread: Int, onSelect: (String) -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .height(72.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
        shadowElevation = 16.dp,
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEach { tab ->
                ir.studying.app.ui.components.NavBubbleItem(
                    icon = tab.icon,
                    label = tab.label,
                    selected = currentRoute == tab.route,
                    badge = if (tab.route == "messages") unread else 0,
                    modifier = Modifier.weight(1f),
                ) { onSelect(tab.route) }
            }
        }
    }
}

@Composable
private fun NavPill(tab: Tab, selected: Boolean, badge: Int, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent,
        tween(280), label = "navBg")
    val fg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        tween(280), label = "navFg")
    val scale by animateFloatAsState(
        if (selected) 1.08f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 480f), label = "navScale")
    Box(
        modifier
            .padding(horizontal = 3.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable(remember { MutableInteractionSource() }, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick()
            }
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
                Icon(tab.icon, contentDescription = tab.label, tint = fg, modifier = Modifier.size(23.dp))
            }
            AnimatedVisibility(
                visible = selected,
                enter = expandHorizontally(tween(260)) + fadeIn(tween(300)),
                exit = shrinkHorizontally(tween(200)) + fadeOut(tween(140)),
            ) {
                Row {
                    Spacer(Modifier.width(6.dp))
                    Text(tab.label, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
                }
            }
            // بج نخوانده — کنار آیتم، بدون روی‌هم‌افتادگی با متن
            if (badge > 0) {
                Spacer(Modifier.width(4.dp))
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.error) {
                    Text(if (badge > 99) "+۹۹" else badge.fa(), color = MaterialTheme.colorScheme.onError,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                }
            }
        }
    }
}

@Composable
private fun StudyFloatingBar(modifier: Modifier = Modifier, onClick: () -> Unit) {
    var label by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            val pomo = Pomodoro.state.value
            label = when {
                pomo.running -> "پومودورو  " + clockMs(pomo.remainingSec)
                Chrono.running -> "کرنومتر  " + clockH((Chrono.elapsedMs() / 1000))
                else -> null
            }
            delay(1000)
        }
    }
    val haptic = LocalHapticFeedback.current
    AnimatedVisibility(visible = label != null, modifier = modifier) {
        Surface(shape = CircleShape, color = Color.Transparent, shadowElevation = 10.dp) {
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(brandGradient())
                    .clickable(remember { MutableInteractionSource() }, indication = null) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick()
                    }
                    .padding(horizontal = 18.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(9.dp).background(MaterialTheme.colorScheme.onPrimary, CircleShape))
                Spacer(Modifier.width(8.dp))
                Icon(AppIcons.Study, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(label ?: "", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

private fun clockMs(sec: Int): String = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60).fa()
private fun clockH(sec: Long): String = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60).fa()
