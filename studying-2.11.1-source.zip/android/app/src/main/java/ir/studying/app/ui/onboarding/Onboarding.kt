package ir.studying.app.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.ui.theme.readableAccent
import ir.studying.app.ui.theme.tintedSurface
import ir.studying.app.core.Goals
import ir.studying.app.ui.auth.AuthScreen
import ir.studying.app.ui.home.GoalChoiceGrid

private data class IntroPage(
    val icon: ImageVector,
    val eyebrow: String,
    val title: String,
    val text: String,
    val colors: List<Color>,
)

private val prePages = listOf(
    IntroPage(Icons.Rounded.AutoStories, "مطالعه، ساده‌تر از همیشه", "تمرکزت را پیدا کن", "کرنومتر و پومودورو، صدای محیط و ثبت خودکار زمان؛ همه در یک فضای آرام و زیبا.", listOf(Color(0xFF0F9B73), Color(0xFF38BDF8))),
    IntroPage(Icons.Rounded.Lock, "بدون حواس‌پرتی", "گوشی را برای هدفت قفل کن", "اپ‌های مزاحم را انتخاب کن، زمان بده و با خیال راحت درس بخوان. کنترل همیشه دست خودت می‌ماند.", listOf(Color(0xFF7C3AED), Color(0xFFEC4899))),
    IntroPage(Icons.Rounded.Groups, "کنار هم قوی‌تریم", "با دوست‌ها رقابت کن", "رقابت مطالعه بساز، وارد اتاق شو و پیشرفت خودت را زنده با بقیه مقایسه کن.", listOf(Color(0xFFF97316), Color(0xFFEAB308))),
)

private val guidePages = listOf(
    IntroPage(Icons.Rounded.PlayArrow, "قدم اول", "اولین پارت را شروع کن", "یک درس انتخاب کن و با کرنومتر یا پومودورو شروع کن. هر دقیقه مطالعه، یک سکه برای میز مطالعه‌ات می‌سازد.", listOf(Color(0xFF10B981), Color(0xFF22D3EE))),
    IntroPage(Icons.Rounded.Lock, "قدم دوم", "قفل تمرکز را آماده کن", "از آیکن قفل بالای خانه یا اتاق مطالعه وارد شو. اگر دسترسی لازم باشد، دکمه تو را مستقیم به همان تنظیمات می‌برد.", listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))),
    IntroPage(Icons.Rounded.TaskAlt, "قدم سوم", "درس و کارهایت را مرتب کن", "هدف روزانه، درس‌ها، تسک‌ها و فلش‌کارت‌ها را بچین تا هر بار دقیقاً بدانی قدم بعدی چیست.", listOf(Color(0xFF2563EB), Color(0xFF06B6D4))),
    IntroPage(Icons.Rounded.Insights, "قدم چهارم", "رشدت را ببین", "استریک، گزارش روزانه و نمودارها به تو نشان می‌دهند کجا عالی بودی و کجا می‌توانی بهتر شوی.", listOf(Color(0xFFF59E0B), Color(0xFFF43F5E))),
    IntroPage(Icons.Rounded.Groups, "قدم پنجم", "تنها درس نخوان", "دوست پیدا کن، حداکثر سه رقابت فعال بساز و جدیدترین رقابت را همیشه روی کارت اصلی خانه ببین.", listOf(Color(0xFF14B8A6), Color(0xFF6366F1))),
    IntroPage(Icons.Rounded.Notifications, "همه‌چیز آماده است", "حالا نوبت توست", "با یک پارت کوتاه شروع کن. استمرارهای کوچک، نتیجه‌های خیلی بزرگ می‌سازند.", listOf(Color(0xFF22C55E), Color(0xFF0EA5E9))),
)

@Composable
fun PreAuthOnboarding(onDone: () -> Unit) {
    var finished by remember { mutableIntStateOf(0) }
    if (finished == 1) {
        AuthScreen()
    } else {
        StoryPager(
            pages = prePages,
            finalLabel = "شروع و ساخت حساب",
            allowSkip = true,
            onDone = { onDone(); finished = 1 },
        )
    }
}

@Composable
fun NewUserGuide(onDone: () -> Unit) {
    /*
     * آخرین قدمِ ثبت‌نام: هدف روزانه.
     *
     * قبلاً اپ خودش دو ساعت را هدف کاربر فرض می‌کرد و کارت خانه و پست خودکار
     * روی همان عدد ساختگی کار می‌کردند. حالا همان‌جا که کاربر تازه آمده یک بار
     * می‌پرسیم؛ اگر رد کند، هدف «تنظیم‌نشده» می‌ماند و هیچ عددی جعل نمی‌شود.
     */
    var stage by remember { mutableIntStateOf(0) }
    if (stage == 0) {
        StoryPager(pages = guidePages, finalLabel = "آخرین قدم", allowSkip = true, onDone = { stage = 1 })
    } else {
        GoalSetupStep(onDone = onDone)
    }
}

/** پرسش هدف روزانه، یک‌بار و فقط برای کاربر تازه. */
@Composable
private fun GoalSetupStep(onDone: () -> Unit) {
    val current by Goals.daily.collectAsState()
    val colors = listOf(Color(0xFF10B981), Color(0xFF0EA5E9))

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(tintedSurface(colors.first(), 0.16f), MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.background),
            ),
        ),
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(.25f))
            Box(
                Modifier.size(150.dp).background(Brush.linearGradient(colors), RoundedCornerShape(44.dp)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.TaskAlt, null, tint = Color.White, modifier = Modifier.size(64.dp)) }
            Spacer(Modifier.height(18.dp))
            Text("هدف روزانه‌ات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text(
                "هر روز چقدر می‌خواهی بخوانی؟ بعداً هر وقت خواستی عوضش کن.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GoalChoiceGrid(current = current) { Goals.setDaily(it) }
            }
            Spacer(Modifier.weight(.55f))
            Button(
                onClick = onDone,
                enabled = current > 0,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(18.dp),
                /*
                 * contentColor حتماً باید کنار containerColor بیاید: با تم تیره
                 * رنگ پیش‌فرض متن دکمه (onPrimary) تقریباً سیاه است و روی این
                 * زمینه‌های پررنگ اصلاً خوانده نمی‌شد.
                 */
                colors = ButtonDefaults.buttonColors(
                    containerColor = colors.first(),
                    contentColor = Color.White,
                    disabledContainerColor = colors.first().copy(alpha = 0.35f),
                    disabledContentColor = Color.White.copy(alpha = 0.65f),
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
            ) {
                Text(
                    if (current > 0) "ثبت هدف و شروع" else "یک عدد انتخاب کن",
                    fontWeight = FontWeight.Bold,
                )
            }
            TextButton(onClick = onDone, modifier = Modifier.padding(top = 3.dp)) { Text("بعداً تعیین می‌کنم") }
        }
    }
}

@Composable
private fun StoryPager(pages: List<IntroPage>, finalLabel: String, allowSkip: Boolean, onDone: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val current = pages[page]
    val motion = rememberInfiniteTransition(label = "onboardingMotion")
    val float by motion.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float",
    )

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(tintedSurface(current.colors.first(), 0.16f), MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.background)),
        ),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(current.colors[0].copy(alpha = .08f), radius = size.minDimension * .42f, center = Offset(size.width * .82f, size.height * .18f))
            drawCircle(current.colors[1].copy(alpha = .07f), radius = size.minDimension * .30f, center = Offset(size.width * .12f, size.height * .72f))
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Studying", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                if (allowSkip && page < pages.lastIndex) TextButton(onClick = onDone) { Text("رد کردن") }
            }
            Spacer(Modifier.weight(.35f))
            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    (slideInHorizontally(tween(480, easing = FastOutSlowInEasing)) { it / 2 } + fadeIn(tween(360)))
                        .togetherWith(slideOutHorizontally(tween(360)) { -it / 3 } + fadeOut(tween(220)))
                },
                label = "introPage",
            ) { index ->
                val item = pages[index]
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.height(250.dp)) {
                        Box(
                            Modifier.size(190.dp).graphicsLayer { translationY = float }
                                .background(Brush.linearGradient(item.colors), RoundedCornerShape(52.dp)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Surface(shape = CircleShape, color = Color.White.copy(alpha = .18f), modifier = Modifier.size(112.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(58.dp))
                                }
                            }
                        }
                    }
                    Text(item.eyebrow, color = readableAccent(item.colors.first()), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(item.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(item.text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, lineHeight = 27.sp)
                }
            }
            Spacer(Modifier.weight(.65f))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 18.dp)) {
                pages.indices.forEach { i ->
                    Box(
                        Modifier.height(7.dp).size(width = if (i == page) 28.dp else 7.dp, height = 7.dp)
                            .background(if (i == page) current.colors.first() else MaterialTheme.colorScheme.outlineVariant, CircleShape)
                            .clickable { page = i },
                    )
                }
            }
            Button(
                onClick = { if (page == pages.lastIndex) onDone() else page += 1 },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = current.colors.first(),
                    contentColor = Color.White,
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
            ) { Text(if (page == pages.lastIndex) finalLabel else "بعدی", fontWeight = FontWeight.Bold) }
            if (page > 0) {
                TextButton(onClick = { page -= 1 }, modifier = Modifier.padding(top = 3.dp)) { Text("قبلی") }
            } else Spacer(Modifier.height(51.dp))
        }
    }
}
