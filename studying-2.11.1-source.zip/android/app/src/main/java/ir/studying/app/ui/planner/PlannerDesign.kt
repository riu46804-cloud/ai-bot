package ir.studying.app.ui.planner

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.studying.app.core.fa
import ir.studying.app.ui.theme.AppRadius

/* ======================================================================== */
/*  زبان بصری بخش برنامه‌ریز                                                */
/* ======================================================================== */

/*
 * چرا پالت جدا از تم اپ؟
 *
 * بقیهٔ اپ گزارش گذشته است (چقدر خواندی، استریک، رفقا) و رنگ برند سبزِ آرام
 * برایش درست است. برنامه‌ریز اما «تصمیم امروز» را نشان می‌دهد و باید حس
 * ابزارِ زنده بدهد، نه کارنامه. اینجا هر نوع فعالیت گرادیان دوتایی و آیکون
 * مخصوص خودش را دارد تا چشم بدون خواندن متن، ریتم روز را بفهمد: آبی یعنی
 * یادگیری تازه، بنفش یعنی تمرین، کهربایی یعنی مرور، قرمز یعنی سنجش.
 *
 * رنگ‌ها ثابت‌اند و از تم نمی‌آیند، چون معنی دارند؛ اگر با تم عوض شوند،
 * کاربری که تم را تغییر داده باید دوباره معنی رنگ‌ها را یاد بگیرد.
 */
data class PlannerTone(val from: Color, val to: Color, val icon: ImageVector, val label: String)

private val TONE_LEARN = PlannerTone(Color(0xFF60A5FA), Color(0xFF2563EB), Icons.Rounded.MenuBook, "یادگیری")
private val TONE_PRACTICE = PlannerTone(Color(0xFFA78BFA), Color(0xFF7C3AED), Icons.Rounded.EditNote, "تمرین")
private val TONE_REVIEW = PlannerTone(Color(0xFFFBBF24), Color(0xFFF97316), Icons.Rounded.Repeat, "مرور")
private val TONE_FIX = PlannerTone(Color(0xFFFB7185), Color(0xFFE11D48), Icons.Rounded.Psychology, "جبران")
private val TONE_TEST = PlannerTone(Color(0xFF34D399), Color(0xFF0D9488), Icons.Rounded.Quiz, "سنجش")
private val TONE_DRILL = PlannerTone(Color(0xFF38BDF8), Color(0xFF0EA5E9), Icons.Rounded.Timer, "زمان‌دار")

fun toneOf(type: String): PlannerTone = when (type) {
    "learn" -> TONE_LEARN
    "practice", "mixed_practice" -> TONE_PRACTICE
    "review", "concept_review", "flash_review", "weekly_review", "mock_analysis" -> TONE_REVIEW
    "reteach", "analyze_errors" -> TONE_FIX
    "weekly_test", "mock_exam", "test" -> TONE_TEST
    "timed_drill" -> TONE_DRILL
    else -> TONE_LEARN
}

fun PlannerTone.brush(): Brush = Brush.linearGradient(listOf(from, to))

/** گرادیان اصلی بخش: همان چیزی که روی کارت خانه و سربرگ می‌نشیند. */
val plannerBrand = listOf(Color(0xFF6366F1), Color(0xFF0EA5E9))

fun plannerBrandBrush(): Brush = Brush.linearGradient(plannerBrand)

/** رنگ خوانا روی پس‌زمینهٔ تیره/روشن تم. */
@Composable
fun onTone(tone: PlannerTone): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) tone.from else tone.to
}

/* ------------------------------------------------------------------ */
/*  پس‌زمینهٔ شفق                                                      */
/* ------------------------------------------------------------------ */

/**
 * لکه‌های نورِ آرام پشت محتوا.
 *
 * به‌جای بلور (که زیر اندروید ۱۲ اصلاً کار نمی‌کند و روی گوشی ضعیف فریم
 * می‌اندازد) از گرادیان شعاعی استفاده می‌شود: همان حس عمق، با هزینهٔ یک
 * drawCircle. حرکتشان خیلی کند است تا پس‌زمینه بماند و حواس را نبرد.
 */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier, intensity: Float = 1f) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "auroraP")
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val a1 = (if (dark) 0.26f else 0.17f) * intensity
    val a2 = (if (dark) 0.20f else 0.13f) * intensity
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sweep = kotlin.math.sin(p * 2 * Math.PI).toFloat()
        drawCircle(
            Brush.radialGradient(
                listOf(plannerBrand[0].copy(alpha = a1), Color.Transparent),
                center = Offset(w * (0.18f + 0.06f * sweep), h * 0.12f), radius = w * 0.62f,
            ),
            radius = w * 0.62f, center = Offset(w * (0.18f + 0.06f * sweep), h * 0.12f),
        )
        drawCircle(
            Brush.radialGradient(
                listOf(plannerBrand[1].copy(alpha = a2), Color.Transparent),
                center = Offset(w * (0.86f - 0.07f * sweep), h * 0.03f), radius = w * 0.55f,
            ),
            radius = w * 0.55f, center = Offset(w * (0.86f - 0.07f * sweep), h * 0.03f),
        )
    }
}

/* ------------------------------------------------------------------ */
/*  کارت شیشه‌ای                                                       */
/* ------------------------------------------------------------------ */

/**
 * کارت پایهٔ این بخش: نیمه‌شفاف با حاشیهٔ گرادیانی نازک.
 *
 * حاشیه عمداً از بالا-راست روشن و پایین-چپ محو است؛ همان ترفند قدیمی که به
 * سطح حس «شیشهٔ زیر نور» می‌دهد بدون اینکه کارت سنگین شود.
 */
@Composable
fun PlannerCard(
    modifier: Modifier = Modifier,
    accent: Color = MaterialTheme.colorScheme.primary,
    shape: Shape = AppRadius.card,
    padding: Dp = 16.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed && onClick != null) 0.978f else 1f,
        tween(140, easing = FastOutSlowInEasing), label = "cardPress",
    )
    androidx.compose.foundation.layout.Column(
        modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        if (dark) Color.White.copy(alpha = 0.075f) else Color.White.copy(alpha = 0.95f),
                        if (dark) accent.copy(alpha = 0.055f) else accent.copy(alpha = 0.045f),
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(accent.copy(alpha = if (dark) 0.42f else 0.30f), accent.copy(alpha = 0.06f)),
                ),
                shape,
            )
            .let { m ->
                if (onClick != null) m.clickable(interaction, indication = null, onClick = onClick) else m
            }
            .padding(padding),
        content = content,
    )
}

/* ------------------------------------------------------------------ */
/*  حلقهٔ پیشرفت                                                       */
/* ------------------------------------------------------------------ */

/**
 * حلقهٔ درصد با گرادیان چرخشی.
 *
 * نوار خطی برای «۷ از ۲۷ جلسه» بی‌روح بود و در سربرگ گم می‌شد. حلقه هم جای
 * کمتری می‌گیرد، هم وسطش عدد می‌نشیند، هم وقتی پر می‌شود واقعاً حس پیشرفت
 * می‌دهد. انیمیشن فقط یک‌بار و در ورود اجرا می‌شود، نه در هر بازترکیب.
 */
@Composable
fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    size: Dp = 78.dp,
    stroke: Dp = 9.dp,
    colors: List<Color> = plannerBrand,
    center: @Composable () -> Unit = {},
) {
    val animated by animateFloatAsState(
        progress.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "ring")
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val inset = w / 2
            drawArc(
                color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(this.size.width - w, this.size.height - w),
                style = Stroke(width = w, cap = StrokeCap.Round),
            )
            if (animated > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(colors.first(), colors.last(), colors.first())),
                    startAngle = -90f, sweepAngle = 360f * animated, useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = Size(this.size.width - w, this.size.height - w),
                    style = Stroke(width = w, cap = StrokeCap.Round),
                )
            }
        }
        center()
    }
}

/* ------------------------------------------------------------------ */
/*  ریزقطعه‌ها                                                         */
/* ------------------------------------------------------------------ */

/** تراشهٔ گرادیانی کوچک با آیکون — برچسب نوع جلسه. */
@Composable
fun ToneChip(tone: PlannerTone, text: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(tone.from.copy(alpha = 0.22f), tone.to.copy(alpha = 0.12f))))
            .padding(horizontal = 9.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        androidx.compose.material3.Icon(tone.icon, null, tint = onTone(tone), modifier = Modifier.size(12.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = onTone(tone), fontWeight = FontWeight.Medium)
    }
}

/** نشان دایره‌ای گرادیانی با آیکون — سر هر کارت جلسه. */
@Composable
fun ToneBadge(tone: PlannerTone, size: Dp = 38.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(tone.brush()),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Icon(
            tone.icon, null, tint = Color.White,
            modifier = Modifier.size(size * 0.45f),
        )
    }
}

/** نقطهٔ نبض — کنار «امروز» و آیتم‌های زنده. */
@Composable
fun PulseDot(color: Color, size: Dp = 7.dp) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0.35f, 1f,
        infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulseA")
    Box(Modifier.size(size).clip(CircleShape).background(color.copy(alpha = a)))
}

/** عدد فارسی با شمارش بالارونده — برای آمار سربرگ. */
@Composable
fun CountUpFa(target: Int, style: androidx.compose.ui.text.TextStyle, color: Color = Color.Unspecified) {
    val v by animateFloatAsState(target.toFloat(), tween(700, easing = FastOutSlowInEasing), label = "count")
    Text(v.toInt().fa(), style = style, color = color, fontWeight = FontWeight.Bold)
}

/** خط جداکنندهٔ محوشونده. */
@Composable
fun SoftDivider(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(Color.Transparent, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f), Color.Transparent)
                )
            )
    )
}

/** آیکون جرقه با درخشش آرام — نشانهٔ «این را هوش مصنوعی ساخته». */
@Composable
fun SparkleMark(size: Dp = 30.dp) {
    val t = rememberInfiniteTransition(label = "spark")
    val glow by t.animateFloat(0.55f, 1f,
        infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sparkGlow")
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(plannerBrand.map { it.copy(alpha = glow) })),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Icon(
            Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(size * 0.52f))
    }
}
