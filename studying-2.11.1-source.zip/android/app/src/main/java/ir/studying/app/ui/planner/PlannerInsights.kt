package ir.studying.app.ui.planner

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Fmt
import ir.studying.app.core.RetentionForecast
import ir.studying.app.core.fa
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.AppRadius
import ir.studying.app.ui.theme.AppSpace

/* ======================================================================== */
/*  تب مرور — ماندگاری، نمای هفتگی، خطاها، نقشهٔ مرور                        */
/* ======================================================================== */

/** پالت ثابت خطوط نمودار؛ از تم نمی‌آید چون باید در هر تم از هم تفکیک شوند. */
private val SERIES_COLORS = listOf(
    Color(0xFF60A5FA), Color(0xFFA78BFA), Color(0xFF34D399),
    Color(0xFFFBBF24), Color(0xFFFB7185), Color(0xFF22D3EE),
)

@Composable
fun PlannerReviewTab(s: PlannerViewModel.State, modifier: Modifier = Modifier) {
    val res = s.result ?: return
    val cs = MaterialTheme.colorScheme
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AppSpace.lg, end = AppSpace.lg, top = AppSpace.sm,
            bottom = AppSpace.xxl + LocalBottomBarPadding.current.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(AppSpace.md),
    ) {
        if (res.retention.series.isNotEmpty()) {
            item { PlannerSectionTitle("ماندگاری مطالب") }
            item { RetentionCard(res.retention) }
        }

        if (res.weekly.isNotEmpty()) {
            item { PlannerSectionTitle("نمای هفتگی") }
            items(res.weekly, key = { it.week }) { w ->
                PlannerCard(accent = plannerBrand[1]) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "${Fmt.jalaliShort(w.from)} تا ${Fmt.jalaliShort(w.to)}",
                            style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                        )
                        Spacer(Modifier.weight(1f))
                        Box(
                            Modifier.clip(CircleShape)
                                .background(plannerBrand[0].copy(alpha = 0.14f))
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                        ) {
                            Text("${w.taskCount.fa()} جلسه", style = MaterialTheme.typography.labelSmall,
                                color = plannerBrand[1])
                        }
                    }
                    Spacer(Modifier.height(AppSpace.md))
                    GradientBar(
                        ratio = if (w.capacityMinutes == 0) 0f else w.plannedMinutes.toFloat() / w.capacityMinutes,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${Fmt.minutes(w.plannedMinutes)} از ${Fmt.minutes(w.capacityMinutes)} وقت آزاد",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    )
                    if (w.topics.isNotEmpty()) {
                        Spacer(Modifier.height(AppSpace.sm))
                        Text(w.topics.take(5).joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        if (res.mistakes.isNotEmpty()) {
            item { PlannerSectionTitle("ریشهٔ خطاها") }
            items(res.mistakes, key = { it.labelFa }) { m ->
                PlannerCard(accent = Color(0xFFE11D48), padding = 14.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Color(0xFFFB7185), Color(0xFFE11D48)))),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(m.count.fa(), style = MaterialTheme.typography.labelMedium,
                                color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(AppSpace.md))
                        Column(Modifier.weight(1f)) {
                            Text(m.labelFa, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text("راهکار: ${m.actionFa}", style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        if (res.review.isNotEmpty()) {
            item { PlannerSectionTitle("نقشهٔ مرور") }
            items(res.review, key = { it.topicId }) { r ->
                PlannerCard(accent = plannerBrand[0], padding = 14.dp) {
                    Text(r.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    DateLine("یادگیری", r.learnDates, SERIES_COLORS[0])
                    DateLine("مرور", r.reviewDates, SERIES_COLORS[3])
                    DateLine("آزمون", r.testDates, SERIES_COLORS[2])
                    r.gapWarningFa?.let {
                        Spacer(Modifier.height(4.dp))
                        Text("⚠ $it", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE11D48))
                    }
                }
            }
        }

        if (res.retention.series.isEmpty() && res.review.isEmpty()) {
            item { EmptyState("📈", "هنوز داده‌ای برای تحلیل مرور نیست") }
        }
    }
}

@Composable
private fun GradientBar(ratio: Float) {
    val v by animateFloatAsState(ratio.coerceIn(0f, 1f), tween(700, easing = FastOutSlowInEasing), label = "bar")
    Box(
        Modifier.fillMaxWidth().height(8.dp).clip(CircleShape)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
    ) {
        Box(Modifier.fillMaxWidth(v).fillMaxHeight().clip(CircleShape).background(plannerBrandBrush()))
    }
}

@Composable
private fun DateLine(label: String, dates: List<String>, color: Color) {
    if (dates.isEmpty()) return
    Row(
        Modifier.padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Text(
            "$label: ${dates.joinToString("، ") { Fmt.jalaliShort(it) }}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * منحنی فراموشی.
 *
 * هر خط یک مبحث است و پرش‌های رو به بالا همان جلسه‌های مرورند. چرا نمودار و
 * نه جدول: افت تدریجی حافظه با عدد حس نمی‌شود ولی با شیب خط بلافاصله فهمیده
 * می‌شود — و همین حس است که دانش‌آموز را سر جلسهٔ مرور نگه می‌دارد.
 *
 * خط‌چین ۸۰٪ آستانه‌ای است که زیرش مرور لازم می‌شود؛ زیر همان خط یک سایهٔ
 * قرمز کم‌رنگ کشیده شده تا «منطقهٔ خطر» بدون توضیح فهمیده شود. خطوط با
 * انیمیشن از راست به چپ کشیده می‌شوند، هم‌جهت با خواندن فارسی.
 */
@Composable
private fun RetentionCard(f: RetentionForecast) {
    val cs = MaterialTheme.colorScheme
    val shown = f.series.take(6)
    var play by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { play = true }
    val draw by animateFloatAsState(
        if (play) 1f else 0f, tween(1100, easing = FastOutSlowInEasing), label = "drawCurve")

    PlannerCard(accent = plannerBrand[0]) {
        Canvas(Modifier.fillMaxWidth().height(176.dp)) {
            val n = f.dates.size
            if (n < 2) return@Canvas
            val stepX = size.width / (n - 1)
            fun y(v: Float) = size.height * (1f - v.coerceIn(0f, 1f))

            // منطقهٔ خطر زیر ۸۰٪
            drawRect(
                Brush.verticalGradient(
                    listOf(Color(0xFFE11D48).copy(alpha = 0.06f), Color(0xFFE11D48).copy(alpha = 0.012f))
                ),
                topLeft = Offset(0f, y(0.8f)),
                size = androidx.compose.ui.geometry.Size(size.width, size.height - y(0.8f)),
            )
            drawLine(
                cs.outlineVariant, Offset(0f, y(0.8f)), Offset(size.width, y(0.8f)),
                strokeWidth = 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(9f, 9f)),
            )

            val visible = size.width * draw
            shown.forEachIndexed { i, s ->
                val c = SERIES_COLORS[i % SERIES_COLORS.size]
                val path = Path()
                var started = false
                s.retention.forEachIndexed { x, v ->
                    if (v <= 0f) { started = false; return@forEachIndexed }
                    // RTL: اولین روز سمت راست نمودار می‌نشیند.
                    val px = size.width - x * stepX
                    val py = y(v)
                    if (!started) { path.moveTo(px, py); started = true } else path.lineTo(px, py)
                }
                clipRect(left = size.width - visible, top = 0f, right = size.width, bottom = size.height) {
                    drawPath(
                        path, c,
                        style = Stroke(width = 3.2f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
            }
        }
        Spacer(Modifier.height(AppSpace.md))
        shown.forEachIndexed { i, s ->
            Row(
                Modifier.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(SERIES_COLORS[i % SERIES_COLORS.size]))
                Text(s.title, style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.weight(1f), maxLines = 1)
                val low = s.endRetention < 0.8f
                Box(
                    Modifier.clip(CircleShape)
                        .background((if (low) Color(0xFFE11D48) else Color(0xFF10B981)).copy(alpha = 0.14f))
                        .padding(horizontal = 7.dp, vertical = 1.dp),
                ) {
                    Text(
                        "${(s.endRetention * 100).toInt().fa()}٪",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (low) Color(0xFFE11D48) else Color(0xFF059669),
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Spacer(Modifier.height(AppSpace.sm))
        SoftDivider()
        Spacer(Modifier.height(AppSpace.sm))
        Text(
            "عدد کنار هر مبحث، ماندگاری تخمینی آن در پایان دوره است. زیر ۸۰٪ یعنی قبل از آزمون یک مرور دیگر لازم دارد.",
            style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
        )
    }
}

/* ======================================================================== */
/*  تب کیفیت — چک‌لیست استانداردهای برنامه                                   */
/* ======================================================================== */

@Composable
fun PlannerQualityTab(s: PlannerViewModel.State, modifier: Modifier = Modifier) {
    val cl = s.result?.checklist
    if (cl == null) {
        EmptyState("✅", "چک‌لیستی برای این برنامه نیست")
        return
    }
    val cs = MaterialTheme.colorScheme
    val total = cl.total.coerceAtLeast(1)
    val good = cl.score >= total - 1

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AppSpace.lg, end = AppSpace.lg, top = AppSpace.sm,
            bottom = AppSpace.xxl + LocalBottomBarPadding.current.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(AppSpace.sm),
    ) {
        item {
            PlannerCard(accent = if (good) Color(0xFF10B981) else Color(0xFFF59E0B)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        cl.score.toFloat() / total,
                        size = 84.dp, stroke = 9.dp,
                        colors = if (good) listOf(Color(0xFF34D399), Color(0xFF059669))
                        else listOf(Color(0xFFFBBF24), Color(0xFFF97316)),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CountUpFa(cl.score * 100 / total, MaterialTheme.typography.titleLarge, cs.onSurface)
                            Text("٪", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.width(AppSpace.lg))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("کیفیت برنامه", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                        Text("${cl.score.fa()} از ${cl.total.fa()} معیار",
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (good) "برنامه همهٔ اصول را رعایت می‌کند."
                            else "چند معیار هنوز جا مانده‌اند؛ پایین را ببین.",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // گروه‌بندی همان گروه‌های موتور است؛ ترتیبشان معنی دارد (طراحی ← زمان‌بندی ← یادگیری ← اجرا).
        cl.items.groupBy { it.group }.forEach { (group, rows) ->
            item { PlannerSectionTitle(group) }
            items(rows, key = { it.labelFa }) { row ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(AppRadius.small)
                        .background(
                            if (row.ok) Color(0xFF10B981).copy(alpha = 0.06f)
                            else Color(0xFFF59E0B).copy(alpha = 0.07f)
                        )
                        .padding(horizontal = AppSpace.md, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
                ) {
                    Box(
                        Modifier.size(24.dp).clip(CircleShape)
                            .background(
                                if (row.ok) Brush.linearGradient(listOf(Color(0xFF34D399), Color(0xFF059669)))
                                else Brush.linearGradient(listOf(Color(0xFFFBBF24), Color(0xFFF97316)))
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            if (row.ok) Icons.Rounded.Check else Icons.Rounded.Close, null,
                            tint = Color.White, modifier = Modifier.size(13.dp),
                        )
                    }
                    Text(
                        row.labelFa, style = MaterialTheme.typography.bodyMedium,
                        color = if (row.ok) cs.onSurface else cs.onSurfaceVariant,
                    )
                }
            }
        }

        item {
            Text(
                "معیارهای نارنجی هنوز در برنامه پوشش داده نشده‌اند. با گزارش‌کردن نتیجهٔ جلسه‌ها و زدن «بازبرنامه‌ریزی»، دورهٔ بعد آن‌ها را جبران می‌کند.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                modifier = Modifier.padding(top = AppSpace.sm),
            )
        }
    }
}
