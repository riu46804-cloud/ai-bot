package ir.studying.app.ui.planner

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.studying.app.core.CurrBook
import ir.studying.app.core.CurrChapter
import ir.studying.app.core.CurrTrack
import ir.studying.app.core.ExamProvider
import ir.studying.app.core.TopicStatus
import ir.studying.app.core.fa
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.AppRadius
import ir.studying.app.ui.theme.AppSpace

/* ======================================================================== */
/*  آنبوردینگ: «تا کجا خوانده‌ای؟»                                          */
/* ======================================================================== */

/*
 * چرا این صفحه از همه‌چیز مهم‌تر است:
 *
 * موتور برنامه‌ریزی بدون دانستن وضعیت فعلی، ناچار است فرض کند هیچ‌چیز خوانده
 * نشده. نتیجه‌اش همان چیزی بود که دیده شد — برنامه‌ای که برای همه یکسان است و
 * از فصل اول شروع می‌کند، حتی برای کسی که وسط کتاب است.
 *
 * فهرست عمداً در سطح «فصل» باز می‌شود و نه مبحث: کسی حوصله ندارد ۴۰ تا مبحث
 * را تک‌تک علامت بزند. یک تپ روی فصل همهٔ مباحثش را علامت می‌زند و هر کس
 * بخواهد دقیق‌تر شود، فصل را باز می‌کند و تک‌تک را تنظیم می‌کند.
 */

@Composable
fun PlannerOnboarding(
    step: Int,
    tracks: List<CurrTrack>,
    selectedTrack: String?,
    selectedGrade: Int,
    graduate: Boolean,
    providers: List<ExamProvider>,
    selectedProvider: String?,
    books: List<CurrBook>,
    includedBooks: Set<String>,
    openBook: String?,
    loadingBook: String?,
    loading: Boolean,
    error: String?,
    selection: Map<String, TopicStatus>,
    sessionMinutes: Int,
    freeHours: Int,
    saving: Boolean,
    onRetry: () -> Unit,
    onSelectTrack: (String) -> Unit,
    onSelectGrade: (Int) -> Unit,
    onSelectGraduate: () -> Unit,
    onSelectProvider: (String) -> Unit,
    onToggleBook: (CurrBook) -> Unit,
    onToggleInclude: (String) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onStudiedUpTo: (CurrBook, CurrChapter) -> Unit,
    onSetTopic: (String, TopicStatus) -> Unit,
    onSetChapter: (CurrChapter, TopicStatus) -> Unit,
    onSessionMinutes: (Int) -> Unit,
    onFreeHours: (Int) -> Unit,
    onBackStep: () -> Unit,
    onNext: () -> Unit,
    onFinish: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    if (error != null && tracks.isEmpty() && books.isEmpty()) {
        ErrorState(error, modifier.fillMaxSize(), onRetry = onRetry)
        return
    }

    val marked = selection.count { it.value != TopicStatus.NOT_STARTED }

    Column(modifier.fillMaxSize()) {
        StepBar(step)

        if (loading && ((step == 0 && tracks.isEmpty()) || (step == 1 && providers.isEmpty()) || (step == 2 && books.isEmpty()))) {
            Column(Modifier.fillMaxWidth().weight(1f), Arrangement.Center, Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(Modifier.height(AppSpace.md))
                Text(
                    when (step) {
                        0 -> "دارم رشته‌ها را می‌گیرم…"
                        1 -> "دارم تقویم آزمون‌ها را می‌گیرم…"
                        else -> "دارم درس‌های رشته‌ات را می‌گیرم…"
                    },
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(
                    start = AppSpace.lg, end = AppSpace.lg, top = AppSpace.sm, bottom = AppSpace.lg,
                ),
                verticalArrangement = Arrangement.spacedBy(AppSpace.md),
            ) {
                when (step) {
                    /* ---------------- گام ۱: رشته و پایه ---------------- */
                    0 -> {
                        item {
                            PlannerCard(accent = plannerBrand[0]) {
                                Text("رشته‌ات چیست؟", style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold)
                                Text(
                                    "درس‌های هر رشته فرق دارد. با انتخاب رشته و پایه، دقیقاً همان کتاب‌هایی می‌آید که امسال داری.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                            }
                        }
                        items(tracks, key = { it.trackId }) { t ->
                            TrackRow(t, t.trackId == selectedTrack) { onSelectTrack(t.trackId) }
                        }
                        val grades = tracks.firstOrNull { it.trackId == selectedTrack }?.grades.orEmpty()
                        if (grades.isNotEmpty()) {
                            item { PlannerSectionTitle("پایه") }
                            item {
                                PlannerCard(accent = plannerBrand[1], padding = 14.dp) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
                                        grades.forEach { (n, title) ->
                                            GradeChip(title, !graduate && n == selectedGrade, Modifier.weight(1f)) { onSelectGrade(n) }
                                        }
                                    }
                                    Spacer(Modifier.height(AppSpace.sm))
                                    // فارغ‌التحصیل پایه ندارد ولی کنکور دارد؛ جدا گذاشتیم
                                    // تا کسی که مدرسه نمی‌رود مجبور نباشد «دوازدهم» بزند.
                                    GradeChip("فارغ‌التحصیلم", graduate, Modifier.fillMaxWidth()) { onSelectGraduate() }
                                    if (graduate || selectedGrade >= 12) {
                                        Spacer(Modifier.height(AppSpace.sm))
                                        Text(
                                            "کنکور از هر سه پایه سؤال می‌دهد، پس کتاب‌های دهم و یازدهم هم در گام بعد می‌آید.",
                                            style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }

                    /* ---------------- گام ۲: مؤسسهٔ آزمون ---------------- */
                    1 -> {
                        item {
                            PlannerCard(accent = plannerBrand[1]) {
                                Text("آزمون آزمایشی کجا می‌دهی؟", style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold)
                                Text(
                                    "تاریخ آزمون‌ها و سرفصل هر آزمون از تقویم همان مؤسسه خوانده می‌شود و برنامه طوری چیده می‌شود که هر مبحث قبل از آزمونش تمام شده باشد.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                            }
                        }
                        items(providers, key = { it.providerId }) { pr ->
                            ProviderRow(pr, pr.providerId == selectedProvider) { onSelectProvider(pr.providerId) }
                        }
                    }

                    /* ---------------- گام ۳: درس‌ها و مباحث ---------------- */
                    2 -> {
                        item {
                            PlannerCard(accent = plannerBrand[0]) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ProgressRing(
                                        (marked.toFloat() / books.sumOf { it.topicCount }.coerceAtLeast(1)),
                                        size = 62.dp, stroke = 7.dp,
                                    ) {
                                        Text(marked.fa(), style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.width(AppSpace.md))
                                    Column(Modifier.weight(1f)) {
                                        Text("کدام درس‌ها در برنامه باشد؟", style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold)
                                        Text(
                                            "تیکِ کنار هر درس یعنی آن درس در برنامه بیاید. با بازکردن درس هم می‌توانی فصل‌هایی را که خوانده‌ای علامت بزنی تا برنامه از فصل اول شروع نکند.",
                                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                        )
                                    }
                                }
                                Spacer(Modifier.height(AppSpace.md))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("${includedBooks.size.fa()} از ${books.size.fa()} درس انتخاب شده",
                                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                                        modifier = Modifier.weight(1f))
                                    val allOn = includedBooks.size == books.size && books.isNotEmpty()
                                    Text(
                                        if (allOn) "هیچ‌کدام" else "همه",
                                        Modifier
                                            .clip(CircleShape)
                                            .clickable { onSelectAll(!allOn) }
                                            .padding(horizontal = 12.dp, vertical = 6.dp),
                                        style = MaterialTheme.typography.labelMedium, color = plannerBrand[1],
                                    )
                                }
                            }
                        }
                        // کنکوری‌ها کتاب سه پایه دارند؛ بدون تیتر پایه فهرست گیج‌کننده می‌شود.
                        val groups = books.groupBy { it.gradeNumber }.toSortedMap()
                        groups.forEach { (g, list) ->
                            if (groups.size > 1) {
                                item(key = "g$g") { PlannerSectionTitle(list.firstOrNull()?.grade ?: "پایه ${g.fa()}") }
                            }
                            items(list, key = { it.bookId }) { b ->
                                BookRow(
                                    book = b,
                                    pick = true,
                                    open = false,
                                    loadingDetail = false,
                                    included = b.bookId in includedBooks,
                                    selection = selection,
                                    onToggleInclude = { onToggleInclude(b.bookId) },
                                    onToggle = { onToggleInclude(b.bookId) },
                                    onSetTopic = onSetTopic,
                                    onSetChapter = onSetChapter,
                                    onStudiedUpTo = { },
                                )
                            }
                        }
                    }

                    /* ---------------- گام ۴: تا کجا خوانده‌ای؟ ---------------- */
                    3 -> {
                        val mine = books.filter { it.bookId in includedBooks }
                        item {
                            PlannerCard(accent = plannerBrand[0]) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ProgressRing(
                                        marked.toFloat() / mine.sumOf { it.topicCount }.coerceAtLeast(1),
                                        size = 62.dp, stroke = 7.dp,
                                    ) {
                                        Text(marked.fa(), style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.width(AppSpace.md))
                                    Column(Modifier.weight(1f)) {
                                        Text("تا کجا خوانده‌ای؟", style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold)
                                        Text(
                                            "درس را باز کن و روی «تا اینجا خوانده‌ام» بزن. بدون این، برنامه فرض می‌کند هیچ‌چیز نخوانده‌ای و وقتت را روی چیزی می‌گذارد که بلدی.",
                                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                        items(mine, key = { it.bookId }) { b ->
                            BookRow(
                                book = b,
                                pick = false,
                                open = b.bookId == openBook,
                                loadingDetail = b.bookId == loadingBook,
                                included = true,
                                selection = selection,
                                onToggleInclude = { },
                                onToggle = { onToggleBook(b) },
                                onSetTopic = onSetTopic,
                                onSetChapter = onSetChapter,
                                onStudiedUpTo = { ch -> onStudiedUpTo(b, ch) },
                            )
                        }
                    }

                    /* ---------------- گام ۳: زمان ---------------- */
                    else -> {
                        item { PlannerSectionTitle("هر جلسه چند دقیقه؟") }
                        item {
                            PlannerCard(accent = plannerBrand[1], padding = 14.dp) {
                                Text(
                                    "طول جلسه‌ای که واقعاً می‌توانی بدون کَنده‌شدن ادامه بدهی. اگر مطمئن نیستی ۴۵ دقیقه انتخاب خوبی است.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                Spacer(Modifier.height(AppSpace.md))
                                Row(horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
                                    listOf(30, 45, 60, 90).forEach { m ->
                                        MinutesChip(m, m == sessionMinutes, Modifier.weight(1f)) { onSessionMinutes(m) }
                                    }
                                }
                            }
                        }
                        item { PlannerSectionTitle("روزی چند ساعت وقت داری؟") }
                        item {
                            PlannerCard(accent = plannerBrand[0], padding = 14.dp) {
                                Text(
                                    "مجموع ساعتی که در یک روز عادی می‌توانی درس بخوانی. برنامه دقیقاً در همین اندازه چیده می‌شود، نه بیشتر.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                Spacer(Modifier.height(AppSpace.md))
                                HoursSlider(freeHours, onFreeHours)
                            }
                        }
                        item {
                            PlannerCard(accent = plannerBrand[1], padding = 14.dp) {
                                Text("بعدش چه می‌شود؟", style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold)
                                Text(
                                    "همین که بزنی، برنامهٔ کاملت ساخته می‌شود — بدون هیچ سؤال دیگری. " +
                                        "زمان هر مبحث از بودجه‌بندی رسمی کتاب درسی می‌آید، نه از حدس. " +
                                        "اگر خواستی چیزی را عوض کنی، بعدش در تب «گفتگو» بگو.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }

        /* ---------------- نوار پایین ---------------- */
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = AppSpace.lg)
                .padding(bottom = AppSpace.md + LocalBottomBarPadding.current.calculateBottomPadding()),
        ) {
            SoftDivider()
            Spacer(Modifier.height(AppSpace.md))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (step > 0) {
                    Text(
                        "برگرد",
                        Modifier
                            .clip(CircleShape)
                            .clickable(enabled = !saving, onClick = onBackStep)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(AppSpace.sm))
                }
                val enabled = when (step) {
                    0 -> selectedTrack != null && (selectedGrade > 0 || graduate)
                    1 -> selectedProvider != null
                    // بدون حتی یک درس، برنامه‌ای برای ساختن نمی‌ماند.
                    2 -> includedBooks.isNotEmpty()
                    else -> true
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(CircleShape)
                        .background(if (enabled) plannerBrandBrush() else SolidColor(cs.surfaceVariant))
                        .clickable(enabled = enabled && !saving) { if (step == 4) onFinish() else onNext() }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (saving) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Text(
                            when (step) {
                                0, 1 -> "ادامه"
                                2 -> if (includedBooks.isEmpty()) "یک درس انتخاب کن"
                                    else "ثبت ${includedBooks.size.fa()} درس و ادامه"
                                3 -> if (marked == 0) "چیزی نخوانده‌ام، ادامه"
                                    else "ثبت ${marked.fa()} مبحث و ادامه"
                                else -> "برنامه‌ام را بساز"
                            },
                            color = if (enabled) Color.White else cs.onSurfaceVariant,
                            style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  نوار گام‌ها                                                        */
/* ------------------------------------------------------------------ */

@Composable
private fun StepBar(step: Int) {
    val cs = MaterialTheme.colorScheme
    val labels = listOf("رشته", "آزمون", "درس‌ها", "خوانده‌ها", "زمان")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = AppSpace.lg, vertical = AppSpace.sm),
        horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        labels.forEachIndexed { i, label ->
            val active = i <= step
            Column(Modifier.weight(1f)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(if (active) plannerBrandBrush() else SolidColor(cs.outlineVariant.copy(alpha = .5f)))
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    label, style = MaterialTheme.typography.labelSmall,
                    color = if (active) cs.onSurface else cs.onSurfaceVariant,
                    fontWeight = if (i == step) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  ردیف رشته و چیپ پایه                                               */
/* ------------------------------------------------------------------ */

@Composable
private fun TrackRow(track: CurrTrack, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(
                if (selected) plannerBrand[0].copy(alpha = if (dark) .14f else .09f)
                else if (dark) Color.White.copy(alpha = .04f) else Color.White.copy(alpha = .8f)
            )
            .border(1.dp,
                if (selected) plannerBrand[0].copy(alpha = .55f) else cs.outlineVariant.copy(alpha = .45f),
                AppRadius.small)
            .clickable(onClick = onClick)
            .padding(AppSpace.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BigCheck(selected, selected) { onClick() }
        Spacer(Modifier.width(AppSpace.md))
        Column(Modifier.weight(1f)) {
            Text(track.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text("${track.bookCount.fa()} کتاب در سه پایه",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
    }
}

/* ------------------------------------------------------------------ */
/*  ردیف مؤسسهٔ آزمون                                                  */
/* ------------------------------------------------------------------ */

@Composable
private fun ProviderRow(p: ExamProvider, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(
                if (selected) plannerBrand[1].copy(alpha = if (dark) .14f else .09f)
                else if (dark) Color.White.copy(alpha = .04f) else Color.White.copy(alpha = .8f)
            )
            .border(1.dp,
                if (selected) plannerBrand[1].copy(alpha = .55f) else cs.outlineVariant.copy(alpha = .45f),
                AppRadius.small)
            .clickable(enabled = p.available, onClick = onClick)
            .padding(AppSpace.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BigCheck(selected, selected) { if (p.available) onClick() }
        Spacer(Modifier.width(AppSpace.md))
        Column(Modifier.weight(1f)) {
            Text(
                p.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                color = if (p.available) cs.onSurface else cs.onSurfaceVariant,
            )
            p.noteFa?.let {
                Text(it, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
        // مؤسسه‌ای که تقویمش را نداریم حذف نمی‌شود، خاکستری می‌شود.
        if (!p.available) {
            Text(
                "به‌زودی",
                Modifier.clip(CircleShape).background(cs.onSurface.copy(alpha = .07f))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun GradeChip(title: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        if (selected) plannerBrand[1].copy(alpha = .18f) else cs.surfaceVariant.copy(alpha = .35f),
        label = "gchip",
    )
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(1.dp, if (selected) plannerBrand[1].copy(alpha = .55f) else Color.Transparent, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            title, style = MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) plannerBrand[1] else cs.onSurfaceVariant,
        )
    }
}

/* ------------------------------------------------------------------ */
/*  ردیف درس                                                           */
/* ------------------------------------------------------------------ */

/**
 * یک درس، که با تپ باز می‌شود و فصل‌هایش همان لحظه از سرور می‌آید.
 *
 * دلیل تنبل‌بودن بارگذاری: دیتاست رسمی ۸۱ کتاب دارد؛ کشیدن ساختار همه‌شان در
 * ورود، هم چند مگابایت است هم بی‌فایده — دانش‌آموز معمولاً سه چهار درس را
 * علامت می‌زند و بقیه را رد می‌کند.
 */
@Composable
private fun BookRow(
    book: CurrBook,
    /** حالت انتخاب درس (تیک) در برابر حالت ثبت پیشرفت (فصل‌ها). */
    pick: Boolean,
    open: Boolean,
    loadingDetail: Boolean,
    included: Boolean,
    selection: Map<String, TopicStatus>,
    onToggleInclude: () -> Unit,
    onToggle: () -> Unit,
    onSetTopic: (String, TopicStatus) -> Unit,
    onSetChapter: (CurrChapter, TopicStatus) -> Unit,
    onStudiedUpTo: (CurrChapter) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val arrow by animateFloatAsState(if (open) 180f else 0f, spring(), label = "bkArrow")
    val markedHere = book.allTopics.count { selection[it.topicId].let { st -> st != null && st != TopicStatus.NOT_STARTED } }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(
                if (included) plannerBrand[1].copy(alpha = if (dark) .12f else .08f)
                else if (dark) Color.White.copy(alpha = .04f) else Color.White.copy(alpha = .85f)
            )
            .border(1.dp,
                if (included) plannerBrand[1].copy(alpha = .5f) else cs.outlineVariant.copy(alpha = .45f),
                AppRadius.small),
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(AppSpace.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (pick) {
                // تیک = «این درس در برنامه باشد»
                BigCheck(included, included) { onToggleInclude() }
                Spacer(Modifier.width(AppSpace.md))
            }
            Column(Modifier.weight(1f)) {
                Text(book.subject, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    buildString {
                        append("${book.topicCount.fa()} مبحث")
                        if (book.studyMinutes > 0) append(" • ${(book.studyMinutes / 60).fa()} ساعت مطالعه")
                        if (markedHere > 0) append(" • ${markedHere.fa()} علامت‌خورده")
                    },
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
            if (book.isKonkur) {
                Text(
                    "کنکوری",
                    Modifier
                        .clip(CircleShape)
                        .background(plannerBrand[1].copy(alpha = .15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    style = MaterialTheme.typography.labelSmall, color = plannerBrand[1],
                )
                Spacer(Modifier.width(AppSpace.sm))
            }
            if (loadingDetail) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            } else if (!pick) {
                Icon(Icons.Rounded.ExpandMore, null, tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(20.dp).rotate(arrow))
            }
        }

        AnimatedVisibility(open && book.loaded, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Column(
                Modifier.padding(start = AppSpace.md, end = AppSpace.md, bottom = AppSpace.md),
                verticalArrangement = Arrangement.spacedBy(AppSpace.sm),
            ) {
                book.chapters.forEach { ch ->
                    ChapterRow(
                        chapter = ch,
                        selection = selection,
                        onSetTopic = onSetTopic,
                        onSetChapter = { st -> onSetChapter(ch, st) },
                        onStudiedUpTo = { onStudiedUpTo(ch) },
                    )
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  ردیف فصل                                                           */
/* ------------------------------------------------------------------ */

@Composable
private fun ChapterRow(
    chapter: CurrChapter,
    selection: Map<String, TopicStatus>,
    onSetTopic: (String, TopicStatus) -> Unit,
    onSetChapter: (TopicStatus) -> Unit,
    onStudiedUpTo: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    var open by remember { mutableStateOf(false) }
    val arrow by animateFloatAsState(if (open) 180f else 0f, spring(), label = "chArrow")

    val states = chapter.topics.map { selection[it.topicId] ?: TopicStatus.NOT_STARTED }
    val doneAll = states.isNotEmpty() && states.all { it != TopicStatus.NOT_STARTED }
    val doneSome = states.any { it != TopicStatus.NOT_STARTED }
    val ratio = if (states.isEmpty()) 0f else states.count { it != TopicStatus.NOT_STARTED }.toFloat() / states.size

    Column(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(
                if (doneSome) plannerBrand[0].copy(alpha = if (dark) 0.10f else 0.07f)
                else if (dark) Color.White.copy(alpha = 0.04f) else Color.White.copy(alpha = 0.8f)
            )
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.45f), AppRadius.small),
    ) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(AppSpace.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // تیک فصل: کل مباحثش را یک‌جا «خوانده‌ام» یا «نخوانده‌ام» می‌کند.
            BigCheck(doneAll, doneSome) {
                onSetChapter(if (doneAll) TopicStatus.NOT_STARTED else TopicStatus.STUDIED)
            }
            Spacer(Modifier.width(AppSpace.md))
            Column(Modifier.weight(1f)) {
                Text(chapter.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "${chapter.topics.size.fa()} مبحث" +
                        if (doneSome && !doneAll) " • ${(ratio * 100).toInt().fa()}٪ علامت خورده" else "",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
            // میان‌بر واقعی: «تا اینجا خوانده‌ام» همهٔ فصل‌های قبلی را هم علامت می‌زند
            Text(
                "تا اینجا",
                Modifier
                    .clip(CircleShape)
                    .background(plannerBrand[1].copy(alpha = .15f))
                    .clickable(onClick = onStudiedUpTo)
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                style = MaterialTheme.typography.labelSmall, color = plannerBrand[1],
            )
            Spacer(Modifier.width(AppSpace.sm))
            Icon(Icons.Rounded.ExpandMore, null, tint = cs.onSurfaceVariant,
                modifier = Modifier.size(20.dp).rotate(arrow))
        }

        AnimatedVisibility(open, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Column(Modifier.padding(start = AppSpace.md, end = AppSpace.md, bottom = AppSpace.md)) {
                SoftDivider()
                Spacer(Modifier.height(AppSpace.sm))
                chapter.topics.forEach { t ->
                    val st = selection[t.topicId] ?: TopicStatus.NOT_STARTED
                    Column(Modifier.padding(vertical = 5.dp)) {
                        Text(t.title, style = MaterialTheme.typography.bodySmall)
                        // زیرمبحث‌ها و زمان رسمی، تا کاربر بداند دقیقاً چه چیزی را علامت می‌زند
                        val meta = buildString {
                            t.timeFa?.let { append(it) }
                            if (t.suggestedTests > 0) {
                                if (isNotEmpty()) append(" • ")
                                append("${t.suggestedTests.fa()} تست")
                            }
                            if (t.subtopics.isNotEmpty()) {
                                if (isNotEmpty()) append(" • ")
                                append(t.subtopics.take(3).joinToString("، "))
                            }
                        }
                        if (meta.isNotBlank()) {
                            Text(meta, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(5.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            TopicStatus.entries.forEach { opt ->
                                StatusChip(opt, opt == st, Modifier.weight(1f)) { onSetTopic(t.topicId, opt) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BigCheck(all: Boolean, some: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        if (all) plannerBrand[1] else Color.Transparent, tween(180), label = "checkBg")
    Box(
        Modifier
            .size(26.dp)
            .clip(CircleShape)
            .background(bg)
            .border(1.5.dp, if (all) Color.Transparent else cs.outlineVariant, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        when {
            all -> Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
            // نیمه‌پر: بعضی مباحث علامت خورده‌اند، نه همه.
            some -> Box(Modifier.size(10.dp).clip(CircleShape).background(plannerBrand[1]))
        }
    }
}

@Composable
private fun StatusChip(status: TopicStatus, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scale by animateFloatAsState(if (active) 1f else 0.97f, spring(dampingRatio = 0.6f), label = "stChip")
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(
                if (active) plannerBrandBrush()
                else androidx.compose.ui.graphics.SolidColor(cs.onSurface.copy(alpha = 0.05f))
            )
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            status.labelFa,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) Color.White else cs.onSurfaceVariant,
            maxLines = 1,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * ساعت مطالعهٔ روزانه با لغزنده.
 *
 * تراشه‌های ثابت ۱/۲/۳/۴/۶ ساعت برای دانش‌آموز کنکوری بی‌معنی بود: کسی که
 * تابستان روزی ۱۰ ساعت می‌خواند مجبور می‌شد ۶ را انتخاب کند و بعد شاکی
 * می‌شد که برنامه کم است. بازه تا ۱۵ ساعت باز شده و قدم ۰٫۵ ساعت است.
 */
@Composable
private fun HoursSlider(hours: Int, onChange: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            hours.fa() + " ساعت",
            Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(plannerBrand[0].copy(alpha = .16f))
                .padding(horizontal = 12.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold, color = plannerBrand[0],
        )
        Spacer(Modifier.width(AppSpace.md))
        Slider(
            value = hours.coerceIn(1, 15).toFloat(),
            onValueChange = { onChange(it.toInt().coerceIn(1, 15)) },
            valueRange = 1f..15f,
            steps = 13,                                  // ۱ تا ۱۵ با قدم ۱ ساعت
            modifier = Modifier.weight(1f),
        )
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("۱ ساعت", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        Text("۱۵ ساعت", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
    if (hours >= 10) {
        Spacer(Modifier.height(6.dp))
        Text(
            "روزی " + hours.fa() + " ساعت فقط وقتی جواب می‌دهد که واقعاً همین‌قدر وقت آزاد داشته باشی؛ " +
                "برنامه دقیقاً به همین اندازه پر می‌شود.",
            style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
        )
    }
}

@Suppress("unused")
@Composable
private fun HoursChip(
    hours: Int,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        if (selected) plannerBrand[0].copy(alpha = .18f) else cs.surfaceVariant.copy(alpha = .35f),
        label = "hchip",
    )
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(
                1.dp,
                if (selected) plannerBrand[0].copy(alpha = .55f) else Color.Transparent,
                RoundedCornerShape(14.dp),
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            hours.fa() + " ساعت",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) plannerBrand[0] else cs.onSurfaceVariant,
        )
    }
}

@Composable
private fun MinutesChip(minutes: Int, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .clip(CircleShape)
            .background(
                if (active) plannerBrandBrush()
                else androidx.compose.ui.graphics.SolidColor(cs.onSurface.copy(alpha = 0.06f))
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "${minutes.fa()}′",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            color = if (active) Color.White else cs.onSurface,
        )
    }
}
