package ir.studying.app.ui.planner

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Fmt
import ir.studying.app.core.IranTime
import ir.studying.app.core.PlanBreak
import ir.studying.app.core.PlanDay
import ir.studying.app.core.PlanTask
import ir.studying.app.core.fa
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.AppRadius
import ir.studying.app.ui.theme.AppSpace

/* ======================================================================== */
/*  تب برنامه — تقویم روز و ساختار جلسه                                     */
/* ======================================================================== */

@Composable
fun PlannerPlanTab(s: PlannerViewModel.State, vm: PlannerViewModel, modifier: Modifier = Modifier) {
    val plan = s.plan ?: return
    val day = s.day
    val dayIndex = s.days.indexOfFirst { it.date == day?.date }.coerceAtLeast(0)
    val rowState = rememberLazyListState()
    LaunchedEffect(dayIndex) { rowState.animateScrollToItem(dayIndex.coerceAtLeast(0)) }
    val today = remember { IranTime.todayIso() }
    // نمای پیش‌فرض «کل دوره» است: شکایت اصلی این بود که برنامه فقط روزبه‌روز
    // دیده می‌شد و تصویر کلی دوره هیچ‌وقت جلوی چشم نمی‌آمد.
    var tableMode by rememberSaveable { mutableStateOf(true) }

    Column(modifier.fillMaxSize()) {
        ViewModeSwitch(tableMode) { tableMode = it }
        if (tableMode) {
            PlanTable(s, onOpenDay = { date -> vm.selectDate(date); tableMode = false })
            return@Column
        }
        LazyRow(
            state = rowState,
            contentPadding = PaddingValues(horizontal = AppSpace.lg, vertical = AppSpace.xs),
            horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
        ) {
            items(s.days, key = { it.date }) { d ->
                DayChip(
                    d = d,
                    selected = d.date == day?.date,
                    isToday = d.date == today,
                    doneRatio = doneRatio(s, d),
                ) { vm.selectDate(d.date) }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(
                start = AppSpace.lg, end = AppSpace.lg, top = AppSpace.sm,
                bottom = AppSpace.xxl + LocalBottomBarPadding.current.calculateBottomPadding(),
            ),
            verticalArrangement = Arrangement.spacedBy(AppSpace.md),
        ) {
            // آزمونِ هدف اولین چیزی است که باید دیده شود؛ برنامه برای آن چیده شده.
            s.result?.let { r ->
                if (r.examTarget != null || !r.strategyFa.isNullOrBlank()) {
                    item { ExamTargetCard(r.examTarget, r.strategyFa, r.notesFa, r.plannerBy) }
                }
            }
            item { PlanHeaderCard(s) }

            if (day == null || day.tasks.isEmpty()) {
                item {
                    EmptyState(
                        "🌴",
                        if (day?.isBlocked == true) "این روز را خالی گذاشتی" else "برای این روز جلسه‌ای تنظیم نشده",
                    )
                }
            } else {
                item { DayHeader(day) }
                // جلسه‌ها و استراحت‌ها در یک ستون زمانی درهم می‌آیند تا روزِ واقعی دیده شود،
                // نه فهرستی از کارها که انگار پشت سر هم و بی‌وقفه انجام می‌شوند.
                items(timelineOf(day), key = { it.key }) { e ->
                    when (e) {
                        is TimelineEntry.Session -> TaskCard(
                            task = e.task,
                            done = s.reports[e.task.taskId]?.completed == true,
                            onToggle = { vm.toggleDone(e.task) },
                        )
                        is TimelineEntry.Rest -> BreakRow(e.rest)
                    }
                }
            }

            if (plan.backlog.isNotEmpty()) {
                item { PlannerSectionTitle("منتقل‌شده به دوره‌ی بعد", plan.backlog.size) }
                items(plan.backlog, key = { "b-" + it.taskId }) { t -> BacklogRow(t) }
            }
        }
    }
}

/** کلید نمای «کل دوره» / «یک روز». */
@Composable
private fun ViewModeSwitch(table: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Row(
        Modifier
            .padding(horizontal = AppSpace.lg, vertical = AppSpace.xs)
            .clip(CircleShape)
            .background(if (dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.7f))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        listOf(true to "کل دوره", false to "یک روز").forEach { (v, label) ->
            val on = v == table
            Text(
                label,
                Modifier
                    .clip(CircleShape)
                    .background(if (on) plannerBrandBrush() else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { onChange(v) }
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                color = if (on) Color.White else cs.onSurfaceVariant,
            )
        }
    }
}

/**
 * کارت آزمون هدف.
 *
 * بدون این، کاربر نمی‌فهمد چرا این مباحث انتخاب شده‌اند و برنامه بی‌ربط به
 * نظر می‌رسد — همان شکایتی که داشتیم.
 */
@Composable
private fun ExamTargetCard(
    ex: ir.studying.app.core.ExamTarget?,
    strategy: String?,
    notes: List<String>,
    plannerBy: String?,
) {
    val cs = MaterialTheme.colorScheme
    PlannerCard(accent = plannerBrand[1]) {
        if (ex != null) {
            val left = IranTime.daysUntil(ex.dateIso)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("هدف این دوره: آزمون ${ex.dateFa}",
                        style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    if (ex.milestoneFa.isNotBlank()) {
                        Text(ex.milestoneFa, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                }
                if (left >= 0) {
                    Text(
                        if (left == 0) "امروز" else "${left.fa()} روز مانده",
                        Modifier.clip(CircleShape).background(plannerBrand[1].copy(alpha = .15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium, color = plannerBrand[1],
                    )
                }
            }
            Spacer(Modifier.height(AppSpace.sm))
        }
        if (!strategy.isNullOrBlank()) {
            Text(strategy, style = MaterialTheme.typography.bodySmall)
        }
        notes.forEach {
            Spacer(Modifier.height(4.dp))
            Text("• $it", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
        if (plannerBy == "rules") {
            // صادق باشیم: اگر مدل در دسترس نبود، کاربر باید بداند این برنامه
            // نسخهٔ پشتیبان است نه چیزی که برایش نوشته شده.
            Spacer(Modifier.height(AppSpace.sm))
            Text("این برنامه را موتور پشتیبان چیده؛ هوش مصنوعی در دسترس نبود.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
    }
}

/** یک ردیف از ستون زمانی روز: یا جلسه است یا استراحت. */
private sealed interface TimelineEntry {
    val at: String
    val key: String
    data class Session(val task: PlanTask) : TimelineEntry {
        override val at get() = task.startTime
        override val key get() = "t-" + task.taskId
    }
    data class Rest(val rest: PlanBreak) : TimelineEntry {
        override val at get() = rest.startTime
        override val key get() = "r-" + rest.startTime
    }
}

private fun timelineOf(d: PlanDay): List<TimelineEntry> =
    (d.tasks.map { TimelineEntry.Session(it) } + d.breaks.map { TimelineEntry.Rest(it) })
        .sortedBy { it.at }

private fun doneRatio(s: PlannerViewModel.State, d: PlanDay): Float {
    val total = d.tasks.size
    if (total == 0) return 0f
    return d.tasks.count { s.reports[it.taskId]?.completed == true }.toFloat() / total
}

/* ------------------------------------------------------------------ */
/*  تراشهٔ روز                                                         */
/* ------------------------------------------------------------------ */

/**
 * تراشهٔ روز با حلقهٔ پیشرفت کوچک.
 *
 * نسخهٔ اول فقط تاریخ و تعداد جلسه را نشان می‌داد، که یعنی برای فهمیدن «کدام
 * روز را عقبم» باید تک‌تک روزها را باز می‌کردی. حلقه همان اطلاعات را بدون تپ
 * می‌دهد و نقطهٔ نبض، «امروز» را از بقیه جدا می‌کند.
 */
@Composable
private fun DayChip(d: PlanDay, selected: Boolean, isToday: Boolean, doneRatio: Float, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val haptic = LocalHapticFeedback.current
    val lift by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.65f), label = "chipLift")

    Box(
        Modifier
            .width(80.dp)
            .graphicsLayer { scaleX = 1f + 0.04f * lift; scaleY = 1f + 0.04f * lift }
            .clip(AppRadius.small)
            .background(
                if (selected) plannerBrandBrush()
                else Brush.verticalGradient(listOf(
                    if (dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.85f),
                    if (dark) Color.White.copy(alpha = 0.03f) else Color.White.copy(alpha = 0.6f),
                ))
            )
            .border(
                1.dp,
                if (selected) Color.Transparent else cs.outlineVariant.copy(alpha = 0.45f),
                AppRadius.small,
            )
            .clickable {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(vertical = 9.dp, horizontal = 6.dp),
    ) {
        val fg = if (selected) Color.White else cs.onSurface
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (isToday) PulseDot(if (selected) Color.White else plannerBrand[1], 6.dp)
                Text(weekdayFa(d.weekday), style = MaterialTheme.typography.labelSmall,
                    color = fg.copy(alpha = 0.78f), maxLines = 1)
            }
            Text(Fmt.jalaliShort(d.date), style = MaterialTheme.typography.labelMedium,
                color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(6.dp))
            if (d.tasks.isEmpty()) {
                Text("—", style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.55f))
            } else {
                ProgressRing(
                    progress = doneRatio,
                    size = 30.dp,
                    stroke = 3.5.dp,
                    colors = if (selected) listOf(Color.White, Color.White) else plannerBrand,
                ) {
                    Text(d.tasks.size.fa(), style = MaterialTheme.typography.labelSmall,
                        color = fg, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun weekdayFa(w: String): String = when (w.lowercase().take(3)) {
    "sat" -> "شنبه"; "sun" -> "یکشنبه"; "mon" -> "دوشنبه"; "tue" -> "سه‌شنبه"
    "wed" -> "چهارشنبه"; "thu" -> "پنجشنبه"; "fri" -> "جمعه"; else -> w
}

/* ------------------------------------------------------------------ */
/*  سرصفحه‌ها                                                          */
/* ------------------------------------------------------------------ */

@Composable
fun PlannerSectionTitle(title: String, count: Int? = null) {
    Row(
        Modifier.fillMaxWidth().padding(top = AppSpace.sm),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
    ) {
        Box(Modifier.size(width = 4.dp, height = 16.dp).clip(CircleShape).background(plannerBrandBrush()))
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        if (count != null) {
            Box(
                Modifier.clip(CircleShape)
                    .background(plannerBrand[0].copy(alpha = 0.16f))
                    .padding(horizontal = 7.dp, vertical = 1.dp),
            ) {
                Text(count.fa(), style = MaterialTheme.typography.labelSmall, color = plannerBrand[1])
            }
        }
    }
}

@Composable
private fun PlanHeaderCard(s: PlannerViewModel.State) {
    val plan = s.plan ?: return
    val cs = MaterialTheme.colorScheme
    val done = s.doneCount
    val total = plan.totals.taskCount.coerceAtLeast(1)
    PlannerCard(accent = plannerBrand[0]) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(done.toFloat() / total, size = 72.dp, stroke = 8.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CountUpFa(done * 100 / total, MaterialTheme.typography.titleMedium, cs.onSurface)
                    Text("٪", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.width(AppSpace.lg))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("پیشرفت دوره", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                Text("${done.fa()} از ${plan.totals.taskCount.fa()} جلسه",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
                    MiniStat("زمان کل", Fmt.minutes(plan.totals.plannedMinutes))
                    MiniStat("ظرفیت", "${(plan.totals.utilization * 100).toInt().fa()}٪")
                }
            }
        }
        if (plan.capacityNoteFa.isNotBlank()) {
            Spacer(Modifier.height(AppSpace.md))
            SoftDivider()
            Spacer(Modifier.height(AppSpace.sm))
            Text(plan.capacityNoteFa, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (s.replanNotes.isNotEmpty()) {
            Spacer(Modifier.height(AppSpace.sm))
            s.replanNotes.forEach {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("◆", style = MaterialTheme.typography.labelSmall, color = plannerBrand[1])
                    Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurface)
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.labelMedium, color = cs.onSurface, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DayHeader(d: PlanDay) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
            Text(
                "${weekdayFa(d.weekday)} ${Fmt.jalaliShort(d.date)}",
                style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
            )
            if (d.isLowEnergy) {
                Box(
                    Modifier.clip(CircleShape)
                        .background(Color(0xFFF59E0B).copy(alpha = 0.16f))
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                ) {
                    Text("روز کم‌انرژی", style = MaterialTheme.typography.labelSmall, color = Color(0xFFD97706))
                }
            }
            Spacer(Modifier.weight(1f))
            Text("${Fmt.minutes(d.plannedMinutes)} / ${Fmt.minutes(d.capacityMinutes)}",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
        if (d.capacityNoteFa.isNotBlank()) {
            Text(d.capacityNoteFa, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}

/* ------------------------------------------------------------------ */
/*  استراحت                                                            */
/* ------------------------------------------------------------------ */

@Composable
private fun BreakRow(b: PlanBreak) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
    ) {
        Text(b.startTime, style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant, modifier = Modifier.width(44.dp))
        // خط‌چین عمودی کوتاه: نشان می‌دهد زمان ادامه دارد ولی کاری در جریان نیست.
        Box(
            Modifier.width(2.dp).height(20.dp).clip(CircleShape)
                .background(cs.outlineVariant.copy(alpha = 0.7f))
        )
        Icon(Icons.Rounded.LocalCafe, null, tint = cs.onSurfaceVariant.copy(alpha = 0.75f),
            modifier = Modifier.size(15.dp))
        Text("${b.labelFa} • ${b.minutes.fa()} دقیقه",
            style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

/* ------------------------------------------------------------------ */
/*  کارت جلسه                                                          */
/* ------------------------------------------------------------------ */

/*
 * چرا کارت تا این حد باز می‌شود: یک «۴۵ دقیقه شیمی فصل ۲» هیچ‌کس را سر درس
 * نمی‌نشاند. چیزی که کار می‌کند این است که دانش‌آموز بداند دقیقاً کدام صفحه،
 * کدام زیرمبحث، در چه فازهایی، و با چه معیاری تمام‌شده حساب می‌شود. همهٔ این
 * داده‌ها را موتور می‌فرستد؛ وظیفهٔ این کارت فقط خواناکردنشان است.
 *
 * جزئیات پیش‌فرض بسته است، چون در حالت «نگاه سریع به روز» فقط شلوغی می‌کند.
 */
@Composable
private fun TaskCard(task: PlanTask, done: Boolean, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val tone = toneOf(task.type)
    val accent = onTone(tone)
    var open by remember { mutableStateOf(false) }
    val arrow by animateFloatAsState(if (open) 180f else 0f, spring(), label = "arrow")
    val fade by animateFloatAsState(if (done) 0.5f else 1f, tween(220), label = "doneFade")

    Column(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.card)
            .background(
                if (done) Brush.linearGradient(listOf(
                    cs.onSurface.copy(alpha = 0.04f), cs.onSurface.copy(alpha = 0.02f)))
                else Brush.linearGradient(listOf(
                    if (dark) tone.from.copy(alpha = 0.13f) else tone.from.copy(alpha = 0.10f),
                    if (dark) Color.White.copy(alpha = 0.035f) else Color.White.copy(alpha = 0.82f),
                ))
            )
            .border(
                1.dp,
                Brush.verticalGradient(listOf(
                    tone.from.copy(alpha = if (done) 0.12f else 0.38f),
                    tone.to.copy(alpha = if (done) 0.05f else 0.12f),
                )),
                AppRadius.card,
            )
            // ریل رنگی لبهٔ شروع کارت (در RTL سمت راست): ردیف‌های یک روز با یک
            // نگاه دسته‌بندی می‌شوند. با drawBehind کشیده می‌شود نه با یک Box
            // کناری، چون ارتفاع کارت وابسته به باز/بستهٔ جزئیات است و هیچ
            // اندازه‌گیری ذاتی لازم نمی‌شود.
            .drawBehind {
                val w = 4.dp.toPx()
                drawRect(
                    brush = Brush.verticalGradient(listOf(tone.from, tone.to)),
                    topLeft = androidx.compose.ui.geometry.Offset(size.width - w, 0f),
                    size = androidx.compose.ui.geometry.Size(w, size.height),
                )
            },
    ) {
        Column(Modifier.padding(start = 14.dp, end = 16.dp, top = 13.dp, bottom = 11.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
                Column(Modifier.width(46.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(task.startTime, style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold, color = accent)
                    Text(task.endTime, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.height(5.dp))
                    ToneBadge(tone, 30.dp)
                }
                Column(Modifier.weight(1f).alpha(fade)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        ToneChip(tone, task.typeFa)
                        if (task.minRequired) RequiredChip()
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        task.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                    )
                    val sub = listOfNotNull(
                        task.subject.takeIf { it.isNotBlank() },
                        task.chapterTitle,
                    ).joinToString(" • ")
                    if (sub.isNotBlank()) {
                        Text(sub, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MetaPill("${task.durationMinutes.fa()} دقیقه", accent)
                        task.pages?.labelFa?.let { MetaPill(it, cs.onSurfaceVariant) }
                        if (task.split) MetaPill("بخش‌بندی‌شده", cs.onSurfaceVariant)
                    }
                }
                DoneButton(done, tone, onToggle)
            }

            Row(
                Modifier.fillMaxWidth().clickable { open = !open }.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (open) "بستن جزئیات" else "ساختار جلسه و معیار پایان",
                    style = MaterialTheme.typography.labelSmall, color = accent, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Rounded.ExpandMore, null, tint = accent,
                    modifier = Modifier.size(18.dp).rotate(arrow))
            }

            AnimatedVisibility(open, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Column(Modifier.padding(top = AppSpace.sm), verticalArrangement = Arrangement.spacedBy(AppSpace.md)) {
                    SoftDivider()
                    if (task.focusFa.isNotBlank() && task.focusFa != task.title) {
                        DetailBlock("تمرکز این جلسه", task.focusFa, accent)
                    }
                    if (task.subtopics.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("زیرمبحث‌ها", style = MaterialTheme.typography.labelMedium,
                                color = accent, fontWeight = FontWeight.Bold)
                            task.subtopics.forEach {
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Box(Modifier.padding(top = 7.dp).size(4.dp).clip(CircleShape)
                                        .background(tone.to.copy(alpha = 0.7f)))
                                    Text(it, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    if (task.phases.isNotEmpty()) PhaseStrip(task, tone, accent)
                    task.criteria?.takeIf { it.textFa.isNotBlank() }?.let {
                        DetailBlock("کِی تمام‌شده حساب می‌شود", it.textFa, accent, Icons.Rounded.Flag)
                    }
                    if (task.watchOutFa.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Icon(Icons.Rounded.WarningAmber, null, tint = Color(0xFFF59E0B),
                                    modifier = Modifier.size(15.dp))
                                Text("حواست باشد", style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFD97706), fontWeight = FontWeight.Bold)
                            }
                            task.watchOutFa.forEach {
                                Text("• $it", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                    task.estimate?.takeIf { it.explainFa.isNotBlank() }?.let {
                        Text("⏱ ${it.explainFa}", style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetaPill(text: String, color: Color) {
    Box(
        Modifier.clip(CircleShape)
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = color)
    }
}

@Composable
private fun DetailBlock(
    title: String,
    body: String,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            if (icon != null) Icon(icon, null, tint = accent, modifier = Modifier.size(15.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, color = accent, fontWeight = FontWeight.Bold)
        }
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    }
}

/**
 * نوار فازها.
 *
 * عرض هر فاز با دقیقه‌اش متناسب است، پس نسبت «بازیابی / یادگیری / تثبیت» را
 * می‌شود بدون خواندن عدد دید — و دقیقاً همین نسبت است که یک جلسهٔ حرفه‌ای را
 * از یک ساعت خواندنِ بی‌هدف جدا می‌کند. شدت رنگ از پررنگ به کم‌رنگ می‌رود تا
 * ترتیب زمانی هم خوانده شود.
 */
@Composable
private fun PhaseStrip(task: PlanTask, tone: PlannerTone, accent: Color) {
    val cs = MaterialTheme.colorScheme
    val total = task.phases.sumOf { it.minutes }.coerceAtLeast(1)
    val grow by animateFloatAsState(1f, tween(600, easing = FastOutSlowInEasing), label = "phaseGrow")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ساختار جلسه", style = MaterialTheme.typography.labelMedium, color = accent, fontWeight = FontWeight.Bold)
        Row(
            Modifier.fillMaxWidth().height(10.dp).clip(CircleShape)
                .graphicsLayer { scaleX = grow; transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0.5f) },
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            task.phases.forEachIndexed { i, p ->
                val f = (i.toFloat() / task.phases.size.coerceAtLeast(1))
                Box(
                    Modifier
                        .weight(p.minutes.toFloat() / total)
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(androidx.compose.ui.graphics.lerp(tone.from, tone.to, f)),
                )
            }
        }
        task.phases.forEachIndexed { i, p ->
            Row(horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
                Box(
                    Modifier.size(26.dp).clip(CircleShape)
                        .background(androidx.compose.ui.graphics.lerp(tone.from, tone.to,
                            i.toFloat() / task.phases.size.coerceAtLeast(1)).copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("${p.minutes.fa()}", style = MaterialTheme.typography.labelSmall,
                        color = accent, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f)) {
                    Text(p.labelFa, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    if (p.howFa.isNotBlank()) {
                        Text(p.howFa, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun RequiredChip() {
    Row(
        Modifier.clip(CircleShape)
            .background(Color(0xFFE11D48).copy(alpha = 0.14f))
            .padding(horizontal = 7.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Icon(Icons.Rounded.Lock, null, tint = Color(0xFFE11D48), modifier = Modifier.size(11.dp))
        Text("حداقل روز", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE11D48))
    }
}

/**
 * دکمهٔ تیک.
 *
 * فشار کوچک فنری + پرشدن گرادیانی. این تنها جایی است که کاربر هر روز با آن
 * کار می‌کند، پس ارزش دارد بازخوردش از بقیهٔ دکمه‌ها جان‌دارتر باشد.
 */
@Composable
private fun DoneButton(done: Boolean, tone: PlannerTone, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val fill by animateFloatAsState(if (done) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "fill")
    Box(
        Modifier
            .size(34.dp)
            .graphicsLayer { scaleX = 1f + 0.06f * fill; scaleY = 1f + 0.06f * fill }
            .clip(CircleShape)
            .background(
                if (done) tone.brush()
                else androidx.compose.ui.graphics.SolidColor(Color.Transparent)
            )
            .border(1.5.dp, if (done) Color.Transparent else cs.outlineVariant, CircleShape)
            .clickable {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.Check,
            contentDescription = if (done) "انجام شد" else "علامت انجام",
            tint = if (done) Color.White else cs.outline,
            modifier = Modifier.size(18.dp),
        )
    }
}

/* ------------------------------------------------------------------ */
/*  ردیف عقب‌افتاده                                                    */
/* ------------------------------------------------------------------ */

@Composable
private fun BacklogRow(t: PlanTask) {
    val cs = MaterialTheme.colorScheme
    val tone = toneOf(t.type)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(cs.onSurface.copy(alpha = 0.04f))
            .padding(horizontal = AppSpace.md, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
    ) {
        ToneBadge(tone, 24.dp)
        Text(t.title, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 2)
        Text(Fmt.minutes(t.durationMinutes), style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant)
    }
}
