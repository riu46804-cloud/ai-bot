@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package ir.studying.app.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.studying.app.core.ExamBrief
import ir.studying.app.core.Fmt
import ir.studying.app.core.IranTime
import ir.studying.app.core.PlanDay
import ir.studying.app.core.PlanTask
import ir.studying.app.core.fa
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.AppRadius
import ir.studying.app.ui.theme.AppSpace

/* ======================================================================== */
/*  نمای جدولی کل دوره                                                      */
/* ======================================================================== */

/*
 * چرا این نما لازم شد:
 * نمای روزانه فقط یک روز را نشان می‌داد و برای دیدن کل دوره باید ۱۴ بار تپ
 * می‌کردی. وقتی برنامه «تا آزمون بعدی» چیده می‌شود، چیزی که دانش‌آموز
 * می‌خواهد ببیند همین کل دوره است: کدام روز چه خبر است و بار کجا سنگین شده.
 * پس همهٔ روزها در یک ستون می‌آیند و هر جلسه یک تراشهٔ رنگیِ درس است.
 */

/** پالت ثابت درس‌ها: رنگ هر درس در کل اپ یکی می‌ماند تا چشم عادت کند. */
private val SUBJECT_PALETTE = listOf(
    Color(0xFF2563EB), Color(0xFF059669), Color(0xFFD97706), Color(0xFFDC2626),
    Color(0xFF7C3AED), Color(0xFF0891B2), Color(0xFFDB2777), Color(0xFF65A30D),
    Color(0xFF4F46E5), Color(0xFFEA580C),
)

/**
 * رنگ درس از روی نام آن.
 *
 * عمداً هش ساده و پایدار است (نه رنگ تصادفی و نه نگاشت دستی): نام درس‌ها از
 * دیتاست رسمی می‌آید و با اضافه‌شدن کتاب جدید لازم نیست جایی را دست بزنیم.
 */
fun subjectColor(subject: String): Color {
    if (subject.isBlank()) return SUBJECT_PALETTE[0]
    var h = 0
    for (c in subject) h = h * 31 + c.code
    return SUBJECT_PALETTE[((h % SUBJECT_PALETTE.size) + SUBJECT_PALETTE.size) % SUBJECT_PALETTE.size]
}

/**
 * جدول کل دوره.
 *
 * هر ردیف یک روز است: ستون راست تاریخ و بار روز، ستون چپ تراشه‌های جلسه.
 * تپ روی ردیف همان روز را در نمای روزانه باز می‌کند.
 */
@Composable
fun PlanTable(
    s: PlannerViewModel.State,
    onOpenDay: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val today = remember { IranTime.todayIso() }
    val cs = MaterialTheme.colorScheme
    val subjects = remember(s.days) {
        s.days.flatMap { d -> d.tasks.map { it.subject } }.filter { it.isNotBlank() }.distinct().sorted()
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AppSpace.lg, end = AppSpace.lg, top = AppSpace.sm,
            bottom = AppSpace.xxl + LocalBottomBarPadding.current.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(AppSpace.sm),
    ) {
        s.result?.examBrief?.let { b -> item { ExamBriefCard(b) } }
        // اگر برنامه آزمون‌محور نشد، دانش‌آموز باید علتش را بداند؛ وگرنه فکر
        // می‌کند برنامه برای آزمون بعدی چیده شده و بی‌ربط درآمده.
        s.result?.examStatusFa?.let { msg -> item { ExamStatusNote(msg) } }

        if (subjects.size > 1) {
            item {
                FlowRow(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    subjects.forEach { sub ->
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(subjectColor(sub)))
                            Text(sub, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        items(s.days, key = { "row-" + it.date }) { d ->
            TableDayRow(
                day = d,
                isToday = d.date == today,
                doneOf = { t -> s.reports[t.taskId]?.completed == true },
                onClick = { onOpenDay(d.date) },
            )
        }
    }
}

@Composable
private fun TableDayRow(
    day: PlanDay,
    isToday: Boolean,
    doneOf: (PlanTask) -> Boolean,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val total = day.tasks.size
    val done = day.tasks.count(doneOf)

    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(
                if (isToday) plannerBrand[0].copy(alpha = if (dark) 0.14f else 0.09f)
                else if (dark) Color.White.copy(alpha = 0.045f) else Color.White.copy(alpha = 0.72f)
            )
            .border(
                1.dp,
                if (isToday) plannerBrand[0].copy(alpha = 0.45f) else cs.outlineVariant.copy(alpha = 0.35f),
                AppRadius.small,
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        // ستون تاریخ — عرض ثابت تا ردیف‌ها مثل جدول واقعی تراز بمانند
        Column(
            Modifier
                .width(62.dp)
                .drawBehind {
                    // خط جداکنندهٔ ستون؛ fillMaxHeight در Row با ارتفاع محتوا کار نمی‌کند
                    drawLine(
                        cs.outlineVariant.copy(alpha = 0.5f),
                        androidx.compose.ui.geometry.Offset(0f, 2f),
                        androidx.compose.ui.geometry.Offset(0f, size.height - 2f),
                        strokeWidth = 1f,
                    )
                },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(weekdayShortFa(day.weekday), style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant, maxLines = 1)
            Text(Fmt.jalaliShort(day.date), style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold, maxLines = 1)
            if (total > 0) {
                Text("${done.fa()}/${total.fa()}", style = MaterialTheme.typography.labelSmall,
                    color = if (done == total) Color(0xFF059669) else cs.onSurfaceVariant)
                Text(Fmt.minutes(day.plannedMinutes), style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
        Spacer(Modifier.width(8.dp))

        if (total == 0) {
            Text(
                if (day.isBlocked) "خالی گذاشتی" else "بدون جلسه",
                Modifier.padding(top = 4.dp),
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
        } else {
            FlowRow(
                Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                day.tasks.forEach { t -> SessionChip(t, doneOf(t)) }
            }
        }
    }
}

/** یک جلسه در جدول: رنگ = درس، نوار کناری = نوع جلسه، خط‌خورده = انجام‌شده. */
@Composable
private fun SessionChip(t: PlanTask, done: Boolean) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val base = subjectColor(t.subject)
    val tone = toneOf(t.type)
    val alpha = if (done) 0.35f else 1f

    Row(
        Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(base.copy(alpha = (if (dark) 0.22f else 0.13f) * alpha))
            .border(1.dp, base.copy(alpha = 0.38f * alpha), RoundedCornerShape(7.dp))
            .padding(end = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .width(4.dp)
                .height(22.dp)
                .background(tone.to.copy(alpha = alpha))
        )
        Spacer(Modifier.width(5.dp))
        Text(
            t.title.ifBlank { t.typeFa },
            Modifier.widthIn(max = 150.dp),
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurface.copy(alpha = if (done) 0.5f else 1f),
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.width(5.dp))
        Text(
            "${t.durationMinutes.fa()}′",
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant.copy(alpha = if (done) 0.5f else 1f),
        )
    }
}

private fun weekdayShortFa(w: String): String = when (w.lowercase().take(3)) {
    "sat" -> "شنبه"; "sun" -> "یک‌شنبه"; "mon" -> "دوشنبه"; "tue" -> "سه‌شنبه"
    "wed" -> "چهارشنبه"; "thu" -> "پنج‌شنبه"; "fri" -> "جمعه"; else -> w
}

/* ======================================================================== */
/*  کارت «آزمون بعدی چه می‌خواهد»                                           */
/* ======================================================================== */

/**
 * خلاصهٔ آزمون بعدی.
 *
 * سه سؤالی که دانش‌آموز قبل از شروع می‌پرسد: سرفصل چیست، با این ساعت‌ها
 * چقدرش جا می‌شود، و چه می‌ماند. همه را سرور حساب کرده؛ اینجا فقط نشان
 * می‌دهیم تا عدد اپ و عدد برنامه هیچ‌وقت از هم جدا نشوند.
 */
@Composable
fun ExamBriefCard(b: ExamBrief, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var open by rememberSaveable { mutableStateOf(false) }
    val good = Color(0xFF059669)
    val bad = Color(0xFFDC2626)

    PlannerCard(modifier, accent = if (b.enough) good else bad) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    b.titleFa?.takeIf { it.isNotBlank() } ?: "آزمون بعدی",
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                )
                Text(
                    "${b.topicsPlanned.fa()} از ${b.topicsTotal.fa()} مبحث سرفصل در این برنامه جا شده",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
            b.daysLeft?.takeIf { it >= 0 }?.let {
                Text(
                    if (it == 0) "امروز" else "${it.fa()} روز",
                    Modifier.clip(CircleShape).background(plannerBrand[1].copy(alpha = .15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium, color = plannerBrand[1],
                )
            }
        }

        Spacer(Modifier.height(AppSpace.sm))
        LinearProgressIndicator(
            progress = { b.ratio.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = if (b.enough) good else bad,
            trackColor = cs.outlineVariant.copy(alpha = 0.4f),
        )

        Spacer(Modifier.height(AppSpace.sm))
        Row(horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
            BriefStat("وقت آزادت", Fmt.minutes(b.capacityMinutes), Modifier.weight(1f))
            BriefStat("لازم برای سرفصل", Fmt.minutes(b.neededMinutes), Modifier.weight(1f))
            BriefStat(
                if (b.enough) "وقت اضافه" else "کسری وقت",
                Fmt.minutes(kotlin.math.abs(b.balanceMinutes)),
                Modifier.weight(1f),
                if (b.enough) good else bad,
            )
        }

        if (b.summaryFa.isNotBlank()) {
            Spacer(Modifier.height(AppSpace.sm))
            Text(b.summaryFa, style = MaterialTheme.typography.bodySmall)
        }

        if (b.scope.isNotEmpty() || b.leftOut.isNotEmpty()) {
            Spacer(Modifier.height(AppSpace.xs))
            Text(
                if (open) "بستن جزئیات" else "سرفصل کامل و مباحث جامانده",
                Modifier.clickable { open = !open }.padding(vertical = 4.dp),
                style = MaterialTheme.typography.labelMedium, color = plannerBrand[0],
            )
        }

        if (open) {
            b.scope.forEach { sb ->
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(subjectColor(sb.subject)))
                    Text(sb.subject, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Text("${sb.plannedTopics.fa()}/${sb.topics.fa()} مبحث · ${Fmt.minutes(sb.minutes)}",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                if (sb.chapters.isNotEmpty()) {
                    Text(sb.chapters.joinToString("، "),
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            if (b.leftOut.isNotEmpty()) {
                Spacer(Modifier.height(AppSpace.sm))
                Text("در این دوره جا نشد (${b.leftOut.size.fa()} مبحث):",
                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                b.leftOut.forEach {
                    Text("• ${it.subject} — ${it.title}",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun BriefStat(label: String, value: String, modifier: Modifier = Modifier, color: Color? = null) {
    val cs = MaterialTheme.colorScheme
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
        Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
            color = color ?: cs.onSurface, maxLines = 1)
    }
}

/** هشدار کوتاه وقتی تقویم آزمون در دسترس نیست. */
@Composable
private fun ExamStatusNote(message: String) {
    val cs = MaterialTheme.colorScheme
    val warn = Color(0xFFD97706)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .background(warn.copy(alpha = 0.12f))
            .border(1.dp, warn.copy(alpha = 0.35f), AppRadius.small)
            .padding(10.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("⚠️", style = MaterialTheme.typography.labelLarge)
        Text(message, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium,
            color = cs.onSurface)
    }
}
