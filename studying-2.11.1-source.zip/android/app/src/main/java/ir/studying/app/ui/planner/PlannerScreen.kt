package ir.studying.app.ui.planner

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Fmt
import ir.studying.app.core.fa
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.AppRadius
import ir.studying.app.ui.theme.AppSpace

/* ======================================================================== */
/*  برنامه‌ریز هوشمند                                                       */
/* ======================================================================== */

/*
 * چهار تب، نه بیشتر:
 *   گفتگو  — برنامه با حرف زدن ساخته می‌شود، نه با پر کردن ده تا فیلد.
 *   برنامه — تایم‌لاین روز با ساختار دقیق هر جلسه.
 *   مرور   — منحنی ماندگاری، نقشهٔ مرور و تحلیل خطاها.
 *   کیفیت  — چک‌لیست استانداردهای یک برنامهٔ درست.
 *
 * دلیل این تقسیم: ساخت برنامه یک کار است، اجرای روزانه کار دوم، و بازبینی
 * هفتگی کار سوم. قاطی‌کردنشان در یک اسکرول بلند همان چیزی بود که نسخهٔ وب را
 * غیرقابل‌استفاده کرده بود.
 */

// ترتیب عمداً عوض شد: «برنامه» اول است. برنامه خودکار ساخته می‌شود و گفتگو
// فقط برای پرسیدن سؤال و اصلاح همان برنامه است، نه برای ساختنش.
private val TABS = listOf("برنامه", "گفتگو", "مرور", "کیفیت")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ActivePlannerScreen(onBack: () -> Unit, vm: PlannerViewModel = viewModel()) {
    val s by vm.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    // اولین باری که برنامه آماده می‌شود، خودکار به تب «برنامه» می‌رویم؛
    // کاربر منتظر نتیجه بوده، نه منتظر اینکه خودش تب عوض کند.
    var sawPlan by remember { mutableStateOf(false) }
    LaunchedEffect(s.hasPlan, s.fromCache) {
        if (s.hasPlan && !sawPlan) { sawPlan = true; tab = 0 }
    }

    Box(Modifier.fillMaxSize()) {
        // شفق فقط پشت یک‌سومِ بالای صفحه؛ پایین‌تر محتوا باید کنتراست کامل داشته باشد.
        AuroraBackground(Modifier.fillMaxWidth().height(360.dp))

        Column(Modifier.fillMaxSize()) {
            PlannerTopBar(
                subtitle = when {
                    s.needsOnboarding -> "اول وضعیت درسی‌ات را مشخص کن"
                    s.plan != null -> "${Fmt.jalaliShort(s.plan!!.startDate)} تا ${Fmt.jalaliShort(s.plan!!.endDate)} • ${s.plan!!.totals.taskCount.fa()} جلسه"
                    else -> null
                },
                replanning = s.replanning,
                showReplan = s.hasPlan && !s.needsOnboarding,
                onBack = onBack,
                onReplan = { vm.replan() },
            )

            AnimatedVisibility(s.hasPlan && !s.needsOnboarding, enter = fadeIn() + slideInVertically { -it / 2 }) {
                PlannerTabs(TABS, tab) { tab = it }
            }

            when {
                s.booting -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }

                // تا وقتی نمی‌دانیم کاربر چه خوانده، هر برنامه‌ای حدس است.
                s.needsOnboarding -> PlannerOnboarding(
                    step = s.step,
                    tracks = s.tracks,
                    selectedTrack = s.draftTrack,
                    selectedGrade = s.draftGrade,
                    graduate = s.draftGraduate,
                    providers = s.providers,
                    selectedProvider = s.draftProvider,
                    books = s.books,
                    includedBooks = s.draftBooks,
                    openBook = s.openBook,
                    loadingBook = s.loadingBook,
                    loading = s.booksLoading,
                    error = s.booksError,
                    selection = s.draftTopics,
                    sessionMinutes = s.draftMinutes,
                    freeHours = s.draftFreeHours,
                    saving = s.savingProfile || s.building,
                    onRetry = { vm.loadTracks() },
                    onSelectTrack = vm::selectTrack,
                    onSelectGrade = vm::selectGrade,
                    onSelectGraduate = { vm.selectGraduate() },
                    onSelectProvider = vm::selectProvider,
                    onToggleBook = vm::toggleBook,
                    onToggleInclude = vm::toggleInclude,
                    onSelectAll = vm::setAllIncluded,
                    onStudiedUpTo = vm::setStudiedUpTo,
                    onSetTopic = vm::setTopicStatus,
                    onSetChapter = vm::setChapterStatus,
                    onSessionMinutes = vm::setSessionMinutes,
                    onFreeHours = vm::setFreeHours,
                    onBackStep = { vm.backStep() },
                    onNext = {
                        when (s.step) {
                            0 -> vm.goToExams()
                            1 -> vm.goToSubjects()
                            2 -> vm.goToProgress()
                            else -> vm.goToTime()
                        }
                    },
                    onFinish = { vm.finishOnboarding() },
                    modifier = Modifier.weight(1f),
                )

                // ساخت خودکار برنامه بعد از آنبوردینگ — بدون هیچ چتی
                s.building -> BuildingPlan(Modifier.weight(1f))

                tab == 1 -> PlannerChatTab(
                    s, Modifier.weight(1f),
                    onEditTopics = { vm.reopenOnboarding() },
                    onSend = { vm.send(it) },
                )
                !s.hasPlan -> NoPlanYet(s, Modifier.weight(1f), onBuild = { vm.buildPlan(force = true) },
                    onEditTopics = { vm.reopenOnboarding() })
                tab == 0 -> PlannerPlanTab(s, vm, Modifier.weight(1f))
                tab == 2 -> PlannerReviewTab(s, Modifier.weight(1f))
                else -> PlannerQualityTab(s, Modifier.weight(1f))
            }
        }

        if (s.pendingConfirm != null) {
            ReplaceConfirmDialog(
                onConfirm = { vm.confirmReplace() },
                onDismiss = { vm.dismissConfirm() },
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/*  حالت‌های بدون برنامه                                               */
/* ------------------------------------------------------------------ */

/** در حال ساخت برنامه؛ هیچ ورودی دیگری از کاربر لازم نیست. */
@Composable
private fun BuildingPlan(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.fillMaxSize().padding(AppSpace.xl), Arrangement.Center, Alignment.CenterHorizontally) {
        SparkleMark(64.dp)
        Spacer(Modifier.height(AppSpace.lg))
        Text("دارم برنامه‌ات را می‌چینم…", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(AppSpace.sm))
        Text(
            "زمان هر مبحث از بودجه‌بندی رسمی کتاب درسی خوانده می‌شود و روی ساعت‌های آزاد تو چیده می‌شود.",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(AppSpace.lg))
        LinearProgressIndicator(Modifier.fillMaxWidth(0.6f).clip(CircleShape))
    }
}

/** پرونده کامل است ولی برنامه‌ای نیست (مثلاً ساخت قبلی خطا خورده). */
@Composable
private fun NoPlanYet(
    s: PlannerViewModel.State,
    modifier: Modifier = Modifier,
    onBuild: () -> Unit,
    onEditTopics: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.fillMaxSize().padding(AppSpace.xl),
        Arrangement.Center, Alignment.CenterHorizontally,
    ) {
        SparkleMark(56.dp)
        Spacer(Modifier.height(AppSpace.lg))
        Text("هنوز برنامه‌ای نداری", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(AppSpace.sm))
        Text(
            s.error ?: "پروندهٔ درسی‌ات آماده است؛ یک تپ تا برنامهٔ کامل فاصله داری.",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(AppSpace.lg))
        Box(
            Modifier
                .clip(CircleShape)
                .background(plannerBrandBrush())
                .clickable(onClick = onBuild)
                .padding(horizontal = 28.dp, vertical = 13.dp),
        ) {
            Text("برنامه‌ام را بساز", color = Color.White,
                style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(AppSpace.sm))
        TextButton(onClick = onEditTopics) { Text("اول وضعیت درس‌هایم را اصلاح کنم") }
    }
}

/**
 * تأیید جایگزینی برنامهٔ فعلی.
 *
 * برنامه‌ای که هر چند ساعت عوض شود هیچ‌وقت اجرا نمی‌شود؛ مرور فاصله‌دار و
 * انباشت تسلط هر دو به پیوستگی چند روزه نیاز دارند. این دیالوگ جلوی تغییر
 * تکانه‌ای را می‌گیرد، ولی راه را نمی‌بندد: اگر واقعاً شرایط عوض شده (مثلاً
 * امتحان جابه‌جا شده) یک تپ کافی است.
 */
@Composable
private fun ReplaceConfirmDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("برنامه‌ی فعلی را جایگزین کنم؟") },
        text = {
            Text(
                "برنامه‌ی الان هنوز تازه است و مرورهایش روی همین چند روز چیده شده. " +
                    "اگر عوضش کنم، آن زمان‌بندی از بین می‌رود.\n\n" +
                    "اگر فقط می‌خواهی چیزی را اصلاح کنی (مثل خالی‌کردن یک روز)، بعد از ساخت هم می‌شود؛ " +
                    "ولی اگر شرایطت واقعاً عوض شده، ادامه بده.",
                style = MaterialTheme.typography.bodySmall,
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("برنامه‌ی تازه بساز") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("نه، همین بماند") } },
    )
}

/* ------------------------------------------------------------------ */
/*  سربرگ                                                             */
/* ------------------------------------------------------------------ */

@Composable
private fun PlannerTopBar(
    subtitle: String?,
    replanning: Boolean,
    showReplan: Boolean,
    onBack: () -> Unit,
    onReplan: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = AppSpace.md, vertical = AppSpace.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "بازگشت", onBack)
        Spacer(Modifier.width(AppSpace.sm))
        SparkleMark(34.dp)
        Spacer(Modifier.width(AppSpace.sm))
        Column(Modifier.weight(1f)) {
            Text(
                "برنامه‌ریز هوشمند",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
        if (showReplan) {
            // چرخش فقط وقتی کار واقعاً در جریان است؛ آیکون چرخانِ بی‌دلیل دروغ می‌گوید.
            val t = rememberInfiniteTransition(label = "replan")
            val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "spin")
            RoundIconButton(
                Icons.Rounded.Refresh, "بازبرنامه‌ریزی", onReplan,
                enabled = !replanning,
                rotation = if (replanning) spin else 0f,
            )
        }
    }
}

@Composable
private fun RoundIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    rotation: Float = 0f,
) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Surface(
        shape = CircleShape,
        color = if (dark) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.8f),
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.5f)),
        onClick = { if (enabled) onClick() },
        modifier = Modifier.size(38.dp),
    ) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Icon(
                icon, contentDescription = label,
                tint = if (enabled) cs.onSurface else cs.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = rotation },
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/*  نوار تب                                                           */
/* ------------------------------------------------------------------ */

/**
 * تبِ قرصی با نشانگر گرادیانی لغزان.
 *
 * نسخهٔ قبل از تبِ عمومی اپ استفاده می‌کرد و در این صفحه بی‌هویت بود. نشانگر
 * اینجا همان گرادیان برند برنامه‌ریز را دارد، پس تب فعال هم‌خانوادهٔ کارت
 * خانه و سربرگ دیده می‌شود و کاربر می‌فهمد هنوز داخل همان ابزار است.
 */
@Composable
private fun PlannerTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val haptic = LocalHapticFeedback.current
    BoxWithConstraints(
        Modifier.fillMaxWidth().padding(horizontal = AppSpace.lg, vertical = AppSpace.xs),
    ) {
        val n = options.size.coerceAtLeast(1)
        val inner = maxWidth - 10.dp
        val itemW = inner / n
        val off by animateDpAsState(itemW * selected, spring(dampingRatio = 0.78f, stiffness = 320f), label = "tabOff")
        Box(
            Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(if (dark) Color.Black.copy(alpha = 0.32f) else cs.onSurface.copy(alpha = 0.055f))
                .border(1.dp, cs.outlineVariant.copy(alpha = 0.35f), CircleShape)
                .padding(5.dp),
        ) {
            Box(
                Modifier
                    .offset(x = off)
                    .width(itemW)
                    .height(34.dp)
                    .clip(CircleShape)
                    .background(plannerBrandBrush()),
            )
            Row(Modifier.fillMaxWidth()) {
                options.forEachIndexed { i, label ->
                    val active = i == selected
                    val alpha by animateFloatAsState(if (active) 1f else 0.62f, tween(220), label = "tabA")
                    Box(
                        Modifier
                            .width(itemW)
                            .height(34.dp)
                            .clip(CircleShape)
                            .clickable {
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                onSelect(i)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            color = if (active) Color.White else cs.onSurface.copy(alpha = alpha),
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

/* ======================================================================== */
/*  تب گفتگو                                                                */
/* ======================================================================== */

// گفتگو دیگر جای ساختن برنامه نیست؛ برنامه خودکار ساخته شده و اینجا فقط
// اصلاحش می‌کنیم یا دربارهٔ آن سؤال می‌پرسیم.
private val STARTERS = listOf(
    "🌙 جمعه‌ها را خالی کن" to "جمعه‌ها را خالی کن",
    "⏱ این هفته وقت کمتری دارم، سبک‌ترش کن" to "این هفته وقت کمتری دارم، برنامه را سبک‌تر کن",
    "📘 جمعه امتحان شیمی دارم، روی آن تمرکز کن" to "جمعه امتحان شیمی دارم، برنامه را روی آن متمرکز کن",
    "❓ چرا این مبحث اول آمده؟" to "چرا این مبحث اول برنامه آمده؟",
)

@Composable
private fun PlannerChatTab(
    s: PlannerViewModel.State,
    modifier: Modifier = Modifier,
    onEditTopics: () -> Unit,
    onSend: (String) -> Unit,
) {
    var draft by remember { mutableStateOf("") }
    // از فریم اول روی آخرین پیام؛ با رسیدن جواب هم فقط اگر کاربر پایین باشد دنبال می‌کند
    val listState = ir.studying.app.ui.components.rememberChatListState(
        count = s.messages.size,
        lastKey = s.messages.lastOrNull()?.let { "${s.messages.size}:${it.pending}" },
        lastIsMine = s.messages.lastOrNull()?.fromUser == true,
    )

    Column(modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(AppSpace.lg),
            verticalArrangement = Arrangement.spacedBy(AppSpace.md),
        ) {
            if (s.messages.isEmpty()) {
                item { PlannerIntro() }
                item { ProfileSummaryRow(s.profile.studiedCount, onEditTopics) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
                        STARTERS.forEachIndexed { i, (label, text) ->
                            StarterChip(label, i) { onSend(text) }
                        }
                    }
                }
            }
            items(s.messages.size) { i -> ChatBubble(s.messages[i]) }
        }

        // سهمیه فقط وقتی دیده می‌شود که کم شده باشد؛ نمایش دائمی‌اش فقط
        // اضطراب می‌سازد بدون اینکه چیزی به کاربر بدهد.
        if (s.quotaLeft < ir.studying.app.core.PlannerStore.MAX_PLANS_PER_DAY) {
            Text(
                if (s.quotaLeft > 0) "امروز ${s.quotaLeft.fa()} بار دیگر می‌توانی برنامه بسازی"
                else "سهمیه‌ی امروز تمام شد؛ فردا دوباره باز می‌شود",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            )
        }

        ChatComposer(
            draft = draft,
            sending = s.sending,
            onChange = { draft = it },
            onSend = { if (draft.isNotBlank()) { onSend(draft); draft = "" } },
        )
    }
}

/**
 * نوار «پروندهٔ من».
 *
 * یادآوری می‌کند که برنامه بر پایهٔ چه چیزی ساخته می‌شود و راه برگشت به
 * فهرست مباحث را باز نگه می‌دارد. بدون این، کاربری که وسط ترم چند فصل جلو
 * رفته هیچ‌وقت وضعیتش را به‌روز نمی‌کرد و برنامه‌ها عقب‌تر از واقعیت می‌ماندند.
 */
@Composable
private fun ProfileSummaryRow(studied: Int, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Surface(
        shape = AppRadius.small,
        color = if (dark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.8f),
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.45f)),
        onClick = onEdit,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(horizontal = AppSpace.lg, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("پرونده‌ی درسی من", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Text(
                    if (studied == 0) "هیچ مبحثی علامت نخورده — برنامه از ابتدای کتاب شروع می‌کند"
                    else "${studied.fa()} مبحث خوانده‌شده ثبت شده",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
            Text("ویرایش", style = MaterialTheme.typography.labelMedium, color = plannerBrand[1])
        }
    }
}

@Composable
private fun StarterChip(label: String, index: Int, onClick: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(90L * index); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(340), label = "starterA")
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    Surface(
        shape = AppRadius.small,
        color = if (dark) Color.White.copy(alpha = 0.055f) else Color.White.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, Brush.horizontalGradient(
            listOf(plannerBrand[0].copy(alpha = 0.35f), plannerBrand[1].copy(alpha = 0.10f)))),
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = a; translationY = (1f - a) * 18f },
    ) {
        Text(label, Modifier.padding(horizontal = AppSpace.lg, vertical = 13.dp),
            style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PlannerIntro() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "intro")
    val float by t.animateFloat(-5f, 5f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "introFloat")
    Column(
        Modifier.fillMaxWidth().padding(top = AppSpace.lg, bottom = AppSpace.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(96.dp).graphicsLayer { translationY = float },
            contentAlignment = Alignment.Center,
        ) {
            // هالهٔ بیرونی + هستهٔ مات: عمق بدون blur، که روی اندروید ۱۱ هم کار کند.
            Box(
                Modifier.fillMaxSize().clip(CircleShape)
                    .background(Brush.radialGradient(
                        listOf(plannerBrand[0].copy(alpha = 0.32f), Color.Transparent)))
            )
            Box(
                Modifier.size(62.dp).clip(CircleShape).background(plannerBrandBrush()),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
        }
        Spacer(Modifier.height(AppSpace.md))
        Text("چیزی را می‌خواهی عوض کنی؟", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(AppSpace.xs))
        Text(
            "برنامه‌ات از روی کتاب‌های همین رشته و پایه ساخته شده. اینجا می‌توانی اصلاحش کنی — مثلاً روزی را خالی کنی، یک درس را جلو بیندازی، یا بپرسی چرا ترتیب این‌طور شده.",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = AppSpace.lg),
        )
        Spacer(Modifier.height(AppSpace.lg))
    }
}

@Composable
private fun ChatBubble(m: PlannerMessage) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val mine = m.fromUser
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(260), label = "bubbleA")

    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a; translationY = (1f - a) * 10f },
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom,
    ) {
        if (!mine) { SparkleMark(26.dp); Spacer(Modifier.width(7.dp)) }
        Box(
            Modifier
                .widthIn(max = 310.dp)
                .clip(RoundedCornerShape(
                    topStart = 20.dp, topEnd = 20.dp,
                    bottomStart = if (mine) 20.dp else 6.dp, bottomEnd = if (mine) 6.dp else 20.dp,
                ))
                .background(
                    if (mine) plannerBrandBrush()
                    else Brush.linearGradient(listOf(
                        if (dark) Color.White.copy(alpha = 0.085f) else Color.White.copy(alpha = 0.95f),
                        if (dark) Color.White.copy(alpha = 0.04f) else Color.White.copy(alpha = 0.78f),
                    ))
                )
                .let { if (mine) it else it.border(1.dp, cs.outlineVariant.copy(alpha = 0.45f), RoundedCornerShape(
                    topStart = 20.dp, topEnd = 20.dp, bottomStart = 6.dp, bottomEnd = 20.dp)) },
        ) {
            if (m.pending) {
                Row(
                    Modifier.padding(horizontal = AppSpace.lg, vertical = 15.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) { repeat(3) { i -> TypingDot(i) } }
            } else {
                Text(
                    m.text,
                    Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (mine) Color.White else cs.onSurface,
                )
            }
        }
    }
}

@Composable
private fun TypingDot(index: Int) {
    val t = rememberInfiniteTransition(label = "dot$index")
    val y by t.animateFloat(
        0f, -4f,
        infiniteRepeatable(tween(460, delayMillis = index * 140, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dotY",
    )
    Box(
        Modifier.size(7.dp).graphicsLayer { translationY = y }
            .clip(CircleShape)
            .background(plannerBrand[index % plannerBrand.size]),
    )
}

/**
 * نوار نوشتن.
 *
 * دکمهٔ ارسال وقتی متن خالی است خاکستری و تخت است و به‌محض تایپ گرادیانی و
 * برجسته می‌شود؛ همان بازخورد کوچکی که معلوم می‌کند حالا می‌شود فرستاد، بدون
 * اینکه پیام خطا لازم شود.
 */
@Composable
private fun ChatComposer(draft: String, sending: Boolean, onChange: (String) -> Unit, onSend: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val can = draft.isNotBlank() && !sending
    val btnScale by animateFloatAsState(if (can) 1f else 0.9f, spring(dampingRatio = 0.5f), label = "sendScale")

    Column {
        SoftDivider()
        Row(
            Modifier
                .fillMaxWidth()
                .background(if (dark) Color.Black.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.55f))
                .padding(horizontal = AppSpace.md, vertical = AppSpace.sm)
                .padding(bottom = LocalBottomBarPadding.current.calculateBottomPadding()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(AppSpace.sm),
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (dark) Color.White.copy(alpha = 0.07f) else Color.White)
                    .border(1.dp, cs.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                    .padding(horizontal = AppSpace.lg, vertical = 14.dp),
            ) {
                if (draft.isEmpty()) {
                    Text("چی می‌خوای بخونی؟", style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant)
                }
                BasicTextField(
                    value = draft,
                    onValueChange = onChange,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = cs.onSurface),
                    cursorBrush = SolidColor(plannerBrand[0]),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Box(
                Modifier
                    .size(48.dp)
                    .graphicsLayer { scaleX = btnScale; scaleY = btnScale }
                    .clip(CircleShape)
                    .background(if (can) plannerBrandBrush() else SolidColor(cs.surfaceVariant))
                    .clickable(enabled = can, onClick = onSend),
                contentAlignment = Alignment.Center,
            ) {
                if (sending) {
                    CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = cs.onSurfaceVariant)
                } else {
                    Icon(
                        Icons.AutoMirrored.Rounded.Send, contentDescription = "بفرست",
                        tint = if (can) Color.White else cs.onSurfaceVariant,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }
}
