package ir.studying.app.ui.planner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Cache
import ir.studying.app.core.CurrBook
import ir.studying.app.core.CurrChapter
import ir.studying.app.core.CurrTrack
import ir.studying.app.core.ExamProvider
import ir.studying.app.core.PlannerExams
import ir.studying.app.core.IranTime
import ir.studying.app.core.PlanResult
import ir.studying.app.core.PlanTask
import ir.studying.app.core.PlannerApi
import ir.studying.app.core.PlannerCurriculum
import ir.studying.app.core.PlannerProfile
import ir.studying.app.core.PlannerStore
import ir.studying.app.core.Store
import ir.studying.app.core.TopicStatus
import ir.studying.app.core.humanizeError
import ir.studying.app.core.parsePlanResult
import ir.studying.app.core.toBaseRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** یک پیام گفتگو؛ `pending` یعنی هنوز جواب سرور نیامده. */
data class PlannerMessage(val fromUser: Boolean, val text: String, val pending: Boolean = false)

/** گزارش انجام یک جلسه که به چرخهٔ بازبرنامه‌ریزی تغذیه می‌شود. */
data class SessionReport(
    val completed: Boolean,
    val minutes: Int,
    /** علت ← تعداد؛ کلیدها همان علت‌های استاندارد موتورند. */
    val mistakes: Map<String, Int> = emptyMap(),
    val attempted: Int = 0,
    val correct: Int = 0,
)

/**
 * مغز بخش برنامه‌ریزی.
 *
 * چرا اینجا و نه در صفحه: ساخت برنامه تا یک دقیقه طول می‌کشد و کاربر در این
 * فاصله تب عوض می‌کند یا گوشی را می‌چرخاند. اگر وضعیت در Composable می‌ماند،
 * هر بازترکیب درخواست را دور می‌انداخت. نتیجهٔ آخر هم در [Cache] می‌نشیند تا
 * صفحه آفلاین و بدون اسپینر باز شود.
 */
class PlannerViewModel : ViewModel() {

    data class State(
        val booting: Boolean = true,
        val sending: Boolean = false,
        val replanning: Boolean = false,
        val error: String? = null,
        val messages: List<PlannerMessage> = emptyList(),
        val result: PlanResult? = null,
        /** تاریخ روز انتخاب‌شده در تب «برنامه». */
        val selectedDate: String? = null,
        /** گزارش جلسه‌ها، کلید = task_id. */
        val reports: Map<String, SessionReport> = emptyMap(),
        val replanNotes: List<String> = emptyList(),
        val fromCache: Boolean = false,

        /* ---- آنبوردینگ ---- */
        val profile: PlannerProfile = PlannerProfile(),
        /** گام آنبوردینگ: ۰ رشته، ۱ آزمون، ۲ درس‌ها، ۳ خوانده‌ها، ۴ زمان. */
        val step: Int = 0,
        val tracks: List<CurrTrack> = emptyList(),
        val draftTrack: String? = null,
        val draftGrade: Int = 0,
        /** فارغ‌التحصیل: پایه ندارد ولی مثل کنکوری هر سه پایه را می‌بیند. */
        val draftGraduate: Boolean = false,
        /* ---- مؤسسهٔ آزمون ---- */
        val providers: List<ExamProvider> = emptyList(),
        val draftProvider: String? = null,
        /** کتاب‌هایی که کاربر برای برنامه انتخاب کرده. */
        val draftBooks: Set<String> = emptySet(),
        val books: List<CurrBook> = emptyList(),
        val booksLoading: Boolean = false,
        val booksError: String? = null,
        /** کتابی که باز است؛ فصل‌هایش همان لحظه از سرور می‌آید. */
        val openBook: String? = null,
        val loadingBook: String? = null,
        /** ساخت خودکار برنامه بعد از آنبوردینگ. */
        val building: Boolean = false,
        /** انتخاب‌های در حال ویرایش در آنبوردینگ، پیش از ذخیره. */
        val draftTopics: Map<String, TopicStatus> = emptyMap(),
        val draftMinutes: Int = 60,
        val draftFreeHours: Int = 3,
        val savingProfile: Boolean = false,

        /* ---- سهمیه ---- */
        /** پیامی که منتظر تأیید کاربر برای جایگزینی برنامهٔ فعلی است. */
        val pendingConfirm: String? = null,
        val quotaLeft: Int = PlannerStore.MAX_PLANS_PER_DAY,
    ) {
        val plan get() = result?.plan
        val days get() = plan?.days.orEmpty()
        val day get() = days.firstOrNull { it.date == selectedDate } ?: days.firstOrNull()
        val hasPlan get() = result != null
        val needsOnboarding get() = !profile.onboarded
        val trackTitle get() = tracks.firstOrNull { it.trackId == draftTrack }?.title
        /** تا وقتی رشته و پایه مشخص نشده، رفتن به گام بعد معنا ندارد. */
        val canGoToSubjects get() = draftTrack != null && (draftGrade > 0 || draftGraduate)
        /** پایه‌هایی که کتابشان باید بیاید. */
        val gradeScope: List<Int>
            get() = if (draftGraduate || draftGrade >= 12) listOf(10, 11, 12) else listOf(draftGrade)
        /** تعداد جلسه‌هایی که کاربر تیک زده. */
        val doneCount get() = reports.count { it.value.completed }
    }

    // Keep the actual plan for AI edits/replanning; never reconstruct it from UI rows.
    private var currentPlanPayload: JSONObject? = null

    val state = MutableStateFlow(State())

    init {
        if (ir.studying.app.core.PlannerAvailability.ENABLED) boot()
        else state.update { it.copy(booting = false) }
    }

    private fun unavailable(): Boolean {
        if (ir.studying.app.core.PlannerAvailability.ENABLED) return false
        state.update { it.copy(booting = false, building = false, sending = false,
            replanning = false, savingProfile = false, error = ir.studying.app.core.PlannerAvailability.MESSAGE) }
        return true
    }

    /* ------------------------------------------------------------------ */
    /*  راه‌اندازی                                                         */
    /* ------------------------------------------------------------------ */

    private fun boot() {
        viewModelScope.launch {
            val profile = PlannerStore.load()
            state.update {
                it.copy(
                    profile = profile,
                    draftTopics = profile.topics,
                    draftMinutes = profile.sessionMinutes,
                    draftFreeHours = profile.freeHoursPerDay,
                    quotaLeft = PlannerStore.remainingToday(),
                )
            }
            restorePlan()
            if (!profile.onboarded) {
                state.update {
                    it.copy(
                        draftTrack = profile.field.takeIf { f -> f.isNotBlank() },
                        draftGrade = profile.gradeNumber,
                        draftGraduate = profile.graduate,
                        draftProvider = profile.examProvider,
                        draftBooks = profile.bookIds.toSet(),
                    )
                }
                loadTracks()
            }
        }
    }

    private suspend fun restorePlan() {
        val raw = Cache.get(Cache.PLANNER, maxAgeMs = 30L * 24 * 60 * 60 * 1000)
        if (raw == null) { state.update { it.copy(booting = false) }; return }
        runCatching {
            val saved = JSONObject(raw)
            val restored = saved.getJSONObject("result")
            val res = parsePlanResult(restored)
            currentPlanPayload = if (res != null) restored else null
            val msgs = (saved.optJSONArray("messages") ?: JSONArray()).let { a ->
                (0 until a.length()).mapNotNull { a.optJSONObject(it) }
                    .map { PlannerMessage(it.optBoolean("me"), it.optString("text")) }
            }
            val reports = mutableMapOf<String, SessionReport>()
            saved.optJSONObject("reports")?.let { o ->
                o.keys().forEach { k ->
                    val r = o.getJSONObject(k)
                    reports[k] = SessionReport(r.optBoolean("completed"), r.optInt("minutes"))
                }
            }
            state.update {
                it.copy(booting = false, result = res, messages = msgs, reports = reports,
                    fromCache = true, selectedDate = defaultDate(res))
            }
        }.onFailure { state.update { s -> s.copy(booting = false) } }
    }

    /** امروز اگر در برنامه باشد، وگرنه اولین روز — کاربر معمولاً «امروز» را می‌خواهد. */
    private fun defaultDate(res: PlanResult?): String? {
        val days = res?.plan?.days.orEmpty()
        val today = IranTime.todayIso()
        return days.firstOrNull { it.date == today }?.date ?: days.firstOrNull()?.date
    }

    private fun persist(rawResult: JSONObject) {
        currentPlanPayload = JSONObject(rawResult.toString())
        val s = state.value
        val payload = JSONObject()
            .put("result", rawResult)
            .put("messages", JSONArray().apply {
                s.messages.filter { !it.pending }.takeLast(30)
                    .forEach { put(JSONObject().put("me", it.fromUser).put("text", it.text)) }
            })
            .put("reports", JSONObject().apply {
                s.reports.forEach { (k, v) -> put(k, JSONObject().put("completed", v.completed).put("minutes", v.minutes)) }
            })
        Cache.put(Cache.PLANNER, payload.toString())
    }

    /* ------------------------------------------------------------------ */
    /*  آنبوردینگ                                                          */
    /* ------------------------------------------------------------------ */

    fun loadTracks() {
        if (state.value.booksLoading) return
        state.update { it.copy(booksLoading = true, booksError = null) }
        viewModelScope.launch {
            try {
                val tracks = PlannerCurriculum.tracks()
                state.update { it.copy(booksLoading = false, tracks = tracks) }
            } catch (e: Exception) {
                state.update { it.copy(booksLoading = false, booksError = humanizeError(e)) }
            }
        }
    }

    fun selectTrack(id: String) = state.update { it.copy(draftTrack = id, books = emptyList(), openBook = null) }

    fun selectGrade(n: Int) =
        state.update { it.copy(draftGrade = n, draftGraduate = false, books = emptyList(), draftBooks = emptySet(), openBook = null) }

    /** فارغ‌التحصیل: پایه‌ای انتخاب نمی‌کند ولی مثل دوازدهمی برنامه می‌گیرد. */
    fun selectGraduate() =
        state.update { it.copy(draftGraduate = true, draftGrade = 12, books = emptyList(), draftBooks = emptySet(), openBook = null) }

    /** گام دوم: مؤسسهٔ آزمون آزمایشی. */
    fun goToExams() {
        if (!state.value.canGoToSubjects) return
        state.update { it.copy(step = 1) }
        if (state.value.providers.isNotEmpty()) return
        state.update { it.copy(booksLoading = true, booksError = null) }
        viewModelScope.launch {
            try {
                val ps = PlannerExams.providers()
                state.update { s ->
                    s.copy(booksLoading = false, providers = ps,
                        draftProvider = s.draftProvider ?: ps.firstOrNull { it.available }?.providerId)
                }
            } catch (e: Exception) {
                state.update { it.copy(booksLoading = false, booksError = humanizeError(e)) }
            }
        }
    }

    fun selectProvider(id: String) = state.update { it.copy(draftProvider = id) }

    /** گام سوم: درس‌ها. کتاب‌های همهٔ پایه‌های لازم همین‌جا گرفته می‌شوند. */
    fun goToSubjects() {
        val s = state.value
        val track = s.draftTrack ?: return
        if (!s.canGoToSubjects) return
        state.update { it.copy(step = 2, booksLoading = true, booksError = null) }
        viewModelScope.launch {
            try {
                val books = PlannerCurriculum.books(track, s.gradeScope)
                state.update { st ->
                    // پیش‌فرض: درس‌های کنکوری تیک‌خورده. کسی که همین‌طور رد شود
                    // برنامهٔ منطقی می‌گیرد، و هر کس بخواهد تیک‌ها را عوض می‌کند.
                    val pre = st.draftBooks.ifEmpty {
                        books.filter { it.isKonkur }.map { it.bookId }.toSet()
                            .ifEmpty { books.map { it.bookId }.toSet() }
                    }
                    st.copy(booksLoading = false, books = books, draftBooks = pre)
                }
            } catch (e: Exception) {
                state.update { it.copy(booksLoading = false, booksError = humanizeError(e)) }
            }
        }
    }

    /** انتخاب/حذف یک درس از برنامه. */
    fun toggleInclude(bookId: String) = state.update { s ->
        s.copy(draftBooks = if (bookId in s.draftBooks) s.draftBooks - bookId else s.draftBooks + bookId)
    }

    fun setAllIncluded(on: Boolean) = state.update { s ->
        s.copy(draftBooks = if (on) s.books.map { it.bookId }.toSet() else emptySet())
    }

    fun backStep() = state.update { it.copy(step = (it.step - 1).coerceAtLeast(0), openBook = null) }

    /** گام چهارم: «تا کجا خوانده‌ای؟» — فقط روی درس‌های انتخاب‌شده. */
    fun goToProgress() = state.update { it.copy(step = 3, openBook = null) }

    fun goToTime() = state.update { it.copy(step = 4, openBook = null) }

    /**
     * «تا این فصل خوانده‌ام».
     *
     * تک‌تک علامت‌زدن ۴۰ مبحث کاری است که هیچ‌کس نمی‌کند، و نتیجه‌اش این بود
     * که موتور همه را نخوانده فرض می‌کرد و برنامه از فصل اول شروع می‌شد. با
     * یک تپ، همهٔ فصل‌های تا اینجا «خوانده‌ام» و بقیه «نخوانده‌ام» می‌شوند.
     */
    fun setStudiedUpTo(book: CurrBook, chapter: CurrChapter) {
        state.update { s ->
            val next = s.draftTopics.toMutableMap()
            var passed = false
            book.chapters.forEach { ch ->
                val studied = !passed
                ch.topics.forEach { t ->
                    next[t.topicId] = if (studied) TopicStatus.STUDIED else TopicStatus.NOT_STARTED
                }
                if (ch.chapterId == chapter.chapterId) passed = true
            }
            s.copy(draftTopics = next)
        }
    }

    /**
     * باز/بسته کردن یک کتاب.
     *
     * فصل‌ها و مباحث فقط همین‌جا گرفته می‌شوند؛ دیتاست رسمی ۸۱ کتاب دارد و
     * کشیدن همه‌شان موقع ورود، هم کند است هم بی‌فایده.
     */
    fun toggleBook(book: CurrBook) {
        if (state.value.openBook == book.bookId) { state.update { it.copy(openBook = null) }; return }
        state.update { it.copy(openBook = book.bookId) }
        if (book.loaded) return
        state.update { it.copy(loadingBook = book.bookId) }
        viewModelScope.launch {
            try {
                val full = PlannerCurriculum.detail(book)
                state.update { s ->
                    s.copy(loadingBook = null, books = s.books.map { if (it.bookId == full.bookId) full else it })
                }
            } catch (e: Exception) {
                state.update { it.copy(loadingBook = null, booksError = humanizeError(e)) }
            }
        }
    }

    fun setTopicStatus(topicId: String, status: TopicStatus) {
        state.update { it.copy(draftTopics = it.draftTopics + (topicId to status)) }
    }

    fun setChapterStatus(chapter: CurrChapter, status: TopicStatus) {
        state.update { s ->
            val next = s.draftTopics.toMutableMap()
            chapter.topics.forEach { next[it.topicId] = status }
            s.copy(draftTopics = next)
        }
    }

    fun setSessionMinutes(m: Int) = state.update { it.copy(draftMinutes = m) }

    fun setFreeHours(h: Int) = state.update { it.copy(draftFreeHours = h) }

    /**
     * پایان آنبوردینگ: پرونده ذخیره و بلافاصله برنامه ساخته می‌شود.
     *
     * دیگر هیچ چتی اول کار نیست — کاربر رشته و پایه و خوانده‌هایش را گفته،
     * پس سرور همه‌چیزِ لازم را دارد و باید برنامهٔ کامل بدهد، نه سؤال.
     */
    fun finishOnboarding() {
        if (unavailable()) return
        val s = state.value
        state.update { it.copy(savingProfile = true) }
        val p = s.profile.copy(
            studentId = Store.username ?: s.profile.studentId,
            field = s.draftTrack ?: s.profile.field,
            gradeNumber = if (s.draftGrade > 0) s.draftGrade else s.profile.gradeNumber,
            graduate = s.draftGraduate,
            examProvider = s.draftProvider ?: "none",
            grade = if (s.draftGraduate) "فارغ‌التحصیل"
                else s.books.firstOrNull { it.gradeNumber == s.draftGrade }?.grade ?: s.profile.grade,
            // فقط درس‌هایی که کاربر خواسته. اگر هیچ‌کدام را نزده، همه.
            bookIds = s.draftBooks.toList().ifEmpty { s.books.map { it.bookId } },
            topics = s.draftTopics.filterValues { it != TopicStatus.NOT_STARTED },
            // وضعیت مباحث فقط برای درس‌هایی معنی دارد که در برنامه هستند
            sessionMinutes = s.draftMinutes,
            freeHoursPerDay = s.draftFreeHours,
            onboarded = true,
        )
        PlannerStore.save(p)
        state.update { it.copy(profile = p, savingProfile = false, step = 0) }
        buildPlan()
    }

    /**
     * ساخت برنامه بدون گفتگو.
     *
     * درخواست ساختاریافته به مسیر AI-only فرستاده می‌شود. مدل برنامه و
     * request نهایی را می‌نویسد؛ کلاینت نباید تصمیم‌های برگشتی آن را جایگزین کند.
     */
    fun buildPlan(force: Boolean = false) {
        if (unavailable()) return
        val s = state.value
        if (s.building) return
        if (!force && PlannerStore.remainingToday() <= 0) {
            state.update { it.copy(error = "امروز ${PlannerStore.MAX_PLANS_PER_DAY} بار برنامه ساختی؛ فردا دوباره می‌توانی.") }
            return
        }
        state.update { it.copy(building = true, error = null) }
        viewModelScope.launch {
            try {
                val out = PlannerApi.post("/v1/plan", state.value.profile.toBaseRequest())
                if (out.optJSONObject("request") == null) {
                    out.put("request", state.value.profile.toBaseRequest())
                }
                val parsed = parsePlanResult(out)
                if (parsed != null) PlannerStore.notePlanBuilt()
                state.update {
                    it.copy(
                        building = false, result = parsed ?: it.result, reports = emptyMap(),
                        selectedDate = defaultDate(parsed), fromCache = false,
                        quotaLeft = PlannerStore.remainingToday(), profile = PlannerStore.profile.value,
                    )
                }
                if (parsed != null) persist(out)
            } catch (e: Exception) {
                state.update { it.copy(building = false, error = humanizeError(e)) }
            }
        }
    }

    /** برگشت به آنبوردینگ برای به‌روزکردن وضعیت مباحث. */
    fun reopenOnboarding() {
        state.update {
            it.copy(
                profile = it.profile.copy(onboarded = false),
                draftTopics = it.profile.topics,
                draftMinutes = it.profile.sessionMinutes,
                draftFreeHours = it.profile.freeHoursPerDay,
            )
        }
        PlannerStore.save(state.value.profile)
        state.update {
            it.copy(step = 0, draftTrack = it.profile.field, draftGrade = it.profile.gradeNumber,
                draftGraduate = it.profile.graduate, draftProvider = it.profile.examProvider,
                draftBooks = it.profile.bookIds.toSet())
        }
        if (state.value.tracks.isEmpty()) loadTracks()
    }

    /* ------------------------------------------------------------------ */
    /*  گفتگو                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * ارسال پیام.
     *
     * هر پیام در این سرویس یک برنامهٔ کامل تولید می‌کند، پس «پیام فرستادن» و
     * «برنامهٔ تازه گرفتن» یک چیزند. دو محافظ گذاشته شده:
     *
     *  ۱. سقف روزانه، که هم اعتبار مدل را حفظ می‌کند هم جلوی عادت بد
     *     «هر روز برنامه عوض کن» را می‌گیرد — برنامه‌ای که اجرا نشود ارزشی ندارد.
     *  ۲. تأیید جایگزینی، وقتی برنامهٔ فعلی کمتر از ۲۰ ساعت عمر دارد. کسی که
     *     صبح برنامه گرفته و ظهر پشیمان شده، باید یک‌بار آگاهانه تأیید کند.
     */
    fun send(text: String, confirmedReplace: Boolean = false) {
        if (unavailable()) return
        val msg = text.trim()
        if (msg.isEmpty() || state.value.sending) return

        if (PlannerStore.remainingToday() <= 0) {
            state.update {
                it.copy(
                    quotaLeft = 0,
                    messages = it.messages + PlannerMessage(false,
                        "امروز ${PlannerStore.MAX_PLANS_PER_DAY} بار برنامه ساختی. برنامه وقتی جواب می‌دهد که اجرا شود، نه وقتی عوض شود — فردا دوباره می‌توانی. تا آن موقع همین برنامه را جلو ببر و جلسه‌ها را تیک بزن."),
                )
            }
            return
        }
        if (!confirmedReplace && state.value.hasPlan && PlannerStore.needsReplaceConfirm()) {
            state.update { it.copy(pendingConfirm = msg) }
            return
        }

        // گفتگو برنامه نمی‌سازد، فقط برنامهٔ موجود را عوض می‌کند یا توضیح می‌دهد.
        // قبلاً اگر برنامه‌ای نبود، پروندهٔ کاربر به‌عنوان پایه فرستاده می‌شد و چت
        // یک برنامهٔ دوم و ناهمگون می‌ساخت که با چیزی که در تب «برنامه» بود نمی‌خواند.
        val baseReq = state.value.result?.request
        if (baseReq == null) {
            state.update {
                it.copy(
                    pendingConfirm = null,
                    messages = it.messages + PlannerMessage(true, msg) + PlannerMessage(
                        false,
                        "هنوز برنامه‌ای نداری که رویش کار کنم. اول از تب «برنامه» یک برنامه بساز، " +
                            "بعد اینجا بگو چه تغییری می‌خواهی — مثلاً «جمعه‌ها را خالی کن» یا «فصل ۳ زیست را هم اضافه کن».",
                    ),
                )
            }
            return
        }

        state.update {
            it.copy(sending = true, error = null, pendingConfirm = null,
                messages = it.messages + PlannerMessage(true, msg) + PlannerMessage(false, "", pending = true))
        }
        viewModelScope.launch {
            try {
                val body = JSONObject()
                    .put("message", msg)
                    .put("history", JSONArray().apply {
                        state.value.messages.filter { !it.pending && it.text.isNotBlank() }.dropLast(1).takeLast(8)
                            .forEach { put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text)) }
                    })

                // درخواست پایه همیشه همان برنامهٔ فعلی است.
                body.put("base_request", baseReq)
                currentPlanPayload?.optJSONObject("plan")?.let { body.put("current_plan", it) }

                val out = PlannerApi.post("/v1/plan/chat", body)
                val reply = out.optString("reply_fa").ifBlank { "متوجه نشدم؛ کمی دقیق‌تر بگو." }
                val resultObj = out.optJSONObject("result")
                val parsed = resultObj?.let { r ->
                    // درخواست کنار نتیجه می‌آید نه داخلش؛ برای ریپلن باید همراهش ذخیره شود.
                    out.optJSONObject("request")?.let { r.put("request", it) }
                    parsePlanResult(r)
                }
                if (parsed != null) PlannerStore.notePlanBuilt()
                state.update { s ->
                    s.copy(
                        sending = false,
                        messages = s.messages.dropLast(1) + PlannerMessage(false, reply),
                        result = parsed ?: s.result,
                        selectedDate = if (parsed != null) defaultDate(parsed) else s.selectedDate,
                        reports = if (parsed != null) emptyMap() else s.reports,
                        fromCache = false,
                        quotaLeft = PlannerStore.remainingToday(),
                        profile = PlannerStore.profile.value,
                    )
                }
                if (resultObj != null) persist(resultObj)
            } catch (e: Exception) {
                val why = humanizeError(e)
                state.update { s ->
                    s.copy(sending = false, error = why,
                        messages = s.messages.dropLast(1) + PlannerMessage(false, why))
                }
            }
        }
    }

    fun confirmReplace() {
        val pending = state.value.pendingConfirm ?: return
        send(pending, confirmedReplace = true)
    }

    fun dismissConfirm() = state.update { it.copy(pendingConfirm = null) }

    fun clearError() = state.update { it.copy(error = null) }

    fun selectDate(date: String) = state.update { it.copy(selectedDate = date) }

    /* ------------------------------------------------------------------ */
    /*  گزارش جلسه و بازبرنامه‌ریزی                                        */
    /* ------------------------------------------------------------------ */

    fun toggleDone(task: PlanTask) {
        state.update { s ->
            val cur = s.reports[task.taskId]
            val next = if (cur?.completed == true) s.reports - task.taskId
            else s.reports + (task.taskId to SessionReport(true, task.durationMinutes))
            s.copy(reports = next)
        }
        persistReportsOnly()
        // تیک‌زدن یعنی مبحث خوانده شد؛ پروندهٔ کاربر هم باید جلو برود، وگرنه
        // دورهٔ بعد دوباره از همان‌جا شروع می‌کند.
        if (task.topicId != null && state.value.reports[task.taskId]?.completed == true) {
            val p = state.value.profile
            val cur = p.statusOf(task.topicId)
            if (cur.ordinal < TopicStatus.STUDIED.ordinal) {
                val next = p.copy(topics = p.topics + (task.topicId to TopicStatus.STUDIED))
                PlannerStore.save(next)
                state.update { it.copy(profile = next) }
            }
        }
    }

    fun report(task: PlanTask, report: SessionReport) {
        state.update { it.copy(reports = it.reports + (task.taskId to report)) }
        persistReportsOnly()
    }

    /*
     * گزارش‌ها باید همان لحظه روی دیسک بروند، نه موقع ساخت برنامهٔ بعدی:
     * بررسی شبانه در یک پراسس دیگر اجرا می‌شود و فقط چیزی را می‌بیند که ذخیره
     * شده است.
     */
    private fun persistReportsOnly() {
        viewModelScope.launch {
            val raw = Cache.get(Cache.PLANNER, maxAgeMs = 30L * 24 * 60 * 60 * 1000) ?: return@launch
            runCatching {
                val saved = JSONObject(raw)
                saved.put("reports", JSONObject().apply {
                    state.value.reports.forEach { (k, v) ->
                        put(k, JSONObject().put("completed", v.completed).put("minutes", v.minutes))
                    }
                })
                Cache.put(Cache.PLANNER, saved.toString())
            }
        }
    }

    /**
     * دورهٔ بعد را بر پایهٔ همین گزارش‌ها می‌سازد.
     *
     * فقط «انجام شد/نشد» کافی نیست: علت غلط‌ها هم فرستاده می‌شود، چون موتور از
     * روی همان تصمیم می‌گیرد که آموزش مجدد بدهد یا مرور فاصله‌دار.
     */
    fun replan() {
        if (unavailable()) return
        val s = state.value
        val req = s.result?.request ?: run {
            state.update { it.copy(error = "برای بازبرنامه‌ریزی اول باید یک برنامه بسازی") }; return
        }
        if (s.replanning) return
        state.update { it.copy(replanning = true, error = null) }
        viewModelScope.launch {
            try {
                val progress = JSONArray()
                s.days.flatMap { it.tasks }.forEach { t ->
                    val r = s.reports[t.taskId] ?: SessionReport(false, 0)
                    if (t.topicId == null) return@forEach
                    val e = JSONObject()
                        .put("topic_id", t.topicId)
                        .put("date", t.date)
                        .put("type", t.type)
                        .put("planned_minutes", t.durationMinutes)
                        .put("minutes", r.minutes)
                        .put("completed", r.completed)
                    if (r.mistakes.isNotEmpty()) {
                        e.put("mistake_reasons", JSONObject().apply { r.mistakes.forEach { (k, v) -> put(k, v) } })
                    }
                    if (r.attempted > 0) {
                        e.put("attempted", r.attempted).put("correct", r.correct)
                            .put("wrong", (r.attempted - r.correct).coerceAtLeast(0))
                    }
                    progress.put(e)
                }
                val out = PlannerApi.post("/v1/plan/replan", JSONObject()
                    .put("request", req).put("progress", progress).put("from_date", IranTime.todayIso())
                    .apply { currentPlanPayload?.optJSONObject("plan")?.let { put("current_plan", it) } })
                out.optJSONObject("request")?.let { out.put("request", it) }
                val parsed = parsePlanResult(out)
                val notes = out.optJSONObject("replan")?.optJSONArray("changes_fa")?.let { a ->
                    (0 until a.length()).map { a.optString(it) }
                }.orEmpty()
                if (parsed != null) PlannerStore.notePlanBuilt()
                state.update {
                    it.copy(replanning = false, result = parsed ?: it.result, replanNotes = notes,
                        reports = emptyMap(), selectedDate = defaultDate(parsed), fromCache = false,
                        quotaLeft = PlannerStore.remainingToday(),
                        messages = it.messages + PlannerMessage(false,
                            if (notes.isEmpty()) "برنامه‌ی دوره‌ی بعد ساخته شد." else "برنامه بازنگری شد:\n• " + notes.joinToString("\n• ")))
                }
                if (parsed != null) persist(out)
            } catch (e: Exception) {
                state.update { it.copy(replanning = false, error = humanizeError(e)) }
            }
        }
    }

    fun reset() {
        currentPlanPayload = null
        Cache.forget(Cache.PLANNER)
        state.value = State(booting = false, profile = state.value.profile)
    }
}
