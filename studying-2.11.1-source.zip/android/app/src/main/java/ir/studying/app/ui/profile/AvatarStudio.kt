@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.studying.app.ui.profile

import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import ir.studying.app.core.Api
import ir.studying.app.core.Avatars
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.GlassPill
import ir.studying.app.ui.components.StarField
import ir.studying.app.ui.components.bouncyClick
import ir.studying.app.ui.components.shine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/*
 * استودیوی کاراکتر — نسخهٔ ۲.۹.
 *
 * ده کاراکتر سه‌بعدیِ اختصاصی (av_01…av_10) جای آواتارهای تخت قبلی را
 * گرفته‌اند. کلیدها همان a1…a10 مانده‌اند، پس هیچ پروفایلی روی سرور عوض
 * نمی‌شود؛ فقط تصویری که هر نسخه از روی کلید رندر می‌کند تازه شده است.
 *
 * انتخابگر شبیه صفحهٔ «انتخاب شخصیت» بازی‌هاست: صحنه‌ای با نورافکن و سکو،
 * کاراکترها روی چرخ‌فلکی که با کشیدن انگشت می‌چرخد، و کاراکتر وسط که زنده
 * است (شناور، با هالهٔ چرخان و سایهٔ روی سکو). همه‌چیز با Canvas و
 * graphicsLayer کشیده می‌شود؛ هیچ کتابخانهٔ سه‌بعدی‌ای اضافه نشده است.
 */

private const val TAU = (2.0 * PI).toFloat()

internal fun Avatars.Character.accent(): Color = Color(color)
internal fun Avatars.Character.accent2(): Color = Color(glow)

/**
 * انتخاب کاراکتر روی سرور و ذخیرهٔ محلی — همان مسیر قدیمی «avatar_pick».
 *
 * چرا یک تابع مشترک: هم صفحهٔ ویرایش پروفایل و هم استودیوی بازشونده از
 * صفحهٔ پروفایل از آن استفاده می‌کنند؛ اگر دو نسخه بود، یکی‌شان دیر یا زود
 * فراموش می‌کرد Store را به‌روز کند و آواتار سرصفحه کهنه می‌ماند.
 */
internal suspend fun pickCharacter(key: String): Result<String> = runCatching {
    Api.post("avatar_pick", JSONObject().put("avatar_key", key))
    val v = Avatars.value(key)
    Store.setAvatar(v)
    v
}

// ============================================================ کاراکتر زنده

/**
 * کاراکتر سه‌بعدی زنده.
 *
 * تصویرها خودشان سه‌بعدی رندر شده‌اند؛ این‌جا «جان» می‌گیرند: آرام شناور
 * می‌شوند، کمی دور محور عمودی می‌چرخند (rotationY با فاصلهٔ دوربین برای حس
 * عمق)، هالهٔ رنگیِ خودشان دورشان می‌چرخد و سایه‌شان با بالا رفتن کوچک
 * می‌شود. [active] که خاموش باشد، همه‌چیز نرم به حالت ساکن برمی‌گردد.
 */
@Composable
fun CharacterAvatar3D(
    key: String,
    size: Dp,
    modifier: Modifier = Modifier,
    active: Boolean = true,
    shadow: Boolean = true,
    selected: Boolean = false,
) {
    val ch = Avatars.characterOf(key) ?: Avatars.characters.first()
    val c1 = ch.accent()
    val c2 = ch.accent2()
    val on = animateFloatAsState(if (active) 1f else 0f, tween(480), label = "charOn")
    val t = rememberInfiniteTransition(label = "char3d")
    val spin = t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(6400, easing = LinearEasing)), label = "charSpin",
    )
    val bob = t.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "charBob",
    )
    val sway = t.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(3300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "charSway",
    )
    val twinkle = t.animateFloat(
        0f, TAU, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "charTwinkle",
    )
    val seed = remember(key) { (abs(key.hashCode()) % 360).toFloat() }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val r = this.size.minDimension / 2f
            val ctr = center
            val k = on.value
            if (k > 0.01f) {
                /* درخشش نرم پشت سر */
                drawCircle(
                    Brush.radialGradient(listOf(c1.copy(alpha = 0.55f * k), Color.Transparent), ctr, r),
                    r, ctr,
                )
                /* هالهٔ دنباله‌دار چرخان + یک ماهوارهٔ نورانی */
                rotate(spin.value + seed, ctr) {
                    drawCircle(
                        Brush.sweepGradient(
                            listOf(
                                c2.copy(alpha = 0f),
                                c2.copy(alpha = 0.35f * k),
                                c1.copy(alpha = 0.95f * k),
                                Color.White.copy(alpha = 0.95f * k),
                            ),
                            ctr,
                        ),
                        radius = r * 0.9f,
                        center = ctr,
                        style = Stroke(r * 0.045f, cap = StrokeCap.Round),
                    )
                    val sat = Offset(ctr.x + r * 0.9f, ctr.y)
                    drawCircle(c2.copy(alpha = 0.45f * k), r * 0.11f, sat)
                    drawCircle(Color.White.copy(alpha = k), r * 0.045f, sat)
                }
                /* جرقه‌های چهارپر روی مدار بیرونی */
                for (i in 0 until 4) {
                    val ang = i * TAU / 4f + 0.6f + seed / 57f
                    val tw = 0.5f + 0.5f * sin(twinkle.value * (1 + i % 2) + i * 1.7f)
                    if (tw < 0.15f) continue
                    val p = Offset(ctr.x + cos(ang) * r * 0.99f, ctr.y + sin(ang) * r * 0.99f)
                    sparkle(p, r * 0.075f * tw, Color.White.copy(alpha = (0.35f + 0.65f * tw) * k))
                }
            }
            if (shadow) {
                /* سایهٔ کف: کاراکتر که بالا می‌رود، سایه کوچک‌تر و کم‌رنگ‌تر می‌شود */
                val lift = (bob.value + 1f) / 2f * k
                val w = r * (0.62f - 0.14f * lift)
                val c = Offset(ctr.x, ctr.y + r * 0.9f)
                withTransform({ scale(1f, 0.2f, c) }) {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(Color.Black.copy(alpha = 0.42f - 0.16f * lift), Color.Transparent), c, w,
                        ),
                        w, c,
                    )
                }
            }
        }
        val d = size * 0.78f
        Image(
            painter = painterResource(Avatars.drawableForKey(ch.key)),
            contentDescription = ch.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(d)
                .graphicsLayer {
                    val k = on.value
                    translationY = (-bob.value * 0.045f - 0.03f) * d.toPx() * k
                    rotationY = sway.value * 11f * k
                    rotationZ = sway.value * 1.8f * k
                    cameraDistance = 12f * density
                    shape = CircleShape
                    clip = true
                }
                .border(
                    2.dp,
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.85f), c1.copy(alpha = 0.55f))),
                    CircleShape,
                )
                .drawWithContent {
                    drawContent()
                    /* برق شیشه‌ای بالا-چپ و سایهٔ حجمی پایین */
                    drawCircle(
                        Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.26f), Color.Transparent),
                            center = Offset(this.size.width * 0.3f, this.size.height * 0.2f),
                            radius = this.size.width * 0.42f,
                        ),
                    )
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.16f)),
                            startY = this.size.height * 0.6f,
                        ),
                    )
                },
        )
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = size * 0.15f, end = size * 0.15f)
                    .size(size * 0.17f)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(c1, lerp(c1, c2, 0.5f))))
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(size * 0.11f))
            }
        }
    }
}

/** جرقهٔ چهارپر. */
private fun DrawScope.sparkle(c: Offset, r: Float, color: Color) {
    if (r <= 0f) return
    val p = Path().apply {
        moveTo(c.x, c.y - r)
        quadraticBezierTo(c.x, c.y, c.x + r, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y + r)
        quadraticBezierTo(c.x, c.y, c.x - r, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y - r)
        close()
    }
    drawPath(p, color)
}

// ============================================================ استودیو

/**
 * انتخابگر کاراکتر: صحنهٔ نورپردازی‌شده + چرخ‌فلک سه‌بعدی.
 *
 * [autoSelect] روشن: با ایستادن چرخ روی هر کاراکتر همان انتخاب می‌شود (برای
 * ثبت‌نام که فقط حالت محلی است). خاموش: دکمهٔ تأیید ظاهر می‌شود تا با هر
 * بار چرخاندن درخواستی به سرور نرود (ویرایش پروفایل).
 *
 * [compact] برای صفحهٔ ثبت‌نام است که باید کوتاه بماند: صحنهٔ کوتاه‌تر،
 * بی‌کارت ویژگی‌ها و بی‌ردیف بندانگشتی.
 */
@Composable
fun AvatarStudio(
    selectedKey: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    photoUri: Uri? = null,
    onGallery: (() -> Unit)? = null,
    compact: Boolean = false,
    autoSelect: Boolean = true,
    busy: Boolean = false,
) {
    val keys = Avatars.keys
    val cs = MaterialTheme.colorScheme
    val pager = rememberPagerState(initialPage = keys.indexOf(selectedKey).coerceAtLeast(0)) { keys.size }
    val scope = rememberCoroutineScope()
    val select by rememberUpdatedState(onSelect)
    val auto by rememberUpdatedState(autoSelect)
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val dir = if (rtl) -1f else 1f

    LaunchedEffect(pager) {
        snapshotFlow { pager.settledPage }.drop(1).collect { if (auto) select(keys[it]) }
    }
    LaunchedEffect(selectedKey) {
        val i = keys.indexOf(selectedKey)
        if (i >= 0 && i != pager.currentPage && !pager.isScrollInProgress) pager.animateScrollToPage(i)
    }

    val cur = Avatars.characters[pager.currentPage.coerceIn(0, keys.lastIndex)]
    val acc = animateColorAsState(cur.accent(), tween(520), label = "stageAcc")
    val acc2 = animateColorAsState(cur.accent2(), tween(520), label = "stageAcc2")

    /* هر بار که چرخ می‌ایستد: کاراکتر با فنر «پاپ» می‌کند و جرقه‌ها می‌پاشند. */
    val pop = remember { Animatable(1f) }
    val burst = remember { Animatable(1f) }
    LaunchedEffect(pager.settledPage) {
        launch { pop.snapTo(0.86f); pop.animateTo(1f, spring(dampingRatio = 0.36f, stiffness = 420f)) }
        launch { burst.snapTo(0f); burst.animateTo(1f, tween(950, easing = FastOutSlowInEasing)) }
    }
    val pulse = rememberInfiniteTransition(label = "podium").animateFloat(
        0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "podiumP",
    )

    val stageH = if (compact) 160.dp else 262.dp
    val item = if (compact) 106.dp else 166.dp
    val podiumY = if (compact) 0.87f else 0.85f
    val bottomPad = stageH * (1f - podiumY) - item * 0.05f
    val shape = RoundedCornerShape(if (compact) 24.dp else 30.dp)

    Column(modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(stageH)
                .clip(shape)
                .drawBehind {
                    val a = acc.value
                    drawRect(
                        Brush.verticalGradient(
                            listOf(lerp(a, Color(0xFF0B1026), 0.3f), lerp(a, Color(0xFF060816), 0.82f)),
                        ),
                    )
                    val top = Offset(size.width / 2f, -size.height * 0.1f)
                    drawCircle(
                        Brush.radialGradient(listOf(Color.White.copy(alpha = 0.2f), Color.Transparent), top, size.height),
                        size.height, top,
                    )
                }
                .border(
                    1.dp,
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.3f), Color.White.copy(alpha = 0.04f))),
                    shape,
                ),
        ) {
            StarField(Modifier.matchParentSize(), count = if (compact) 18 else 30, seed = 11, maxAlpha = 0.55f)
            /* نورافکن و سکو */
            Canvas(Modifier.matchParentSize()) {
                val cx = size.width / 2f
                val py = size.height * podiumY
                val ip = item.toPx()
                val cone = Path().apply {
                    moveTo(cx - ip * 0.16f, 0f)
                    lineTo(cx + ip * 0.16f, 0f)
                    lineTo(cx + ip * 0.7f, py)
                    lineTo(cx - ip * 0.7f, py)
                    close()
                }
                drawPath(
                    cone,
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.015f)), 0f, py,
                    ),
                )
                val pc = Offset(cx, py)
                withTransform({ scale(1f, 0.24f, pc) }) {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(acc2.value.copy(alpha = 0.7f), acc.value.copy(alpha = 0.22f), Color.Transparent),
                            pc, ip * 0.85f,
                        ),
                        ip * 0.85f, pc,
                    )
                }
                val rw = ip * 0.62f
                val rh = rw * 0.24f
                drawOval(
                    Color.White.copy(alpha = 0.32f),
                    Offset(cx - rw, py - rh), Size(rw * 2, rh * 2),
                    style = Stroke(1.4.dp.toPx()),
                )
                val p = pulse.value
                val pw = rw * (1f + 0.5f * p)
                val ph = pw * 0.24f
                drawOval(
                    acc2.value.copy(alpha = 0.55f * (1f - p)),
                    Offset(cx - pw, py - ph), Size(pw * 2, ph * 2),
                    style = Stroke(1.8.dp.toPx()),
                )
            }
            BoxWithConstraints(Modifier.matchParentSize()) {
                val side = ((maxWidth - item) / 2).coerceAtLeast(0.dp)
                HorizontalPager(
                    state = pager,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = side),
                    pageSize = PageSize.Fixed(item),
                    beyondBoundsPageCount = 3,
                    key = { keys[it] },
                ) { page ->
                    val k = keys[page]
                    Box(Modifier.fillMaxHeight().width(item)) {
                        CharacterAvatar3D(
                            key = k,
                            size = item,
                            active = page == pager.currentPage && photoUri == null,
                            selected = !autoSelect && photoUri == null && k == selectedKey,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = bottomPad)
                                .graphicsLayer {
                                    /* فاصلهٔ این صفحه از مرکز چرخ؛ مثبت یعنی «بعدی». */
                                    val rel = page - (pager.currentPage + pager.currentPageOffsetFraction)
                                    val a = abs(rel)
                                    val near = a.coerceAtMost(1f)
                                    val far = (a - 1f).coerceIn(0f, 1.5f)
                                    val p = if (page == pager.settledPage) pop.value else 1f
                                    val s = (1f - 0.26f * near - 0.14f * far) * p
                                    scaleX = s
                                    scaleY = s
                                    alpha = (1f - 0.32f * a).coerceIn(0f, 1f)
                                    rotationY = rel.coerceIn(-2f, 2f) * -30f * dir
                                    translationX = -rel * size.width * 0.12f * dir
                                    translationY = -near * size.height * 0.04f
                                    cameraDistance = 9f * density
                                    transformOrigin = TransformOrigin(0.5f, 0.95f)
                                }
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                ) {
                                    if (page != pager.currentPage) {
                                        scope.launch { pager.animateScrollToPage(page) }
                                    } else {
                                        scope.launch {
                                            pop.snapTo(0.88f)
                                            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 480f))
                                        }
                                        if (auto) select(k)
                                    }
                                },
                        )
                    }
                }
            }
            /* جرقه‌های لحظهٔ انتخاب */
            Canvas(Modifier.matchParentSize()) {
                val b = burst.value
                if (b >= 1f) return@Canvas
                val ip = item.toPx()
                val c = Offset(size.width / 2f, size.height - bottomPad.toPx() - ip / 2f)
                val fade = (1f - b).coerceIn(0f, 1f)
                for (i in 0 until 14) {
                    val ang = i * TAU / 14f + 0.25f
                    val dist = ip * (0.4f + (0.36f + 0.08f * (i % 3)) * b)
                    val p = Offset(c.x + cos(ang) * dist, c.y + sin(ang) * dist)
                    if (i % 3 == 0) {
                        sparkle(p, 7.dp.toPx() * (1f - 0.4f * b), Color.White.copy(alpha = fade))
                    } else {
                        drawCircle(acc2.value.copy(alpha = fade), 3.2.dp.toPx() * (1f - 0.5f * b), p)
                    }
                }
            }
            /* ردیف بالا: شمارنده و دکمهٔ گالری */
            Row(
                Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassPill(
                    (pager.currentPage + 1).fa() + " از " + keys.size.fa(),
                    leading = cur.emoji,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                )
                Spacer(Modifier.weight(1f))
                if (onGallery != null) {
                    Row(
                        Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.14f))
                            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                            .bouncyClick { onGallery() }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Rounded.AddPhotoAlternate, null,
                            tint = Color.White, modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(5.dp))
                        Text("از گالری", style = MaterialTheme.typography.labelMedium, color = Color.White)
                    }
                }
            }
            if (photoUri != null) {
                PhotoOverlay(
                    photoUri = photoUri,
                    size = item * 0.74f,
                    ring = Brush.linearGradient(listOf(acc.value, acc2.value)),
                    onChange = { onGallery?.invoke() },
                    onBack = { select(keys[pager.currentPage]) },
                )
            }
        }

        if (compact) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedContent(
                    targetState = cur,
                    transitionSpec = { nameSwap() },
                    modifier = Modifier.weight(1f),
                    label = "charNameCompact",
                ) { ch ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(ch.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            ch.tagline,
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                PageDots(count = keys.size, current = pager.currentPage, color = acc.value)
            }
        } else {
            Spacer(Modifier.height(14.dp))
            AnimatedContent(
                targetState = cur,
                transitionSpec = { nameSwap() },
                label = "charName",
            ) { ch ->
                Column(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(ch.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(8.dp))
                        Text(ch.emoji, fontSize = 22.sp)
                    }
                    Text(ch.tagline, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBar("🎯", "تمرکز", cur.focus, acc.value, acc2.value)
                StatBar("⚡", "انرژی", cur.energy, acc.value, acc2.value)
                StatBar("😜", "شیطنت", cur.mischief, acc.value, acc2.value)
            }
            Spacer(Modifier.height(14.dp))
            val rowState = rememberLazyListState()
            LaunchedEffect(pager.currentPage) {
                rowState.animateScrollToItem((pager.currentPage - 2).coerceAtLeast(0))
            }
            LazyRow(
                state = rowState,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
            ) {
                itemsIndexed(keys, key = { _, k -> k }) { i, k ->
                    Thumb(
                        key = k,
                        current = i == pager.currentPage,
                        mine = !autoSelect && photoUri == null && k == selectedKey,
                        onClick = { scope.launch { pager.animateScrollToPage(i) } },
                    )
                }
            }
            if (!autoSelect) {
                Spacer(Modifier.height(12.dp))
                val curKey = keys[pager.currentPage]
                AnimatedContent(
                    targetState = curKey == selectedKey && photoUri == null,
                    transitionSpec = { (fadeIn(tween(220)) + scaleIn(initialScale = 0.92f)) togetherWith fadeOut(tween(150)) },
                    label = "charConfirm",
                ) { mine ->
                    if (mine) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(acc.value.copy(alpha = 0.12f))
                                .border(1.dp, acc.value.copy(alpha = 0.35f), RoundedCornerShape(16.dp)),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Check, null, tint = acc.value, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "الان " + cur.name + " روی پروفایلته",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = acc.value,
                            )
                        }
                    } else {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            lerp(acc.value, Color.Black, 0.18f),
                                            acc.value,
                                            lerp(acc.value, acc2.value, 0.3f),
                                        ),
                                    ),
                                )
                                .shine(enabled = !busy)
                                .bouncyClick(enabled = !busy) { select(curKey) },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (busy) {
                                CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
                            } else {
                                Text(
                                    "✨ " + cur.name + " رو بذار روی پروفایلم",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun androidx.compose.animation.AnimatedContentTransitionScope<Avatars.Character>.nameSwap() =
    (slideInVertically(tween(320)) { it / 2 } + fadeIn(tween(260)))
        .togetherWith(slideOutVertically(tween(260)) { -it / 2 } + fadeOut(tween(180)))
        .using(SizeTransform(clip = false))

@Composable
private fun PhotoOverlay(photoUri: Uri, size: Dp, ring: Brush, onChange: () -> Unit, onBack: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC070A1A)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AsyncImage(
                model = photoUri,
                contentDescription = "عکس خودت",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .border(3.dp, ring, CircleShape)
                    .bouncyClick { onChange() },
            )
            Spacer(Modifier.height(8.dp))
            GlassPill(
                "برگشت به کاراکترها",
                leading = "↩",
                modifier = Modifier.bouncyClick { onBack() },
            )
        }
    }
}

/** نقطه‌های صفحه؛ نقطهٔ فعلی کشیده و رنگی است. */
@Composable
private fun PageDots(count: Int, current: Int, color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { i ->
            val on = i == current
            val w by animateDpAsState(if (on) 14.dp else 5.dp, spring(dampingRatio = 0.6f, stiffness = 500f), label = "dot$i")
            Box(
                Modifier
                    .size(width = w, height = 5.dp)
                    .clip(CircleShape)
                    .background(if (on) color else MaterialTheme.colorScheme.outlineVariant),
            )
        }
    }
}

/** نوار ویژگی پنج‌خانه‌ای — مثل کارت شخصیت بازی‌ها، با پر شدن فنری. */
@Composable
private fun StatBar(emoji: String, label: String, value: Int, a1: Color, a2: Color) {
    val v by animateFloatAsState(
        value.toFloat(), spring(dampingRatio = 0.72f, stiffness = 110f), label = "stat$label",
    )
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 14.sp)
        Spacer(Modifier.width(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.widthIn(min = 52.dp),
        )
        Spacer(Modifier.width(6.dp))
        Canvas(Modifier.weight(1f).height(10.dp)) {
            val n = 5
            val gap = 4.dp.toPx()
            val w = (size.width - gap * (n - 1)) / n
            val h = size.height
            val cr = CornerRadius(h / 2f)
            for (i in 0 until n) {
                val x = if (rtl) size.width - (i + 1) * w - i * gap else i * (w + gap)
                drawRoundRect(track, Offset(x, 0f), Size(w, h), cr)
                val f = (v - i).coerceIn(0f, 1f)
                if (f > 0f) {
                    val fw = w * f
                    val fx = if (rtl) x + w - fw else x
                    drawRoundRect(
                        Brush.horizontalGradient(listOf(a1, lerp(a1, a2, 0.6f)), fx, fx + fw),
                        Offset(fx, 0f), Size(fw, h), cr,
                    )
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(
            value.fa() + "/۵",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = a1,
        )
    }
}

@Composable
private fun Thumb(key: String, current: Boolean, mine: Boolean, onClick: () -> Unit) {
    val ch = Avatars.characterOf(key) ?: return
    val s by animateFloatAsState(if (current) 1.08f else 0.9f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "thumb")
    Box(
        Modifier
            .size(52.dp)
            .graphicsLayer { scaleX = s; scaleY = s }
            .border(
                if (current) 2.5.dp else 1.dp,
                if (current) Brush.linearGradient(listOf(ch.accent(), ch.accent2()))
                else SolidColor(MaterialTheme.colorScheme.outlineVariant),
                CircleShape,
            )
            .padding(3.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
    ) {
        Image(
            painter = painterResource(Avatars.drawableForKey(key)),
            contentDescription = ch.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = if (current) 1f else 0.78f },
        )
        if (mine) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 3.dp)
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(ch.accent())
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(9.dp))
            }
        }
    }
}

// ============================================================ دیالوگ استودیو

/**
 * استودیوی کاراکتر به‌صورت پنجرهٔ تمام‌عرض — از منوی آواتار صفحهٔ پروفایل.
 */
@Composable
fun CharacterPickerDialog(
    currentKey: String?,
    onDismiss: () -> Unit,
    onPicked: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var mine by remember { mutableStateOf(currentKey) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        CharacterPickerBody(
            selectedKey = mine,
            busy = busy,
            onClose = onDismiss,
            onSelect = { key ->
                if (busy) return@CharacterPickerBody
                busy = true
                scope.launch {
                    pickCharacter(key)
                        .onSuccess {
                            mine = key
                            AppSnack.show("کاراکترت عوض شد ✅")
                            onPicked(key)
                        }
                        .onFailure { AppSnack.show(it.message ?: "ذخیره نشد") }
                    busy = false
                }
            },
        )
    }
}

/** بدنهٔ بی‌حالت دیالوگ (برای پیش‌نمایش هم استفاده می‌شود). */
@Composable
internal fun CharacterPickerBody(
    selectedKey: String?,
    busy: Boolean,
    onClose: () -> Unit,
    onSelect: (String) -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(30.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 24.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 24.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("استودیوی کاراکتر", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(
                        "بچرخان، ببین و انتخاب کن",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                        .bouncyClick { onClose() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "بستن", modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            AvatarStudio(
                selectedKey = selectedKey,
                onSelect = onSelect,
                autoSelect = false,
                busy = busy,
            )
        }
    }
}
