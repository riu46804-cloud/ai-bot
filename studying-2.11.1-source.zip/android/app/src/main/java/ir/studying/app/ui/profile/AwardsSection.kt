package ir.studying.app.ui.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import ir.studying.app.core.Awards
import ir.studying.app.core.fa

/**
 * «دستاوردها» به‌صورت پنجرهٔ بازشو.
 *
 * چرا پاپ‌آپ و نه بخش همیشه‌باز: این فهرست بلند بود و وسط پروفایل نیم صفحه
 * اسکرول می‌خورد، در حالی که کاربر فقط گاهی سراغش می‌رود. حالا از روی کارت
 * امتیاز/استریک باز می‌شود و بقیهٔ وقت‌ها سر راه نیست.
 */
@Composable
fun AwardsDialog(onDismiss: () -> Unit) {
    var feed by remember { mutableStateOf(Awards.Feed(emptyList(), emptyList(), 0, false)) }
    var showAll by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { feed = Awards.load() }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(18.dp).heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                Text("دستاوردها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (!feed.ready) {
                    Text("در حال خواندن…", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text(
                        ("امتیاز گرفته‌شده از دستاوردها: " + feed.xp.toString()).fa(),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(8.dp))
                    if (feed.awards.isEmpty()) {
                        Text(
                            "هنوز دستاوردی نگرفته‌ای. به هدف روزانه برس، رتبهٔ اول روز شو، قفل گوشی را کامل تحمل کن یا یک رقابت را ببر.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        val shown = if (showAll) feed.awards else feed.awards.take(5)
                        shown.forEach { a ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(a.emoji, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(a.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    if (a.note.isNotBlank()) {
                                        Text(
                                            a.note.fa(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                                Text(("+" + a.xp.toString()).fa(), fontWeight = FontWeight.Bold)
                            }
                        }
                        if (feed.awards.size > 5) {
                            TextButton(onClick = { showAll = !showAll }) {
                                Text(if (showAll) "کمتر" else "همه")
                            }
                        }
                    }
                    if (feed.catalog.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text("چطور امتیاز بگیرم", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        feed.catalog.forEach { c ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    c.emoji + " " + c.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f),
                                )
                                Surface(
                                    shape = MaterialTheme.shapes.small,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                                ) {
                                    Text(
                                        ("+" + c.xp.toString() + " امتیاز · " + c.coins.toString() + " سکه").fa(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("بستن") }
                }
            }
        }
    }
}
