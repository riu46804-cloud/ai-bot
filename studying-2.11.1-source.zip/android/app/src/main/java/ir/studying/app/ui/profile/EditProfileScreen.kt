@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.profile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Api
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.ui.auth.IranPhone
import ir.studying.app.ui.components.AppCard
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.theme.AppRadius
import kotlinx.coroutines.launch
import org.json.JSONObject

/*
 * ویرایش پروفایل — بازطراحی.
 *
 * مشکل نسخهٔ قبل: همهٔ گزینه‌ها هم‌زمان روی صفحه ریخته بودند. پایهٔ تحصیلی
 * یعنی حدود پانزده تراشه در چند ردیف، زیرش رشته‌ها، زیرش نام کاربری با توضیح،
 * زیرش شماره با توضیح؛ کاربر برای عوض کردن یک اسم باید از کل این شلوغی رد
 * می‌شد و هیچ‌وقت معلوم نبود کدام دکمه چه چیزی را ذخیره می‌کند.
 *
 * طرح تازه: صفحه فقط «وضعیت فعلی» را در چند ردیف کوتاه نشان می‌دهد؛ هر انتخاب
 * در شیتِ خودش باز می‌شود و همان‌جا تمام می‌شود. پایه دو مرحله‌ای شد (اول مقطع،
 * بعد پایه) تا هیچ‌وقت بیش از چند گزینه هم‌زمان جلوی چشم نباشد. ذخیره هم یک
 * نوار چسبیده به پایین است که فقط وقتی چیزی عوض شده باشد ظاهر می‌شود.
 *
 * پایه‌ها و رشته‌ها همچنان از profile_meta می‌آیند و در اپ کپی نشده‌اند.
 */

private data class GradeOpt(val key: String, val label: String, val stage: String, val needsField: Boolean)

private data class FieldOpt(val key: String, val label: String, val emoji: String)

/** optString روی مقدار null جیسون رشتهٔ "null" می‌دهد، پس صریح پاکش می‌کنیم. */
private fun JSONObject.s(key: String): String = if (isNull(key)) "" else optString(key, "")

@Composable
fun EditProfileScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var reloadKey by remember { mutableStateOf(0) }

    var grades by remember { mutableStateOf(listOf<GradeOpt>()) }
    var fields by remember { mutableStateOf(listOf<FieldOpt>()) }
    var bioMax by remember { mutableStateOf(300) }
    var nameMax by remember { mutableStateOf(60) }
    var usernameDays by remember { mutableStateOf(30) }

    var name by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf<String?>(null) }
    var field by remember { mutableStateOf<String?>(null) }
    var savingId by remember { mutableStateOf(false) }
    var gender by remember { mutableStateOf<String?>(null) }
    var avatarValue by remember { mutableStateOf("") }

    // عکسِ اولیهٔ داده‌ها؛ تنها راه فهمیدن «چیزی عوض شده یا نه»
    var baseName by remember { mutableStateOf("") }
    var baseBio by remember { mutableStateOf("") }
    var baseGrade by remember { mutableStateOf<String?>(null) }
    var baseField by remember { mutableStateOf<String?>(null) }
    var baseGender by remember { mutableStateOf<String?>(null) }

    var username by remember { mutableStateOf("") }
    var currentUsername by remember { mutableStateOf("") }
    var waitDays by remember { mutableStateOf(0) }
    var savingUser by remember { mutableStateOf(false) }

    var phoneMasked by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var phoneStep by remember { mutableStateOf(1) }
    var phoneBusy by remember { mutableStateOf(false) }

    // "" | "grade" | "field" | "username" | "phone"
    var sheet by remember { mutableStateOf("") }

    LaunchedEffect(reloadKey) {
        loading = true
        loadError = null
        runCatching {
            val meta = Api.obj(Api.get("profile_meta"))
            val me = Api.obj(Api.get("profile_me"))

            val ga = meta.optJSONArray("grades")
            val gl = ArrayList<GradeOpt>()
            if (ga != null) for (i in 0 until ga.length()) {
                val o = ga.getJSONObject(i)
                gl.add(GradeOpt(o.s("key"), o.s("label"), o.s("stage"), o.optBoolean("field", false)))
            }
            val fj = meta.optJSONArray("fields")
            val fl = ArrayList<FieldOpt>()
            if (fj != null) for (i in 0 until fj.length()) {
                val o = fj.getJSONObject(i)
                fl.add(FieldOpt(o.s("key"), o.s("label"), o.s("emoji")))
            }

            grades = gl
            fields = fl
            bioMax = meta.optInt("bio_max", 300)
            nameMax = meta.optInt("name_max", 60)
            usernameDays = meta.optInt("username_days", 30)

            name = me.s("display_name")
            bio = me.s("bio")
            grade = me.s("grade").takeIf { it.isNotEmpty() }
            field = me.s("field").takeIf { it.isNotEmpty() }
            gender = me.s("gender").takeIf { it.isNotEmpty() }
            avatarValue = me.s("avatar")
            baseName = name; baseBio = bio; baseGrade = grade; baseField = field; baseGender = gender
            currentUsername = me.s("username")
            username = currentUsername
            waitDays = me.optInt("username_wait_days", 0)
            phoneMasked = me.s("phone_masked")
        }.onFailure { loadError = it.message ?: "در دسترس نیست" }
        loading = false
    }

    val gradeOpt = grades.firstOrNull { it.key == grade }
    val needsField = gradeOpt?.needsField == true
    val fieldOpt = fields.firstOrNull { it.key == field }
    val dirty = name != baseName || bio != baseBio || grade != baseGrade || gender != baseGender ||
        (needsField && field != baseField)

    fun save() {
        if (needsField && field == null) {
            AppSnack.show("رشتهٔ تحصیلی‌ات را هم انتخاب کن")
            return
        }
        savingId = true
        scope.launch {
            val body = JSONObject()
                .put("display_name", name.trim())
                .put("bio", bio.trim())
                .put("grade", grade ?: "")
                .put("gender", gender ?: "")
            if (needsField) body.put("field_of_study", field ?: "")
            runCatching { Api.post("profile_update", body) }
                .onSuccess {
                    baseName = name; baseBio = bio; baseGrade = grade; baseField = field; baseGender = gender
                    AppSnack.show("پروفایل ذخیره شد ✅")
                }
                .onFailure { AppSnack.show(it.message ?: "ذخیره نشد") }
            savingId = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowForward, contentDescription = "بازگشت") }
                Text("ویرایش پروفایل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                return@Column
            }

            val err = loadError
            if (err != null) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(err, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { reloadKey++ }) { Text("تلاش دوباره") }
                }
                return@Column
            }

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ProfileHero(
                    avatar = avatarValue,
                    name = name.ifBlank { currentUsername },
                    username = currentUsername,
                    gradeLabel = gradeOpt?.label,
                    fieldLabel = fieldOpt?.let { it.emoji + " " + it.label },
                )

                AppCard {
                    CardTitle("دربارهٔ تو")
                    OutlinedTextField(
                        value = name,
                        onValueChange = { if (it.length <= nameMax) name = it },
                        label = { Text("نام نمایشی") },
                        singleLine = true,
                        shape = AppRadius.chip,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { if (it.length <= bioMax) bio = it },
                        label = { Text("بیوگرافی") },
                        shape = AppRadius.chip,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 92.dp),
                    )
                    Spacer(Modifier.height(6.dp))
                    // شمارندهٔ خطی: وقتی به سقف نزدیک می‌شوی رنگ عوض می‌شود
                    CharMeter(used = bio.length, max = bioMax)
                }

                AppCard {
                    CardTitle("کاراکتر پروفایل")
                    /*
                     * کاراکترهای سه‌بعدی داخل خود اپ‌اند: انتخابشان فقط یک کلید کوتاه
                     * روی سرور ذخیره می‌کند، پس نه آپلودی هست و نه ترافیکی. چرخاندن
                     * چرخ‌فلک درخواستی نمی‌فرستد؛ فقط دکمهٔ تأیید.
                     */
                    var picking by remember { mutableStateOf(false) }
                    AvatarStudio(
                        selectedKey = ir.studying.app.core.Avatars.keyOf(avatarValue),
                        onSelect = { key ->
                            if (!picking) {
                                picking = true
                                scope.launch {
                                    pickCharacter(key)
                                        .onSuccess {
                                            avatarValue = it
                                            AppSnack.show("کاراکترت عوض شد ✅")
                                        }
                                        .onFailure { AppSnack.show(it.message ?: "ذخیره نشد") }
                                    picking = false
                                }
                            }
                        },
                        onGallery = { AppSnack.show("برای عکس شخصی، از صفحهٔ پروفایل عکس بگذار") },
                        autoSelect = false,
                        busy = picking,
                    )
                }

                AppCard {
                    CardTitle("تحصیل")
                    ir.studying.app.ui.auth.AuthChoiceRow(
                        label = "جنسیت",
                        items = ir.studying.app.data.Edu.genders,
                        selected = gender,
                    ) { gender = it }
                    Spacer(Modifier.height(10.dp))
                    PickRow(
                        icon = Icons.Rounded.School,
                        title = "پایهٔ تحصیلی",
                        value = gradeOpt?.label,
                        placeholder = "انتخاب کن",
                        onClick = { sheet = "grade" },
                    )
                    if (needsField) {
                        RowDivider()
                        PickRow(
                            icon = Icons.Rounded.Science,
                            title = "رشتهٔ تحصیلی",
                            value = fieldOpt?.let { it.emoji + " " + it.label },
                            placeholder = "انتخاب کن",
                            warn = field == null,
                            onClick = { sheet = "field" },
                        )
                    }
                }

                AppCard {
                    CardTitle("حساب کاربری")
                    PickRow(
                        icon = Icons.Rounded.AlternateEmail,
                        title = "نام کاربری",
                        value = if (currentUsername.isNotBlank()) "@" + currentUsername else null,
                        placeholder = "ثبت نشده",
                        trailing = if (waitDays > 0) waitDays.fa() + " روز تا تغییر بعدی" else null,
                        locked = waitDays > 0,
                        onClick = { username = currentUsername; sheet = "username" },
                    )
                    RowDivider()
                    PickRow(
                        icon = Icons.Rounded.Phone,
                        title = "شمارهٔ موبایل",
                        value = phoneMasked.takeIf { it.isNotEmpty() }?.fa(),
                        placeholder = "ثبت نشده",
                        onClick = { newPhone = ""; code = ""; phoneStep = 1; sheet = "phone" },
                    )
                }

                Spacer(Modifier.height(90.dp))
            }
        }

        // نوار ذخیره: فقط وقتی چیزی عوض شده باشد بالا می‌آید. قبلاً دکمهٔ ذخیره
        // وسط صفحه گم بود و معلوم نبود کدام بخش را ذخیره می‌کند.
        AnimatedVisibility(
            visible = dirty && !loading && loadError == null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Surface(
                color = cs.surface,
                tonalElevation = 3.dp,
                shadowElevation = 12.dp,
                shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "تغییرات ذخیره نشده",
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = { name = baseName; bio = baseBio; grade = baseGrade; field = baseField },
                        enabled = !savingId,
                    ) { Text("برگرداندن") }
                    Spacer(Modifier.width(6.dp))
                    Button(onClick = { save() }, enabled = !savingId, modifier = Modifier.height(46.dp)) {
                        Text(if (savingId) "در حال ذخیره…" else "ذخیره")
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- شیت‌ها

    if (sheet == "grade") {
        val stages = remember(grades) { grades.map { it.stage }.distinct() }
        var stage by remember(grades, grade) {
            mutableStateOf(gradeOpt?.stage ?: stages.firstOrNull().orEmpty())
        }
        PickSheet(title = "پایهٔ تحصیلی", subtitle = "اول مقطع، بعد پایه", onDismiss = { sheet = "" }) {
            // مرحلهٔ اول: مقطع. با این کار هیچ‌وقت بیش از چند گزینه جلوی چشم نیست.
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                stages.forEach { st ->
                    StagePill(text = st, selected = st == stage) { stage = st }
                }
            }
            Spacer(Modifier.height(12.dp))
            grades.filter { it.stage == stage }.forEach { g ->
                OptionRow(
                    label = g.label,
                    selected = grade == g.key,
                    onClick = {
                        grade = g.key
                        if (!g.needsField) field = null
                        sheet = if (g.needsField && field == null) "field" else ""
                    },
                )
            }
            Spacer(Modifier.height(4.dp))
            TextButton(onClick = { grade = null; field = null; sheet = "" }) { Text("پاک کردن انتخاب") }
        }
    }

    if (sheet == "field") {
        PickSheet(title = "رشتهٔ تحصیلی", subtitle = null, onDismiss = { sheet = "" }) {
            fields.forEach { f ->
                OptionRow(
                    label = f.label,
                    emoji = f.emoji,
                    selected = field == f.key,
                    onClick = { field = f.key; sheet = "" },
                )
            }
        }
    }

    if (sheet == "username") {
        PickSheet(title = "نام کاربری", subtitle = "آدرس پروفایلت با همین ساخته می‌شود", onDismiss = { sheet = "" }) {
            OutlinedTextField(
                value = username,
                onValueChange = { username = it.trim() },
                label = { Text("بدون @") },
                singleLine = true,
                enabled = waitDays == 0,
                shape = AppRadius.chip,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (waitDays > 0)
                    "هر " + usernameDays.fa() + " روز یک بار می‌شود عوضش کرد؛ " + waitDays.fa() + " روز دیگر."
                else
                    "بعد از تغییر، لینک‌های قبلیِ پروفایلت کار نمی‌کنند.",
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    savingUser = true
                    scope.launch {
                        runCatching { Api.obj(Api.post("profile_username", JSONObject().put("username", username))) }
                            .onSuccess { res ->
                                val next = res.s("username").takeIf { it.isNotEmpty() } ?: username
                                Store.token?.let { Store.saveSession(it, next) }
                                currentUsername = next
                                username = next
                                waitDays = usernameDays
                                sheet = ""
                                AppSnack.show("نام کاربری عوض شد ✅")
                            }
                            .onFailure { AppSnack.show(it.message ?: "عوض نشد") }
                        savingUser = false
                    }
                },
                enabled = !savingUser && waitDays == 0 && username.isNotBlank() && username != currentUsername,
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) { Text("ثبت نام کاربری") }
        }
    }

    if (sheet == "phone") {
        PickSheet(
            title = "شمارهٔ موبایل",
            subtitle = if (phoneMasked.isNotEmpty()) "الان: " + phoneMasked.fa() else null,
            onDismiss = { sheet = "" },
        ) {
            OutlinedTextField(
                value = newPhone,
                onValueChange = { newPhone = IranPhone.typing(it) },
                label = { Text("شمارهٔ جدید") },
                placeholder = { Text(IranPhone.HINT) },
                singleLine = true,
                enabled = phoneStep == 1,
                shape = AppRadius.chip,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
            )
            if (phoneStep == 2) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { v -> if (v.length <= 6) code = v.filter { c -> c.isDigit() } },
                    label = { Text("کد پیامکی") },
                    singleLine = true,
                    shape = AppRadius.chip,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        phoneBusy = true
                        scope.launch {
                            if (phoneStep == 1) {
                                val norm = IranPhone.normalize(newPhone)
                                if (norm == null) {
                                    AppSnack.show("شمارهٔ موبایل معتبر نیست")
                                } else {
                                    runCatching { Api.post("otp_request_register", JSONObject().put("phone", norm)) }
                                        .onSuccess { phoneStep = 2; AppSnack.show("کد فرستاده شد 📩") }
                                        .onFailure { AppSnack.show(it.message ?: "کد فرستاده نشد") }
                                }
                            } else {
                                val norm = IranPhone.normalize(newPhone) ?: ""
                                runCatching {
                                    val v = Api.obj(Api.post(
                                        "otp_verify_register",
                                        JSONObject().put("phone", norm).put("code", code),
                                    ))
                                    val ticket = v.s("ticket")
                                    if (ticket.isEmpty()) throw IllegalStateException("بلیت تأیید دریافت نشد")
                                    Api.obj(Api.post("profile_phone", JSONObject().put("ticket", ticket)))
                                }
                                    .onSuccess { res ->
                                        phoneMasked = res.s("phone_masked")
                                        sheet = ""
                                        AppSnack.show("شماره عوض شد ✅")
                                    }
                                    .onFailure { AppSnack.show(it.message ?: "تأیید نشد") }
                            }
                            phoneBusy = false
                        }
                    },
                    enabled = !phoneBusy,
                    modifier = Modifier.weight(1f).height(48.dp),
                ) { Text(if (phoneStep == 1) "ارسال کد" else "تأیید و ثبت") }
                if (phoneStep == 2) {
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { phoneStep = 1; code = "" }, enabled = !phoneBusy) { Text("اصلاح شماره") }
                }
            }
        }
    }
}

// ==================================================================== اجزا

/** سرصفحهٔ شاخص: همان چیزی که بقیه در پروفایلت می‌بینند. */
@Composable
private fun ProfileHero(avatar: String?, name: String, username: String, gradeLabel: String?, fieldLabel: String?) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.hero)
            .background(
                Brush.verticalGradient(
                    listOf(cs.primary.copy(alpha = 0.20f), cs.secondary.copy(alpha = 0.07f)),
                ),
            )
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), AppRadius.hero)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            /* کاراکتر سه‌بعدی زنده، عکس شخصی، یا حرف اول — به همین ترتیب. */
            val charKey = ir.studying.app.core.Avatars.keyOf(avatar)
            if (charKey != null) {
                CharacterAvatar3D(charKey, size = 74.dp)
            } else if (!avatar.isNullOrBlank()) {
                ir.studying.app.ui.components.Avatar(username.ifBlank { name }, size = 58.dp, avatarUrl = avatar)
            } else {
                Box(
                    Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(cs.primary, cs.tertiary))),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        name.trim().take(1).ifBlank { "?" },
                        color = cs.onPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                    )
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    name.ifBlank { "بدون نام" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                )
                if (username.isNotBlank()) {
                    Text(
                        "@" + username,
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
                if (gradeLabel != null || fieldLabel != null) {
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        gradeLabel?.let { MiniChip(it) }
                        fieldLabel?.let { MiniChip(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniChip(text: String) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
            maxLines = 1,
        )
    }
}

@Composable
private fun CardTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
}

/** یک ردیف انتخاب: عنوان، مقدار فعلی و فلش. کار اصلی داخل شیت انجام می‌شود. */
@Composable
private fun PickRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String?,
    placeholder: String,
    trailing: String? = null,
    warn: Boolean = false,
    locked: Boolean = false,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AppRadius.small)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = cs.primary, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            Text(
                value ?: placeholder,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (value != null) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    warn -> cs.error
                    value == null -> cs.onSurfaceVariant
                    else -> cs.onSurface
                },
                maxLines = 1,
            )
        }
        if (trailing != null) {
            Text(trailing, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
            Spacer(Modifier.width(6.dp))
        }
        Icon(
            if (locked) Icons.Rounded.Lock else Icons.Rounded.KeyboardArrowLeft,
            null,
            tint = cs.onSurfaceVariant,
            modifier = Modifier.size(if (locked) 15.dp else 20.dp),
        )
    }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 52.dp)
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
    )
}

/** شمارندهٔ کاراکتر بیو؛ نوار نازکی که نزدیک سقف قرمز می‌شود. */
@Composable
private fun CharMeter(used: Int, max: Int) {
    val cs = MaterialTheme.colorScheme
    val frac = (used.toFloat() / max.coerceAtLeast(1)).coerceIn(0f, 1f)
    val anim by animateFloatAsState(frac, tween(300), label = "bioMeter")
    val tone = if (frac > 0.9f) cs.error else cs.primary
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.weight(1f).height(4.dp).clip(CircleShape)
                .background(cs.onSurfaceVariant.copy(alpha = 0.14f)),
        ) {
            Box(Modifier.fillMaxWidth(anim).height(4.dp).clip(CircleShape).background(tone))
        }
        Spacer(Modifier.width(8.dp))
        Text(
            used.fa() + " / " + max.fa(),
            style = MaterialTheme.typography.labelSmall,
            color = if (frac > 0.9f) cs.error else cs.onSurfaceVariant,
        )
    }
}

/** شیت مشترک همهٔ انتخاب‌ها. */
@Composable
private fun PickSheet(
    title: String,
    subtitle: String?,
    onDismiss: () -> Unit,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier
                .padding(horizontal = 18.dp)
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Spacer(Modifier.height(3.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

/** تراشهٔ مقطع در مرحلهٔ اول انتخاب پایه. */
@Composable
private fun StagePill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = CircleShape,
        color = if (selected) cs.primary else cs.surfaceVariant,
        onClick = onClick,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) cs.onPrimary else cs.onSurface,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
        )
    }
}

/** یک گزینهٔ کامل‌عرض داخل شیت؛ تیک سبز یعنی انتخاب‌شده. */
@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit, emoji: String? = null) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(AppRadius.chip)
            .background(if (selected) cs.primary.copy(alpha = 0.14f) else cs.surfaceVariant.copy(alpha = 0.55f))
            .border(
                1.dp,
                if (selected) cs.primary.copy(alpha = 0.55f) else cs.outlineVariant.copy(alpha = 0.5f),
                AppRadius.chip,
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (emoji != null) {
            Text(emoji, fontSize = 17.sp)
            Spacer(Modifier.width(9.dp))
        }
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1f),
        )
        if (selected) {
            Box(
                Modifier.size(22.dp).clip(CircleShape).background(cs.primary),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(14.dp)) }
        }
    }
}
