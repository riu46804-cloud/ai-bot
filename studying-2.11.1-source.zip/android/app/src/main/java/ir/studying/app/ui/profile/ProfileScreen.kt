@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package ir.studying.app.ui.profile

import ir.studying.app.R
import androidx.compose.ui.res.stringResource
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.components.AppSnack
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.automirrored.rounded.Logout
import ir.studying.app.core.NavBus
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Api
import ir.studying.app.core.Fmt
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.core.int
import ir.studying.app.data.ProfileData
import ir.studying.app.player.PlayerHolder
import ir.studying.app.ui.components.AppCard
import ir.studying.app.ui.components.Avatar
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.GlassAction
import ir.studying.app.ui.components.GlassMenu
import ir.studying.app.ui.components.LoadingBox
import ir.studying.app.ui.components.SectionTitle
import ir.studying.app.ui.theme.brandGradient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class ProfileViewModel : ViewModel() {
    data class State(
        val loading: Boolean = true,
        val error: String? = null,
        val profile: ProfileData = ProfileData(0, 0, emptyList(), emptyList()),
        val streak: Int = 0,
        val followers: Int = 0,
        val following: Int = 0,
        val statusText: String = "",
    )

    val state = MutableStateFlow(State())

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            state.update { it.copy(error = null) }
            try {
                val profile = ProfileData.from(Api.obj(Api.get("profile")))
                val streak = runCatching { Api.obj(Api.get("streak")).int("streak") }.getOrDefault(0)
                val social = runCatching { Api.obj(Api.get("social_profile", "username" to (ir.studying.app.core.Store.username ?: ""))) }.getOrNull()
                val status = runCatching { Api.obj(Api.get("status")).optString("status_text", "") }.getOrDefault("")
                state.update {
                    it.copy(loading = false, profile = profile, streak = streak, statusText = status,
                        followers = social?.optInt("followers", 0) ?: 0, following = social?.optInt("following", 0) ?: 0)
                }
            } catch (e: Exception) {
                state.update { it.copy(loading = false, error = e.message ?: "خطا") }
            }
        }
    }

    fun uploadAvatar(ctx: android.content.Context, uri: android.net.Uri, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            runCatching {
                val bytes = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    ctx.contentResolver.openInputStream(uri)?.readBytes() ?: throw Exception("خطا در خواندن عکس")
                }
                val mime = ctx.contentResolver.getType(uri) ?: "image/jpeg"
                val res = Api.upload("avatar_upload", emptyMap(), listOf(ir.studying.app.core.Api.FilePart("file", "avatar.jpg", bytes, mime)))
                val o = ir.studying.app.core.Api.obj(res)
                // Two separate faults produced "saved!" with no visible change:
                // an empty path was stored as a success, and the reused file
                // name meant the image loader redrew its cached copy. Accept
                // whichever key the endpoint used, refuse a blank one, and
                // append a version marker so the URL is genuinely new.
                val saved = listOf("avatar", "path", "url", "file", "avatar_path", "avatar_url")
                    .asSequence()
                    .map { k -> o.optString(k, "") }
                    .firstOrNull { it.isNotBlank() }
                    ?: throw Exception("سرور مسیر عکس را برنگرداند")
                saved
            }.onSuccess { path ->
                // Two caches have to be dealt with: Coil already holds the
                // old bytes under the old URL, and the URL itself is about
                // to be reused. Evict the entries, then bump the version so
                // every screen requests a URL that has never been fetched.
                ir.studying.app.core.Api.mediaUrl(path)?.let { u ->
                    runCatching {
                        val loader = coil.Coil.imageLoader(ctx)
                        loader.memoryCache?.remove(coil.memory.MemoryCache.Key(u))
                        loader.diskCache?.remove(u)
                    }
                }
                ir.studying.app.core.Store.bumpAvatarVersion()
                ir.studying.app.core.Store.setAvatar(path)
                state.update { it.copy(profile = it.profile.copy(avatar = path)) }
                onResult(null)
            }.onFailure { onResult(it.message ?: "خطا در آپلود") }
        }
    }

    fun logout() {
        viewModelScope.launch {
            runCatching { Api.post("logout", JSONObject()) }
            PlayerHolder.stopAndClear()
            Store.clearSession(explicitSignOut = true)
        }
    }
}

@Composable
fun ProfileScreen(vm: ProfileViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val game by ir.studying.app.core.Game.state.collectAsState()
    val gameScope = rememberCoroutineScope()
    LaunchedEffect(Unit) { vm.refresh() }
    LaunchedEffect(Unit) { ir.studying.app.core.Game.refresh() }
    LaunchedEffect(Unit) { ir.studying.app.core.RefreshBus.events.collect { vm.refresh() } }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(40000); vm.refresh() } }
    val username = Store.username ?: ""
    var showFollowList by remember { mutableStateOf<String?>(null) }
    var showLogout by remember { mutableStateOf(false) }

    if (state.loading) {
        LoadingBox(height = 300.dp)
        return
    }
    if (state.error != null) {
        ErrorState(state.error ?: "", onRetry = { vm.refresh() })
        return
    }

    Refreshable(onRefresh = { vm.refresh() }) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp, top = 16.dp,
            bottom = 16.dp + LocalBottomBarPadding.current.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            AppCard {
                val ctx = androidx.compose.ui.platform.LocalContext.current
                var avatarMenu by remember { mutableStateOf(false) }
                val avPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                    if (uri != null) vm.uploadAvatar(ctx, uri) { err -> AppSnack.show(err ?: "عکس پروفایل به‌روز شد ✅") }
                }
                val avScope = rememberCoroutineScope()
                var charPicker by remember { mutableStateOf(false) }
                if (charPicker) {
                    CharacterPickerDialog(
                        currentKey = ir.studying.app.core.Avatars.keyOf(state.profile.avatar),
                        onDismiss = { charPicker = false },
                        onPicked = { charPicker = false; vm.refresh() },
                    )
                }
                if (avatarMenu) {
                    GlassMenu(onDismiss = { avatarMenu = false }) {
                        GlassAction(Icons.Rounded.AutoAwesome, "انتخاب کاراکتر سه‌بعدی") { charPicker = true }
                        GlassAction(Icons.Rounded.PhotoCamera, "تغییر عکس پروفایل") { avPick.launch("image/*") }
                        if (state.profile.avatar != null) {
                            GlassAction(Icons.Rounded.Delete, "حذف عکس", danger = true) {
                                avScope.launch {
                                    runCatching { Api.post("avatar_delete", org.json.JSONObject()) }
                                        .onSuccess { ir.studying.app.core.Store.setAvatar(null); vm.refresh() }
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val charKey = ir.studying.app.core.Avatars.keyOf(state.profile.avatar)
                    if (charKey != null) {
                        /* کاراکتر سه‌بعدی: شناور با هالهٔ رنگیِ خودش، جای رینگ برند. */
                        CharacterAvatar3D(
                            charKey,
                            size = 76.dp,
                            modifier = Modifier.clip(CircleShape).clickable { avatarMenu = true },
                        )
                    } else {
                        // آواتار با رینگ گرادیانی برند (مطابق ماکاپ)
                        Box(
                            Modifier.size(66.dp)
                                .background(brandGradient(), CircleShape)
                                .padding(3.dp)
                                .background(MaterialTheme.colorScheme.surface, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Box(Modifier.clip(CircleShape).clickable { avatarMenu = true }) {
                                Avatar(username, size = 56.dp, avatarUrl = state.profile.avatar)
                            }
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(username, style = MaterialTheme.typography.titleLarge)
                        if (state.statusText.isNotBlank()) {
                            Text(
                                state.statusText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Row {
                            Row(Modifier.clickable { showFollowList = "following" }, verticalAlignment = Alignment.CenterVertically) {
                                Text(state.following.fa(), style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.width(3.dp))
                                Text(stringResource(R.string.profile_screen_001), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(Modifier.width(14.dp))
                            Row(Modifier.clickable { showFollowList = "followers" }, verticalAlignment = Alignment.CenterVertically) {
                                Text(state.followers.fa(), style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.width(3.dp))
                                Text(stringResource(R.string.profile_screen_002), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.13f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.28f))) {
                        Text("🔥 ${state.streak.fa()}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.padding(horizontal = 13.dp, vertical = 6.dp))
                    }
                }
            }
        }

        /* آمار مطالعه حالا صفحهٔ خودش را دارد؛ اینجا فقط یک درِ ورودی. */
        item { ReportEntryCard(state.profile.totalMinutes, state.profile.studyDays) }

        /*
         * یک کارت به جای دو کارت: «امتیاز و رقابت» و «استریک من» هر دو نشان لقب،
         * امتیاز و سکه را تکرار می‌کردند و بی‌دلیل دو صفحه اسکرول می‌خواستند.
         */
        item { SectionTitle("امتیاز و استریک") }
        item {
            var showLadder by remember { mutableStateOf(false) }
            var showAwards by remember { mutableStateOf(false) }
            /* دستاوردها به پاپ‌آپ منتقل شد؛ از همین کارت باز می‌شود. */
            if (showAwards) AwardsDialog(onDismiss = { showAwards = false })
            if (showLadder) {
                ir.studying.app.ui.components.RankLadderDialog(level = game.level, onDismiss = { showLadder = false })
            }
            ir.studying.app.ui.components.StreakCard(
                streak = state.streak,
                todayMinutes = game.todayMinutes,
                byDate = state.profile.daily.associate { it.date to it.minutes },
                xp = game.xp,
                level = game.level,
                levelTitle = game.rankTitle,
                levelEmoji = game.rankEmoji,
                levelKey = game.levelKey,
                levelProgress = game.levelProgress,
                coins = game.coins,
                rank = game.rank,
                bestStreak = game.bestStreak,
                onOpenLadder = { showLadder = true },
                xpToNext = (game.nextLevelXp - game.xp).coerceAtLeast(0),
                nextLevel = game.level + 1,
                nextRankTitle = game.nextRankTitle,
                nextRankLevel = game.nextRankLevel,
                awardXp = game.awardXp,
                onOpenAwards = { showAwards = true },
                /*
                 * احیا فقط وقتی معنا دارد که دقیقاً یک روز جا مانده باشد؛ بیشتر از ان،
                 * استریک واقعاً پریده و فروش سکه مسخره می‌شود. یک بار هم بیشتر نشان داده نمی‌شود.
                 */
                missedDays = game.missedDays
                    .filter { !ir.studying.app.ui.components.StreakFx.reviveDismissed(it) }
                    .take(1),
                reviveCost = game.reviveCost,
                onRevive = { day ->
                    gameScope.launch {
                        val err = ir.studying.app.core.Game.revive(day)
                        if (err == null) ir.studying.app.ui.components.StreakFx.dismissRevive(day)
                        AppSnack.show(err ?: "استریکت احیا شد 🔥")
                        vm.refresh()
                    }
                },
            )
        }

        item { EditProfileEntryCard() }

        item { SettingsEntryCard() }

        item {
            OutlinedButton(
                onClick = { showLogout = true },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = MaterialTheme.shapes.medium,
            ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.profile_screen_005), color = MaterialTheme.colorScheme.error)
            }
        }
        item {
            Text(stringResource(R.string.profile_screen_006),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth(),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
    }

    if (showLogout) {
        AlertDialog(
            onDismissRequest = { showLogout = false },
            title = { Text(stringResource(R.string.profile_screen_005)) },
            text = { Text(stringResource(R.string.profile_screen_007)) },
            confirmButton = {
                TextButton(onClick = { showLogout = false; vm.logout() }) {
                    Text(stringResource(R.string.profile_screen_008), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { showLogout = false }) { Text(stringResource(R.string.groups_011)) } },
        )
    }

    showFollowList?.let { kind ->
        ir.studying.app.ui.feed.FollowListSheet(username = username, kind = kind,
            onDismiss = { showFollowList = null }, onOpenUser = { showFollowList = null })
    }
}

/** Single doorway into the settings hub; everything else moved there. */
@Composable
private fun EditProfileEntryCard() {
    AppCard {
        Row(
            Modifier.fillMaxWidth().clickable { NavBus.requestRoute("profile_edit") },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Edit, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("ویرایش پروفایل", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "نام، بیوگرافی، پایه و رشته، شماره",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun SettingsEntryCard() {
    AppCard {
        Row(
            Modifier.fillMaxWidth().clickable { NavBus.requestRoute("settings") },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Settings, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.settings_001), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.settings_042),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** درِ ورودی صفحهٔ «گزارش»: همهٔ نمودارها و آمار مطالعه آنجاست. */
@Composable
private fun ReportEntryCard(totalMinutes: Int, studyDays: Int) {
    val cs = MaterialTheme.colorScheme
    AppCard(onClick = { NavBus.requestRoute("report") }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(brandGradient(), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Insights, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("گزارش مطالعه", style = MaterialTheme.typography.bodyLarge, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Text(
                    if (totalMinutes > 0) "${Fmt.minutes(totalMinutes)} در ${studyDays.fa()} روز · نمودارها، تقویم و رکوردها"
                    else "نمودارها، تقویم و رکوردهای مطالعه",
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 2,
                )
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, null, tint = cs.onSurfaceVariant)
        }
    }
}
