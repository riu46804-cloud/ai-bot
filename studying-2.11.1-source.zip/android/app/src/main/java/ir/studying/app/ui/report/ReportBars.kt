package ir.studying.app.ui.report

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Jalali
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** یک میله: مجموع روز و تکه‌های درس‌ها به ترتیب چیدن (پایین به بالا). */
@Immutable
data class BarDatum(val iso: String, val total: Int, val segments: List<Pair<Color, Int>> = emptyList())

/**
 * هندسهٔ مشترک نمودارهای زمانی. زمان مثل بقیهٔ اپ از راست به چپ جلو می‌رود:
 * قدیمی‌ترین روز سمت راست، امروز سمت چپ. ستون برچسب محور سمت شروع است.
 */
private class TimeAxis(
    val n: Int,
    val rtl: Boolean,
    val width: Float,
    val axisW: Float,
    val pad: Float,
) {
    val plotLeft = if (rtl) pad else axisW
    val plotRight = if (rtl) width - axisW else width - pad
    val plotW = (plotRight - plotLeft).coerceAtLeast(1f)
    val slot = plotW / n.coerceAtLeast(1)

    fun centerX(i: Int): Float =
        if (rtl) plotRight - (i + 0.5f) * slot else plotLeft + (i + 0.5f) * slot

    fun indexAt(x: Float): Int? {
        if (n <= 0 || x < plotLeft - slot / 2 || x > plotRight + slot / 2) return null
        val f = if (rtl) (plotRight - x) / slot else (x - plotLeft) / slot
        return floor(f).toInt().coerceIn(0, n - 1)
    }

    /** محل برچسب‌های محور عمودی و تراز آن‌ها. */
    val axisLabelX: Float get() = if (rtl) width else 0f
    val axisLabelAlign: Float get() = if (rtl) 1f else 0f

    /** انتهای نمودار (سمت امروز) برای برچسب خط هدف و میانگین. */
    val endX: Float get() = if (rtl) plotLeft else plotRight
    val endAlign: Float get() = if (rtl) 0f else 1f
}

private fun DrawScope.drawGrid(
    tm: TextMeasurer,
    axis: TimeAxis,
    top: Int,
    step: Int,
    plotTop: Float,
    plotBottom: Float,
    grid: Color,
    axisStyle: TextStyle,
) {
    val plotH = plotBottom - plotTop
    val dash = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 4.dp.toPx()), 0f)
    var v = step
    while (v <= top) {
        val y = plotBottom - plotH * v / top
        drawLine(grid, Offset(axis.plotLeft, y), Offset(axis.plotRight, y), strokeWidth = 1.dp.toPx(), pathEffect = dash)
        chartText(tm, ReportStats.axisLabel(v), axisStyle, axis.axisLabelX, y, axis.axisLabelAlign, centerY = true)
        v += step
    }
    drawLine(grid, Offset(axis.plotLeft, plotBottom), Offset(axis.plotRight, plotBottom), strokeWidth = 1.2.dp.toPx())
}

/**
 * خط افقی هدف یا میانگین با برچسب قرصی روی خود خط. هدف سمت امروز می‌نشیند و
 * میانگین سمت قدیمی‌ترین روز تا دو برچسب هیچ‌وقت روی هم نیفتند.
 */
private fun DrawScope.drawLevelLine(
    tm: TextMeasurer,
    axis: TimeAxis,
    y: Float,
    color: Color,
    label: String,
    style: TextStyle,
    dotted: Boolean,
    alpha: Float,
    bg: Color,
    atEnd: Boolean = true,
) {
    val effect = if (dotted) PathEffect.dashPathEffect(floatArrayOf(1.5.dp.toPx(), 4.dp.toPx()), 0f)
    else PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx()), 0f)
    drawLine(color.copy(alpha = 0.9f * alpha), Offset(axis.plotLeft, y), Offset(axis.plotRight, y),
        strokeWidth = 1.6.dp.toPx(), pathEffect = effect, cap = StrokeCap.Round)
    val l = tm.measure(label, style.copy(color = color))
    val padX = 6.dp.toPx()
    val padY = 1.5.dp.toPx()
    val w = l.size.width + padX * 2
    val h = l.size.height + padY * 2
    // سمت امروز = انتهای محور؛ سمت دیگر = ابتدای ناحیهٔ نمودار کنار برچسب‌های محور.
    val endSideLeft = axis.endAlign == 0f
    val left = when {
        atEnd && endSideLeft -> axis.plotLeft
        atEnd -> axis.plotRight - w
        endSideLeft -> axis.plotRight - w
        else -> axis.plotLeft
    }
    val top = y - h / 2f
    drawRoundRect(bg, Offset(left, top), Size(w, h), CornerRadius(h / 2f), alpha = alpha)
    drawRoundRect(color.copy(alpha = 0.14f), Offset(left, top), Size(w, h), CornerRadius(h / 2f), alpha = alpha)
    drawRoundRect(color.copy(alpha = 0.55f), Offset(left, top), Size(w, h), CornerRadius(h / 2f),
        style = Stroke(1.dp.toPx()), alpha = alpha)
    drawText(l, topLeft = Offset(left + padX, top + padY), alpha = alpha)
}

/**
 * نمودار میله‌ای روزانه، تک‌رنگ یا تفکیک‌شده بر اساس درس.
 * لمس یا کشیدن انگشت روی نمودار یک روز را انتخاب می‌کند.
 */
@Composable
fun TrendBars(
    data: List<BarDatum>,
    labels: List<String>,
    subLabels: List<String>?,
    todayIndex: Int,
    goal: Int,
    average: Int,
    selected: Int?,
    onSelect: (Int?) -> Unit,
    showValues: Boolean,
    animKey: Any?,
    modifier: Modifier = Modifier,
    height: Dp = 214.dp,
) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val tm = rememberTextMeasurer()
    val reveal = rememberChartReveal(animKey)
    val baseLabel = MaterialTheme.typography.labelSmall
    val axisStyle = baseLabel.copy(color = cs.onSurfaceVariant.copy(alpha = 0.75f), fontSize = 9.sp)
    val labelStyle = baseLabel.copy(color = cs.onSurfaceVariant, fontSize = 10.sp)
    val todayStyle = labelStyle.copy(color = cs.primary, fontWeight = FontWeight.Black)
    val valueStyle = baseLabel.copy(color = cs.onSurface, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    val tagStyle = baseLabel.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold)
    val grid = cs.outlineVariant.copy(alpha = 0.7f)
    val goalColor = cs.tertiary
    val avgColor = cs.secondary
    val primary = cs.primary
    val secondary = cs.secondary
    val stub = cs.onSurface.copy(alpha = 0.10f)
    val highlight = cs.onSurface.copy(alpha = 0.06f)
    val labelBg = cs.surface

    val n = data.size
    val maxV = data.maxOfOrNull { it.total } ?: 0
    val goalInScale = goal > 0 && goal <= maxV * 2 + 30
    val (top, step) = ReportStats.niceAxis(maxOf(maxV, average, if (goalInScale) goal else 0), 3)

    val sel by rememberUpdatedState(selected)
    val onSel by rememberUpdatedState(onSelect)
    val topPad = if (showValues) 18.dp else 10.dp
    val bottomPad = if (subLabels != null) 34.dp else 20.dp

    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .pointerInput(n, rtl) {
                detectTapGestures { pos ->
                    val axis = TimeAxis(n, rtl, size.width.toFloat(), 30.dp.toPx(), 4.dp.toPx())
                    val i = axis.indexAt(pos.x)
                    onSel(if (i == null || i == sel) null else i)
                }
            }
            .pointerInput(n, rtl) {
                detectHorizontalDragGestures(
                    onDragStart = { pos ->
                        TimeAxis(n, rtl, size.width.toFloat(), 30.dp.toPx(), 4.dp.toPx()).indexAt(pos.x)?.let { onSel(it) }
                    },
                ) { change, _ ->
                    change.consume()
                    TimeAxis(n, rtl, size.width.toFloat(), 30.dp.toPx(), 4.dp.toPx())
                        .indexAt(change.position.x)?.let { if (it != sel) onSel(it) }
                }
            },
    ) {
        if (n == 0) return@Canvas
        val axis = TimeAxis(n, rtl, size.width, 30.dp.toPx(), 4.dp.toPx())
        val plotTop = topPad.toPx()
        val plotBottom = size.height - bottomPad.toPx()
        val plotH = plotBottom - plotTop
        val t = reveal.value

        drawGrid(tm, axis, top, step, plotTop, plotBottom, grid, axisStyle)

        val barW = min(axis.slot * (if (n <= 10) 0.56f else 0.62f), 30.dp.toPx())
        val rad = min(barW / 2f, 7.dp.toPx())

        sel?.let { s ->
            if (s in 0 until n) {
                val cx = axis.centerX(s)
                val w = min(axis.slot * 0.92f, barW + 14.dp.toPx())
                drawRoundRect(highlight, Offset(cx - w / 2f, plotTop - 6.dp.toPx()),
                    Size(w, plotBottom - plotTop + 6.dp.toPx()), CornerRadius(10.dp.toPx()))
            }
        }

        val valueTops = ArrayList<Pair<Int, Float>>(n)
        for (i in 0 until n) {
            val d = data[i]
            val cx = axis.centerX(i)
            val left = cx - barW / 2f
            val dim = sel != null && sel != i
            val alpha = if (dim) 0.3f else 1f
            if (d.total <= 0) {
                drawRoundRect(stub, Offset(left, plotBottom - 3.dp.toPx()), Size(barW, 3.dp.toPx()),
                    CornerRadius(1.5.dp.toPx()), alpha = alpha)
                continue
            }
            val bh = plotH * (d.total.toFloat() / top) * staggered(t, i, n)
            if (bh < 0.5f) continue
            val topY = plotBottom - bh
            val path = Path().apply {
                addRoundRect(
                    RoundRect(
                        left, topY, left + barW, plotBottom,
                        topLeftCornerRadius = CornerRadius(rad),
                        topRightCornerRadius = CornerRadius(rad),
                        bottomRightCornerRadius = CornerRadius(rad * 0.3f),
                        bottomLeftCornerRadius = CornerRadius(rad * 0.3f),
                    ),
                )
            }
            if (d.segments.isEmpty()) {
                drawPath(path, Brush.verticalGradient(listOf(primary, secondary.copy(alpha = 0.8f)), startY = topY, endY = plotBottom), alpha = alpha)
            } else {
                val segTotal = d.segments.sumOf { it.second }.coerceAtLeast(1)
                clipPath(path) {
                    var y = plotBottom
                    d.segments.forEachIndexed { k, (color, m) ->
                        val sh = bh * m / segTotal
                        drawRect(color, Offset(left, y - sh), Size(barW, sh + 0.6f), alpha = alpha)
                        if (k > 0) drawLine(Color.Black.copy(alpha = 0.18f * alpha), Offset(left, y), Offset(left + barW, y), 1.dp.toPx())
                        y -= sh
                    }
                }
            }
            if (showValues && t > 0.55f) valueTops.add(i to topY)
        }

        if (average > 0) {
            val y = plotBottom - plotH * average / top
            drawLevelLine(tm, axis, y, avgColor, "میانگین", tagStyle, dotted = true, alpha = t, bg = labelBg, atEnd = false)
        }
        if (goalInScale) {
            val y = plotBottom - plotH * goal / top
            drawLevelLine(tm, axis, y, goalColor, "🎯 هدف", tagStyle, dotted = false, alpha = t, bg = labelBg)
        }

        // عدد بالای میله‌ها آخر از همه، روی یک پس‌زمینهٔ کوچک تا خط هدف از رویش رد نشود.
        valueTops.forEach { (i, topY) ->
            val dim = sel != null && sel != i
            val a = ((t - 0.55f) / 0.45f).coerceIn(0f, 1f) * (if (dim) 0.45f else 1f)
            val style = if (sel == i) valueStyle.copy(color = primary) else valueStyle
            val l = tm.measure(ReportStats.clock(data[i].total), style)
            val cx = axis.centerX(i)
            val y = topY - 14.dp.toPx()
            val padX = 3.dp.toPx()
            drawRoundRect(
                labelBg,
                Offset(cx - l.size.width / 2f - padX, y - 1.dp.toPx()),
                Size(l.size.width + padX * 2, l.size.height + 2.dp.toPx()),
                CornerRadius(4.dp.toPx()),
                alpha = a * 0.92f,
            )
            drawText(l, topLeft = Offset(cx - l.size.width / 2f, y), alpha = a)
        }

        for (i in 0 until n) {
            val cx = axis.centerX(i)
            val st = if (i == todayIndex || sel == i) todayStyle else labelStyle
            labels.getOrNull(i)?.let { chartText(tm, it, st, cx, plotBottom + 5.dp.toPx(), 0.5f) }
            subLabels?.getOrNull(i)?.let { chartText(tm, it, st.copy(fontSize = 9.sp), cx, plotBottom + 19.dp.toPx(), 0.5f) }
        }
    }
}

/**
 * ۹۰ روز: میله‌های باریک روزانه پشت سطح نرم میانگین ۷ روزه. میله‌ها
 * واقعیت هر روزند، سطح جهت حرکت را نشان می‌دهد.
 */
@Composable
fun TrendArea(
    values: List<Int>,
    trend: List<Float>,
    monthTicks: List<Pair<Int, String>>,
    goal: Int,
    selected: Int?,
    onSelect: (Int?) -> Unit,
    animKey: Any?,
    modifier: Modifier = Modifier,
    height: Dp = 214.dp,
) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val tm = rememberTextMeasurer()
    val reveal = rememberChartReveal(animKey, 1200)
    val baseLabel = MaterialTheme.typography.labelSmall
    val axisStyle = baseLabel.copy(color = cs.onSurfaceVariant.copy(alpha = 0.75f), fontSize = 9.sp)
    val labelStyle = baseLabel.copy(color = cs.onSurfaceVariant, fontSize = 10.sp)
    val tagStyle = baseLabel.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold)
    val grid = cs.outlineVariant.copy(alpha = 0.7f)
    val primary = cs.primary
    val secondary = cs.secondary
    val surface = cs.surface
    val labelBg = cs.surface
    val goalColor = cs.tertiary
    val guide = cs.onSurface.copy(alpha = 0.35f)

    val n = values.size
    val maxV = values.maxOrNull() ?: 0
    val goalInScale = goal > 0 && goal <= maxV * 2 + 30
    val (top, step) = ReportStats.niceAxis(maxOf(maxV, if (goalInScale) goal else 0), 3)
    val sel by rememberUpdatedState(selected)
    val onSel by rememberUpdatedState(onSelect)

    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .pointerInput(n, rtl) {
                detectTapGestures { pos ->
                    val axis = TimeAxis(n, rtl, size.width.toFloat(), 30.dp.toPx(), 4.dp.toPx())
                    val i = axis.indexAt(pos.x)
                    onSel(if (i == null || i == sel) null else i)
                }
            }
            .pointerInput(n, rtl) {
                detectHorizontalDragGestures(
                    onDragStart = { pos ->
                        TimeAxis(n, rtl, size.width.toFloat(), 30.dp.toPx(), 4.dp.toPx()).indexAt(pos.x)?.let { onSel(it) }
                    },
                ) { change, _ ->
                    change.consume()
                    TimeAxis(n, rtl, size.width.toFloat(), 30.dp.toPx(), 4.dp.toPx())
                        .indexAt(change.position.x)?.let { if (it != sel) onSel(it) }
                }
            },
    ) {
        if (n == 0) return@Canvas
        val axis = TimeAxis(n, rtl, size.width, 30.dp.toPx(), 4.dp.toPx())
        val plotTop = 12.dp.toPx()
        val plotBottom = size.height - 22.dp.toPx()
        val plotH = plotBottom - plotTop
        val t = reveal.value
        fun y(v: Float) = plotBottom - plotH * (v / top)

        drawGrid(tm, axis, top, step, plotTop, plotBottom, grid, axisStyle)

        // آشکار شدن از قدیمی‌ترین روز به امروز
        val revealW = axis.plotW * FastOutSlow(t) + axis.slot
        val clipL = if (rtl) axis.plotRight - revealW else axis.plotLeft - axis.slot
        val clipR = if (rtl) axis.plotRight + axis.slot else axis.plotLeft + revealW
        clipRect(left = clipL, top = 0f, right = clipR, bottom = size.height) {
            val bw = max(axis.slot * 0.5f, 1.5.dp.toPx())
            for (i in 0 until n) {
                val v = values[i]
                if (v <= 0) continue
                val cx = axis.centerX(i)
                val isSel = sel == i
                drawRoundRect(
                    if (isSel) primary else primary.copy(alpha = 0.22f),
                    Offset(cx - bw / 2f, y(v.toFloat())),
                    Size(bw, plotBottom - y(v.toFloat())),
                    CornerRadius(bw / 2f),
                )
            }
            val pts = (0 until n).map { Offset(axis.centerX(it), y(trend.getOrElse(it) { 0f })) }
            val line = smoothPath(pts)
            val fill = Path().apply {
                addPath(line)
                lineTo(pts.last().x, plotBottom)
                lineTo(pts.first().x, plotBottom)
                close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(primary.copy(alpha = 0.34f), secondary.copy(alpha = 0.03f)), startY = plotTop, endY = plotBottom))
            drawPath(line, Brush.horizontalGradient(listOf(secondary, primary)),
                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }

        if (goalInScale) drawLevelLine(tm, axis, y(goal.toFloat()), goalColor, "🎯 هدف", tagStyle, dotted = false, alpha = t, bg = labelBg)

        sel?.let { s ->
            if (s in 0 until n) {
                val cx = axis.centerX(s)
                drawLine(guide, Offset(cx, plotTop), Offset(cx, plotBottom), strokeWidth = 1.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx()), 0f))
                val p = Offset(cx, y(trend.getOrElse(s) { 0f }))
                drawCircle(surface, 6.dp.toPx(), p)
                drawCircle(primary, 6.dp.toPx(), p, style = Stroke(2.5.dp.toPx()))
            }
        }

        monthTicks.forEach { (i, name) ->
            if (i in 0 until n) {
                val cx = axis.centerX(i)
                drawLine(grid, Offset(cx, plotBottom), Offset(cx, plotBottom + 4.dp.toPx()), strokeWidth = 1.dp.toPx())
                chartText(tm, name, labelStyle, cx, plotBottom + 6.dp.toPx(), 0.5f)
            }
        }
    }
}

private fun FastOutSlow(t: Float): Float = androidx.compose.animation.core.FastOutSlowInEasing.transform(t.coerceIn(0f, 1f))

/** دوازده ماه شمسی اخیر، تازه‌ترین بالا؛ بهترین ماه تاج دارد. */
@Composable
fun MonthlyBars(
    buckets: List<ReportStats.MonthBucket>,
    currentYear: Int,
    animKey: Any?,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val reveal = rememberChartReveal(animKey, 1000)
    val t = reveal.value
    val maxV = (buckets.maxOfOrNull { it.minutes } ?: 0).coerceAtLeast(1)
    val best = buckets.indices.maxByOrNull { buckets[it].minutes }?.takeIf { buckets[it].minutes > 0 }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        buckets.forEachIndexed { i, b ->
            val f = (b.minutes.toFloat() / maxV) * staggered(t, i, buckets.size)
            // مرز سال: یک جداکنندهٔ کوچک به جای تکرار سال کنار هر ماه.
            if (b.year != currentYear && (i == 0 || buckets[i - 1].year != b.year)) {
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(b.year.fa(), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f).height(1.dp).background(cs.outlineVariant.copy(alpha = 0.6f)))
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Jalali.monthName(b.month),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (i == 0) cs.primary else cs.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(76.dp),
                )
                Box(
                    Modifier
                        .weight(1f)
                        .height(16.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(cs.onSurface.copy(alpha = 0.06f)),
                ) {
                    if (b.minutes > 0) {
                        Box(
                            Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(f.coerceIn(0.015f, 1f))
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (i == best) Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFFBBF24)))
                                    else Brush.horizontalGradient(listOf(cs.primary.copy(alpha = 0.55f), cs.secondary.copy(alpha = 0.75f))),
                                ),
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.width(84.dp), horizontalAlignment = Alignment.End) {
                    Text(
                        (if (i == best) "👑 " else "") + bigDuration(b.minutes),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                    )
                    Text(
                        b.activeDays.fa() + " روز",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/** میانگین هر روز هفته؛ شنبه سمت راست، بهترین روز با تاج و گرادیان. */
@Composable
fun WeekdayRhythm(
    values: List<Int>,
    todayIndex: Int,
    animKey: Any?,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val reveal = rememberChartReveal(animKey, 900)
    val t = reveal.value
    val maxV = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    val best = values.indices.maxByOrNull { values[it] }?.takeIf { values[it] > 0 }
    Row(
        modifier.fillMaxWidth().height(178.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        values.forEachIndexed { i, v ->
            val isBest = i == best
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (isBest) "👑" else " ", fontSize = 12.sp)
                Text(
                    if (v > 0) ReportStats.clock(v) else "—",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = if (isBest) FontWeight.Black else FontWeight.Medium,
                    color = if (isBest) cs.primary else cs.onSurfaceVariant,
                    maxLines = 1,
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(cs.onSurface.copy(alpha = 0.055f)),
                ) {
                    val f = (v.toFloat() / maxV) * staggered(t, i, values.size)
                    if (v > 0) {
                        Box(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .fillMaxHeight(f.coerceIn(0.04f, 1f))
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isBest) Brush.verticalGradient(listOf(cs.primary, cs.secondary))
                                    else SolidColor(cs.primary.copy(alpha = 0.28f + 0.42f * v / maxV)),
                                ),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    WeekdayShort.getOrElse(i) { "" },
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (i == todayIndex) FontWeight.Black else FontWeight.SemiBold,
                    color = if (i == todayIndex) cs.primary else cs.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 2.dp),
                )
            }
        }
    }
}
