package ir.studying.app.ui.report

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Fmt
import ir.studying.app.core.Jalali
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa
import kotlin.math.abs

private data class CalDay(val iso: String, val day: Int, val minutes: Int, val future: Boolean, val known: Boolean)

private data class CalMonth(
    val year: Int,
    val month: Int,
    val lead: Int,
    val days: List<CalDay>,
    val total: Int,
    val active: Int,
    val elapsed: Int,
    val bestIso: String?,
    val bestMinutes: Int,
)

private fun buildMonth(byDate: Map<String, Int>, todayIso: String, jy: Int, jm: Int): CalMonth {
    val len = ReportStats.jalaliMonthLength(jy, jm)
    val firstIso = ReportStats.jalaliMonthStart(jy, jm)
    val today = ReportStats.epochDay(todayIso) ?: 0L
    val first = ReportStats.epochDay(firstIso) ?: today
    val earliest = today - (CALENDAR_DAYS - 1)
    var total = 0
    var active = 0
    var elapsed = 0
    var bestIso: String? = null
    var best = 0
    val days = (0 until len).map { k ->
        val e = first + k
        val iso = ReportStats.isoOfEpochDay(e)
        val m = (byDate[iso] ?: 0).coerceAtLeast(0)
        val future = e > today
        if (!future) {
            elapsed++
            total += m
            if (m > 0) active++
            if (m > best) { best = m; bestIso = iso }
        }
        CalDay(iso, k + 1, if (future) 0 else m, future, e >= earliest)
    }
    return CalMonth(jy, jm, ReportStats.weekdayIndex(firstIso), days, total, active, elapsed, bestIso, best)
}

/** ماه [back] تا قبل از ماه جاری (صفر یعنی همین ماه). */
private fun monthBack(todayIso: String, back: Int): Pair<Int, Int> {
    val j = ReportStats.jalaliOf(todayIso) ?: return 1403 to 1
    var y = j.year
    var m = j.month - back
    while (m <= 0) { m += 12; y-- }
    return y to m
}

/**
 * تقویم شمسی ماه‌به‌ماه با شدت مطالعهٔ هر روز. با فلش‌ها یا کشیدن انگشت
 * بین ماه‌ها جابه‌جا می‌شود؛ هر روز با یک لمس جزئیاتش را باز می‌کند.
 */
@Composable
fun MonthCalendar(
    byDate: Map<String, Int>,
    todayIso: String,
    onOpenDay: (String, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val density = LocalDensity.current
    var back by rememberSaveable { mutableIntStateOf(0) }
    val maxBack = remember(todayIso) {
        val j = ReportStats.jalaliOf(todayIso)
        val e = ReportStats.jalaliOf(ReportStats.shift(todayIso, -(CALENDAR_DAYS - 1)))
        if (j == null || e == null) 0 else ((j.year - e.year) * 12 + (j.month - e.month)).coerceAtLeast(0)
    }
    val scale = remember(byDate) { ReportStats.heatScale(byDate.values) }
    val curBack by rememberUpdatedState(back)
    val curMax by rememberUpdatedState(maxBack)

    Column(
        modifier
            .fillMaxWidth()
            .pointerInput(rtl) {
                var drag = 0f
                val threshold = with(density) { 56.dp.toPx() }
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = {
                        if (abs(drag) > threshold) {
                            // در راست‌به‌چپ گذشته سمت راست است: کشیدن به راست یعنی ماه بعد.
                            val newer = if (rtl) drag > 0 else drag < 0
                            if (newer && curBack > 0) back = curBack - 1
                            else if (!newer && curBack < curMax) back = curBack + 1
                        }
                        drag = 0f
                    },
                ) { _, amount -> drag += amount }
            },
    ) {
        AnimatedContent(
            targetState = back,
            transitionSpec = {
                val older = targetState > initialState
                // ماه قدیمی‌تر از سمت گذشته (راست در راست‌به‌چپ) وارد می‌شود.
                val sign = if (older == rtl) 1 else -1
                (slideInHorizontally(tween(280)) { w -> sign * w / 6 } + fadeIn(tween(260)))
                    .togetherWith(slideOutHorizontally(tween(220)) { w -> -sign * w / 6 } + fadeOut(tween(160)))
            },
            label = "calendarMonth",
        ) { b ->
            val (jy, jm) = monthBack(todayIso, b)
            val month = remember(byDate, todayIso, jy, jm) { buildMonth(byDate, todayIso, jy, jm) }
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (back < maxBack) back++ }, enabled = b < maxBack) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "ماه قبل")
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "${Jalali.monthName(jm)} ${jy.fa()}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            if (month.total > 0) "${Fmt.minutes(month.total)} در ${month.active.fa()} روز"
                            else "هنوز مطالعه‌ای ثبت نشده",
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { if (back > 0) back-- }, enabled = b > 0) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "ماه بعد")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    WeekdayShort.forEachIndexed { i, d ->
                        Text(
                            d,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (i == 6) cs.error.copy(alpha = 0.8f) else cs.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                val cells = month.lead + month.days.size
                val rows = (cells + 6) / 7
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    for (r in 0 until rows) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            for (c in 0 until 7) {
                                val idx = r * 7 + c - month.lead
                                val d = month.days.getOrNull(idx)
                                if (d == null) {
                                    Spacer(Modifier.weight(1f))
                                } else {
                                    CalendarCell(
                                        d = d,
                                        level = ReportStats.heatLevel(d.minutes, scale),
                                        today = d.iso == todayIso,
                                        modifier = Modifier.weight(1f),
                                        onClick = { onOpenDay(d.iso, d.minutes) },
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth()) {
                    CalStat("مجموع", if (month.total > 0) bigDuration(month.total) else "—", Modifier.weight(1f))
                    CalStat("روز فعال", "${month.active.fa()} از ${month.elapsed.fa()}", Modifier.weight(1f))
                    CalStat(
                        "میانگین روز فعال",
                        if (month.active > 0) ReportStats.clock(month.total / month.active) else "—",
                        Modifier.weight(1f),
                    )
                    CalStat(
                        "بهترین روز",
                        if (month.bestIso != null) ReportStats.clock(month.bestMinutes) else "—",
                        Modifier.weight(1f),
                        sub = month.bestIso?.let { Fmt.jalaliShort(it) },
                    )
                }
            }
        }
        if (back > 0) {
            TextButton(
                onClick = { back = 0 },
                modifier = Modifier.align(Alignment.CenterHorizontally),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
            ) { Text("برگشت به این ماه", style = MaterialTheme.typography.labelMedium) }
        }
    }
}

@Composable
private fun CalendarCell(d: CalDay, level: Int, today: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val strong = level >= 3
    val shape = RoundedCornerShape(10.dp)
    val bg = when {
        d.future || !d.known -> Color.Transparent
        else -> heatColor(level, cs)
    }
    Box(
        modifier
            .aspectRatio(0.9f)
            .clip(shape)
            .background(bg)
            .then(
                if (today) Modifier.border(1.6.dp, if (strong) cs.onSurface.copy(alpha = 0.85f) else cs.primary, shape)
                else if (d.future) Modifier.border(1.dp, cs.outlineVariant.copy(alpha = 0.45f), shape)
                else Modifier
            )
            .alpha(if (d.future) 0.45f else 1f)
            .clickable(enabled = !d.future && d.known, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                d.day.fa(),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (today) FontWeight.Black else FontWeight.Medium,
                color = if (strong) cs.onPrimary else if (today) cs.primary else cs.onSurface,
            )
            if (d.minutes > 0) {
                Text(
                    ReportStats.clock(d.minutes),
                    fontSize = 8.5.sp,
                    lineHeight = 9.sp,
                    color = if (strong) cs.onPrimary.copy(alpha = 0.85f) else cs.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun CalStat(label: String, value: String, modifier: Modifier, sub: String? = null) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.padding(horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
        if (sub != null) {
            Text(sub, style = MaterialTheme.typography.labelSmall, color = cs.primary, fontSize = 9.sp, maxLines = 1)
        }
        Spacer(Modifier.width(1.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, fontSize = 9.5.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}
