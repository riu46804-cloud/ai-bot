package ir.studying.app.ui.report

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Fmt
import ir.studying.app.core.Jalali
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa

// ============================================================ قالب کارت

@Composable
fun ReportCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.55f)),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp), content = content)
    }
}

@Composable
fun CardHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
        trailing?.invoke()
    }
}

@Composable
private fun CardEmpty(text: String, height: Int = 140) {
    Box(Modifier.fillMaxWidth().height(height.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CardLoading(height: Int = 200) {
    Box(Modifier.fillMaxWidth().height(height.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 2.5.dp)
    }
}

/** جمله‌ی کوتاه برداشت زیر نمودارها. */
@Composable
private fun Insight(emoji: String, text: String) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(cs.primary.copy(alpha = 0.07f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 16.sp)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = cs.onSurface)
    }
}

private val numberStyle = SpanStyle(fontSize = 26.sp, fontWeight = FontWeight.Black)
private val unitStyle = SpanStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium)

// ============================================================ روند

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TrendCard(
    period: ReportPeriod,
    dates: List<String>,
    byDate: Map<String, Int>,
    stacks: Map<String, DayStack>?,
    courseOrder: List<String>,
    palette: CoursePalette,
    goal: Int,
    summary: ReportStats.Summary,
    todayIso: String,
    onOpenDay: (String, Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var selected by remember(period) { mutableStateOf<Int?>(null) }
    val months = remember(byDate, todayIso, period) {
        if (period == ReportPeriod.YEAR) ReportStats.jalaliMonths(byDate, todayIso, 12) else emptyList()
    }
    val sel = selected?.takeIf { it in dates.indices && period != ReportPeriod.YEAR }

    ReportCard {
        // سربرگ: پیش‌فرض میانگین؛ با لمس یک روز، همان روز.
        Box(Modifier.fillMaxWidth().heightIn(min = 76.dp)) {
            AnimatedContent(
                targetState = sel,
                transitionSpec = { fadeIn(tween(180)).togetherWith(fadeOut(tween(120))) },
                label = "trendHeader",
            ) { idx ->
                if (idx == null) {
                    Column {
                        Text(
                            if (period == ReportPeriod.YEAR) "میانگین ماهانه" else "میانگین روزانه",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant,
                        )
                        val avg = if (period == ReportPeriod.YEAR) {
                            val m = months.filter { it.elapsedDays > 0 }
                            if (m.isEmpty()) 0 else m.sumOf { it.minutes } / m.size
                        } else summary.avgPerDay
                        Text(durationAnnotated(avg, numberStyle.copy(color = cs.onSurface), unitStyle.copy(color = cs.onSurfaceVariant)))
                        Text(
                            "${period.noun} · مجموع ${if (summary.total > 0) bigDuration(summary.total) else "۰"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                } else {
                    val iso = dates[idx]
                    val m = byDate[iso] ?: 0
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(Fmt.jalaliWithDay(iso), style = MaterialTheme.typography.labelMedium, color = cs.primary)
                            Text(durationAnnotated(m, numberStyle.copy(color = cs.onSurface), unitStyle.copy(color = cs.onSurfaceVariant)))
                            val top = stacks?.get(iso)?.courses?.sortedByDescending { it.minutes }?.take(3).orEmpty()
                            if (top.isNotEmpty()) {
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    top.forEach { c ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(7.dp).background(palette[c.name], CircleShape))
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                "${c.name} ${ReportStats.clock(c.minutes)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = cs.onSurfaceVariant,
                                                maxLines = 1,
                                            )
                                        }
                                    }
                                }
                            } else if (m == 0) {
                                Text("بدون مطالعه", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            }
                        }
                        TextButton(onClick = { onOpenDay(iso, m) }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Text("جزئیات روز ›", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        val empty = summary.total <= 0
        Box(Modifier.fillMaxWidth()) {
        Column(Modifier.alpha(if (empty) 0.4f else 1f)) {
        when (period) {
            ReportPeriod.WEEK, ReportPeriod.MONTH -> {
                val data = remember(dates, byDate, stacks, palette) {
                    dates.map { iso ->
                        val segs = stacks?.get(iso)?.courses
                            ?.filter { it.minutes > 0 }
                            ?.sortedBy { palette.rank(it.name) }
                            ?.map { palette[it.name] to it.minutes }
                            .orEmpty()
                        BarDatum(iso, byDate[iso] ?: 0, segs)
                    }
                }
                val week = period == ReportPeriod.WEEK
                val labels = remember(dates, week) {
                    dates.mapIndexed { i, iso ->
                        if (week) WeekdayShort[ReportStats.weekdayIndex(iso)]
                        else if ((dates.size - 1 - i) % 5 == 0) (ReportStats.jalaliOf(iso)?.day ?: 0).fa()
                        else ""
                    }
                }
                val subLabels = remember(dates, week) {
                    if (week) dates.map { (ReportStats.jalaliOf(it)?.day ?: 0).fa() } else null
                }
                TrendBars(
                    data = data,
                    labels = labels,
                    subLabels = subLabels,
                    todayIndex = dates.size - 1,
                    goal = goal,
                    average = summary.avgPerDay,
                    selected = sel,
                    onSelect = { selected = it },
                    showValues = week,
                    animKey = period,
                )
                val legend = courseOrder.take(6)
                if (stacks != null && legend.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        legend.forEach { name ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(8.dp).background(palette[name], CircleShape))
                                Spacer(Modifier.width(5.dp))
                                Text(name, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
                            }
                        }
                    }
                }
            }
            ReportPeriod.QUARTER -> {
                val values = remember(dates, byDate) { dates.map { byDate[it] ?: 0 } }
                val trend = remember(values) { ReportStats.movingAverage(values, 7) }
                val ticks = remember(dates) {
                    dates.mapIndexedNotNull { i, iso ->
                        val j = ReportStats.jalaliOf(iso) ?: return@mapIndexedNotNull null
                        if (j.day == 1) i to Jalali.monthName(j.month) else null
                    }
                }
                TrendArea(
                    values = values,
                    trend = trend,
                    monthTicks = ticks,
                    goal = goal,
                    selected = sel,
                    onSelect = { selected = it },
                    animKey = period,
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(width = 14.dp, height = 3.dp).background(cs.primary, CircleShape))
                    Spacer(Modifier.width(5.dp))
                    Text("میانگین ۷ روزه", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.width(14.dp))
                    Box(Modifier.size(width = 4.dp, height = 10.dp).background(cs.primary.copy(alpha = 0.35f), RoundedCornerShape(2.dp)))
                    Spacer(Modifier.width(5.dp))
                    Text("هر روز", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            ReportPeriod.YEAR -> {
                val j = remember(todayIso) { ReportStats.jalaliOf(todayIso) }
                MonthlyBars(buckets = months, currentYear = j?.year ?: 0, animKey = period)
            }
        }
        }
            if (empty) EmptyChartBadge(Modifier.align(Alignment.Center))
        }
    }
}

/** پیام خالی بودن بازه، روی نمودارِ کم‌رنگ. */
@Composable
private fun EmptyChartBadge(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = cs.surface,
        shadowElevation = 3.dp,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🌱", fontSize = 16.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                "هنوز در این بازه مطالعه‌ای ثبت نشده",
                style = MaterialTheme.typography.labelLarge,
                color = cs.onSurface,
            )
        }
    }
}

// ============================================================ درس‌ها

@Composable
fun CoursesCard(breakdown: PeriodBreakdown?, loading: Boolean, palette: CoursePalette, period: ReportPeriod) {
    val cs = MaterialTheme.colorScheme
    var selected by remember(period, breakdown) { mutableStateOf<Int?>(null) }
    ReportCard {
        CardHeader("سهم درس‌ها", period.noun)
        Spacer(Modifier.height(10.dp))
        when {
            breakdown == null && loading -> { CardLoading(240); return@ReportCard }
            breakdown == null -> { CardEmpty("اطلاعات درس‌ها در دسترس نیست"); return@ReportCard }
            breakdown.courses.none { it.minutes > 0 } -> { CardEmpty("در این بازه مطالعه‌ای ثبت نشده"); return@ReportCard }
        }
        val all = breakdown!!.courses.filter { it.minutes > 0 }.sortedByDescending { it.minutes }
        val slices = remember(all, palette) {
            val top = all.take(6).map { DonutSlice(it.name, it.icon, it.minutes, it.sessions, palette[it.name]) }
            val rest = all.drop(6)
            if (rest.isEmpty()) top
            else top + DonutSlice("سایر درس‌ها", "➕", rest.sumOf { it.minutes }, rest.sumOf { it.sessions }, cs.outline)
        }
        val total = slices.sumOf { it.minutes }
        CourseDonut(
            slices = slices,
            selected = selected,
            onSelect = { selected = it },
            animKey = period,
            modifier = Modifier.size(214.dp).align(Alignment.CenterHorizontally),
        ) {
            val s = selected?.let { slices.getOrNull(it) }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(120.dp)) {
                if (s == null) {
                    Text(bigDuration(total), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text("${all.size.fa()} درس", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                } else {
                    Text(s.icon, fontSize = 20.sp)
                    Text(s.label, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    Text(bigDuration(s.minutes), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = s.color)
                    Text(percentOf(s.minutes, total), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        slices.forEachIndexed { i, s ->
            val on = selected == i
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) s.color.copy(alpha = 0.11f) else Color.Transparent)
                    .clickable { selected = if (on) null else i }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(32.dp).background(s.color.copy(alpha = 0.16f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Text(s.icon, fontSize = 15.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            s.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            percentOf(s.minutes, total) + (if (s.sessions > 0) " · ${s.sessions.fa()} پارت" else ""),
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.06f))) {
                        Box(
                            Modifier
                                .fillMaxWidth(s.minutes.toFloat() / (slices.maxOf { it.minutes }).coerceAtLeast(1))
                                .fillMaxHeight()
                                .clip(CircleShape)
                                .background(s.color),
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    ReportStats.clock(s.minutes),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    textAlign = TextAlign.End,
                    modifier = Modifier.width(64.dp),
                )
            }
        }
    }
}

// ============================================================ ریتم هفته

@Composable
fun RhythmCard(byDate: Map<String, Int>, todayIso: String, period: ReportPeriod) {
    val days = maxOf(period.days, 28)
    val stats = remember(byDate, todayIso, days) { ReportStats.weekdays(ReportStats.window(todayIso, days), byDate) }
    val avgs = stats.averages
    ReportCard {
        CardHeader("ریتم هفته", "میانگین هر روز هفته در ${if (days == period.days) period.noun else "۴ هفتهٔ اخیر"}")
        Spacer(Modifier.height(14.dp))
        if (avgs.all { it == 0 }) {
            CardEmpty("هنوز داده‌ای برای ریتم هفته نیست", 120)
            return@ReportCard
        }
        WeekdayRhythm(values = avgs, todayIndex = ReportStats.weekdayIndex(todayIso), animKey = period to days)
        Spacer(Modifier.height(14.dp))
        val best = avgs.indices.maxByOrNull { avgs[it] } ?: 0
        val worst = avgs.indices.filter { stats.counts[it] > 0 }.minByOrNull { avgs[it] } ?: best
        val name = Jalali.weekDayNames
        Insight(
            "📈",
            if (best == worst) "${name[best]}‌ها پرکارترین روزت هستند؛ میانگین ${bigDuration(avgs[best])}."
            else "${name[best]}‌ها با میانگین ${bigDuration(avgs[best])} پرکارترین روزت هستند و ${name[worst]}‌ها " +
                (if (avgs[worst] > 0) "با ${bigDuration(avgs[worst])} " else "") + "کم‌کارترین.",
        )
    }
}

// ============================================================ ساعت‌های طلایی

@Composable
fun HoursCard(breakdown: PeriodBreakdown?, loading: Boolean, period: ReportPeriod) {
    val cs = MaterialTheme.colorScheme
    var selected by remember(period, breakdown) { mutableStateOf<Int?>(null) }
    ReportCard {
        CardHeader("ساعت‌های طلایی", "در کدام ساعت‌های شبانه‌روز درس می‌خوانی")
        Spacer(Modifier.height(10.dp))
        val hours = breakdown?.hours
        when {
            hours == null && loading -> { CardLoading(260); return@ReportCard }
            hours == null || hours.all { it <= 0 } -> { CardEmpty("در این بازه ساعتی ثبت نشده"); return@ReportCard }
        }
        val h = hours!!
        val peak = ReportStats.peakHour(h)
        HourClock(
            hours = h,
            selected = selected,
            onSelect = { selected = it },
            animKey = period,
            modifier = Modifier.size(250.dp).align(Alignment.CenterHorizontally),
        ) {
            val s = selected
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (s == null) {
                    Text("اوج تمرکز", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    Text(
                        "${peak.fa()} تا ${((peak + 1) % 24).fa()}",
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = DayPartColors[ReportStats.dayPartOf(peak)],
                    )
                    Text(bigDuration(h[peak]), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                } else {
                    Text("ساعت ${s.fa()} تا ${((s + 1) % 24).fa()}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    Text(
                        if (h[s] > 0) bigDuration(h[s]) else "—",
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = DayPartColors[ReportStats.dayPartOf(s)],
                    )
                    Text(percentOf(h[s], h.sum()), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        val parts = ReportStats.dayParts(h)
        DayPartsBar(parts)
        Spacer(Modifier.height(14.dp))
        val top = parts.indices.maxByOrNull { parts[it] } ?: 0
        Insight(
            DayPartEmoji[top],
            "بیشترِ مطالعه‌ات ${DayPartNames[top]} است (${percentOf(parts[top], parts.sum())}) و پرکارترین ساعتت " +
                "${peak.fa()} تا ${((peak + 1) % 24).fa()}.",
        )
    }
}

// ============================================================ رکوردها

@Composable
fun RecordsCard(
    lifetimeMinutes: Int,
    lifetimeDays: Int,
    streak: Int,
    bestStreak: Int,
    byDate: Map<String, Int>,
    todayIso: String,
    onOpenDay: (String, Int) -> Unit,
) {
    val longest = remember(byDate) { ReportStats.longestStreak(byDate) }
    val record = remember(byDate) { byDate.filterValues { it > 0 }.maxByOrNull { it.value } }
    val bestMonth = remember(byDate, todayIso) {
        ReportStats.jalaliMonths(byDate, todayIso, 13).filter { it.minutes > 0 }.maxByOrNull { it.minutes }
    }
    val current = maxOf(streak, ReportStats.currentStreak(byDate, todayIso))
    ReportCard {
        CardHeader("رکوردها", "کارنامهٔ کل مسیرت")
        Spacer(Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RecordTile("📚", if (lifetimeMinutes > 0) bigDuration(lifetimeMinutes) else "—", "کل مطالعه", null, ChartPalette[0])
                RecordTile("✅", lifetimeDays.fa(), "روز مطالعه", null, ChartPalette[2])
            }
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RecordTile("🔥", "${current.fa()} روز", "استریک فعلی", null, ChartPalette[5])
                RecordTile(
                    "🏆", "${maxOf(bestStreak, longest.length).fa()} روز", "بهترین استریک",
                    longest.endIso?.takeIf { longest.length >= bestStreak && longest.length > 0 }?.let { "تا " + Fmt.jalaliShort(it) },
                    ChartPalette[3],
                )
            }
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RecordTile(
                    "⚡", record?.let { bigDuration(it.value) } ?: "—", "رکورد یک روز",
                    record?.let { Fmt.jalaliShort(it.key) + " ›" }, ChartPalette[4],
                    onClick = record?.let { r -> { onOpenDay(r.key, r.value) } },
                )
                RecordTile(
                    "👑", bestMonth?.let { bigDuration(it.minutes) } ?: "—", "بهترین ماه",
                    bestMonth?.let { Jalali.monthName(it.month) + " " + it.year.fa() }, ChartPalette[1],
                )
            }
        }
    }
}

@Composable
private fun RowScope.RecordTile(
    emoji: String,
    value: String,
    label: String,
    sub: String?,
    tint: Color,
    onClick: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.16f), tint.copy(alpha = 0.04f))))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(12.dp),
    ) {
        Text(emoji, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
        if (sub != null) {
            Text(
                sub,
                style = MaterialTheme.typography.labelSmall,
                color = if (onClick != null) cs.primary else tint,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
