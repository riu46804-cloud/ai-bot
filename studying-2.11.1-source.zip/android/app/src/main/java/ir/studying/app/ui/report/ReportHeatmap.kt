package ir.studying.app.ui.report

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Fmt
import ir.studying.app.core.Jalali
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa

/** رنگ هر پلهٔ شدت؛ پلهٔ صفر یعنی خانهٔ خالی. */
fun heatColor(level: Int, cs: ColorScheme): Color = when (level) {
    0 -> cs.onSurface.copy(alpha = 0.07f)
    1 -> cs.primary.copy(alpha = 0.30f)
    2 -> cs.primary.copy(alpha = 0.52f)
    3 -> cs.primary.copy(alpha = 0.76f)
    else -> cs.primary
}

private class HeatGrid(
    val weeks: Int,
    val startEpoch: Long,
    val todayEpoch: Long,
    val minutes: IntArray,
    val levels: IntArray,
    val months: List<Pair<Int, String>>,
    val activeDays: Int,
    val totalDays: Int,
)

/**
 * نقشهٔ حرارتی چند ماه اخیر. هر ستون یک هفته (شنبه بالا)، قدیمی‌ترین هفته
 * سمت راست و هفتهٔ جاری سمت چپ. شدت رنگ نسبت به صدک ۹۰ همین بازه است.
 * لمس یک خانه آن روز را نشان می‌دهد و از همان‌جا جزئیاتش باز می‌شود.
 */
@Composable
fun StudyHeatmap(
    byDate: Map<String, Int>,
    todayIso: String,
    onOpenDay: (String, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val tm = rememberTextMeasurer()
    val density = LocalDensity.current
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    val labelStyle = MaterialTheme.typography.labelSmall.copy(color = cs.onSurfaceVariant, fontSize = 9.sp)
    val monthStyle = MaterialTheme.typography.labelSmall.copy(color = cs.onSurfaceVariant, fontSize = 10.sp, fontWeight = FontWeight.Medium)

    BoxWithConstraints(modifier.fillMaxWidth()) {
        val boxWidth = maxWidth
        Column(Modifier.fillMaxWidth()) {
            val labelW = 18.dp
            val gap = 3.dp
            val avail = boxWidth - labelW
            val weeks = ((avail + gap) / (15.dp + gap)).toInt().coerceIn(8, 30)
            val cell = (avail - gap * (weeks - 1)) / weeks
            val monthH = 18.dp
            val height = monthH + cell * 7 + gap * 6

            val grid = remember(byDate, todayIso, weeks) { buildGrid(byDate, todayIso, weeks) }
            val reveal = rememberChartReveal(grid.weeks to grid.activeDays, 900)
            val sel by rememberUpdatedState(selected)
            val cellPx = with(density) { cell.toPx() }
            val gapPx = with(density) { gap.toPx() }
            val labelPx = with(density) { labelW.toPx() }
            val monthPx = with(density) { monthH.toPx() }

            fun colLeft(c: Int, width: Float): Float =
                if (rtl) width - labelPx - (c + 1) * cellPx - c * gapPx
                else labelPx + c * (cellPx + gapPx)

            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(height)
                    .pointerInput(grid, rtl, cellPx) {
                        detectTapGestures { pos ->
                            val w = size.width.toFloat()
                            val step = cellPx + gapPx
                            val fromStart = if (rtl) w - labelPx - pos.x else pos.x - labelPx
                            val c = (fromStart / step).toInt()
                            val r = ((pos.y - monthPx) / step).toInt()
                            if (fromStart < 0 || pos.y < monthPx || c !in 0 until grid.weeks || r !in 0..6) return@detectTapGestures
                            val e = grid.startEpoch + c * 7L + r
                            if (e > grid.todayEpoch) return@detectTapGestures
                            val iso = ReportStats.isoOfEpochDay(e)
                            selected = if (sel == iso) null else iso
                        }
                    },
            ) {
                val w = size.width
                val t = reveal.value
                val radius = CornerRadius(cellPx * 0.28f, cellPx * 0.28f)

                // نام ماه‌ها بالای ستونی که روز اولشان در آن است.
                var lastEdge = Float.NaN
                grid.months.forEach { (c, name) ->
                    val l = tm.measure(name, monthStyle)
                    val x0 = colLeft(c, w)
                    val left = if (rtl) x0 + cellPx - l.size.width else x0
                    val right = left + l.size.width
                    val fits = lastEdge.isNaN() || (if (rtl) right < lastEdge - 6f else left > lastEdge + 6f)
                    val inside = left >= 0f && right <= w
                    if (fits && inside) {
                        drawText(l, topLeft = Offset(left, (monthPx - l.size.height) / 2f - 1f))
                        lastEdge = if (rtl) left else right
                    }
                }

                // برچسب روزها: شنبه، دوشنبه، چهارشنبه، جمعه.
                for (r in 0..6 step 2) {
                    val y = monthPx + r * (cellPx + gapPx) + cellPx / 2f
                    val x = if (rtl) w else 0f
                    chartText(tm, WeekdayShort[r], labelStyle, x, y, align = if (rtl) 1f else 0f, centerY = true)
                }

                for (c in 0 until grid.weeks) {
                    val p = staggered(t, c, grid.weeks, spread = 0.55f)
                    if (p <= 0f) continue
                    val x = colLeft(c, w)
                    for (r in 0..6) {
                        val idx = c * 7 + r
                        val e = grid.startEpoch + idx
                        if (e > grid.todayEpoch) continue
                        val y = monthPx + r * (cellPx + gapPx)
                        val s = cellPx * (0.55f + 0.45f * p)
                        val off = (cellPx - s) / 2f
                        drawRoundRect(
                            color = heatColor(grid.levels[idx], cs),
                            topLeft = Offset(x + off, y + off),
                            size = Size(s, s),
                            cornerRadius = radius,
                            alpha = p,
                        )
                        val iso = ReportStats.isoOfEpochDay(e)
                        val isToday = e == grid.todayEpoch
                        if (isToday || iso == sel) {
                            val o = if (iso == sel) 2.2f * density.density else 1.4f * density.density
                            drawRoundRect(
                                color = if (iso == sel) cs.onSurface else cs.primary,
                                topLeft = Offset(x - o / 2f, y - o / 2f),
                                size = Size(cellPx + o, cellPx + o),
                                cornerRadius = CornerRadius(radius.x + o / 2f, radius.y + o / 2f),
                                style = Stroke(width = if (iso == sel) 1.8f * density.density else 1.3f * density.density),
                                alpha = p,
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            val current = selected
            Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                if (current != null) {
                    val m = (byDate[current] ?: 0).coerceAtLeast(0)
                    Column(Modifier.weight(1f)) {
                        Text(Fmt.jalaliWithDay(current), style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (m > 0) Fmt.minutes(m) else "بدون مطالعه",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (m > 0) cs.primary else cs.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = { onOpenDay(current, m) }, contentPadding = PaddingValues(horizontal = 10.dp)) {
                        Text("جزئیات روز ›", style = MaterialTheme.typography.labelLarge)
                    }
                } else {
                    Text(
                        "${grid.activeDays.fa()} روز فعال در ${grid.weeks.fa()} هفتهٔ اخیر",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    HeatLegend()
                }
            }
        }
    }
}

/** «کمتر ▢▢▢▢▢ بیشتر» */
@Composable
fun HeatLegend(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("کمتر", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, fontSize = 9.sp)
        Spacer(Modifier.width(2.dp))
        for (level in 0..4) {
            Spacer(Modifier.size(10.dp).background(heatColor(level, cs), RoundedCornerShape(3.dp)))
        }
        Spacer(Modifier.width(2.dp))
        Text("بیشتر", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, fontSize = 9.sp)
    }
}

private fun buildGrid(byDate: Map<String, Int>, todayIso: String, weeks: Int): HeatGrid {
    val today = ReportStats.epochDay(todayIso) ?: 0L
    val start = (ReportStats.epochDay(ReportStats.weekStart(todayIso)) ?: today) - (weeks - 1) * 7L
    val n = weeks * 7
    val minutes = IntArray(n)
    for (i in 0 until n) {
        val e = start + i
        if (e > today) break
        minutes[i] = (byDate[ReportStats.isoOfEpochDay(e)] ?: 0).coerceAtLeast(0)
    }
    val scale = ReportStats.heatScale(minutes.toList())
    val levels = IntArray(n) { ReportStats.heatLevel(minutes[it], scale) }
    val months = ArrayList<Pair<Int, String>>()
    for (c in 0 until weeks) {
        for (r in 0..6) {
            val e = start + c * 7L + r
            if (e > today) break
            val j = ReportStats.jalaliOf(ReportStats.isoOfEpochDay(e)) ?: continue
            if (j.day == 1) { months.add(c to Jalali.monthName(j.month)); break }
        }
    }
    // اگر اولین مرز ماه دیر می‌رسد، ستون اول هم نام ماهش را بگیرد.
    if (months.firstOrNull()?.first?.let { it >= 3 } != false) {
        ReportStats.jalaliOf(ReportStats.isoOfEpochDay(start))?.let { months.add(0, 0 to Jalali.monthName(it.month)) }
    }
    var active = 0
    var total = 0
    for (i in 0 until n) {
        if (start + i > today) break
        total++
        if (minutes[i] > 0) active++
    }
    return HeatGrid(weeks, start, today, minutes, levels, months, active, total)
}
