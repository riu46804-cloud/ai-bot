package ir.studying.app.ui.report

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.withStyle
import ir.studying.app.core.fa

// ============================================================ رنگ‌ها

const val NO_COURSE = "بدون درس"

/**
 * ده رنگ متمایز برای درس‌ها. چهار رنگی که کاربر می‌تواند برای درس انتخاب کند
 * (بنفش، سبز، قرمز، نارنجی) هم جزو همین‌هاست تا انتخابش در نمودار حفظ شود.
 */
val ChartPalette: List<Color> = listOf(
    Color(0xFFA78BFA), // بنفش
    Color(0xFF4ADE9F), // سبز نعنایی
    Color(0xFF38BDF8), // آبی آسمانی
    Color(0xFFFBBF24), // کهربایی
    Color(0xFFF87171), // قرمز
    Color(0xFFFB923C), // نارنجی
    Color(0xFF2DD4BF), // فیروزه‌ای
    Color(0xFFF472B6), // صورتی
    Color(0xFFA3E635), // لیمویی
    Color(0xFF6366F1), // نیلی
)

val NoCourseColor = Color(0xFF94A3B8)

/** رنگ بخش‌های روز: صبح، ظهر، عصر، شب. */
val DayPartColors = listOf(Color(0xFFFBBF24), Color(0xFFFB923C), Color(0xFFF472B6), Color(0xFF818CF8))
val DayPartNames = listOf("صبح", "ظهر", "عصر", "شب")
val DayPartEmoji = listOf("🌅", "☀️", "🌇", "🌙")
val WeekdayShort = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

/** کارت شاخص تیره؛ در هر دو تم روشن و تیره یکسان و پرکنتراست. */
val HeroTop = Color(0xFF111827)
val HeroBottom = Color(0xFF1E1B4B)
val UpColor = Color(0xFF34D399)
val DownColor = Color(0xFFFB7185)

private fun preferredIndex(key: String): Int? = when (key.trim().lowercase()) {
    "purple" -> 0
    "green" -> 1
    "red" -> 4
    "orange" -> 5
    else -> null
}

@Immutable
class CoursePalette(private val colors: Map<String, Color>) {
    operator fun get(name: String): Color = colors[name]
        ?: if (name == NO_COURSE) NoCourseColor
        else ChartPalette[Math.floorMod(name.hashCode(), ChartPalette.size)]

    /** جایگاه ثابت درس برای چیدن تکه‌های میله؛ درس پرکارتر پایین‌تر. */
    fun rank(name: String): Int = order[name] ?: Int.MAX_VALUE

    private val order: Map<String, Int> = colors.keys.withIndex().associate { it.value to it.index }
}

/**
 * هر درس در کل صفحه یک رنگ ثابت دارد. ترتیب از مجموع کل عمر می‌آید تا با
 * عوض شدن بازه رنگ‌ها جابه‌جا نشوند. رنگی که کاربر برای درس انتخاب کرده حفظ
 * می‌شود، مگر درس پرکارتری زودتر همان را گرفته باشد؛ آن‌وقت اولین رنگ آزاد.
 */
fun coursePalette(order: List<String>, preferred: Map<String, String>): CoursePalette {
    val out = LinkedHashMap<String, Color>()
    val used = BooleanArray(ChartPalette.size)
    for (name in order) {
        if (name in out) continue
        if (name == NO_COURSE) { out[name] = NoCourseColor; continue }
        val pref = preferred[name]?.let { preferredIndex(it) }
        val idx = if (pref != null && !used[pref]) pref
        else used.indexOfFirst { !it }.takeIf { it >= 0 } ?: (out.size % ChartPalette.size)
        used[idx] = true
        out[name] = ChartPalette[idx]
    }
    return CoursePalette(out)
}

// ============================================================ انیمیشن

/** پیشرفت خطی ۰ → ۱ که هر بار [key] عوض شود از نو پخش می‌شود. */
@Composable
fun rememberChartReveal(key: Any?, durationMs: Int = 950): Animatable<Float, AnimationVector1D> {
    val a = remember { Animatable(0f) }
    LaunchedEffect(key) {
        a.snapTo(0f)
        a.animateTo(1f, tween(durationMs, easing = LinearEasing))
    }
    return a
}

/** پیشرفت عضو [i] از [n] با تأخیر پلکانی؛ خروجی نرم‌شده. */
fun staggered(t: Float, i: Int, n: Int, spread: Float = 0.35f): Float {
    if (n <= 1) return FastOutSlowInEasing.transform(t.coerceIn(0f, 1f))
    val start = spread * i / (n - 1)
    val local = ((t - start) / (1f - spread)).coerceIn(0f, 1f)
    return FastOutSlowInEasing.transform(local)
}

// ============================================================ متن

/**
 * متنی که گوشه‌ای از آن روی [x] می‌نشیند.
 * [align] صفر یعنی لبهٔ چپ روی x، نیم یعنی وسط، یک یعنی لبهٔ راست.
 */
fun DrawScope.chartText(
    tm: TextMeasurer,
    text: String,
    style: TextStyle,
    x: Float,
    y: Float,
    align: Float = 0.5f,
    alpha: Float = 1f,
    centerY: Boolean = false,
) {
    if (text.isEmpty()) return
    val l = tm.measure(text, style)
    val top = if (centerY) y - l.size.height / 2f else y
    drawText(l, topLeft = Offset(x - l.size.width * align, top), alpha = alpha.coerceIn(0f, 1f))
}

/** خط نرم (منحنی بزیه با مماس افقی) که هیچ‌وقت از بازهٔ دو سرش بیرون نمی‌زند. */


/** «۲ ساعت ۱۵ دقیقه» با عددهای درشت و واحدهای ریز. */
fun durationAnnotated(minutes: Int, number: SpanStyle, unit: SpanStyle) = buildAnnotatedString {
    val m = minutes.coerceAtLeast(0)
    val h = m / 60
    val mm = m % 60
    if (h > 0) {
        withStyle(number) { append(h.fa()) }
        withStyle(unit) { append(" ساعت") }
    }
    if (mm > 0 || h == 0) {
        if (h > 0) append("  ")
        withStyle(number) { append(mm.fa()) }
        withStyle(unit) { append(" دقیقه") }
    }
}

/** «۴۲ ساعت» برای عددهای بزرگ، «۲:۱۵» برای کمتر از ده ساعت. */
fun bigDuration(minutes: Int): String {
    val m = minutes.coerceAtLeast(0)
    return when {
        m >= 600 -> (m / 60).fa() + " ساعت"
        m >= 60 -> ir.studying.app.core.ReportStats.clock(m)
        else -> m.fa() + " دقیقه"
    }
}

/** درصد گرد شده با رقم فارسی. */
fun percentOf(part: Int, total: Int): String =
    if (total <= 0) "۰٪" else (Math.round(part * 100f / total)).fa() + "٪"
