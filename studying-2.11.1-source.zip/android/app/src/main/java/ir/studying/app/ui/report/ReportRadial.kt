package ir.studying.app.ui.report

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa
import ir.studying.app.data.HourlyPart
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** حلقهٔ پیشرفت با گرادیان چرخشی و گوی نورانی سرِ قوس. */
@Composable
fun GoalRing(
    progress: Float,
    modifier: Modifier = Modifier,
    stroke: Dp = 12.dp,
    track: Color,
    colors: List<Color>,
    content: @Composable BoxScope.() -> Unit,
) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(progress) {
        anim.animateTo(progress.coerceIn(0f, 1f), tween(1200, easing = FastOutSlowInEasing))
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val d = size.minDimension - sw
            val tl = Offset((size.width - d) / 2f, (size.height - d) / 2f)
            val arc = Size(d, d)
            drawArc(track, -90f, 360f, false, tl, arc, style = Stroke(sw))
            val frac = anim.value
            if (frac > 0.002f) {
                val c1 = colors.firstOrNull() ?: Color.White
                val c2 = colors.lastOrNull() ?: c1
                rotate(-90f) {
                    drawArc(
                        Brush.sweepGradient(0f to c1, frac.coerceAtLeast(0.01f) to c2, 1f to c1),
                        0f, 360f * frac, false, tl, arc,
                        style = Stroke(sw, cap = StrokeCap.Round),
                    )
                }
                val a = Math.toRadians((360.0 * frac) - 90.0)
                val r = d / 2f
                val tip = Offset(center.x + (cos(a) * r).toFloat(), center.y + (sin(a) * r).toFloat())
                drawCircle(c2.copy(alpha = 0.35f), sw * 0.95f, tip)
                drawCircle(Color.White, sw * 0.3f, tip)
            }
        }
        content()
    }
}

@Immutable
data class DonutSlice(val label: String, val icon: String, val minutes: Int, val sessions: Int, val color: Color)

/**
 * دونات سهم درس‌ها با فاصلهٔ ظریف بین تکه‌ها. تکهٔ انتخاب‌شده بیرون می‌زند
 * و بقیه کم‌رنگ می‌شوند؛ وسط دونات را صدا زننده پر می‌کند.
 */
@Composable
fun CourseDonut(
    slices: List<DonutSlice>,
    selected: Int?,
    onSelect: (Int?) -> Unit,
    animKey: Any?,
    modifier: Modifier = Modifier,
    centerContent: @Composable BoxScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val reveal = rememberChartReveal(animKey, 1100)
    val total = slices.sumOf { it.minutes }.coerceAtLeast(1)
    val sel by rememberUpdatedState(selected)
    val onSel by rememberUpdatedState(onSelect)
    val ring = cs.onSurface.copy(alpha = 0.06f)
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(slices) {
                    detectTapGestures { pos ->
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val v = pos - c
                        val dist = v.getDistance()
                        val outer = min(size.width, size.height) / 2f - 8.dp.toPx()
                        val inner = outer - 26.dp.toPx()
                        if (dist < inner - 16.dp.toPx() || dist > outer + 16.dp.toPx()) {
                            onSel(null); return@detectTapGestures
                        }
                        var ang = Math.toDegrees(atan2(v.y.toDouble(), v.x.toDouble())).toFloat() + 90f
                        if (ang < 0f) ang += 360f
                        var acc = 0f
                        var hit: Int? = null
                        slices.forEachIndexed { i, s ->
                            val sw = 360f * s.minutes / total
                            if (hit == null && ang >= acc && ang < acc + sw) hit = i
                            acc += sw
                        }
                        onSel(if (hit == sel) null else hit)
                    }
                },
        ) {
            val stroke = 26.dp.toPx()
            val pop = 8.dp.toPx()
            val outer = size.minDimension / 2f - pop
            val r = outer - stroke / 2f
            drawCircle(ring, r, center, style = Stroke(stroke))
            val gap = if (slices.size > 1) 2.2f else 0f
            val shown = 360f * FastOutSlowInEasing.transform(reveal.value)
            var start = 0f
            slices.forEachIndexed { i, s ->
                val full = 360f * s.minutes / total
                val visible = (min(start + full, shown) - start).coerceAtLeast(0f)
                if (visible > 0.05f) {
                    val isSel = sel == i
                    val dim = sel != null && !isSel
                    val sw = if (isSel) stroke + 8.dp.toPx() else stroke
                    val rr = if (isSel) r + 3.dp.toPx() else r
                    val sweep = if (visible > gap + 0.4f) visible - gap else visible * 0.6f
                    drawArc(
                        s.color, start - 90f + gap / 2f, sweep, false,
                        Offset(center.x - rr, center.y - rr), Size(rr * 2, rr * 2),
                        alpha = if (dim) 0.32f else 1f,
                        style = Stroke(sw, cap = StrokeCap.Butt),
                    )
                }
                start += full
            }
        }
        centerContent()
    }
}

/**
 * ساعت ۲۴ساعتهٔ قطبی: هر ساعت یک پرتو که طولش دقیقه‌های آن ساعت است و
 * رنگش بخش روز. پرکارترین ساعت پررنگ‌تر می‌درخشد.
 */
@Composable
fun HourClock(
    hours: List<Int>,
    selected: Int?,
    onSelect: (Int?) -> Unit,
    animKey: Any?,
    modifier: Modifier = Modifier,
    centerContent: @Composable BoxScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val tm = rememberTextMeasurer()
    val reveal = rememberChartReveal(animKey, 1200)
    val maxV = (hours.maxOrNull() ?: 0).coerceAtLeast(1)
    val peak = ReportStats.peakHour(hours)
    val track = cs.onSurface.copy(alpha = 0.06f)
    val labelStyle = MaterialTheme.typography.labelSmall.copy(color = cs.onSurfaceVariant, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    val sel by rememberUpdatedState(selected)
    val onSel by rememberUpdatedState(onSelect)
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { pos ->
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val v = pos - c
                        val outer = min(size.width, size.height) / 2f - 20.dp.toPx()
                        val dist = v.getDistance()
                        if (dist < outer * 0.3f || dist > outer + 18.dp.toPx()) {
                            onSel(null); return@detectTapGestures
                        }
                        var ang = Math.toDegrees(atan2(v.y.toDouble(), v.x.toDouble())).toFloat() + 90f
                        if (ang < 0f) ang += 360f
                        val h = (ang / 15f).toInt().coerceIn(0, 23)
                        onSel(if (sel == h) null else h)
                    }
                },
        ) {
            val outer = size.minDimension / 2f - 20.dp.toPx()
            val r0 = outer * 0.5f
            val bw = min((2 * PI * (r0 + (outer - r0) * 0.25f) / 24.0 * 0.58).toFloat(), 9.dp.toPx())
            drawCircle(track, r0 - 7.dp.toPx(), center, style = Stroke(1.dp.toPx()))
            for (h in 0 until 24) {
                val a = Math.toRadians(h * 15.0 + 7.5 - 90.0)
                val dir = Offset(cos(a).toFloat(), sin(a).toFloat())
                val start = center + dir * r0
                drawLine(track, start, center + dir * outer, strokeWidth = bw, cap = StrokeCap.Round)
                val v = hours.getOrElse(h) { 0 }
                if (v > 0) {
                    val len = max((outer - r0) * (v.toFloat() / maxV) * staggered(reveal.value, h, 24, 0.5f), 0.5f)
                    val dim = sel != null && sel != h
                    val color = DayPartColors[ReportStats.dayPartOf(h)]
                    if (h == peak && !dim) {
                        drawLine(color.copy(alpha = 0.25f), start, start + dir * len, strokeWidth = bw * 2.1f, cap = StrokeCap.Round)
                    }
                    drawLine(color, start, start + dir * len, strokeWidth = bw, cap = StrokeCap.Round,
                        alpha = when { dim -> 0.28f; h == peak || sel == h -> 1f; else -> 0.8f })
                }
            }
            for (h in listOf(0, 6, 12, 18)) {
                val a = Math.toRadians(h * 15.0 - 90.0)
                val p = center + Offset(cos(a).toFloat(), sin(a).toFloat()) * (outer + 11.dp.toPx())
                chartText(tm, h.fa(), labelStyle, p.x, p.y, 0.5f, centerY = true)
            }
        }
        centerContent()
    }
}

/** نوار ۱۰۰٪ صبح/ظهر/عصر/شب با درصد زیر هر بخش. */
@Composable
fun DayPartsBar(parts: List<Int>, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val total = parts.sum()
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().height(12.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.06f)),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (total > 0) parts.forEachIndexed { i, v ->
                if (v > 0) Box(Modifier.weight(v.toFloat()).fillMaxHeight().background(DayPartColors[i]))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            parts.forEachIndexed { i, v ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(DayPartColors[i], CircleShape))
                        Spacer(Modifier.width(4.dp))
                        Text(DayPartEmoji[i] + " " + DayPartNames[i], style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                    Text(percentOf(v, total), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

/**
 * نوار ۲۴ ساعته‌ی یک روز: هر پارت به رنگ درسش. ساعت صفر سمت راست است
 * (راست‌به‌چپ)، نشانگر سفید یعنی «الان».
 */
@Composable
fun DayTimeline(
    parts: List<HourlyPart>,
    palette: CoursePalette,
    modifier: Modifier = Modifier,
    nowMinute: Int? = null,
    onDark: Boolean = false,
    barHeight: Dp = 22.dp,
) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val track = if (onDark) Color.White.copy(alpha = 0.08f) else cs.onSurface.copy(alpha = 0.06f)
    val tick = if (onDark) Color.White.copy(alpha = 0.16f) else cs.outlineVariant
    val labelColor = if (onDark) Color.White.copy(alpha = 0.55f) else cs.onSurfaceVariant
    val nowColor = if (onDark) Color.White else cs.onSurface
    val spans = remember(parts) {
        parts.mapNotNull { p -> ReportStats.span(p.start, p.minutes)?.let { Triple(it.first, it.second, p.course) } }
    }
    val reveal = rememberChartReveal(spans.size, 1000)
    Column(modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(barHeight)) {
            val w = size.width
            val h = size.height
            fun x(min: Int): Float {
                val f = min / 1440f
                return if (rtl) w * (1f - f) else w * f
            }
            drawRoundRect(track, cornerRadius = CornerRadius(h / 2.4f))
            for (hh in 3 until 24 step 3) {
                val xx = x(hh * 60)
                drawLine(tick, Offset(xx, h * 0.32f), Offset(xx, h * 0.68f), strokeWidth = 1.dp.toPx())
            }
            val t = FastOutSlowInEasing.transform(reveal.value)
            spans.forEach { (s, e, course) ->
                val end = max(e, s + 6)
                val shown = s + ((end - s) * t).toInt()
                val x1 = x(s)
                val x2 = x(shown)
                val left = min(x1, x2)
                val width = max(kotlin.math.abs(x2 - x1), 2.5.dp.toPx())
                drawRoundRect(palette[course], Offset(left, h * 0.16f), Size(width, h * 0.68f), CornerRadius(4.dp.toPx()))
            }
            nowMinute?.let { nm ->
                val xx = x(nm.coerceIn(0, 1440))
                drawLine(nowColor, Offset(xx, -2.dp.toPx()), Offset(xx, h + 2.dp.toPx()), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(nowColor, 3.dp.toPx(), Offset(xx, -2.dp.toPx()))
            }
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf(0, 6, 12, 18, 24).forEach { hh ->
                Text(
                    (if (hh < 10) "0$hh" else hh.toString()).fa(),
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = labelColor,
                )
            }
        }
    }
}
