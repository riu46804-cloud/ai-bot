package ir.studying.app.ui.report

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Fmt
import ir.studying.app.core.Game
import ir.studying.app.core.Goals
import ir.studying.app.core.IranTime
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.ReportStats
import ir.studying.app.core.fa
import ir.studying.app.data.HourlyPart
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.components.SegmentedTabs
import ir.studying.app.ui.components.SkeletonBox
import ir.studying.app.ui.components.shimmerBrush
import ir.studying.app.ui.nav.LocalBottomBarPadding
import kotlinx.coroutines.delay
import java.util.Calendar

private fun minuteNow(): Int = IranTime.calendar().let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

/**
 * صفحهٔ «گزارش»: همهٔ آمار مطالعه یک‌جا. بالای صفحه امروز است، بعد بازهٔ
 * انتخابی (هفته تا سال) با شاخص‌ها و نمودارها، و آخر نقشهٔ حرارتی، تقویم و رکوردها.
 */
@Composable
fun ReportScreen(vm: ReportViewModel = viewModel()) {
    val s by vm.state.collectAsState()
    val game by Game.state.collectAsState()
    val dailyGoal by Goals.daily.collectAsState()
    val weeklyGoal by Goals.weekly.collectAsState()
    var nowMinute by remember { mutableIntStateOf(minuteNow()) }

    LaunchedEffect(Unit) { if (!vm.state.value.loading) vm.refresh(silent = true) }
    LaunchedEffect(Unit) { Game.refresh() }
    LaunchedEffect(Unit) {
        RefreshBus.events.collect { tag -> if (tag == "study" || tag == "all") vm.refresh(silent = true) }
    }
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMinute = minuteNow() } }
    LaunchedEffect(Unit) { while (true) { delay(90_000); vm.refresh(silent = true) } }

    var showGoal by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }
    var showTimeline by remember { mutableStateOf(false) }
    var dayDetail by remember { mutableStateOf<Pair<String, Int>?>(null) }
    val openDay: (String, Int) -> Unit = { iso, m -> dayDetail = iso to m }

    // هر درس در کل صفحه یک رنگ ثابت؛ ترتیب از مجموع کل عمر.
    val palette = remember(s.lifetimeCourses, s.breakdowns, s.stacks, s.todayParts, s.yesterdayParts, s.courses) {
        val order = LinkedHashSet<String>()
        s.lifetimeCourses.sortedByDescending { it.minutes }.forEach { order.add(it.name) }
        s.breakdowns.values.forEach { b -> b.courses.sortedByDescending { it.minutes }.forEach { order.add(it.name) } }
        s.stacks.values.forEach { m -> m.values.forEach { d -> d.courses.forEach { order.add(it.name) } } }
        s.todayParts.forEach { order.add(it.course) }
        s.yesterdayParts.forEach { order.add(it.course) }
        val preferred = HashMap<String, String>()
        s.courses.forEach { preferred[it.name] = it.color }
        s.breakdowns.values.forEach { b -> b.courses.forEach { if (it.colorKey.isNotBlank()) preferred[it.name] = it.colorKey } }
        coursePalette(order.toList(), preferred)
    }

    when {
        s.loading && s.days.isEmpty() -> { ReportSkeleton(); return }
        s.error != null && s.days.isEmpty() -> {
            ErrorState(s.error ?: "", modifier = Modifier.padding(16.dp), onRetry = { vm.refresh() })
            return
        }
    }

    val today = s.todayIso
    val byDate = s.minutesByDate
    val period = s.period
    val dates = remember(today, period) { ReportStats.window(today, period.days) }
    val cur = remember(dates, s.days) { ReportStats.summarize(dates, s.days) }
    val prev = remember(today, period, s.days) {
        if (!period.comparable) null
        else ReportStats.summarize(ReportStats.window(ReportStats.shift(today, -period.days), period.days), s.days)
    }
    val breakdown = s.breakdowns[period]
    val periodLoading = period in s.loadingPeriods
    val avg7 = remember(today, s.days) {
        ReportStats.summarize(ReportStats.window(ReportStats.shift(today, -1), 7), s.days).avgPerDay
    }
    val yesterdayUntilNow = remember(s.yesterdayParts, nowMinute) {
        ReportStats.minutesUntil(s.yesterdayParts.mapNotNull { ReportStats.span(it.start, it.minutes) }, nowMinute)
    }
    val todayMinutes = s.todayMinutes
    val deltaYesterday = if (todayMinutes == 0 && yesterdayUntilNow == 0) null else todayMinutes - yesterdayUntilNow
    val weekMinutes = remember(today, byDate) {
        ReportStats.window(today, ReportStats.weekdayIndex(today) + 1).sumOf { byDate[it] ?: 0 }
    }

    Refreshable(onRefresh = { vm.refresh() }, refreshing = s.refreshing) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp, top = 16.dp,
                bottom = 24.dp + LocalBottomBarPadding.current.calculateBottomPadding(),
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item("header") {
                FadeSlideIn(0) {
                    ReportHeader(
                        onGoal = { showGoal = true },
                        onShare = { vm.loadReport(); showReport = true },
                    )
                }
            }
            item("hero") {
                FadeSlideIn(1) {
                    TodayHero(
                        todayMinutes = todayMinutes,
                        goal = dailyGoal,
                        average = avg7,
                        deltaVsYesterday = deltaYesterday,
                        parts = s.todayParts,
                        palette = palette,
                        nowMinute = nowMinute,
                        weekMinutes = weekMinutes,
                        weeklyGoal = weeklyGoal,
                        onReport = { vm.loadReport(); showReport = true },
                        onTimeline = { showTimeline = true },
                        onGoal = { showGoal = true },
                    )
                }
            }
            item("periods") {
                FadeSlideIn(2) {
                    Column {
                        SegmentedTabs(ReportPeriod.entries.map { it.label }, period.ordinal) {
                            vm.selectPeriod(ReportPeriod.entries[it])
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${Fmt.jalaliShort(dates.firstOrNull())} تا ${Fmt.jalaliShort(today)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f),
                            )
                            if (periodLoading) {
                                CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(6.dp))
                            }
                            if (prev != null) {
                                Text(
                                    "مقایسه با ${period.days.fa()} روز قبل",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                                )
                            }
                        }
                    }
                }
            }
            item("kpis") {
                FadeSlideIn(3) { KpiGrid(cur, prev, breakdown, periodLoading, period, onBestDay = openDay) }
            }
            item("trend") {
                FadeSlideIn(4) {
                    TrendCard(
                        period = period,
                        dates = dates,
                        byDate = byDate,
                        stacks = s.stacks[period],
                        courseOrder = breakdown?.courses?.sortedByDescending { it.minutes }?.map { it.name }.orEmpty(),
                        palette = palette,
                        goal = dailyGoal,
                        summary = cur,
                        todayIso = today,
                        onOpenDay = openDay,
                    )
                }
            }
            item("courses") {
                FadeSlideIn(5) { CoursesCard(breakdown, periodLoading, palette, period) }
            }
            item("rhythm") {
                FadeSlideIn(6) { RhythmCard(byDate, today, period) }
            }
            item("hours") {
                FadeSlideIn(7) { HoursCard(breakdown, periodLoading, period) }
            }
            item("heat") {
                FadeSlideIn(8) {
                    ReportCard {
                        CardHeader("نقشهٔ مطالعه", "هر خانه یک روز؛ پررنگ‌تر یعنی بیشتر")
                        Spacer(Modifier.height(14.dp))
                        StudyHeatmap(byDate, today, onOpenDay = openDay)
                    }
                }
            }
            item("calendar") {
                FadeSlideIn(9) {
                    ReportCard {
                        CardHeader("تقویم مطالعه", "روی هر روز بزن تا جزئیاتش را ببینی")
                        Spacer(Modifier.height(8.dp))
                        MonthCalendar(byDate, today, onOpenDay = openDay)
                    }
                }
            }
            item("records") {
                FadeSlideIn(10) {
                    RecordsCard(
                        lifetimeMinutes = s.lifetimeMinutes,
                        lifetimeDays = s.lifetimeDays,
                        streak = s.streak,
                        bestStreak = game.bestStreak,
                        byDate = byDate,
                        todayIso = today,
                        onOpenDay = openDay,
                    )
                }
            }
        }
    }

    if (showGoal) ir.studying.app.ui.home.GoalPickerSheet(onDismiss = { showGoal = false })
    if (showReport) {
        DailyReportSheet(
            report = s.report,
            loading = s.reportLoading,
            palette = palette,
            onRetry = { vm.loadReport() },
            onDismiss = { showReport = false },
        )
    }
    if (showTimeline) {
        TimelineSheet(
            today = s.todayParts,
            yesterday = s.yesterdayParts,
            palette = palette,
            courses = s.courses,
            nowMinute = nowMinute,
            onLoadCourses = { vm.loadCourses() },
            onDelete = { p -> vm.deletePart(p) { err -> AppSnack.show(err ?: "پارت حذف شد") } },
            onSetCourse = { p, id ->
                vm.setPartCourse(p, id) { err -> AppSnack.show(err ?: if (id == null) "درس پارت برداشته شد" else "درس پارت عوض شد") }
            },
            onDismiss = { showTimeline = false },
        )
    }
    dayDetail?.let { (iso, m) ->
        ir.studying.app.ui.home.DayDetailSheet(dateIso = iso, minutes = m, onDismiss = { dayDetail = null })
    }
}

// ============================================================ سربرگ

@Composable
private fun ReportHeader(onGoal: () -> Unit, onShare: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("گزارش", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text(Fmt.todayFull(), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
        HeaderAction(Icons.Rounded.Flag, "هدف روزانه", onGoal)
        Spacer(Modifier.width(8.dp))
        HeaderAction(Icons.Rounded.Share, "اشتراک گزارش امروز", onShare)
    }
}

@Composable
private fun HeaderAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(cs.surfaceVariant.copy(alpha = 0.6f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = cs.onSurface, modifier = Modifier.size(20.dp))
    }
}

// ============================================================ امروز

@Composable
private fun TodayHero(
    todayMinutes: Int,
    goal: Int,
    average: Int,
    deltaVsYesterday: Int?,
    parts: List<HourlyPart>,
    palette: CoursePalette,
    nowMinute: Int,
    weekMinutes: Int,
    weeklyGoal: Int,
    onReport: () -> Unit,
    onTimeline: () -> Unit,
    onGoal: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val glow = cs.primary
    val target = if (goal > 0) goal else average
    val progress = if (target > 0) todayMinutes.toFloat() / target else 0f
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(HeroTop, HeroBottom)))
            .drawBehind {
                drawCircle(
                    Brush.radialGradient(
                        listOf(glow.copy(alpha = 0.38f), Color.Transparent),
                        center = Offset(size.width * 0.12f, 0f),
                        radius = size.width * 0.75f,
                    ),
                    radius = size.width * 0.75f,
                    center = Offset(size.width * 0.12f, 0f),
                )
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFF38BDF8).copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width, size.height),
                        radius = size.width * 0.6f,
                    ),
                    radius = size.width * 0.6f,
                    center = Offset(size.width, size.height),
                )
            }
            .padding(18.dp),
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GoalRing(
                    progress = progress,
                    modifier = Modifier.size(116.dp),
                    stroke = 11.dp,
                    track = Color.White.copy(alpha = 0.10f),
                    colors = listOf(cs.primary, Color(0xFF38BDF8)),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (target > 0) {
                            Text(
                                (Math.round(progress * 100)).fa() + "٪",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                            )
                            Text(
                                if (goal > 0) "از " + bigDuration(goal) else "از میانگین",
                                color = Color.White.copy(alpha = 0.6f),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        } else {
                            Text("🎯", fontSize = 24.sp)
                            Text("هدف بگذار", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("امروز", color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.labelMedium)
                    Text(
                        durationAnnotated(
                            todayMinutes,
                            number = SpanStyle(fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White),
                            unit = SpanStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = 0.7f)),
                        ),
                        maxLines = 1,
                    )
                    if (deltaVsYesterday != null) {
                        val up = deltaVsYesterday > 0
                        val same = deltaVsYesterday == 0
                        Text(
                            when {
                                same -> "هم‌پای دیروز تا همین ساعت"
                                up -> "▲ ${Fmt.minutes(deltaVsYesterday)} جلوتر از دیروز تا همین ساعت"
                                else -> "▼ ${Fmt.minutes(-deltaVsYesterday)} عقب‌تر از دیروز تا همین ساعت"
                            },
                            color = when { same -> Color.White.copy(alpha = 0.7f); up -> UpColor; else -> DownColor },
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    if (goal > 0) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (todayMinutes >= goal) "🎉 هدف امروز کامل شد"
                            else "${Fmt.minutes(goal - todayMinutes)} تا هدف امروز",
                            color = if (todayMinutes >= goal) UpColor else Color.White.copy(alpha = 0.72f),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    } else {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "تعیین هدف روزانه ›",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onGoal).padding(vertical = 2.dp),
                        )
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            DayTimeline(parts, palette, nowMinute = nowMinute, onDark = true)
            if (parts.isEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "هنوز پارتی ثبت نشده؛ اولین تایمر امروز را بزن 💪",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.labelSmall,
                )
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                HeroStat("پارت", if (parts.isEmpty()) "—" else parts.size.fa())
                HeroDivider()
                HeroStat("اولین شروع", parts.minByOrNull { ReportStats.minuteOfDay(it.start) ?: 9999 }?.let { Fmt.hm(it.start) } ?: "—")
                HeroDivider()
                HeroStat("آخرین پایان", parts.maxByOrNull { ReportStats.minuteOfDay(it.end) ?: -1 }?.let { Fmt.hm(it.end) } ?: "—")
                HeroDivider()
                HeroStat("میانگین ۷ روز", if (average > 0) bigDuration(average) else "—")
            }

            if (weeklyGoal > 0) {
                Spacer(Modifier.height(14.dp))
                val wp = (weekMinutes.toFloat() / weeklyGoal).coerceIn(0f, 1f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("هدف این هفته", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                    Text(
                        "${bigDuration(weekMinutes)} از ${bigDuration(weeklyGoal)}",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))) {
                    Box(
                        Modifier
                            .fillMaxWidth(wp)
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(Brush.horizontalGradient(listOf(cs.primary, Color(0xFF38BDF8)))),
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HeroButton(Icons.Rounded.Assessment, "گزارش امروز", onReport)
                HeroButton(Icons.Rounded.Timeline, "تایم‌لاین", onTimeline)
            }
        }
    }
}

@Composable
private fun RowScope.HeroStat(label: String, value: String) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun HeroDivider() {
    Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 4.dp).background(Color.White.copy(alpha = 0.12f)))
}

@Composable
private fun RowScope.HeroButton(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .weight(1f)
            .height(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

// ============================================================ شاخص‌ها

private data class Delta(val text: String, val up: Boolean?)

private fun pctDelta(cur: Int, prev: Int?): Delta? {
    if (prev == null) return null
    val p = ReportStats.deltaPercent(cur, prev) ?: return null
    val text = if (kotlin.math.abs(p) > 999) "۹۹۹+٪" else kotlin.math.abs(p).fa() + "٪"
    return when {
        p > 0 -> Delta(text, true)
        p < 0 -> Delta(text, false)
        else -> Delta("۰٪", null)
    }
}

private fun countDelta(cur: Int, prev: Int?): Delta? {
    if (prev == null) return null
    val d = cur - prev
    return when {
        d > 0 -> Delta(d.fa(), true)
        d < 0 -> Delta((-d).fa(), false)
        else -> Delta("۰", null)
    }
}

@Composable
private fun KpiGrid(
    cur: ReportStats.Summary,
    prev: ReportStats.Summary?,
    breakdown: PeriodBreakdown?,
    loading: Boolean,
    period: ReportPeriod,
    onBestDay: (String, Int) -> Unit,
) {
    val sessions = if (cur.sessions > 0) cur.sessions else breakdown?.sessions ?: 0
    val avgSession = if (sessions > 0) Math.round(cur.total.toFloat() / sessions) else 0
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiTile(
                icon = Icons.Rounded.HourglassBottom, tint = ChartPalette[0],
                label = "مجموع مطالعه", value = if (cur.total > 0) bigDuration(cur.total) else "—",
                sub = prev?.let { "دورهٔ قبل: " + if (it.total > 0) bigDuration(it.total) else "—" },
                delta = pctDelta(cur.total, prev?.total),
            )
            KpiTile(
                icon = Icons.Rounded.Speed, tint = ChartPalette[2],
                label = "میانگین روزانه", value = if (cur.avgPerDay > 0) bigDuration(cur.avgPerDay) else "—",
                sub = if (cur.activeDays > 0) "روزهای فعال: " + bigDuration(cur.avgPerActiveDay) else null,
                delta = pctDelta(cur.avgPerDay, prev?.avgPerDay),
            )
        }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiTile(
                icon = Icons.Rounded.EventAvailable, tint = ChartPalette[1],
                label = "روزهای فعال", value = "${cur.activeDays.fa()} از ${cur.days.fa()}",
                sub = percentOf(cur.activeDays, cur.days) + " روزها مطالعه داشتی",
                delta = countDelta(cur.activeDays, prev?.activeDays),
                progress = if (cur.days > 0) cur.activeDays.toFloat() / cur.days else 0f,
            )
            KpiTile(
                icon = Icons.Rounded.EmojiEvents, tint = ChartPalette[3],
                label = "بهترین روز", value = if (cur.bestMinutes > 0) bigDuration(cur.bestMinutes) else "—",
                sub = cur.bestIso?.let { Fmt.jalaliWithDay(it) + " ›" },
                delta = null,
                onClick = cur.bestIso?.let { iso -> { onBestDay(iso, cur.bestMinutes) } },
            )
        }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiTile(
                icon = Icons.Rounded.Layers, tint = ChartPalette[7],
                label = "پارت‌ها", value = if (sessions > 0) sessions.fa() else "—",
                sub = if (avgSession > 0) "میانگین هر پارت " + bigDuration(avgSession) else null,
                delta = if (cur.sessions > 0) pctDelta(cur.sessions, prev?.sessions) else null,
            )
            val best = breakdown?.bestSession ?: 0
            KpiTile(
                icon = Icons.Rounded.Bolt, tint = ChartPalette[5],
                label = "طولانی‌ترین پارت",
                value = when {
                    best > 0 -> bigDuration(best)
                    breakdown == null && loading -> "…"
                    else -> "—"
                },
                sub = "در " + period.noun,
                delta = null,
            )
        }
    }
}

@Composable
private fun RowScope.KpiTile(
    icon: ImageVector,
    tint: Color,
    label: String,
    value: String,
    sub: String?,
    delta: Delta?,
    progress: Float? = null,
    onClick: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.weight(1f).fillMaxHeight(),
        shape = RoundedCornerShape(20.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.55f)),
    ) {
        Column(
            Modifier
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(30.dp).background(tint.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(17.dp)) }
                Spacer(Modifier.weight(1f))
                if (delta != null) DeltaChip(delta)
            }
            Spacer(Modifier.height(10.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, maxLines = 1)
            if (progress != null) {
                Spacer(Modifier.height(7.dp))
                Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.07f))) {
                    Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(tint))
                }
            }
            if (sub != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    sub,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (onClick != null) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun DeltaChip(d: Delta) {
    val color = when (d.up) { true -> UpColor; false -> DownColor; null -> MaterialTheme.colorScheme.onSurfaceVariant }
    val arrow = when (d.up) { true -> "▲ "; false -> "▼ "; null -> "" }
    Text(
        arrow + d.text,
        color = color,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(CircleShape)
            .background(color.copy(alpha = 0.13f))
            .padding(horizontal = 7.dp, vertical = 2.dp),
    )
}

// ============================================================ اسکلت

@Composable
private fun ReportSkeleton() {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.fillMaxWidth(0.4f).height(26.dp).clip(RoundedCornerShape(8.dp)).background(shimmerBrush()))
        Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(28.dp)).background(shimmerBrush()))
        Box(Modifier.fillMaxWidth().height(44.dp).clip(CircleShape).background(shimmerBrush()))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f).height(110.dp).clip(RoundedCornerShape(20.dp)).background(shimmerBrush()))
            Box(Modifier.weight(1f).height(110.dp).clip(RoundedCornerShape(20.dp)).background(shimmerBrush()))
        }
        SkeletonBox(height = 160.dp)
    }
}
