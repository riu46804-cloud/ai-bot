package ir.studying.app.ui.report

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Api
import ir.studying.app.core.Fmt
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.ReportStats
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.core.humanizeError
import ir.studying.app.data.Course
import ir.studying.app.data.DailyReport
import ir.studying.app.data.HourlyPart
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.DailyQuestionStats
import ir.studying.app.ui.components.EmptyState
import ir.studying.app.ui.components.LoadingBox
import ir.studying.app.ui.components.SegmentedTabs
import ir.studying.app.ui.profile.ReportImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** کارت گزارش امروز با ذخیره در گالری و انتشار در شبکهٔ اجتماعی. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyReportSheet(
    report: DailyReport?,
    loading: Boolean,
    palette: CoursePalette,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
) {
    val username = Store.username ?: ""
    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        val r = report
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 30.dp)) {
            Text("📋 گزارش امروز", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            if (r == null) {
                if (loading) {
                    LoadingBox(height = 120.dp)
                } else {
                    Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("گزارش امروز خوانده نشد", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onRetry, shape = MaterialTheme.shapes.large) { Text("تلاش دوباره") }
                    }
                }
                return@Column
            }
            val cs = MaterialTheme.colorScheme
            Surface(shape = MaterialTheme.shapes.large, color = Color.Transparent) {
                Column(
                    Modifier
                        .background(Brush.linearGradient(listOf(HeroTop, HeroBottom, cs.primary.copy(alpha = 0.85f))))
                        .padding(18.dp),
                ) {
                    Text(username, style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Text(Fmt.jalaliWithDay(r.dateIso), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.8f))
                    Spacer(Modifier.height(12.dp))
                    ReportLine("⏰ بیداری", if (r.wakeupTime != null) Fmt.hm(r.wakeupTime) else "ثبت نشده")
                    ReportLine("📚 مجموع مطالعه", Fmt.minutes(r.totalMinutes))
                    ReportLine("🔥 استریک", "${r.streak.fa()} روز")
                    if (r.firstStudy != null) ReportLine("🌅 اولین پارت", Fmt.hm(r.firstStudy))
                    if (r.lastStudy != null) ReportLine("🌙 آخرین پارت", Fmt.hm(r.lastStudy))
                }
            }
            Spacer(Modifier.height(14.dp))
            DailyQuestionStats(r.questionTotals)
            if (r.sessions.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text("پارت‌های امروز", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(6.dp))
                r.sessions.forEach { s -> PartRow(s, palette[s.course]) }
            }
            Spacer(Modifier.height(16.dp))

            val ctx = LocalContext.current
            val dark = cs.background.luminance() < 0.5f
            val scope = rememberCoroutineScope()
            var saving by remember { mutableStateOf(false) }
            val doSave: () -> Unit = {
                saving = true
                val prim = cs.primary.toArgb()
                val sec = cs.secondary.toArgb()
                scope.launch {
                    val err = withContext(Dispatchers.IO) {
                        ReportImage.save(ctx, username, r, primary = prim, secondary = sec, dark = dark)
                    }
                    saving = false
                    AppSnack.show(err ?: "✅ تصویر گزارش در گالری ذخیره شد (Pictures/Studying)", long = true)
                }
            }
            val writePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) doSave() else AppSnack.show("برای ذخیره تصویر، مجوز حافظه لازم است")
            }
            Button(
                onClick = {
                    if (Build.VERSION.SDK_INT >= 29) doSave()
                    else writePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                },
                enabled = !saving,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
            ) {
                Icon(Icons.Rounded.Download, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (saving) "در حال ذخیره…" else "ذخیره عکس گزارش 📸")
            }
            Spacer(Modifier.height(8.dp))
            // همان کارت، مستقیم در شبکهٔ اجتماعی.
            var sharing by remember { mutableStateOf(false) }
            var shareText by remember { mutableStateOf("") }
            OutlinedTextField(
                value = shareText,
                onValueChange = { shareText = it },
                label = { Text("متن پست (اختیاری)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    sharing = true
                    val prim = cs.primary.toArgb()
                    val sec = cs.secondary.toArgb()
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            runCatching {
                                val png = ReportImage.bytes(ctx, username, r, primary = prim, secondary = sec, dark = dark)
                                    ?: throw Exception("ساخت تصویر ناموفق بود")
                                val fields = HashMap<String, String>()
                                fields["text"] = shareText.ifBlank { "گزارش مطالعهٔ امروزم 📚" }
                                fields["media_type"] = "image"
                                Api.upload("post_create", fields, listOf(Api.FilePart("file", "report.png", png, "image/png")))
                            }
                        }
                        sharing = false
                        res.onSuccess {
                            shareText = ""
                            RefreshBus.emit("feed")
                            AppSnack.show("✅ گزارش در شبکهٔ اجتماعی منتشر شد")
                            onDismiss()
                        }.onFailure {
                            AppSnack.show(humanizeError(it), long = true)
                        }
                    }
                },
                enabled = !sharing,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
            ) {
                Text(if (sharing) "در حال انتشار…" else "انتشار در شبکهٔ اجتماعی 🚀")
            }
        }
    }
}

/** تایم‌لاین امروز و دیروز؛ هر پارت را می‌شود حذف کرد یا درسش را عوض کرد. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimelineSheet(
    today: List<HourlyPart>,
    yesterday: List<HourlyPart>,
    palette: CoursePalette,
    courses: List<Course>,
    nowMinute: Int,
    onLoadCourses: () -> Unit,
    onDelete: (HourlyPart) -> Unit,
    onSetCourse: (HourlyPart, Int?) -> Unit,
    onDismiss: () -> Unit,
) {
    var tab by remember { mutableIntStateOf(0) }
    var partMenu by remember { mutableStateOf<HourlyPart?>(null) }
    var partPick by remember { mutableStateOf<HourlyPart?>(null) }
    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 30.dp)) {
            Text("🕐 تایم‌لاین مطالعه", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            SegmentedTabs(listOf("امروز", "دیروز"), tab) { tab = it }
            Spacer(Modifier.height(14.dp))
            val parts = if (tab == 0) today else yesterday
            if (parts.isEmpty()) {
                EmptyState("😴", "پارتی ثبت نشده")
            } else {
                val total = parts.sumOf { it.minutes }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(Fmt.minutes(total), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "در ${parts.size.fa()} پارت",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 3.dp),
                    )
                }
                Spacer(Modifier.height(12.dp))
                DayTimeline(parts, palette, nowMinute = if (tab == 0) nowMinute else null)
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                Spacer(Modifier.height(6.dp))
                parts.forEach { p -> PartRow(p, palette[p.course], onMenu = { partMenu = p }) }
            }
        }
    }

    partMenu?.let { target ->
        AlertDialog(
            onDismissRequest = { partMenu = null },
            title = { Text(target.icon + " " + target.course) },
            text = {
                Text(
                    Fmt.minutes(target.minutes) + " · " + Fmt.hm(target.start) + " → " + Fmt.hm(target.end),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    partMenu = null
                    onLoadCourses()
                    partPick = target
                }) { Text("تغییر درس") }
            },
            dismissButton = {
                TextButton(onClick = {
                    partMenu = null
                    onDelete(target)
                }) { Text("حذف پارت", color = MaterialTheme.colorScheme.error) }
            },
        )
    }

    partPick?.let { target ->
        AlertDialog(
            onDismissRequest = { partPick = null },
            title = { Text("درس این پارت") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (courses.isEmpty()) {
                        Text("در حال خواندن درس‌ها…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    courses.forEach { c ->
                        TextButton(onClick = {
                            partPick = null
                            onSetCourse(target, c.id)
                        }) { Text(c.icon + "  " + c.name) }
                    }
                    TextButton(onClick = {
                        partPick = null
                        onSetCourse(target, null)
                    }) { Text("➖  بدون درس") }
                }
            },
            confirmButton = { TextButton(onClick = { partPick = null }) { Text("انصراف") } },
        )
    }
}

@Composable
private fun ReportLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.88f), modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.titleSmall, color = Color.White)
    }
}

/** یک پارت: نوار رنگ درس، نام و بازهٔ زمانی، مدت. */
@Composable
fun PartRow(p: HourlyPart, color: Color, onMenu: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(width = 4.dp, height = 34.dp).background(color, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.size(34.dp).background(color.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text(p.icon, style = MaterialTheme.typography.titleSmall) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(p.course, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${Fmt.hm(p.start)} → ${Fmt.hm(p.end)}" + (p.topic.takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""),
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(ReportStats.clock(p.minutes), style = MaterialTheme.typography.titleSmall, color = color, fontWeight = FontWeight.Bold)
        // پارت‌های قدیمی شناسه ندارند؛ منوی حذف و تغییر برایشان نیست.
        if (onMenu != null && p.id > 0) {
            TextButton(onClick = onMenu, contentPadding = PaddingValues(horizontal = 6.dp)) {
                Text("⋯", style = MaterialTheme.typography.titleMedium)
            }
        } else if (onMenu != null) {
            Spacer(Modifier.width(8.dp))
        }
    }
}
