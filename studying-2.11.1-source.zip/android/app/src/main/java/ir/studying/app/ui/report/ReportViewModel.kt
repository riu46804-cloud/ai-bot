package ir.studying.app.ui.report

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.core.CourseCache
import ir.studying.app.core.IranTime
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.ReportStats
import ir.studying.app.core.humanizeError
import ir.studying.app.core.int
import ir.studying.app.core.objects
import ir.studying.app.core.str
import ir.studying.app.core.strOrNull
import ir.studying.app.data.Course
import ir.studying.app.data.CourseMinutes
import ir.studying.app.data.DailyReport
import ir.studying.app.data.HourlyPart
import ir.studying.app.data.ProfileData
import ir.studying.app.data.StudyHistory
import ir.studying.app.ui.components.AppSnack
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

/** بازه‌های گزارش. همه به امروز ختم می‌شوند. */
enum class ReportPeriod(val days: Int, val label: String, val noun: String) {
    WEEK(7, "هفته", "۷ روز اخیر"),
    MONTH(30, "ماه", "۳۰ روز اخیر"),
    QUARTER(90, "۳ ماه", "۹۰ روز اخیر"),
    YEAR(365, "سال", "۱۲ ماه اخیر");

    /** دورهٔ قبلی هم باید در ۴۰۰ روزی که تقویم می‌دهد جا شود. */
    val comparable: Boolean get() = days * 2 <= CALENDAR_DAYS

    /** تفکیک درس‌به‌درسِ هر روز فقط برای میله‌های هفته و ماه لازم است. */
    val stacked: Boolean get() = this == WEEK || this == MONTH
}

const val CALENDAR_DAYS = 400

data class CourseShare(
    val name: String,
    val icon: String,
    val colorKey: String,
    val minutes: Int,
    val sessions: Int,
)

data class PeriodBreakdown(
    val courses: List<CourseShare>,
    /** دقیقه‌های هر ساعت شبانه‌روز (بر اساس ساعت شروع پارت). */
    val hours: List<Int>,
    val sessions: Int,
    val bestSession: Int,
)

data class DayStack(val total: Int, val courses: List<CourseShare>)

class ReportViewModel : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val refreshing: Boolean = false,
        val error: String? = null,
        val todayIso: String = IranTime.todayIso(),
        val days: Map<String, ReportStats.Day> = emptyMap(),
        val period: ReportPeriod = ReportPeriod.WEEK,
        val breakdowns: Map<ReportPeriod, PeriodBreakdown> = emptyMap(),
        val stacks: Map<ReportPeriod, Map<String, DayStack>> = emptyMap(),
        val loadingPeriods: Set<ReportPeriod> = emptySet(),
        val todayParts: List<HourlyPart> = emptyList(),
        val yesterdayParts: List<HourlyPart> = emptyList(),
        val lifetimeMinutes: Int = 0,
        val lifetimeDays: Int = 0,
        val lifetimeCourses: List<CourseMinutes> = emptyList(),
        val streak: Int = 0,
        val report: DailyReport? = null,
        val reportLoading: Boolean = false,
        val courses: List<Course> = emptyList(),
    ) {
        val minutesByDate: Map<String, Int> by lazy { days.mapValues { it.value.minutes } }
        val todayMinutes: Int get() = days[todayIso]?.minutes ?: todayParts.sumOf { it.minutes }
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> get() = _state

    private var loadJob: Job? = null
    private var again = false
    private val periodJobs = HashMap<ReportPeriod, Job>()

    init { refresh(silent = true) }

    /**
     * همه‌چیز با هم و موازی خوانده می‌شود. فقط تقویم حیاتی است؛ بقیه اگر
     * نرسیدند صفحه با دادهٔ قبلی‌شان سر پا می‌ماند.
     */
    fun refresh(silent: Boolean = false) {
        if (loadJob?.isActive == true) { again = true; return }
        loadJob = viewModelScope.launch {
            do {
                again = false
                loadAll(silent)
            } while (again)
        }
    }

    private suspend fun loadAll(silent: Boolean) {
        if (!silent) _state.update { it.copy(refreshing = it.days.isNotEmpty(), error = null) }
        val period = _state.value.period
        try {
            coroutineScope {
                val calendar = async { loadCalendar() }
                val hourly = async { soft { loadHourly() } }
                val profile = async { soft { ProfileData.from(Api.obj(Api.get("profile"))) } }
                val streak = async { soft { Api.obj(Api.get("streak")).int("streak") } }
                val breakdown = async { soft { loadBreakdown(period) } }
                val stacks = async { if (period.stacked) soft { loadStacks(period) } else null }

                val days = calendar.await()
                val h = hourly.await()
                val p = profile.await()
                val st = streak.await()
                val b = breakdown.await()
                val sk = stacks.await()
                _state.update { s ->
                    s.copy(
                        loading = false,
                        refreshing = false,
                        error = null,
                        todayIso = IranTime.todayIso(),
                        days = days,
                        todayParts = h?.first ?: s.todayParts,
                        yesterdayParts = h?.second ?: s.yesterdayParts,
                        lifetimeMinutes = p?.totalMinutes ?: s.lifetimeMinutes,
                        lifetimeDays = p?.studyDays ?: s.lifetimeDays,
                        lifetimeCourses = p?.courses ?: s.lifetimeCourses,
                        streak = st ?: s.streak,
                        // بقیهٔ بازه‌ها کهنه شده‌اند؛ با انتخاب دوباره تازه خوانده می‌شوند.
                        breakdowns = if (b != null) mapOf(period to b) else s.breakdowns.filterKeys { it == period },
                        stacks = if (sk != null) mapOf(period to sk) else s.stacks.filterKeys { it == period },
                    )
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val hadData = _state.value.days.isNotEmpty()
            _state.update {
                it.copy(loading = false, refreshing = false, error = if (hadData) null else humanizeError(e))
            }
            if (hadData && !silent) AppSnack.show(humanizeError(e))
        }
        // اگر کاربر وسط بارگیری بازهٔ دیگری را انتخاب کرده بود، آن هم کامل شود.
        ensurePeriod(_state.value.period)
    }

    fun selectPeriod(p: ReportPeriod) {
        if (_state.value.period == p) return
        _state.update { it.copy(period = p) }
        ensurePeriod(p)
    }

    private fun ensurePeriod(p: ReportPeriod) {
        val s = _state.value
        val needBreakdown = s.breakdowns[p] == null
        val needStacks = p.stacked && s.stacks[p] == null
        if (!needBreakdown && !needStacks) return
        if (periodJobs[p]?.isActive == true) return
        periodJobs[p] = viewModelScope.launch {
            _state.update { it.copy(loadingPeriods = it.loadingPeriods + p) }
            val (b, st) = coroutineScope {
                val b = async { if (needBreakdown) soft { loadBreakdown(p) } else null }
                val st = async { if (needStacks) soft { loadStacks(p) } else null }
                b.await() to st.await()
            }
            _state.update { cur ->
                cur.copy(
                    loadingPeriods = cur.loadingPeriods - p,
                    breakdowns = if (b != null) cur.breakdowns + (p to b) else cur.breakdowns,
                    stacks = if (st != null) cur.stacks + (p to st) else cur.stacks,
                )
            }
        }
    }

    fun loadReport() {
        if (_state.value.reportLoading) return
        viewModelScope.launch {
            _state.update { it.copy(reportLoading = true) }
            val r = soft { DailyReport.from(Api.obj(Api.get("daily_report"))) }
            _state.update { it.copy(report = r ?: it.report, reportLoading = false) }
            if (r == null && _state.value.report == null) AppSnack.show("گزارش امروز بارگیری نشد؛ دوباره امتحان کن")
        }
    }

    /** درس‌ها فقط برای عوض کردن درس یک پارت لازمند. */
    fun loadCourses() {
        if (_state.value.courses.isNotEmpty()) return
        viewModelScope.launch {
            val list = soft { CourseCache.peek().ifEmpty { CourseCache.refresh() } }.orEmpty()
            if (list.isNotEmpty()) _state.update { it.copy(courses = list) }
        }
    }

    fun deletePart(part: HourlyPart, onResult: (String?) -> Unit) {
        if (part.id <= 0) { onResult("این پارت شناسه ندارد"); return }
        viewModelScope.launch {
            try {
                Api.get("study_part_delete", "id" to part.id.toString())
                afterPartChange()
                onResult(null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) { onResult(humanizeError(e)) }
        }
    }

    fun setPartCourse(part: HourlyPart, courseId: Int?, onResult: (String?) -> Unit) {
        if (part.id <= 0) { onResult("این پارت شناسه ندارد"); return }
        viewModelScope.launch {
            try {
                Api.get("study_part_course", "id" to part.id.toString(), "course_id" to (courseId ?: 0).toString())
                afterPartChange()
                onResult(null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) { onResult(humanizeError(e)) }
        }
    }

    private fun afterPartChange() {
        StudyHistory.invalidate()
        _state.update { it.copy(report = null) }
        refresh(silent = true)
        // خانه، پروفایل و تقویم‌ها هم باید همین حالا عدد تازه را ببینند.
        RefreshBus.emit("study")
    }

    // ------------------------------------------------------------------ شبکه

    private suspend fun loadCalendar(): Map<String, ReportStats.Day> {
        val o = Api.obj(Api.get("study_calendar", "days" to CALENDAR_DAYS.toString()))
        val out = HashMap<String, ReportStats.Day>()
        o.optJSONArray("days")?.objects()?.forEach { d ->
            val date = d.strOrNull("date")?.take(10) ?: return@forEach
            val prev = out[date]
            val m = d.int("minutes").coerceAtLeast(0)
            val n = d.int("sessions").coerceAtLeast(0)
            out[date] = if (prev == null) ReportStats.Day(m, n) else ReportStats.Day(prev.minutes + m, prev.sessions + n)
        }
        return out
    }

    private suspend fun loadHourly(): Pair<List<HourlyPart>, List<HourlyPart>> {
        val o = Api.obj(Api.get("analytics_hourly"))
        val today = o.optJSONArray("today_parts")?.let { HourlyPart.list(it) } ?: emptyList()
        val yesterday = o.optJSONArray("yesterday_parts")?.let { HourlyPart.list(it) } ?: emptyList()
        return today to yesterday
    }

    /** پنجرهٔ سرور «امروز منهای N» است، یعنی N+۱ روز؛ پس days-1 می‌فرستیم. */
    private suspend fun loadBreakdown(p: ReportPeriod): PeriodBreakdown {
        val o = Api.obj(Api.get("study_by_course", "days" to (p.days - 1).coerceAtLeast(1).toString()))
        val courses = o.optJSONArray("courses")?.objects()?.map { share(it) }.orEmpty()
            .filter { it.minutes > 0 }
            .sortedByDescending { it.minutes }
        val hoursArr = o.optJSONArray("hours")
        val hours = List(24) { i -> hoursArr?.optInt(i, 0)?.coerceAtLeast(0) ?: 0 }
        return PeriodBreakdown(courses, hours, o.int("sessions"), o.int("best_session"))
    }

    private suspend fun loadStacks(p: ReportPeriod): Map<String, DayStack> {
        val o = Api.obj(Api.get("study_days", "days" to (p.days - 1).coerceAtLeast(1).toString()))
        val out = HashMap<String, DayStack>()
        o.optJSONArray("days")?.objects()?.forEach { d ->
            val date = d.strOrNull("date")?.take(10) ?: return@forEach
            val courses = d.optJSONArray("courses")?.objects()?.map { share(it) }.orEmpty()
                .filter { it.minutes > 0 }
                .sortedByDescending { it.minutes }
            out[date] = DayStack(d.int("total_minutes").coerceAtLeast(courses.sumOf { it.minutes }), courses)
        }
        return out
    }

    private fun share(o: JSONObject) = CourseShare(
        name = o.strOrNull("name") ?: "بدون درس",
        icon = o.strOrNull("icon") ?: "📖",
        colorKey = o.str("color"),
        minutes = o.int("minutes").coerceAtLeast(0),
        sessions = o.int("sessions").coerceAtLeast(0),
    )
}

/** مثل runCatching، ولی لغو شدن کوروتین را قورت نمی‌دهد. */
private suspend fun <T> soft(block: suspend () -> T): T? = try {
    block()
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    null
}

