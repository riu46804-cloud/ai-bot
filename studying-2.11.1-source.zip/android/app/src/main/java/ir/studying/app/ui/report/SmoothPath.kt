package ir.studying.app.ui.report

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path

fun smoothPath(points: List<Offset>): Path {
    val p = Path()
    if (points.isEmpty()) return p
    p.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) {
        val a = points[i - 1]
        val b = points[i]
        val mx = (a.x + b.x) / 2f
        p.cubicTo(mx, a.y, mx, b.y, b.x, b.y)
    }
    return p
}
