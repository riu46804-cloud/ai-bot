@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Game
import ir.studying.app.core.GiftCodeInput
import ir.studying.app.core.fa
import kotlinx.coroutines.launch

@Composable
internal fun GiftCodeSheet(onDismiss: () -> Unit) {
    var code by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var receipt by remember { mutableStateOf<Game.GiftResult?>(null) }
    val scope = rememberCoroutineScope()
    val game by Game.state.collectAsState()
    val keyboard = LocalSoftwareKeyboardController.current
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { Game.refresh() }

    val submit: () -> Unit = {
        if (!busy) {
            if (GiftCodeInput.normalize(code) == null) {
                error = GiftCodeInput.ERROR
            } else {
                busy = true
                error = null
                keyboard?.hide()
                scope.launch {
                    try {
                        val response = Game.redeemGift(code)
                        if (response.error != null) error = response.error else receipt = response
                    } finally { busy = false }
                }
            }
        }
    }
    ModalBottomSheet(
        onDismissRequest = { if (!busy) onDismiss() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier.fillMaxWidth().imePadding().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Surface(shape = RoundedCornerShape(24.dp), color = cs.primaryContainer.copy(alpha = 0.5f)) {
                Column(
                    Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(
                        cs.primary.copy(alpha = 0.13f), cs.tertiary.copy(alpha = 0.12f))))
                        .padding(horizontal = 18.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(Modifier.size(66.dp).background(cs.primary.copy(alpha = 0.13f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.CardGiftcard, null, tint = cs.primary, modifier = Modifier.size(34.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("یک هدیه برای تو", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(5.dp))
                    Text("کد را وارد کن؛ سکه‌ها به حساب خودت اضافه می‌شوند.",
                        style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                        color = cs.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    Surface(shape = RoundedCornerShape(30.dp), color = cs.surface.copy(alpha = 0.8f)) {
                        Text(if (game.loaded) "موجودی: ${game.coins.fa()} سکه" else "در حال دریافت موجودی…",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            val redeemed = receipt
            if (redeemed == null) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { if (it.length <= 96) { code = it; error = null } },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    singleLine = true,
                    label = { Text("کد هدیه") },
                    placeholder = { Text("کد را با حروف انگلیسی وارد کن") },
                    textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None,
                        keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    isError = error != null,
                    supportingText = { Text(error ?: "بزرگ یا کوچک بودن حروف فرقی ندارد؛ هر کد برای هر حساب یک‌بار است.") },
                    shape = RoundedCornerShape(18.dp),
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = submit, enabled = !busy && code.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                        Spacer(Modifier.width(9.dp))
                    }
                    Text(if (busy) "در حال بررسی کد…" else "دریافت هدیه", fontWeight = FontWeight.Bold)
                }
                TextButton(enabled = !busy, onClick = onDismiss) { Text("بستن") }
            } else {
                val duplicate = redeemed.alreadyRedeemed
                Surface(shape = RoundedCornerShape(22.dp), color = if (duplicate) cs.surfaceVariant else cs.primaryContainer) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(if (duplicate) Icons.Rounded.History else Icons.Rounded.CheckCircle, null,
                            tint = cs.primary, modifier = Modifier.size(38.dp))
                        Spacer(Modifier.height(10.dp))
                        Text(if (duplicate) "این هدیه را قبلاً گرفته‌ای" else "هدیه به حسابت اضافه شد!",
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        if (!duplicate) {
                            Spacer(Modifier.height(8.dp))
                            Text("+${redeemed.granted.fa()} سکه", style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Black, color = cs.primary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(if (duplicate) "این بار سکه‌ای دوباره اضافه نشد؛ پاداش قبلی در حساب تو ثبت شده است."
                            else "موجودی جدید: ${game.coins.fa()} سکه",
                            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("تمام") }
                TextButton(onClick = { receipt = null; code = ""; error = null }) { Text("کد دیگری دارم") }
            }
        }
    }
}
