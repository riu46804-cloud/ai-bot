package ir.studying.app.ui.settings

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Goals
import ir.studying.app.ui.components.GlassRadioGroup

/**
 * Daily and weekly study targets.
 *
 * The first version used a row of preset chips. That design cannot survive the
 * range people actually want: reaching fourteen hours a day in fifteen-minute
 * presets needs fifty-six chips, and even a scrolling row of them turns a
 * one-second decision into a hunt. So the control changed shape rather than
 * growing: one dial, one slider, and a day/week switch built from the same
 * sliding component as the light/dark selector above it, so the screen looks
 * like one screen.
 *
 * The dial is not decoration. It shows the chosen target against the fourteen
 * hour ceiling, which is the only honest way to make "6h" feel different from
 * "12h" before the user has lived either of them.
 */
@Composable
fun GoalsSection() {
    val daily by Goals.daily.collectAsState()
    val weekly by Goals.weekly.collectAsState()

    // 0 = daily, 1 = weekly.
    var tab by remember { mutableIntStateOf(0) }

    val isDaily = tab == 0
    /*
     * هدف دیگر پیش‌فرض ندارد (۰ = تنظیم‌نشده). برای اینکه چرخ و دکمه‌ها جایی
     * برای شروع داشته باشند، عدد پیشنهادی نشان داده می‌شود ولی تا وقتی کاربر
     * دست نزند، جایی ذخیره یا استفاده نمی‌شود.
     */
    val stored = if (isDaily) daily else weekly
    val value = if (stored > 0) stored else if (isDaily) Goals.SUGGESTED_DAILY else Goals.SUGGESTED_WEEKLY
    val min = if (isDaily) Goals.MIN_DAILY else Goals.MIN_WEEKLY
    val max = if (isDaily) Goals.MAX_DAILY else Goals.MAX_WEEKLY
    val step = if (isDaily) Goals.STEP_DAILY else Goals.STEP_WEEKLY

    SettingsGroup("هدف مطالعه") {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {

            GlassRadioGroup(
                options = listOf("روزانه", "هفتگی"),
                selected = tab,
                modifier = Modifier.fillMaxWidth(),
                height = 42.dp,
            ) { tab = it }

            GoalDial(
                minutes = value,
                max = max,
                caption = if (isDaily) "در روز" else "در هفته",
            )

            GoalStepper(
                minutes = value,
                min = min,
                max = max,
                step = step,
                onChange = { if (isDaily) Goals.setDaily(it) else Goals.setWeekly(it) },
            )

            if (stored <= 0) {
                Text(
                    "هنوز هدفی تعیین نکرده‌ای؛ با همین دکمه‌ها عدد خودت را ثبت کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }

            Text(
                if (isDaily) {
                    "از " + Goals.label(Goals.MIN_DAILY) + " تا " + Goals.label(Goals.MAX_DAILY) + " — هدف فقط روی همین گوشی ذخیره می‌شود و جایی منتشر نمی‌شود."
                } else {
                    "از " + Goals.label(Goals.MIN_WEEKLY) + " تا " + Goals.label(Goals.MAX_WEEKLY) + " — هدف فقط روی همین گوشی ذخیره می‌شود و جایی منتشر نمی‌شود."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 10.dp),
            )
        }
    }
}

/**
 * Ring plus the number in the middle. The sweep is a spring rather than a
 * linear tween so dragging the slider feels attached to the finger, and the
 * number swaps with a short vertical slide so a change never goes unnoticed.
 */
@Composable
private fun GoalDial(minutes: Int, max: Int, caption: String) {
    val cs = MaterialTheme.colorScheme
    val sweep by animateFloatAsState(
        targetValue = (minutes.toFloat() / max.toFloat()).coerceIn(0f, 1f),
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 260f),
        label = "goalSweep",
    )

    Box(
        Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(168.dp)) {
            val stroke = 14.dp.toPx()
            val inset = stroke / 2f
            val arcSize = androidx.compose.ui.geometry.Size(
                size.width - stroke,
                size.height - stroke,
            )
            val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)

            // Track: a 270 degree arc, opening at the bottom so the gap reads as
            // intentional rather than as a rendering glitch.
            drawArc(
                color = cs.onSurface.copy(alpha = 0.10f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )

            if (sweep > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(cs.primary, cs.tertiary, cs.primary),
                    ),
                    startAngle = 135f,
                    sweepAngle = 270f * sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AnimatedContent(
                targetState = Goals.label(minutes),
                transitionSpec = {
                    (slideInVertically { it / 2 } + fadeIn(tween(160))) togetherWith
                        (slideOutVertically { -it / 2 } + fadeOut(tween(160)))
                },
                label = "goalValue",
            ) { text ->
                Text(
                    text,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Black,
                    color = cs.onSurface,
                )
            }
            Text(
                caption,
                style = MaterialTheme.typography.labelMedium,
                color = cs.onSurfaceVariant,
            )
        }
    }
}

/**
 * Slider between the two round buttons.
 *
 * The slider is continuous and snapped in code instead of using `steps`:
 * Material draws a tick for every step, and 193 ticks on the weekly range look
 * like a barcode. Snapping keeps the round numbers without the visual noise.
 */
@Composable
private fun GoalStepper(
    minutes: Int,
    min: Int,
    max: Int,
    step: Int,
    onChange: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current

    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        RoundStep(
            icon = Icons.Rounded.Remove,
            enabled = minutes > min,
        ) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onChange((minutes - step).coerceAtLeast(min))
        }

        Slider(
            value = minutes.toFloat(),
            onValueChange = { raw ->
                val snapped = Goals.snap(raw.toInt(), min, max, step)
                if (snapped != minutes) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onChange(snapped)
                }
            },
            valueRange = min.toFloat()..max.toFloat(),
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                activeTrackColor = cs.primary,
                inactiveTrackColor = cs.onSurface.copy(alpha = 0.12f),
            ),
        )

        RoundStep(
            icon = Icons.Rounded.Add,
            enabled = minutes < max,
        ) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onChange((minutes + step).coerceAtMost(max))
        }
    }
}

@Composable
private fun RoundStep(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val alpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.35f,
        animationSpec = tween(200),
        label = "stepAlpha",
    )
    Box(
        Modifier
            .size(38.dp)
            .background(cs.onSurface.copy(alpha = 0.07f * alpha), CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = cs.onSurface.copy(alpha = alpha),
            modifier = Modifier.size(20.dp),
        )
    }
}
