package ir.studying.app.ui.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.QuestionAnswer
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ir.studying.app.R
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.notify.DaySummary
import ir.studying.app.notify.Reminder
import java.util.Locale

private fun timeStr(h: Int, m: Int): String = String.format(Locale.US, "%02d:%02d", h, m).fa()

/** Every push type the server can send, in the order they matter most. */
private val SOCIAL = listOf(
    Triple("dm", "پیام خصوصی", Icons.Rounded.Chat),
    Triple("follow", "دنبال‌شدن", Icons.Rounded.PersonAdd),
    Triple("post_like", "لایک پست", Icons.Rounded.Favorite),
    Triple("post_reply", "پاسخ پست", Icons.Rounded.QuestionAnswer),
    Triple("repost", "بازنشر", Icons.Rounded.Repeat),
    Triple("mention", "منشن گروه", Icons.Rounded.AlternateEmail),
    Triple("group_reply", "پاسخ گروه", Icons.Rounded.QuestionAnswer),
    Triple("reaction", "ری‌اکشن پیام", Icons.Rounded.EmojiEmotions),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs by Store.prefs.collectAsState()
    var showTime by remember { mutableStateOf(false) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Store.setReminder(granted, prefs.reminderHour, prefs.reminderMinute)
        if (granted) Reminder.apply(ctx)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        SettingsRow(
            icon = Icons.Rounded.ArrowForward,
            title = stringResource(R.string.settings_002),
            onClick = onBack,
        )
        Spacer(Modifier.height(10.dp))

        SettingsGroup(stringResource(R.string.settings_010)) {
            SettingsSwitchRow(
                icon = Icons.Rounded.NotificationsActive,
                title = stringResource(R.string.settings_011),
                subtitle = if (prefs.reminderEnabled)
                    stringResource(R.string.settings_012) + " " + timeStr(prefs.reminderHour, prefs.reminderMinute)
                else stringResource(R.string.settings_013),
                checked = prefs.reminderEnabled,
            ) { on ->
                if (on && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                else { Store.setReminder(on, prefs.reminderHour, prefs.reminderMinute); Reminder.apply(ctx) }
            }
            if (prefs.reminderEnabled) {
                SettingsDivider()
                SettingsRow(
                    icon = Icons.Rounded.Schedule,
                    title = stringResource(R.string.settings_014),
                    subtitle = timeStr(prefs.reminderHour, prefs.reminderMinute),
                    onClick = { showTime = true },
                )
            }
        }

        SettingsGroup(stringResource(R.string.settings_020)) {
            SOCIAL.forEachIndexed { i, (key, label, icon) ->
                if (i > 0) SettingsDivider()
                SettingsSwitchRow(
                    icon = icon,
                    title = label,
                    checked = prefs.pushTypes.contains(key),
                ) { Store.togglePushType(key) }
            }
        }

        SettingsGroup(stringResource(R.string.settings_030)) {
            SettingsSwitchRow(
                icon = Icons.Rounded.NotificationsActive,
                title = stringResource(R.string.settings_031),
                subtitle = stringResource(R.string.settings_032) + " " + timeStr(DaySummary.HOUR, DaySummary.MINUTE),
                checked = prefs.autoStudyPost,
            ) { Store.setAutoStudyPost(it) }
        }
        Spacer(Modifier.height(40.dp))
    }

    if (showTime) {
        /*
         * همان چرخِ صفحهٔ زنگ، نه `TimePicker` متریال: آن یکی در چیدمان
         * راست‌به‌چپ آینه می‌شود و دقیقه را سمت چپ می‌اندازد.
         */
        var h by remember { mutableStateOf(prefs.reminderHour) }
        var m by remember { mutableStateOf(prefs.reminderMinute) }
        AlertDialog(
            onDismissRequest = { showTime = false },
            title = { Text(stringResource(R.string.settings_014)) },
            text = {
                ir.studying.app.ui.components.TimeDial(
                    hour = h,
                    minute = m,
                    onHour = { h = it },
                    onMinute = { m = it },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Store.setReminder(true, h, m)
                    Reminder.apply(ctx)
                    showTime = false
                }) { Text(stringResource(R.string.groups_010)) }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text(stringResource(R.string.groups_011)) } },
        )
    }
}
