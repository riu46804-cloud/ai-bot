@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ir.studying.app.R
import ir.studying.app.core.Api
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.ui.theme.AppPalettes
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * The settings hub, reachable from Profile. Everything that used to be piled
 * into one card on the profile page now lives here, grouped by subject.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenTelegram: () -> Unit = {},
    onOpenFocus: () -> Unit = {},
    onOpenDailySms: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val prefs by Store.prefs.collectAsState()
    val subscription by ir.studying.app.core.Subscriptions.state.collectAsState()
    val scope = rememberCoroutineScope()
    var showAutoDl by remember { mutableStateOf(false) }
    var showGiftCode by remember { mutableStateOf(false) }
    var hideSeen by remember { mutableStateOf(false) }
    var showMyket by remember { mutableStateOf(!Store.myketPopupSeen) }
    var myketBusy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching { hideSeen = Api.obj(Api.get("privacy")).optInt("hide_last_seen", 0) == 1 }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SettingsRow(
            icon = Icons.Rounded.ArrowForward,
            title = stringResource(R.string.settings_001),
            onClick = onBack,
        )
        Spacer(Modifier.height(10.dp))

        SettingsGroup("حمایت از اپ") {
            SettingsRow(
                icon = Icons.Rounded.Star,
                title = "نظرت دربارهٔ Studying",
                subtitle = "یک نقد کوتاه در مایکت بنویس و ۳۰۰ سکه هدیه بگیر",
                onClick = { showMyket = true },
            )
        }
        Spacer(Modifier.height(10.dp))

        SettingsGroup("اشتراک Studying") {
            SettingsRow(
                icon = Icons.Rounded.WorkspacePremium,
                title = "اشتراک ویژه",
                subtitle = if (subscription.loaded && ir.studying.app.core.Subscriptions.canAccess(ir.studying.app.core.SubscriptionFeatures.ROOM_THEMES))
                    "اشتراک فعال؛ مشاهده یا تمدید" else "یک‌ماهه، سه‌ماهه و یک‌ساله برای تم‌های ویژه",
                onClick = { ir.studying.app.core.Subscriptions.openPaywall() },
            )
            SettingsDivider()
            SettingsRow(
                icon = Icons.Rounded.WbSunny,
                title = "پیامک انگیزشی صبحگاهی",
                subtitle = "از ساعت ۷ صبح: جملهٔ انگیزشی و شمارش معکوس کنکور",
                tint = Color(0xFFF59E0B),
                onClick = onOpenDailySms,
                trailing = {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFF59E0B).copy(alpha = 0.16f),
                    ) {
                        Text(
                            "جدید",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                            color = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) Color(0xFFFCD34D) else Color(0xFFB45309),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                        )
                    }
                },
            )
        }
        Spacer(Modifier.height(10.dp))

        SettingsGroup("جوایز و هدیه‌ها") {
            SettingsRow(
                icon = Icons.Rounded.CardGiftcard,
                title = "کد هدیه",
                subtitle = "کدت را وارد کن و سکهٔ هدیه بگیر",
                onClick = { showGiftCode = true },
            )
        }
        Spacer(Modifier.height(10.dp))

        SettingsGroup(stringResource(R.string.settings_040)) {
            SettingsRow(
                icon = Icons.Rounded.Notifications,
                title = stringResource(R.string.settings_041),
                subtitle = stringResource(R.string.settings_042),
                onClick = onOpenNotifications,
            )
            SettingsDivider()
            SettingsRow(
                icon = Icons.Rounded.Lock,
                title = "قفل تمرکز",
                subtitle = "قفل برنامه‌های مزاحم، ساکت کردن نوتیفیکیشن و چالش گروهی",
                onClick = onOpenFocus,
            )
            SettingsDivider()
            SettingsRow(
                icon = Icons.Rounded.Send,
                title = "ربات تلگرام",
                subtitle = "گزارش مطالعه، یادآوری و اعلان‌ها در تلگرام",
                onClick = onOpenTelegram,
            )
        }

        GoalsSection()

        WidgetSection()

        SettingsGroup(stringResource(R.string.settings_050)) {
            SettingsSwitchRow(
                icon = Icons.Rounded.MenuBook,
                title = stringResource(R.string.settings_051),
                subtitle = stringResource(R.string.settings_052),
                checked = prefs.autoStudyPost,
            ) { Store.setAutoStudyPost(it) }
        }

        SettingsGroup(stringResource(R.string.settings_060)) {
            SettingsSwitchRow(
                icon = Icons.Rounded.VisibilityOff,
                title = stringResource(R.string.settings_061),
                subtitle = stringResource(R.string.settings_062),
                checked = hideSeen,
            ) { v ->
                hideSeen = v
                scope.launch {
                    runCatching { Api.post("privacy", JSONObject().put("hide_last_seen", if (v) 1 else 0)) }
                }
            }
        }

        SettingsGroup(stringResource(R.string.settings_070)) {
            SettingsRow(
                icon = Icons.Rounded.Palette,
                title = stringResource(R.string.settings_071),
            ) {
                val themeModes = listOf("system", "light", "dark")
                ir.studying.app.ui.components.GlassRadioGroup(
                    options = listOf("سیستم", "روشن", "تیره"),
                    selected = themeModes.indexOf(prefs.themeMode).coerceAtLeast(0),
                    modifier = Modifier.width(214.dp),
                    height = 40.dp,
                ) { i -> Store.setThemeMode(themeModes[i]) }
            }
            SettingsDivider()
            Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                Text(stringResource(R.string.settings_072), style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) { AppPalettes.forEach { pal -> PaletteDot(pal, prefs.themeColor == pal.id) } }
            }
        }

        SettingsGroup(stringResource(R.string.settings_080)) {
            SettingsRow(
                icon = Icons.Rounded.Download,
                title = stringResource(R.string.settings_081),
                subtitle = stringResource(R.string.settings_082) + " " + prefs.adMaxMb.fa() + "MB",
                onClick = { showAutoDl = true },
            )
        }

        SettingsGroup(stringResource(R.string.settings_090)) {
            SettingsRow(
                icon = Icons.Rounded.Info,
                title = stringResource(R.string.settings_091),
                subtitle = "Studying " + ir.studying.app.BuildConfig.VERSION_NAME.fa(),
            )
        }
        Spacer(Modifier.height(40.dp))
    }

    if (showGiftCode) {
        GiftCodeSheet(onDismiss = { showGiftCode = false })
    }

    if (showMyket) {
        AlertDialog(
            onDismissRequest = { showMyket = false; Store.markMyketPopupSeen() },
            icon = {
                Box(
                    Modifier.size(64.dp).background(
                        Brush.linearGradient(listOf(Color(0xFFFFC857), Color(0xFFFF8A4C))), CircleShape,
                    ),
                    contentAlignment = Alignment.Center,
                ) { Text("⭐", style = MaterialTheme.typography.headlineMedium) }
            },
            title = { Text("۳۰۰ سکه برای نظر تو") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("با ثبت یک نقد کوتاه در مایکت کمک کن Studying بهتر شود. به‌محض باز شدن صفحهٔ نقد، پاداش یک‌باره‌ات خودکار ثبت می‌شود.")
                    Spacer(Modifier.height(12.dp))
                    Text("+۳۰۰ 🪙", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                TextButton(enabled = !myketBusy, onClick = {
                    myketBusy = true
                    Store.markMyketPopupSeen()
                    val intent = android.content.Intent(android.content.Intent.ACTION_EDIT).apply {
                        data = android.net.Uri.parse("myket://comment?id=" + ctx.packageName)
                        setPackage("ir.mservices.market")
                    }
                    val opened = runCatching { ctx.startActivity(intent) }.isSuccess
                    if (!opened) runCatching {
                        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://myket.ir/app/" + ctx.packageName)))
                    }
                    scope.launch {
                        runCatching { Api.obj(Api.post("review_claim")) }
                            .onSuccess { o ->
                                val granted = o.optInt("granted", 0)
                                ir.studying.app.ui.components.AppSnack.show(if (granted > 0) "۳۰۰ سکه به حسابت اضافه شد 🪙" else "پاداش قبلاً دریافت شده")
                                runCatching { ir.studying.app.core.Game.refresh() }
                            }
                            .onFailure { ir.studying.app.ui.components.AppSnack.show(ir.studying.app.core.humanizeError(it)) }
                        myketBusy = false
                        showMyket = false
                    }
                }) { Text(if (myketBusy) "در حال ثبت…" else "ثبت نظر و دریافت خودکار") }
            },
            dismissButton = { TextButton(onClick = { showMyket = false; Store.markMyketPopupSeen() }) { Text("بعداً") } },
        )
    }

    /*
     * دانلود خودکار: شیت پایین‌صفحه به‌جای دیالوگ.
     *
     * نسخهٔ قبلی یک `AlertDialog` بود با سه سوییچ لخت و یک ردیف چیپ که در
     * صفحهٔ کوچک بریده می‌شد و هیچ شباهتی به بقیهٔ اپ نداشت. حالا هر نوع رسانه
     * یک کارت با آیکون و توضیح است و حجم با لغزنده انتخاب می‌شود.
     */
    if (showAutoDl) {
        var img by remember { mutableStateOf(prefs.adImages) }
        var voc by remember { mutableStateOf(prefs.adVoice) }
        var fil by remember { mutableStateOf(prefs.adFiles) }
        var maxMb by remember { mutableStateOf(prefs.adMaxMb) }
        ModalBottomSheet(
            onDismissRequest = { showAutoDl = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(
                Modifier.verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp).padding(bottom = 26.dp),
            ) {
                Text(
                    stringResource(R.string.settings_081),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "هر چیزی که اینجا روشن باشد، به‌محض رسیدن پیام بدون لمس تو دانلود می‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(14.dp))

                MediaToggleCard(
                    icon = Icons.Rounded.Image,
                    title = stringResource(R.string.profile_screen_031),
                    hint = "عکس‌های چت و گروه",
                    checked = img,
                ) { img = it }
                Spacer(Modifier.height(8.dp))
                MediaToggleCard(
                    icon = Icons.Rounded.Mic,
                    title = stringResource(R.string.profile_screen_032),
                    hint = "ویس‌ها معمولاً کوچک‌اند",
                    checked = voc,
                ) { voc = it }
                Spacer(Modifier.height(8.dp))
                MediaToggleCard(
                    icon = Icons.Rounded.InsertDriveFile,
                    title = stringResource(R.string.profile_screen_033),
                    hint = "جزوه و پی‌دی‌اف",
                    checked = fil,
                ) { fil = it }

                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.profile_screen_034),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        maxMb.fa() + " مگابایت",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Slider(
                    value = maxMb.toFloat(),
                    onValueChange = { maxMb = it.toInt().coerceIn(1, 50) },
                    valueRange = 1f..50f,
                    steps = 48,
                )
                Text(
                    "فایل بزرگ‌تر از این، فقط با لمس خودت دانلود می‌شود.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = {
                        Store.setAutoDownload(img, voc, fil, maxMb)
                        showAutoDl = false
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text(stringResource(R.string.groups_010), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
            }
        }
    }
}

/** کارت یک نوع رسانه در شیت دانلود خودکار. */
@Composable
private fun MediaToggleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    hint: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val bg by androidx.compose.animation.animateColorAsState(
        if (checked) androidx.compose.ui.graphics.lerp(cs.surface, cs.primary, 0.10f)
        else cs.surfaceVariant.copy(alpha = 0.35f),
        androidx.compose.animation.core.tween(220),
        label = "mediaBg",
    )
    Surface(
        shape = ir.studying.app.ui.theme.AppRadius.small,
        color = bg,
        modifier = Modifier.fillMaxWidth().clickable { onChange(!checked) },
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).background(cs.primary.copy(alpha = if (checked) 0.16f else 0.08f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, tint = cs.primary, modifier = Modifier.size(19.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(hint, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun PaletteDot(pal: ir.studying.app.ui.theme.AppPalette, selected: Boolean) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { Store.setThemeColor(pal.id) },
    ) {
        Box(
            Modifier.size(48.dp)
                .background(Brush.linearGradient(listOf(pal.pDark, pal.sDark)), CircleShape)
                .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier),
            contentAlignment = Alignment.Center,
        ) { if (selected) Text("✓", color = Color.White) else Text(pal.emoji) }
        Spacer(Modifier.height(4.dp))
        Text(pal.fa, style = MaterialTheme.typography.labelSmall)
    }
}
