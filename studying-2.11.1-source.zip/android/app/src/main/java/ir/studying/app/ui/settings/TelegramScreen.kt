package ir.studying.app.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Summarize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.Api
import ir.studying.app.core.fa
import ir.studying.app.core.int
import ir.studying.app.core.objects
import ir.studying.app.core.str
import ir.studying.app.ui.components.AppCard
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.GradientButton
import ir.studying.app.ui.components.LoadingBox
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Telegram bridge settings.
 *
 * Linking is code based rather than a deep link on purpose. People often read
 * this on the phone that has Telegram installed, but just as often they want
 * the bot on a desktop account. A six character code works in both worlds, and
 * it expires in fifteen minutes so a screenshot cannot hand over the account.
 */
@Composable
fun TelegramScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var loading by remember { mutableStateOf(true) }
    var linked by remember { mutableStateOf(false) }
    var tgUsername by remember { mutableStateOf("") }
    var botName by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var groups by remember { mutableStateOf(listOf<Triple<Int, String, String>>()) }

    var optParts by remember { mutableStateOf(true) }
    var optReport by remember { mutableStateOf(true) }
    var optReminder by remember { mutableStateOf(true) }
    var optStreak by remember { mutableStateOf(true) }
    var optCards by remember { mutableStateOf(true) }
    var optNotifs by remember { mutableStateOf(false) }

    suspend fun refresh() {
        runCatching {
            val o = Api.obj(Api.get("tg_status"))
            linked = o.int("linked") == 1
            tgUsername = o.str("tg_username")
            botName = o.str("bot")
            val opts = o.optJSONObject("options")
            if (opts != null) {
                optParts = opts.optInt("parts", 1) == 1
                optReport = opts.optInt("report", 1) == 1
                optReminder = opts.optInt("reminder", 1) == 1
                optStreak = opts.optInt("streak", 1) == 1
                optCards = opts.optInt("cards", 1) == 1
                optNotifs = opts.optInt("notifs", 0) == 1
            }
            val ga = o.optJSONArray("groups")
            groups = if (ga == null) emptyList() else ga.objects().map {
                Triple(it.int("group_id"), it.str("name"), it.str("title"))
            }
        }
        loading = false
    }

    LaunchedEffect(Unit) { refresh() }

    /*
     * Auto check. Once a code is on screen the screen polls quietly every few
     * seconds, so the moment the user sends the code to the bot this screen
     * flips to the linked state on its own. The manual button below stays
     * anyway: polling can be starved by doze or a dead network, and having to
     * back out and re open the screen would be a miserable fallback.
     */
    LaunchedEffect(code) {
        if (code.isBlank()) return@LaunchedEffect
        var waited = 0
        while (!linked && waited < 15 * 60) {
            kotlinx.coroutines.delay(2500)
            waited += 3
            refresh()
        }
        if (linked) {
            code = ""
            AppSnack.show("✅ حسابت به ربات وصل شد")
        }
    }

    fun save(key: String, value: Boolean) {
        scope.launch {
            runCatching { Api.post("tg_settings", JSONObject().put(key, if (value) 1 else 0)) }
                .onFailure { AppSnack.show(it.message ?: "ذخیره نشد") }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SettingsRow(icon = Icons.Rounded.ArrowForward, title = "ربات تلگرام", onClick = onBack)
        Spacer(Modifier.height(10.dp))

        if (loading) {
            LoadingBox()
        } else if (!linked) {
            AppCard {
                Column(
                    Modifier.fillMaxWidth().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    TelegramOrb()
                    Spacer(Modifier.height(12.dp))
                    Text("اتصال به ربات تلگرام", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "گزارش هر پارت مطالعه، خلاصهٔ پایان شب، یادآوری و هشدار استریک را در تلگرام بگیر.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(16.dp))
                    GuideStep(1, "دکمهٔ پایین را بزن تا کد اتصالت ساخته شود.")
                    GuideStep(2, "ربات را باز کن و دکمهٔ Start را بزن.")
                    GuideStep(3, "همین کد را در چت ربات پیست کن — تمام.")
                    Spacer(Modifier.height(14.dp))

                    if (code.isBlank()) {
                        GradientButton(text = "گرفتن کد اتصال") {
                            scope.launch {
                                runCatching { Api.obj(Api.post("tg_code")) }
                                    .onSuccess {
                                        code = it.str("code")
                                        if (botName.isBlank()) botName = it.str("bot")
                                    }
                                    .onFailure { e -> AppSnack.show(e.message ?: "کد گرفته نشد") }
                            }
                        }
                    } else {
                        val reveal by animateFloatAsState(
                            targetValue = 1f,
                            animationSpec = tween(520, easing = FastOutSlowInEasing),
                            label = "reveal",
                        )
                        Box(
                            Modifier
                                .scale(0.85f + 0.15f * reveal)
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF38BDF8).copy(alpha = 0.22f), Color(0xFF2563EB).copy(alpha = 0.22f))
                                    )
                                )
                                .padding(horizontal = 22.dp, vertical = 12.dp)
                        ) {
                            Text(
                                code,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 6.sp,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "این کد تا " + 15.fa() + " دقیقه معتبر است",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ir.studying.app.ui.components.CopyButton(
                                value = code,
                                onCopied = { AppSnack.show("کد کپی شد") },
                            )
                            if (botName.isNotBlank()) {
                                TextButton(onClick = {
                                    runCatching {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/" + botName)))
                                    }.onFailure { AppSnack.show("تلگرام باز نشد") }
                                }) { Text("باز کردن ربات") }
                            }
                            TextButton(onClick = {
                                scope.launch {
                                    refresh()
                                    if (!linked) AppSnack.show("هنوز وصل نشده — کد را در چت ربات بفرست")
                                }
                            }) { Text("بررسی دستی") }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(13.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "خودکار دارم چک می‌کنم… به محض فرستادن کد، همین‌جا وصل می‌شود",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "در تلگرام ربات را استارت کن و همین کد را بفرست.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        } else {
            AppCard {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("متصل است", style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (tgUsername.isNotBlank()) "@" + tgUsername else "حساب تلگرام شما",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = {
                        scope.launch {
                            runCatching { Api.post("tg_unlink") }
                                .onSuccess {
                                    linked = false
                                    code = ""
                                    AppSnack.show("اتصال قطع شد")
                                }
                                .onFailure { AppSnack.show(it.message ?: "قطع نشد") }
                        }
                    }) { Text("قطع اتصال") }
                }
            }
            Spacer(Modifier.height(14.dp))

            SettingsGroup("چه چیزهایی در تلگرام بیاید") {
                SettingsSwitchRow(
                    icon = Icons.Rounded.MenuBook,
                    title = "هر پارت مطالعه",
                    subtitle = "به محض ثبت هر پارت",
                    checked = optParts,
                ) { optParts = it; save("parts", it) }
                SettingsDivider()
                SettingsSwitchRow(
                    icon = Icons.Rounded.Summarize,
                    title = "گزارش پایان روز",
                    subtitle = "هر شب ساعت ۲۳:۵۰ به وقت ایران",
                    checked = optReport,
                ) { optReport = it; save("report", it) }
                SettingsDivider()
                SettingsSwitchRow(
                    icon = Icons.Rounded.NotificationsActive,
                    title = "یادآوری شبانه",
                    subtitle = "ساعت ۲۱ اگر هنوز چیزی ثبت نکرده باشی",
                    checked = optReminder,
                ) { optReminder = it; save("reminder", it) }
                SettingsDivider()
                SettingsSwitchRow(
                    icon = Icons.Rounded.LocalFireDepartment,
                    title = "هشدار استریک",
                    subtitle = "ساعت ۲۲:۳۰ وقتی استریکت در خطر است",
                    checked = optStreak,
                ) { optStreak = it; save("streak", it) }
                SettingsDivider()
                SettingsSwitchRow(
                    icon = Icons.Rounded.Psychology,
                    title = "فلش‌کارت‌های سررسید",
                    checked = optCards,
                ) { optCards = it; save("cards", it) }
                SettingsDivider()
                SettingsSwitchRow(
                    icon = Icons.Rounded.Notifications,
                    title = "همهٔ اعلان‌های اپ",
                    subtitle = "لایک، کامنت، فالو و پیام‌ها هم به تلگرام بیاید",
                    checked = optNotifs,
                ) { optNotifs = it; save("notifs", it) }
            }

            /*
             * The bot has always supported custom message texts, but the only way
             * in was typing /tpl into the chat, which nobody finds. Same feature,
             * reachable from the place the user already configures Telegram.
             */
            TelegramTemplatesSection()

            SettingsGroup("گروه‌های متصل") {
                if (groups.isEmpty()) {
                    Text(
                        "گروهی وصل نیست. اگر سازندهٔ یک گروه هستی، از پایین کد بگیر، ربات را به گروه تلگرامی اضافه کن و کد را آنجا بفرست.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp),
                    )
                } else {
                    groups.forEachIndexed { i, g ->
                        if (i > 0) SettingsDivider()
                        SettingsRow(
                            icon = Icons.Rounded.Group,
                            title = g.second,
                            subtitle = if (g.third.isNotBlank()) "وصل به «" + g.third + "»" else "وصل به تلگرام",
                            trailing = {
                                TextButton(onClick = {
                                    scope.launch {
                                        runCatching {
                                            Api.post("tg_group_unlink", JSONObject().put("group_id", g.first))
                                        }
                                            .onSuccess { AppSnack.show("قطع شد"); refresh() }
                                            .onFailure { AppSnack.show(it.message ?: "قطع نشد") }
                                    }
                                }) { Text("قطع") }
                            },
                        )
                    }
                }
            }

            GroupLinkCard { gid ->
                scope.launch {
                    runCatching { Api.obj(Api.post("tg_group_code", JSONObject().put("group_id", gid))) }
                        .onSuccess {
                            val c = it.str("code")
                            clipboard.setText(AnnotatedString("/link " + c))
                            AppSnack.show("دستور /link " + c + " کپی شد؛ در گروه تلگرام بفرست", long = true)
                        }
                        .onFailure { e -> AppSnack.show(e.message ?: "کد گرفته نشد") }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}

/**
 * Lists the study groups this account owns. Only an owner may attach a group to
 * a Telegram chat, otherwise any member could redirect the group's reports.
 */
@Composable
private fun GroupLinkCard(onCode: (Int) -> Unit) {
    var owned by remember { mutableStateOf(listOf<Pair<Int, String>>()) }
    LaunchedEffect(Unit) {
        runCatching {
            owned = Api.arr(Api.get("group_list")).objects()
                .filter { it.optBoolean("is_owner", false) }
                .map { it.int("id") to it.str("name") }
        }
    }
    if (owned.isEmpty()) return
    SettingsGroup("اتصال یک گروه جدید") {
        owned.forEachIndexed { i, g ->
            if (i > 0) SettingsDivider()
            SettingsRow(
                icon = Icons.Rounded.Bolt,
                title = g.second,
                subtitle = "گرفتن کد اتصال برای گروه تلگرامی",
                trailing = { TextButton(onClick = { onCode(g.first) }) { Text("گرفتن کد") } },
            )
        }
    }
}

/** A slowly breathing badge. Cheap, but it makes the empty state feel alive. */
@Composable
private fun TelegramOrb() {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Box(
        Modifier
            .size(74.dp)
            .scale(pulse)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0xFF2563EB)))),
        contentAlignment = Alignment.Center,
    ) {
        Text("\u2708\uFE0F", fontSize = 32.sp)
    }
}

/** One numbered onboarding step. Numbers beat prose for a three step setup. */
@Composable
private fun GuideStep(number: Int, text: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0xFF2563EB)))),
            contentAlignment = Alignment.Center,
        ) {
            Text(number.fa(), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
    }
}
