package ir.studying.app.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Summarize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import ir.studying.app.core.Api
import ir.studying.app.ui.components.AppSnack
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Editor for the four Telegram texts the bot sends on the user's behalf.
 *
 * The server has supported custom templates for a while, but the only way to
 * reach them was typing /tpl into the bot, which nobody discovers. The same
 * fourteen placeholders are now editable here, with a live preview built from
 * sample values so the user can see the result before a real report goes out to
 * a channel where everyone reads it.
 *
 * An empty template means "use the default", which is why saving a blank field
 * sends null and the reset button exists at all.
 */

private data class TplKind(val key: String, val title: String, val hint: String, val icon: ImageVector)

private val TPL_KINDS = listOf(
    TplKind("parts", "پیام هر پارت", "به محض ثبت هر پارت مطالعه", Icons.Rounded.MenuBook),
    TplKind("report", "گزارش پایان روز", "هر شب ساعت ۲۳:۵۰", Icons.Rounded.Summarize),
    TplKind("streak", "هشدار استریک", "وقتی استریکت در خطر است", Icons.Rounded.LocalFireDepartment),
    TplKind("cards", "فلش‌کارت‌های سررسید", "یادآوری مرور کارت‌ها", Icons.Rounded.Psychology),
)

/** All placeholders the server understands, in the order the bot documents them. */
private val PLACEHOLDERS = listOf(
    "{message}", "{name}", "{course}", "{part}", "{start}", "{end}", "{total}",
    "{minutes}", "{count}", "{streak}", "{tier}", "{date}", "{weekday}", "{time}",
)

/*
 * Sample values used only for the preview, never sent anywhere.
 *
 * These must read exactly like the bot's own output: since the bot went back to
 * Persian digits and spelled-out durations («۲ ساعت و ۱۵ دقیقه» instead of
 * «2h 15m»), a preview in the old style would promise something the channel
 * post no longer looks like.
 */
private val SAMPLE = listOf(
    "{name}" to "@Habib_583",
    "{course}" to "شیمی",
    "{part}" to "۴۵ دقیقه",
    "{start}" to "۱۸:۳۰",
    "{end}" to "۱۹:۱۵",
    "{total}" to "۲ ساعت و ۱۵ دقیقه",
    "{minutes}" to "۲ ساعت و ۱۵ دقیقه",
    "{count}" to "۳",
    "{streak}" to "۱۲",
    "{tier}" to "داغ شدی",
    "{date}" to "۱۴۰۵/۰۵/۲۴",
    "{weekday}" to "شنبه",
    "{time}" to "۲۳:۵۰",
)

private fun defaultBody(kind: String): String = when (kind) {
    "parts" -> "🔥 شیمی · ۴۵ دقیقه\nساعت ۱۸:۳۰ تا ۱۹:۱۵\nامروز: ۲ ساعت و ۱۵ دقیقه در ۳ پارت"
    "report" ->
        "🌙 گزارش امشب — شنبه\n" +
            "📖 شیمی — ۱ ساعت و ۳۰ دقیقه ۶۷٪\n" +
            "📖 فیزیک — ۴۵ دقیقه ۳۳٪\n\n" +
            "جمع امروز: ۲ ساعت و ۱۵ دقیقه در ۳ پارت\n" +
            "دیروز: ۱ ساعت و ۴۰ دقیقه · ▲ ۳۵ دقیقه بیشتر از دیروز\n" +
            "🔥 استریک: ۱۲ روز · 🦁 رستمِ دستان · سطح ۱۶"
    "streak" -> "🔥 استریک ۱۲ روزه‌ات دارد می‌سوزد\n" +
        "امروز هیچ دقیقه‌ای ثبت نشده و تا نیمه‌شب یک ساعت و نیم مانده.\n" +
        "۱۰ دقیقه مطالعه یا یک مرور فلش‌کارت، استریک را نگه می‌دارد."
    else -> "🧠 ۱۸ فلش‌کارت سررسید شده و منتظر مرور است"
}

/** Renders a template the way the bot will, using sample values. */
private fun previewOf(kind: String, template: String): String {
    if (template.isBlank()) return defaultBody(kind)
    var out = template.replace("{message}", defaultBody(kind))
    for ((k, v) in SAMPLE) out = out.replace(k, v)
    return out
}

@Composable
fun TelegramTemplatesSection() {
    val scope = rememberCoroutineScope()

    var templates by remember { mutableStateOf(mapOf<String, String>()) }
    var openKind by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    suspend fun load() {
        runCatching { Api.obj(Api.post("tg_templates")) }
            .onSuccess { o ->
                val t = o.optJSONObject("templates")
                if (t != null) {
                    val map = mutableMapOf<String, String>()
                    for (k in TPL_KINDS) map[k.key] = if (t.isNull(k.key)) "" else t.optString(k.key, "")
                    templates = map
                }
            }
    }

    LaunchedEffect(Unit) { load() }

    fun send(kind: String, value: String?) {
        busy = true
        scope.launch {
            val body = JSONObject()
            if (value == null) body.put(kind, JSONObject.NULL) else body.put(kind, value)
            runCatching { Api.post("tg_templates", body) }
                .onSuccess {
                    templates = templates.toMutableMap().apply { put(kind, value ?: "") }
                    openKind = null
                    AppSnack.show(if (value == null) "به حالت پیش‌فرض برگشت ✅" else "متن ذخیره شد ✅")
                }
                .onFailure { AppSnack.show(it.message ?: "ذخیره نشد") }
            busy = false
        }
    }

    SettingsGroup("متن پیام‌های تلگرام") {
        Text(
            "متن هر پیامی که ربات به نام تو می‌فرستد را می‌توانی عوض کنی. خالی بگزاری یعنی متن پیش‌فرض.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
        )
        TPL_KINDS.forEachIndexed { i, kind ->
            if (i > 0) SettingsDivider()
            val current = templates[kind.key] ?: ""
            SettingsRow(
                icon = kind.icon,
                title = kind.title,
                subtitle = if (current.isBlank()) "پیش‌فرض · " + kind.hint else "شخصی‌سازی‌شده · " + kind.hint,
                onClick = {
                    if (openKind == kind.key) {
                        openKind = null
                    } else {
                        openKind = kind.key
                        draft = current
                    }
                },
                trailing = { Text(if (openKind == kind.key) "‹" else "›", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            )
            AnimatedVisibility(visible = openKind == kind.key) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 8,
                        label = { Text("متن دلخواه") },
                        placeholder = { Text("مثلاً: {message}\n— درسخوانی هر روز 💪") },
                    )
                    Spacer(Modifier.height(8.dp))

                    Text(
                        "متغیرها — بزن تا اضافه شود",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        PLACEHOLDERS.forEach { ph ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                                onClick = { draft = draft + ph },
                            ) {
                                Text(
                                    ph,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        "پیش‌نمایش",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                    ) {
                        Text(
                            previewOf(kind.key, draft),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                        )
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        "تگ‌های مجاز: <b> <i> <u> <s> <code> <a> — بقیه حذف می‌شوند",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(enabled = !busy, onClick = { send(kind.key, draft.trim().ifBlank { null }) }) {
                            Text("ذخیره")
                        }
                        TextButton(enabled = !busy && current.isNotBlank(), onClick = { send(kind.key, null) }) {
                            Text("بازگردانی به پیش‌فرض")
                        }
                        TextButton(enabled = !busy, onClick = { openKind = null }) { Text("بستن") }
                    }
                }
            }
        }
    }
}
