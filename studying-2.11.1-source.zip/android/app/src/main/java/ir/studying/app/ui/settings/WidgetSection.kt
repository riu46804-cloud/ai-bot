package ir.studying.app.ui.settings

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.widget.StudyWidget

/**
 * "Add the widget to my home screen" as a normal settings row.
 *
 * Almost nobody discovers a widget the intended way — long-press an empty spot,
 * find a widget drawer, scroll to the right app. Android 8 added a pin request
 * that does all of that in one tap, so the discoverable place (settings) can
 * offer it directly.
 *
 * Two honest fallbacks: on Android 7 the API does not exist, and even above it
 * a launcher may refuse (isRequestPinAppWidgetSupported), so in both cases the
 * user is told how to add it by hand instead of tapping a dead button.
 */
@Composable
fun WidgetSection() {
    val ctx = LocalContext.current

    SettingsGroup("ویجت صفحهٔ اصلی") {
        SettingsRow(
            icon = Icons.Rounded.Widgets,
            title = "افزودن ویجت به صفحهٔ اصلی",
            subtitle = "دقیقه‌های امروز، هدف و استریک بدون باز کردن اپ",
            onClick = { pinWidget(ctx) },
        )
    }
}

private fun pinWidget(context: android.content.Context) {
    val manual = "روی فضای خالی صفحهٔ اصلی نگه دار ← ویجت‌ها ← Studying 📚"

    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        AppSnack.show(manual, long = true)
        return
    }

    val manager = AppWidgetManager.getInstance(context)
    if (!manager.isRequestPinAppWidgetSupported) {
        AppSnack.show("لانچر گوشی‌ات این را پشتیبانی نمی‌کند. " + manual, long = true)
        return
    }

    val provider = ComponentName(context, StudyWidget::class.java)

    /*
     * The callback is what turns a silent system dialog into feedback: if the
     * user actually drops the widget, they get a confirmation instead of
     * wondering whether the tap did anything.
     */
    val callback = PendingIntent.getBroadcast(
        context,
        3001,
        Intent(context, StudyWidget::class.java)
            .setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    val requested = runCatching { manager.requestPinAppWidget(provider, null, callback) }
        .getOrDefault(false)

    if (!requested) AppSnack.show(manual, long = true)
}
