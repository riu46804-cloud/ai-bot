package ir.studying.app.ui.sms

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.FormatQuote
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.ApiException
import ir.studying.app.core.DailySms
import ir.studying.app.core.NavBus
import ir.studying.app.core.Subscriptions
import ir.studying.app.core.fa
import ir.studying.app.core.humanizeError
import ir.studying.app.ui.components.AppCard
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.GradientButton
import ir.studying.app.ui.components.SkeletonBox
import ir.studying.app.ui.components.shimmerBrush
import ir.studying.app.ui.settings.SettingsRow
import ir.studying.app.ui.theme.Amber
import ir.studying.app.ui.theme.AppRadius
import ir.studying.app.ui.theme.AppSpace
import ir.studying.app.ui.theme.CoursePurple
import ir.studying.app.ui.theme.Cyan
import ir.studying.app.ui.theme.Mint
import ir.studying.app.ui.theme.Rose
import ir.studying.app.ui.theme.readableAccent
import ir.studying.app.ui.theme.tintedSurface
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

/* رنگ‌های «طلوع» — هیرو در هر دو تم همین رنگ‌ها را دارد، مثل آسمان واقعی. */
private val Night = Color(0xFF1E1147)
private val Dusk = Color(0xFF6A2C91)
private val Dawn = Color(0xFFE2557A)
private val Sunrise = Color(0xFFFF8A4C)
private val SunCore = Color(0xFFFFE9A3)
private val SunEdge = Color(0xFFFFB347)
private val QuoteAccent = Color(0xFFF59E0B)

/**
 * پیامک انگیزشی صبحگاهی.
 *
 * هر تغییر بلافاصله (خوش‌بینانه) روی صفحه می‌نشیند و در پس‌زمینه ذخیره می‌شود؛
 * اگر سرور قبول نکرد، به حالت قبل برمی‌گردد و دلیلش را می‌گوید. قفل اشتراک
 * و شماره را سرور تعیین می‌کند؛ این صفحه فقط نشانش می‌دهد.
 */
@Composable
fun DailySmsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<DailySms.Status?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val sub by Subscriptions.state.collectAsState()

    suspend fun load(silent: Boolean) {
        if (!silent) error = null
        try {
            status = DailySms.status()
            error = null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (status == null) error = humanizeError(e) else if (!silent) AppSnack.show(humanizeError(e))
        }
    }

    LaunchedEffect(Unit) { load(false) }
    // بعد از خرید یا تمدید اشتراک از همین صفحه، قفل خودبه‌خود باز شود.
    LaunchedEffect(sub.expiresAt) { if (status != null) load(true) }

    fun apply(motivational: Boolean, konkur: Boolean, examKey: String?) {
        val before = status ?: return
        if (saving) return
        if (before.locked && (motivational || konkur)) {
            Subscriptions.openPaywall()
            return
        }
        status = before.copy(motivational = motivational, konkur = konkur, examKey = examKey ?: before.examKey)
        saving = true
        scope.launch {
            try {
                val r = DailySms.save(motivational, konkur, examKey)
                status = r.status
                if (r.message.isNotBlank()) AppSnack.show(r.message)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = before
                if ((e as? ApiException)?.errorCode == "subscription_required") Subscriptions.openPaywall()
                AppSnack.show(humanizeError(e), long = true)
            } finally {
                saving = false
            }
        }
    }

    fun sendTest() {
        if (testing) return
        testing = true
        scope.launch {
            try {
                val r = DailySms.sendTest()
                status = r.status
                AppSnack.show(r.message.ifBlank { "پیامک آزمایشی فرستاده شد 📩" })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AppSnack.show(humanizeError(e), long = true)
                load(true)
            } finally {
                testing = false
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(AppSpace.lg)) {
        SettingsRow(icon = Icons.Rounded.ArrowForward, title = "پیامک صبحگاهی", onClick = onBack)
        Spacer(Modifier.height(AppSpace.sm))
        val s = status
        val err = error
        when {
            s == null && err != null -> ErrorState(err, onRetry = { scope.launch { load(false) } })
            s == null -> LoadingState()
            else -> DailySmsContent(
                s = s,
                testing = testing,
                onApply = { m, k, e -> apply(m, k, e) },
                onSendTest = { sendTest() },
            )
        }
    }
}

/**
 * بدنهٔ صفحه، بدون شبکه و state — تا بشود با دادهٔ نمونه پیش‌نمایش/اسکرین‌شات گرفت.
 */
@Composable
internal fun DailySmsContent(
    s: DailySms.Status,
    testing: Boolean,
    onApply: (motivational: Boolean, konkur: Boolean, examKey: String?) -> Unit,
    onSendTest: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        SunriseHero(s)
        Spacer(Modifier.height(AppSpace.lg))
        when (s.blockReason) {
            "subscription_required" -> { LockedCard(s); Spacer(Modifier.height(AppSpace.lg)) }
            "phone_required", "phone_unverified" -> { PhoneCard(s.blockReason); Spacer(Modifier.height(AppSpace.lg)) }
        }
        if (s.locked && s.anyOn) {
            OutlinedButton(onClick = { onApply(false, false, null) }, modifier = Modifier.fillMaxWidth()) {
                Text("خاموش کردن همه پیامک‌ها")
            }
            Spacer(Modifier.height(AppSpace.md))
        }
        SectionLabel("چه چیزی برایت بفرستیم؟")
        ModeCard(
            icon = Icons.Rounded.FormatQuote,
            accent = QuoteAccent,
            title = "جملهٔ انگیزشی",
            subtitle = if (s.quotesCount > 0) "جمله‌های انگیزشی از میان ${s.quotesCount.fa()} جمله" else "جمله‌های انگیزشی برای هر صبح",
            checked = s.motivational,
            locked = s.locked,
            onToggle = { onApply(it, s.konkur, null) },
        )
        Spacer(Modifier.height(AppSpace.md))
        ModeCard(
            icon = Icons.Rounded.HourglassTop,
            accent = CoursePurple,
            title = "شمارش معکوس کنکور",
            subtitle = "هر صبح ببین چند روز تا کنکورت مانده",
            checked = s.konkur,
            locked = s.locked,
            onToggle = { onApply(s.motivational, it, if (it) s.shownExam?.key else null) },
        ) {
            AnimatedVisibility(
                visible = s.konkur,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                Column {
                    Spacer(Modifier.height(AppSpace.md))
                    ExamPicker(s) { key -> if (key != s.examKey) onApply(s.motivational, true, key) }
                    Spacer(Modifier.height(AppSpace.md))
                    s.shownExam?.let { CountdownPanel(it) }
                }
            }
        }
        Spacer(Modifier.height(AppSpace.lg))
        s.preview?.let {
            PreviewCard(s, it)
            Spacer(Modifier.height(AppSpace.lg))
        }
        InfoCard(s)
        Spacer(Modifier.height(AppSpace.lg))
        if (!s.locked && s.blockReason == null) {
            TestCard(s, testing, onSendTest)
            Spacer(Modifier.height(AppSpace.lg))
        }
        if (s.history.isNotEmpty()) {
            SectionLabel("پیامک‌های اخیر")
            s.history.forEach { HistoryRow(it); Spacer(Modifier.height(AppSpace.sm)) }
            Spacer(Modifier.height(AppSpace.sm))
        }
        Text(
            "هر وقت بخواهی، با خاموش کردن هر دو حالت، پیامک‌ها قطع می‌شوند.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = AppSpace.sm),
        )
        Spacer(Modifier.height(AppSpace.xl))
    }
}

/* ======================================================================== */
/*  هیرو: آسمان صبح با خورشیدی که آرام بالا می‌آید                            */
/* ======================================================================== */

@Composable
private fun SunriseHero(s: DailySms.Status) {
    val t = rememberInfiniteTransition(label = "sunrise")
    val rise by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "rise")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(48000, easing = LinearEasing)), label = "spin")
    val twinkle by t.animateFloat(0.2f, 1f, infiniteRepeatable(tween(1700), RepeatMode.Reverse), label = "twinkle")

    Box(
        Modifier.fillMaxWidth().height(236.dp).clip(AppRadius.hero)
            .background(Brush.verticalGradient(listOf(Night, Dusk, Dawn, Sunrise))),
    ) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val stars = listOf(0.08f to 0.12f, 0.22f to 0.24f, 0.36f to 0.07f, 0.5f to 0.2f, 0.64f to 0.1f, 0.83f to 0.16f, 0.93f to 0.3f, 0.3f to 0.38f)
            stars.forEachIndexed { i, (x, y) ->
                val a = if (i % 2 == 0) twinkle else 1.2f - twinkle
                drawCircle(Color.White.copy(alpha = (a * 0.85f).coerceIn(0.12f, 0.9f)),
                    radius = if (i % 3 == 0) 2.2.dp.toPx() else 1.4.dp.toPx(), center = Offset(w * x, h * y))
            }
            // خورشید در سمت چپ فیزیکی؛ متن (راست‌به‌چپ) سمت راست است.
            val r = 32.dp.toPx()
            val c = Offset(w * 0.19f, h * (0.8f - 0.07f * rise))
            drawCircle(Brush.radialGradient(listOf(SunEdge.copy(alpha = 0.6f), Color.Transparent), center = c, radius = r * 3.4f), radius = r * 3.4f, center = c)
            rotate(spin, pivot = c) {
                for (i in 0 until 12) {
                    val ang = Math.toRadians(i * 30.0)
                    val dx = cos(ang).toFloat()
                    val dy = sin(ang).toFloat()
                    drawLine(SunCore.copy(alpha = 0.65f), Offset(c.x + dx * r * 1.32f, c.y + dy * r * 1.32f),
                        Offset(c.x + dx * r * 1.7f, c.y + dy * r * 1.7f), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                }
            }
            drawCircle(Brush.radialGradient(listOf(SunCore, SunEdge), center = c, radius = r), radius = r, center = c)
            val far = Path().apply {
                moveTo(0f, h); lineTo(0f, h * 0.84f)
                quadraticBezierTo(w * 0.3f, h * 0.7f, w * 0.58f, h * 0.84f)
                quadraticBezierTo(w * 0.8f, h * 0.93f, w, h * 0.8f)
                lineTo(w, h); close()
            }
            drawPath(far, Color(0xFF3B1350).copy(alpha = 0.45f))
            val near = Path().apply {
                moveTo(0f, h); lineTo(0f, h * 0.93f)
                quadraticBezierTo(w * 0.45f, h * 0.83f, w, h * 0.95f)
                lineTo(w, h); close()
            }
            drawPath(near, Color(0xFF240B38).copy(alpha = 0.6f))
        }
        Column(Modifier.align(Alignment.TopStart).fillMaxWidth(0.74f).padding(AppSpace.xl)) {
            StatusPill(s)
            Spacer(Modifier.height(AppSpace.md))
            Text("صبحت را با انرژی شروع کن", style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black, color = Color.White)
            Spacer(Modifier.height(AppSpace.xs))
            Text(
                "هر روز ساعت ${s.sendTimeFa} صبح، یک پیامک کوتاه با جملهٔ انگیزشی و شمارش معکوس کنکور؛ حتی وقتی اینترنت نداری.",
                style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.86f), lineHeight = 21.sp,
            )
        }
        if (s.totalSent > 0) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(horizontal = AppSpace.xl, vertical = AppSpace.md),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Sms, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "${s.totalSent.fa()} پیامک تا امروز" + (s.sinceFa?.let { " · از $it" } ?: ""),
                    style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.92f),
                )
            }
        }
    }
}

@Composable
private fun StatusPill(s: DailySms.Status) {
    val (dot, text) = when {
        s.locked -> Amber to "ویژهٔ مشترکین"
        s.blockReason != null -> Rose to "شمارهٔ موبایل لازم است"
        // برچسب سرور «فردا، ساعت ۷:۰۰ صبح» است؛ در این قرص کوتاهش می‌کنیم تا جا شود.
        s.active -> Mint to "فعال · پیامک بعدی: ${s.nextSendLabel.substringBefore('،').trim().ifBlank { "فردا" }} ${s.sendTimeFa}"
        else -> Color.White.copy(alpha = 0.6f) to "خاموش"
    }
    val t = rememberInfiniteTransition(label = "pill")
    val pulse by t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.16f), border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f))) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            if (s.locked) {
                Icon(Icons.Rounded.Lock, null, tint = Amber, modifier = Modifier.size(13.dp))
            } else {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot.copy(alpha = if (s.active) pulse else 1f)))
            }
            Spacer(Modifier.width(7.dp))
            Text(text, style = MaterialTheme.typography.labelMedium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/* ======================================================================== */
/*  کارت‌های قفل و شماره                                                     */
/* ======================================================================== */

@Composable
private fun LockedCard(s: DailySms.Status) {
    val accent = readableAccent(Amber)
    Surface(shape = AppRadius.card, color = tintedSurface(Amber, 0.13f), border = BorderStroke(1.dp, Amber.copy(alpha = 0.45f))) {
        Column(Modifier.fillMaxWidth().padding(AppSpace.lg)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(AppRadius.small).background(Brush.linearGradient(listOf(Amber, Sunrise))),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.WorkspacePremium, null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(AppSpace.md))
                Column(Modifier.weight(1f)) {
                    Text("ویژهٔ مشترکین Studying", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (s.anyOn) "اشتراکت تمام شده و پیامک‌ها متوقف شده‌اند؛ با تمدید، از صبح بعد دوباره می‌رسند."
                        else "با اشتراک ویژه، هر صبح این پیامک را می‌گیری:",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(AppSpace.md))
            Benefit("☀", if (s.quotesCount > 0) "جمله‌های انگیزشی از میان ${s.quotesCount.fa()} جمله" else "جمله‌های انگیزشی برای هر صبح")
            Benefit("⏳", "شمارش معکوس کنکور گروه آزمایشی خودت")
            Benefit("📩", "روی پیامک؛ بدون نیاز به اینترنت یا باز کردن اپ")
            Spacer(Modifier.height(AppSpace.md))
            GradientButton(
                text = if (s.anyOn) "تمدید اشتراک" else "فعال‌سازی اشتراک ویژه",
                icon = Icons.Rounded.WorkspacePremium,
                modifier = Modifier.fillMaxWidth(),
            ) { Subscriptions.openPaywall() }
            Text(
                "تم‌های ویژهٔ اتاق مطالعه هم در همین اشتراک است.",
                style = MaterialTheme.typography.labelSmall, color = accent,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = AppSpace.sm),
            )
        }
    }
}

@Composable
private fun Benefit(emoji: String, text: String) {
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 15.sp)
        Spacer(Modifier.width(AppSpace.sm))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PhoneCard(reason: String) {
    Surface(shape = AppRadius.card, color = tintedSurface(Rose, 0.12f), border = BorderStroke(1.dp, Rose.copy(alpha = 0.4f))) {
        Row(Modifier.fillMaxWidth().padding(AppSpace.lg), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PhoneAndroid, null, tint = readableAccent(Rose), modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(AppSpace.md))
            Column(Modifier.weight(1f)) {
                Text(if (reason == "phone_unverified") "شماره‌ات هنوز تأیید نشده" else "شمارهٔ موبایل ثبت نشده",
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("پیامک‌ها فقط به شمارهٔ تأییدشدهٔ حسابت می‌روند. از ویرایش پروفایل، شماره‌ات را ثبت و تأیید کن.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { NavBus.requestRoute("profile_edit") }) { Text("ثبت شماره") }
        }
    }
}

/* ======================================================================== */
/*  حالت‌ها                                                                  */
/* ======================================================================== */

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = AppSpace.xs, bottom = AppSpace.sm))
}

@Composable
private fun ModeCard(
    icon: ImageVector,
    accent: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    locked: Boolean,
    onToggle: (Boolean) -> Unit,
    extra: @Composable ColumnScope.() -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    val border by animateColorAsState(if (checked) accent.copy(alpha = 0.75f) else cs.outlineVariant.copy(alpha = 0.55f), label = "modeBorder")
    val bg by animateColorAsState(if (checked) tintedSurface(accent, 0.09f) else cs.surface, label = "modeBg")
    Surface(shape = AppRadius.card, color = bg, border = BorderStroke(if (checked) 1.5.dp else 1.dp, border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.animateContentSize()) {
            Row(
                Modifier.fillMaxWidth().clickable { onToggle(!checked) }.padding(AppSpace.lg),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(48.dp).clip(AppRadius.small)
                        .background(Brush.linearGradient(listOf(accent, lerp(accent, Color.White, 0.3f)))),
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
                Spacer(Modifier.width(AppSpace.md))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.width(AppSpace.sm))
                if (locked) {
                    Icon(Icons.Rounded.Lock, null, tint = readableAccent(Amber), modifier = Modifier.size(22.dp))
                } else {
                    Switch(
                        checked = checked,
                        onCheckedChange = { onToggle(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.White),
                    )
                }
            }
            Column(Modifier.padding(start = AppSpace.lg, end = AppSpace.lg, bottom = if (checked) AppSpace.lg else 0.dp)) { extra() }
        }
    }
}

@Composable
private fun ExamPicker(s: DailySms.Status, onPick: (String) -> Unit) {
    val selected = s.shownExam?.key
    Text("گروه آزمایشی", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(AppSpace.sm))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(AppSpace.sm)) {
        s.exams.forEach { e ->
            val on = e.key == selected
            val bg by animateColorAsState(if (on) CoursePurple.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f), label = "chip")
            Surface(
                shape = AppRadius.chip, color = bg,
                border = BorderStroke(1.dp, if (on) CoursePurple else Color.Transparent),
                modifier = Modifier.clip(AppRadius.chip).clickable { onPick(e.key) },
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (e.emoji.isNotBlank()) { Text(e.emoji, fontSize = 14.sp); Spacer(Modifier.width(6.dp)) }
                    Text(e.shortTitle, style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                        color = if (on) readableAccent(CoursePurple) else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

@Composable
private fun CountdownPanel(e: DailySms.Exam) {
    val days = e.daysLeft
    val target = when {
        days == null -> 0f
        days <= 0 -> 1f
        else -> (1f - days / 365f).coerceIn(0.04f, 1f)
    }
    // در پیش‌نمایش/اسکرین‌شات حلقه از اول پر است؛ در اپ از صفر پر می‌شود.
    val inspection = LocalInspectionMode.current
    var started by remember(e.key) { mutableStateOf(inspection) }
    LaunchedEffect(e.key) { started = true }
    val sweep by animateFloatAsState(if (started) target else 0f, tween(1100, easing = FastOutSlowInEasing), label = "ring")
    val track = CoursePurple.copy(alpha = 0.16f)
    Surface(shape = AppRadius.small, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)) {
        Row(Modifier.fillMaxWidth().padding(AppSpace.md), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.matchParentSize()) {
                    val stroke = 9.dp.toPx()
                    val inset = stroke / 2
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(track, 0f, 360f, false, topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke))
                    drawArc(
                        Brush.sweepGradient(listOf(Cyan, CoursePurple, Rose, Cyan)), -90f, 360f * sweep, false,
                        topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        when {
                            days == null -> "—"
                            days < 0 -> "✓"
                            else -> days.fa()
                        },
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black,
                    )
                    Text(if (days != null && days >= 0) "روز" else "", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.width(AppSpace.lg))
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        days == null -> e.title
                        days < 0 -> "${e.title} برگزار شد"
                        days == 0 -> "امروز روز ${e.title} است!"
                        else -> "مانده تا ${e.title}"
                    },
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                )
                e.dateFa?.let {
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Event, null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(4.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(6.dp))
                val accent = if (e.official) Mint else Amber
                Surface(shape = CircleShape, color = accent.copy(alpha = 0.16f)) {
                    Text(
                        if (e.official) "تاریخ رسمی سازمان سنجش" else "تاریخ تقریبی",
                        style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                        color = readableAccent(if (e.official) Color(0xFF059669) else Color(0xFFB45309)),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp),
                    )
                }
                if (!e.official) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (days != null && days < 0) "تاریخ کنکور بعدی به‌محض اعلام ثبت می‌شود."
                        else "تاریخ رسمی هنوز اعلام نشده؛ به‌محض اعلام سازمان سنجش به‌روز می‌شود.",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/* ======================================================================== */
/*  پیش‌نمایش، اطلاعات، تست، سابقه                                          */
/* ======================================================================== */

@Composable
private fun PreviewCard(s: DailySms.Status, p: DailySms.Preview) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Sms, null, tint = readableAccent(Sunrise), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(AppSpace.sm))
            Text("پیش‌نمایش پیامک", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (p.isSample) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                    Text("نمونه", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp))
                }
            }
        }
        Spacer(Modifier.height(AppSpace.md))
        Surface(shape = RoundedCornerShape(24.dp), color = tintedSurface(Dusk, 0.07f)) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Sunrise, Dusk))),
                        contentAlignment = Alignment.Center,
                    ) { Text("S", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp) }
                    Spacer(Modifier.width(AppSpace.sm))
                    Column(Modifier.weight(1f)) {
                        Text("Studying", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Text("پیامک · ${s.nextSendDayFa.ifBlank { "هر روز" }}", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(s.sendTimeFa, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(AppSpace.md))
                Surface(
                    shape = RoundedCornerShape(topStart = 6.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth(0.94f),
                ) {
                    Text(p.text, style = MaterialTheme.typography.bodyMedium, lineHeight = 25.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp))
                }
            }
        }
        Spacer(Modifier.height(AppSpace.sm))
        Text(
            when {
                p.isSample && s.locked -> "نمونهٔ پیامکی که مشترکین ویژه هر صبح می‌گیرند."
                p.isSample -> "این یک نمونه است؛ یکی از حالت‌ها را روشن کن تا پیامک خودت را ببینی."
                else -> listOfNotNull(
                    "جملهٔ هر روز تازه است".takeIf { s.motivational },
                    "عدد شمارش معکوس هر صبح به‌روز می‌شود".takeIf { s.konkur },
                ).joinToString(" · ")
            },
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun InfoCard(s: DailySms.Status) {
    AppCard {
        InfoRow(Icons.Rounded.PhoneAndroid, "ارسال به", s.phoneMasked?.fa() ?: "شماره ثبت نشده", ltr = s.phoneMasked != null)
        InfoRow(Icons.Rounded.Schedule, "زمان ارسال", "هر روز ${s.sendTimeFa} صبح", sub = "به وقت تهران")
        if (s.active) InfoRow(Icons.Rounded.Event, "پیامک بعدی", s.nextSendLabel, sub = s.nextSendDayFa.ifBlank { null })
        if (s.todayStatus == "sent") InfoRow(Icons.Rounded.CheckCircle, "پیامک امروز", "ثبت ارسال نزد سرویس ✓")
        if (s.todayStatus == "unknown") InfoRow(Icons.Rounded.Schedule, "پیامک امروز", "وضعیت ارسال نامشخص است")
        if (s.eligible) {
            InfoRow(Icons.Rounded.WorkspacePremium, "اشتراک", "فعال" + (s.subscriptionExpiresFa?.let { " تا $it" } ?: ""))
            if (s.subscriptionDaysLeft in 0..5 && s.anyOn) {
                Spacer(Modifier.height(AppSpace.sm))
                Surface(shape = AppRadius.small, color = tintedSurface(Amber, 0.14f)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = AppSpace.md, vertical = AppSpace.sm), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (s.subscriptionDaysLeft <= 1) "اشتراکت امروز یا فردا تمام می‌شود؛ برای ادامهٔ پیامک‌ها تمدید کن."
                            else "اشتراکت ${s.subscriptionDaysLeft.fa()} روز دیگر تمام می‌شود؛ برای ادامهٔ پیامک‌ها تمدید کن.",
                            style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { Subscriptions.openPaywall() }) { Text("تمدید") }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String, ltr: Boolean = false, sub: String? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(AppSpace.md))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(AppSpace.md))
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium.copy(textDirection = if (ltr) TextDirection.Ltr else TextDirection.Content),
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.End,
            )
            if (sub != null) {
                Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun TestCard(s: DailySms.Status, busy: Boolean, onSend: () -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(AppRadius.small).background(tintedSurface(Cyan, 0.2f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Send, null, tint = readableAccent(Color(0xFF0284C7)), modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(AppSpace.md))
            Column(Modifier.weight(1f)) {
                Text("پیامک آزمایشی", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    if (s.testUsedToday) "پیامک آزمایشی امروز فرستاده شد ✓ فردا دوباره می‌شود."
                    else "همین الان یک نمونه روی گوشی‌ات بگیر (روزی یک بار).",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(AppSpace.sm))
            OutlinedButton(onClick = onSend, enabled = s.testAvailable && !busy) {
                if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                else Text("بفرست")
            }
        }
    }
}

@Composable
private fun HistoryRow(h: DailySms.HistoryItem) {
    var open by remember { mutableStateOf(false) }
    val ok = h.status == "sent"
    AppCard(onClick = { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(h.dateFa + (h.timeFa?.let { " · $it" } ?: ""), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            if (h.kind == "test") {
                Surface(shape = CircleShape, color = tintedSurface(Cyan, 0.18f)) {
                    Text("آزمایشی", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp))
                }
                Spacer(Modifier.width(6.dp))
            }
            Surface(shape = CircleShape, color = (if (ok) Mint else Rose).copy(alpha = 0.16f)) {
                Text(
                    h.statusLabel.ifBlank { if (ok) "ارسال شد" else "ارسال نشد" },
                    style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                    color = readableAccent(if (ok) Color(0xFF059669) else Color(0xFFE11D48)),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            h.text, style = MaterialTheme.typography.bodySmall, lineHeight = 21.sp,
            maxLines = if (open) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun LoadingState() {
    Box(Modifier.fillMaxWidth().height(236.dp).clip(AppRadius.hero).background(shimmerBrush()))
    Spacer(Modifier.height(AppSpace.lg))
    SkeletonBox(height = 240.dp)
}
