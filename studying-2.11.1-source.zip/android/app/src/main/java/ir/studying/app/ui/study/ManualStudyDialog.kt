package ir.studying.app.ui.study

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import ir.studying.app.core.StudyNumberInput
import ir.studying.app.core.StudyReportMath

/** Manual registrations go through the very same detail sheet and durable queue as timers. */
@Composable
fun ManualStudyDialog(onDismiss: () -> Unit, onContinue: (Int) -> Unit) {
    var raw by remember { mutableStateOf("") }
    val minutes = StudyNumberInput.parse(raw, StudyReportMath.MAX_MINUTES)
    val valid = minutes != null && minutes > 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت دستی مطالعه") },
        text = {
            OutlinedTextField(
                value = raw,
                onValueChange = { StudyNumberInput.normalize(it)?.let { text -> raw = text } },
                label = { Text("زمان مطالعه (دقیقه)") },
                supportingText = { Text("۱ تا ۱۴۴۰ دقیقه؛ در مرحلهٔ بعد درس و جزئیات را وارد کن.",
                    style = MaterialTheme.typography.labelSmall) },
                isError = raw.isNotEmpty() && !valid,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { if (valid) onContinue(minutes!!) }) { Text("ادامهٔ ثبت گزارش") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
