@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.study

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import ir.studying.app.core.StudyNumberInput
import ir.studying.app.core.StudyReportMath
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.StudyRecent
import ir.studying.app.core.fa
import ir.studying.app.data.Course
import ir.studying.app.data.CourseTopic
import ir.studying.app.data.StudyDetail
import ir.studying.app.data.TopicRepo

/**
 * شیت «ثبت گزارش» — بازطراحی‌شده.
 *
 * نسخهٔ قبلی یک ستون بلند از جعبه‌های +/− بود: انتخاب درس اصلاً اینجا نبود
 * (بالای کرنومتر گیر کرده بود)، سرفصل‌ها همیشه باز و طولانی بودند و پیدا
 * کردن فصل دیروز یعنی اسکرول. حالا:
 *  ۱) درس همین‌جا و در لحظهٔ ثبت انتخاب می‌شود، نه قبل از شروع تایمر.
 *  ۲) «مثل دفعهٔ قبل»: آخرین سرفصل‌های همین درس یک‌ضربه برمی‌گردند.
 *  ۳) سرفصل جمع‌شده است و جست‌وجو دارد.
 *  ۴) تفکیک زمان یک نوار انباشته دارد تا ببینی چقدرش تفکیک شده.
 *  ۵) تمرکز به‌جای اسلایدر، پنج حالت شکلکی است — سریع‌تر و صادقانه‌تر.
 */
@Composable
fun StudyDetailSheet(
    courseId: Int,
    minutes: Int,
    courses: List<Course> = emptyList(),
    initial: StudyDetail = StudyDetail(),
    confirmText: String = "ثبت گزارش",
    onQuick: ((Int) -> Unit)? = null,
    onDismiss: () -> Unit,
    onConfirm: (Int, StudyDetail) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current

    var course by remember { mutableIntStateOf(courseId) }
    var topics by remember { mutableStateOf<List<CourseTopic>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var topicId by remember { mutableIntStateOf(initial.topicId) }
    var topicTitle by remember { mutableStateOf(initial.topicTitle) }
    var pickerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    var correctText by remember { mutableStateOf(initial.qCorrect.takeIf { it > 0 }?.toString().orEmpty()) }
    var wrongText by remember { mutableStateOf(initial.qWrong.takeIf { it > 0 }?.toString().orEmpty()) }
    var blankText by remember { mutableStateOf(initial.qBlank.takeIf { it > 0 }?.toString().orEmpty()) }
    var descriptiveText by remember { mutableStateOf(initial.qDescriptive.takeIf { it > 0 }?.toString().orEmpty()) }
    var mVideoText by remember { mutableStateOf(initial.minVideo.takeIf { it > 0 }?.toString().orEmpty()) }
    var mTestText by remember { mutableStateOf(initial.minTest.takeIf { it > 0 }?.toString().orEmpty()) }
    var mBookText by remember { mutableStateOf(initial.minBook.takeIf { it > 0 }?.toString().orEmpty()) }
    var mReviewText by remember { mutableStateOf(initial.minReview.takeIf { it > 0 }?.toString().orEmpty()) }
    var mLearnText by remember { mutableStateOf(initial.minLearn.takeIf { it > 0 }?.toString().orEmpty()) }
    var focus by remember { mutableIntStateOf(if (initial.focus > 0) initial.focus else 80) }
    var note by remember { mutableStateOf(initial.note) }

    /* با عوض شدن درس، سرفصل‌ها از نو می‌آیند و انتخاب قبلی بی‌معنا می‌شود. */
    LaunchedEffect(course) {
        if (course <= 0) { topics = emptyList(); loading = false; return@LaunchedEffect }
        loading = true
        runCatching { TopicRepo.topics(course) }.onSuccess { topics = it.first }
        loading = false
    }

    val correct = StudyNumberInput.parse(correctText, StudyReportMath.MAX_QUESTIONS) ?: 0
    val wrong = StudyNumberInput.parse(wrongText, StudyReportMath.MAX_QUESTIONS) ?: 0
    val blank = StudyNumberInput.parse(blankText, StudyReportMath.MAX_QUESTIONS) ?: 0
    val descriptive = StudyNumberInput.parse(descriptiveText, StudyReportMath.MAX_QUESTIONS) ?: 0
    val mVideo = StudyNumberInput.parse(mVideoText, StudyReportMath.MAX_MINUTES) ?: 0
    val mTest = StudyNumberInput.parse(mTestText, StudyReportMath.MAX_MINUTES) ?: 0
    val mBook = StudyNumberInput.parse(mBookText, StudyReportMath.MAX_MINUTES) ?: 0
    val mReview = StudyNumberInput.parse(mReviewText, StudyReportMath.MAX_MINUTES) ?: 0
    val mLearn = StudyNumberInput.parse(mLearnText, StudyReportMath.MAX_MINUTES) ?: 0
    val spent = mVideo + mTest + mBook + mReview + mLearn
    val countsValid = listOf(correctText, wrongText, blankText, descriptiveText)
        .all { StudyNumberInput.parse(it, StudyReportMath.MAX_QUESTIONS) != null }
    val timesValid = listOf(mVideoText, mTestText, mBookText, mReviewText, mLearnText)
        .all { StudyNumberInput.parse(it, StudyReportMath.MAX_MINUTES) != null }
    val countTotalValid = correct + wrong + blank <= StudyReportMath.MAX_QUESTIONS
    val valid = countsValid && timesValid && countTotalValid && spent <= minutes && minutes > 0

    /* init داخل remember: اگر منتظر LaunchedEffect می‌ماندیم، اولین ترسیم شیت
       همیشه بدون «قبلی‌ها» بود. */
    val recent = remember(course) { StudyRecent.init(ctx); StudyRecent.forCourse(course) }

    fun build() = StudyDetail(
        topicId = topicId, topicTitle = topicTitle,
        qCorrect = correct, qWrong = wrong, qBlank = blank, qDescriptive = descriptive,
        minVideo = mVideo, minTest = mTest, minBook = mBook,
        minReview = mReview, minLearn = mLearn,
        focus = focus, note = note.trim(),
    )

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp).padding(bottom = 24.dp),
        ) {
            /* ---------- سرتیتر ---------- */
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(54.dp).clip(RoundedCornerShape(18.dp))
                        .background(cs.primary.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(minutes.fa(), fontSize = 20.sp, fontWeight = FontWeight.Black, color = cs.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("ثبت گزارش مطالعه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    Text(
                        "${minutes.fa()} دقیقه — جزئیات اختیاری است، ولی تحلیل‌ها را دقیق می‌کند",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    )
                }
            }

            /* ---------- درس ---------- */
            if (courses.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                SectionTitle("درس")
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    courses.forEach { c ->
                        Pill(
                            text = "${c.icon} ${c.name}",
                            selected = c.id == course,
                            onClick = {
                                if (c.id != course) { topicId = 0; topicTitle = "" }
                                course = c.id
                            },
                        )
                    }
                }
                if (course <= 0) {
                    Spacer(Modifier.height(6.dp))
                    Text("اول درس را انتخاب کن", style = MaterialTheme.typography.labelSmall, color = cs.error)
                }
            }

            /* ---------- مثل دفعهٔ قبل ---------- */
            if (recent.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.History, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    SectionTitle("ادامهٔ همان قبلی")
                }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    recent.take(6).forEach { e ->
                        Pill(
                            text = e.topicTitle.substringAfterLast("› ").trim(),
                            selected = e.topicId == topicId,
                            onClick = {
                                /* سرفصل و الگوی تفکیک قبلی برمی‌گردد؛ تعداد تست‌ها نه. */
                                topicId = e.topicId
                                topicTitle = e.topicTitle
                                if (spent == 0 && e.detail.activityMinutes <= minutes) {
                                    mVideoText = e.detail.minVideo.takeIf { it > 0 }?.toString().orEmpty(); mTestText = e.detail.minTest.takeIf { it > 0 }?.toString().orEmpty()
                                    mBookText = e.detail.minBook.takeIf { it > 0 }?.toString().orEmpty(); mReviewText = e.detail.minReview.takeIf { it > 0 }?.toString().orEmpty()
                                    mLearnText = e.detail.minLearn.takeIf { it > 0 }?.toString().orEmpty()
                                }
                                if (e.detail.focus > 0) focus = e.detail.focus
                            },
                        )
                    }
                }
            }

            /* ---------- سرفصل ---------- */
            Spacer(Modifier.height(14.dp))
            SectionTitle("سرفصل")
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = cs.surfaceVariant.copy(alpha = 0.35f),
                modifier = Modifier.fillMaxWidth().animateContentSize(),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { pickerOpen = !pickerOpen }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            if (topicId > 0) Icons.Rounded.Check else Icons.Rounded.Search,
                            null,
                            tint = if (topicId > 0) cs.primary else cs.onSurfaceVariant,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (topicId > 0) topicTitle else "انتخاب فصل / مبحث (اختیاری)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (topicId > 0) cs.primary else cs.onSurfaceVariant,
                            fontWeight = if (topicId > 0) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            if (pickerOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                            null, tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp),
                        )
                    }
                    AnimatedVisibility(pickerOpen) {
                        Column {
                            Spacer(Modifier.height(8.dp))
                            when {
                                course <= 0 -> Text(
                                    "اول درس را انتخاب کن.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                loading -> ir.studying.app.ui.components.LoadingBox(height = 80.dp)
                                topics.isEmpty() -> Text(
                                    "برای این درس فصل‌بندی نساخته‌ای. از «مدیریت دروس ← جزئیات» یکی از درس‌های آماده را اضافه کن.",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                else -> {
                                    OutlinedTextField(
                                        value = query,
                                        onValueChange = { query = it },
                                        placeholder = { Text("جست‌وجوی مبحث") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Box(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
                                        Column(Modifier.fillMaxWidth()) {
                                            if (query.isBlank()) {
                                                topics.forEach { chapter ->
                                                    TopicPickRow(chapter, topicId) { t, path ->
                                                        topicId = t.id; topicTitle = path; pickerOpen = false
                                                    }
                                                }
                                            } else {
                                                /* جست‌وجو درخت را صاف می‌کند؛ مسیر کامل نمایش داده می‌شود. */
                                                flatten(topics).filter { it.second.contains(query.trim()) }
                                                    .take(40).forEach { (t, path) ->
                                                        FlatTopicRow(path, t.id == topicId) {
                                                            topicId = t.id; topicTitle = path
                                                            pickerOpen = false; query = ""
                                                        }
                                                    }
                                            }
                                        }
                                    }
                                    if (topicId > 0) {
                                        TextButton(onClick = { topicId = 0; topicTitle = "" }) { Text("حذف انتخاب") }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            /* ---------- تست ---------- */
            Spacer(Modifier.height(14.dp))
            SectionTitle("تست")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumBox("درست", correctText, Modifier.weight(1f), tint = Color(0xFF10B981)) { correctText = it }
                NumBox("غلط", wrongText, Modifier.weight(1f), tint = Color(0xFFFB7185)) { wrongText = it }
                NumBox("نزده", blankText, Modifier.weight(1f), tint = cs.onSurfaceVariant) { blankText = it }
            }
            Spacer(Modifier.height(8.dp))
            NumBox("سؤال تشریحی حل‌شده", descriptiveText, Modifier.fillMaxWidth()) { descriptiveText = it }
            Text("تشریحی جدا از تعداد تست و درصد آزمون است", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            if (!countTotalValid) Text("مجموع تست‌ها نباید بیشتر از ۲۰۰۰ باشد", color = cs.error)
            val total = correct + wrong + blank
            if (total > 0) {
                val exam = StudyReportMath.formatPercent(StudyReportMath.examPercent(correct, wrong, blank))
                val accuracy = StudyReportMath.formatPercent(StudyReportMath.accuracyPercent(correct, wrong))
                Spacer(Modifier.height(8.dp))
                /* نوار سه‌رنگ: همان عددها، ولی در یک نگاه. */
                Row(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape)) {
                    if (correct > 0) Box(Modifier.weight(correct.toFloat()).height(8.dp).background(Color(0xFF10B981)))
                    if (wrong > 0) Box(Modifier.weight(wrong.toFloat()).height(8.dp).background(Color(0xFFFB7185)))
                    if (blank > 0) Box(Modifier.weight(blank.toFloat()).height(8.dp).background(cs.outlineVariant))
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    "مجموع ${total.fa()} تست · درصد آزمون (نمره منفی یک‌سوم): $exam٪",
                    style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                )
                if (correct + wrong > 0) Text("دقت پاسخ‌های زده‌شده: $accuracy٪",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }

            Text("هر ۳ غلط، اثر یک درست را کم می‌کند؛ نزده‌ها در مجموع محاسبه می‌شوند.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)

            /* ---------- تفکیک زمان ---------- */
            Spacer(Modifier.height(14.dp))
            SectionTitle("زمان هر فعالیت (دقیقه)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumBox("🎬 ویدئو", mVideoText, Modifier.weight(1f), max = StudyReportMath.MAX_MINUTES) { mVideoText = it }
                NumBox("✍️ تست", mTestText, Modifier.weight(1f), max = StudyReportMath.MAX_MINUTES) { mTestText = it }
                NumBox("📗 کتاب", mBookText, Modifier.weight(1f), max = StudyReportMath.MAX_MINUTES) { mBookText = it }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumBox("🔁 مرور", mReviewText, Modifier.weight(1f), max = StudyReportMath.MAX_MINUTES) { mReviewText = it }
                NumBox("🧠 یادگیری", mLearnText, Modifier.weight(1f), max = StudyReportMath.MAX_MINUTES) { mLearnText = it }
                Spacer(Modifier.weight(1f))
            }
            if (spent > 0) {
                Spacer(Modifier.height(8.dp))
                val over = spent > minutes
                Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(cs.surfaceVariant)) {
                    Box(
                        Modifier.fillMaxWidth((spent.toFloat() / minutes.coerceAtLeast(1)).coerceIn(0f, 1f))
                            .height(8.dp).clip(CircleShape)
                            .background(if (over) cs.error else cs.primary),
                    )
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    if (over) "مجموع فعالیت‌ها (${spent.fa()}) از کل زمان بیشتر است"
                    else "${spent.fa()} از ${minutes.fa()} دقیقه تفکیک شد",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (over) cs.error else cs.onSurfaceVariant,
                )
            }

            /* ---------- تمرکز ---------- */
            Spacer(Modifier.height(14.dp))
            SectionTitle("میزان تمرکز")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                focusLevels.forEach { (value, emoji) ->
                    val on = focus == value
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surfaceVariant.copy(alpha = 0.3f))
                            .border(
                                1.dp,
                                if (on) cs.primary else Color.Transparent,
                                RoundedCornerShape(16.dp),
                            )
                            .clickable { focus = value }
                            .padding(vertical = 9.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(emoji, fontSize = 20.sp)
                        Text(
                            value.fa() + "٪",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (on) cs.primary else cs.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = note,
                onValueChange = { if (it.length <= 120) note = it },
                label = { Text("یادداشت کوتاه (اختیاری)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (!valid || course <= 0) return@Button
                    val d = build()
                    StudyRecent.push(ctx, course, d)
                    onConfirm(course, d)
                },
                enabled = course > 0 && valid,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Text(confirmText, fontWeight = FontWeight.Bold) }
            if (onQuick != null) {
                TextButton(
                    onClick = { onQuick(course) },
                    enabled = course > 0,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("ثبت سریع بدون جزئیات") }
            }
        }
    }
}

/** پنج حالت تمرکز؛ انتخاب یک شکلک از کشیدن اسلایدر سریع‌تر است. */
private val focusLevels = listOf(
    100 to "🔥", 85 to "🙂", 65 to "😐", 45 to "🥱", 25 to "😵‍💫",
)

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Black,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(bottom = 6.dp),
    )
}

/** قرصِ انتخاب (درس یا سرفصلِ اخیر). */
@Composable
private fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(CircleShape)
            .background(if (selected) cs.primary else cs.surfaceVariant.copy(alpha = 0.4f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) cs.onPrimary else cs.onSurface,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}

/** نتیجهٔ جست‌وجو: مسیر کامل در یک ردیف. */
@Composable
private fun FlatTopicRow(path: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        path,
        style = MaterialTheme.typography.bodySmall,
        color = if (selected) cs.primary else cs.onSurface,
        maxLines = 2, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) cs.primary.copy(alpha = 0.16f) else cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
    )
}

/** صاف کردن درخت سرفصل‌ها برای جست‌وجو. */
private fun flatten(list: List<CourseTopic>, parent: String = ""): List<Pair<CourseTopic, String>> =
    list.flatMap { t ->
        val path = if (parent.isEmpty()) t.title else "$parent › ${t.title}"
        listOf(t to path) + flatten(t.children, path)
    }

/** ردیف انتخاب سرفصل با باز/بسته شدن زیرشاخه‌ها. */
@Composable
private fun TopicPickRow(
    topic: CourseTopic,
    selectedId: Int,
    parentPath: String = "",
    onSelect: (CourseTopic, String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var open by remember(topic.id) { mutableStateOf(false) }
    val path = if (parentPath.isEmpty()) topic.title else "$parentPath › ${topic.title}"
    val selected = topic.id == selectedId
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = (topic.level * 14).dp, top = 3.dp, bottom = 3.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) cs.primary.copy(alpha = 0.16f) else cs.surfaceVariant.copy(alpha = 0.28f))
                .clickable { onSelect(topic, path) }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                topic.title,
                style = if (topic.level == 0) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodySmall,
                fontWeight = if (topic.level == 0) FontWeight.Bold else FontWeight.Normal,
                color = if (selected) cs.primary else cs.onSurface,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (topic.children.isNotEmpty()) {
                Icon(
                    if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = null,
                    tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(20.dp).clip(CircleShape).clickable { open = !open },
                )
            }
        }
        if (open) topic.children.forEach { child -> TopicPickRow(child, selectedId, path, onSelect) }
    }
}

/** A controlled text field: empty stays empty, invalid ranges are visible and block submission. */
@Composable
private fun NumBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    max: Int = StudyReportMath.MAX_QUESTIONS,
    tint: Color = Color.Unspecified,
    onChange: (String) -> Unit,
) {
    val valid = StudyNumberInput.parse(value, max) != null
    OutlinedTextField(
        value = value,
        onValueChange = { raw -> StudyNumberInput.normalize(raw)?.let(onChange) },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        placeholder = { Text("۰") },
        singleLine = true,
        isError = !valid,
        supportingText = if (!valid) ({ Text("۰ تا ${max.fa()}") }) else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        textStyle = MaterialTheme.typography.bodyLarge.copy(
            color = if (tint == Color.Unspecified) MaterialTheme.colorScheme.onSurface else tint,
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier,
    )
}
