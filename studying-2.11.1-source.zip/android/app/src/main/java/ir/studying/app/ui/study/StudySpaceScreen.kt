@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.study

import ir.studying.app.R
import androidx.compose.ui.res.stringResource
import ir.studying.app.ui.components.AppSnack
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Api
import ir.studying.app.core.Store
import ir.studying.app.core.fa
import ir.studying.app.data.MusicTrack
import ir.studying.app.data.Playlist
import ir.studying.app.player.AmbientMixer
import ir.studying.app.player.Chrono
import ir.studying.app.player.PlayerHolder
import ir.studying.app.player.Pomodoro
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/* رنگ‌های فضای تمرکز — هماهنگ با پالت «شب مطالعه» */
private val FocusBg = Brush.verticalGradient(listOf(Color(0xFF0B100E), Color(0xFF12241C), Color(0xFF0A121A)))
private val FocusMint = Color(0xFF4ADE9F)
private val FocusCyan = Color(0xFF38BDF8)
private val FocusInk = Color(0xFF06110C)
private val FocusGrad = Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF38BDF8)))

@Composable
fun StudySpaceDialog(onClose: () -> Unit, vm: StudyViewModel = viewModel()) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)) {
        StudySpaceContent(onClose, vm)
    }
}

@Composable
private fun StudySpaceContent(onClose: () -> Unit, vm: StudyViewModel) {
    val ctx = LocalContext.current
    val courses by vm.courses.collectAsState()
    val selectedCourse by vm.selectedCourse.collectAsState()
    val soundStates by AmbientMixer.states.collectAsState()
    val activeCount by AmbientMixer.activeCount.collectAsState()

    var mode by remember { mutableStateOf(if (Pomodoro.state.value.running || Pomodoro.state.value.phase != Pomodoro.Phase.IDLE) 1 else Store.prefs.value.lastStudyMode) } // 0=chrono 1=pomodoro
    var showMusic by remember { mutableStateOf(false) }
    var showTasks by remember { mutableStateOf(false) }
    /* پارتی که منتظر ثبت است: (دقیقه، منبع). با پر شدنش شیت جزئیات باز می‌شود. */
    var showManual by remember { mutableStateOf(false) }
    var pendingLog by remember { mutableStateOf<Pair<Int, ir.studying.app.core.Offline.Source>?>(null) }

    Box(Modifier.fillMaxSize().background(FocusBg)) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "بستن", tint = Color.White) }
                    Spacer(Modifier.weight(1f))
                    Text(stringResource(R.string.home_screen_001), color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.weight(1f))
                    val focusSession by ir.studying.app.focus.FocusLock.session.collectAsState()
                    val focusCfg by ir.studying.app.focus.FocusLock.config.collectAsState()
                    val missing = ir.studying.app.focus.PermState.current(ctx).missingFor(focusCfg.mode).isNotEmpty()
                    Box {
                        IconButton(onClick = {
                            onClose()
                            ir.studying.app.core.NavBus.requestRoute("focus_settings")
                        }) { Icon(Icons.Rounded.Lock, "قفل تمرکز", tint = Color.White) }
                        if (focusSession != null || missing) {
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(9.dp).size(9.dp)
                                    .background(if (focusSession != null) FocusMint else Color(0xFFF59E0B), CircleShape),
                            )
                        }
                    }
                    /* تسک‌ها همان‌جا که مطالعه می‌شود، بدون خروج از فضای تمرکز. */
                    IconButton(onClick = { showTasks = true }) {
                        Icon(Icons.Rounded.TaskAlt, "کارهای امروز", tint = Color.White)
                    }
                    IconButton(onClick = { showMusic = true }) { Icon(Icons.Rounded.LibraryMusic, "موسیقی", tint = Color.White) }
                }
            }

            // mode toggle
            item {
                Spacer(Modifier.height(8.dp))
                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.07f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.09f))) {
                    Row(Modifier.padding(4.dp)) {
                        SegBtn("کرنومتر", mode == 0) { mode = 0; Store.setLastStudyMode(0) }
                        SegBtn("پومودورو", mode == 1) { mode = 1; Store.setLastStudyMode(1) }
                    }
                }
            }

            /* تسکِ فعال: اگر کاربر از صفحهٔ تسک‌ها «شروع مطالعه» زده باشد،
               اینجا دیده می‌شود و دقیقه‌های ثبت‌شده روی همان تسک می‌نشیند.
               طراحی‌اش عمداً «زنده» است (نقطهٔ نبض‌دار + گرادیان) تا یادت نرود
               تایمر به یک کار مشخص وصل است. */
            item {
                val focusTask by ir.studying.app.core.TaskFocus.title.collectAsState()
                androidx.compose.animation.AnimatedVisibility(
                    visible = focusTask.isNotBlank(),
                    enter = androidx.compose.animation.expandVertically(tween(300)) + androidx.compose.animation.fadeIn(tween(240)),
                    exit = androidx.compose.animation.shrinkVertically(tween(200)) + androidx.compose.animation.fadeOut(tween(140)),
                ) {
                    val cs = MaterialTheme.colorScheme
                    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "focusTask")
                    val pulse by t.animateFloat(
                        initialValue = 0.55f, targetValue = 1f,
                        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                            tween(1100, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                            androidx.compose.animation.core.RepeatMode.Reverse,
                        ),
                        label = "focusPulse",
                    )
                    Column {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(cs.primary.copy(alpha = 0.22f), cs.tertiary.copy(alpha = 0.10f)),
                                    ),
                                )
                                .border(1.dp, cs.primary.copy(alpha = 0.30f), RoundedCornerShape(18.dp))
                                .padding(horizontal = 13.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier
                                    .size(9.dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(cs.primary.copy(alpha = pulse)),
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "در حال کار روی این تسک",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = cs.onSurfaceVariant,
                                )
                                Text(
                                    focusTask,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = cs.primary,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                )
                            }
                            Text(
                                "پایان",
                                style = MaterialTheme.typography.labelMedium,
                                color = cs.error,
                                modifier = Modifier
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .clickable { ir.studying.app.core.TaskFocus.clear() }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                            )
                        }
                    }
                }
            }

            /*
             * انتخاب درس از بالای کرنومتر برداشته شد.
             *
             * چرا: آدم قبل از شروع خواندن لزوماً نمی‌داند دقیقاً چه چیزی
             * می‌خواند، و این یک مانع اضافه سر راه زدنِ دکمهٔ شروع بود. درس
             * حالا در همان شیت ثبت — یعنی وقتی واقعاً معلوم است — انتخاب می‌شود.
             */
            item {
                if (courses.isEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text(stringResource(R.string.study_space_screen_001), color = Color(0xFFFB7185), style = MaterialTheme.typography.bodySmall)
                }
            }

            item {
                Spacer(Modifier.height(20.dp))
                if (mode == 0) ChronoPanel(courses.isNotEmpty()) { mins ->
                    pendingLog = mins to ir.studying.app.core.Offline.Source.CHRONO
                } else PomodoroPanel(vm, courses.isNotEmpty()) { mins ->
                    pendingLog = mins to ir.studying.app.core.Offline.Source.POMODORO
                }
            }

            /* Parts that are studied but not yet on the server live here. */
            item {
                Spacer(Modifier.height(14.dp))
                OfflinePartsCard(courses)
                androidx.compose.material3.TextButton(
                    onClick = { showManual = true },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("ثبت دستی زمان و گزارش مطالعه") }
            }

            // ambient
            item {
                Spacer(Modifier.height(26.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.study_space_screen_002), color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.weight(1f))
                    AnimatedVisibility(activeCount > 0) {
                        Text("قطع همه (${activeCount.fa()})", color = Color(0xFFFB7185),
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFFB7185).copy(alpha = 0.14f))
                                .clickable { AmbientMixer.stopAll() }.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            items(AmbientMixer.sounds.chunked(2), key = { row -> row.joinToString("|") { it.key } }) { rowSounds ->
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    rowSounds.forEach { snd ->
                        val st = soundStates[snd.key] ?: AmbientMixer.SoundState()
                        SoundCard(snd.emoji, snd.label, st.active, st.volume, Modifier.weight(1f),
                            { AmbientMixer.toggle(ctx, snd.key) }, { AmbientMixer.setVolume(snd.key, it) })
                    }
                    if (rowSounds.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item { Spacer(Modifier.height(30.dp)) }
        }

        /* لایهٔ تسک‌ها داخل همین پنجره می‌نشیند (نه Dialog تازه) تا کیبورد
           فوکوس بگیرد؛ وگرنه کادر «کار تازه» تایپ را قبول نمی‌کند. */
        if (showTasks) StudyTasksPopup(onDismiss = { showTasks = false })
    }

    if (showMusic) MusicPickerSheet(onDismiss = { showMusic = false })

    if (showManual) ManualStudyDialog(
        onDismiss = { showManual = false },
        onContinue = { mins ->
            showManual = false
            pendingLog = mins to ir.studying.app.core.Offline.Source.MANUAL
        },
    )

    pendingLog?.let { (mins, src) ->
        val cid = selectedCourse ?: courses.firstOrNull()?.id ?: 0
        StudyDetailSheet(
            courseId = cid,
            minutes = mins,
            courses = courses,
            confirmText = "ثبت " + mins.fa() + " دقیقه",
            onQuick = { chosen ->
                pendingLog = null
                vm.selectCourse(chosen)
                vm.log(mins, src) { err -> AppSnack.show(err ?: "ثبت شد 🎉 (" + mins.fa() + " دقیقه)") }
            },
            onDismiss = { pendingLog = null },
            onConfirm = { chosen, detail ->
                pendingLog = null
                vm.selectCourse(chosen)
                vm.log(mins, src, detail) { err -> AppSnack.show(err ?: "ثبت شد 🎉 (" + mins.fa() + " دقیقه)") }
            },
        )
    }
}

@Composable
private fun ChronoPanel(hasCourse: Boolean, onLog: (Int) -> Unit) {
    var elapsed by remember { mutableLongStateOf(0L) }
    var running by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { elapsed = Chrono.elapsedMs(); running = Chrono.running; delay(400) } }
    val sec = elapsed / 1000
    val minutes = (sec / 60).toInt()

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        TimerRing(progress = (sec % 60) / 60f, running = running, ringA = FocusMint, ringB = FocusCyan) {
            Text(clockHms(sec), color = Color.White, fontWeight = FontWeight.Black, fontSize = 44.sp, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(
                if (running) "در حال مطالعه…"
                else if (sec > 0) "متوقف شده"
                else "آمادهٔ شروع",
                color = if (running) FocusMint else Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodySmall,
            )
            if (minutes > 0) {
                Spacer(Modifier.height(7.dp))
                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.10f)) {
                    Text(
                        minutes.fa() + " دقیقهٔ قابل ثبت",
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleCtl(Icons.Filled.Refresh, "ریست", 54.dp, Color.White.copy(alpha = 0.10f), Color.White) { Chrono.reset() }
            GradCtl(if (running) Icons.Filled.Pause else Icons.Filled.PlayArrow, "شروع", 82.dp, running) {
                if (running) Chrono.pause() else Chrono.start()
            }
            Spacer(Modifier.size(54.dp))
        }
        Spacer(Modifier.height(20.dp))
        LogButton(
            enabled = hasCourse && sec >= 60,
            text = "ثبت مطالعه (" + minutes.fa() + " دقیقه)",
        ) {
            Chrono.pause()
            onLog(minutes)
        }
        if (!hasCourse) Text(stringResource(R.string.study_space_screen_003),
            color = Color(0xFFFBBF24), style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

@Composable
private fun PomodoroPanel(vm: StudyViewModel, hasCourse: Boolean, onLog: (Int) -> Unit) {
    val ctx = LocalContext.current
    val pomo by Pomodoro.state.collectAsState()
    val pending by vm.pendingMinutes.collectAsState()
    val phaseTotal = when (pomo.phase) {
        Pomodoro.Phase.WORK, Pomodoro.Phase.IDLE -> pomo.config.workMin * 60
        Pomodoro.Phase.BREAK -> pomo.config.breakMin * 60
        Pomodoro.Phase.LONG_BREAK -> pomo.config.longBreakMin * 60
    }.coerceAtLeast(1)
    val progress = 1f - pomo.remainingSec.toFloat() / phaseTotal
    val isBreak = pomo.phase == Pomodoro.Phase.BREAK || pomo.phase == Pomodoro.Phase.LONG_BREAK
    val ringA = if (isBreak) FocusCyan else FocusMint
    val ringB = if (isBreak) Color(0xFF818CF8) else FocusCyan
    val phaseLabel = when (pomo.phase) {
        Pomodoro.Phase.WORK -> "تمرکز"
        Pomodoro.Phase.BREAK -> "استراحت کوتاه"
        Pomodoro.Phase.LONG_BREAK -> "استراحت بلند"
        Pomodoro.Phase.IDLE -> "آمادهٔ تمرکز"
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        TimerRing(progress = progress.coerceIn(0f, 1f), running = pomo.running, ringA = ringA, ringB = ringB) {
            Surface(shape = CircleShape, color = ringA.copy(alpha = 0.16f)) {
                Text(
                    phaseLabel, color = ringA, style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 4.dp),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(clockMs(pomo.remainingSec), color = Color.White, fontWeight = FontWeight.Black, fontSize = 50.sp, maxLines = 1)
            Spacer(Modifier.height(6.dp))
            CycleDots(pomo.completedWork)
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleCtl(Icons.Filled.Refresh, "ریست", 54.dp, Color.White.copy(alpha = 0.10f), Color.White) { Pomodoro.reset() }
            GradCtl(if (pomo.running) Icons.Filled.Pause else Icons.Filled.PlayArrow, "شروع", 82.dp, pomo.running) {
                if (pomo.running) Pomodoro.pause() else Pomodoro.start(ctx)
            }
            CircleCtl(Icons.Filled.SkipNext, "بعدی", 54.dp, Color.White.copy(alpha = 0.10f), Color.White) {
                // رد کردن دیگر وقتِ خوانده‌شده را دور نمی‌ریزد؛ همان‌جا می‌گوییم چقدر ماند.
                val kept = Pomodoro.skip(ctx)
                if (kept > 0) AppSnack.show(kept.fa() + " دقیقهٔ خوانده‌شده حفظ شد")
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PresetChip("۲۵ / ۵", pomo.config.workMin == 25) { Pomodoro.setConfig(Pomodoro.Config(25, 5)) }
            PresetChip("۵۰ / ۱۰", pomo.config.workMin == 50) { Pomodoro.setConfig(Pomodoro.Config(50, 10)) }
            PresetChip("۹۰ / ۲۰", pomo.config.workMin == 90) { Pomodoro.setConfig(Pomodoro.Config(90, 20, 30)) }
        }
        Spacer(Modifier.height(18.dp))
        val partial = if (pomo.phase == Pomodoro.Phase.WORK) ((pomo.config.workMin * 60 - pomo.remainingSec) / 60).coerceAtLeast(0) else 0
        val loggable = pending + partial
        Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.07f)) {
            Text(stringResource(R.string.study_space_screen_004) + loggable.fa() + " دقیقه",
                color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        LogButton(
            enabled = hasCourse && loggable >= 1,
            text = "ثبت مطالعه تا اینجا (" + loggable.fa() + " دقیقه)",
        ) {
            /* پیش از ثبت، شیت جزئیات باز می‌شود؛ کاربر می‌تواند «ثبت سریع» بزند. */
            onLog(loggable)
        }
        if (!hasCourse) Text(stringResource(R.string.study_space_screen_003),
            color = Color(0xFFFBBF24), style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

@Composable
private fun MusicPickerSheet(onDismiss: () -> Unit) {
    var tracks by remember { mutableStateOf<List<MusicTrack>>(emptyList()) }
    var playlists by remember { mutableStateOf<List<Playlist>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var showFull by remember { mutableStateOf(false) } // پخش‌کننده تمام‌صفحه از داخل همین شیت
    LaunchedEffect(Unit) {
        runCatching { MusicTrack.list(Api.arr(Api.get("music_list", "sort" to "newest"))) }.onSuccess { tracks = it }
        runCatching { Playlist.list(Api.arr(Api.get("playlist_list"))) }.onSuccess { playlists = it }
        loading = false
    }
    val scope = rememberCoroutineScope()
    val currentId by ir.studying.app.player.PlayerHolder.currentId.collectAsState()
    val playing by ir.studying.app.player.PlayerHolder.isPlaying.collectAsState()
    val cs = MaterialTheme.colorScheme

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(Modifier.fillMaxWidth()) {
            /* سربرگ: موج زنده + عنوان، به‌جای یک تیتر خشک */
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(cs.primary.copy(alpha = 0.22f), cs.tertiary.copy(alpha = 0.10f)),
                        ),
                    )
                    .padding(horizontal = 16.dp, vertical = 14.dp),
            ) {
                Column {
                    Text(
                        "موزیک مطالعه",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                    )
                    Text(
                        "یک پلی‌لیست بگذار و برو تو کار",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(6.dp))
                    ir.studying.app.ui.library.WaveLine(
                        color = cs.primary,
                        playing = playing,
                        modifier = Modifier.fillMaxWidth().height(22.dp),
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Box(Modifier.padding(horizontal = 16.dp)) {
                ir.studying.app.ui.library.NowPlayingBanner(onOpen = { showFull = true })
            }

            Spacer(Modifier.height(10.dp))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ir.studying.app.ui.library.MusicChip("آهنگ‌ها · " + tracks.size.fa(), tab == 0, cs.primary) { tab = 0 }
                ir.studying.app.ui.library.MusicChip("پلی‌لیست‌ها · " + playlists.size.fa(), tab == 1, cs.tertiary) { tab = 1 }
            }

            Spacer(Modifier.height(8.dp))
            LazyColumn(
                Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 30.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (loading) {
                    item { ir.studying.app.ui.components.LoadingBox(height = 120.dp) }
                } else if (tab == 0) {
                    if (tracks.isEmpty()) {
                        item {
                            Text(
                                "هنوز آهنگی نیست — از کتابخانه آپلود کن",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            )
                        }
                    }
                    items(tracks, key = { "tr-" + it.id }) { t ->
                        val active = t.id == currentId
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    if (active) cs.primary.copy(alpha = 0.13f)
                                    else cs.surfaceVariant.copy(alpha = 0.34f),
                                )
                                .clickable { PlayerHolder.play(tracks, tracks.indexOfFirst { it.id == t.id }) }
                                .padding(9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ir.studying.app.ui.library.TrackCover(t, 46.dp, corner = 14.dp)
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    t.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                    color = if (active) cs.primary else cs.onSurface,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    t.artist.ifBlank { t.username },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (active) {
                                ir.studying.app.ui.library.Equalizer(
                                    playing = playing, color = cs.primary,
                                    modifier = Modifier.size(15.dp, 14.dp),
                                )
                            } else {
                                Icon(Icons.Rounded.PlayArrow, null, tint = cs.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                } else {
                    if (playlists.isEmpty()) {
                        item {
                            Text(
                                "پلی‌لیستی نساخته‌ای",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            )
                        }
                    }
                    items(playlists, key = { "pl-" + it.id }) { p ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(cs.surfaceVariant.copy(alpha = 0.34f))
                                .clickable {
                                    scope.launch {
                                        runCatching { MusicTrack.list(Api.arr(Api.get("playlist_music", "playlist_id" to p.id.toString()))) }
                                            .onSuccess { if (it.isNotEmpty()) PlayerHolder.play(it, 0) }
                                    }
                                    onDismiss()
                                }
                                .padding(11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Brush.linearGradient(listOf(cs.tertiary, cs.primary))),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Rounded.LibraryMusic, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1)
                                Text(
                                    "${p.musicCount.fa()} آهنگ",
                                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                                )
                            }
                            Icon(Icons.Rounded.PlayArrow, null, tint = cs.tertiary, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
    if (showFull) {
        ir.studying.app.ui.library.FullPlayerSheet(onDismiss = { showFull = false })
    }
}

/* ---------- small helpers ---------- */

private fun clockHms(totalSec: Long): String {
    val h = totalSec / 3600; val m = (totalSec % 3600) / 60; val s = totalSec % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s).fa()
}
private fun clockMs(totalSec: Int): String = String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60).fa()

@Composable
private fun SegBtn(text: String, selected: Boolean, onClick: () -> Unit) {
    val scale by animateFloatAsState(
        if (selected) 1f else 0.96f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "seg",
    )
    Surface(shape = CircleShape, color = Color.Transparent, onClick = onClick, modifier = Modifier.scale(scale)) {
        Box(
            Modifier
                .clip(CircleShape)
                .background(if (selected) FocusGrad else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.06f)))),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text,
                color = if (selected) FocusInk else Color.White.copy(alpha = 0.72f),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 26.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
private fun CourseChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(shape = CircleShape, color = Color.Transparent, onClick = onClick,
        border = if (!selected) androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)) else null) {
        Box(Modifier.clip(CircleShape).background(if (selected) FocusGrad else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.08f))))) {
            Text(text, color = if (selected) FocusInk else Color.White, style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PresetChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val scale by animateFloatAsState(
        if (selected) 1.05f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "preset",
    )
    Surface(
        shape = CircleShape,
        color = if (selected) FocusMint.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.06f),
        border = BorderStroke(1.dp, if (selected) FocusMint else Color.White.copy(alpha = 0.12f)),
        onClick = onClick,
        modifier = Modifier.scale(scale),
    ) {
        Text(
            text,
            color = if (selected) FocusMint else Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}

/**
 * The button the whole screen exists for.
 *
 * It used to be a flat gradient box with no reaction to touch at all. Now, while
 * it is armed, a light sweep travels across it so the eye is pulled there the
 * moment enough minutes have accumulated; pressing springs it inward with a
 * haptic tick, and the drop shadow fades in and out with the enabled state.
 */
@Composable
private fun LogButton(enabled: Boolean, text: String, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed && enabled) 0.96f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "logScale",
    )
    val glow by animateFloatAsState(if (enabled) 1f else 0f, tween(400), label = "logGlow")
    val inf = rememberInfiniteTransition(label = "logShine")
    val shine by inf.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart),
        label = "shine",
    )

    Surface(
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            onClick()
        },
        enabled = enabled,
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        shadowElevation = (14f * glow).dp,
        interactionSource = interaction,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
            .scale(scale),
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(
                    if (enabled) FocusGrad
                    else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.07f)))
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (enabled) {
                Box(
                    Modifier
                        .matchParentSize()
                        .graphicsLayer { translationX = shine * size.width }
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.30f), Color.Transparent)
                            )
                        )
                )
            }
            Text(
                text,
                color = if (enabled) FocusInk else Color.White.copy(alpha = 0.32f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 16.dp, horizontal = 18.dp),
            )
        }
    }
}

@Composable
private fun CircleCtl(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, size: androidx.compose.ui.unit.Dp, bg: Color, fg: Color, onClick: () -> Unit) {
    Surface(shape = CircleShape, color = bg, onClick = onClick, modifier = Modifier.size(size)) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, desc, tint = fg, modifier = Modifier.size(size * 0.42f)) }
    }
}

/** دکمهٔ اصلی گرادیانی تایمر (پخش/توقف). */
@Composable
private fun GradCtl(icon: ImageVector, desc: String, box: Dp, active: Boolean = false, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.90f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "ctlScale",
    )
    val inf = rememberInfiniteTransition(label = "ctlHalo")
    val halo by inf.animateFloat(
        1.04f, if (active) 1.26f else 1.04f,
        infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "halo",
    )

    Box(contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(box * halo)
                .background(FocusMint.copy(alpha = if (active) 0.18f else 0.07f), CircleShape)
        )
        Surface(
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
            shape = CircleShape,
            color = Color.Transparent,
            shadowElevation = 12.dp,
            interactionSource = interaction,
            modifier = Modifier.size(box).scale(scale),
        ) {
            Box(Modifier.background(FocusGrad), contentAlignment = Alignment.Center) {
                Icon(icon, desc, tint = FocusInk, modifier = Modifier.size(box * 0.46f))
            }
        }
    }
}

@Composable
private fun SoundCard(emoji: String, label: String, active: Boolean, volume: Float, modifier: Modifier = Modifier, onToggle: () -> Unit, onVolume: (Float) -> Unit) {
    Surface(modifier = modifier, shape = RoundedCornerShape(22.dp),
        color = if (active) FocusMint.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.05f),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) FocusMint.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.08f)),
        onClick = onToggle) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.height(6.dp))
            Text(label, color = if (active) Color.White else Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelLarge)
            AnimatedVisibility(active) {
                Slider(value = volume, onValueChange = onVolume, modifier = Modifier.height(28.dp),
                    colors = SliderDefaults.colors(thumbColor = FocusMint, activeTrackColor = FocusMint, inactiveTrackColor = Color.White.copy(alpha = 0.2f)))
            }
        }
    }
}

/**
 * Shared timer face for the chronometer and the pomodoro.
 *
 * Replaces the flat single stroke circle both panels used to draw: a soft halo
 * that brightens while the timer runs, a minute dial of sixty ticks, a dim
 * track, and a sweep gradient progress arc. The whole face breathes slowly
 * while running, which reads as "alive" without being distracting.
 */
@Composable
private fun TimerRing(
    progress: Float,
    running: Boolean,
    ringA: Color,
    ringB: Color,
    content: @Composable ColumnScope.() -> Unit,
) {
    val inf = rememberInfiniteTransition(label = "ring")
    val breath by inf.animateFloat(
        1f, if (running) 1.03f else 1f,
        infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breath",
    )
    val shown by animateFloatAsState(progress.coerceIn(0f, 1f), tween(500), label = "ringProgress")
    val haloAlpha by animateFloatAsState(if (running) 0.22f else 0.07f, tween(700), label = "halo")

    Box(
        modifier = Modifier.size(264.dp).scale(breath),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(264.dp)
                .background(Brush.radialGradient(listOf(ringA.copy(alpha = haloAlpha), Color.Transparent)), CircleShape)
        )
        Canvas(Modifier.size(232.dp)) {
            val stroke = 16.dp.toPx()
            val d = size.minDimension - stroke * 2.6f
            val tl = Offset((size.width - d) / 2f, (size.height - d) / 2f)
            val cx = size.width / 2f
            val cy = size.height / 2f
            val rBase = d / 2f + stroke * 1.15f
            for (i in 0 until 60) {
                val a = Math.toRadians((i * 6).toDouble())
                val major = i % 5 == 0
                val len = if (major) stroke * 0.5f else stroke * 0.26f
                val r1 = rBase
                val r0 = r1 - len
                drawLine(
                    color = Color.White.copy(alpha = if (major) 0.22f else 0.09f),
                    start = Offset(cx + (r0 * cos(a)).toFloat(), cy + (r0 * sin(a)).toFloat()),
                    end = Offset(cx + (r1 * cos(a)).toFloat(), cy + (r1 * sin(a)).toFloat()),
                    strokeWidth = if (major) stroke * 0.15f else stroke * 0.08f,
                    cap = StrokeCap.Round,
                )
            }
            drawArc(
                color = Color.White.copy(alpha = 0.07f),
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = tl, size = Size(d, d),
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (shown > 0.001f) drawArc(
                brush = Brush.sweepGradient(listOf(ringA, ringB, ringA)),
                startAngle = -90f, sweepAngle = 360f * shown, useCenter = false,
                topLeft = tl, size = Size(d, d),
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

/** Four dots showing where in the current pomodoro set the user is. */
@Composable
private fun CycleDots(done: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until 4) {
            val filled = if (done > 0 && done % 4 == 0) true else (done % 4) > i
            val a by animateFloatAsState(if (filled) 1f else 0.22f, tween(400), label = "dot")
            Box(Modifier.size(if (filled) 9.dp else 6.dp).background(FocusMint.copy(alpha = a), CircleShape))
        }
        Spacer(Modifier.width(6.dp))
        Text(stringResource(R.string.study_space_screen_007) + done.fa(),
            color = Color.White.copy(alpha = 0.6f),
            style = MaterialTheme.typography.labelSmall,
        )
    }
}


/**
 * The offline pocket: every part that could not reach the server, listed with
 * its course and length so the user can see exactly what is waiting, drop a
 * part that was a mistake, and push everything with one tap once the phone is
 * back online. Without this the queue was invisible and the user had no reason
 * to trust it, which is why the save button was tapped again and again.
 */
@Composable
private fun OfflinePartsCard(courses: List<ir.studying.app.data.Course>) {
    val scope = rememberCoroutineScope()
    val parts by ir.studying.app.core.Offline.parts.collectAsState()
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { ir.studying.app.core.Offline.refresh() }

    androidx.compose.animation.AnimatedVisibility(visible = parts.isNotEmpty()) {
        Surface(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            color = FocusMint.copy(alpha = 0.10f),
            border = androidx.compose.foundation.BorderStroke(1.dp, FocusMint.copy(alpha = 0.22f)),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "پارت‌های ذخیره‌شده",
                        color = Color.White, style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(shape = CircleShape, color = FocusMint) {
                        Text(
                            parts.size.fa(), color = FocusInk,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        parts.sumOf { it.minutes }.fa() + " دقیقه",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                Spacer(Modifier.height(10.dp))
                parts.forEach { p ->
                    val name = courses.firstOrNull { it.id == p.courseId }?.name
                        ?: "بدون درس"
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    ) {
                        Surface(
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.08f),
                        ) {
                            Text(
                                p.minutes.fa(), color = FocusMint,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (p.rejected) "$name — نیاز به بررسی" else name), color = Color.White.copy(alpha = 0.88f),
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                            )
                            ir.studying.app.data.StudyDetail.parse(p.detail)?.let { detail ->
                                val summary = buildList {
                                    if (detail.qTotal > 0) add("${detail.qTotal.fa()} تست · آزمون: ${ir.studying.app.core.StudyReportMath.formatPercent(detail.examPercent)}٪")
                                    if (detail.qDescriptive > 0) add("${detail.qDescriptive.fa()} تشریحی")
                                }.joinToString(" · ")
                                if (summary.isNotEmpty()) Text(summary,
                                    style = MaterialTheme.typography.labelSmall, color = FocusMint)
                            }
                        }
                        IconButton(onClick = {
                            scope.launch { ir.studying.app.core.Offline.remove(p.id) }
                        }) {
                            Icon(
                                Icons.Filled.Close,
                                "حذف",
                                tint = Color.White.copy(alpha = 0.55f),
                                modifier = Modifier.size(17.dp),
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                LogButton(
                    enabled = !busy,
                    text = if (busy) "دارم می‌فرستم…"
                    else "ارسال همه (" + parts.size.fa() + " پارت)",
                ) {
                    if (!busy) {
                        busy = true
                        scope.launch {
                            try {
                                val sent = ir.studying.app.core.Offline.flush(retryRejected = true)
                                AppSnack.show(if (sent > 0) sent.fa() + " پارت ثبت شد ✅"
                                    else "هنوز ارسال نشد؛ پارت‌ها روی دستگاه محفوظ‌اند")
                            } finally { busy = false }
                        }
                    }
                }
            }
        }
    }
}
