@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.study

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.IranTime
import ir.studying.app.core.fa
import ir.studying.app.data.TaskItem
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.tasks.TasksViewModel

/**
 * تسک‌های امروز، داخل فضای مطالعه.
 *
 * چرا اینجا: تسک‌ها یک تب دیگر در ته اپ بودند، در حالی که لحظه‌ای که آدم به
 * لیست کارهایش نگاه می‌کند دقیقاً وسط مطالعه است. برای بستن پارت باید از فضای
 * مطالعه بیرون می‌آمد و همان بیرون‌آمدن، تمرکز را می‌شکست.
 *
 * پاپ‌آپ است نه صفحه: با فنر باز و بسته می‌شود، پس‌زمینهٔ مطالعه محو می‌ماند و
 * تایمر پشتش هیچ‌وقت از بین نمی‌رود. تیک‌زدن، ویرایش عنوان، افزودن و حذف همه
 * همان‌جا انجام می‌شود.
 *
 * چرا Dialog نیست و لایه‌ای داخل همان پنجره است: فضای مطالعه خودش یک Dialog
 * است و دیالوگِ تو‌در‌تو فوکوس کیبورد را نمی‌گیرد. نتیجه‌اش این بود که کادر
 * «کار تازه…» تایپ را قبول نمی‌کرد و افزودن تسک عملاً کار نمی‌کرد.
 */
@Composable
fun StudyTasksPopup(onDismiss: () -> Unit, vm: TasksViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val busy by vm.busy.collectAsState()
    val hidden by vm.hidden.collectAsState()
    val adding by vm.adding.collectAsState()

    /* انیمیشن ورود باید بعد از اولین فریم شروع شود، وگرنه پاپ‌آپ می‌پرد. */
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true; vm.refresh() }

    var newTitle by remember { mutableStateOf("") }

    // زیرتسک‌ها اینجا نباید مثل کار مستقل دیده شوند؛ فقط کارهای اصلی امروز.
    val tasks = state.today.filter { it.id !in hidden && it.parentId == 0 }
    val doneCount = tasks.count { it.done }

    BackHandler(enabled = true) { onDismiss() }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ),
        contentAlignment = Alignment.Center,
    ) {
            AnimatedVisibility(
                visible = shown,
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), initialScale = 0.82f) +
                    fadeIn(tween(220)),
                exit = scaleOut(tween(160), targetScale = 0.9f) + fadeOut(tween(140)),
            ) {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color(0xFF101A16),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .heightIn(max = 560.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(26.dp))
                        /*
                         * کلیک روی خود کارت نباید به پرده برسد، وگرنه پاپ‌آپ
                         * بسته می‌شود. `enabled = false` این کار را نمی‌کند —
                         * لمس را مصرف نمی‌کند — و همین باعث می‌شد ضربه به کادر
                         * «کار تازه» پاپ‌آپ را ببندد و افزودن تسک ناممکن شود.
                         */
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) {},
                ) {
                    Column(Modifier.padding(16.dp)) {

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(38.dp).clip(RoundedCornerShape(13.dp))
                                    .background(Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF38BDF8)))),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Rounded.TaskAlt, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("کارهای امروز", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(
                                    if (tasks.isEmpty()) "هنوز کاری ننوشته‌ای"
                                    else doneCount.fa() + " از " + tasks.size.fa() + " انجام شد",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 11.sp,
                                )
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Rounded.Close, "بستن", tint = Color.White.copy(alpha = 0.8f))
                            }
                        }

                        Spacer(Modifier.height(10.dp))

                        /* نوار پیشرفت: با یک نگاه معلوم است چقدر مانده. */
                        val frac = if (tasks.isEmpty()) 0f else doneCount.toFloat() / tasks.size
                        Box(
                            Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.10f)),
                        ) {
                            Box(
                                Modifier.fillMaxWidth(frac).height(6.dp).clip(CircleShape)
                                    .background(Brush.horizontalGradient(listOf(Color(0xFF10B981), Color(0xFF38BDF8)))),
                            )
                        }

                        Spacer(Modifier.height(12.dp))

                        if (state.loading && tasks.isEmpty()) {
                            Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Color(0xFF4ADE9F))
                            }
                        } else {
                            LazyColumn(
                                Modifier.weight(1f, fill = false).heightIn(max = 330.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                items(tasks, key = { it.id }) { t ->
                                    TaskRow(
                                        task = t,
                                        busy = t.id in busy,
                                        onToggle = { vm.toggle(t) },
                                        onDelete = { vm.delete(t) },
                                    )
                                }
                                if (tasks.isEmpty()) {
                                    item {
                                        Text(
                                            "یک کار کوچک برای همین حالا بنویس.",
                                            color = Color.White.copy(alpha = 0.55f),
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(vertical = 18.dp),
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newTitle,
                                onValueChange = { newTitle = it },
                                placeholder = { Text("کار تازه…", color = Color.White.copy(alpha = 0.4f)) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                /*
                                 * رنگ‌ها دستی‌اند چون این کارت همیشه تیره است،
                                 * ولی OutlinedTextField رنگ متن را از تم می‌گیرد؛
                                 * نتیجه این بود که در یکی از دو تم، متنِ تایپ‌شده
                                 * سیاهِ روی زمینهٔ سیاه می‌شد و کاربر فکر می‌کرد
                                 * چیزی تایپ نشده.
                                 */
                                textStyle = LocalTextStyle.current.copy(color = Color.White),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    disabledTextColor = Color.White.copy(alpha = 0.5f),
                                    cursorColor = Color(0xFF4ADE9F),
                                    focusedBorderColor = Color(0xFF4ADE9F),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.22f),
                                    focusedContainerColor = Color.White.copy(alpha = 0.06f),
                                    unfocusedContainerColor = Color.White.copy(alpha = 0.06f),
                                ),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = {
                                    if (newTitle.isNotBlank()) {
                                        vm.add(newTitle.trim(), IranTime.todayIso(), "normal") { err ->
                                            if (err != null) AppSnack.show(err)
                                        }
                                        newTitle = ""
                                    }
                                }),
                            )
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (newTitle.isBlank() || adding)
                                            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.10f)))
                                        else Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF38BDF8))),
                                    )
                                    .clickable(enabled = newTitle.isNotBlank() && !adding) {
                                        vm.add(newTitle.trim(), IranTime.todayIso(), "normal") { err ->
                                            if (err != null) AppSnack.show(err)
                                        }
                                        newTitle = ""
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (adding) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                                else Icon(Icons.Rounded.Add, "افزودن", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
}

/**
 * یک سطر تسک: تیک و حذف.
 *
 * ویرایش عنوان از این پاپ‌آپ برداشته شد: روی سرورهایی که هنوز به‌روز نشده‌اند
 * فیلد `title` در PUT نادیده گرفته می‌شد، پس دکمهٔ مداد ظاهراً کار می‌کرد ولی
 * عنوان برنمی‌گشت. وسط جلسهٔ مطالعه هم جای ویرایش متن نیست؛ تیک‌زدن و حذف کافی است.
 */
@Composable
private fun TaskRow(
    task: TaskItem,
    busy: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (task.done) Color(0xFF10B981).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.06f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(26.dp).clip(CircleShape)
                    .background(if (task.done) Color(0xFF10B981) else Color.White.copy(alpha = 0.10f))
                    .clickable(enabled = !busy, onClick = onToggle),
                contentAlignment = Alignment.Center,
            ) {
                if (busy) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(14.dp))
                else if (task.done) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text(
                task.title,
                color = if (task.done) Color.White.copy(alpha = 0.55f) else Color.White,
                fontSize = 13.sp,
                textDecoration = if (task.done) TextDecoration.LineThrough else null,
                modifier = Modifier.weight(1f).clickable(enabled = !busy, onClick = onToggle),
            )
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, "حذف", tint = Color(0xFFFB7185), modifier = Modifier.size(18.dp))
            }
        }
    }
}
