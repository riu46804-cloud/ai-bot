package ir.studying.app.ui.study

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.core.CourseCache
import ir.studying.app.core.ApiException
import ir.studying.app.core.Offline
import ir.studying.app.core.StudyPending
import ir.studying.app.core.humanizeError
import ir.studying.app.data.Course
import ir.studying.app.player.Pomodoro
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Backs the study space (chronometer + pomodoro). Course selection is REQUIRED;
 *  nothing is logged without a course. Pomodoro work blocks accumulate and are
 *  logged on demand (user can do many pomodoros then register the total). */
class StudyViewModel : ViewModel() {

    private val _courses = MutableStateFlow<List<Course>>(emptyList())
    val courses: StateFlow<List<Course>> get() = _courses

    private val _selectedCourse = MutableStateFlow<Int?>(ir.studying.app.core.Store.timer.value.courseId)
    val selectedCourse: StateFlow<Int?> get() = _selectedCourse

    /**
     * Minutes finished in Pomodoro work blocks but not yet logged. Backed by disk
     * so a process kill in the middle of a session no longer erases finished work.
     */
    val pendingMinutes: StateFlow<Int> get() = StudyPending.minutes

    init {
        loadCourses()
        viewModelScope.launch { StudyPending.load() }
        /*
         * Nothing is collected here on purpose. This collector was the only
         * thing crediting finished work blocks, so every block that ended while
         * the study screen was off-composition (user on another tab, phone in a
         * pocket) was dropped on the floor. Pomodoro now writes straight to
         * StudyPending, which is on disk and screen-independent.
         */
        /*
         * درسِ تایمر ممکن است بیرون از این صفحه عوض شود (مثلاً دستیار هوشمند
         * پومودورو را برای «ریاضی» روشن کرد). این ViewModel مال اکتیویتی است و
         * بین باز و بسته شدن فضای مطالعه زنده می‌ماند، پس باید دنبالش کند.
         */
        viewModelScope.launch {
            ir.studying.app.core.Store.timer.collect { t ->
                val id = t.courseId
                if (id != null && id != _selectedCourse.value) _selectedCourse.value = id
            }
        }
        // A course created anywhere in the app must be selectable here at once.
        viewModelScope.launch {
            ir.studying.app.core.RefreshBus.events.collect { tag ->
                if (tag == "courses" || tag == "study" || tag == "all") loadCourses()
            }
        }
    }

    /**
     * لیست درس‌ها از [CourseCache] می‌آید، نه مستقیم از شبکه.
     *
     * قبلاً بی‌اینترنت لیست خالی می‌ماند و چون ثبت پارت بدون درس ممنوع است،
     * حالت آفلاین عملاً بی‌فایده بود. حالا اول نسخهٔ روی دیسک نشان داده می‌شود
     * و بعد اگر شبکه بود تازه‌سازی می‌شود.
     */
    fun loadCourses() {
        viewModelScope.launch {
            val disk = CourseCache.peek().ifEmpty { CourseCache.cached() }
            if (disk.isNotEmpty()) apply(disk)
            apply(CourseCache.refresh())
        }
    }

    private fun apply(list: List<Course>) {
        if (list.isEmpty()) return
        _courses.value = list
        if (list.none { it.id == _selectedCourse.value }) selectCourse(list.first().id)
    }

    fun selectCourse(id: Int?) { _selectedCourse.value = id; ir.studying.app.player.Chrono.setCourse(id) }

    /** Logs [minutes] to the selected course. Returns error text or null on success. */
    fun log(
        minutes: Int,
        source: Offline.Source = Offline.Source.CHRONO,
        detail: ir.studying.app.data.StudyDetail? = null,
        onResult: (String?) -> Unit,
    ) {
        val course = _selectedCourse.value
        if (course == null) { onResult("اول یک درس انتخاب کن"); return }
        if (minutes < 1) { onResult("زمانی برای ثبت نیست"); return }
        if (logging) { onResult("در حال ثبت…"); return }
        logging = true
        try {
            // Commit before networking and before success; process death cannot create a second UID.
            val detailJson = detail?.takeIf { !it.isEmpty }?.toJson()?.toString().orEmpty()
            check(Offline.record(minutes, course, source, detail = detailJson)) { "این پارت قبلاً ذخیره شده بود" }
            ir.studying.app.notify.SyncWorker.kick(ir.studying.app.App.instance)
            /* اگر مطالعه از روی یک تسک شروع شده، همان دقیقه‌ها روی تسک هم ثبت
               می‌شود؛ بدون این، «چقدر روی این کار وقت گذاشتم» هیچ‌وقت معلوم نبود. */
            viewModelScope.launch { ir.studying.app.core.TaskFocus.credit(minutes) }
            onResult(null)
            ir.studying.app.core.RefreshBus.emit("study")
        } catch (e: Exception) {
            onResult(humanizeError(e))
        } finally {
            logging = false
        }
    }

    /** True while a save is in flight, so repeat taps cannot duplicate a part. */
    private var logging = false

    fun clearPending() { viewModelScope.launch { StudyPending.clear() } }
}
