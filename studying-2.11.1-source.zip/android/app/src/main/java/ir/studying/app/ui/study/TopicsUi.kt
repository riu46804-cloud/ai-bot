@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.studying.app.ui.study

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.studying.app.core.fa
import ir.studying.app.core.humanizeError
import ir.studying.app.data.Course
import ir.studying.app.data.CourseTopic
import ir.studying.app.data.ReadyCourse
import ir.studying.app.data.TopicStat
import ir.studying.app.data.TopicRepo
import ir.studying.app.ui.components.AppSnack
import kotlinx.coroutines.launch

/**
 * ویرایشگر جزئیات یک درس: فصل → بخش → پارت.
 *
 * چرا سه سطح: بیشتر کتاب‌های درسی همین‌قدر عمق دارند (فصل، زیربخش، جزء).
 * عنوان‌ها آزادند؛ هیچ‌جا کلمهٔ «گفتار» یا قالب ثابت تحمیل نمی‌شود.
 */
@Composable
fun CourseTopicsSheet(course: Course, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var topics by remember { mutableStateOf<List<CourseTopic>>(emptyList()) }
    var stats by remember { mutableStateOf<List<TopicStat>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var newChapter by remember { mutableStateOf("") }
    var showReady by remember { mutableStateOf(false) }
    var addUnder by remember { mutableStateOf<CourseTopic?>(null) }
    var renaming by remember { mutableStateOf<CourseTopic?>(null) }
    /* «نصب نشده» یعنی جدول‌های این بخش روی سرور ساخته نشده‌اند؛ باید دیده شود،
       نه اینکه کاربر فصل بسازد و هیچ اتفاقی نیفتد. */
    var notReady by remember { mutableStateOf(false) }

    LaunchedEffect(course.id, reload) {
        loading = true
        runCatching { TopicRepo.tree(course.id) }
            .onSuccess { topics = it.topics; stats = it.stats; notReady = it.notReady }
            .onFailure { notReady = isNotReady(it); AppSnack.show(humanizeError(it)) }
        loading = false
    }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 26.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${course.icon} ${course.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showReady = true }) {
                    Icon(Icons.Rounded.Download, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("درس‌های آماده")
                }
            }
            Text(
                "فصل‌ها و بخش‌های درس را اینجا بساز تا موقع ثبت گزارش، دقیق مشخص کنی چه چیزی خواندی.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
            if (notReady) {
                Spacer(Modifier.height(8.dp))
                SetupBanner { notReady = false; reload++ }
            }

            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newChapter,
                    onValueChange = { newChapter = it },
                    label = { Text("فصل جدید") },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        val t = newChapter.trim()
                        if (t.isEmpty()) return@Button
                        newChapter = ""
                        scope.launch {
                            runCatching { TopicRepo.save(course.id, t, parentId = 0, level = 0) }
                                .onSuccess { reload++ }
                                .onFailure { AppSnack.show(humanizeError(it)) }
                        }
                    },
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.height(52.dp),
                ) { Icon(Icons.Rounded.Add, "افزودن") }
            }

            Spacer(Modifier.height(10.dp))
            if (loading) {
                ir.studying.app.ui.components.LoadingBox(height = 120.dp)
            } else if (topics.isEmpty()) {
                Text("هنوز فصلی نساخته‌ای — یا یک درس آماده را وارد کن.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            } else {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    topics.forEach { t ->
                        TopicEditRow(
                            topic = t,
                            stats = stats,
                            onAddChild = { addUnder = it },
                            onRename = { renaming = it },
                            onDelete = { target ->
                                scope.launch {
                                    runCatching { TopicRepo.delete(target.id) }
                                        .onSuccess { reload++ }
                                        .onFailure { AppSnack.show(humanizeError(it)) }
                                }
                            },
                        )
                    }
                }
            }
        }
    }

    addUnder?.let { parent ->
        TopicNameDialog(
            title = "زیرشاخهٔ «${parent.title}»",
            initial = "",
            onDismiss = { addUnder = null },
            onSave = { name ->
                addUnder = null
                scope.launch {
                    runCatching {
                        TopicRepo.save(course.id, name, parentId = parent.id, level = (parent.level + 1).coerceAtMost(2))
                    }.onSuccess { reload++ }.onFailure { AppSnack.show(humanizeError(it)) }
                }
            },
        )
    }

    renaming?.let { t ->
        TopicNameDialog(
            title = "ویرایش عنوان",
            initial = t.title,
            onDismiss = { renaming = null },
            onSave = { name ->
                renaming = null
                scope.launch {
                    runCatching { TopicRepo.rename(course.id, t.id, name) }
                        .onSuccess { reload++ }.onFailure { AppSnack.show(humanizeError(it)) }
                }
            },
        )
    }

    if (showReady) {
        ReadyCoursesSheet(
            onDismiss = { showReady = false },
            onImported = { showReady = false; reload++; ir.studying.app.core.RefreshBus.emit("courses") },
        )
    }
}

@Composable
private fun TopicEditRow(
    topic: CourseTopic,
    stats: List<TopicStat>,
    onAddChild: (CourseTopic) -> Unit,
    onRename: (CourseTopic) -> Unit,
    onDelete: (CourseTopic) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var open by remember(topic.id) { mutableStateOf(topic.level == 0) }
    var confirmDelete by remember(topic.id) { mutableStateOf(false) }
    val st = stats.firstOrNull { it.topicId == topic.id }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = (topic.level * 14).dp, top = 3.dp, bottom = 3.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (topic.level == 0) cs.surfaceVariant.copy(alpha = 0.40f) else cs.surfaceVariant.copy(alpha = 0.18f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (topic.children.isNotEmpty()) {
                Icon(
                    if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null,
                    tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(20.dp).clip(CircleShape).clickable { open = !open },
                )
                Spacer(Modifier.width(4.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    topic.title,
                    style = if (topic.level == 0) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodySmall,
                    fontWeight = if (topic.level == 0) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                if (st != null && (st.minutes > 0 || st.qTotal > 0 || st.qDescriptive > 0)) {
                    Text(
                        buildString {
                            append("${st.minutes.fa()} دقیقه")
                            if (st.qTotal > 0) append(" · ${st.qTotal.fa()} تست · ${ir.studying.app.core.StudyReportMath.formatPercent(st.examPercent)}٪ آزمون (منفی یک‌سوم)")
                            if (st.qDescriptive > 0) append(" · ${st.qDescriptive.fa()} تشریحی")
                            st.focus?.let { append(" · تمرکز ${it.fa()}٪") }
                        },
                        style = MaterialTheme.typography.labelSmall, color = cs.primary,
                    )
                }
            }
            if (topic.level < 2) {
                Icon(
                    Icons.Rounded.Add, "زیرشاخه", tint = cs.primary,
                    modifier = Modifier.size(20.dp).clip(CircleShape).clickable { onAddChild(topic) },
                )
                Spacer(Modifier.width(6.dp))
            }
            Icon(
                Icons.Rounded.Edit, "ویرایش", tint = cs.onSurfaceVariant,
                modifier = Modifier.size(18.dp).clip(CircleShape).clickable { onRename(topic) },
            )
            Spacer(Modifier.width(6.dp))
            Icon(
                Icons.Rounded.Delete,
                if (confirmDelete) "مطمئنی؟" else "حذف",
                tint = if (confirmDelete) cs.error else cs.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(18.dp).clip(CircleShape).clickable {
                    /* دو مرحله‌ای: ضربهٔ اول هشدار، ضربهٔ دوم حذف — چون زیرشاخه‌ها هم پاک می‌شوند. */
                    if (confirmDelete) onDelete(topic) else confirmDelete = true
                },
            )
        }
        if (open) topic.children.forEach { c ->
            TopicEditRow(c, stats, onAddChild, onRename, onDelete)
        }
    }
}

@Composable
private fun TopicNameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text("عنوان") }, shape = MaterialTheme.shapes.medium,
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.trim().isNotEmpty()) onSave(text.trim()) }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بی‌خیال") } },
    )
}

/**
 * درس‌های آمادهٔ سرور. پیش‌فرض بر اساس پایه و رشتهٔ خود کاربر فیلتر می‌شود؛
 * با «همهٔ پایه‌ها» می‌شود بقیه را هم دید.
 */
@Composable
fun ReadyCoursesSheet(onDismiss: () -> Unit, onImported: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var all by remember { mutableStateOf(false) }
    var list by remember { mutableStateOf<List<ReadyCourse>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var preview by remember { mutableStateOf<ReadyCourse?>(null) }
    var previewTopics by remember { mutableStateOf<List<CourseTopic>>(emptyList()) }
    var importing by remember { mutableIntStateOf(0) }

    var notReady by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(all, reload) {
        loading = true
        runCatching { TopicRepo.ready(all) }
            .onSuccess { list = it; notReady = false }
            .onFailure { notReady = isNotReady(it); AppSnack.show(humanizeError(it)) }
        loading = false
    }
    LaunchedEffect(preview?.id) {
        val p = preview
        previewTopics = emptyList()
        if (p != null) runCatching { TopicRepo.readyDetail(p.id) }.onSuccess { previewTopics = it }
    }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 26.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("درس‌های آماده", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { all = !all }) { Text(if (all) "فقط پایهٔ من" else "همهٔ پایه‌ها") }
            }
            Text(
                "با یک ضربه، درس با همهٔ فصل‌ها و بخش‌هایش به لیست درس‌های تو اضافه می‌شود.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
            )
            if (notReady) {
                Spacer(Modifier.height(8.dp))
                SetupBanner { notReady = false; reload++ }
            }
            Spacer(Modifier.height(10.dp))
            if (loading) {
                ir.studying.app.ui.components.LoadingBox(height = 120.dp)
            } else if (list.isEmpty()) {
                Text(
                    "برای پایهٔ تو هنوز درس آماده‌ای ثبت نشده. پایه و رشته‌ات را در پروفایل کامل کن یا «همهٔ پایه‌ها» را بزن.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                )
            } else {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    list.forEach { rc ->
                        val open = preview?.id == rc.id
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                                .padding(10.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(rc.icon, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(rc.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    Text(
                                        listOfNotNull(rc.gradeLabel.ifEmpty { null }, rc.fieldLabel).joinToString(" · ") +
                                            " · ${rc.topicCount.fa()} سرفصل",
                                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                                    )
                                }
                                TextButton(onClick = { preview = if (open) null else rc }) {
                                    Text(if (open) "بستن" else "فهرست")
                                }
                                Button(
                                    onClick = {
                                        importing = rc.id
                                        scope.launch {
                                            runCatching { TopicRepo.importCourse(rc.id) }
                                                .onSuccess {
                                                    AppSnack.show("«${rc.name}» اضافه شد ✅")
                                                    importing = 0
                                                    onImported(it)
                                                }
                                                .onFailure { importing = 0; AppSnack.show(humanizeError(it)) }
                                        }
                                    },
                                    enabled = importing != rc.id,
                                    shape = MaterialTheme.shapes.medium,
                                ) { Text(if (importing == rc.id) "…" else "افزودن") }
                            }
                            if (open) {
                                Spacer(Modifier.height(6.dp))
                                previewTopics.forEach { ch ->
                                    Text(
                                        "• ${ch.title}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 4.dp),
                                    )
                                    ch.children.forEach { sec ->
                                        Text(
                                            "— ${sec.title}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = cs.onSurfaceVariant,
                                            modifier = Modifier.padding(start = 12.dp),
                                        )
                                    }
                                }
                                if (previewTopics.isEmpty()) {
                                    Text("در حال خواندن فهرست…", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        }
    }
}

/** آیا خطای سرور همان «هنوز نصب نشده» است؟ */
private fun isNotReady(e: Throwable): Boolean =
    (e.message ?: "").contains("نصب نشده") || (e.message ?: "").contains("فعال نشده")

/**
 * بنر نصب.
 *
 * چرا وجود دارد: جدول‌های «جزئیات درس‌ها» یک مهاجرت جداگانه لازم دارند و اگر
 * روی سرور اجرا نشده باشد، این بخش کاملاً بی‌اثر می‌شود — بدون هیچ پیامی.
 * حالا همان مهاجرت با یک دکمه از داخل اپ اجرا می‌شود.
 */
@Composable
private fun SetupBanner(onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cs.errorContainer)
            .padding(12.dp),
    ) {
        Text(
            "این بخش روی سرور نصب نشده",
            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black,
            color = cs.onErrorContainer,
        )
        Text(
            "جدول‌های سرفصل و درس‌های آماده هنوز ساخته نشده‌اند؛ برای همین افزودن فصل و فهرست درس‌های آماده کار نمی‌کند.",
            style = MaterialTheme.typography.labelSmall, color = cs.onErrorContainer,
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (busy) return@Button
                busy = true
                scope.launch {
                    runCatching { TopicRepo.setup() }
                        .onSuccess { ok ->
                            AppSnack.show(if (ok) "نصب شد ✅" else "نصب ناموفق بود؛ دسترسی دیتابیس را بررسی کن")
                            if (ok) onDone()
                        }
                        .onFailure { AppSnack.show(humanizeError(it)) }
                    busy = false
                }
            },
            shape = MaterialTheme.shapes.medium,
        ) { Text(if (busy) "در حال نصب…" else "نصب روی سرور") }
    }
}
