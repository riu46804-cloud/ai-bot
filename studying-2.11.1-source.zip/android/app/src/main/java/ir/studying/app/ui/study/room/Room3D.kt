package ir.studying.app.ui.study.room

import android.annotation.SuppressLint
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.HapticFeedbackConstants
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import ir.studying.app.BuildConfig
import ir.studying.app.player.Pomodoro
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

/**
 * «هفت‌خانِ تمرکز» — اتاق مطالعهٔ سه‌بعدی.
 *
 * صحنه با three.js داخل یک WebView ساخته شده و همهٔ فایل‌هایش داخل خود APK
 * است (assets/room3d)؛ هیچ آدرس اینترنتی‌ای باز نمی‌شود. منطق واقعی — تایمرها،
 * ضربان اتاق، جایزه‌ها و سکه‌ها — همان کد اپ و سرور است؛ صفحه فقط نمایش و
 * لمس را انجام می‌دهد و با پیام‌های کوچک JSON با اپ حرف می‌زند:
 *
 *  - صفحه → اپ: `AndroidR3.post(type, json)` (فقط نوع‌های [Room3DProtocol.ALLOWED])
 *  - اپ → صفحه: `R3.push(json)` با [Room3DProtocol.pushScript]
 */
internal object Room3DProtocol {
    const val ENTRY = "file:///android_asset/room3d/index.html"
    private const val ASSET_PREFIX = "file:///android_asset/room3d/"
    const val MAX_JSON = 32_000

    val ALLOWED = setOf(
        "ready", "focus_toggle", "timer_reset", "timer_skip", "log", "open", "night", "cheer",
        "claim", "chest_open", "hat", "buy", "haptic", "modal", "back_unhandled", "webgl_fail", "debug",
    )
    val SHEETS = setOf("char", "sound", "shop", "roster", "goal", "top", "theme", "classic")

    /** اسکریپتی که یک پیام را تحویل صفحه می‌دهد؛ JSON داخل یک رشتهٔ امن JS می‌رود. */
    fun pushScript(json: String): String {
        val quoted = JSONObject.quote(json)
            .replace("\u2028", "\\u2028")
            .replace("\u2029", "\\u2029")
        return "window.R3&&window.R3.push&&window.R3.push($quoted);"
    }

    /** پیام رسیده از صفحه؛ نوع ناشناخته، متن خیلی بلند یا JSON خراب رد می‌شود. */
    fun parse(type: String?, json: String?): Pair<String, JSONObject>? {
        val t = type?.trim().orEmpty()
        if (t !in ALLOWED) return null
        val raw = json.orEmpty()
        if (raw.length > MAX_JSON) return null
        val o = runCatching { if (raw.isBlank()) JSONObject() else JSONObject(raw) }.getOrNull() ?: return null
        return t to o
    }

    /** فقط فایل‌های خود بازی داخل APK و داده‌های درون‌حافظه‌ای. */
    fun isAllowedUrl(url: String): Boolean {
        if (url.startsWith("data:") || url.startsWith("blob:")) return true
        if (!url.startsWith(ASSET_PREFIX)) return false
        val path = url.substring(ASSET_PREFIX.length).substringBefore('?').substringBefore('#')
        return path.isNotEmpty() && !path.contains("..") && !path.contains('\\') && !path.contains("%2e", ignoreCase = true)
    }

    fun result(rid: Int, data: JSONObject?, error: String?): JSONObject {
        val o = JSONObject().put("t", "result").put("rid", rid).put("ok", error == null)
        if (error == null) o.put("data", data ?: JSONObject()) else o.put("error", error)
        return o
    }

    fun toast(text: String, kind: String = ""): JSONObject =
        JSONObject().put("t", "toast").put("text", text.take(300)).put("kind", kind)

    fun phaseKey(p: Pomodoro.Phase): String = when (p) {
        Pomodoro.Phase.WORK -> "work"
        Pomodoro.Phase.BREAK -> "break"
        Pomodoro.Phase.LONG_BREAK -> "long_break"
        Pomodoro.Phase.IDLE -> "idle"
    }

    fun timer(p: Pomodoro.State, pendingMin: Int, chronoRunning: Boolean, chronoSec: Int): JSONObject {
        val c = p.config
        val total = when (p.phase) {
            Pomodoro.Phase.BREAK -> c.breakMin * 60
            Pomodoro.Phase.LONG_BREAK -> c.longBreakMin * 60
            else -> c.workMin * 60
        }
        return JSONObject()
            .put("t", "timer")
            .put("phase", phaseKey(p.phase))
            .put("running", p.running)
            .put("remaining", p.remainingSec.coerceAtLeast(0))
            .put("total", total)
            .put("completed", p.completedWork)
            .put("work_min", c.workMin)
            .put("break_min", c.breakMin)
            .put("long_min", c.longBreakMin)
            .put("pending_min", pendingMin.coerceAtLeast(0))
            .put("chrono_running", chronoRunning)
            .put("chrono_sec", chronoSec.coerceAtLeast(0))
    }

    data class Me(
        val username: String,
        val character: String,
        val level: Int,
        val levelTitle: String,
        val levelEmoji: String,
        val xp: Int,
        val levelStartXp: Int,
        val nextLevelXp: Int,
        val coins: Int,
        val streak: Int,
        val todayMinutes: Int,
        val desk: Map<String, String>,
    )

    fun state(
        me: Me,
        online: Int,
        theme: String,
        night: Boolean,
        error: String?,
        others: List<RoomOccupant>,
        cheers: List<RoomCheer>,
        snapSeq: Int,
        r3: JSONObject?,
        serverR3: Boolean?,
    ): JSONObject {
        val desk = JSONObject()
        me.desk.forEach { (k, v) -> desk.put(k, v) }
        val meO = JSONObject()
            .put("username", me.username)
            .put("character", me.character)
            .put("level", me.level)
            .put("level_title", me.levelTitle)
            .put("level_emoji", me.levelEmoji)
            .put("xp", me.xp)
            .put("level_start_xp", me.levelStartXp)
            .put("next_level_xp", me.nextLevelXp)
            .put("coins", me.coins)
            .put("streak", me.streak)
            .put("today_minutes", me.todayMinutes)
            .put("desk", desk)
        val room = JSONObject().put("online", online).put("theme", theme).put("night", night)
        if (!error.isNullOrBlank()) room.put("error", error)
        val arr = JSONArray()
        others.take(11).forEach { o ->
            arr.put(
                JSONObject()
                    .put("user_id", o.userId)
                    .put("username", o.username)
                    .put("character", o.character)
                    .put("state", o.state)
                    .put("minutes_today", o.minutesToday)
                    .put("hat", o.hat)
                    .put("combo", o.combo),
            )
        }
        val ch = JSONArray()
        cheers.take(5).forEach { c -> ch.put(JSONObject().put("emoji", c.emoji).put("from", c.from)) }
        return JSONObject()
            .put("t", "state")
            .put("me", meO)
            .put("room", room)
            .put("others", arr)
            .put("cheers", ch)
            .put("snap_seq", snapSeq)
            .put("r3", r3 ?: JSONObject.NULL)
            .put("server_r3", serverR3 ?: JSONObject.NULL)
    }
}

/** فقط برای این جلسهٔ اپ: اگر صحنه یک‌بار از کار افتاد، دوباره امتحانش نمی‌کنیم. */
internal object Room3DSession {
    @Volatile var failed = false
}

/**
 * نگه‌دارندهٔ WebView و صف پیام‌ها. وضعیت‌های Compose‌ای ([ready]، [readyGen]، [modalOpen])
 * باعث می‌شوند اثرهای ارسال، بعد از آماده شدن صفحه دوباره اجرا شوند.
 */
@Stable
internal class Room3DController {
    internal var web: WebView? = null
    var ready by mutableStateOf(false)
        private set
    var readyGen by mutableIntStateOf(0)
        private set
    var modalOpen by mutableStateOf(false)
    private var lastState: String? = null
    private var lastTimer: String? = null

    fun push(o: JSONObject) = pushRaw(o.toString())

    /** وضعیت تکراری فرستاده نمی‌شود (هر ثانیه چند بار ترکیب‌بندی ممکن است رخ دهد). */
    fun pushState(o: JSONObject) {
        val s = o.toString()
        if (s == lastState) return
        lastState = s
        pushRaw(s)
    }

    fun pushTimer(o: JSONObject) {
        val s = o.toString()
        if (s == lastTimer) return
        lastTimer = s
        pushRaw(s)
    }

    private fun pushRaw(json: String) {
        val w = web ?: return
        if (!ready) return
        runCatching { w.evaluateJavascript(Room3DProtocol.pushScript(json), null) }
    }

    fun setActive(active: Boolean) {
        val w = web ?: return
        runCatching { if (active) w.onResume() else w.onPause() }
        push(JSONObject().put("t", "lifecycle").put("active", active))
    }

    fun haptic(kind: String) {
        val w = web ?: return
        val c = when (kind) {
            "heavy" -> HapticFeedbackConstants.LONG_PRESS
            "medium" -> HapticFeedbackConstants.VIRTUAL_KEY
            else -> HapticFeedbackConstants.CLOCK_TICK
        }
        runCatching { w.performHapticFeedback(c) }
    }

    internal fun markReady() {
        lastState = null
        lastTimer = null
        ready = true
        readyGen += 1
    }

    internal fun detach() {
        ready = false
        modalOpen = false
        web = null
        lastState = null
        lastTimer = null
    }
}

/** پل جاوااسکریپت؛ از رشتهٔ JavaBridge صدا می‌شود و فقط پیام را به رشتهٔ اصلی می‌سپارد. */
internal class Room3DBridge(private val sink: (String?, String?) -> Unit) {
    @JavascriptInterface
    fun post(type: String?, json: String?) = sink(type, json)
}

@SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
@Composable
internal fun Room3DView(
    controller: Room3DController,
    onMessage: (String, JSONObject) -> Unit,
    onCrash: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val latest by rememberUpdatedState(onMessage)
    val crash by rememberUpdatedState(onCrash)
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val main = Handler(Looper.getMainLooper())
            val web = WebView(ctx)
            web.setBackgroundColor(0xFF2B1E16.toInt())
            web.overScrollMode = View.OVER_SCROLL_NEVER
            web.isVerticalScrollBarEnabled = false
            web.isHorizontalScrollBarEnabled = false
            web.isFocusable = true
            web.isFocusableInTouchMode = true
            web.isHapticFeedbackEnabled = true
            with(web.settings) {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = false
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                mediaPlaybackRequiresUserGesture = true
                setGeolocationEnabled(false)
                cacheMode = WebSettings.LOAD_NO_CACHE
                // صفحه گزینهٔ «متن بزرگ‌تر» خودش را دارد
                textZoom = 100
            }
            web.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

                @Deprecated("Deprecated in Java")
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = true

                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    val url = request.url?.toString().orEmpty()
                    if (Room3DProtocol.isAllowedUrl(url)) return null
                    return WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }

                @RequiresApi(Build.VERSION_CODES.O)
                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    // موتور گرافیک از کار افتاد (کمبود حافظه و…): اتاق کلاسیک جایش می‌آید
                    controller.detach()
                    Room3DSession.failed = true
                    main.post { crash() }
                    return true
                }
            }
            web.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                    if (BuildConfig.DEBUG) Log.d("Room3D", m.message() + " @" + m.lineNumber())
                    return true
                }
            }
            web.addJavascriptInterface(Room3DBridge { type, json ->
                val msg = Room3DProtocol.parse(type, json) ?: return@Room3DBridge
                main.post {
                    if (controller.web == null) return@post
                    when (msg.first) {
                        "ready" -> controller.markReady()
                        "modal" -> controller.modalOpen = msg.second.optBoolean("open")
                        "haptic" -> controller.haptic(msg.second.optString("kind"))
                    }
                    latest(msg.first, msg.second)
                }
            }, "AndroidR3")
            controller.web = web
            web.loadUrl(Room3DProtocol.ENTRY)
            web
        },
        onRelease = { web ->
            controller.detach()
            runCatching {
                web.removeJavascriptInterface("AndroidR3")
                web.stopLoading()
                web.loadUrl("about:blank")
                web.destroy()
            }
        },
    )
}
