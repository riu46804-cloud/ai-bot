package ir.studying.app.ui.study.room

/** Missing preferences choose classic; keep explicit choices and WebGL fallback. */
internal object RoomModePolicy {
    const val DEFAULT_USE_3D = false
    fun use3D(savedChoice: Boolean? = null, unsupported: Boolean = false): Boolean =
        (savedChoice ?: DEFAULT_USE_3D) && !unsupported
}
