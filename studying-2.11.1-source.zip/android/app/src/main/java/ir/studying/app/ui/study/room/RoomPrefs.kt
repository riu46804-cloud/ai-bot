package ir.studying.app.ui.study.room

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * A desk/wall item unlocked with study coins.
 *
 * [group] is the item family (clock / plant / mug / lamp). Only one model per
 * family is shown on the desk at a time; the rest stay in storage.
 */
data class DeskItem(
    val key: String,
    val fa: String,
    val cost: Int,
    val group: String,
)

data class DeskGroup(
    val key: String,
    val fa: String,
)

object RoomPrefs {

    val groups: List<DeskGroup> = listOf(
        DeskGroup("clock", "ساعت مطالعه"),
        DeskGroup("plant", "گلدان"),
        DeskGroup("mug", "ماگ"),
        DeskGroup("lamp", "چراغ"),
    )

    /** One studied minute = one coin. */
    val catalogue: List<DeskItem> = listOf(
        DeskItem("lamp", "چراغ مطالعه کلاسیک", 60, "lamp"),
        DeskItem("lamp_neon", "چراغ نئونی", 900, "lamp"),
        DeskItem("clock_round", "ساعت رومیزی گرد", 120, "clock"),
        DeskItem("clock_hourglass", "ساعت شنی", 480, "clock"),
        DeskItem("clock_digital", "ساعت دیجیتال", 1200, "clock"),
        DeskItem("clock_pendulum", "ساعت پاندولی", 2400, "clock"),
        DeskItem("plant", "گلدان ساده", 180, "plant"),
        DeskItem("plant_cactus", "کاکتوس", 540, "plant"),
        DeskItem("plant_monstera", "مونسترا", 1100, "plant"),
        DeskItem("plant_bonsai", "بونسای", 2000, "plant"),
        DeskItem("mug_coffee", "ماگ قهوه", 360, "mug"),
        DeskItem("mug_tea", "استکان چای", 700, "mug"),
        DeskItem("mug_matcha", "ماچای سبز", 1400, "mug"),
        DeskItem("mug_cocoa", "کاکائوی داغ", 2200, "mug"),
    )

    fun itemsOf(group: String): List<DeskItem> = catalogue.filter { it.group == group }

    fun item(key: String): DeskItem? = catalogue.find { it.key == key }

    /** Quick presets. The goal itself is free-form, these are shortcuts. */
    val goalChoices = listOf(60, 120, 180, 240, 300, 360, 480, 600)

    /** A goal below a quarter hour is noise; above ten hours is not a plan. */
    const val GOAL_MIN = 15
    const val GOAL_MAX = 600
    const val GOAL_STEP = 15

    private const val FILE = "studying_room"
    private const val K_OWNED = "owned_items"
    private const val K_SPENT = "coins_spent"
    private const val K_ACTIVE = "active_items"
    private const val K_THEME = "room_theme"
    private const val K_3D = "room_3d"
    private const val K_3D_BROKEN = "room_3d_unsupported"

    private var prefs: SharedPreferences? = null

    private val _theme = MutableStateFlow(RoomTheme.LIBRARY)
    val theme: StateFlow<RoomTheme> get() = _theme

    /**
     * اتاق سه‌بعدی «هفت‌خانِ تمرکز» یا اتاق کلاسیک دوبعدی.
     * پیش‌فرض کلاسیک است؛ حالت سه‌بعدی فقط با انتخاب کاربر روشن می‌شود.
     */
    private val _use3D = MutableStateFlow(RoomModePolicy.DEFAULT_USE_3D)
    val use3D: StateFlow<Boolean> get() = _use3D

    fun setUse3D(on: Boolean) {
        _use3D.value = on
        val e = prefs?.edit() ?: return
        e.putBoolean(K_3D, on)
        if (on) e.putBoolean(K_3D_BROKEN, false)
        e.apply()
    }

    /** گوشی اصلاً WebGL ندارد؛ دفعهٔ بعد مستقیم اتاق کلاسیک باز می‌شود (تا کاربر خودش دوباره امتحان کند). */
    fun mark3DUnsupported() {
        _use3D.value = false
        prefs?.edit()?.putBoolean(K_3D_BROKEN, true)?.putBoolean(K_3D, false)?.apply()
    }

    fun setTheme(theme: RoomTheme) {
        if (theme.requiresSubscription && !ir.studying.app.core.Subscriptions.canAccess(ir.studying.app.core.SubscriptionFeatures.ROOM_THEMES)) return
        _theme.value = theme
        prefs?.edit()?.putString(K_THEME, theme.key)?.apply()
    }

    /**
     * هدف روزانه یک جا نگه داشته می‌شود: [ir.studying.app.core.Goals].
     *
     * قبلاً دو هدف موازی وجود داشت (یکی اینجا با پیش‌فرض ۱۲۰ دقیقه، یکی در
     * Goals) و کارت خانه و حلقهٔ اتاق مطالعه دو عدد مختلف نشان می‌دادند. حالا
     * این فقط یک پنجره به همان مقدار است و «۰» یعنی کاربر هنوز هدفی نگذاشته.
     */
    val goal: StateFlow<Int> get() = ir.studying.app.core.Goals.daily

    private val _owned = MutableStateFlow<Set<String>>(emptySet())
    val owned: StateFlow<Set<String>> get() = _owned

    private val _spent = MutableStateFlow(0)
    val spent: StateFlow<Int> get() = _spent

    /** group key -> item key currently placed on the desk. */
    private val _active = MutableStateFlow<Map<String, String>>(emptyMap())
    val active: StateFlow<Map<String, String>> get() = _active

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        prefs = p
        _theme.value = RoomTheme.fromKey(p.getString(K_THEME, null))
        val ownedRaw = p.getStringSet(K_OWNED, emptySet())?.toSet() ?: emptySet()
        // migration from 2.3.1: the old "coffee" key is now "mug_coffee"
        _owned.value = if (ownedRaw.contains("coffee")) ownedRaw - "coffee" + "mug_coffee" else ownedRaw
        _spent.value = p.getInt(K_SPENT, 0)
        _active.value = decodeActive(p.getStringSet(K_ACTIVE, emptySet()))
        _use3D.value = RoomModePolicy.use3D(
            savedChoice = if (p.contains(K_3D)) p.getBoolean(K_3D, false) else null,
            unsupported = p.getBoolean(K_3D_BROKEN, false),
        )
    }

    private fun decodeActive(raw: Set<String>?): Map<String, String> {
        val out = HashMap<String, String>()
        raw?.forEach { entry ->
            val i = entry.indexOf('=')
            if (i > 0) out[entry.substring(0, i)] = entry.substring(i + 1)
        }
        return out
    }

    private fun persistActive(map: Map<String, String>) {
        val encoded = map.map { e -> e.key + "=" + e.value }.toSet()
        prefs?.edit()?.putStringSet(K_ACTIVE, encoded)?.apply()
    }

    /** Which model should be drawn for this family, or null if the user owns none. */
    fun activeOf(group: String): String? {
        val chosen = _active.value[group]
        if (chosen != null && _owned.value.contains(chosen)) return chosen
        return itemsOf(group).firstOrNull { _owned.value.contains(it.key) }?.key
    }

    fun setActive(group: String, key: String) {
        if (!_owned.value.contains(key)) return
        val m = _active.value + (group to key)
        _active.value = m
        persistActive(m)
    }

    /** Set the daily goal directly, from the goal sheet. */
    fun setGoal(minutes: Int) {
        ir.studying.app.core.Goals.setDaily(minutes.coerceIn(GOAL_MIN, GOAL_MAX))
    }

    /** Nudge the goal by one step, used by the +/- buttons in the sheet. */
    fun nudgeGoal(deltaMinutes: Int) = setGoal(goal.value + deltaMinutes)

    fun cycleGoal() {
        val i = goalChoices.indexOf(goal.value)
        setGoal(goalChoices[if (i < 0) 0 else (i + 1) % goalChoices.size])
    }

    fun coins(totalMinutes: Int): Int = (totalMinutes - _spent.value).coerceAtLeast(0)

    fun isOwned(key: String): Boolean = _owned.value.contains(key)

    /** خریدِ تاییدشده توسط سرور: سکه سراسری است، پس محلی فقط مالکیت را نگه می‌دارد. */
    fun markOwned(item: DeskItem) {
        val newOwned = _owned.value + item.key
        _owned.value = newOwned
        prefs?.edit()?.putStringSet(K_OWNED, newOwned)?.apply()
        val m = _active.value + (item.group to item.key)
        _active.value = m
        persistActive(m)
    }

    /** همگام‌سازی مالکیت از سرور (نصب تازه یا گوشی جدید). */
    fun applyServerOwned(keys: Set<String>) {
        if (keys.isEmpty()) return
        val merged = _owned.value + keys
        if (merged == _owned.value) return
        _owned.value = merged
        prefs?.edit()?.putStringSet(K_OWNED, merged)?.apply()
    }

    /** Buy an item. Returns false when already owned or coins are insufficient. */
    fun buy(item: DeskItem, totalMinutes: Int): Boolean {
        if (isOwned(item.key)) return false
        if (coins(totalMinutes) < item.cost) return false
        val newOwned = _owned.value + item.key
        val newSpent = _spent.value + item.cost
        _owned.value = newOwned
        _spent.value = newSpent
        prefs?.edit()
            ?.putStringSet(K_OWNED, newOwned)
            ?.putInt(K_SPENT, newSpent)
            ?.apply()
        val m = _active.value + (item.group to item.key)
        _active.value = m
        persistActive(m)
        return true
    }
}
