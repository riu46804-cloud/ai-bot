package ir.studying.app.ui.study.room

import kotlin.math.max
import kotlin.math.min

/** Physical, left-origin coordinates. Text direction must not mirror the artwork. */
data class RoomRect(val x: Float, val y: Float, val width: Float, val height: Float) {
    val right: Float get() = x + width
    val bottom: Float get() = y + height
}

data class RoomBackgroundMapping(val width: Float, val height: Float, val zoom: Float = 1.20f) {
    val scale = max(width / 768f, height / 1376f) * zoom
    val drawnWidth = 768f * scale
    val drawnHeight = 1376f * scale
    val left = (width - drawnWidth) / 2f
    val top = height - drawnHeight
    fun x(fraction: Float): Float = left + drawnWidth * fraction
    fun y(fraction: Float): Float = top + drawnHeight * fraction
}

/** One source of truth for image/clock, panels, desks and sprite anchors, in dp. */
data class RoomSceneGeometry(val width: Float, val height: Float, val theme: RoomTheme, val night: Boolean) {
    val background = RoomBackgroundMapping(width, height)
    val clockX = background.x(theme.clockCenterX(night))
    val clockY = background.y(theme.clockCenterY(night))
    val faceRadius = background.drawnWidth * theme.clockFaceRadius
    val frameRadius = background.drawnWidth * theme.clockFrameRadius
    private val margin = 10f
    private val gap = 9f
    // Size controls independently of the artwork's dial radius. Both side panels
    // must remain within the viewport AND outside the decorative clock frame.
    private val timerWidth = min(108f, min(clockX - frameRadius - gap - margin,
        width - margin - clockX - frameRadius - gap)).coerceAtLeast(1f)
    private val timerHeight = 76f
    val pomodoro = RoomRect(clockX - frameRadius - gap - timerWidth, clockY - timerHeight / 2f, timerWidth, timerHeight)
    val chronometer = RoomRect(clockX + frameRadius + gap, clockY - timerHeight / 2f, timerWidth, timerHeight)
    private val statWidth = min(106f, (width - margin * 2f - gap * 2f) / 3f)
    private val statHeight = 72f
    private val statY = clockY - frameRadius - 12f - statHeight
    val statistics: List<RoomRect> = listOf(
        RoomRect(margin, statY, statWidth, statHeight),
        RoomRect((width - statWidth) / 2f, statY, statWidth, statHeight),
        RoomRect(width - margin - statWidth, statY, statWidth, statHeight),
    )
    val backCenters = listOf(width * 0.24f, width * 0.50f, width * 0.76f)
    // Owl is the widest sprite: < 92% of the square canvas. Cap by seat
    // spacing, not just height, so three visible bodies never intersect.
    val backCanvas = min(height * 0.2323f, width * 0.27f)
    val frontCanvas = min(height * 0.3223f, width * 0.65f)
    private val floor = background.y(theme.floorLineY)
    val backDeskTop = floor + (height - floor) * 0.16f
    val backDeskHeight = height * 0.028f
    val frontDeskTop = height * 0.939f
    // The desk hides the lowest 17.3% of the character, matching both rows.
    val backBaseline = backDeskTop + backCanvas * 0.173f
    val frontBaseline = frontDeskTop + frontCanvas * 0.173f
}
