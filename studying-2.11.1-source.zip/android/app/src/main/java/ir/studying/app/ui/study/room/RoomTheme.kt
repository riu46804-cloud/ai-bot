package ir.studying.app.ui.study.room

import ir.studying.app.R

/** Room appearance; paid ownership is validated by the server, independent of timers. */
enum class RoomTheme(val key: String, val titleFa: String, val requiresSubscription: Boolean) {
    LIBRARY("library", "کتابخانه", false),
    ANCIENT_IRAN("ancient_iran", "ایران باستان", true),
    RASHT("rasht", "رشت", true),
    WHITE_NIGHTS("white_nights", "شب‌های روشن", true),
    JAPANESE("japanese", "فضای ژاپنی", true);

    // Legacy coin ownership remains on the server for old APKs. It does not
    // unlock paid themes in this version, per the new subscription policy.
    fun isUnlocked(subscriptionAccess: Boolean): Boolean = !requiresSubscription || subscriptionAccess

    // Only the clock face is aligned to the supplied artwork. Scene layout,
    // wall panels, seats and desks keep their original common anchors.
    // Measured against each 768 x 1376 background: the library night clock
    // is 8 px lower than the day clock. Cover the entire printed dial, not
    // just its middle, while leaving the wooden frame untouched.
    fun clockCenterX(night: Boolean): Float = when (this) {
        LIBRARY -> (if (night) 384.5f else 384f) / 768f
        ANCIENT_IRAN, RASHT, WHITE_NIGHTS, JAPANESE -> 384f / 768f
    }
    fun clockCenterY(night: Boolean): Float = when (this) {
        LIBRARY -> (if (night) 693f else 685f) / 1376f
        ANCIENT_IRAN -> 686.5f / 1376f
        RASHT -> 685.5f / 1376f
        WHITE_NIGHTS -> 687f / 1376f
        JAPANESE -> 686f / 1376f
    }
    val clockFaceRadius: Float get() = when (this) {
        LIBRARY -> 50.5f / 768f
        ANCIENT_IRAN -> 45f / 768f
        RASHT -> 43f / 768f
        WHITE_NIGHTS -> 43.5f / 768f
        JAPANESE -> 48.5f / 768f
    }

    /** The larger decorative frame is reserved when laying out clickable panels. */
    val clockFrameRadius: Float get() = when (this) {
        LIBRARY -> 58f / 768f
        ANCIENT_IRAN -> 72f / 768f
        RASHT -> 63f / 768f
        WHITE_NIGHTS -> 67f / 768f
        JAPANESE -> 59f / 768f
    }
    // These supplied artworks already have ticks, but no painted hands. Keep
    // their paper/wood shading intact; do not paint another dial over them.
    val printedTicks: Boolean get() = this == WHITE_NIGHTS || this == JAPANESE
    val repaintDial: Boolean get() = this == LIBRARY
    val floorLineY: Float get() = 0.760f

    fun backgroundRes(night: Boolean): Int = when (this) {
        LIBRARY -> if (night) R.drawable.room_library_night else R.drawable.room_library_day
        ANCIENT_IRAN -> if (night) R.drawable.room_ancient_iran_night else R.drawable.room_ancient_iran_day
        RASHT -> if (night) R.drawable.room_rasht_night else R.drawable.room_rasht_day
        WHITE_NIGHTS -> if (night) R.drawable.room_white_nights_night else R.drawable.room_white_nights_day
        JAPANESE -> if (night) R.drawable.room_japanese_night else R.drawable.room_japanese_day
    }

    companion object {
        /** Old installs and unknown saved values keep the original library theme. */
        fun fromKey(key: String?): RoomTheme = entries.firstOrNull { it.key == key } ?: LIBRARY
    }
}
