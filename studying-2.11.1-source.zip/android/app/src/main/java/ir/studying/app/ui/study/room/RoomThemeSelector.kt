package ir.studying.app.ui.study.room

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import ir.studying.app.core.Subscriptions
import ir.studying.app.core.SubscriptionFeatures
import androidx.compose.material.icons.rounded.Lock
import ir.studying.app.core.fa
import kotlinx.coroutines.launch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ThemeInk = Color(0xFF2B1E16)
private val ThemeCream = Color(0xFFF7F3E8)
private val ThemeSand = Color(0xFFE8D5A3)
private val ThemeMint = Color(0xFF34D399)

@Composable
internal fun RoomThemeSelector(theme: RoomTheme, night: Boolean, onSelect: (RoomTheme) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val control = Modifier.size(34.dp).clip(CircleShape).background(ThemeSand)
        .border(3.dp, ThemeInk, CircleShape)
        .semantics { contentDescription = "انتخاب ظاهر اتاق؛ ظاهر فعلی: ${theme.titleFa}" }
        .clickable(role = Role.Button) { open = true; scope.launch { Subscriptions.refresh() } }
    Box(control, contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Palette, null, modifier = Modifier.size(18.dp), tint = ThemeInk)
    }
    if (open) RoomThemeSheet(theme, night, onSelect) { open = false }
}

/** شیت انتخاب ظاهر اتاق؛ هم از دکمهٔ پالت اتاق کلاسیک باز می‌شود و هم از منوی اتاق سه‌بعدی. */
@Composable
internal fun RoomThemeSheet(theme: RoomTheme, night: Boolean, onSelect: (RoomTheme) -> Unit, onDismiss: () -> Unit) {
    val subscription by Subscriptions.state.collectAsState()
    val access = subscription.loaded && Subscriptions.canAccess(SubscriptionFeatures.ROOM_THEMES)
    androidx.compose.runtime.LaunchedEffect(Unit) { runCatching { Subscriptions.refresh() } }
    RoomSheet(title = "ظاهر اتاق", onDismiss = { onDismiss() }) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(if (access) "همهٔ تم‌های ویژه با اشتراک فعال‌اند" else "تم پایه رایگان؛ همهٔ تم‌های ویژه با اشتراک",
                color = ThemeInk, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
            Column(Modifier.fillMaxWidth().selectableGroup(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                RoomTheme.entries.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { choice ->
                            val unlocked = choice.isUnlocked(access)
                            ThemePreviewCard(choice, night, choice == theme, !unlocked,
                                subtitle = when {
                                    choice == theme -> "ظاهر فعلی"
                                    !choice.requiresSubscription -> "رایگان"
                                    unlocked -> "انتخاب با اشتراک"
                                    else -> "با اشتراک ویژه"
                                }, modifier = Modifier.weight(1f), onClick = {
                                    onDismiss()
                                    if (choice.isUnlocked(Subscriptions.canAccess(SubscriptionFeatures.ROOM_THEMES))) onSelect(choice)
                                    else Subscriptions.openPaywall(SubscriptionFeatures.ROOM_THEMES)
                                })
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("سکه برای وسایل میز و سایر امکانات باقی است؛ تم‌های ویژهٔ این نسخه اشتراکی‌اند.",
                color = ThemeInk.copy(alpha = 0.72f), fontSize = 11.sp, textAlign = TextAlign.Center)
            if (!access) {
                TextButton(onClick = { onDismiss(); Subscriptions.openPaywall() }, modifier = Modifier.fillMaxWidth()) {
                    Text("مشاهدهٔ پلن‌های اشتراک", color = ThemeInk)
                }
            }
        }
    }
}

@Composable
private fun ThemePreviewCard(
    theme: RoomTheme, night: Boolean, selected: Boolean, locked: Boolean, subtitle: String,
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = modifier.clip(shape).background(ThemeCream)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .border(if (selected) 4.dp else 2.dp, ThemeInk, shape)
            .padding(4.dp),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.66f).clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))) {
            Image(
                painter = painterResource(theme.backgroundRes(night)),
                contentDescription = null, contentScale = ContentScale.Crop,
                alignment = Alignment.Center, modifier = Modifier.fillMaxSize(),
            )
            if (locked) {
                Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(27.dp)
                    .clip(CircleShape).background(ThemeSand).border(2.dp, ThemeInk, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Lock, "نیازمند اشتراک", tint = ThemeInk, modifier = Modifier.size(17.dp))
                }
            }
            if (selected) {
                Box(
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                        .size(27.dp).clip(CircleShape).background(ThemeMint)
                        .border(2.dp, ThemeInk, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = "انتخاب‌شده",
                        tint = ThemeInk, modifier = Modifier.size(17.dp))
                }
            }
        }
        Column(
            modifier = Modifier.fillMaxWidth().background(if (selected) ThemeMint else ThemeSand)
                .padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(theme.titleFa, color = ThemeInk, fontWeight = FontWeight.Bold,
                fontSize = 13.sp, textAlign = TextAlign.Center)
            Text(subtitle,
                color = ThemeInk.copy(alpha = 0.78f), fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}
