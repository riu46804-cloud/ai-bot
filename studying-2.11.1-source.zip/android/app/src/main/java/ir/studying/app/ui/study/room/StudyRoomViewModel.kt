package ir.studying.app.ui.study.room

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.humanizeError
import ir.studying.app.core.str
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * مغز اتاق مطالعه.
 *
 * روی هاست اشتراکی PHP وب‌ساکت نداریم؛ پس حضور با «ضربان» هر [BEAT_SEC] ثانیه
 * نگه داشته می‌شود. همان یک درخواست هم وضعیت ما را می‌فرستد، هم لیست بقیه را
 * برمی‌گرداند و هم تشویق‌های رسیده را تحویل می‌دهد — یعنی یک رفت‌وبرگشت در هر چرخه.
 *
 * آمار قاب‌های دیواری سنگین‌تر است، پس فقط موقع ورود و بعد هر [FULL_EVERY]
 * ضربان درخواست می‌شود؛ ضربان معمولی سبک می‌ماند.
 *
 * حضور فقط تا وقتی ادامه دارد که کاربر روی این صفحه و اپ جلوی چشمش باشد؛
 * صفحه که عوض شود یا اپ برود پس‌زمینه، [leave] صدا می‌شود.
 */
class StudyRoomViewModel : ViewModel() {

    companion object {
        const val BEAT_SEC = 25L
        const val PUBLIC_ROOM = 1

        /** هر چند ضربان یک‌بار آمار کامل بگیریم (۴ × ۲۵ ثانیه ≈ ۱۰۰ ثانیه). */
        const val FULL_EVERY = 4

        val CHEER_EMOJIS = listOf("👏", "☕", "💪", "❤️", "⭐")

        /** تنها فرمان‌هایی که صحنهٔ سه‌بعدی می‌تواند به سرور بفرستد. */
        val R3_ACTIONS = setOf("r3_chest_open", "r3_claim", "r3_hat")
    }

    private val _snapshot = MutableStateFlow(RoomSnapshot())
    val snapshot: StateFlow<RoomSnapshot> get() = _snapshot

    private val _stats = MutableStateFlow(RoomStats())
    val stats: StateFlow<RoomStats> get() = _stats

    private val _character = MutableStateFlow("cat")
    val character: StateFlow<String> get() = _character

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> get() = _error

    /**
     * وضعیت خودمان، به صورت StateFlow.
     *
     * قبلاً این یک تابع ساده بود که در حین ترکیب صدا می‌شد. مشکلش این بود که
     * `Chrono.running` یک مقدار معمولی است نه State؛ پس Compose نمی‌فهمید که عوض شده
     * و کاراکتر در حالت بیکار می‌ماند. حالا هر ثانیه خوانده و در فلو ریخته می‌شود.
     */
    private val _myState = MutableStateFlow(RoomState.IDLE)
    val myState: StateFlow<String> get() = _myState

    private var beatJob: Job? = null
    private var watchJob: Job? = null
    private var beatCount = 0

    /* ---------------- هفت‌خانِ تمرکز (اتاق سه‌بعدی) ---------------- */

    /** صحنهٔ سه‌بعدی روشن است؛ ضربان وضعیت کامل بازی و تا ۱۱ هم‌اتاقی را می‌خواهد. */
    private var game3D = false

    /** آخرین وضعیت بازی از سرور (خان، کمبو، صندوق‌ها، مأموریت‌ها…). */
    private val _r3 = MutableStateFlow<JSONObject?>(null)
    val r3: StateFlow<JSONObject?> get() = _r3

    /** سرور بازی سه‌بعدی را دارد؟ null یعنی هنوز معلوم نیست. */
    private val _serverR3 = MutableStateFlow<Boolean?>(null)
    val serverR3: StateFlow<Boolean?> get() = _serverR3

    /** با هر ضربان موفق یکی زیاد می‌شود؛ صحنه تشویق‌های همان ضربان را فقط یک‌بار نشان می‌دهد. */
    private val _snapSeq = MutableStateFlow(0)
    val snapSeq: StateFlow<Int> get() = _snapSeq

    /** آخرین رویداد اتاق که دیده‌ایم؛ ‎-1 یعنی «بار اول، فقط نشانگر بده». */
    private var evLast = -1

    fun setGame3D(on: Boolean) {
        if (on == game3D) return
        game3D = on
        // بلافاصله یک ضربان کامل تا کاتالوگ کلاه‌ها و خان‌ها همان اول برسد
        if (on && beatJob?.isActive == true) viewModelScope.launch { beat(full = true) }
    }

    private fun computeMyState(): String {
        val p = Pomodoro.state.value
        return when {
            p.running && p.phase == Pomodoro.Phase.WORK -> RoomState.STUDYING
            Chrono.running -> RoomState.STUDYING
            else -> RoomState.IDLE
        }
    }

    fun enter() {
        _myState.value = computeMyState()

        if (beatJob?.isActive != true) {
            beatCount = 0
            beatJob = viewModelScope.launch {
                while (isActive) {
                    // ضربان اول و بعد هر چهار تا، آمار کامل هم می‌آید
                    beat(full = beatCount % FULL_EVERY == 0)
                    beatCount++
                    delay(BEAT_SEC * 1000)
                }
            }
        }

        // ناظر یک‌ثانیه‌ای: تا تایمر را بزنی کاراکتر فوراً عوض می‌شود و
        // همان لحظه یک ضربان می‌رود تا بقیه هم زود ببینند.
        if (watchJob?.isActive != true) {
            watchJob = viewModelScope.launch {
                while (isActive) {
                    val s = computeMyState()
                    if (s != _myState.value) {
                        _myState.value = s
                        beat(full = false)
                    }
                    delay(1000)
                }
            }
        }
    }

    /** خروج از اتاق — صفحه عوض شد یا اپ رفت پس‌زمینه. */
    fun leave() {
        beatJob?.cancel(); beatJob = null
        watchJob?.cancel(); watchJob = null
        _snapshot.value = RoomSnapshot()
        viewModelScope.launch {
            runCatching { Api.post("room_leave", JSONObject().put("room_id", PUBLIC_ROOM)) }
        }
    }

    /** ضربان دستی — بعد از استارت/استاپ تایمر تا وضعیت فوری در اتاق عوض شود. */
    fun pulse() {
        _myState.value = computeMyState()
        viewModelScope.launch { beat(full = false) }
    }

    /** تشویق یک نفر دیگر. خطایش عمداً بی‌صداست — چیز حیاتی‌ای نیست. */
    fun cheer(toUserId: Int, emoji: String) {
        viewModelScope.launch {
            runCatching {
                Api.post(
                    "room_cheer",
                    JSONObject().put("to_user", toUserId).put("emoji", emoji),
                )
            }
        }
    }

    private suspend fun beat(full: Boolean) {
        val body = JSONObject()
            .put("room_id", PUBLIC_ROOM)
            .put("state", _myState.value)
            .put("character", _character.value)
        if (full) body.put("full", 1)
        // استراحت پومودورو کمبو را نمی‌شکند (سرور تا ۳۰ دقیقه صبر می‌کند)
        val phase = Pomodoro.state.value.phase
        if (phase == Pomodoro.Phase.BREAK || phase == Pomodoro.Phase.LONG_BREAK) body.put("rest", 1)
        val want3D = game3D
        if (want3D) body.put("r3", 1).put("others_limit", 11).put("ev_since", evLast)

        runCatching { Api.obj(Api.post("room_beat", body)) }
            .onSuccess { o ->
                _error.value = null
                val mine = o.str("character")
                if (mine.isNotBlank()) _character.value = mine
                if (want3D) {
                    val r = o.optJSONObject("r3")
                    if (r != null) {
                        evLast = maxOf(evLast, r.optInt("ev_last", evLast))
                        _r3.value = r
                        _serverR3.value = true
                    } else if (_r3.value == null) {
                        _serverR3.value = false
                    }
                }
                _snapshot.value = RoomSnapshot.from(o)
                // ضربان سبک آمار ندارد؛ آمار قبلی را دور نمی‌ریزیم
                RoomStats.from(o)?.let { _stats.value = it }
                _snapSeq.value = _snapSeq.value + 1
            }
            .onFailure { _error.value = humanizeError(it) }
    }

    /**
     * فرمان‌های بازی سه‌بعدی: باز کردن صندوق، گرفتن جایزه، گذاشتن کلاه.
     * همهٔ قرعه‌ها و جایزه‌ها سمت سرور است؛ اینجا فقط درخواست می‌رود و پاسخ
     * کامل برمی‌گردد. اول [onResult] صدا می‌شود و بعد وضعیت تازه در فلوها
     * ریخته می‌شود تا صحنه جشن را دوبار پخش نکند.
     */
    fun r3Action(action: String, body: JSONObject, onResult: (JSONObject?, String?) -> Unit) {
        if (action !in R3_ACTIONS) { onResult(null, "درخواست نامعتبر"); return }
        viewModelScope.launch {
            body.put("room_id", PUBLIC_ROOM).put("ev_since", evLast)
            runCatching { Api.obj(Api.post(action, body)) }
                .onSuccess { o ->
                    if (!o.optBoolean("success")) {
                        onResult(null, o.str("error").ifBlank { "کار انجام نشد" })
                        return@onSuccess
                    }
                    onResult(o, null)
                    o.optJSONObject("state")?.let { ir.studying.app.core.Game.applyServerState(it) }
                    o.optJSONObject("r3")?.let { r ->
                        evLast = maxOf(evLast, r.optInt("ev_last", evLast))
                        // کاتالوگ فقط در ضربان کامل می‌آید؛ اگر پاسخ نداشت، قبلی را نگه داریم
                        val prev = _r3.value
                        if (!r.has("hats_catalog") && prev != null && prev.has("hats_catalog")) {
                            r.put("hats_catalog", prev.opt("hats_catalog"))
                            r.put("bosses", prev.opt("bosses"))
                        }
                        _r3.value = r
                        _serverR3.value = true
                    }
                }
                .onFailure { onResult(null, humanizeError(it)) }
        }
    }

    /** خرید کلاه با سکهٔ سراسری و پوشیدنش. */
    fun buyHat(item: String, cost: Int, equip: Boolean, onResult: (JSONObject?, String?) -> Unit) {
        viewModelScope.launch {
            val err = ir.studying.app.core.Game.buy(item, cost)
            if (err != null) { onResult(null, err); return@launch }
            val coins = ir.studying.app.core.Game.state.value.coins
            if (!equip) { onResult(JSONObject().put("coins", coins), null); return@launch }
            r3Action("r3_hat", JSONObject().put("hat", item)) { o, e ->
                // خرید انجام شده؛ اگر پوشیدن نشد هم موفق حساب می‌شود
                onResult((o ?: JSONObject()).put("coins", coins).put("equip_error", e ?: ""), null)
            }
        }
    }

    fun selectCharacter(key: String) {
        _character.value = key
        viewModelScope.launch {
            runCatching { Api.post("character_set", JSONObject().put("character", key)) }
            beat(full = false)
        }
    }

    /** ثبت دقیقه‌های مطالعه در همان جدول قدیمی `study_sessions` — بدون جدول موازی. */
    fun logMinutes(
        minutes: Int,
        courseId: Int?,
        detail: ir.studying.app.data.StudyDetail? = null,
        onResult: (String?) -> Unit,
    ) {
        if (minutes < 1) {
            onResult("زمانی برای ثبت نیست")
            return
        }
        try {
            // The old path ignored the study POST result, then reported AutoPost success as a saved study.
            ir.studying.app.core.Offline.record(
                minutes, courseId ?: 0, ir.studying.app.core.Offline.Source.ALL_TIMERS,
                detail = detail?.takeIf { !it.isEmpty }?.toJson()?.toString().orEmpty(),
            )
            ir.studying.app.notify.SyncWorker.kick(ir.studying.app.App.instance)
            RefreshBus.emit("study")
            onResult(null)
            pulse()
        } catch (e: Exception) { onResult(humanizeError(e)) }
    }

    override fun onCleared() {
        super.onCleared()
        beatJob?.cancel()
        watchJob?.cancel()
    }
}
