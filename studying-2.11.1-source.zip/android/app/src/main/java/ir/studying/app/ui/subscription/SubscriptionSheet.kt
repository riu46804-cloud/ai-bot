@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
package ir.studying.app.ui.subscription

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import kotlinx.coroutines.launch
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.studying.app.core.*
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

/** سرور و مایکت ریال می‌گویند؛ کاربر تومان می‌بیند (۱ تومان = ۱۰ ریال). */
private fun toman(rialAmount: Long): String = NumberFormat.getIntegerInstance(Locale("fa")).format(rialAmount / 10) + " تومان"

@Composable
fun SubscriptionSheet(onDismiss: () -> Unit) {
    val sub by Subscriptions.state.collectAsState()
    val billing by MyketBilling.state.collectAsState()
    var selected by rememberSaveable { mutableStateOf("monthly") }
    var codeText by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val shownPlans = sub.plans.map { BillingDiscountRules.effective(it, sub.discount) }
    LaunchedEffect(Unit) { MyketBilling.restore() }
    LaunchedEffect(sub.plans) { if (sub.plans.isNotEmpty() && sub.plans.none { it.key == selected }) selected = sub.plans.first().key }
    val applyCode = {
        if (!sub.discountBusy && !billing.busy) { keyboard?.hide(); scope.launch { Subscriptions.applyDiscount(codeText) } }
    }
    val cs = MaterialTheme.colorScheme
    val active = Subscriptions.canAccess(SubscriptionFeatures.ROOM_THEMES)
    val roomExpiry = sub.lease?.features?.get(SubscriptionFeatures.ROOM_THEMES) ?: 0L
    val displayedPlan = shownPlans.firstOrNull { it.key == selected }
    ModalBottomSheet(onDismissRequest = { if (!billing.busy) onDismiss() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Surface(shape = RoundedCornerShape(24.dp), color = cs.primaryContainer) {
                Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(
                    cs.primary.copy(alpha = 0.14f), cs.tertiary.copy(alpha = 0.12f)))).padding(20.dp)) {
                    Icon(Icons.Rounded.WorkspacePremium, null, tint = cs.primary, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("اشتراک ویژهٔ Studying", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    Text("همهٔ تم‌های ویژهٔ اتاق مطالعه، با یک اشتراک.", style = MaterialTheme.typography.bodyMedium)
                    if (active && roomExpiry > 0L) {
                        Spacer(Modifier.height(10.dp))
                        Text("اشتراک فعال تا " + Fmt.jalaliWithDay(Fmt.isoOf(Date(roomExpiry * 1000))),
                            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.primary)
                        Text("تمدید تازه به زمان باقی‌مانده اضافه می‌شود.", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("پلن خودت را انتخاب کن", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            if (shownPlans.isEmpty()) {
                Surface(shape = RoundedCornerShape(18.dp), color = cs.surfaceVariant.copy(alpha = 0.35f), modifier = Modifier.fillMaxWidth()) {
                    Text(if (sub.error != null) "پلن‌ها دریافت نشد؛ اتصال اینترنت را بررسی کنید و صفحه را دوباره باز کنید."
                        else "در حال دریافت قیمت‌ها از سرور…", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(10.dp))
            }
            shownPlans.forEach { plan ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected == plan.key) cs.primaryContainer.copy(alpha = 0.6f) else cs.surfaceVariant.copy(alpha = 0.3f),
                    border = BorderStroke(if (selected == plan.key) 2.dp else 1.dp,
                        if (selected == plan.key) cs.primary else cs.outlineVariant),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable(enabled = !billing.busy) { selected = plan.key },
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Text(plan.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                val planTag = when (plan.key) {
                                    "monthly" -> "محبوب‌ترین"
                                    "annual" -> "به‌صرفه‌ترین"
                                    else -> null
                                }
                                if (planTag != null) {
                                    Surface(shape = RoundedCornerShape(10.dp), color = cs.secondaryContainer) {
                                        Text(planTag, Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                            style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer)
                                    }
                                }
                                if (plan.discounted) {
                                    Surface(shape = RoundedCornerShape(10.dp), color = cs.tertiaryContainer) {
                                        val percent = if (plan.discountPercent == 0) "کمتر از ۱٪" else "${plan.discountPercent.fa()}٪"
                                        Text("تخفیف $percent" + if (plan.discountCode != null) " با کد" else "",
                                            Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                            style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = cs.onTertiaryContainer)
                                    }
                                }
                            }
                            Text(plan.durationDays.fa() + " روز دسترسی", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            if (plan.discounted) {
                                Text(toman(plan.listPriceRial), style = MaterialTheme.typography.bodyMedium,
                                    color = cs.onSurfaceVariant, textDecoration = TextDecoration.LineThrough)
                            }
                            Text(toman(plan.priceRial), style = MaterialTheme.typography.titleLarge, color = cs.primary, fontWeight = FontWeight.Black)
                            if (plan.discounted) {
                                Text("${((plan.listPriceRial - plan.priceRial) / 10).fa()} تومان صرفه‌جویی", style = MaterialTheme.typography.labelSmall,
                                    color = cs.tertiary, fontWeight = FontWeight.Bold)
                            }
                            if (sub.discount != null && plan.discountCode == null) {
                                Text("این کد روی این پلن تخفیف ندارد", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            }
                            val withoutCode = sub.plans.firstOrNull { it.key == plan.key }
                            if (plan.discountCode != null && withoutCode != null && plan.priceRial > withoutCode.priceRial) {
                                Text("مبلغ با کد از قیمت بدون کد بیشتر است؛ کد جایگزین تخفیف قبلی شده.",
                                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            }
                        }
                        RadioButton(selected = selected == plan.key, enabled = !billing.busy, onClick = { selected = plan.key })
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            val applied = sub.discount
            if (applied == null) {
                OutlinedTextField(
                    value = codeText,
                    onValueChange = { if (it.length <= 96) { codeText = it; if (sub.discountError != null) Subscriptions.clearDiscount() } },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !billing.busy && !sub.discountBusy,
                    label = { Text("کد تخفیف") },
                    trailingIcon = {
                        TextButton(onClick = applyCode, enabled = codeText.isNotBlank() && !sub.discountBusy && !billing.busy) {
                            if (sub.discountBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("اعمال")
                        }
                    },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { applyCode() }),
                    isError = sub.discountError != null,
                    supportingText = sub.discountError?.let { err -> { Text(err) } },
                    shape = RoundedCornerShape(16.dp),
                )
            } else {
                Surface(shape = RoundedCornerShape(16.dp), color = cs.tertiaryContainer.copy(alpha = 0.55f), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CheckCircle, null, tint = cs.tertiary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("کد ${applied.code} اعمال شد", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { codeText = ""; Subscriptions.clearDiscount() }, enabled = !billing.busy) { Text("حذف") }
                    }
                }
            }
            if (sub.catalogLoaded && !sub.billingReady) {
                Text("خرید اشتراک هنوز روی سرور راه‌اندازی نشده است. تا تکمیل تنظیمات مایکت، پرداخت غیرفعال می‌ماند.",
                    style = MaterialTheme.typography.bodySmall, color = cs.error)
            }
            (billing.error ?: sub.error)?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall)
            }
            billing.message?.let {
                Spacer(Modifier.height(8.dp))
                Surface(shape = RoundedCornerShape(14.dp), color = cs.secondaryContainer) {
                    Text(it, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = { displayedPlan?.let { MyketBilling.buy(it) } },
                enabled = sub.billingReady && displayedPlan != null && !billing.busy,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                if (billing.busy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                    Spacer(Modifier.width(9.dp))
                }
                Text(if (billing.busy) "در حال بررسی خرید…" else if (active) "تمدید با پرداخت مایکت" else "خرید با پرداخت مایکت", fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onDismiss, enabled = !billing.busy, modifier = Modifier.fillMaxWidth()) { Text("بستن") }
        }
    }
}
