@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package ir.studying.app.ui.tasks

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.studying.app.core.CourseCache
import ir.studying.app.core.fa
import ir.studying.app.data.Routine
import ir.studying.app.data.RoutineItem
import ir.studying.app.data.RoutineTemplates
import ir.studying.app.ui.components.LoadingBox

/* =============================================================================
 *  تب روتین‌ها
 *
 *  چرا این بخش: «تکرار» روی تک‌تسک، کارِ هرروزه را مدیریت نمی‌کرد. روتین یک
 *  بستهٔ نام‌دار از چند کار است با برنامهٔ روزها، پیشرفت مشترک، زنجیرهٔ روزانه
 *  و نقشهٔ ۳۰ روز. تسک‌های واقعی همچنان در لیست امروز ساخته می‌شوند تا تایمر،
 *  یادآور و ویجت بدون تغییر رویشان کار کند.
 * ========================================================================== */

@Composable
fun RoutinesTab(
    vm: RoutinesViewModel,
    bottomPadding: androidx.compose.ui.unit.Dp,
    onCreate: () -> Unit,
    onEdit: (Routine) -> Unit,
) {
    val state by vm.state.collectAsState()
    val busy by vm.busy.collectAsState()

    when {
        state.loading -> LoadingBox(height = 200.dp)
        state.routines.isEmpty() -> RoutinesEmpty(onCreate = onCreate)
        else -> LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 16.dp + bottomPadding),
            verticalArrangement = Arrangement.spacedBy(11.dp),
        ) {
            items(state.routines, key = { it.id }) { r ->
                RoutineCard(
                    routine = r,
                    busy = busy.contains(r.id),
                    onToggleActive = { vm.setActive(r, it) },
                    onApply = { vm.applyNow(r) },
                    onCompleteAll = { vm.completeAll(r) },
                    onSkip = { vm.skipToday(r) },
                    onEdit = { onEdit(r) },
                    onDelete = { vm.delete(r) },
                    onSaveItems = { newItems ->
                        // ویرایش/حذف یک کار از داخل کارت، بدون باز کردن فرم کامل.
                        // روتینِ بدون کار بی‌معنی است، پس آخرین کار حذف نمی‌شود.
                        if (newItems.isEmpty()) {
                            ir.studying.app.ui.components.AppSnack.show(
                                "آخرین کارِ روتین حذف نمی‌شود؛ خود روتین را حذف کن",
                            )
                        } else {
                            vm.save(r.id, r.title, r.emoji, r.selectedDays, r.startHm, newItems, r.active) { err ->
                                if (err != null) ir.studying.app.ui.components.AppSnack.show(err)
                            }
                        }
                    },
                )
            }
            // دکمهٔ ساخت روتین همان FAB گوشهٔ صفحه است؛ دکمهٔ تکراری حذف شد.
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

/** شعلهٔ کوچک زنجیره با تپش ملایم. */
@Composable
private fun StreakFlame(days: Int, big: Boolean = false) {
    val t = rememberInfiniteTransition(label = "flame")
    val pulse by t.animateFloat(
        0.94f, 1.10f,
        infiniteRepeatable(tween(950, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "flamePulse",
    )
    Row(
        Modifier
            .clip(CircleShape)
            .background(Color(0xFFFF7043).copy(alpha = 0.14f))
            .padding(horizontal = if (big) 12.dp else 9.dp, vertical = if (big) 7.dp else 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("🔥", fontSize = if (big) 18.sp else 13.sp, modifier = Modifier.scale(pulse))
        Spacer(Modifier.width(4.dp))
        Text(
            days.fa(),
            style = if (big) MaterialTheme.typography.titleSmall else MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Black, color = Color(0xFFFF7043),
        )
    }
}

/**
 * کارت یک روتین — عمداً خلوت.
 *
 * حالت بسته فقط: حلقهٔ پیشرفت، اسم، روزها/ساعت، زنجیره و سوییچ. بقیهٔ چیزها
 * (کارها، نقشهٔ ۳۰ روز، دکمه‌ها) با یک تپ باز می‌شوند تا لیست شلوغ نشود.
 */
@Composable
private fun RoutineCard(
    routine: Routine,
    busy: Boolean,
    onToggleActive: (Boolean) -> Unit,
    onApply: () -> Unit,
    onCompleteAll: () -> Unit,
    onSkip: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onSaveItems: (List<RoutineItem>) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var open by remember(routine.id) { mutableStateOf(false) }
    var editIndex by remember(routine.id) { mutableIntStateOf(-1) }
    var confirmDelete by remember(routine.id) { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (routine.completedToday) cs.primary.copy(alpha = 0.06f) else cs.surface,
        border = BorderStroke(
            1.dp,
            if (routine.completedToday) cs.primary.copy(alpha = 0.30f) else cs.outlineVariant.copy(alpha = 0.45f),
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { open = !open }
                    .padding(horizontal = 13.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ProgressRing(
                    progress = routine.progress,
                    size = 44.dp, stroke = 5.dp,
                    colors = listOf(cs.primary, cs.secondary),
                ) { Text(routine.emoji, fontSize = 17.sp) }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        routine.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (routine.active) cs.onSurface else cs.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        buildString {
                            append(routine.daysLabel)
                            routine.startHm?.let { append(" · ${it.fa()}") }
                            if (routine.active && routine.scheduledToday && routine.todayTotal > 0) {
                                append(" · ${routine.todayDone.fa()}/${routine.todayTotal.fa()}")
                            }
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                if (routine.streak > 0) { StreakFlame(routine.streak); Spacer(Modifier.width(6.dp)) }
                Switch(
                    checked = routine.active,
                    onCheckedChange = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onToggleActive(it)
                    },
                    enabled = !busy,
                    colors = SwitchDefaults.colors(checkedThumbColor = cs.onPrimary, checkedTrackColor = cs.primary),
                )
            }

            AnimatedVisibility(
                visible = open,
                enter = expandVertically(tween(260, easing = FastOutSlowInEasing)) + fadeIn(tween(200)),
                exit = shrinkVertically(tween(200)) + fadeOut(tween(120)),
            ) {
                Column(Modifier.padding(start = 13.dp, end = 13.dp, bottom = 13.dp)) {
                    routine.items.forEachIndexed { i, item ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(cs.surfaceVariant.copy(alpha = 0.35f))
                                .clickable { editIndex = i }   // تپ = جزئیات و ویرایش
                                .padding(horizontal = 11.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${(i + 1).fa()}.", style = MaterialTheme.typography.labelSmall, color = cs.primary, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                item.title,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            item.dueHm?.let {
                                Text("⏰ ${it.fa()}", style = MaterialTheme.typography.labelSmall, color = cs.tertiary)
                                Spacer(Modifier.width(6.dp))
                            }
                            if (item.estimateMin > 0) {
                                Text(minutesLabel(item.estimateMin), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                                Spacer(Modifier.width(6.dp))
                            }
                            // حذف مستقیم همان کار از روتین
                            Icon(
                                Icons.Rounded.Delete, "حذف",
                                tint = cs.error.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .size(15.dp)
                                    .clickable {
                                        onSaveItems(routine.items.filterIndexed { idx, _ -> idx != i })
                                    },
                            )
                        }
                    }

                    Spacer(Modifier.height(9.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        RoundAction("▶️", "اجرای امروز", cs.primary, !busy, Modifier.weight(1f), onApply)
                        RoundAction("✅", "همه انجام شد", cs.secondary, !busy && routine.todayTotal > 0, Modifier.weight(1f), onCompleteAll)
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        RoundAction("😴", "استراحت", Color(0xFFF59E0B), !busy, Modifier.weight(1f), onSkip)
                        RoundAction("✏️", "ویرایش", cs.tertiary, true, Modifier.weight(1f), onEdit)
                        RoundAction("🗑", if (confirmDelete) "مطمئنی؟" else "حذف", cs.error, !busy, Modifier.weight(1f)) {
                            if (confirmDelete) onDelete() else confirmDelete = true
                        }
                    }

                    Spacer(Modifier.height(11.dp))
                    RoutineHeatStrip(routine)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "۳۰ روز گذشته" + (if (routine.bestStreak > 0) " · بهترین زنجیره ${routine.bestStreak.fa()} روز" else ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant.copy(alpha = 0.8f),
                    )
                }
            }
        }
    }

    if (editIndex >= 0 && editIndex < routine.items.size) {
        val idx = editIndex
        RoutineItemSheet(
            item = routine.items[idx],
            onDismiss = { editIndex = -1 },
            onDelete = {
                onSaveItems(routine.items.filterIndexed { i, _ -> i != idx })
                editIndex = -1
            },
            onSave = { updated ->
                onSaveItems(routine.items.mapIndexed { i, old -> if (i == idx) updated else old })
                editIndex = -1
            },
        )
    }
}

/** دکمهٔ کوچکِ کارِ روتین. */
@Composable
private fun RoundAction(
    emoji: String,
    label: String,
    accent: Color,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(accent.copy(alpha = if (enabled) 0.12f else 0.05f))
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 12.sp)
        Spacer(Modifier.width(5.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (enabled) accent else accent.copy(alpha = 0.5f),
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
    }
}

/** ۳۰ مربع کوچک: سبز=کامل، نارنجی=ناتمام، خاکستری=بی‌برنامه، آبی=استراحت. */
@Composable
private fun RoutineHeatStrip(routine: Routine) {
    val cs = MaterialTheme.colorScheme
    val map = remember(routine.history) { routine.history.associateBy { it.day } }
    val days = remember(routine.history) {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -29)
        (0 until 30).map { fmt.format(cal.time).also { _ -> cal.add(java.util.Calendar.DAY_OF_YEAR, 1) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.fillMaxWidth()) {
        days.forEach { d ->
            val log = map[d]
            val color = when {
                log == null -> cs.onSurface.copy(alpha = 0.07f)
                log.state == 1 -> cs.primary
                log.state == 2 -> cs.tertiary.copy(alpha = 0.6f)
                log.total > 0 -> Color(0xFFF59E0B).copy(alpha = 0.55f)
                else -> cs.onSurface.copy(alpha = 0.07f)
            }
            Box(
                Modifier
                    .weight(1f)
                    .height(14.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color),
            )
        }
    }
}

@Composable
private fun NewRoutineButton(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(cs.primary, cs.secondary)))
            .clickable { onClick() }
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Add, null, tint = cs.onPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(7.dp))
        Text("روتین جدید", color = cs.onPrimary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RoutinesEmpty(onCreate: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "empty")
    val float by t.animateFloat(
        -6f, 6f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float",
    )
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("🌅", fontSize = 52.sp, modifier = Modifier.padding(bottom = 10.dp).scale(1f + float / 120f))
        Text("هنوز روتینی نساخته‌ای", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "روتین یعنی چند کار ثابت که هر روز (یا روزهای خاصی) خودکار به لیست امروزت اضافه می‌شوند و زنجیرهٔ روزانه می‌سازند.",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        NewRoutineButton(onCreate)
    }
}

/* =============================================================================
 *  ساخت/ویرایش روتین
 * ========================================================================== */

@Composable
fun RoutineEditorSheet(
    initial: Routine?,
    saving: Boolean,
    onDismiss: () -> Unit,
    onSave: (title: String, emoji: String, days: Set<Int>, startTime: String?, itemList: List<RoutineItem>) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var emoji by remember { mutableStateOf(initial?.emoji ?: "🌅") }
    var start by remember { mutableStateOf(initial?.startHm) }
    var timePicker by remember { mutableStateOf(false) }
    val days = remember { mutableStateListOf<Int>().also { it.addAll(initial?.selectedDays ?: (0..6).toSet()) } }
    val itemList = remember { mutableStateListOf<RoutineItem>().also { it.addAll(initial?.items ?: emptyList()) } }
    var newItem by remember { mutableStateOf("") }
    var editItem by remember { mutableIntStateOf(-1) }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(
            Modifier
                .padding(horizontal = 16.dp)
                .padding(bottom = 26.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            SheetHeader(
                emoji,
                if (initial == null) "روتین جدید" else "ویرایش روتین",
                "چند کار ثابت + روزهایی که تکرار می‌شوند",
            )

            // قالب‌های آماده فقط برای روتین جدید؛ کاربر تازه‌کار از صفر نماند
            if (initial == null) {
                Spacer(Modifier.height(12.dp))
                Text("قالب آماده", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(7.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(RoutineTemplates) { tpl ->
                        SpringChip("${tpl.emoji} ${tpl.title}", title == tpl.title) {
                            title = tpl.title
                            emoji = tpl.emoji
                            start = tpl.startTime
                            days.clear(); days.addAll(tpl.days)
                            itemList.clear(); itemList.addAll(tpl.items)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(cs.primary.copy(alpha = 0.12f))
                        .clickable { emoji = nextEmoji(emoji) },
                    contentAlignment = Alignment.Center,
                ) { Text(emoji, fontSize = 24.sp) }
                Spacer(Modifier.width(10.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("اسم روتین، مثلاً: صبح مطالعه") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = cs.primary,
                        unfocusedBorderColor = cs.outlineVariant,
                    ),
                    modifier = Modifier.weight(1f),
                )
            }

            Spacer(Modifier.height(14.dp))
            Text("روزهای تکرار", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Routine.DAY_SHORT.forEachIndexed { i, label ->
                    val sel = days.contains(i)
                    val bg by androidx.compose.animation.animateColorAsState(
                        if (sel) cs.primary else cs.surfaceVariant.copy(alpha = 0.5f),
                        tween(200), label = "day$i",
                    )
                    Box(
                        Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(bg)
                            .clickable { if (sel) days.remove(i) else days.add(i) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (sel) cs.onPrimary else cs.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                SpringChip("هر روز", days.size == 7) { days.clear(); days.addAll(0..6) }
                SpringChip("شنبه تا چهارشنبه", days.toSet() == setOf(0, 1, 2, 3, 4)) { days.clear(); days.addAll(0..4) }
                SpringChip(
                    start?.let { "⏰ ${it.fa()}" } ?: "ساعت شروع",
                    start != null,
                    accent = cs.tertiary,
                ) { timePicker = true }
            }

            Spacer(Modifier.height(16.dp))
            Text("کارهای روتین", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(7.dp))
            RoutineItemsList(items = itemList, onEdit = { editItem = it })

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newItem,
                    onValueChange = { newItem = it },
                    placeholder = { Text("کار جدید…") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = cs.primary,
                        unfocusedBorderColor = cs.outlineVariant,
                    ),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (newItem.isBlank()) cs.onSurface.copy(alpha = 0.10f) else cs.primary)
                        .clickable(enabled = newItem.isNotBlank()) {
                            itemList.add(RoutineItem(title = newItem.trim()))
                            newItem = ""
                        },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Add, null, tint = cs.onPrimary, modifier = Modifier.size(20.dp)) }
            }

            Spacer(Modifier.height(18.dp))
            GradientActionButton(
                text = if (saving) "در حال ذخیره…" else "ذخیرهٔ روتین",
                enabled = title.isNotBlank() && itemList.isNotEmpty() && !saving,
            ) { onSave(title.trim(), emoji, days.toSet(), start, itemList.toList()) }
        }
    }

    if (timePicker) {
        TimePickerDialog(
            initial = start,
            onDismiss = { timePicker = false },
            onClear = { start = null; timePicker = false },
            onConfirm = { start = it; timePicker = false },
        )
    }

    if (editItem >= 0 && editItem < itemList.size) {
        val it0 = itemList[editItem]
        RoutineItemSheet(
            item = it0,
            onDismiss = { editItem = -1 },
            onDelete = { itemList.removeAt(editItem); editItem = -1 },
            onSave = { updated -> itemList[editItem] = updated; editItem = -1 },
        )
    }
}

/** لیست کارهای داخل فرم روتین. */
@Composable
private fun RoutineItemsList(items: List<RoutineItem>, onEdit: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    if (items.isEmpty()) {
        Text("هنوز کاری اضافه نکرده‌ای", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        return
    }
    Column {
        items.forEachIndexed { i, it0 ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(cs.surfaceVariant.copy(alpha = 0.42f))
                    .clickable { onEdit(i) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("${(i + 1).fa()}.", style = MaterialTheme.typography.labelSmall, color = cs.primary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(
                    it0.title,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (it0.estimateMin > 0) {
                    Text(minutesLabel(it0.estimateMin), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                }
                it0.dueHm?.let {
                    Text("⏰ ${it.fa()}", style = MaterialTheme.typography.labelSmall, color = cs.tertiary)
                    Spacer(Modifier.width(6.dp))
                }
                Icon(Icons.Rounded.Edit, null, tint = cs.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.size(15.dp))
            }
        }
    }
}

/** ویرایش یک کارِ روتین: عنوان، ساعت، تخمین، اولویت، درس. */
@Composable
private fun RoutineItemSheet(
    item: RoutineItem,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onSave: (RoutineItem) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var title by remember { mutableStateOf(item.title) }
    var due by remember { mutableStateOf(item.dueHm) }
    var estimate by remember { mutableIntStateOf(item.estimateMin) }
    var priority by remember { mutableStateOf(item.priority) }
    var course by remember { mutableStateOf(item.course) }
    var timePicker by remember { mutableStateOf(false) }
    val courses = remember { CourseCache.peek().map { it.name } }

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 26.dp).verticalScroll(rememberScrollState())) {
            SheetHeader("🧩", "کارِ روتین", "این کار هر بار که روتین اجرا شود ساخته می‌شود")
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = cs.primary,
                    unfocusedBorderColor = cs.outlineVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            ir.studying.app.ui.components.PriorityRadio(
                selected = priority,
                labels = listOf("فوری", "معمولی", "کم"),
            ) { priority = it }

            Spacer(Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                SpringChip(due?.let { "⏰ ${it.fa()}" } ?: "ساعت", due != null, accent = cs.tertiary) { timePicker = true }
                listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                    SpringChip(
                        if (m == 0) "بدون زمان" else minutesLabel(m),
                        estimate == m,
                        accent = cs.secondary,
                    ) { estimate = m }
                }
            }
            if (courses.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    SpringChip("بدون درس", course.isBlank()) { course = "" }
                    courses.forEach { c -> SpringChip("📚 $c", course == c) { course = c } }
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Box(Modifier.weight(1f)) {
                    GradientActionButton("ذخیره", enabled = title.isNotBlank()) {
                        onSave(item.copy(title = title.trim(), dueTime = due, estimateMin = estimate, priority = priority, course = course))
                    }
                }
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(cs.error.copy(alpha = 0.14f))
                        .clickable { onDelete() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Delete, "حذف", tint = cs.error, modifier = Modifier.size(20.dp)) }
            }
        }
    }

    if (timePicker) {
        TimePickerDialog(
            initial = due,
            onDismiss = { timePicker = false },
            onClear = { due = null; timePicker = false },
            onConfirm = { due = it; timePicker = false },
        )
    }
}

/** دکمهٔ گرادیانی (نسخهٔ عمومیِ همان دکمهٔ شیت‌ها). */
@Composable
internal fun GradientActionButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (enabled) Brush.horizontalGradient(listOf(cs.primary, cs.secondary))
                else Brush.horizontalGradient(listOf(cs.onSurface.copy(alpha = 0.12f), cs.onSurface.copy(alpha = 0.12f))),
            )
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            color = if (enabled) cs.onPrimary else cs.onSurface.copy(alpha = 0.5f),
        )
    }
}

/** چرخاندن ایموجی روتین با تپ؛ انتخابگر کامل ایموجی برای این کار زیادی است. */
private val RoutineEmojis = listOf("🌅", "🌙", "📚", "💪", "🧘", "🏃", "✍️", "🧪", "🎯", "☕", "🌱", "🔁")
private fun nextEmoji(current: String): String {
    val i = RoutineEmojis.indexOf(current)
    return RoutineEmojis[(if (i < 0) 0 else i + 1) % RoutineEmojis.size]
}

/* =============================================================================
 *  تبدیل یک تسک تکی به روتین
 *
 *  چرا جدا از فرم کامل: کاربر در این لحظه فقط یک تصمیم دارد — «چه روزهایی
 *  تکرار شود؟». باقی تنظیم‌ها بعداً در ویرایش روتین در دسترس است.
 * ========================================================================== */
@Composable
fun MakeRoutineSheet(
    taskTitle: String,
    onDismiss: () -> Unit,
    onConfirm: (days: Set<Int>, emoji: String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val days = remember { mutableStateListOf<Int>().also { it.addAll(0..6) } }
    var emoji by remember { mutableStateOf("🔁") }
    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 26.dp)) {
            SheetHeader("🔁", "روتین از «$taskTitle»", "از این به بعد خودکار در روزهای انتخابی ساخته می‌شود")
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Routine.DAY_SHORT.forEachIndexed { i, label ->
                    val sel = days.contains(i)
                    Box(
                        Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(if (sel) cs.primary else cs.surfaceVariant.copy(alpha = 0.5f))
                            .clickable { if (sel) days.remove(i) else days.add(i) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label, style = MaterialTheme.typography.labelLarge,
                            color = if (sel) cs.onPrimary else cs.onSurfaceVariant, fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(cs.primary.copy(alpha = 0.12f))
                        .clickable { emoji = nextEmoji(emoji) },
                    contentAlignment = Alignment.Center,
                ) { Text(emoji, fontSize = 22.sp) }
                Spacer(Modifier.width(10.dp))
                Text(
                    "برای عوض‌کردن آیکن روی آن بزن",
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(16.dp))
            GradientActionButton("بساز", enabled = days.isNotEmpty()) { onConfirm(days.toSet(), emoji) }
        }
    }
}
