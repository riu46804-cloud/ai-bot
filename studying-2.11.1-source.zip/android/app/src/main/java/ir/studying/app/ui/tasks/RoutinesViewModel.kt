package ir.studying.app.ui.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.humanizeError
import ir.studying.app.data.Routine
import ir.studying.app.data.RoutineItem
import ir.studying.app.ui.components.AppSnack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * منطق بخش روتین‌ها.
 *
 * جدا از [TasksViewModel] نگه داشته شده چون چرخهٔ داده‌اش فرق دارد: روتین
 * الگوست و تسک‌ها خروجی روزانه‌اش؛ ولی بعد از هر تغییر، لیست تسک‌ها هم باید
 * تازه شود، برای همین روی [RefreshBus] رویداد "tasks" می‌فرستیم.
 */
class RoutinesViewModel : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val error: String? = null,
        val routines: List<Routine> = emptyList(),
        val saving: Boolean = false,
    ) {
        val active: List<Routine> get() = routines.filter { it.active }
        /** جمع پیشرفت امروزِ همهٔ روتین‌های امروزی — برای نوار بالای تب. */
        val todayTotal: Int get() = active.filter { it.scheduledToday }.sumOf { it.todayTotal }
        val todayDone: Int get() = active.filter { it.scheduledToday }.sumOf { it.todayDone }
        val bestStreak: Int get() = routines.maxOfOrNull { it.streak } ?: 0
        fun byId(id: Int): Routine? = routines.firstOrNull { it.id == id }
        /** نگاشت شناسهٔ روتین به خودش؛ برای نشان‌دادن برچسب روی کارت تسک. */
        val map: Map<Int, Routine> get() = routines.associateBy { it.id }
    }

    val state = MutableStateFlow(State())
    val busy = MutableStateFlow<Set<Int>>(emptySet())

    init {
        refresh()
        /*
         * تیک‌خوردن تسک در تب «امروز» باید فوراً روی پیشرفت روتین دیده شود.
         * [TasksViewModel] بعد از هر تغییر رویداد "routines" می‌فرستد و ما فقط
         * می‌خوانیم (بدون emit دوباره) تا حلقهٔ بی‌نهایت رفرش درست نشود.
         */
        viewModelScope.launch {
            RefreshBus.events.collect { if (it == "routines" || it == "all") load() }
        }
    }

    fun refresh() {
        viewModelScope.launch { load(first = true) }
    }

    private suspend fun load(first: Boolean = false) {
        try {
            val list = Routine.list(Api.arr(Api.get("routines")))
            state.update { it.copy(loading = false, error = null, routines = list) }
        } catch (e: Exception) {
            // سرور قدیمی هنوز اندپوینت روتین ندارد؛ تب باید خالی بماند نه خراب.
            if (first) state.update { it.copy(loading = false, error = humanizeError(e)) }
        }
    }

    /**
     * به‌روزرسانی خوش‌بینانهٔ شمارش یک روتین.
     *
     * وقتی کاربر تسکی از روتین را تیک می‌زند، تا رسیدن پاسخ سرور هم عدد باید
     * تکان بخورد؛ وگرنه حس می‌کند چیزی کار نمی‌کند.
     */
    fun bumpLocal(routineId: Int, delta: Int) {
        if (routineId <= 0) return
        state.update { s ->
            s.copy(
                routines = s.routines.map { r ->
                    if (r.id != routineId) r
                    else r.copy(todayDone = (r.todayDone + delta).coerceIn(0, r.todayTotal))
                },
            )
        }
    }

    private suspend fun reload() {
        load()
        RefreshBus.emit("tasks")
    }

    /** ساخت/ویرایش کامل یک روتین. id=0 یعنی جدید. */
    fun save(
        id: Int,
        title: String,
        emoji: String,
        days: Set<Int>,
        startTime: String?,
        items: List<RoutineItem>,
        active: Boolean = true,
        onResult: (String?) -> Unit = {},
    ) {
        val t = title.trim()
        if (t.isEmpty()) { onResult("اسم روتین را بنویس"); return }
        if (items.none { it.title.isNotBlank() }) { onResult("حداقل یک کار به روتین اضافه کن"); return }
        viewModelScope.launch {
            state.update { it.copy(saving = true) }
            val arr = JSONArray()
            items.filter { it.title.isNotBlank() }.forEach { arr.put(it.toJson()) }
            val body = JSONObject()
                .put("id", id).put("title", t).put("emoji", emoji)
                .put("days", Routine.rule(days))
                .put("start_time", startTime ?: "")
                .put("active", if (active) 1 else 0)
                .put("items", arr)
            val res = runCatching { Api.obj(Api.post("routine_save", body)) }
            val err = res.exceptionOrNull()?.let { humanizeError(it) }
                ?: res.getOrNull()?.optString("error").orEmpty().ifBlank { null }
            reload()
            state.update { it.copy(saving = false) }
            onResult(err)
        }
    }

    fun setActive(r: Routine, active: Boolean) {
        viewModelScope.launch {
            busy.update { it + r.id }
            // خوش‌بینانه: سوییچ باید فوری تکان بخورد، بعد سرور تأیید کند.
            state.update { s -> s.copy(routines = s.routines.map { if (it.id == r.id) it.copy(active = active) else it }) }
            runCatching { Api.post("routine_toggle", JSONObject().put("id", r.id).put("active", if (active) 1 else 0)) }
            reload()
            busy.update { it - r.id }
        }
    }

    fun applyNow(r: Routine, date: String? = null) {
        viewModelScope.launch {
            busy.update { it + r.id }
            val res = runCatching {
                Api.obj(Api.post("routine_apply", JSONObject().put("id", r.id).put("date", date ?: "")))
            }
            reload()
            busy.update { it - r.id }
            val made = res.getOrNull()?.optInt("made") ?: 0
            AppSnack.show(if (res.isSuccess) "${made} کار از «${r.title}» به لیست امروز اضافه شد" else "اجرا نشد")
        }
    }

    fun completeAll(r: Routine, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            busy.update { it + r.id }
            val res = runCatching { Api.obj(Api.post("routine_complete", JSONObject().put("id", r.id))) }
            reload()
            busy.update { it - r.id }
            onDone(res.isSuccess)
        }
    }

    /** «امروز استراحت» — روز علامت می‌خورد و زنجیره نمی‌شکند. */
    fun skipToday(r: Routine) {
        viewModelScope.launch {
            busy.update { it + r.id }
            runCatching { Api.post("routine_skip", JSONObject().put("id", r.id)) }
            reload()
            busy.update { it - r.id }
            AppSnack.show("امروزِ «${r.title}» استراحت شد؛ زنجیره‌ات نمی‌شکند")
        }
    }

    fun delete(r: Routine) {
        viewModelScope.launch {
            state.update { s -> s.copy(routines = s.routines.filterNot { it.id == r.id }) }
            runCatching { Api.post("routine_delete", JSONObject().put("id", r.id)) }
            reload()
            AppSnack.show("روتین «${r.title}» حذف شد")
        }
    }

    /** تبدیل یک تسک تکی به روتین (خواستهٔ رایج: «این کار هر روزم بشه»). */
    fun fromTask(taskId: Int, title: String, days: Set<Int>, emoji: String = "🔁", onResult: (String?) -> Unit = {}) {
        viewModelScope.launch {
            val body = JSONObject()
                .put("task_id", taskId).put("title", title)
                .put("days", Routine.rule(days)).put("emoji", emoji)
            val res = runCatching { Api.obj(Api.post("routine_from_task", body)) }
            val err = res.exceptionOrNull()?.let { humanizeError(it) }
                ?: res.getOrNull()?.optString("error").orEmpty().ifBlank { null }
            reload()
            onResult(err)
        }
    }

    fun reorder(ids: List<Int>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            runCatching { Api.post("routine_reorder", JSONObject().put("ids", arr)) }
            reload()
        }
    }
}
