@file:OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)

package ir.studying.app.ui.tasks

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.studying.app.core.fa

/* =============================================================================
 *  زبان بصری بخش تسک.
 *
 *  چرا یک فایل جدا: قبلاً هر ردیف فقط یک Surface خاکستری با متن بود و صفحه
 *  «فرم اداری» به نظر می‌رسید. تکه‌های زیر (حلقهٔ پیشرفت، پیل‌های گرادیانی،
 *  چیپ فنری، شیمر و سربرگ شیت‌ها) یک بار ساخته می‌شوند تا همهٔ بخش‌های تازه
 *  یک حس داشته باشند و انیمیشن‌ها در همه‌جا هم‌خانواده باشند.
 * ========================================================================== */

/** رنگ اختصاصی هر اولویت؛ گرادیان‌ها از همین می‌آیند. */
@Composable
internal fun priorityColors(priority: String): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (priority) {
        "high" -> Color(0xFFFB7185) to Color(0xFFF43F5E)
        "low" -> Color(0xFF34D399) to Color(0xFF10B981)
        else -> cs.primary to cs.secondary
    }
}

/**
 * حلقهٔ پیشرفت با گرادیان چرخان و نقطهٔ نورانی روی نوک قوس.
 *
 * ProgressIndicator آماده یک قوس تخت می‌کشد؛ اینجا سه لایه داریم: شیار،
 * قوس گرادیانی و یک هالهٔ نرم پشت نوک، که حرکت را «زنده» نشان می‌دهد.
 */
@Composable
internal fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    size: Dp = 62.dp,
    stroke: Dp = 7.dp,
    colors: List<Color> = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary),
    trackColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
    content: @Composable () -> Unit = {},
) {
    val p by animateFloatAsState(
        progress.coerceIn(0f, 1f),
        spring(dampingRatio = 0.62f, stiffness = 140f),
        label = "ring",
    )
    val glow = rememberInfiniteTransition(label = "ringGlow")
    val pulse by glow.animateFloat(
        initialValue = 0.75f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "ringPulse",
    )
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val inset = sw / 2f
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(
                color = trackColor, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize,
                style = Stroke(sw, cap = StrokeCap.Round),
            )
            if (p > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(colors + colors.first()),
                    startAngle = -90f, sweepAngle = 360f * p, useCenter = false,
                    topLeft = Offset(inset, inset), size = arcSize,
                    style = Stroke(sw, cap = StrokeCap.Round),
                )
                // نقطهٔ نورانی روی نوک قوس
                val angle = Math.toRadians((-90f + 360f * p).toDouble())
                val r = (this.size.minDimension - sw) / 2f
                val cx = this.size.width / 2f + r * kotlin.math.cos(angle).toFloat()
                val cy = this.size.height / 2f + r * kotlin.math.sin(angle).toFloat()
                drawCircle(colors.last().copy(alpha = 0.22f), radius = sw * 1.5f * pulse, center = Offset(cx, cy))
                drawCircle(Color.White.copy(alpha = 0.9f), radius = sw * 0.32f, center = Offset(cx, cy))
            }
        }
        content()
    }
}

/** عدد با انیمیشن بالا/پایین — تغییر شمارش باید دیده شود، نه بی‌صدا عوض شود. */
@Composable
internal fun AnimatedCount(
    value: Int,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.titleMedium,
    color: Color = MaterialTheme.colorScheme.onSurface,
    suffix: String = "",
) {
    AnimatedContent(
        targetState = value,
        transitionSpec = {
            if (targetState > initialState) {
                (slideInVertically { it / 2 } + fadeIn()).togetherWith(slideOutVertically { -it / 2 } + fadeOut())
            } else {
                (slideInVertically { -it / 2 } + fadeIn()).togetherWith(slideOutVertically { it / 2 } + fadeOut())
            }
        },
        label = "count",
    ) { v ->
        Text(v.fa() + suffix, style = style, color = color, fontWeight = FontWeight.Bold)
    }
}

/** پیل شیشه‌ای با لبهٔ گرادیانی؛ جایگزین چیپ‌های تخت قبلی. */
@Composable
internal fun GradientPill(
    text: String,
    tint: Color,
    modifier: Modifier = Modifier,
    strong: Boolean = false,
    pulsing: Boolean = false,
) {
    val pulse = rememberInfiniteTransition(label = "pillPulse")
    val a by pulse.animateFloat(
        initialValue = 0.35f, targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pillAlpha",
    )
    val borderAlpha = if (pulsing) a else if (strong) 0.55f else 0.30f
    Box(
        modifier
            .clip(CircleShape)
            .background(
                Brush.horizontalGradient(
                    listOf(tint.copy(alpha = if (strong) 0.26f else 0.13f), tint.copy(alpha = if (strong) 0.14f else 0.06f)),
                ),
            )
            .border(1.dp, tint.copy(alpha = borderAlpha), CircleShape)
            .padding(horizontal = 9.dp, vertical = 3.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = tint, fontWeight = FontWeight.Medium)
    }
}

/** چیپ انتخابی با پرش فنری و پرشدن گرادیانی. */
@Composable
internal fun SpringChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    accent: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit,
) {
    val scale by animateFloatAsState(
        if (selected) 1.06f else 1f,
        spring(dampingRatio = 0.42f, stiffness = 620f),
        label = "chipScale",
    )
    val bg by animateColorAsState(
        if (selected) accent.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        tween(220), label = "chipBg",
    )
    val fg by animateColorAsState(
        if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant,
        tween(220), label = "chipFg",
    )
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.6f) else Color.Transparent,
                RoundedCornerShape(14.dp),
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 13.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = fg,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
    }
}

/**
 * درخشش عبوری روی کارت‌های مهم.
 *
 * به‌جای انیمیشن روی رنگِ پس‌زمینه (که باعث recomposition می‌شود) فقط یک لایهٔ
 * گرادیانی روی محتوا کشیده می‌شود، پس هزینه‌اش در حد یک draw است.
 */
@Composable
internal fun Modifier.shimmerSweep(alpha: Float = 0.16f): Modifier {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(
        initialValue = -1f, targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerX",
    )
    return this.drawWithContent {
        drawContent()
        val w = size.width
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = alpha), Color.Transparent),
                startX = x * w - w * 0.35f,
                endX = x * w + w * 0.35f,
            ),
        )
    }
}

/** نوار رنگی کنار هر تسک: اولویت را بدون خواندن متن نشان می‌دهد. */
@Composable
internal fun PriorityStripe(priority: String, done: Boolean, height: Dp = 42.dp) {
    val (c1, c2) = priorityColors(priority)
    val a by animateFloatAsState(if (done) 0.25f else 1f, tween(400), label = "stripe")
    Box(
        Modifier
            .width(4.dp)
            .height(height)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(c1.copy(alpha = a), c2.copy(alpha = a)))),
    )
}

/** سربرگ شیت‌ها: حبابِ گرادیانی + عنوان + زیرنویس. */
@Composable
internal fun SheetHeader(emoji: String, title: String, subtitle: String? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f),
                        ),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) { Text(emoji, style = MaterialTheme.typography.titleMedium) }
        Spacer(Modifier.width(11.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
        }
    }
}

/** کارت آمار با هالهٔ رنگی. */
@Composable
internal fun GlowStatCard(
    emoji: String,
    value: String,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.20f), accent.copy(alpha = 0.06f)),
                ),
            )
            .border(1.dp, accent.copy(alpha = 0.28f), RoundedCornerShape(18.dp))
            .padding(vertical = 13.dp, horizontal = 8.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(emoji, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(5.dp))
            Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}
