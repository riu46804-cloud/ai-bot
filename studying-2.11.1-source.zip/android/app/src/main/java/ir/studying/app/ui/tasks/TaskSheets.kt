@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package ir.studying.app.ui.tasks

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.ui.graphics.graphicsLayer
import ir.studying.app.core.CourseCache
import ir.studying.app.core.Fmt
import ir.studying.app.core.fa
import ir.studying.app.data.TaskItem

/** همهٔ فیلدهای قابل‌ویرایش یک تسک در یک بسته. */
data class TaskDraft(
    val title: String = "",
    val date: String = Fmt.upcomingDays(1).first().first,
    val priority: String = "normal",
    val dueTime: String? = null,
    val repeatRule: String = "",
    val course: String = "",
    val estimateMin: Int = 0,
)

/* =============================================================================
 *  ساخت/ویرایش سریع
 *
 *  بازطراحی: انتخاب فوریت دوباره همان رادیوی رنگی حرفه‌ای برنامه است (نسخهٔ
 *  منویی حس بدی می‌داد)، و بقیهٔ تنظیم‌ها به‌جای چیپ‌های تودرتو، ردیف‌های
 *  تمیزِ «آیکن · عنوان · مقدار» داخل یک کارت‌اند که منویشان زیر خودشان باز
 *  می‌شود. ساعت هم به‌جای لیست بلند، تایم‌پیکر عقربه‌ای دارد.
 * ========================================================================== */
@Composable
fun QuickTaskSheet(
    title: String,
    initial: TaskDraft = TaskDraft(),
    busy: Boolean = false,
    compact: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (TaskDraft) -> Unit,
) {
    var text by remember { mutableStateOf(initial.title) }
    var priority by remember { mutableStateOf(initial.priority) }
    var dateIso by remember { mutableStateOf(initial.date) }
    var dueTime by remember { mutableStateOf(initial.dueTime) }
    var repeat by remember { mutableStateOf(initial.repeatRule) }
    var course by remember { mutableStateOf(initial.course) }
    var estimate by remember { mutableStateOf(initial.estimateMin) }
    var timePicker by remember { mutableStateOf(false) }
    val days = remember { Fmt.upcomingDays(21) }
    val courseNames = remember { CourseCache.peek().map { it.name } }
    val cs = MaterialTheme.colorScheme

    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(
            Modifier
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            SheetHeader("📝", title, "فقط عنوان لازم است؛ بقیه اختیاری‌اند")
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("مثلاً: حل ۲۰ تست ریاضی") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = cs.primary,
                    unfocusedBorderColor = cs.outlineVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(14.dp))
            Text(
                "فوریت",
                style = MaterialTheme.typography.labelMedium,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp, start = 2.dp),
            )
            // همان رادیوی اصلی برنامه با حلقهٔ رنگی و لرزش ریز
            ir.studying.app.ui.components.PriorityRadio(
                selected = priority,
                // ترتیب برچسب‌ها باید با keys داخل PriorityRadio یکی باشد: high, normal, low
                labels = listOf("فوری", "معمولی", "کم"),
            ) { priority = it }

            Spacer(Modifier.height(14.dp))
            OptionCard {
                if (!compact) {
                    OptionRow(
                        icon = "📅",
                        label = "روز",
                        value = days.firstOrNull { it.first == dateIso }?.second ?: Fmt.jalaliWithDay(dateIso),
                        active = dateIso != days.first().first,
                        accent = cs.primary,
                        options = days.map { it.second to it.first },
                        onPick = { dateIso = it },
                    )
                    OptionDivider()
                }
                OptionRow(
                    icon = "⏰",
                    label = "ساعت",
                    value = dueTime?.fa() ?: "تنظیم نشده",
                    active = dueTime != null,
                    accent = cs.tertiary,
                    options = emptyList(),
                    onClick = { timePicker = true },
                    onPick = {},
                )
                if (!compact) {
                    OptionDivider()
                    OptionRow(
                        icon = "🔁",
                        label = "تکرار",
                        value = repeatOptions.firstOrNull { it.second == repeat }?.first ?: "بدون تکرار",
                        active = repeat.isNotBlank(),
                        accent = cs.secondary,
                        options = repeatOptions,
                        onPick = { repeat = it },
                    )
                }
                OptionDivider()
                OptionRow(
                    icon = "📚",
                    label = "درس",
                    value = course.ifBlank { "انتخاب نشده" },
                    active = course.isNotBlank(),
                    accent = cs.primary,
                    options = listOf("بدون درس" to "") + courseNames.map { it to it },
                    onPick = { course = it },
                )
                OptionDivider()
                OptionRow(
                    icon = "⏳",
                    label = "زمان تخمینی",
                    value = if (estimate == 0) "تنظیم نشده" else minutesLabel(estimate),
                    active = estimate > 0,
                    accent = cs.secondary,
                    options = estimateOptions.map { (if (it == 0) "بدون زمان" else minutesLabel(it)) to it.toString() },
                    onPick = { estimate = it.toIntOrNull() ?: 0 },
                )
            }

            Spacer(Modifier.height(18.dp))
            GradientButton(
                text = if (busy) "در حال ذخیره…" else "ذخیره",
                enabled = text.isNotBlank() && !busy,
                busy = busy,
            ) {
                onSave(TaskDraft(text.trim(), dateIso, priority, dueTime, repeat, course.trim(), estimate))
            }
        }
    }

    if (timePicker) {
        TimePickerDialog(
            initial = dueTime,
            onDismiss = { timePicker = false },
            onClear = { dueTime = null; timePicker = false },
            onConfirm = { dueTime = it; timePicker = false },
        )
    }
}

/** کارت سفیدِ دربرگیرندهٔ ردیف‌های تنظیم. */
@Composable
private fun OptionCard(content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surfaceVariant.copy(alpha = 0.32f))
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.45f), RoundedCornerShape(18.dp)),
        content = content,
    )
}

@Composable
private fun OptionDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
    )
}

/**
 * یک ردیف تنظیم: آیکن، عنوان، مقدار فعلی و فلش.
 *
 * اگر options خالی باشد فقط onClick صدا می‌خورد (مثل ساعت که دیالوگ خودش را
 * باز می‌کند)، وگرنه منوی کشویی دقیقاً زیر همان ردیف باز می‌شود.
 */
@Composable
private fun OptionRow(
    icon: String,
    label: String,
    value: String,
    active: Boolean,
    accent: Color,
    options: List<Pair<String, String>>,
    onPick: (String) -> Unit,
    onClick: (() -> Unit)? = null,
) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val rotate by animateFloatAsState(if (open) 180f else 0f, tween(180), label = "arrow")
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { if (onClick != null) onClick() else open = true }
                .padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = if (active) 0.16f else 0.08f)),
                contentAlignment = Alignment.Center,
            ) { Text(icon, fontSize = 14.sp) }
            Spacer(Modifier.width(10.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium, color = cs.onSurface)
            Spacer(Modifier.weight(1f))
            Text(
                value,
                style = MaterialTheme.typography.labelLarge,
                color = if (active) accent else cs.onSurfaceVariant,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 150.dp),
            )
            Icon(
                Icons.Rounded.ExpandMore, null,
                tint = cs.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(18.dp).scale(1f).graphicsLayer { rotationZ = rotate },
            )
        }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            modifier = Modifier.heightIn(max = 340.dp),
        ) {
            options.forEach { (text, key) ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (text == value) FontWeight.Bold else FontWeight.Normal,
                            color = if (text == value) accent else cs.onSurface,
                        )
                    },
                    trailingIcon = {
                        if (text == value) Icon(Icons.Rounded.Check, null, tint = accent, modifier = Modifier.size(16.dp))
                    },
                    onClick = { onPick(key); open = false },
                )
            }
        }
    }
}

/** دیالوگ ساعت با تایم‌پیکر عقربه‌ای متریال + دکمهٔ «بدون ساعت». */
@Composable
internal fun TimePickerDialog(
    initial: String?,
    onDismiss: () -> Unit,
    onClear: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val h0 = initial?.substringBefore(":")?.toIntOrNull() ?: 18
    val m0 = initial?.substringAfter(":", "")?.toIntOrNull() ?: 0
    val state = rememberTimePickerState(initialHour = h0, initialMinute = m0, is24Hour = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                // با locale فارسی، String.format رقم فارسی می‌سازد و سرور نمی‌پذیرد؛
                // پس دستی و با ارقام لاتین می‌سازیم
                val h = state.hour.toString().padStart(2, '0')
                val m = state.minute.toString().padStart(2, '0')
                onConfirm("$h:$m")
            }) { Text("تأیید", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onClear) { Text("بدون ساعت", color = cs.onSurfaceVariant) }
                TextButton(onClick = onDismiss) { Text("انصراف", color = cs.onSurfaceVariant) }
            }
        },
        title = { Text("ساعت یادآوری", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
        text = {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                TimePicker(state = state)
            }
        },
        containerColor = cs.surface,
        shape = RoundedCornerShape(24.dp),
    )
}

private val repeatOptions = listOf(
    "بدون تکرار" to "",
    "هر روز" to "daily",
    "شنبه تا چهارشنبه" to "weekdays",
    "شنبه‌ها" to "dow:0",
    "یک‌شنبه‌ها" to "dow:1",
    "دوشنبه‌ها" to "dow:2",
    "سه‌شنبه‌ها" to "dow:3",
    "چهارشنبه‌ها" to "dow:4",
    "پنج‌شنبه‌ها" to "dow:5",
    "جمعه‌ها" to "dow:6",
)

private val estimateOptions = listOf(0, 15, 30, 45, 60, 90, 120, 180)

/** دکمهٔ گرادیانی مشترک شیت‌ها. */
@Composable
private fun GradientButton(text: String, enabled: Boolean, busy: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scale by animateFloatAsState(if (enabled) 1f else 0.99f, spring(dampingRatio = 0.5f), label = "btn")
    Box(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (enabled) Brush.horizontalGradient(listOf(cs.primary, cs.secondary))
                else Brush.horizontalGradient(listOf(cs.onSurface.copy(alpha = 0.12f), cs.onSurface.copy(alpha = 0.12f))),
            )
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                Spacer(Modifier.width(9.dp))
            }
            Text(
                text, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                color = if (enabled) cs.onPrimary else cs.onSurface.copy(alpha = 0.5f),
            )
        }
    }
}

/* =============================================================================
 *  جزئیات تسک — با یک لمس روی کارت باز می‌شود
 *
 *  همهٔ چیزهایی که قبلاً روی خود ردیف چپانده شده بود (زیرتسک‌ها، تاریخ‌ها،
 *  زمان صرف‌شده، کارها) اینجا جمع شده تا لیست تمیز بماند.
 * ========================================================================== */
@Composable
fun TaskDetailSheet(
    task: TaskItem,
    subtasks: List<TaskItem>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onToggle: () -> Unit,
    onToggleSub: (TaskItem) -> Unit,
    onDeleteSub: (TaskItem) -> Unit,
    onAddSub: () -> Unit,
    onEdit: () -> Unit,
    onStudy: () -> Unit,
    onMove: (String, String) -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    /* روتین: اگر این تسک از روتین آمده، برچسبش را نشان می‌دهیم؛ وگرنه دکمهٔ
       «روتینش کن» تا کاربر همان‌جا تبدیلش کند. */
    routineLabel: String? = null,
    onMakeRoutine: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val days = remember { Fmt.upcomingDays(8) }
    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 26.dp)) {
            SheetHeader(
                if (task.done) "✅" else "🎯",
                task.title,
                Fmt.jalaliWithDay(task.date) + (task.dueHm?.let { " · ساعت ${it.fa()}" } ?: ""),
            )

            Spacer(Modifier.height(14.dp))
            GradientButton(if (task.done) "برگرداندن به انجام‌نشده" else "انجام شد ✅", enabled = !busy) { onToggle() }

            // ── مشخصات ──
            val chips = buildList {
                if (task.priority == "high") add("🔥 فوری" to cs.error)
                if (task.priority == "low") add("🟢 کم‌اهمیت" to Color(0xFF10B981))
                if (task.course.isNotBlank()) add("📚 ${task.course}" to cs.primary)
                if (task.isRepeating) add("🔁 ${task.repeatLabel}" to cs.secondary)
                if (task.estimateMin > 0) add("⏳ تخمین ${minutesLabel(task.estimateMin)}" to cs.secondary)
                if (task.spentMin > 0) add("⏱ کار شده ${minutesLabel(task.spentMin)}" to cs.primary)
                if (task.movedCount > 0) add("↪️ ${task.movedCount.fa()} بار جابه‌جا شده" to Color(0xFFF59E0B))
                if (task.sharedBy.isNotBlank()) add("🎁 از @${task.sharedBy}" to cs.tertiary)
                if (!routineLabel.isNullOrBlank()) add(routineLabel to cs.primary)
            }
            if (chips.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) { chips.forEach { (t, c) -> GradientPill(t, c) } }
            }

            // نوار پیشرفت زمان
            if (task.estimateMin > 0 && task.spentMin > 0) {
                Spacer(Modifier.height(12.dp))
                val ratio = (task.spentMin.toFloat() / task.estimateMin).coerceIn(0f, 1f)
                val w by animateFloatAsState(ratio, tween(700, easing = FastOutSlowInEasing), label = "spent")
                Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.07f))) {
                    Box(
                        Modifier.fillMaxWidth(w).height(7.dp).clip(CircleShape)
                            .background(Brush.horizontalGradient(listOf(cs.primary, cs.secondary))),
                    )
                }
            }

            // ── زیرتسک‌ها ──
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("☑️ زیرتسک‌ها", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (subtasks.isNotEmpty()) {
                    Text(
                        "${subtasks.count { it.done }.fa()} از ${subtasks.size.fa()}",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (subtasks.isEmpty()) {
                Text("زیرتسکی ندارد", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
            } else {
                subtasks.forEach { sub ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(cs.surfaceVariant.copy(alpha = 0.40f))
                            .padding(horizontal = 11.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        // زیرتسک هم همان چک‌باکس ترقه‌ای و خط‌خوردگی انیمیشنی را دارد
                        ir.studying.app.ui.components.FireworkCheck(
                            checked = sub.done,
                            onToggle = { onToggleSub(sub) },
                            boxSize = 22.dp,
                            color = cs.primary,
                        )
                        Spacer(Modifier.width(7.dp))
                        Box(Modifier.weight(1f)) {
                            ir.studying.app.ui.components.SliceText(
                                text = sub.title,
                                done = sub.done,
                                style = MaterialTheme.typography.bodyMedium,
                                activeColor = cs.onSurface,
                                doneColor = cs.onSurfaceVariant,
                            )
                        }
                        Icon(
                            Icons.Rounded.Delete, "حذف",
                            tint = cs.error.copy(alpha = 0.65f),
                            modifier = Modifier.size(15.dp).clickable { onDeleteSub(sub) },
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
            Row(
                Modifier
                    .clip(RoundedCornerShape(13.dp))
                    .background(cs.primary.copy(alpha = 0.10f))
                    .clickable { onAddSub() }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("➕", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.width(6.dp))
                Text("افزودن زیرتسک", style = MaterialTheme.typography.labelMedium, color = cs.primary, fontWeight = FontWeight.Bold)
            }

            // ── کارها ──
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                ActionTile("▶️", "شروع مطالعه", cs.primary, Modifier.weight(1f), onStudy)
                ActionTile("✏️", "ویرایش", cs.secondary, Modifier.weight(1f), onEdit)
            }
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                ActionTile("🎁", "برای دوست", Color(0xFF8B5CF6), Modifier.weight(1f), onShare)
                ActionTile("🗑", "حذف", cs.error, Modifier.weight(1f), onDelete)
            }
            if (onMakeRoutine != null) {
                Spacer(Modifier.height(9.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    ActionTile("🔁", "روتینش کن", Color(0xFF10B981), Modifier.weight(1f), onMakeRoutine)
                }
            }

            // ── انتقال ──
            Spacer(Modifier.height(16.dp))
            Text("📆 انتقال به روز دیگر", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(days, key = { it.first }) { (iso, label) ->
                    SpringChip(label, task.date == iso) { onMove(iso, label) }
                }
            }
        }
    }
}

/** کاشی کار با پرش لمسی. */
@Composable
private fun ActionTile(emoji: String, label: String, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.4f, stiffness = 700f), label = "tile")
    LaunchedEffect(pressed) { if (pressed) { kotlinx.coroutines.delay(130); pressed = false } }
    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(accent.copy(alpha = 0.13f))
            .border(1.dp, accent.copy(alpha = 0.26f), RoundedCornerShape(16.dp))
            .clickable { pressed = true; onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.width(7.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = accent, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/* =============================================================================
 *  فرستادن تسک برای دوست
 * ========================================================================== */
@Composable
fun TaskShareSheet(
    task: TaskItem,
    friends: List<String>,
    onDismiss: () -> Unit,
    onSend: (String) -> Unit,
) {
    var username by remember { mutableStateOf("") }
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 26.dp)) {
            SheetHeader("🎁", "فرستادن «${task.title}»", "یک کپی برای امروزِ او ساخته می‌شود و اعلان می‌گیرد")
            Spacer(Modifier.height(14.dp))
            if (friends.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(friends, key = { it }) { f ->
                        FriendBubble(f, selected = username == f) { username = if (username == f) "" else f }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("نام کاربری") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = cs.primary,
                    unfocusedBorderColor = cs.outlineVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(14.dp))
            GradientButton("بفرست 🚀", enabled = username.isNotBlank()) { onSend(username) }
        }
    }
}

@Composable
private fun FriendBubble(username: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scale by animateFloatAsState(if (selected) 1.08f else 1f, spring(dampingRatio = 0.42f, stiffness = 600f), label = "friend")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp).clickable { onClick() }) {
        Box(
            Modifier
                .size(48.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(cs.primary, cs.tertiary)))
                .border(2.dp, if (selected) cs.primary else Color.Transparent, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(username.take(1).uppercase(), style = MaterialTheme.typography.titleMedium, color = cs.onPrimary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "@$username", style = MaterialTheme.typography.labelSmall,
            color = if (selected) cs.primary else cs.onSurfaceVariant,
            maxLines = 1, textAlign = TextAlign.Center,
        )
    }
}

/* =============================================================================
 *  آمار
 * ========================================================================== */
@Composable
fun TaskStatsSheet(stats: TaskStats?, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 26.dp)) {
            SheetHeader("📊", "عملکرد تسک‌ها", "دو هفتهٔ گذشته")
            Spacer(Modifier.height(16.dp))
            if (stats == null) {
                Box(Modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
                    ir.studying.app.ui.components.FlameLoader()
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    GlowStatCard("🔥", "${stats.streak.fa()} روز", "استریک کامل", Color(0xFFF59E0B), Modifier.weight(1f))
                    GlowStatCard("✅", "${stats.rate.fa()}٪", "نرخ انجام", cs.primary, Modifier.weight(1f))
                    GlowStatCard("⏳", minutesLabel(stats.spentMin), "روی تسک‌ها", cs.tertiary, Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("روند روزانه", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("${stats.done.fa()} از ${stats.total.fa()} تسک", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.height(10.dp))
                StatsChart(stats)
                Spacer(Modifier.height(10.dp))
                Text(
                    when {
                        stats.streak >= 3 -> "${stats.streak.fa()} روز پشت‌سرهم همهٔ تسک‌هات رو تموم کردی — ادامه بده 🔥"
                        stats.rate >= 70 -> "روند خوبیه؛ کمی دقت بیشتر و استریک کامل می‌گیری."
                        stats.total == 0 -> "هنوز داده‌ای نیست؛ چند روز تسک بنویس تا نمودار پر شود."
                        else -> "شاید تعداد تسک‌های روزانه‌ات از توانت بیشتر است؛ کمترش کن تا استریک بگیری."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
        }
    }
}

/** نمودار ستونی با رشد پلکانی و رنگ بر اساس نرخ انجام. */
@Composable
private fun StatsChart(stats: TaskStats) {
    var play by remember { mutableStateOf(false) }
    LaunchedEffect(stats) { play = false; kotlinx.coroutines.delay(60); play = true }
    val grow by animateFloatAsState(if (play) 1f else 0f, tween(900, easing = FastOutSlowInEasing), label = "grow")
    val cs = MaterialTheme.colorScheme
    val good = cs.primary
    val mid = Color(0xFFF59E0B)
    val bad = cs.error
    val track = cs.onSurface.copy(alpha = 0.06f)
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val n = stats.days.size.coerceAtLeast(1)
        val gap = 6f
        val w = (size.width - gap * (n - 1)) / n
        stats.days.forEachIndexed { i, d ->
            val x = i * (w + gap)
            drawRoundRect(color = track, topLeft = Offset(x, 0f), size = Size(w, size.height), cornerRadius = CornerRadius(7f, 7f))
            val frac = if (d.total > 0) d.done.toFloat() / d.total else 0f
            val local = ((grow * n) - i).coerceIn(0f, 1f)
            val h = size.height * frac * local
            if (h > 1f) {
                val c = when {
                    frac >= 0.999f -> good
                    frac >= 0.5f -> mid
                    else -> bad
                }
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(c, c.copy(alpha = 0.55f)), startY = size.height - h, endY = size.height),
                    topLeft = Offset(x, size.height - h),
                    size = Size(w, h),
                    cornerRadius = CornerRadius(7f, 7f),
                )
            }
        }
    }
}
