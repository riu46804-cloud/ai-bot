@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package ir.studying.app.ui.tasks

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.studying.app.core.Fmt
import ir.studying.app.core.fa
import ir.studying.app.data.TaskItem
import ir.studying.app.ui.components.AppSnack
import ir.studying.app.ui.components.ErrorState
import ir.studying.app.ui.components.FadeSlideIn
import ir.studying.app.ui.components.LoadingBox
import ir.studying.app.ui.components.Refreshable
import ir.studying.app.ui.components.SegmentedTabs
import ir.studying.app.ui.nav.LocalBottomBarPadding
import ir.studying.app.ui.theme.brandGradient
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * صفحهٔ تسک‌ها.
 *
 * بازطراحی دوم، بر اساس بازخورد: نوار بالا کوتاه شد، زیرتسک‌ها دیگر در لیست
 * اصلی تکرار نمی‌شوند (و در شمارش روز هم نمی‌آیند)، هر کارت با یک لمس جزئیات
 * کامل را باز می‌کند و کارتِ انجام‌شده به‌جای لایه‌های روی‌هم فقط کم‌رنگ و
 * خط‌خورده می‌شود.
 */
@Composable
fun TasksScreen(vm: TasksViewModel = viewModel(), rvm: RoutinesViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val routineState by rvm.state.collectAsState()
    LaunchedEffect(Unit) { vm.refresh() }
    LaunchedEffect(Unit) {
        ir.studying.app.core.RefreshBus.events.collect { if (it == "tasks" || it == "all") vm.refresh() }
    }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showStats by remember { mutableStateOf(false) }
    var detailId by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<TaskItem?>(null) }
    var sharing by remember { mutableStateOf<TaskItem?>(null) }
    var subFor by remember { mutableStateOf<TaskItem?>(null) }
    // روتین‌ها: فرم ساخت/ویرایش و تبدیل یک تسک به روتین
    var routineEditor by remember { mutableStateOf(false) }
    var editingRoutine by remember { mutableStateOf<ir.studying.app.data.Routine?>(null) }
    var makeRoutineOf by remember { mutableStateOf<TaskItem?>(null) }
    val busy by vm.busy.collectAsState()
    val adding by vm.adding.collectAsState()

    Scaffold(
        containerColor = Color.Transparent,
        floatingActionButton = {
            // در تب روتین‌ها دکمهٔ شناور هم روتین می‌سازد، نه تسک
            AddFab { if (tab == 1) { editingRoutine = null; routineEditor = true } else showAdd = true }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            // در تب روتین‌ها همین نوار، پیشرفت روتین‌های امروز را نشان می‌دهد
            // (باکس خلاصهٔ تکراریِ داخل لیست حذف شد).
            TasksHeaderBar(
                state = state,
                routines = if (tab == 1) routineState else null,
                onStats = { vm.loadStats(); showStats = true },
            )

            AnimatedVisibility(
                visible = tab == 0 && state.overdue.isNotEmpty(),
                enter = expandVertically(tween(300, easing = FastOutSlowInEasing)) + fadeIn(tween(240)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(140)),
            ) {
                CarryBanner(count = state.overdue.size) { vm.carryOver() }
            }

            SegmentedTabs(
                options = listOf(
                    "امروز" + countSuffix(state.todayMain.size),
                    "روتین‌ها" + countSuffix(routineState.active.size),
                    "آینده" + countSuffix(state.upcoming.count { it.parentId == 0 }),
                    "تاریخچه",
                ),
                selected = tab,
                modifier = Modifier.padding(horizontal = 16.dp),
            ) { tab = it }

            if (state.courses.isNotEmpty() && tab != 1) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item { SpringChip("همه", state.courseFilter == null) { vm.setCourseFilter(null) } }
                    items(state.courses, key = { it }) { c ->
                        SpringChip("📚 $c", state.courseFilter == c) {
                            vm.setCourseFilter(if (state.courseFilter == c) null else c)
                        }
                    }
                }
            } else {
                Spacer(Modifier.height(6.dp))
            }

            // فقط تسک‌های اصلی در لیست؛ زیرتسک‌ها داخل جزئیات همان تسک دیده می‌شوند.
            val list = when (tab) {
                0 -> state.today
                2 -> state.upcoming
                3 -> state.history
                else -> emptyList()
            }.filter { it.parentId == 0 }
                .filter { state.courseFilter == null || it.course == state.courseFilter }

            var order by remember(tab) { mutableStateOf(list) }
            LaunchedEffect(list) { order = list }
            var dragId by remember { mutableIntStateOf(0) }
            val dragAcc = remember { androidx.compose.runtime.mutableFloatStateOf(0f) }

            when {
                tab == 1 -> RoutinesTab(
                    vm = rvm,
                    bottomPadding = LocalBottomBarPadding.current.calculateBottomPadding(),
                    onCreate = { editingRoutine = null; routineEditor = true },
                    onEdit = { r -> editingRoutine = r; routineEditor = true },
                )
                state.loading -> LoadingBox(height = 200.dp)
                state.error != null -> ErrorState(state.error ?: "", onRetry = { vm.refresh() })
                order.isEmpty() -> TasksEmpty(tab)
                else -> Refreshable(onRefresh = { vm.refresh() }) {
                    LazyColumn(
                        contentPadding = PaddingValues(
                            start = 16.dp, end = 16.dp, top = 8.dp,
                            bottom = 16.dp + LocalBottomBarPadding.current.calculateBottomPadding(),
                        ),
                        verticalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        itemsIndexed(order, key = { _, t -> t.id }) { i, task ->
                            Box(Modifier.animateItemPlacement(tween(300))) {
                                FadeSlideIn(i) {
                                    TaskRow(
                                        task = task,
                                        routineTag = routineState.map[task.routineId]
                                            ?.let { r -> "${r.emoji} ${r.title}" },
                                        subCount = state.subtasksOf(task.id).size,
                                        subDone = state.subtasksOf(task.id).count { it.done },
                                        showDate = tab != 0,
                                        busy = busy.contains(task.id),
                                        dragging = dragId == task.id,
                                        onToggle = {
                                            vm.toggle(task)
                                            // شمارش روتین بدون انتظار برای سرور تکان بخورد
                                            rvm.bumpLocal(task.routineId, if (task.done) -1 else 1)
                                        },
                                        onDelete = { vm.delete(task) },
                                        onOpen = { detailId = task.id },
                                        onDrag = { delta, rowPx, end ->
                                            if (end) {
                                                dragId = 0; dragAcc.floatValue = 0f
                                                vm.reorder(order.map { it.id })
                                            } else {
                                                dragId = task.id
                                                dragAcc.floatValue += delta
                                                val idx = order.indexOfFirst { it.id == task.id }
                                                if (idx >= 0 && dragAcc.floatValue > rowPx && idx < order.lastIndex) {
                                                    order = order.toMutableList().also { l -> l.add(idx + 1, l.removeAt(idx)) }
                                                    dragAcc.floatValue -= rowPx
                                                } else if (idx > 0 && dragAcc.floatValue < -rowPx) {
                                                    order = order.toMutableList().also { l -> l.add(idx - 1, l.removeAt(idx)) }
                                                    dragAcc.floatValue += rowPx
                                                }
                                            }
                                        },
                                    )
                                }
                            }
                        }
                        item { Spacer(Modifier.height(76.dp)) }
                    }
                }
            }
        }
    }

    // ---------------- شیت‌ها ----------------
    if (showAdd) {
        QuickTaskSheet(
            title = "تسک جدید",
            busy = adding,
            onDismiss = { if (!adding) showAdd = false },
            onSave = { d ->
                vm.add(d.title, d.date, d.priority, d.dueTime, d.repeatRule, d.course, d.estimateMin) { err ->
                    AppSnack.show(err ?: "تسک اضافه شد ✅")
                    if (err == null) showAdd = false
                }
            },
        )
    }

    val detail = state.byId(detailId)
    if (detailId != 0 && detail != null) {
        TaskDetailSheet(
            task = detail,
            subtasks = state.subtasksOf(detail.id),
            busy = busy.contains(detail.id),
            onDismiss = { detailId = 0 },
            onToggle = {
                vm.toggle(detail)
                rvm.bumpLocal(detail.routineId, if (detail.done) -1 else 1)
            },
            onToggleSub = { vm.toggle(it) },
            onDeleteSub = { vm.delete(it) },
            onAddSub = { subFor = detail },
            onEdit = { editing = detail; detailId = 0 },
            onStudy = { detailId = 0; vm.startStudy(detail) },
            onMove = { iso, label -> vm.move(detail, iso, label) },
            onShare = { vm.loadFriends(); sharing = detail; detailId = 0 },
            onDelete = { detailId = 0; vm.delete(detail) },
            routineLabel = routineState.map[detail.routineId]?.let { "🔁 ${it.emoji} ${it.title}" },
            onMakeRoutine = if (detail.routineId == 0) {
                { makeRoutineOf = detail; detailId = 0 }
            } else null,
        )
    }

    editing?.let { t ->
        QuickTaskSheet(
            title = "ویرایش تسک",
            initial = TaskDraft(t.title, t.date, t.priority, t.dueHm, t.repeatRule, t.course, t.estimateMin),
            busy = busy.contains(t.id),
            onDismiss = { editing = null },
            onSave = { d ->
                vm.edit(t, d.title, d.date, d.priority, d.dueTime, d.repeatRule, d.course, d.estimateMin) { err ->
                    AppSnack.show(err ?: "ذخیره شد ✅")
                    if (err == null) editing = null
                }
            },
        )
    }

    subFor?.let { parent ->
        QuickTaskSheet(
            title = "زیرتسک برای «${parent.title}»",
            initial = TaskDraft("", parent.date, parent.priority, null, "", parent.course, 0),
            busy = adding,
            compact = true,
            onDismiss = { subFor = null },
            onSave = { d ->
                vm.add(d.title, parent.date, d.priority, d.dueTime, "", d.course, d.estimateMin, parentId = parent.id) { err ->
                    AppSnack.show(err ?: "زیرتسک اضافه شد ✅")
                    if (err == null) subFor = null
                }
            },
        )
    }

    sharing?.let { t ->
        val friends by vm.friends.collectAsState()
        TaskShareSheet(
            task = t,
            friends = friends,
            onDismiss = { sharing = null },
            onSend = { u ->
                vm.share(t, u) { err ->
                    AppSnack.show(err ?: "تسک برای @$u فرستاده شد ✅")
                    if (err == null) sharing = null
                }
            },
        )
    }

    if (routineEditor) {
        RoutineEditorSheet(
            initial = editingRoutine,
            saving = routineState.saving,
            onDismiss = { routineEditor = false },
            onSave = { t, e, d, st, its ->
                rvm.save(editingRoutine?.id ?: 0, t, e, d, st, its, active = editingRoutine?.active ?: true) { err ->
                    AppSnack.show(err ?: "روتین ذخیره شد ✅")
                    if (err == null) { routineEditor = false; vm.refresh() }
                }
            },
        )
    }

    makeRoutineOf?.let { t ->
        MakeRoutineSheet(
            taskTitle = t.title,
            onDismiss = { makeRoutineOf = null },
            onConfirm = { d, e ->
                rvm.fromTask(t.id, t.title, d, e) { err ->
                    AppSnack.show(err ?: "روتین ساخته شد 🔁")
                    if (err == null) { makeRoutineOf = null; vm.refresh() }
                }
            },
        )
    }

    if (showStats) TaskStatsSheet(stats = state.stats, onDismiss = { showStats = false })
}

/* =============================================================================
 *  نوار بالا — عمداً کوتاه
 *
 *  نسخهٔ قبلی یک کارت بلند بود که نصف صفحه را می‌خورد. حالا یک نوار یک‌خطی
 *  است: حلقهٔ کوچک درصد، عنوان، شمارش و دکمهٔ آمار.
 * ========================================================================== */
@Composable
private fun TasksHeaderBar(
    state: TasksViewModel.State,
    routines: RoutinesViewModel.State? = null,
    onStats: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val main = state.todayMain
    val routineMode = routines != null
    val total = if (routineMode) routines.todayTotal else main.size
    val done = if (routineMode) routines.todayDone else main.count { it.done }
    val frac = if (total == 0) 0f else done.toFloat() / total
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProgressRing(progress = frac, size = 42.dp, stroke = 5.dp) {
            if (total > 0 && done >= total) {
                Text("🏆", style = MaterialTheme.typography.labelMedium)
            } else {
                Text("${(frac * 100).toInt().fa()}٪", style = MaterialTheme.typography.labelSmall, color = cs.primary)
            }
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (routineMode) "روتین‌های امروز" else "تسک‌های امروز",
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedCount(done, MaterialTheme.typography.labelMedium, cs.primary)
                Text(
                    if (routineMode) {
                        " از ${total.fa()} کار" +
                            (routines.bestStreak.takeIf { it > 0 }?.let { " · 🔥 ${it.fa()} روز" } ?: "")
                    } else {
                        " از ${total.fa()}" +
                            if (state.todayLoadMin > 0) " · ${minutesLabel(state.todayLoadMin)} کار مانده" else ""
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(cs.primary.copy(alpha = 0.10f))
                .clickable { onStats() },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.BarChart, "آمار تسک‌ها", tint = cs.primary, modifier = Modifier.size(18.dp)) }
    }
}

/** دکمهٔ افزودن با هالهٔ نبض‌دار. */
@Composable
private fun AddFab(onClick: () -> Unit) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val t = rememberInfiniteTransition(label = "fab")
    val halo by t.animateFloat(
        initialValue = 1f, targetValue = 1.22f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "fabHalo",
    )
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(74.dp)) {
        Box(
            Modifier.size(58.dp).scale(halo).clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
        )
        Surface(
            shape = CircleShape,
            color = Color.Transparent,
            shadowElevation = 10.dp,
            modifier = Modifier.size(58.dp),
            onClick = {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                onClick()
            },
        ) {
            Box(Modifier.background(brandGradient()), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Add, "تسک جدید", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(26.dp))
            }
        }
    }
}

/** نوار پیشنهاد انتقال کارهای عقب‌افتاده. */
@Composable
private fun CarryBanner(count: Int, onCarry: () -> Unit) {
    val amber = Color(0xFFF59E0B)
    Row(
        Modifier
            .padding(horizontal = 16.dp)
            .padding(bottom = 6.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(amber.copy(alpha = 0.13f))
            .border(1.dp, amber.copy(alpha = 0.30f), RoundedCornerShape(15.dp))
            .clickable { onCarry() }
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("⏳", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(8.dp))
        Text(
            "${count.fa()} تسک عقب‌افتاده",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f),
        )
        Text("انتقال به امروز", style = MaterialTheme.typography.labelMedium, color = amber, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(4.dp))
        Icon(Icons.Rounded.Update, null, tint = amber, modifier = Modifier.size(14.dp))
    }
}

/* =============================================================================
 *  ردیف تسک
 *
 *  ساختار عمداً تخت است (یک Surface و یک Row): نسخهٔ قبلی چند Box روی‌هم و
 *  سایه داشت و در حالت «انجام‌شده» تو در تو و به‌هم‌ریخته دیده می‌شد.
 * ========================================================================== */
@Composable
private fun TaskRow(
    task: TaskItem,
    routineTag: String? = null,
    subCount: Int,
    subDone: Int,
    showDate: Boolean,
    busy: Boolean,
    dragging: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onOpen: () -> Unit,
    onDrag: (delta: Float, rowPx: Float, end: Boolean) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val accent = priorityColors(task.priority).first
    val bg by animateColorAsState(
        if (task.done) cs.surfaceVariant.copy(alpha = 0.45f) else cs.surface,
        tween(300), label = "rowBg",
    )
    val lift by animateFloatAsState(if (dragging) 1.02f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "lift")

    /*
     * کشیدن افقی حذف شد: با اسکرول عمودی لیست قاطی می‌شد و عملاً کار نمی‌کرد.
     * حذف حالا از شیت جزئیات انجام می‌شود و تیک هم روی خود دایره است.
     */
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = bg,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            when {
                dragging -> cs.primary.copy(alpha = 0.5f)
                task.done -> Color.Transparent
                task.priority == "high" -> accent.copy(alpha = 0.32f)
                else -> cs.outlineVariant.copy(alpha = 0.5f)
            },
        ),
        modifier = Modifier
            .fillMaxWidth()
            .scale(lift)
            // لمس طولانی = جابه‌جایی ترتیب
            .pointerInput(task.id) {
                val rowPx = 72.dp.toPx()
                detectDragGesturesAfterLongPress(
                    onDragStart = { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) },
                    onDragEnd = { onDrag(0f, rowPx, true) },
                    onDragCancel = { onDrag(0f, rowPx, true) },
                    onDrag = { change, amount -> change.consume(); onDrag(amount.y, rowPx, false) },
                )
            },
    ) {
        Row(
            Modifier
                .clickable(enabled = !busy) { onOpen() }
                .padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // چک‌باکس اصلی برنامه (ترقه + لرزش)
            ir.studying.app.ui.components.FireworkCheck(
                checked = task.done,
                onToggle = onToggle,
                enabled = !busy,
                busy = busy,
                color = if (task.priority == "high") cs.error else cs.primary,
            )
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                // خط‌خوردگی انیمیشنی به‌جای TextDecoration ثابت
                ir.studying.app.ui.components.SliceText(
                    text = task.title,
                    done = task.done,
                    style = MaterialTheme.typography.bodyLarge,
                    activeColor = cs.onSurface,
                    doneColor = cs.onSurfaceVariant,
                )
                val meta = taskMeta(task, subCount, subDone, showDate, routineTag)
                if (meta.isNotEmpty()) {
                    Spacer(Modifier.height(5.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        meta.forEach { (text, color) -> GradientPill(text, color) }
                    }
                }
            }
            Icon(
                Icons.Rounded.Delete, "حذف",
                tint = cs.error.copy(alpha = 0.55f),
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .clickable(enabled = !busy) { onDelete() },
            )
            Spacer(Modifier.width(6.dp))
            Icon(
                Icons.Rounded.ChevronLeft, null,
                tint = cs.onSurfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

/** برچسب‌های کوتاه زیر عنوان؛ فهرست (متن، رنگ). */
@Composable
private fun taskMeta(
    task: TaskItem,
    subCount: Int,
    subDone: Int,
    showDate: Boolean,
    routineTag: String? = null,
): List<Pair<String, Color>> {
    val cs = MaterialTheme.colorScheme
    val out = mutableListOf<Pair<String, Color>>()
    // تسکِ متعلق به روتین باید در نگاه اول معلوم باشد
    if (!routineTag.isNullOrBlank()) out += routineTag to cs.primary
    if (task.priority == "high" && !task.done) out += "فوری" to cs.error
    task.dueHm?.let { out += "⏰ ${it.fa()}" to cs.tertiary }
    if (subCount > 0) out += "☑️ ${subDone.fa()}/${subCount.fa()}" to cs.primary
    if (task.course.isNotBlank()) out += "📚 ${task.course}" to cs.primary
    if (task.isRepeating) out += "🔁" to cs.secondary
    if (task.spentMin > 0) out += "⏳ ${minutesLabel(task.spentMin)}" to cs.secondary
    else if (task.estimateMin > 0) out += "⏳ ${minutesLabel(task.estimateMin)}" to cs.secondary
    if (task.sharedBy.isNotBlank()) out += "🎁 @${task.sharedBy}" to cs.tertiary
    if (showDate && task.date.isNotBlank()) out += Fmt.jalaliWithDay(task.date) to cs.onSurfaceVariant
    return out
}

/** «امروز · ۵» */
private fun countSuffix(n: Int): String = if (n > 0) " · ${n.fa()}" else ""

/** حالت خالی با ایموجی شناور. */
@Composable
private fun TasksEmpty(tab: Int) {
    val t = rememberInfiniteTransition(label = "empty")
    val float by t.animateFloat(
        initialValue = -5f, targetValue = 5f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "emptyFloat",
    )
    val cs = MaterialTheme.colorScheme
    // شمارهٔ تب‌ها بعد از اضافه‌شدن «روتین‌ها» جابه‌جا شد: ۰ امروز، ۲ آینده، ۳ تاریخچه
    val emoji = when (tab) { 0 -> "🌤"; 2 -> "🔮"; else -> "📜" }
    val title = when (tab) { 0 -> "امروز هنوز خالیه"; 2 -> "برای روزهای بعد چیزی ننوشتی"; else -> "تاریخچه‌ای نیست" }
    val hint = when (tab) {
        0 -> "با دکمهٔ + اولین کار امروزت رو بنویس."
        2 -> "کارهای هفتهٔ بعدت رو از الان بچین تا ذهنت آزاد بشه."
        else -> "هر تسکی که روزش بگذرد اینجا بایگانی می‌شود."
    }
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .offset { IntOffset(0, float.roundToInt()) }
                .size(84.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.20f), Color.Transparent))),
            contentAlignment = Alignment.Center,
        ) { Text(emoji, style = MaterialTheme.typography.displaySmall) }
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(hint, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

/** "۱ ساعت و ۳۰ دقیقه" / "۴۵ دقیقه" */
internal fun minutesLabel(min: Int): String {
    if (min <= 0) return "۰ دقیقه"
    val h = min / 60
    val m = min % 60
    return when {
        h > 0 && m > 0 -> "${h.fa()} ساعت و ${m.fa()} دقیقه"
        h > 0 -> "${h.fa()} ساعت"
        else -> "${m.fa()} دقیقه"
    }
}
