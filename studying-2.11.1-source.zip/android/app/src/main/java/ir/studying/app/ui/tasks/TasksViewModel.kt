package ir.studying.app.ui.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.studying.app.core.Api
import ir.studying.app.core.RefreshBus
import ir.studying.app.core.TaskFocus
import ir.studying.app.core.humanizeError
import ir.studying.app.data.TaskItem
import ir.studying.app.ui.components.AppSnack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** آمار تسک برای شیت «عملکرد». */
data class TaskDayStat(val date: String, val total: Int, val done: Int, val spentMin: Int)

data class TaskStats(
    val days: List<TaskDayStat> = emptyList(),
    val streak: Int = 0,
    val total: Int = 0,
    val done: Int = 0,
    val spentMin: Int = 0,
    val rate: Int = 0,
)

/**
 * منطق صفحهٔ تسک.
 *
 * نسخهٔ قبلی فقط add/toggle/rename/delete داشت. کارهای تازه (یادآور ساعتی،
 * تکرار، درس، تخمین، زیرتسک، ترتیب دستی، انتقال، آمار و اشتراک با دوست) همگی
 * اینجا جمع شده‌اند تا UI فقط نمایش باشد.
 */
class TasksViewModel : ViewModel() {
    data class State(
        val loading: Boolean = true,
        val error: String? = null,
        val today: List<TaskItem> = emptyList(),
        val upcoming: List<TaskItem> = emptyList(),
        val history: List<TaskItem> = emptyList(),
        val stats: TaskStats? = null,
        val courseFilter: String? = null,
    ) {
        /*
         * زیرتسک‌ها نباید در شمارش بالای صفحه بیایند؛ قبلاً می‌آمدند و درصد
         * روز با هر زیرتسک عوض می‌شد، که اشتباه بود: زیرتسک جزئی از یک کار است.
         */
        val todayMain: List<TaskItem> get() = today.filter { it.parentId == 0 }
        /** تسک‌های عقب‌افتاده‌ای که هنوز انجام نشده‌اند (نامزد انتقال به امروز). */
        val overdue: List<TaskItem> get() = history.filter { !it.done && it.parentId == 0 }
        /** بار امروز بر حسب دقیقه = جمع تخمین تسک‌های باقی‌مانده. */
        val todayLoadMin: Int get() = todayMain.filter { !it.done }.sumOf { it.estimateMin }
        val courses: List<String>
            get() = (today + upcoming + history).map { it.course }.filter { it.isNotBlank() }.distinct().sorted()
        /** زیرتسک‌های یک تسک، از هر سه لیست. */
        fun subtasksOf(parentId: Int): List<TaskItem> =
            (today + upcoming + history).filter { it.parentId == parentId }
        fun byId(id: Int): TaskItem? = (today + upcoming + history).firstOrNull { it.id == id }
    }

    val state = MutableStateFlow(State())
    val busy = MutableStateFlow<Set<Int>>(emptySet())
    val hidden = MutableStateFlow<Set<Int>>(emptySet())
    val adding = MutableStateFlow(false)
    /** نام کاربری کسانی که دنبال می‌کنیم؛ برای شیت «فرستادن تسک». */
    val friends = MutableStateFlow<List<String>>(emptyList())

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            state.update { it.copy(error = null) }
            try {
                loadLists()
            } catch (e: Exception) {
                state.update { it.copy(loading = false, error = e.message ?: "خطا") }
            }
        }
    }

    private suspend fun loadLists() {
        val today = TaskItem.list(Api.arr(Api.get("tasks")))
        val upcoming = TaskItem.list(Api.arr(Api.get("tasks_upcoming")))
        val history = TaskItem.list(Api.arr(Api.get("tasks_history")))
        state.update { it.copy(loading = false, error = null, today = today, upcoming = upcoming, history = history) }
        // آلارم‌های امروز هر بار با لیست تازه هم‌خوان می‌شوند؛ تسکِ تیک‌خورده دیگر زنگ نمی‌زند.
        runCatching { ir.studying.app.notify.TaskAlarm.sync(ir.studying.app.App.instance, today) }
        // ویجت خانه از همین عکس فوری می‌خواند؛ پس بدون شبکه هم به‌روز می‌ماند.
        runCatching { ir.studying.app.widget.TaskSnapshot.save(ir.studying.app.App.instance, today) }
    }

    private suspend fun refreshNow() {
        runCatching { loadLists() }
        RefreshBus.emit("home")
        // تب روتین‌ها باید بلافاصله پیشرفت تازه را بگیرد (تیک/حذف تسکِ روتین).
        RefreshBus.emit("routines")
    }

    fun setCourseFilter(c: String?) = state.update { it.copy(courseFilter = c) }

    /** ساخت تسک با همهٔ فیلدهای تازه. پارامترهای خالی به سرور فرستاده نمی‌شوند. */
    fun add(
        title: String,
        date: String,
        priority: String,
        dueTime: String? = null,
        repeatRule: String = "",
        course: String = "",
        estimateMin: Int = 0,
        parentId: Int = 0,
        onResult: (String?) -> Unit = {},
    ) {
        viewModelScope.launch {
            adding.value = true
            try {
                val body = JSONObject()
                    .put("title", title).put("task_date", date).put("priority", priority)
                    .put("repeat_rule", repeatRule).put("course", course)
                    .put("estimate_min", estimateMin).put("parent_id", parentId)
                if (!dueTime.isNullOrBlank()) body.put("due_time", dueTime)
                Api.post("tasks", body)
                refreshNow()
                onResult(null)
            } catch (e: Exception) {
                onResult(humanizeError(e))
            } finally {
                adding.value = false
            }
        }
    }

    /**
     * ویرایش کامل تسک. `done` همیشه فرستاده می‌شود چون سرورهای قدیمی‌تر فقط
     * همان را می‌فهمند و بدون آن وضعیت تیک عوض می‌شد.
     */
    fun edit(
        task: TaskItem,
        title: String = task.title,
        date: String = task.date,
        priority: String = task.priority,
        dueTime: String? = task.dueTime,
        repeatRule: String = task.repeatRule,
        course: String = task.course,
        estimateMin: Int = task.estimateMin,
        onResult: (String?) -> Unit = {},
    ) {
        val t = title.trim()
        if (t.isEmpty()) { onResult("عنوان خالی است"); return }
        viewModelScope.launch {
            busy.update { it + task.id }
            val body = JSONObject()
                .put("title", t).put("done", if (task.done) 1 else 0)
                .put("task_date", date).put("priority", priority)
                .put("due_time", dueTime ?: "")
                .put("repeat_rule", repeatRule).put("course", course)
                .put("estimate_min", estimateMin)
            val res = runCatching { Api.put("tasks", body, "id" to task.id.toString()) }
            refreshNow()
            busy.update { it - task.id }
            onResult(res.exceptionOrNull()?.let { humanizeError(it) })
        }
    }

    fun rename(task: TaskItem, title: String, onResult: (String?) -> Unit = {}) =
        edit(task, title = title, onResult = onResult)

    fun toggle(task: TaskItem) {
        viewModelScope.launch {
            busy.update { it + task.id }
            state.update { s ->
                fun flip(l: List<TaskItem>) = l.map { if (it.id == task.id) it.copy(done = !it.done) else it }
                s.copy(today = flip(s.today), upcoming = flip(s.upcoming), history = flip(s.history))
            }
            runCatching {
                Api.put("tasks", JSONObject().put("done", if (task.done) 0 else 1), "id" to task.id.toString())
            }
            // تسکِ انجام‌شده نباید بعداً زنگ یادآوری بزند.
            if (!task.done) runCatching { ir.studying.app.notify.TaskAlarm.cancel(ir.studying.app.App.instance, task.id) }
            refreshNow()
            busy.update { it - task.id }
        }
    }

    /**
     * حذف تسک.
     *
     * باگی که اینجا رفع شد: قبلاً حذف واقعی داخل `onCommit` اسنک‌بار انجام
     * می‌شد، یعنی فقط وقتی اسنک‌بار «به‌درستی» بسته می‌شد. اگر کاربر صفحه را
     * عوض می‌کرد، پاپ‌آپ تسک‌های صفحهٔ مطالعه باز بود یا اسنک‌بار اصلاً نمایش
     * داده نمی‌شد (کالکتور فعال نبود)، هیچ درخواستی به سرور نمی‌رفت و تسک با
     * اولین رفرش برمی‌گشت. حالا حذف بلافاصله روی سرور انجام می‌شود و «برگرداندن»
     * تسک را دوباره می‌سازد.
     */
    fun delete(task: TaskItem) {
        val subs = state.value.subtasksOf(task.id)
        val app = ir.studying.app.App.instance
        hidden.update { it + task.id }
        state.update { s ->
            fun rm(l: List<TaskItem>) = l.filterNot { it.id == task.id || it.parentId == task.id }
            s.copy(today = rm(s.today), upcoming = rm(s.upcoming), history = rm(s.history))
        }
        viewModelScope.launch {
            busy.update { it + task.id }
            val ok = runCatching {
                // زیرتسک‌ها هم پاک شوند تا ردیف یتیم نماند (سرور جدید خودش هم می‌کند)
                subs.forEach { runCatching { Api.delete("tasks", "id" to it.id.toString()) } }
                Api.delete("tasks", "id" to task.id.toString())
            }.isSuccess
            runCatching { ir.studying.app.notify.TaskAlarm.cancel(app, task.id) }
            refreshNow()
            busy.update { it - task.id }
            hidden.update { it - task.id }
            if (ok) {
                AppSnack.undoable("تسک حذف شد", onUndo = { restore(task, subs) })
            } else {
                AppSnack.show("حذف نشد؛ اتصال اینترنت را بررسی کن")
            }
        }
    }

    /** بازسازی تسکِ حذف‌شده (شناسهٔ تازه می‌گیرد؛ محتوا همان است). */
    private fun restore(task: TaskItem, subs: List<TaskItem>) {
        viewModelScope.launch {
            val res = runCatching {
                val body = JSONObject()
                    .put("title", task.title).put("task_date", task.date)
                    .put("priority", task.priority).put("repeat_rule", task.repeatRule)
                    .put("course", task.course).put("estimate_min", task.estimateMin)
                    .put("sort_order", task.sortOrder)
                if (!task.dueTime.isNullOrBlank()) body.put("due_time", task.dueTime)
                val o = Api.obj(Api.post("tasks", body))
                val newId = o.optInt("id")
                subs.forEach { sub ->
                    val sb = JSONObject()
                        .put("title", sub.title).put("task_date", sub.date)
                        .put("priority", sub.priority).put("course", sub.course)
                        .put("estimate_min", sub.estimateMin).put("parent_id", newId)
                    runCatching { Api.post("tasks", sb) }
                }
                newId
            }
            refreshNow()
            AppSnack.show(if (res.isSuccess) "برگشت ✅" else "برگرداندن ناموفق بود")
        }
    }

    /** انتقال یک تسک به تاریخ دیگر (پیش‌فرض فردا). */
    fun move(task: TaskItem, date: String, label: String = "فردا") {
        viewModelScope.launch {
            busy.update { it + task.id }
            val res = runCatching { Api.post("task_move", JSONObject().put("id", task.id).put("date", date)) }
            refreshNow()
            busy.update { it - task.id }
            AppSnack.show(if (res.isSuccess) "منتقل شد به $label" else "انتقال نشد")
        }
    }

    /** همهٔ عقب‌افتاده‌های انجام‌نشده را می‌آورد به امروز. */
    fun carryOver(onDone: (Int) -> Unit = {}) {
        viewModelScope.launch {
            val res = runCatching { Api.obj(Api.post("tasks_carry", JSONObject())) }
            val moved = res.getOrNull()?.optInt("moved", 0) ?: 0
            refreshNow()
            onDone(moved)
            AppSnack.show(if (res.isSuccess) "$moved تسک به امروز منتقل شد" else "انتقال نشد")
        }
    }

    /** ترتیب دستی: لیست idها به همان ترتیبی که کاربر چید. */
    fun reorder(ids: List<Int>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            runCatching { Api.post("task_reorder", JSONObject().put("ids", arr)) }
            refreshNow()
        }
    }

    /** فرستادن تسک برای یک دوست (چالش دوستانه). */
    fun share(task: TaskItem, username: String, onResult: (String?) -> Unit) {
        val u = username.trim().removePrefix("@")
        if (u.isEmpty()) { onResult("نام کاربری را بنویس"); return }
        viewModelScope.launch {
            val res = runCatching {
                Api.obj(Api.post("task_share", JSONObject().put("id", task.id).put("username", u)))
            }
            val err = res.exceptionOrNull()?.let { humanizeError(it) } ?: res.getOrNull()?.optString("error").orEmpty()
            onResult(err.ifBlank { null })
        }
    }

    fun loadFriends() {
        if (friends.value.isNotEmpty()) return
        viewModelScope.launch {
            runCatching {
                val a = Api.arr(Api.get("following"))
                (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("username") }.filter { it.isNotBlank() }
            }.onSuccess { friends.value = it }
        }
    }

    fun loadStats(days: Int = 14) {
        viewModelScope.launch {
            runCatching {
                val o = Api.obj(Api.get("tasks_stats", "days" to days.toString()))
                val arr = o.optJSONArray("days")
                val list = (0 until (arr?.length() ?: 0)).mapNotNull { i ->
                    arr?.optJSONObject(i)?.let {
                        TaskDayStat(it.optString("date"), it.optInt("total"), it.optInt("done"), it.optInt("spent_min"))
                    }
                }
                TaskStats(list, o.optInt("streak"), o.optInt("total"), o.optInt("done"), o.optInt("spent_min"), o.optInt("rate"))
            }.onSuccess { st -> state.update { it.copy(stats = st) } }
        }
    }

    /** «شروع مطالعه روی این تسک» — تایمر و تسک را به هم وصل می‌کند. */
    fun startStudy(task: TaskItem) {
        TaskFocus.select(task.id, task.title)
        ir.studying.app.core.NavBus.requestStudy()
        AppSnack.show("تایمر روی «${task.title}» تنظیم شد")
    }
}
