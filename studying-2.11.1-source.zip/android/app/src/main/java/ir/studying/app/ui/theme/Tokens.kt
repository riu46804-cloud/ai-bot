package ir.studying.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

/**
 * توکن‌های ظاهری مشترک.
 *
 * چرا لازم شد: در بازبینی ظاهری معلوم شد شعاع گوشه‌ها با ۱۵ عدد مختلف (۳ تا ۲۸)
 * و فاصله‌ها با ۱۰/۱۱/۱۲/۱۴/۱۶/۱۸ دستی نوشته شده‌اند، پس کارت‌های کنار هم
 * گوشه و ریتم متفاوت دارند. این فایل مرجع واحد است؛ کد تازه باید از همین
 * استفاده کند و صفحه‌های قدیمی هم به‌مرور به آن کوچ می‌کنند.
 */
object AppRadius {
    /** تراشه، برچسب، ورودی کوچک. */
    val chip = RoundedCornerShape(14.dp)
    /** کارت‌های داخلی و باکس‌های کوچک. */
    val small = RoundedCornerShape(18.dp)
    /** کارت استاندارد صفحه. */
    val card = RoundedCornerShape(22.dp)
    /** کارت شاخص (هیرو) و شیت. */
    val hero = RoundedCornerShape(26.dp)
}

/** نردبان فاصله‌ها؛ فقط همین شش عدد. */
object AppSpace {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 22.dp
    val xxl = 30.dp
}

/**
 * رنگ برند را روی زمینهٔ تم می‌نشاند.
 *
 * رنگِ نیمه‌شفاف روی پس‌زمینهٔ پنجره می‌نشیند، نه روی پس‌زمینهٔ تم؛ نتیجه‌اش
 * در یکی از دو تم همیشه غلط از آب درمی‌آمد. این تابع رنگ مات می‌سازد.
 */
@Composable
fun tintedSurface(accent: Color, amount: Float = 0.12f): Color =
    lerp(MaterialTheme.colorScheme.background, accent, amount)

/** همان رنگ برند، ولی روشن‌شده تا روی زمینهٔ تیره خوانا بماند. */
@Composable
fun readableAccent(accent: Color): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) lerp(accent, Color.White, 0.42f) else accent
}
