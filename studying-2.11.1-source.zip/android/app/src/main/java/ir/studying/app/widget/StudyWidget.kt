package ir.studying.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import ir.studying.app.MainActivity
import ir.studying.app.R
import ir.studying.app.core.Goals
import ir.studying.app.core.Store
import kotlinx.coroutines.runBlocking

/**
 * Home-screen widget: today's minutes, the daily target and the streak.
 *
 * Deliberately built on RemoteViews rather than Glance. Glance would mean a new
 * dependency pinned against the Compose BOM for a surface that shows three
 * numbers and two buttons, and a widget that fails to inflate is invisible to
 * the user, so the boring API is the safer one here.
 *
 * The widget never calls the network. It reads the snapshot the app left behind
 * on its last successful refresh, which is why an offline phone still shows
 * yesterday's honest numbers instead of an error.
 */
class StudyWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> render(context, manager, id) }
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int) {
        runCatching {
            Store.init(context.applicationContext)
            val snap = runBlocking { Goals.snapshot() }
            val views = RemoteViews(context.packageName, R.layout.widget_study)

            val ratio = Goals.progress(snap.todayMinutes, snap.dailyGoal)
            val percent = (ratio * 100).toInt()
            val done = snap.todayMinutes >= snap.dailyGoal && snap.dailyGoal > 0

            views.setTextViewText(R.id.widget_title, if (done) "هدف امروز کامل شد" else "مطالعهٔ امروز")
            views.setTextViewText(R.id.widget_sub, faDate())

            /*
             * چرا قالب عددها عوض شد: قبلاً از Goals.label استفاده می‌شد که
             * «1h 25m» می‌دهد — هم رقم لاتین، هم واحد انگلیسی. روی ویجتِ
             * فارسی این بیشتر از هر چیزی توی چشم می‌زد.
             */
            val h = snap.todayMinutes / 60
            val m = snap.todayMinutes % 60
            views.setTextViewText(
                R.id.widget_minutes,
                if (h > 0) fa(h) + ":" + fa(if (m < 10) "0" + m else m.toString()) else fa(m),
            )
            views.setTextViewText(R.id.widget_unit, if (h > 0) "ساعت" else "دقیقه")

            /* هدف پیش‌فرض نداریم؛ تا کاربر خودش تعیین نکند عددی جعل نمی‌کنیم. */
            val left = Goals.remaining(snap.todayMinutes, snap.dailyGoal)
            views.setTextViewText(
                R.id.widget_goal,
                when {
                    snap.dailyGoal <= 0 -> "هنوز هدف روزانه تعیین نکرده‌ای"
                    done -> "هدف امروز کامل شد؛ هر دقیقهٔ بعدی امتیاز اضافه است"
                    else -> "از " + faMinutes(snap.dailyGoal) + " · " + faMinutes(left) + " مانده"
                },
            )
            views.setTextViewText(R.id.widget_percent, if (snap.dailyGoal > 0) fa(percent) + "٪" else "—")

            // A zero streak is not worth a chip: an empty badge on day one reads
            // as a failure the user has not had a chance to avoid yet.
            if (snap.streak > 0) {
                views.setViewVisibility(R.id.widget_streak, android.view.View.VISIBLE)
                views.setTextViewText(R.id.widget_streak, "🔥 " + fa(snap.streak) + " روز")
            } else {
                views.setViewVisibility(R.id.widget_streak, android.view.View.GONE)
            }

            views.setTextViewText(R.id.widget_start, if (done) "ادامه می‌دهم" else "شروع مطالعه")
            views.setProgressBar(R.id.widget_progress, 100, percent, false)

            views.setOnClickPendingIntent(R.id.widget_root, open(context, "studying://home", 2001))
            views.setOnClickPendingIntent(R.id.widget_start, open(context, "studying://part/new", 2002))
            views.setOnClickPendingIntent(R.id.widget_room, open(context, "studying://room", 2003))

            manager.updateAppWidget(id, views)
        }
    }

    /** رقم‌های فارسی؛ ویجت به توابع Compose دسترسی ندارد، پس همین‌جا. */
    private fun fa(v: Int): String = fa(v.toString())

    private fun fa(v: String): String = buildString {
        for (ch in v) append(if (ch in '0'..'9') FA_DIGITS[ch - '0'] else ch)
    }

    /** «۱ ساعت و ۲۵ دقیقه» یا «۴۵ دقیقه» — کوتاه و فارسی. */
    private fun faMinutes(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h > 0 && m > 0 -> fa(h) + " ساعت و " + fa(m) + " دقیقه"
            h > 0 -> fa(h) + " ساعت"
            else -> fa(m) + " دقیقه"
        }
    }

    /** تاریخ امروز به شمسی، برای خط کوچک زیر عنوان. */
    private fun faDate(): String = runCatching {
        val j = ir.studying.app.core.Jalali.today()
        val w = ir.studying.app.core.Jalali.weekDayNames.getOrElse(
            ir.studying.app.core.Jalali.weekDayIndex(java.util.Date())
        ) { "" }
        w + " " + fa(j.day) + " " + ir.studying.app.core.Jalali.monthName(j.month)
    }.getOrDefault("")

    private fun open(context: Context, uri: String, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data = Uri.parse(uri)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {

        private val FA_DIGITS = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

        /** Repaint every placed widget. Safe to call from any thread or process. */
        fun refresh(context: Context) {
            runCatching {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, StudyWidget::class.java))
                if (ids.isEmpty()) return
                val intent = Intent(context, StudyWidget::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}
