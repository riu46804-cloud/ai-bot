package ir.studying.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import ir.studying.app.MainActivity
import ir.studying.app.R
import ir.studying.app.data.TaskItem
import java.io.File

/**
 * ویجت «تسک‌های امروز».
 *
 * مثل ویجت مطالعه با RemoteViews نوشته شده و هیچ‌وقت شبکه نمی‌زند: اپ آخرین
 * لیست تسک‌های امروز را روی دیسک می‌گذارد ([TaskSnapshot]) و ویجت همان را
 * می‌خواند. این‌طور ویجت بی‌اینترنت هم عدد درست نشان می‌دهد و هرگز «در حال
 * بارگذاری» گیر نمی‌کند.
 */
class TasksWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> render(context, manager, id) }
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int) {
        runCatching {
            val snap = TaskSnapshot.read(context)
            val views = RemoteViews(context.packageName, R.layout.widget_tasks)

            val total = snap.size
            val done = snap.count { it.done }
            val percent = if (total > 0) done * 100 / total else 0

            views.setTextViewText(R.id.tw_title, if (total > 0 && done >= total) "همهٔ تسک‌های امروز انجام شد" else "تسک‌های امروز")
            views.setTextViewText(R.id.tw_sub, faDate())
            views.setTextViewText(R.id.tw_count, if (total > 0) fa(done) + "/" + fa(total) else "—")
            views.setProgressBar(R.id.tw_progress, 100, percent, false)

            /* اول کارهای انجام‌نشده؛ ویجت کوچک است و باید «چه مانده» را نشان دهد. */
            val lines = (snap.filter { !it.done } + snap.filter { it.done }).take(4)
            val ids4 = intArrayOf(R.id.tw_line1, R.id.tw_line2, R.id.tw_line3, R.id.tw_line4)
            ids4.forEachIndexed { i, viewId ->
                val t = lines.getOrNull(i)
                if (t == null) {
                    views.setViewVisibility(viewId, android.view.View.GONE)
                } else {
                    views.setViewVisibility(viewId, android.view.View.VISIBLE)
                    val time = if (t.time.isNotBlank()) "   ⏰ " + fa(t.time) else ""
                    /* نشانهٔ ابتدای خط، اولویت را بدون رنگ‌آمیزی پیچیده می‌رساند؛
                       RemoteViews برای هر TextView فقط یک رنگ می‌پذیرد. */
                    val mark = when {
                        t.done -> "✓ "
                        t.priority == "high" -> "🔴 "
                        t.priority == "low" -> "🟢 "
                        else -> "• "
                    }
                    views.setTextViewText(viewId, mark + t.title + time)
                    views.setTextColor(
                        viewId,
                        when {
                            t.done -> 0x7AFFFFFF.toInt()
                            t.priority == "high" -> 0xFFFDA4AF.toInt()
                            else -> 0xF2FFFFFF.toInt()
                        },
                    )
                }
            }
            val emptyText = when {
                total == 0 -> "برای امروز تسکی ننوشته‌ای"
                total > 4 -> "و " + fa(total - 4) + " تسک دیگر"
                else -> ""
            }
            views.setTextViewText(R.id.tw_empty, emptyText)
            views.setViewVisibility(R.id.tw_empty, if (emptyText.isBlank()) android.view.View.GONE else android.view.View.VISIBLE)

            views.setOnClickPendingIntent(R.id.tw_root, open(context, "studying://tasks", 2101))
            views.setOnClickPendingIntent(R.id.tw_open, open(context, "studying://tasks", 2102))
            views.setOnClickPendingIntent(R.id.tw_study, open(context, "studying://part/new", 2103))

            manager.updateAppWidget(id, views)
        }
    }

    private fun fa(v: Int): String = fa(v.toString())

    private fun fa(v: String): String = buildString {
        for (ch in v) append(if (ch in '0'..'9') FA_DIGITS[ch - '0'] else ch)
    }

    private fun faDate(): String = runCatching {
        val j = ir.studying.app.core.Jalali.today()
        val w = ir.studying.app.core.Jalali.weekDayNames.getOrElse(
            ir.studying.app.core.Jalali.weekDayIndex(java.util.Date())
        ) { "" }
        w + " " + fa(j.day) + " " + ir.studying.app.core.Jalali.monthName(j.month)
    }.getOrDefault("")

    private fun open(context: Context, uri: String, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data = Uri.parse(uri)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        private val FA_DIGITS = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

        fun refresh(context: Context) {
            runCatching {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, TasksWidget::class.java))
                if (ids.isEmpty()) return
                val intent = Intent(context, TasksWidget::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}

/**
 * عکس فوری تسک‌های امروز روی دیسک.
 *
 * از یک فایل متنی سادهٔ خط‌به‌خط استفاده می‌شود نه DataStore، چون ویجت در
 * پروسهٔ لانچر و در ترد براڈکست رندر می‌شود و خواندن همزمان (blocking) از
 * DataStore آن‌جا ریسک ANR دارد.
 */
object TaskSnapshot {
    data class Row(val done: Boolean, val title: String, val time: String, val priority: String = "normal")

    private fun file(context: Context) = File(context.filesDir, "tasks_widget.txt")

    fun save(context: Context, tasks: List<TaskItem>) {
        runCatching {
            val text = tasks.take(12).joinToString("\n") { t ->
                (if (t.done) "1" else "0") + "\u0001" + t.title.replace('\n', ' ') + "\u0001" + (t.dueHm ?: "") + "\u0001" + t.priority
            }
            file(context).writeText(text)
            TasksWidget.refresh(context)
        }
    }

    fun read(context: Context): List<Row> = runCatching {
        val f = file(context)
        if (!f.exists()) return emptyList()
        f.readLines().filter { it.isNotBlank() }.map { line ->
            val p = line.split('\u0001')
            Row(p.getOrNull(0) == "1", p.getOrNull(1).orEmpty(), p.getOrNull(2).orEmpty(), p.getOrNull(3) ?: "normal")
        }
    }.getOrDefault(emptyList())
}
