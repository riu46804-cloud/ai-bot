package ir.studying.app.core

import org.junit.Assert.*
import org.junit.Test

class AvatarsTest {
    @Test fun `every picker key has exactly one character with a distinct name`() {
        assertEquals(Avatars.keys, Avatars.characters.map { it.key })
        assertEquals(Avatars.characters.size, Avatars.characters.map { it.name }.toSet().size)
    }

    @Test fun `trait scores stay in the one to five range`() {
        Avatars.characters.forEach { c ->
            listOf(c.focus, c.energy, c.mischief).forEach { assertTrue(c.key, it in 1..5) }
        }
    }

    @Test fun `character colors are opaque ARGB values`() {
        Avatars.characters.forEach { c ->
            assertEquals(c.key, 0xFFL, c.color ushr 24)
            assertEquals(c.key, 0xFFL, c.glow ushr 24)
        }
    }

    @Test fun `builtin keys and server asset paths resolve to the same character`() {
        assertEquals("a3", Avatars.characterOfValue("builtin:a3")?.key)
        assertEquals("a7", Avatars.characterOfValue("assets/avatars/av_07.webp")?.key)
        assertEquals("a10", Avatars.characterOfValue("https://example.com/assets/avatars/av_10.webp")?.key)
        assertEquals(Avatars.drawableOf("builtin:a5"), Avatars.drawableOf("/assets/avatars/av_05.webp"))
    }

    @Test fun `personal photos and unknown keys have no character`() {
        assertNull(Avatars.characterOfValue(null))
        assertNull(Avatars.characterOfValue("uploads/avatars/u_12.jpg"))
        assertNull(Avatars.characterOfValue("builtin:a11"))
        assertNull(Avatars.characterOfValue("assets/avatars/av_00.webp"))
        assertNull(Avatars.drawableOf("uploads/avatars/u_12.jpg"))
    }
}
