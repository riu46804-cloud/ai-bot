package ir.studying.app.core

import ir.studying.app.data.CourseMinutes
import ir.studying.app.data.DailyReport
import ir.studying.app.data.HourlyPart
import ir.studying.app.data.StudyDetail
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class DailyReportQuestionsTest {
    @Test fun `root daily totals are authoritative and are not added to sessions again`() {
        val r = DailyReport.from(JSONObject("""{"date":"2026-10-25","total_minutes":90,"q_total":35,"q_descriptive":9,
            "sessions":[{"q_total":20,"q_descriptive":4},{"q_total":15,"q_descriptive":5}]}"""))
        assertEquals(QuestionTotals(35, 9), r.questionTotals)
        assertEquals("2026-10-25", r.dateIso)
        assertEquals(QuestionTotals(20, 4), r.sessions[0].questionTotals)
    }
    @Test fun `reported zero is displayed as zero`() {
        assertEquals(QuestionTotals(0, 0), DailyReport.from(JSONObject("""{"q_total":0,"q_descriptive":0}""")).questionTotals)
    }
    @Test fun `old server does not silently display invented zero`() {
        assertNull(DailyReport.from(JSONObject("""{"total_minutes":120,"sessions":[{"minutes":120}]}""")).questionTotals)
        assertNull(DailyReport.from(JSONObject("{}")).questionTotals)
    }
    @Test fun `fallback sums complete per session counts including unclassified courses`() {
        val r = DailyReport.from(JSONObject("""{"sessions":[{"q_total":25,"q_descriptive":8},{"q_total":10,"q_descriptive":0}]}"""))
        assertEquals(QuestionTotals(35,8), r.questionTotals)
    }
    @Test fun `partial old session data remains unknown`() {
        val r = DailyReport.from(JSONObject("""{"sessions":[{"q_total":12,"q_descriptive":2},{"q_total":20}]}"""))
        assertNull(r.questionTotals)
    }
    @Test fun `multiple choice and descriptive remain separate after timer block split`() {
        val detail = StudyDetail(qCorrect=24, qWrong=4, qBlank=2, qDescriptive=17)
        val split = detail.splitAcross(listOf(25,25,10))
        assertEquals(QuestionTotals(30,17), QuestionTotals.sumKnown(split.map { QuestionTotals(it.qTotal,it.qDescriptive) }))
        assertEquals(30, detail.qTotal)
    }
    @Test fun `daily post round trips counters with and without courses`() {
        for (courses in listOf(emptyList(), listOf(CourseMinutes("زیست", "", 80)))) {
            val text = AutoPost.dailySummaryText(80, courses, QuestionTotals(75,12))
            val parsed = AutoPost.parse(text)!!
            assertEquals(QuestionTotals(75,12), parsed.questionTotals)
            assertEquals(AutoPost.DAILY,parsed.kind)
            assertEquals(80,parsed.minutes)
            assertEquals(courses.map { it.name to it.minutes },parsed.courses)
            assertTrue(AutoPost.strip(text).contains("تست"))
        }
    }
    @Test fun `existing achievement posts still parse and have no fake counters`() {
        val old = AutoPost.parse("⟪dh|daily|90|0|0|ریاضی~90⟫امروز مطالعه کردم")!!
        assertNull(old.questionTotals)
        assertEquals(listOf("ریاضی" to 90),old.courses)
        assertNull(AutoPost.parse("پست معمولی"))
        assertNull(AutoPost.parse("⟪dh|goal|90|60|0⟫هدف")!!.questionTotals)
    }
    @Test fun `invalid tag counters are rejected not crash feed`() {
        listOf("q:-1:2","q:3:x","q:999999999999:1","bad:3:1","q:1").forEach {
            assertNull(QuestionTotals.decodeTag(it))
        }
    }
    @Test fun `sum uses wide accumulator and clamps only at display integer limit`() {
        assertEquals(QuestionTotals(Int.MAX_VALUE,6),QuestionTotals.sumKnown(listOf(QuestionTotals(Int.MAX_VALUE,3),QuestionTotals(5,3))))
        assertNull(QuestionTotals.sumKnown(listOf(QuestionTotals(2,1),null)))
        assertEquals(QuestionTotals(0,0),QuestionTotals.sumKnown(emptyList()))
    }
}
