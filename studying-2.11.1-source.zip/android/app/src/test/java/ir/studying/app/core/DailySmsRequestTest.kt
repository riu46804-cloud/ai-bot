package ir.studying.app.core

import okhttp3.Request
import okio.Buffer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Pure request construction only: no real user token, network call or SMS. */
class DailySmsRequestTest {
    private val fakeToken = "unit-test-fake-token"
    private fun assertEndpoint(req: Request, action: String) {
        assertEquals("https", req.url.scheme)
        assertEquals("studying.ir", req.url.host)
        assertEquals("/sms/api.php", req.url.encodedPath)
        assertEquals(action, req.url.queryParameter("action"))
        assertEquals(1, req.url.querySize)
        assertEquals("application/json", req.header("Accept"))
        assertEquals("Bearer $fakeToken", req.header("Authorization"))
        assertEquals(fakeToken, req.header("X-Auth-Token"))
    }
    @Test fun statusIsAuthenticatedGetToExactNewEndpoint() {
        val r = DailySms.buildRequest("status", null, fakeToken)
        assertEndpoint(r, "status")
        assertEquals("GET", r.method)
        assertNull(r.body)
    }
    @Test fun savePreservesFlagsAndUsesOneShotPost() {
        val body = JSONObject().put("motivational", true).put("konkur", false).put("exam_key", "riazi")
        val r = DailySms.buildRequest("save", body, fakeToken)
        assertEndpoint(r, "save")
        assertEquals("POST", r.method)
        assertTrue(r.body!!.isOneShot())
        assertEquals("application/json; charset=utf-8", r.body!!.contentType().toString())
        val sink = Buffer(); r.body!!.writeTo(sink); val payload = JSONObject(sink.readUtf8())
        assertTrue(payload.getBoolean("motivational"))
        assertFalse(payload.getBoolean("konkur"))
        assertEquals("riazi", payload.getString("exam_key"))
    }
    @Test fun explicitTestUsesOneShotEmptyPostButDoesNotSendIt() {
        val r = DailySms.buildRequest("test", JSONObject(), fakeToken)
        assertEndpoint(r, "test")
        assertEquals("POST", r.method)
        assertTrue(r.body!!.isOneShot())
        val sink = Buffer(); r.body!!.writeTo(sink)
        assertEquals(0, JSONObject(sink.readUtf8()).length())
    }
    @Test fun unrecognizedActionsCannotBeConstructed() {
        assertThrows(IllegalArgumentException::class.java) { DailySms.buildRequest("other", null, fakeToken) }
    }
}
