package ir.studying.app.core

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/**
 * قرارداد اپ با سرویس جدای «پیامک صبحگاهی» (studying-sms/public/api.php).
 * نمونه‌ها پاسخ واقعی همان سرویس‌اند (کوتاه‌شده)، نه دادهٔ دست‌ساز.
 */
class DailySmsTest {
    private val active = JSONObject("""{"success":true,"eligible":true,"block_reason":null,"subscription":{"active":true,"expires_at":1796508121,"expires_fa":"۱۵ آذر ۱۴۰۵","days_left":30},"phone":{"masked":"0912***1111","ok":true,"verified":true},"settings":{"motivational":true,"konkur":true,"exam_key":"riazi"},"active":true,"suggested_exam_key":"tajrobi","exams":[{"key":"riazi","title":"کنکور گروه ریاضی و فنی","short_title":"ریاضی","emoji":"📐","date":"2027-07-01","date_fa":"پنجشنبه ۱۰ تیر ۱۴۰۶","days_left":237,"official":false},{"key":"tajrobi","title":"کنکور گروه علوم تجربی","short_title":"تجربی","emoji":"🧪","date":"2027-07-03","date_fa":"شنبه ۱۲ تیر ۱۴۰۶","days_left":239,"official":true}],"schedule":{"send_time":"07:00","send_time_fa":"۷:۰۰","next_send_at":1793935800,"next_send_date":"2026-11-06","next_send_label":"امروز، ساعت ۷:۰۰ صبح","next_send_day_fa":"جمعه ۱۵ آبان"},"preview":{"text":"☀ صبح بخیر، علی\n«موانعی وجود خواهد داشت. شک و تردید وجود خواهد داشت. اشتباهاتی وجود خواهد داشت. اما با سخت کوشی، هیچ محدودیتی وجود ندارد.»\n⏳ ۲۳۷ روز تا کنکور ریاضی (تقریبی)\nStudying","parts":3,"chars":181,"is_sample":false,"date":"2026-11-06","days_left":237},"quotes_count":1000,"today":{"status":"sent","status_label":"ارسال شد","sent_at":1793935800},"stats":{"total_sent":6,"last_sent_at":1795231800,"since_fa":"۱۵ آبان ۱۴۰۵"},"history":[{"date":"2026-11-21","date_fa":"شنبه ۳۰ آبان","time_fa":"۰۷:۰۰","kind":"daily","text":"☀ صبح بخیر، علی\n«یک راز موفقیت در زندگی، این است که آماده دریافت فرصت باشید.»\n⏳ ۲۲۲ روز تا کنکور ریاضی (تقریبی)\nStudying","status":"sent","status_label":"ارسال شد"},{"date":"2026-11-20","date_fa":"جمعه ۲۹ آبان","time_fa":null,"kind":"daily","text":"☀ صبح بخیر، علی\n«پشت هر موفقیت بزرگ، هزاران شکست و تلاش نهفته است.»\n⏳ ۲۲۳ روز تا کنکور ریاضی (تقریبی)\nStudying","status":"failed","status_label":"ارسال نشد"}],"test_available":false,"test_used_today":true,"server_time":1793917393}""")
    private val locked = JSONObject("""{"success":true,"eligible":false,"block_reason":"subscription_required","subscription":{"active":false,"expires_at":null,"expires_fa":null,"days_left":0},"phone":{"masked":"0912***2222","ok":true,"verified":true},"settings":{"motivational":false,"konkur":false,"exam_key":null},"active":false,"suggested_exam_key":"riazi","exams":[{"key":"riazi","title":"کنکور گروه ریاضی و فنی","short_title":"ریاضی","emoji":"📐","date":"2027-07-01","date_fa":"پنجشنبه ۱۰ تیر ۱۴۰۶","days_left":237,"official":false},{"key":"tajrobi","title":"کنکور گروه علوم تجربی","short_title":"تجربی","emoji":"🧪","date":"2027-07-03","date_fa":"شنبه ۱۲ تیر ۱۴۰۶","days_left":239,"official":true}],"schedule":{"send_time":"07:00","send_time_fa":"۷:۰۰","next_send_at":1793935800,"next_send_date":"2026-11-06","next_send_label":"امروز، ساعت ۷:۰۰ صبح","next_send_day_fa":"جمعه ۱۵ آبان"},"preview":{"text":"☀ صبح بخیر، Sara\n«سختی‌ها، سکوی پرش برای موفقیت هستند.»\n⏳ ۲۳۷ روز تا کنکور ریاضی (تقریبی)\nStudying","parts":2,"chars":98,"is_sample":true,"date":"2026-11-06","days_left":237},"quotes_count":1000,"today":null,"stats":{"total_sent":0,"last_sent_at":null,"since_fa":null},"history":[],"test_available":false,"test_used_today":false,"server_time":1793917464}""")

    @Test fun `active subscriber status is parsed completely`() {
        val s = DailySms.parse(active)
        assertTrue(s.eligible)
        assertNull(s.blockReason)
        assertFalse(s.locked)
        assertEquals("۱۵ آذر ۱۴۰۵", s.subscriptionExpiresFa)
        assertEquals(30, s.subscriptionDaysLeft)
        assertEquals("0912***1111", s.phoneMasked)
        assertTrue(s.phoneOk)
        assertTrue(s.motivational)
        assertTrue(s.konkur)
        assertTrue(s.anyOn)
        assertEquals("riazi", s.examKey)
        assertEquals("tajrobi", s.suggestedExamKey)
        assertEquals(2, s.exams.size)
        val riazi = s.exams.first { it.key == "riazi" }
        assertEquals("ریاضی", riazi.shortTitle)
        assertEquals("📐", riazi.emoji)
        assertEquals("2027-07-01", riazi.date)
        assertEquals(237, riazi.daysLeft)
        assertFalse(riazi.official)
        assertEquals("riazi", s.shownExam?.key)
        assertEquals("۷:۰۰", s.sendTimeFa)
        assertTrue(s.nextSendLabel.contains("۷:۰۰"))
        val p = s.preview!!
        assertTrue(p.text.startsWith("☀ صبح بخیر، علی\n«"))
        assertTrue(p.text.endsWith("\nStudying"))
        assertEquals(3, p.parts)
        assertFalse(p.isSample)
        assertEquals(237, p.daysLeft)
        assertEquals(1000, s.quotesCount)
        assertEquals("sent", s.todayStatus)
        assertEquals(6, s.totalSent)
        assertEquals("۱۵ آبان ۱۴۰۵", s.sinceFa)
        assertEquals(2, s.history.size)
        assertEquals("ارسال شد", s.history[0].statusLabel)
        assertEquals("۰۷:۰۰", s.history[0].timeFa)
        assertNull(s.history[1].timeFa)
        assertEquals("failed", s.history[1].status)
        assertFalse(s.testAvailable)
        assertTrue(s.testUsedToday)
    }

    @Test fun `user without subscription is locked and gets a sample preview`() {
        val s = DailySms.parse(locked)
        assertFalse(s.eligible)
        assertEquals("subscription_required", s.blockReason)
        assertTrue(s.locked)
        assertNull(s.subscriptionExpiresFa)
        assertFalse(s.anyOn)
        assertNull(s.examKey)
        assertTrue(s.preview!!.isSample)
        assertNull(s.todayStatus)
        assertEquals(0, s.totalSent)
        assertNull(s.sinceFa)
        assertTrue(s.history.isEmpty())
        assertFalse(s.testAvailable)
    }

    @Test fun `countdown group falls back from choice to suggestion to first`() {
        val s = DailySms.parse(active)
        assertEquals("riazi", s.copy(examKey = "riazi").shownExam?.key)
        assertEquals("tajrobi", s.copy(examKey = null).shownExam?.key)
        assertEquals("tajrobi", s.copy(examKey = "removed_group").shownExam?.key)
        assertEquals("riazi", s.copy(examKey = null, suggestedExamKey = null).shownExam?.key)
        assertNull(s.copy(exams = emptyList()).shownExam)
    }

    @Test fun `missing or partial payload never crashes`() {
        val s = DailySms.parse(JSONObject("{}"))
        assertFalse(s.eligible)
        assertFalse(s.locked)
        assertTrue(s.exams.isEmpty())
        assertNull(s.preview)
        assertEquals("۷:۰۰", s.sendTimeFa)
        val old = DailySms.parse(JSONObject("""{"eligible":1,"settings":{"motivational":"1","konkur":0,"exam_key":null},"quotes_count":"1000"}"""))
        assertTrue(old.eligible)
        assertTrue(old.motivational)
        assertFalse(old.konkur)
        assertNull(old.examKey)
        assertEquals(1000, old.quotesCount)
    }
}
