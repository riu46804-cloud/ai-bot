package ir.studying.app.core

import ir.studying.app.data.DmDeleteScope
import org.junit.Assert.assertEquals
import org.junit.Test

class DmDeleteScopeTest {
    @Test fun `default unchecked deletion is only for this user`() {
        assertEquals(DmDeleteScope.ME, DmDeleteScope.fromBothChecked(false))
        assertEquals("me", DmDeleteScope.ME.api)
    }
    @Test fun `delete for both requires an explicit checked choice`() {
        assertEquals(DmDeleteScope.BOTH, DmDeleteScope.fromBothChecked(true))
        assertEquals("both", DmDeleteScope.BOTH.api)
    }
}
