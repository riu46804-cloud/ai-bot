package ir.studying.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class EmojiParseTest {

    @Test
    fun splitsTextAndEmoji() {
        assertEquals(
            listOf(EmojiParse.Seg("سلام ", false), EmojiParse.Seg("👋", true), EmojiParse.Seg(" دنیا", false)),
            EmojiParse.segments("سلام 👋 دنیا"),
        )
        assertTrue(EmojiParse.segments("").isEmpty())
    }

    @Test
    fun keepsJoinedSequencesAndSkinTonesTogether() {
        assertEquals(listOf("👩‍💻", "👍🏽", "❤️‍🔥"), EmojiParse.emojis("👩‍💻 x 👍🏽 y ❤️‍🔥"))
    }

    @Test
    fun readsFlagsAndKeycaps() {
        assertEquals(listOf("🇮🇷", "1️⃣"), EmojiParse.emojis("🇮🇷 1️⃣ 1"))
    }

    @Test
    fun textSymbolsStayTextWithoutAVariationSelector() {
        assertTrue(EmojiParse.emojis("▲ ✓ ← ™ 123 #").isEmpty())
        assertEquals(listOf("❤️"), EmojiParse.emojis("❤️"))
        assertEquals(listOf("⭐", "✅"), EmojiParse.emojis("⭐ ✅"))
    }

    @Test
    fun onlyEmojiFindsBigEmojiMessages() {
        assertEquals(listOf("😂", "🔥"), EmojiParse.onlyEmoji(" 😂 🔥 "))
        assertNull(EmojiParse.onlyEmoji("😂 ha"))
        assertNull(EmojiParse.onlyEmoji("😂😂😂😂"))
        assertNull(EmojiParse.onlyEmoji(""))
        assertNull(EmojiParse.onlyEmoji(null))
    }

    @Test
    fun assetNameSkipsJoinersAndSelectors() {
        assertEquals("ic3d_1f525", EmojiParse.assetName("🔥"))
        assertEquals("ic3d_2764_1f525", EmojiParse.assetName("❤️‍🔥"))
        assertEquals("ic3d_1f44d_1f3fd", EmojiParse.assetName("👍🏽"))
    }

    /** Every reaction and the emoji the redesigned screens lean on ship as 3D renders. */
    @Test
    fun reactionsAndScreenEmojiHaveBundledRenders() {
        val dir = File("src/main/res/drawable-nodpi")
        assertTrue("render folder missing: ${dir.absolutePath}", dir.isDirectory)
        val screens = EmojiParse.emojis(
            "🃏 ✅ 🧩 🖼️ 🎧 ✨ 🧠 🔁 🏆 🔥 ⏱️ 📅 🗓️ 📌 ⏰ 🌴 🌱 📈 📊 💡 🎯 😵 😓 🙂 😎 📚 🔗 🎉 👥 💬",
        )
        val missing = (EmojiCatalog.allReactions + screens).distinct()
            .filterNot { File(dir, EmojiParse.assetName(it) + ".webp").isFile }
        assertTrue("missing 3D renders: $missing", missing.isEmpty())
    }
}
