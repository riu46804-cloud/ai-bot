package ir.studying.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FlashcardLogicTest {

    @Test fun emptyEditorAndStatsHelpersInitializeSafely() {
        assertEquals(0, FlashcardLogic.clozeCount(""))
        assertEquals(0, FlashcardLogic.breakdown(emptyMap(), 0, 0).total)
        assertEquals(FlashcardLogic.Bucket.NEW, FlashcardLogic.bucket("new", 0))
    }

    @Test fun clozeSupportsPersianAndMultipleLiteralClosingBraces() {
        assertEquals(2, FlashcardLogic.clozeCount("{{سلام}} و {{دنیا}}"))
        assertEquals(listOf("سلام" to true, " و " to false, "دنیا" to true),
            FlashcardLogic.clozeParts("{{سلام}} و {{دنیا}}"))
        assertEquals(0, FlashcardLogic.clozeCount("متن } بدون جای خالی"))
    }


    @Test
    fun bucketFollowsStateAndInterval() {
        assertEquals(FlashcardLogic.Bucket.NEW, FlashcardLogic.bucket("new", 0))
        assertEquals(FlashcardLogic.Bucket.NEW, FlashcardLogic.bucket("", 30))
        assertEquals(FlashcardLogic.Bucket.LEARNING, FlashcardLogic.bucket("learning", 40))
        assertEquals(FlashcardLogic.Bucket.REVIEW, FlashcardLogic.bucket("review", 20))
        assertEquals(FlashcardLogic.Bucket.MASTERED, FlashcardLogic.bucket("review", FlashcardLogic.MASTERED_DAYS))
    }

    @Test
    fun mcqOptionsRoundTrip() {
        val extra = FlashcardLogic.mcqExtra(listOf("Paris" to true, "  Rome " to false, "" to false, "Line\nbreak" to false))
        assertEquals("*Paris\nRome\nLine break", extra)
        assertEquals(listOf("Paris" to true, "Rome" to false, "Line break" to false), FlashcardLogic.mcqOptions(extra))
    }

    @Test
    fun mcqOptionsTolerateSpacesAndBlankLines() {
        assertEquals(listOf("a" to false, "b" to true), FlashcardLogic.mcqOptions(" a \n\n * b \n"))
        assertTrue(FlashcardLogic.mcqOptions("").isEmpty())
    }

    @Test
    fun mcqNeedsTwoFilledOptionsAndOneRightAnswer() {
        assertFalse(FlashcardLogic.mcqValid(listOf("a" to true)))
        assertFalse(FlashcardLogic.mcqValid(listOf("a" to false, "b" to false)))
        assertFalse(FlashcardLogic.mcqValid(listOf("a" to false, " " to true)))
        assertTrue(FlashcardLogic.mcqValid(listOf("a" to false, "b" to true, "" to false)))
    }

    @Test
    fun clozePartsSplitHiddenRuns() {
        val text = "The {{sun}} rises in the {{east}}."
        assertEquals(
            listOf("The " to false, "sun" to true, " rises in the " to false, "east" to true, "." to false),
            FlashcardLogic.clozeParts(text),
        )
        assertEquals(2, FlashcardLogic.clozeCount(text))
        assertEquals(listOf("plain" to false), FlashcardLogic.clozeParts("plain"))
        assertEquals(0, FlashcardLogic.clozeCount("no {{ blank"))
    }

    @Test
    fun wrapClozeWrapsTheSelection() {
        assertEquals("The {{sun}} rises" to 11, FlashcardLogic.wrapCloze("The sun rises", 4, 7))
        // Reversed selections behave the same.
        assertEquals("The {{sun}} rises" to 11, FlashcardLogic.wrapCloze("The sun rises", 7, 4))
    }

    @Test
    fun wrapClozeUsesTheWordUnderTheCursor() {
        assertEquals("The {{sun}} rises" to 11, FlashcardLogic.wrapCloze("The sun rises", 5, 5))
    }

    @Test
    fun wrapClozeTrimsSpacesAroundTheSelection() {
        assertEquals("x {{sun}} y", FlashcardLogic.wrapCloze("x sun y", 1, 6).first)
    }

    @Test
    fun wrapClozeUnwrapsAnExistingBlank() {
        // Cursor inside the blank.
        assertEquals("The sun rises" to 7, FlashcardLogic.wrapCloze("The {{sun}} rises", 7, 7))
        // The whole blank selected, braces included.
        assertEquals("The sun rises" to 7, FlashcardLogic.wrapCloze("The {{sun}} rises", 4, 11))
    }

    @Test
    fun wrapClozeInsertsAnEmptyBlankOnAnEmptySpot() {
        assertEquals("{{}}" to 2, FlashcardLogic.wrapCloze("", 0, 0))
        assertEquals("a {{}} b" to 4, FlashcardLogic.wrapCloze("a  b", 2, 2))
    }

    @Test
    fun streakCountsBackFromTodayOrYesterday() {
        val h = listOf("2024-03-08" to 5, "2024-03-09" to 3, "2024-03-10" to 0, "2024-03-11" to 4, "2024-03-12" to 2)
        assertEquals(2, FlashcardLogic.streak(h, "2024-03-12"))
        assertEquals(2, FlashcardLogic.streak(h, "2024-03-13")) // today is still open
        assertEquals(0, FlashcardLogic.streak(h, "2024-03-14"))
        assertEquals(0, FlashcardLogic.streak(emptyList(), "2024-03-14"))
        // Across a leap day and a month boundary.
        val leap = listOf("2024-02-28" to 1, "2024-02-29" to 1, "2024-03-01" to 1)
        assertEquals(3, FlashcardLogic.streak(leap, "2024-03-01"))
    }

    @Test
    fun forecastFoldsOverdueCardsIntoToday() {
        val f = listOf("2024-03-01" to 3, "2024-03-09" to 2, "2024-03-10" to 4, "2024-03-12" to 1, "2024-04-30" to 9)
        assertEquals(
            listOf("2024-03-10" to 9, "2024-03-11" to 0, "2024-03-12" to 1),
            FlashcardLogic.forecast(f, "2024-03-10", 3),
        )
        assertEquals(5, FlashcardLogic.overdue(f, "2024-03-10"))
        assertEquals(14, FlashcardLogic.forecast(emptyList(), "2024-03-10", 14).size)
    }

    @Test
    fun accuracyIsAWholePercent() {
        assertEquals(0, FlashcardLogic.accuracy(0, 0))
        assertEquals(75, FlashcardLogic.accuracy(4, 1))
        assertEquals(66, FlashcardLogic.accuracy(3, 1))
        assertEquals(0, FlashcardLogic.accuracy(2, 5))
        assertEquals(100, FlashcardLogic.accuracy(5, 0))
    }

    @Test
    fun breakdownSplitsMasteredOutOfReview() {
        val b = FlashcardLogic.breakdown(mapOf("new" to 1, "learning" to 4, "review" to 10), mastered = 6, unseen = 5)
        assertEquals(6, b.fresh)
        assertEquals(4, b.learning)
        assertEquals(4, b.review)
        assertEquals(6, b.mastered)
        assertEquals(20, b.total)
        assertEquals(30, b.percent(6))
        assertEquals(0.3f, b.share(6), 0.0001f)

        val odd = FlashcardLogic.breakdown(mapOf("review" to 2), mastered = 5, unseen = -3)
        assertEquals(0, odd.fresh)
        assertEquals(0, odd.review)
        assertEquals(2, odd.mastered)
        assertEquals(0, FlashcardLogic.breakdown(emptyMap(), 0, 0).percent(0))
    }

    @Test
    fun summarizeTotalsTheHistory() {
        val s = FlashcardLogic.summarize(
            listOf(Triple("2024-03-01", 10, 300), Triple("2024-03-02", 0, 0), Triple("2024-03-03", 25, 650)),
        )
        assertEquals(35, s.cards)
        assertEquals(950, s.seconds)
        assertEquals(2, s.activeDays)
        assertEquals("2024-03-03", s.bestDay)
        assertEquals(25, s.bestCards)
        assertEquals(16, s.minutes)
        assertEquals(18, s.perActiveDay)
        assertEquals(27, s.secondsPerCard)

        val empty = FlashcardLogic.summarize(emptyList())
        assertEquals(0, empty.perActiveDay)
        assertEquals(0, empty.secondsPerCard)
        assertNull(empty.bestDay)
    }
}
