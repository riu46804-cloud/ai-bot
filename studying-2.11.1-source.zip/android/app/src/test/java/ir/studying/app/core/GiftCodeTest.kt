package ir.studying.app.core

import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Test

class GiftCodeTest {
    @After fun clearWallet() { Game.clear() }

    @Test fun `codes normalize ASCII case and PHP compatible edge whitespace`() {
        assertEquals("studying", GiftCodeInput.normalize(" \tSTUDYING\r\n"))
        assertEquals("new_year-26", GiftCodeInput.normalize("NEW_Year-26"))
    }
    @Test fun `invalid characters are rejected rather than silently removed`() {
        listOf("study ing", "studying' OR 1=1", "کد", "study\u200Bing", "-abc", "_abc", "abc!", "\u00A0studying\u00A0").forEach {
            assertNull(it, GiftCodeInput.normalize(it))
        }
    }
    @Test fun `code lengths have the same three to sixty four boundary as server`() {
        assertNull(GiftCodeInput.normalize("ab"))
        assertEquals("abc",GiftCodeInput.normalize("abc"))
        assertNotNull(GiftCodeInput.normalize("a".repeat(64)))
        assertNull(GiftCodeInput.normalize("a".repeat(65)))
        assertNull(GiftCodeInput.normalize(""))
    }
    @Test fun `reward amount and current balance come from server not a local 9000 increment`() {
        Game.clear()
        val result = Game.acceptGiftResponse(JSONObject("""{"success":true,"granted":777,"already_redeemed":false,"state":{"coins":12345}}"""))
        assertNull(result.error)
        assertEquals(777,result.granted)
        assertEquals(12345,Game.state.value.coins)
        assertTrue(Game.state.value.loaded)
    }
    @Test fun `duplicate receipts do not add coins twice`() {
        val response = JSONObject("""{"success":true,"granted":0,"already_redeemed":true,"previous_grant":9000,"state":{"coins":9000}}""")
        repeat(3) {
            val result = Game.acceptGiftResponse(response)
            assertTrue(result.alreadyRedeemed)
            assertEquals(0,result.granted)
            assertEquals(9000,result.previousGrant)
            assertEquals(9000,Game.state.value.coins)
        }
    }
    @Test fun `failed redemption leaves existing wallet untouched`() {
        Game.acceptGiftResponse(JSONObject("""{"success":true,"granted":5,"state":{"coins":500}}"""))
        val result = Game.acceptGiftResponse(JSONObject("""{"success":false,"error":"این کد غیرفعال است","state":{"coins":0}}"""))
        assertNotNull(result.error)
        assertEquals(500,Game.state.value.coins)
    }
    @Test fun `missing wallet never resets balance to zero and tells user to retry`() {
        Game.acceptGiftResponse(JSONObject("""{"success":true,"granted":5,"state":{"coins":500}}"""))
        val result = Game.acceptGiftResponse(JSONObject("""{"success":true,"granted":9000}"""))
        assertNotNull(result.error)
        assertEquals(500,Game.state.value.coins)
    }
    @Test fun `invalid local code never reaches transport or changes wallet`() = kotlinx.coroutines.runBlocking {
        Game.clear()
        val result = Game.redeemGift("invalid code with spaces")
        assertEquals(GiftCodeInput.ERROR, result.error)
        assertEquals(0, Game.state.value.coins)
        assertFalse(Game.state.value.loaded)
    }

}
