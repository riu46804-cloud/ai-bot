package ir.studying.app.core

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The goal arithmetic feeds every progress ring and the widget. It was written
 * as pure functions on purpose so it can be verified without an emulator.
 */
class GoalsMathTest {

    @Test
    fun `progress is clamped between zero and one`() {
        assertEquals(0f, Goals.progress(0, 120), 0.0001f)
        assertEquals(0.5f, Goals.progress(60, 120), 0.0001f)
        assertEquals(1f, Goals.progress(500, 120), 0.0001f)
        // Negative minutes cannot happen, but a crash-free zero is the right answer.
        assertEquals(0f, Goals.progress(-30, 120), 0.0001f)
    }

    @Test
    fun `a zero goal never divides by zero`() {
        assertEquals(0f, Goals.progress(45, 0), 0.0001f)
    }

    @Test
    fun `remaining never goes negative`() {
        assertEquals(60, Goals.remaining(60, 120))
        assertEquals(0, Goals.remaining(200, 120))
    }

    @Test
    fun `label uses latin digits and drops empty units`() {
        assertEquals("45m", Goals.label(45))
        assertEquals("2h", Goals.label(120))
        assertEquals("2h 30m", Goals.label(150))
        assertEquals("0m", Goals.label(0))
    }
}
