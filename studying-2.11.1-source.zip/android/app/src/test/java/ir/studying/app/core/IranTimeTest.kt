package ir.studying.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone

/**
 * Every "day" in the app must be a Tehran day, because the server stamps
 * study_date with CURDATE() on a Tehran clock. These tests deliberately move
 * the JVM's default timezone away from Tehran: that is exactly the situation
 * (emulator on UTC, traveller abroad) that used to file sessions on the wrong
 * day.
 */
class IranTimeTest {

    @Test
    fun `today is a tehran day even when the device is on another timezone`() {
        val original = TimeZone.getDefault()
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("UTC"))
            val utcView = IranTime.todayIso()
            TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"))
            val nyView = IranTime.todayIso()
            assertEquals(utcView, nyView)
        } finally {
            TimeZone.setDefault(original)
        }
    }

    @Test
    fun `days ago counts whole tehran days`() {
        assertEquals(0, IranTime.daysAgoOf(IranTime.todayIso()))
        assertEquals(1, IranTime.daysAgoOf(IranTime.isoDaysAgo(1)))
        assertEquals(7, IranTime.daysAgoOf(IranTime.isoDaysAgo(7)))
    }

    @Test
    fun `a malformed date is rejected instead of throwing`() {
        assertEquals(-1, IranTime.daysAgoOf("not-a-date"))
        assertEquals(-1, IranTime.daysAgoOf(""))
    }

    @Test
    fun `next occurrence is always in the future`() {
        val now = System.currentTimeMillis()
        for (hour in 0..23) {
            val at = IranTime.nextOccurrence(hour, 0)
            assertTrue("hour $hour", at > now)
            // and never more than a day out
            assertTrue("hour $hour", at - now <= 24L * 60 * 60 * 1000 + 1000)
        }
    }

    @Test
    fun `iso days ago is ordered and well formed`() {
        val today = IranTime.todayIso()
        val yesterday = IranTime.isoDaysAgo(1)
        assertTrue(yesterday < today)
        assertTrue(today.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
    }
}
