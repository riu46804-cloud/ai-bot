package ir.studying.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The Jalali converter decides which day a study session belongs to, so a bug
 * here silently moves minutes between days and breaks the streak. It is pure
 * arithmetic with no Android dependency, which makes it the cheapest thing in
 * the app to pin down with tests.
 */
class JalaliTest {

    @Test
    fun `known dates convert from gregorian`() {
        val a = Jalali.fromGregorian(2026, 8, 15)
        assertEquals(1405, a.year)
        assertEquals(5, a.month)
        assertEquals(24, a.day)

        // Nowruz: the first day of the Jalali year.
        val b = Jalali.fromGregorian(2026, 3, 21)
        assertEquals(1405, b.year)
        assertEquals(1, b.month)
        assertEquals(1, b.day)

        // The day before Nowruz must be the last day of the previous year.
        val c = Jalali.fromGregorian(2026, 3, 20)
        assertEquals(1404, c.year)
        assertEquals(12, c.month)
    }

    @Test
    fun `conversion round trips for a decade of dates`() {
        for (year in 1400..1410) {
            for (month in 1..12) {
                // Esfand 30 is not a valid date in common years (covered separately below).
                val day = when { month <= 6 -> 31; month == 12 -> 29; else -> 30 }
                val g = Jalali.toGregorian(year, month, day)
                val back = Jalali.fromGregorian(g[0], g[1], g[2])
                assertEquals("year $year month $month", year, back.year)
                assertEquals("year $year month $month", month, back.month)
                assertEquals("year $year month $month", day, back.day)
            }
        }
    }

    @Test
    fun `esfand 30 exists only in leap years`() {
        // 1403 is a Jalali leap year, 1404 is not.
        val leap = Jalali.toGregorian(1403, 12, 30)
        val backLeap = Jalali.fromGregorian(leap[0], leap[1], leap[2])
        assertEquals(1403, backLeap.year)
        assertEquals(12, backLeap.month)
        assertEquals(30, backLeap.day)

        // Asking for a 30th of Esfand in a common year must roll over rather
        // than produce a date claiming to still be in that year.
        val common = Jalali.toGregorian(1404, 12, 30)
        val backCommon = Jalali.fromGregorian(common[0], common[1], common[2])
        assertTrue(backCommon.year == 1405 && backCommon.month == 1 && backCommon.day == 1)
    }

    @Test
    fun `month name never throws for out of range input`() {
        assertEquals("", Jalali.monthName(0))
        assertEquals("", Jalali.monthName(13))
        assertEquals(Jalali.monthNames[4], Jalali.monthName(5))
    }
}
