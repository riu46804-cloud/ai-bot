package ir.studying.app.core

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.junit.Assert.*
import org.junit.Test
import java.net.ServerSocket
import java.net.SocketException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Local HTTP wire tests: not a test of the production PHP backend. */
class MessageSendTransportTest {
    @Test fun appliesOnlyToTextSendPosts() {
        for (action in listOf("dm_send", "chat", "group_chat")) {
            assertTrue(MessageSendTransport.applies(action, "POST"))
            assertFalse(MessageSendTransport.applies(action, "GET"))
        }
        assertFalse(MessageSendTransport.applies("profile", "POST"))
    }

    @Test fun requestCannotBeAutomaticallyReplayed() {
        val body = "{}".toRequestBody("application/json".toMediaType())
        assertTrue(MessageSendTransport.oneShot(body).isOneShot())
        val client = MessageSendTransport.client(OkHttpClient())
        assertFalse(client.retryOnConnectionFailure)
        assertFalse(client.followRedirects)
        assertFalse(client.followSslRedirects)
    }

    @Test fun retryAfterZero503StillSendsOnlyOnePost() = assertOnePost(503)
    @Test fun requestTimeout408StillSendsOnlyOnePost() = assertOnePost(408)
    @Test fun redirect307DoesNotReplayPost() = assertOnePost(307)
    @Test fun connectionLostAfterCommitDoesNotResendPost() = assertOnePost(null)

    private fun assertOnePost(code: Int?) {
        val server = ServerSocket(0)
        val received = AtomicInteger(0)
        val thread = Thread {
            try {
                while (!server.isClosed) {
                    server.accept().use { socket ->
                        socket.soTimeout = 2000
                        val input = socket.getInputStream().buffered()
                        fun line(): String {
                            val text = StringBuilder()
                            while (true) {
                                val ch = input.read()
                                if (ch < 0 || ch == 10) return text.toString().trimEnd('\r')
                                text.append(ch.toChar())
                            }
                        }
                        val requestLine = line()
                        if (requestLine.isEmpty()) return@use
                        var length = 0
                        while (true) {
                            val header = line()
                            if (header.isEmpty()) break
                            if (header.startsWith("Content-Length:", ignoreCase = true)) {
                                length = header.substringAfter(':').trim().toInt()
                            }
                        }
                        repeat(length) { input.read() }
                        received.incrementAndGet()
                        if (code != null) {
                            val response = "HTTP/1.1 $code Test\r\nContent-Length: 0\r\nConnection: close\r\nRetry-After: 0\r\nLocation: http://127.0.0.1:${server.localPort}/again\r\n\r\n"
                            socket.getOutputStream().write(response.toByteArray())
                            socket.getOutputStream().flush()
                        }
                    }
                }
            } catch (_: SocketException) {
                // Test closes listening socket after the call finishes.
            }
        }.apply { isDaemon = true; start() }
        val client = MessageSendTransport.client(OkHttpClient.Builder()
            .readTimeout(2, TimeUnit.SECONDS).callTimeout(4, TimeUnit.SECONDS).build())
        try {
            val request = Request.Builder().url("http://127.0.0.1:${server.localPort}/send")
                .post(MessageSendTransport.oneShot("{}".toRequestBody("application/json".toMediaType()))).build()
            val result = runCatching { client.newCall(request).execute().use { it.code } }
            if (code == null) assertTrue(result.isFailure) else assertEquals(code, result.getOrThrow())
            assertEquals("One user send must cause exactly one HTTP POST", 1, received.get())
        } finally {
            server.close()
            thread.join(2000)
            client.connectionPool.evictAll()
            client.dispatcher.executorService.shutdown()
        }
    }
}
