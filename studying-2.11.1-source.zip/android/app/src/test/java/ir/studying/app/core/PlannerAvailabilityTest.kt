package ir.studying.app.core

import ir.studying.app.notify.PlannerNightly
import ir.studying.app.ui.planner.PlannerViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

/** The paused release must not require Android, a cache, a session, or a server to open. */
class PlannerAvailabilityTest {
    @Test
    fun `planner is disabled for this release`() {
        assertFalse(PlannerAvailability.ENABLED)
        assertEquals("به‌زودی", PlannerAvailability.BADGE)
        assertEquals("پلنر به‌زودی فعال می‌شود", PlannerAvailability.MESSAGE)
    }

    @Test
    fun `network guard fails with the coming soon message`() {
        val error = assertThrows(IllegalStateException::class.java) { PlannerAvailability.requireEnabled() }
        assertEquals(PlannerAvailability.MESSAGE, error.message)
    }

    @Test
    fun `view model does not boot or restore a plan when disabled`() {
        val vm = PlannerViewModel()
        assertFalse(vm.state.value.booting)
        assertNull(vm.state.value.result)
        assertFalse(vm.state.value.building)
        assertEquals(emptyList<Any>(), vm.state.value.tracks)
    }

    @Test
    fun `all plan generation entry points stop before side effects`() {
        val vm = PlannerViewModel()
        vm.finishOnboarding()
        vm.buildPlan(force = true)
        vm.send("یک برنامه بساز", confirmedReplace = true)
        vm.replan()
        val state = vm.state.value
        assertEquals(PlannerAvailability.MESSAGE, state.error)
        assertFalse(state.savingProfile)
        assertFalse(state.building)
        assertFalse(state.sending)
        assertFalse(state.replanning)
        assertNull(state.result)
        assertEquals(emptyList<Any>(), state.messages)
    }

    @Test
    fun `nightly report returns without reading Android cache`() = runBlocking {
        assertNull(PlannerNightly.buildReport())
    }

    @Test
    fun `planner API refuses requests before creating a network call`() {
        val error = assertThrows(IllegalStateException::class.java) {
            runBlocking { PlannerApi.get("/v1/tracks") }
        }
        assertEquals(PlannerAvailability.MESSAGE, error.message)
    }
}
