package ir.studying.app.core

import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class ReportNavigationTest {
    @Test fun reportIsRestoredAsBottomTab() {
        assertTrue(NavBus.TAB_ROUTES.contains("report"))
        assertTrue(NavBus.routeMatches("report", "report"))
        assertFalse(NavBus.routeMatches("profile", "report"))
    }
}
