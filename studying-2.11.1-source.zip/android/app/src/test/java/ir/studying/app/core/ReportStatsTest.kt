package ir.studying.app.core

import java.util.Calendar
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportStatsTest {

    @Test
    fun epochDayRoundTripsAgainstTheJavaCalendar() {
        val c = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        c.clear()
        c.set(2019, Calendar.DECEMBER, 25)
        repeat(2200) {
            val iso = ReportStats.isoOf(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
            val e = ReportStats.epochDay(iso)!!
            assertEquals(c.timeInMillis / 86_400_000L, e)
            assertEquals(iso, ReportStats.isoOfEpochDay(e))
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
    }

    @Test
    fun invalidDatesAreRejected() {
        assertNull(ReportStats.epochDay(null))
        assertNull(ReportStats.epochDay(""))
        assertNull(ReportStats.epochDay("2025/01/01"))
        assertNull(ReportStats.epochDay("2025-13-01"))
        assertEquals("bad", ReportStats.shift("bad", 3))
    }

    @Test
    fun weekdayMatchesTheIranianWeek() {
        // ۲۰۲۵-۰۳-۲۲ شنبه است.
        assertEquals(0, ReportStats.weekdayIndex("2025-03-22"))
        assertEquals(6, ReportStats.weekdayIndex("2025-03-28"))
        assertEquals(5, ReportStats.weekdayIndex("1970-01-01"))
        val c = Calendar.getInstance(IranTime.ZONE)
        c.clear()
        c.set(2024, Calendar.JANUARY, 1, 12, 0, 0)
        repeat(60) {
            val iso = ReportStats.isoOf(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
            assertEquals(iso, Jalali.weekDayIndex(c.time), ReportStats.weekdayIndex(iso))
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        assertEquals("2025-03-22", ReportStats.weekStart("2025-03-26"))
        assertEquals("2025-03-22", ReportStats.weekStart("2025-03-22"))
    }

    @Test
    fun windowsEndTodayAndCrossMonthAndYearEdges() {
        assertEquals(listOf("2024-12-30", "2024-12-31", "2025-01-01"), ReportStats.window("2025-01-01", 3))
        assertEquals(listOf("2024-02-28", "2024-02-29", "2024-03-01"), ReportStats.window("2024-03-01", 3))
        assertEquals(emptyList<String>(), ReportStats.window("2024-03-01", 0))
        assertEquals("2025-01-06", ReportStats.shift("2024-12-31", 6))
        assertEquals(-6, ReportStats.daysBetween("2025-01-06", "2024-12-31"))
    }

    @Test
    fun summaryCountsOnlyRealStudy() {
        val days = mapOf(
            "2025-03-20" to ReportStats.Day(90, 2),
            "2025-03-21" to ReportStats.Day(0, 0),
            "2025-03-23" to ReportStats.Day(150, 3),
            "2025-03-10" to ReportStats.Day(500, 9),
        )
        val s = ReportStats.summarize(ReportStats.window("2025-03-23", 7), days)
        assertEquals(7, s.days)
        assertEquals(240, s.total)
        assertEquals(2, s.activeDays)
        assertEquals(5, s.sessions)
        assertEquals("2025-03-23", s.bestIso)
        assertEquals(150, s.bestMinutes)
        assertEquals(34, s.avgPerDay)
        assertEquals(120, s.avgPerActiveDay)
        assertEquals(48, s.avgSession)
    }

    @Test
    fun deltaNeedsSomethingToCompareWith() {
        assertNull(ReportStats.deltaPercent(100, 0))
        assertEquals(50, ReportStats.deltaPercent(150, 100))
        assertEquals(-25, ReportStats.deltaPercent(75, 100))
        assertEquals(0, ReportStats.deltaPercent(100, 100))
    }

    @Test
    fun currentStreakWaitsForTodayAndLongestFindsTheBestRun() {
        val m = mapOf("2025-03-20" to 30, "2025-03-21" to 40, "2025-03-22" to 10, "2025-03-18" to 60)
        assertEquals(3, ReportStats.currentStreak(m, "2025-03-22"))
        // امروز هنوز چیزی نخوانده، زنجیره از دیروز حساب می‌شود.
        assertEquals(3, ReportStats.currentStreak(m, "2025-03-23"))
        assertEquals(0, ReportStats.currentStreak(m, "2025-03-25"))
        val run = ReportStats.longestStreak(m + mapOf("2025-02-01" to 5, "2025-02-02" to 5, "2025-02-03" to 5, "2025-02-04" to 5, "2025-02-05" to 0))
        assertEquals(4, run.length)
        assertEquals("2025-02-04", run.endIso)
        assertEquals(0, ReportStats.longestStreak(emptyMap()).length)
    }

    @Test
    fun movingAverageTrailsTheWindow() {
        val avg = ReportStats.movingAverage(listOf(10, 20, 30, 40), 2)
        assertEquals(listOf(10f, 15f, 25f, 35f), avg)
        assertEquals(listOf(1f, 2f), ReportStats.movingAverage(listOf(1, 2), 1))
    }

    @Test
    fun weekdaysAverageByOccurrences() {
        val dates = ReportStats.window("2025-03-28", 14) // دو هفتهٔ کامل شنبه تا جمعه
        val w = ReportStats.weekdays(dates, mapOf("2025-03-22" to 60, "2025-03-15" to 120, "2025-03-28" to 30))
        assertEquals(listOf(2, 2, 2, 2, 2, 2, 2), w.counts)
        assertEquals(180, w.totals[0])
        assertEquals(90, w.averages[0])
        assertEquals(15, w.averages[6])
    }

    @Test
    fun hoursFoldIntoDayParts() {
        val hours = MutableList(24) { 0 }
        hours[6] = 30; hours[13] = 20; hours[18] = 10; hours[22] = 50; hours[2] = 5
        assertEquals(listOf(30, 20, 10, 55), ReportStats.dayParts(hours))
        assertEquals(22, ReportStats.peakHour(hours))
        assertEquals(-1, ReportStats.peakHour(List(24) { 0 }))
    }

    @Test
    fun spansClipAtMidnightAndCompareTheSameTimeOfDay() {
        assertEquals(510, ReportStats.minuteOfDay("08:30"))
        assertEquals(510, ReportStats.minuteOfDay("08:30:00"))
        assertNull(ReportStats.minuteOfDay("8"))
        assertNull(ReportStats.minuteOfDay("xx:10"))
        assertEquals(1410 to 1440, ReportStats.span("23:30", 60))
        val yesterday = listOf(ReportStats.span("08:00", 60)!!, ReportStats.span("10:00", 90)!!)
        assertEquals(60 + 30, ReportStats.minutesUntil(yesterday, 10 * 60 + 30))
        assertEquals(0, ReportStats.minutesUntil(yesterday, 7 * 60))
    }

    @Test
    fun axisIsRoundAndAlwaysCoversTheData() {
        assertEquals(180 to 60, ReportStats.niceAxis(100, 3))
        assertEquals(120 to 30, ReportStats.niceAxis(100, 4))
        assertEquals(30 to 10, ReportStats.niceAxis(25, 3))
        for (v in listOf(1, 7, 44, 59, 61, 100, 179, 300, 721, 1440, 5000)) {
            val (top, step) = ReportStats.niceAxis(v, 3)
            assertTrue("$v -> $top", top >= v)
            assertEquals(top, step * 3)
        }
        assertEquals("۴۵د", ReportStats.axisLabel(45))
        assertEquals("۲س", ReportStats.axisLabel(120))
        assertEquals("۱:۳۰", ReportStats.axisLabel(90))
        assertEquals("۰:۰۵", ReportStats.clock(5))
        assertEquals("۱۲:۴۰", ReportStats.clock(760))
    }

    @Test
    fun jalaliMonthsStopAtToday() {
        // ۲۰۲۵-۰۳-۲۵ = ۵ فروردین ۱۴۰۴؛ اسفند ۱۴۰۳ کبیسه و ۳۰ روزه است.
        val m = ReportStats.jalaliMonths(mapOf("2025-03-21" to 60, "2025-03-25" to 30, "2025-03-20" to 100), "2025-03-25", 3)
        assertEquals(3, m.size)
        assertEquals(1404, m[0].year); assertEquals(1, m[0].month)
        assertEquals(5, m[0].elapsedDays)
        assertEquals(90, m[0].minutes)
        assertEquals(2, m[0].activeDays)
        assertEquals("2025-03-21", m[0].firstIso)
        assertEquals(1403, m[1].year); assertEquals(12, m[1].month)
        assertEquals(30, m[1].elapsedDays)
        assertEquals(100, m[1].minutes)
        assertEquals(11, m[2].month)
        assertEquals(30, ReportStats.jalaliMonthLength(1403, 12))
        assertEquals(29, ReportStats.jalaliMonthLength(1404, 12))
        assertEquals(31, ReportStats.jalaliMonthLength(1404, 6))
    }

    @Test
    fun heatLevelsUseARobustScale() {
        val scale = ReportStats.heatScale(listOf(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 1000))
        assertEquals(90, scale)
        assertEquals(0, ReportStats.heatLevel(0, scale))
        assertEquals(1, ReportStats.heatLevel(10, scale))
        assertEquals(2, ReportStats.heatLevel(40, scale))
        assertEquals(4, ReportStats.heatLevel(1000, scale))
        assertEquals(4, ReportStats.heatLevel(5, 0))
        assertEquals(0, ReportStats.heatScale(listOf(0, 0)))
    }
}
