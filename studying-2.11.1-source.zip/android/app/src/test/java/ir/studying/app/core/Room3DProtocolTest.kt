package ir.studying.app.core

import ir.studying.app.player.Pomodoro
import ir.studying.app.ui.study.room.Room3DProtocol
import ir.studying.app.ui.study.room.RoomCheer
import ir.studying.app.ui.study.room.RoomOccupant
import ir.studying.app.ui.study.room.RoomState
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** پل اتاق سه‌بعدی: هر چیزی که بین WebView و اپ رد و بدل می‌شود. */
class Room3DProtocolTest {

    private val prefix = "window.R3&&window.R3.push&&window.R3.push("

    private fun decode(js: String): String {
        assertTrue(js.startsWith(prefix))
        assertTrue(js.endsWith(");"))
        val literal = js.removePrefix(prefix).removeSuffix(");")
        // لفظ رشته باید یک رشتهٔ JSON معتبر و تنها باشد
        return JSONArray("[$literal]").let { assertEquals(1, it.length()); it.getString(0) }
    }

    @Test
    fun `push script keeps any payload inside one safe JS string`() {
        val raw = "{\"text\":\"</script><img src=x onerror=alert(1)> \\\"q\\\" 'a' \u2028line\u2029para \\\\ end\"}"
        val js = Room3DProtocol.pushScript(raw)
        assertFalse(js.contains('\u2028'))
        assertFalse(js.contains('\u2029'))
        assertFalse(js.contains('\n'))
        assertFalse(js.contains("</script>", ignoreCase = true))
        assertEquals(raw, decode(js))
    }

    @Test
    fun `push script round trips real state messages`() {
        val msg = Room3DProtocol.toast("سلام «دوست» \"من\" 👋", "good").toString()
        val back = JSONObject(decode(Room3DProtocol.pushScript(msg)))
        assertEquals("toast", back.getString("t"))
        assertEquals("سلام «دوست» \"من\" 👋", back.getString("text"))
        assertEquals("good", back.getString("kind"))
    }

    @Test
    fun `parse accepts only whitelisted message types`() {
        assertNull(Room3DProtocol.parse(null, "{}"))
        assertNull(Room3DProtocol.parse("", "{}"))
        assertNull(Room3DProtocol.parse("eval", "{}"))
        assertNull(Room3DProtocol.parse("open_url", "{\"url\":\"https://x\"}"))
        val ok = Room3DProtocol.parse(" focus_toggle ", null)
        assertNotNull(ok)
        assertEquals("focus_toggle", ok!!.first)
        assertEquals(0, ok.second.length())
        Room3DProtocol.ALLOWED.forEach { assertNotNull(it, Room3DProtocol.parse(it, "{}")) }
    }

    @Test
    fun `parse rejects broken or oversized json`() {
        assertNull(Room3DProtocol.parse("claim", "{bad"))
        assertNull(Room3DProtocol.parse("claim", "[1,2]"))
        val big = "{\"x\":\"" + "a".repeat(Room3DProtocol.MAX_JSON) + "\"}"
        assertNull(Room3DProtocol.parse("debug", big))
        val claim = Room3DProtocol.parse("claim", "{\"rid\":7,\"kind\":\"quest\",\"key\":\"focus60\"}")!!
        assertEquals(7, claim.second.getInt("rid"))
        assertEquals("quest", claim.second.getString("kind"))
    }

    @Test
    fun `only bundled game files can be loaded`() {
        assertTrue(Room3DProtocol.isAllowedUrl(Room3DProtocol.ENTRY))
        assertTrue(Room3DProtocol.isAllowedUrl("file:///android_asset/room3d/r3-world.js?v=2#x"))
        assertTrue(Room3DProtocol.isAllowedUrl("file:///android_asset/room3d/fonts/Vazirmatn.woff2"))
        assertTrue(Room3DProtocol.isAllowedUrl("data:image/png;base64,AAAA"))
        assertTrue(Room3DProtocol.isAllowedUrl("blob:null/1234"))

        assertFalse(Room3DProtocol.isAllowedUrl("https://example.com/three.js"))
        assertFalse(Room3DProtocol.isAllowedUrl("http://10.0.0.1/"))
        assertFalse(Room3DProtocol.isAllowedUrl("file:///android_asset/room3d/"))
        assertFalse(Room3DProtocol.isAllowedUrl("file:///android_asset/room3d/../secret.txt"))
        assertFalse(Room3DProtocol.isAllowedUrl("file:///android_asset/room3d/%2E%2E/secret.txt"))
        assertFalse(Room3DProtocol.isAllowedUrl("file:///android_asset/room3d/a\\..\\b"))
        assertFalse(Room3DProtocol.isAllowedUrl("file:///android_asset/other/index.html"))
        assertFalse(Room3DProtocol.isAllowedUrl("file:///data/data/ir.studying.app/shared_prefs/auth.xml"))
        assertFalse(Room3DProtocol.isAllowedUrl("content://ir.studying.app.provider/x"))
        assertFalse(Room3DProtocol.isAllowedUrl("javascript:alert(1)"))
    }

    @Test
    fun `results carry either data or an error`() {
        val ok = Room3DProtocol.result(5, JSONObject().put("coins", 12), null)
        assertEquals("result", ok.getString("t"))
        assertEquals(5, ok.getInt("rid"))
        assertTrue(ok.getBoolean("ok"))
        assertEquals(12, ok.getJSONObject("data").getInt("coins"))
        assertFalse(ok.has("error"))

        val empty = Room3DProtocol.result(6, null, null)
        assertTrue(empty.getBoolean("ok"))
        assertEquals(0, empty.getJSONObject("data").length())

        val bad = Room3DProtocol.result(8, JSONObject().put("x", 1), "سکه کافی نیست")
        assertFalse(bad.getBoolean("ok"))
        assertEquals("سکه کافی نیست", bad.getString("error"))
        assertFalse(bad.has("data"))
    }

    @Test
    fun `toasts are trimmed`() {
        assertEquals(300, Room3DProtocol.toast("x".repeat(1000)).getString("text").length)
        assertEquals("", Room3DProtocol.toast("hi").getString("kind"))
    }

    @Test
    fun `timer message follows the pomodoro phase`() {
        val cfg = Pomodoro.Config(workMin = 50, breakMin = 10, longBreakMin = 20)
        val br = Room3DProtocol.timer(
            Pomodoro.State(Pomodoro.Phase.BREAK, remainingSec = -4, running = true, completedWork = 2, config = cfg),
            pendingMin = -3, chronoRunning = false, chronoSec = -1,
        )
        assertEquals("timer", br.getString("t"))
        assertEquals("break", br.getString("phase"))
        assertTrue(br.getBoolean("running"))
        assertEquals(0, br.getInt("remaining"))
        assertEquals(600, br.getInt("total"))
        assertEquals(2, br.getInt("completed"))
        assertEquals(50, br.getInt("work_min"))
        assertEquals(10, br.getInt("break_min"))
        assertEquals(20, br.getInt("long_min"))
        assertEquals(0, br.getInt("pending_min"))
        assertEquals(0, br.getInt("chrono_sec"))

        val idle = Room3DProtocol.timer(Pomodoro.State(config = cfg), 7, true, 95)
        assertEquals("idle", idle.getString("phase"))
        assertEquals(3000, idle.getInt("total"))
        assertEquals(7, idle.getInt("pending_min"))
        assertTrue(idle.getBoolean("chrono_running"))
        assertEquals(95, idle.getInt("chrono_sec"))

        val long = Room3DProtocol.timer(Pomodoro.State(Pomodoro.Phase.LONG_BREAK, 100, false, 4, cfg), 0, false, 0)
        assertEquals("long_break", long.getString("phase"))
        assertEquals(1200, long.getInt("total"))
        assertEquals("work", Room3DProtocol.phaseKey(Pomodoro.Phase.WORK))
    }

    private fun me() = Room3DProtocol.Me(
        username = "ali", character = "fox", level = 3, levelTitle = "کوشا", levelEmoji = "📘",
        xp = 420, levelStartXp = 300, nextLevelXp = 600, coins = 55, streak = 4, todayMinutes = 75,
        desk = mapOf("lamp" to "lamp_gold"),
    )

    private fun occ(i: Int) = RoomOccupant(i, "u$i", "cat", RoomState.STUDYING, i * 10, 3, hat = "crown", combo = 2)

    @Test
    fun `state message is capped and complete`() {
        val s = Room3DProtocol.state(
            me = me(), online = 14, theme = "rasht", night = true, error = " ",
            others = (1..20).map(::occ), cheers = (1..9).map { RoomCheer("👏", "u$it") },
            snapSeq = 9, r3 = null, serverR3 = null,
        )
        assertEquals("state", s.getString("t"))
        val m = s.getJSONObject("me")
        assertEquals("ali", m.getString("username"))
        assertEquals(600, m.getInt("next_level_xp"))
        assertEquals("lamp_gold", m.getJSONObject("desk").getString("lamp"))
        val room = s.getJSONObject("room")
        assertEquals(14, room.getInt("online"))
        assertEquals("rasht", room.getString("theme"))
        assertTrue(room.getBoolean("night"))
        assertFalse(room.has("error"))
        val others = s.getJSONArray("others")
        assertEquals(11, others.length())
        assertEquals("crown", others.getJSONObject(0).getString("hat"))
        assertEquals(2, others.getJSONObject(0).getInt("combo"))
        assertEquals(RoomState.STUDYING, others.getJSONObject(0).getString("state"))
        assertEquals(5, s.getJSONArray("cheers").length())
        assertEquals(9, s.getInt("snap_seq"))
        assertTrue(s.isNull("r3"))
        assertTrue(s.isNull("server_r3"))

        val withR3 = Room3DProtocol.state(
            me(), 1, "library", false, "اتصال برقرار نیست", emptyList(), emptyList(), 1,
            JSONObject().put("combo", 3), false,
        )
        assertEquals("اتصال برقرار نیست", withR3.getJSONObject("room").getString("error"))
        assertEquals(3, withR3.getJSONObject("r3").getInt("combo"))
        assertFalse(withR3.getBoolean("server_r3"))
    }

    @Test
    fun `occupants from old servers get safe defaults`() {
        val old = RoomOccupant.from(JSONObject("{\"user_id\":\"12\",\"username\":\"sara\",\"minutes_today\":\"40\"}"))
        assertEquals(12, old.userId)
        assertEquals("", old.hat)
        assertEquals(0, old.combo)
        assertEquals("cat", old.character)
        assertEquals(RoomState.IDLE, old.state)

        val wild = RoomOccupant.from(
            JSONObject().put("user_id", 3).put("hat", "h".repeat(90)).put("combo", 99).put("hat2", "x"),
        )
        assertEquals(40, wild.hat.length)
        assertEquals(4, wild.combo)
        assertEquals(0, RoomOccupant.from(JSONObject().put("combo", -5)).combo)
        assertEquals(0, RoomOccupant.from(JSONObject().put("combo", JSONObject.NULL).put("hat", JSONObject.NULL)).combo)
        assertEquals("", RoomOccupant.from(JSONObject().put("hat", JSONObject.NULL)).hat)
    }
}
