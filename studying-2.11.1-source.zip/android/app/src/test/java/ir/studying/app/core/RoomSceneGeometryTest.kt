package ir.studying.app.core

import ir.studying.app.ui.study.room.RoomSceneGeometry
import ir.studying.app.ui.study.room.RoomTheme
import ir.studying.app.ui.study.room.RoomRect
import java.io.File
import org.junit.Assert.*
import org.junit.Test

class RoomSceneGeometryTest {
    private val sizes = listOf(320f to 640f, 320f to 800f, 360f to 600f,
        360f to 800f, 360f to 880f, 411f to 891f, 600f to 960f)
    private fun allScenes() = sizes.flatMap { (w, h) -> RoomTheme.entries.flatMap { theme ->
        listOf(false, true).map { night -> RoomSceneGeometry(w, h, theme, night) }
    } }

    @Test fun `timer panels are onscreen and never cover the clock frame`() {
        allScenes().forEach { s ->
            listOf(s.pomodoro, s.chronometer).forEach { r ->
                assertTrue("$s $r", r.x >= 9.9f && r.right <= s.width - 9.9f)
                assertTrue(r.y >= 78f && r.bottom < s.backDeskTop)
                assertTrue("Readable timer width: $s", r.width >= 72f)
            }
            assertTrue(s.pomodoro.right <= s.clockX - s.frameRadius - 8.9f)
            assertTrue(s.chronometer.x >= s.clockX + s.frameRadius + 8.9f)
        }
    }

    @Test fun `statistics clear toolbar and clock on all portrait layouts`() {
        allScenes().forEach { s ->
            s.statistics.forEach { r ->
                assertTrue("$s $r", r.y >= 78f)
                assertTrue(r.x >= 9.9f && r.right <= s.width - 9.9f)
                assertTrue(r.bottom <= s.clockY - s.frameRadius - 11.9f)
            }
            assertTrue(s.statistics[0].right < s.statistics[1].x)
            assertTrue(s.statistics[1].right < s.statistics[2].x)
        }
    }

    @Test fun `sprite sizes are capped by width and desks occlude their lower bodies`() {
        allScenes().forEach { s ->
            val widestBody = s.backCanvas * 0.92f
            assertTrue(widestBody < s.backCenters[1] - s.backCenters[0])
            assertTrue(s.backCenters.first() - widestBody / 2f > 0f)
            assertTrue(s.backCenters.last() + widestBody / 2f < s.width)
            assertEquals(0.173f, (s.backBaseline - s.backDeskTop) / s.backCanvas, 0.00001f)
            assertEquals(0.173f, (s.frontBaseline - s.frontDeskTop) / s.frontCanvas, 0.00001f)
            assertTrue(s.backDeskTop < s.frontDeskTop)
            assertTrue(s.backBaseline < s.height)
        }
    }

    @Test fun `background mapping stays identical in dp and physical pixels`() {
        allScenes().forEach { s ->
            val px = RoomSceneGeometry(s.width * 3f, s.height * 3f, s.theme, s.night)
            assertEquals(s.clockX * 3f, px.clockX, 0.001f)
            assertEquals(s.clockY * 3f, px.clockY, 0.001f)
            assertEquals(s.faceRadius * 3f, px.faceRadius, 0.001f)
            assertEquals(s.background.top * 3f, px.background.top, 0.001f)
        }
    }

    @Test fun `export renderer geometry for visual reconstruction`() {
        val rows = mutableListOf("theme,night,width,height,bgLeft,bgTop,bgWidth,bgHeight,clockX,clockY,faceR,frameR,pomoX,pomoY,pomoW,pomoH,chronoX,chronoY,chronoW,chronoH,statY,statW,statH,backDesk,backDeskH,frontDesk,backCanvas,frontCanvas,backBaseline,frontBaseline")
        allScenes().forEach { s ->
            rows += listOf(s.theme.key, s.night, s.width, s.height, s.background.left, s.background.top,
                s.background.drawnWidth, s.background.drawnHeight, s.clockX, s.clockY, s.faceRadius,
                s.frameRadius, s.pomodoro.x, s.pomodoro.y, s.pomodoro.width, s.pomodoro.height,
                s.chronometer.x, s.chronometer.y, s.chronometer.width, s.chronometer.height,
                s.statistics[0].y, s.statistics[0].width, s.statistics[0].height,
                s.backDeskTop, s.backDeskHeight, s.frontDeskTop, s.backCanvas, s.frontCanvas,
                s.backBaseline, s.frontBaseline).joinToString(",")
        }
        File("build/reports/room-theme-geometry.csv").apply { parentFile?.mkdirs(); writeText(rows.joinToString("\n")) }
    }
}
