package ir.studying.app.core

import android.content.SharedPreferences
import ir.studying.app.ui.study.room.RoomPrefs
import ir.studying.app.ui.study.room.RoomTheme
import java.lang.reflect.Proxy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoomThemeTest {
    @Test
    fun `old installs default to the existing library`() {
        assertEquals(RoomTheme.LIBRARY, RoomTheme.fromKey(null))
        assertEquals(RoomTheme.LIBRARY, RoomTheme.fromKey(""))
    }

    @Test
    fun `unknown saved theme is safe`() {
        assertEquals(RoomTheme.LIBRARY, RoomTheme.fromKey("unknown_future_theme"))
    }

    @Test
    fun `saved identifiers round trip without localization dependencies`() {
        RoomTheme.entries.forEach { assertEquals(it, RoomTheme.fromKey(it.key)) }
        assertEquals(5, RoomTheme.entries.map { it.key }.toSet().size)
    }

    @Test
    fun `both themes have distinct day and night backgrounds`() {
        val resources = RoomTheme.entries.flatMap { listOf(it.backgroundRes(false), it.backgroundRes(true)) }
        assertEquals(10, resources.toSet().size)
        assertTrue(resources.all { it != 0 })
    }

    @Test
    fun `library dial fills the artwork without covering its wooden frame`() {
        assertEquals(384f, RoomTheme.LIBRARY.clockCenterX(false) * 768f, 0.01f)
        assertEquals(685f, RoomTheme.LIBRARY.clockCenterY(false) * 1376f, 0.01f)
        assertEquals(384.5f, RoomTheme.LIBRARY.clockCenterX(true) * 768f, 0.01f)
        assertEquals(693f, RoomTheme.LIBRARY.clockCenterY(true) * 1376f, 0.01f)
        assertEquals(50.5f, RoomTheme.LIBRARY.clockFaceRadius * 768f, 0.01f)
    }

    @Test
    fun `special themes require the shared subscription feature not legacy coin ownership`() {
        RoomTheme.entries.filter { it.requiresSubscription }.forEach { theme ->
            assertTrue(!theme.isUnlocked(false))
            assertTrue(theme.isUnlocked(true))
        }
        assertTrue(RoomTheme.LIBRARY.isUnlocked(false))
    }

    @Test
    fun `all new themes share the subscription while base stays free`() {
        val themes = listOf(RoomTheme.ANCIENT_IRAN, RoomTheme.RASHT, RoomTheme.WHITE_NIGHTS, RoomTheme.JAPANESE)
        assertEquals(4, themes.size)
        themes.forEach { assertTrue(it.requiresSubscription) }
        assertTrue(!RoomTheme.LIBRARY.requiresSubscription)
    }

    @Test
    fun `new dial measurements fit the supplied decorative frames`() {
        assertEquals(43f, RoomTheme.RASHT.clockFaceRadius * 768f, 0.01f)
        assertEquals(43.5f, RoomTheme.WHITE_NIGHTS.clockFaceRadius * 768f, 0.01f)
        assertEquals(48.5f, RoomTheme.JAPANESE.clockFaceRadius * 768f, 0.01f)
        assertTrue(!RoomTheme.RASHT.printedTicks)
        assertTrue(RoomTheme.WHITE_NIGHTS.printedTicks)
        assertTrue(RoomTheme.JAPANESE.printedTicks)
        RoomTheme.entries.forEach { t ->
            assertTrue(t.clockFrameRadius > t.clockFaceRadius)
        }
    }

    @Test
    fun `unpaid theme cannot be selected through preferences`() {
        Game.clear()
        RoomPrefs.setTheme(RoomTheme.LIBRARY)
        RoomPrefs.setTheme(RoomTheme.ANCIENT_IRAN)
        assertEquals(RoomTheme.LIBRARY, RoomPrefs.theme.value)
    }

    @Test
    fun `new clock face aligns to the supplied bronze frame`() {
        assertEquals(384f, RoomTheme.ANCIENT_IRAN.clockCenterX(false) * 768f, 0.01f)
        assertEquals(686.5f, RoomTheme.ANCIENT_IRAN.clockCenterY(false) * 1376f, 0.01f)
        assertEquals(45f, RoomTheme.ANCIENT_IRAN.clockFaceRadius * 768f, 0.01f)
    }

    @Test
    fun `free theme selection persists only its own key`() {
        val writes = mutableMapOf<String, String?>()
        var applied = false
        lateinit var editor: SharedPreferences.Editor
        editor = Proxy.newProxyInstance(SharedPreferences.Editor::class.java.classLoader,
            arrayOf(SharedPreferences.Editor::class.java)) { _, method, args ->
            when (method.name) {
                "putString" -> { writes[args!![0] as String] = args[1] as String?; editor }
                "apply" -> { applied = true; null }
                else -> error("Unexpected preference mutation: ${method.name}")
            }
        } as SharedPreferences.Editor
        val prefs = Proxy.newProxyInstance(SharedPreferences::class.java.classLoader,
            arrayOf(SharedPreferences::class.java)) { _, method, _ ->
            when (method.name) {
                "edit" -> editor
                else -> error("Unexpected preference access: ${method.name}")
            }
        } as SharedPreferences
        val field = RoomPrefs::class.java.getDeclaredField("prefs").apply { isAccessible = true }
        val previousPrefs = field.get(RoomPrefs)
        val previousTheme = RoomPrefs.theme.value
        try {
            field.set(RoomPrefs, prefs)
            RoomPrefs.setTheme(RoomTheme.LIBRARY)
            assertEquals(RoomTheme.LIBRARY, RoomPrefs.theme.value)
            assertEquals(mapOf("room_theme" to "library"), writes)
            assertTrue(applied)
        } finally {
            field.set(RoomPrefs, previousPrefs)
            RoomPrefs.setTheme(previousTheme)
        }
    }
}
