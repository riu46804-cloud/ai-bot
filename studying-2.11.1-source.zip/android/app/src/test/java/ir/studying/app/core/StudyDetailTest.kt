package ir.studying.app.core

import ir.studying.app.data.StudyDetail
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure model tests; no Android/JSON methods or network calls are invoked. */
class StudyDetailTest {
    @Test fun `written questions make a nonempty report without affecting MC totals`() {
        assertTrue(StudyDetail().isEmpty)
        val detail = StudyDetail(qDescriptive = 7)
        assertFalse(detail.isEmpty)
        assertEquals(0, detail.qTotal)
        assertEquals(0.0, detail.examPercent, 0.00001)
        assertNull(detail.validationError(30))
        assertEquals(10, detail.copy(qCorrect = 6, qWrong = 2, qBlank = 2).qTotal)
    }

    @Test fun `invalid counts and over budget time are rejected`() {
        assertNotNull(StudyDetail(qDescriptive = -1).validationError(60))
        assertNotNull(StudyDetail(qDescriptive = 2001).validationError(60))
        assertNotNull(StudyDetail(qCorrect = 1200, qWrong = 900).validationError(60))
        assertNotNull(StudyDetail(qCorrect = Int.MAX_VALUE).validationError(60))
        assertNotNull(StudyDetail(minVideo = 40, minTest = 30).validationError(60))
        assertNotNull(StudyDetail(minVideo = -1).validationError(60))
        assertNull(StudyDetail(qCorrect = 2000, qDescriptive = 2000, minVideo = 60).validationError(60))
    }

    @Test fun `splitting combined timers keeps questions once and topic on every block`() {
        val detail = StudyDetail(topicId = 12, qCorrect = 6, qWrong = 2, qBlank = 2,
            qDescriptive = 7, minVideo = 30, minTest = 25, minBook = 5, focus = 85, note = "report")
        val budgets = listOf(25, 25, 20)
        val parts = detail.splitAcross(budgets)
        assertEquals(10, parts.sumOf { it.qTotal })
        assertEquals(7, parts.sumOf { it.qDescriptive })
        assertEquals(60, parts.sumOf { it.activityMinutes })
        assertEquals(listOf(12, 12, 12), parts.map { it.topicId })
        assertEquals(listOf(85, 85, 85), parts.map { it.focus })
        assertEquals(listOf("report", "", ""), parts.map { it.note })
        parts.forEachIndexed { i, part -> assertNull(part.validationError(budgets[i])) }
    }

    @Test(expected = IllegalArgumentException::class)
    fun `model splitting rejects an impossible activity budget`() {
        StudyDetail(minVideo = 60).splitAcross(listOf(25, 25))
    }
}
