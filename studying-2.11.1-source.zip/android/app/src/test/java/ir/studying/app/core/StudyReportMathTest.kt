package ir.studying.app.core

import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class StudyReportMathTest {
    @Test fun `zero and all blank reports have zero score`() {
        assertEquals(0.0, StudyReportMath.examPercent(0, 0, 0), 0.00001)
        assertEquals(0.0, StudyReportMath.examPercent(0, 0, 12), 0.00001)
        assertEquals(0.0, StudyReportMath.accuracyPercent(0, 0), 0.00001)
    }

    @Test fun `exam score counts blanks and one third negative marking`() {
        assertEquals(53.333333, StudyReportMath.examPercent(6, 2, 2), 0.00001)
        assertEquals(75.0, StudyReportMath.accuracyPercent(6, 2), 0.00001)
        assertEquals(100.0, StudyReportMath.examPercent(10, 0, 0), 0.00001)
        assertEquals(50.0, StudyReportMath.examPercent(5, 0, 5), 0.00001)
        assertEquals(0.0, StudyReportMath.examPercent(1, 3, 0), 0.00001)
    }

    @Test fun `negative exam scores are preserved`() {
        assertEquals(-33.333333, StudyReportMath.examPercent(0, 5, 0), 0.00001)
        assertEquals(-16.666667, StudyReportMath.examPercent(0, 5, 5), 0.00001)
    }

    @Test fun `scores round to one decimal with locale digits`() {
        assertEquals("53.3", StudyReportMath.formatPercent(StudyReportMath.examPercent(6, 2, 2), Locale.US))
        assertEquals("66.7", StudyReportMath.formatPercent(StudyReportMath.examPercent(2, 0, 1), Locale.US))
        assertEquals("-33.3", StudyReportMath.formatPercent(StudyReportMath.examPercent(0, 5, 0), Locale.US))
        assertEquals("0.0", StudyReportMath.formatPercent(0.0, Locale.US))
        assertEquals("۶۶٫۷", StudyReportMath.formatPercent(StudyReportMath.examPercent(2, 0, 1), Locale("fa")))
    }

    @Test fun `large aggregate counts do not overflow integer multiplication`() {
        assertEquals(50.0, StudyReportMath.examPercent(Int.MAX_VALUE, 0, Int.MAX_VALUE), 0.00001)
        assertEquals(50.0, StudyReportMath.accuracyPercent(Int.MAX_VALUE, Int.MAX_VALUE), 0.00001)
    }

    @Test fun `Latin Persian Arabic and mixed digits parse identically`() {
        assertEquals("123456", StudyNumberInput.normalize("1۲٣4۵٦"))
        assertEquals(2000, StudyNumberInput.parse("۲۰۰۰", 2000))
        assertEquals(1440, StudyNumberInput.parse("١٤٤٠", 1440))
        assertEquals(123, StudyNumberInput.parse("123", 2000))
        assertEquals(0, StudyNumberInput.parse("", 2000))
        assertEquals("", StudyNumberInput.normalize(""))
        assertEquals(12, StudyNumberInput.parse("0012", 2000))
    }

    @Test fun `invalid values never silently clamp or strip signs`() {
        listOf("-1", "−۱", "+5", "1.5", "12a", " 12", "1,000", "۱٫۵").forEach {
            assertNull(StudyNumberInput.normalize(it))
            assertNull(StudyNumberInput.parse(it, 2000))
        }
        assertNull(StudyNumberInput.parse("2001", 2000))
        assertNull(StudyNumberInput.parse("1441", 1440))
        assertNull(StudyNumberInput.parse("2147483648"))
        assertNull(StudyNumberInput.parse("999999999999999999999999"))
    }

    @Test fun `combined timer breakdown fits each real block and preserves totals`() {
        val activities = listOf(30, 25, 5, 0, 0)
        val split = StudyReportMath.splitActivities(activities, listOf(25, 25, 20))
        assertEquals(listOf(25, 0, 0, 0, 0), split[0])
        assertEquals(listOf(5, 20, 0, 0, 0), split[1])
        assertEquals(listOf(0, 5, 5, 0, 0), split[2])
        assertEquals(activities, activities.indices.map { i -> split.sumOf { it[i] } })
    }

    @Test(expected = IllegalArgumentException::class)
    fun `over budget allocation is rejected not clamped`() {
        StudyReportMath.splitActivities(listOf(30, 30), listOf(25, 25))
    }
}
