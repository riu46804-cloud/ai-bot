package ir.studying.app.core

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class SubscriptionRulesTest {
    private val TEST_PLANS = listOf(
        SubscriptionPlan("monthly", "یک‌ماهه", "studying_sub_monthly", 30, 2_550_000, setOf(SubscriptionFeatures.ROOM_THEMES)),
        SubscriptionPlan("quarterly", "سه‌ماهه", "studying_sub_quarterly", 90, 6_500_000, setOf(SubscriptionFeatures.ROOM_THEMES)),
        SubscriptionPlan("annual", "یک‌ساله", "studying_sub_annual", 365, 15_000_000, setOf(SubscriptionFeatures.ROOM_THEMES)),
    )
    @Test fun `test fixture matches the approved launch rial prices and explicit day counts`() {
        val plans = TEST_PLANS
        assertEquals(listOf(2_550_000L,6_500_000L,15_000_000L),plans.map { it.priceRial })
        assertEquals(listOf(30,90,365),plans.map { it.durationDays })
        assertEquals(3,plans.map { it.sku }.toSet().size)
        assertTrue(plans.all { SubscriptionFeatures.ROOM_THEMES in it.features })
    }
    @Test fun `access uses trusted server time plus monotonic elapsed time`() {
        val lease = SubscriptionLease(1000,5000,mapOf("room_themes" to 1060))
        assertTrue(lease.allows("room_themes",5000))
        assertTrue(lease.allows("room_themes",64999))
        assertFalse(lease.allows("room_themes",65000))
    }
    @Test fun `unknown feature and elapsed time reset fail closed`() {
        val lease = SubscriptionLease(1000,5000,mapOf("room_themes" to 999999))
        assertFalse(lease.allows("unknown",6000))
        assertFalse(lease.allows("room_themes",4999))
        assertFalse(SubscriptionLease(0,0,mapOf("room_themes" to 999999)).allows("room_themes",0))
    }
    @Test fun `entitlements are reusable and independent for future app features`() {
        val lease = SubscriptionLease(1000,0,mapOf("room_themes" to 2000,"future_feature" to 1100))
        assertTrue(lease.allows("room_themes",101000))
        assertFalse(lease.allows("future_feature",101000))
    }
    @Test fun `state parser does not turn active flag alone into access`() {
        val lease = SubscriptionLease.from(JSONObject("""{"active":true,"server_time":1000,"features":{}}"""),0)
        assertFalse(lease.allows("room_themes",0))
        val actual = SubscriptionLease.from(JSONObject("""{"server_time":1000,"features":{"room_themes":1060}}"""),0)
        assertTrue(actual.allows("room_themes",0))
    }
    @Test fun `rial price parser handles Persian Arabic and grouping without double conversion`() {
        assertEquals(2_550_000L,BillingPriceRules.rialValue("۲٬۵۵۰٬۰۰۰ ریال"))
        assertEquals(2_550_000L,BillingPriceRules.rialValue("2,550,000 IRR"))
        assertEquals(2_550_000L,BillingPriceRules.rialValue("٢٥٥٠٠٠٠"))
        assertEquals(2_550_000L,BillingPriceRules.rialValue("۲۵۵٬۰۰۰ تومان"))
    }
    @Test fun `ambiguous or malformed prices cannot launch checkout`() {
        listOf("2.55","۲٫۵۵","-2550000","0","USD2550000","2550000تومان ریال","999999999999999999999999","free").forEach {
            assertNull(it,BillingPriceRules.rialValue(it))
        }
    }
    @Test fun `changed displayed terms require a fresh explicit checkout choice`() {
        val original = TEST_PLANS.first()
        assertTrue(BillingPlanRules.sameTerms(original, original.copy(title = "نام تازه")))
        assertFalse(BillingPlanRules.sameTerms(original, original.copy(priceRial = original.priceRial + 1000)))
        assertFalse(BillingPlanRules.sameTerms(original, original.copy(durationDays = 31)))
        assertFalse(BillingPlanRules.sameTerms(original, original.copy(sku = "other_sku")))
        assertFalse(BillingPlanRules.sameTerms(original, original.copy(features = setOf("other_feature"))))
    }
    @Test fun `terminal rejected receipts are isolated without discarding retryable payments`() {
        assertTrue(BillingRecoveryRules.quarantine(422, "invalid_signature"))
        assertTrue(BillingRecoveryRules.quarantine(409, "purchase_revoked"))
        assertFalse(BillingRecoveryRules.quarantine(503, "subscription_storage_error"))
        assertFalse(BillingRecoveryRules.quarantine(502, "myket_unavailable"))
        assertFalse(BillingRecoveryRules.quarantine(429, "billing_rate_limited"))
        assertFalse(BillingRecoveryRules.quarantine(403, "order_owner_mismatch"))
        assertFalse(BillingRecoveryRules.quarantine(401, "unauthorized"))
    }

    private fun quote(code: String = "off20") = DiscountQuote.from(org.json.JSONObject("""{"code":"$code","offers":[
        {"plan_key":"monthly","sku":"studying_sub_monthly_off20","price_rial":2040000,"list_price_rial":2550000},
        {"plan_key":"annual","sku":"studying_sub_annual_off20","price_rial":15000000,"list_price_rial":15000000},
        {"plan_key":"quarterly","sku":"bad","price_rial":7000000,"list_price_rial":6500000}]}"""))!!
    @Test fun `discount quote keeps only strictly lower server prices`() {
        val q = quote()
        assertEquals(setOf("monthly"), q.offers.keys)
        assertEquals(510_000L, q.offers.getValue("monthly").savingsRial)
    }
    @Test fun `effective plan swaps sku and price but keeps the main price visible`() {
        val e = BillingDiscountRules.effective(TEST_PLANS[0], quote())
        assertEquals("studying_sub_monthly_off20", e.sku); assertEquals(2_040_000L, e.priceRial)
        assertEquals(2_550_000L, e.listPriceRial); assertEquals("off20", e.discountCode); assertTrue(e.discounted)
        val untouched = BillingDiscountRules.effective(TEST_PLANS[1], quote())
        assertEquals(TEST_PLANS[1], untouched); assertFalse(untouched.discounted)
    }
    @Test fun `stale quote never mixes with changed main price`() {
        val changed = TEST_PLANS[0].copy(priceRial = 2_700_000, listPriceRial = 2_700_000)
        assertEquals(changed, BillingDiscountRules.effective(changed, quote()))
    }
    @Test fun `discount terms are compared exactly before checkout`() {
        val shown = BillingDiscountRules.effective(TEST_PLANS[0], quote())
        assertTrue(BillingPlanRules.sameTerms(shown, shown.copy(title = "x")))
        assertFalse(BillingPlanRules.sameTerms(shown, TEST_PLANS[0]))
        assertFalse(BillingPlanRules.sameTerms(shown, shown.copy(priceRial = 1_000_000)))
        assertFalse(BillingPlanRules.sameTerms(shown, shown.copy(discountCode = "other")))
    }
    @Test fun `discount code input normalizes safely`() {
        assertEquals("welcome_20", BillingDiscountRules.normalize("  Welcome_20\n"))
        listOf("ab", "کد", "off 20", "off';--", "-bad", "a".repeat(65)).forEach { assertNull(it, BillingDiscountRules.normalize(it)) }
    }
    @Test fun `malformed quotes without usable offers are rejected`() {
        assertNull(DiscountQuote.from(org.json.JSONObject("""{"code":"x","offers":[]}""")))
        assertNull(DiscountQuote.from(org.json.JSONObject("""{"offers":[{"plan_key":"monthly","sku":"a","price_rial":1,"list_price_rial":2}]}""")))
    }

    @Test fun `catalogue displays default sale against actual base reference without a code`() {
        val sale = SubscriptionPlan.from(JSONObject("""{"key":"monthly","title":"یک‌ماهه","sku":"sale255","duration_days":30,
            "price_rial":2550000,"list_price_rial":3600000,"default_discount_applied":true,"features":["room_themes"]}"""))
        assertEquals(2_550_000L, sale.priceRial); assertEquals(3_600_000L, sale.listPriceRial)
        assertTrue(sale.defaultDiscountApplied); assertTrue(sale.discounted); assertNull(sale.discountCode)
        assertEquals(sale, BillingDiscountRules.effective(sale, null))
    }
    @Test fun `old server without new fields keeps original price and no sale`() {
        val plain = SubscriptionPlan.from(JSONObject("""{"key":"monthly","price_rial":2550000,"features":[]}"""))
        assertEquals(plain.priceRial, plain.listPriceRial)
        assertFalse(plain.defaultDiscountApplied); assertFalse(plain.discounted)
    }
    @Test fun `code price288 replaces sale255 using base360 and never chooses cheaper price`() {
        val sale = TEST_PLANS[0].copy(sku = "sale255", listPriceRial = 3_600_000, defaultDiscountApplied = true)
        val code = DiscountQuote("off20", mapOf("monthly" to DiscountOffer("monthly", "code288", 2_880_000, 3_600_000)))
        val actual = BillingDiscountRules.effective(sale, code)
        assertEquals(2_880_000L, actual.priceRial); assertEquals(3_600_000L, actual.listPriceRial)
        assertEquals("code288", actual.sku); assertEquals("off20", actual.discountCode)
        assertFalse(actual.defaultDiscountApplied); assertTrue(actual.discounted)
        assertTrue(actual.priceRial > sale.priceRial)
        assertEquals(sale, BillingDiscountRules.effective(sale, null))
    }
    @Test fun `code stays based on reference after default offer is turned off`() {
        val full = TEST_PLANS[0].copy(sku = "base360", priceRial = 3_600_000, listPriceRial = 3_600_000)
        assertFalse(full.discounted)
        val q = DiscountQuote("off20", mapOf("monthly" to DiscountOffer("monthly", "code288", 2_880_000, 3_600_000)))
        assertEquals(2_880_000L, BillingDiscountRules.effective(full,q).priceRial)
        assertEquals("code288", BillingDiscountRules.effective(full,q).sku)
    }
    @Test fun `stale base quote rejected even if default sale amount is unchanged`() {
        val sale = TEST_PLANS[0].copy(listPriceRial = 3_600_000, defaultDiscountApplied = true)
        val old = DiscountQuote("off20", mapOf("monthly" to DiscountOffer("monthly", "old204", 2_040_000, 2_550_000)))
        assertEquals(sale, BillingDiscountRules.effective(sale, old))
    }
    @Test fun `default sale flag changes terms and requires fresh consent`() {
        val sale = TEST_PLANS[0].copy(listPriceRial = 3_600_000, defaultDiscountApplied = true)
        assertFalse(BillingPlanRules.sameTerms(sale, sale.copy(defaultDiscountApplied = false)))
    }

    @Test fun `default sale percentage uses base360 and final255 without rounding up`() {
        val sale = TEST_PLANS[0].copy(listPriceRial = 3_600_000, defaultDiscountApplied = true)
        assertEquals(29, sale.discountPercent)
    }
    @Test fun `code percentage uses the same base not previous default sale`() {
        val sale = TEST_PLANS[0].copy(listPriceRial = 3_600_000, defaultDiscountApplied = true)
        val q = DiscountQuote("off20", mapOf("monthly" to DiscountOffer("monthly", "code288", 2_880_000, 3_600_000)))
        val applied = BillingDiscountRules.effective(sale, q)
        assertEquals(20, applied.discountPercent)
        assertEquals(29, BillingDiscountRules.effective(sale, null).discountPercent)
    }
    @Test fun `no discount invalid prices and equal price never advertise percent`() {
        val p = TEST_PLANS[0]
        for (bad in listOf(p, p.copy(priceRial = 0), p.copy(priceRial = -1), p.copy(listPriceRial = 0), p.copy(priceRial = 9_000_000))) {
            assertFalse(bad.discounted); assertEquals(0, bad.discountPercent)
        }
    }
    @Test fun `whole percentage handles tiny reductions and large amounts exactly`() {
        val p = TEST_PLANS[0]
        assertTrue(p.copy(priceRial = 9999, listPriceRial = 10000).discounted)
        assertEquals(0, p.copy(priceRial = 9999, listPriceRial = 10000).discountPercent)
        assertEquals(99, p.copy(priceRial = 1, listPriceRial = Long.MAX_VALUE).discountPercent)
        assertEquals(50, p.copy(priceRial = 5_000_000_000, listPriceRial = 10_000_000_000).discountPercent)
    }

}
