package ir.studying.app.ui.anatomy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.URI

class AnatomyChromeTabsTest {
    @Test fun onlyChromeIsTargeted() {
        assertEquals("com.android.chrome", AnatomyChromeTabs.CHROME_PACKAGE)
    }
    @Test fun atlasUrlIsTheExactRequestedHttpsUrl() {
        val u = URI(AnatomyChromeTabs.ATLAS_URL)
        assertEquals("https", u.scheme)
        assertEquals("studying.ir", u.host)
        assertEquals("/anatomi/atlas-3d-badan-ensan.html", u.path)
    }
    @Test fun customTabRequiresChromeActivityAndService() {
        assertTrue(AnatomyChromeTabs.canOpen(hasActivity = true, hasService = true))
        assertFalse(AnatomyChromeTabs.canOpen(hasActivity = false, hasService = true))
        assertFalse(AnatomyChromeTabs.canOpen(hasActivity = true, hasService = false))
        assertFalse(AnatomyChromeTabs.canOpen(hasActivity = false, hasService = false))
    }
}
