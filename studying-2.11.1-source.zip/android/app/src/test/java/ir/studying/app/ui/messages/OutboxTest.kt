package ir.studying.app.ui.messages

import ir.studying.app.data.Reaction
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import org.junit.Assert.*
import org.junit.Test

class OutboxTest {
    private var now = 1_000_000L
    private fun box() = Outbox { now }
    @Test fun noIdAckKeepsTickUntilPostAckPoll() {
        val b=box();val o=b.add("x",null,null,null,0);b.markSent(o.localId,null)
        assertEquals(SendState.SENT,b.items.value.single().state)
        b.reconcile(emptyList(),"me");assertEquals(1,b.items.value.size)
        b.reconcile(emptyList(),"me",retireNoId=true);assertTrue(b.items.value.isEmpty())
    }
    @Test fun idAckWaitsForExactRowWithoutExpiring() {
        val b=box();val o=b.add("x",null,null,null,0);b.markSent(o.localId,42)
        now+=100000;b.reconcile(emptyList(),"me",retireNoId=true);assertEquals(1,b.items.value.size)
        b.reconcile(listOf(ServerMsg(42,"me","changed")),"me",retireNoId=true);assertTrue(b.items.value.isEmpty())
    }
    @Test fun identicalTextFromAnotherDeviceCannotClaimPending() {
        val b=box();b.add("ok",null,null,null,0);b.reconcile(listOf(ServerMsg(7,"me","ok")),"me")
        assertEquals(1,b.items.value.size);assertEquals("m7",b.keyFor(7))
    }
    @Test fun failureDoesNotGetClaimedByAnyPolledText() {
        val b=box();val o=b.add("x",null,null,null,0);b.markFailed(o.localId)
        b.reconcile(listOf(ServerMsg(7,"me","x")),"me",retireNoId=true)
        assertEquals(SendState.FAILED,b.items.value.single().state)
    }
    @Test fun retryCannotQueueSameActiveOperationTwice() {
        val b=box();val o=b.add("x",null,null,null,0);assertNull(b.retry(o.localId,0));b.markFailed(o.localId)
        assertNotNull(b.retry(o.localId,0));assertNull(b.retry(o.localId,0));b.remove(o.localId);assertNull(b.retry(o.localId,0))
    }
    @Test fun clearDoesNotReuseIdsOrResurrectRemovedMessage() {
        val b=box();val o=b.add("x",null,null,null,0);b.clear();b.markSent(o.localId,7)
        assertTrue(b.items.value.isEmpty());assertNotEquals(o.localId,b.add("next",null,null,null,0).localId)
    }
    @Test fun concurrentAddAndReconcileDoNotLoseOperations() {
        val b=box();val ts=(0 until 4).map { n -> Thread { repeat(100){b.add("$n:$it",null,null,null,0);b.reconcile(emptyList(),"me")} }.also{it.start()} }
        ts.forEach{it.join()};assertEquals(400,b.items.value.size);assertEquals(400,b.items.value.map{it.localId}.toSet().size)
    }
    @Test fun normalizeAndTimeStillWork() {
        assertEquals("a b",Outbox.normalize("  a \n\t b "));assertEquals("1970-01-01 03:30:00",Outbox.nowTehran(0L))
    }
}

class ChatSyncTest {
    private fun ui(id:Int,text:String="hi")=UiMsg("m$id",id,"me",true,"text",text,"2026-11-06 12:00:00")
    private fun rows(sync:ChatSync)=timelineChat(sync.timeline.value,"me")
    private fun outgoing(sync:ChatSync)=rows(sync).filter{it.mine}
    @Test fun bubbleImmediatelyThenTickThenExactServerRow() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val gate=CompletableDeferred<Int?>()
        sync.queue("hi",null,null,null,0,send={gate.await()},onErr={},after={})
        assertEquals(1,outgoing(sync).size);assertEquals(Tick.SENDING,outgoing(sync).single().tick)
        gate.complete(42);assertEquals(Tick.SENT,outgoing(sync).single().tick)
        assertTrue(sync.publishPoll(sync.beginPoll(),listOf(ui(42))))
        assertEquals(1,outgoing(sync).size);assertEquals(42,outgoing(sync).single().id);scope.cancel()
    }
    @Test fun pollBeforeAckCannotPublishServerEcho() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val gate=CompletableDeferred<Int?>()
        sync.queue("hi",null,null,null,0,send={gate.await()},onErr={},after={})
        val early=sync.beginPoll();assertFalse(sync.publishPoll(early,listOf(ui(42))))
        assertEquals(1,outgoing(sync).size);gate.complete(42)
        assertFalse(sync.publishPoll(early,listOf(ui(42))))
        assertEquals(1,outgoing(sync).size);assertTrue(sync.publishPoll(sync.beginPoll(),listOf(ui(42))))
        assertEquals(1,outgoing(sync).size);scope.cancel()
    }
    @Test fun noIdAckAndPostAckPollSwapAtomicallyWithoutGuessing() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val gate=CompletableDeferred<Int?>()
        sync.queue("hi",null,null,null,0,send={gate.await()},onErr={},after={})
        val old=sync.beginPoll();gate.complete(null);assertEquals(Tick.SENT,outgoing(sync).single().tick)
        assertFalse(sync.publishPoll(old,listOf(ui(42))))
        assertTrue(sync.publishPoll(sync.beginPoll(),listOf(ui(42))))
        assertEquals(listOf(42),outgoing(sync).map{it.id});scope.cancel()
    }
    @Test fun noIdDelayedEchoMayTemporarilyDisappearButNotDouble() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"}
        sync.queue("hi",null,null,null,0,send={null},onErr={},after={})
        assertEquals(1,outgoing(sync).size);sync.publishPoll(sync.beginPoll(),emptyList());assertEquals(0,outgoing(sync).size)
        sync.publishPoll(sync.beginPoll(),listOf(ui(42)));assertEquals(1,outgoing(sync).size);scope.cancel()
    }
    @Test fun queuedSecondSendBlocksPollUntilBothAck() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val a=CompletableDeferred<Int?>();val b=CompletableDeferred<Int?>()
        sync.queue("one",null,null,null,0,send={a.await()},onErr={},after={});sync.queue("two",null,null,null,0,send={b.await()},onErr={},after={})
        assertEquals(2,outgoing(sync).size);a.complete(null);val poll=sync.beginPoll()
        assertFalse(sync.publishPoll(poll,listOf(ui(1,"one"))))
        b.complete(null);assertFalse(sync.publishPoll(poll,listOf(ui(1,"one"),ui(2,"two"))))
        assertTrue(sync.publishPoll(sync.beginPoll(),listOf(ui(1,"one"),ui(2,"two"))))
        assertEquals(listOf(1,2),outgoing(sync).map{it.id});scope.cancel()
    }
    @Test fun pollStartedBeforeQueueNeverPublishesLater() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val old=sync.beginPoll()
        sync.queue("hi",null,null,null,0,send={null},onErr={},after={})
        assertFalse(sync.publishPoll(old,listOf(ui(1))));assertEquals(1,outgoing(sync).size);scope.cancel()
    }
    @Test fun olderPollCannotOverwriteNewerSnapshot() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val a=sync.beginPoll();val b=sync.beginPoll()
        assertTrue(sync.publishPoll(b,listOf(ui(2))));assertFalse(sync.publishPoll(a,listOf(ui(1))));assertEquals(2,rows(sync).single().id);scope.cancel()
    }
    @Test fun failureRemainsWarningNotSecondBubbleAndNoAutomaticRetry() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};var sends=0
        sync.queue("hi",null,null,null,0,send={sends++;error("lost")},onErr={},after={})
        assertEquals(0,rows(sync).size);assertEquals(SendState.FAILED,sync.timeline.value.pending.single().state)
        sync.publishPoll(sync.beginPoll(),listOf(ui(42)));assertEquals(1,rows(sync).size);assertEquals(1,sends);scope.cancel()
    }
    @Test fun differentServerIdsWithIdenticalTextArePreserved() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"}
        sync.queue("hi",null,null,null,0,send={null},onErr={},after={})
        sync.publishPoll(sync.beginPoll(),listOf(ui(1),ui(2)));assertEquals(listOf(1,2),rows(sync).map{it.id});scope.cancel()
    }
    @Test fun lateCompletionAfterClearCannotModifyNewTimeline() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"};val gate=CompletableDeferred<Int?>();var after=0
        sync.queue("old",null,null,null,0,send={gate.await()},onErr={},after={after++});val old=sync.beginPoll();sync.clear();gate.complete(99)
        assertFalse(sync.publishPoll(old,listOf(ui(99))));assertTrue(rows(sync).isEmpty());assertEquals(0,after);scope.cancel()
    }
    @Test fun accountSwitchSuppressesOldSendCompletion() {
        val scope=CoroutineScope(Dispatchers.Unconfined);var me="first";val sync=ChatSync(scope){me};val gate=CompletableDeferred<Int?>();var after=0
        sync.queue("old",null,null,null,0,send={gate.await()},onErr={},after={after++});me="second";gate.complete(99);assertEquals(0,after);scope.cancel()
    }
    @Test fun sessionTokenChangeRejectsLatePollEvenWithSameUsername() {
        val scope=CoroutineScope(Dispatchers.Unconfined);var session="tokenA"
        val sync=ChatSync(scope,{session}){"me"};val old=sync.beginPoll();session="tokenB"
        assertFalse(sync.publishPoll(old,listOf(ui(1))));sync.ensureSession()
        assertTrue(sync.timeline.value.server.isEmpty());assertTrue(sync.publishPoll(sync.beginPoll(),listOf(ui(2))))
        assertEquals(2,rows(sync).single().id);scope.cancel()
    }
    @Test fun sessionTokenChangePreventsQueuedSendStartingWithNewSession() {
        val scope=CoroutineScope(Dispatchers.Unconfined);var session="tokenA";val sync=ChatSync(scope,{session}){"me"}
        val gate=CompletableDeferred<Int?>();var second=0
        sync.queue("first",null,null,null,0,send={gate.await()},onErr={},after={})
        sync.queue("second",null,null,null,0,send={second++;2},onErr={},after={})
        session="tokenB";gate.complete(1);sync.ensureSession()
        assertEquals(0,second);assertTrue(sync.timeline.value.pending.isEmpty());scope.cancel()
    }
    @Test fun deletingMessageUpdatesTimelineAndRejectsStalePollEvenDuringSend() {
        val scope=CoroutineScope(Dispatchers.Unconfined);val sync=ChatSync(scope){"me"}
        sync.publishPoll(sync.beginPoll(),listOf(ui(1)));val old=sync.beginPoll();val gate=CompletableDeferred<Int?>()
        sync.queue("hi",null,null,null,0,send={gate.await()},onErr={},after={});sync.removeServer(1)
        assertEquals(1,rows(sync).size);assertTrue(rows(sync).single().pending)
        assertFalse(sync.publishPoll(old,listOf(ui(1))));gate.complete(null);scope.cancel()
    }
    @Test fun invalidResponseIdIsNotInvented() { assertNull(ChatSync.idOf("{\"ok\":true}"));assertEquals(42,ChatSync.idOf("{\"id\":42}")) }
}

class ChatListTest {
    private fun msg(key: String, id: Int, at: String = "2024-03-10 10:00:00", sender: String = "a") =
        UiMsg(key = key, id = id, sender = sender, mine = sender == "me", type = "text", text = "t", createdAt = at)

    @Test fun restoredDraftKeepsOriginalReply() {
        val row=msg("m5",5);val item=OutMsg(1,"reply",5,"a","t","now",SendState.FAILED)
        val restored=restoreDeliveryDraft(item,"",null,listOf(row))!!
        assertEquals("reply",restored.text);assertEquals(5,restored.reply!!.id)
    }
    @Test fun restoredTextNeverInheritsUnrelatedReply() {
        val item=OutMsg(1,"text",null,null,null,"now",SendState.FAILED)
        assertNull(restoreDeliveryDraft(item,"",msg("m6",6),listOf(msg("m6",6))))
    }
    @Test fun unavailableOriginalReplyKeepsFailedDraftIntact() {
        val item=OutMsg(1,"reply",5,"a","t","now",SendState.FAILED)
        assertNull(restoreDeliveryDraft(item,"",null,emptyList()))
    }
    @Test fun plainTextRestorationHasNoReply() {
        val item=OutMsg(1,"text",null,null,null,"now",SendState.FAILED)
        assertNull(restoreDeliveryDraft(item,"",null,emptyList())!!.reply)
    }
    @Test fun restorationNeverOverwritesTextBeingTyped() {
        val item=OutMsg(1,"text",null,null,null,"now",SendState.FAILED)
        assertNull(restoreDeliveryDraft(item,"already typing",null,emptyList()))
    }

    @Test fun exactServerIdsAreTheOnlyBubbleIdentity() {
        val rows=listOf(msg("l1",11),msg("l1",12),msg("m11",11))
        assertEquals(listOf("m11","m12"),serverChat(rows).map { it.key })
    }
    @Test fun equalTextWithDistinctServerIdsIsNeverHidden() {
        assertEquals(2,serverChat(listOf(msg("m1",1),msg("m2",2))).size)
    }
    @Test fun deliveryRowsNeverAppearAsChatMessages() {
        assertTrue(serverChat(listOf(msg("l1",-1))).isEmpty())
    }
    @Test fun delayedPendingCollectorCannotDuplicateServerRow() {
        val b=Outbox();val o=b.add("t",null,null,null,0)
        val snapshots=listOf(b.items.value,emptyList(),listOf(o.copy(state=SendState.SENT,serverId=10)))
        for (ignoredPending in snapshots) {
            assertEquals(1,serverChat(listOf(msg("m10",10))).size)
        }
    }
class ReactionsTest {

    @Test
    fun addsANewReaction() {
        assertEquals(listOf(Reaction("🔥", 1, true)), Reactions.toggle(emptyList(), "🔥"))
    }

    @Test
    fun theSameEmojiAgainRemovesIt() {
        assertTrue(Reactions.toggle(listOf(Reaction("🔥", 1, true)), "🔥").isEmpty())
        assertEquals(listOf(Reaction("🔥", 2, false)), Reactions.toggle(listOf(Reaction("🔥", 3, true)), "🔥"))
    }

    @Test
    fun switchingMovesTheOneReactionPerUser() {
        assertEquals(
            listOf(Reaction("🔥", 1, false), Reaction("😂", 2, true)),
            Reactions.toggle(listOf(Reaction("🔥", 2, true), Reaction("😂", 1, false)), "😂"),
        )
    }

    @Test
    fun overlayLivesUntilAPollStartedAfterTheServerConfirmed() {
        val o = ReactionOverlay()
        val server = listOf(Reaction("👍", 1, false))
        o.toggle(7, server, "🔥")
        assertEquals(listOf(Reaction("👍", 1, false), Reaction("🔥", 1, true)), o.view(7, server))
        val early = o.beginPoll()
        o.settle(7)
        o.onServer(early) // this poll may predate the toggle on the server
        assertEquals(2, o.view(7, server).size)
        o.onServer(o.beginPoll())
        assertEquals(server, o.view(7, server))
    }

    @Test
    fun quickSecondToggleStacksOnTheOverlay() {
        val o = ReactionOverlay()
        o.toggle(3, emptyList(), "😂")
        assertEquals(listOf(Reaction("🔥", 1, true)), o.toggle(3, emptyList(), "🔥"))
    }

    @Test
    fun dropForgetsARefusedToggle() {
        val o = ReactionOverlay()
        o.toggle(3, emptyList(), "😂")
        o.drop(3)
        assertTrue(o.view(3, emptyList()).isEmpty())
        assertTrue(o.map.value.isEmpty())
    }
}

    @Test
    fun groupingJoinsCloseMessagesFromTheSameSender() {
        val list = listOf(
            msg("1", 1, "2024-03-10 10:00:00", "a"),
            msg("2", 2, "2024-03-10 10:04:00", "a"),
            msg("3", 3, "2024-03-10 10:20:00", "a"),
            msg("4", 4, "2024-03-10 10:21:00", "b"),
            msg("5", 5, "2024-03-11 10:21:30", "b"),
        )
        assertEquals(Grouping(top = false, bottom = true, newDay = true), groupingOf(list, 0))
        assertEquals(Grouping(top = true, bottom = false, newDay = false), groupingOf(list, 1))
        assertEquals(Grouping(top = false, bottom = false, newDay = false), groupingOf(list, 2))
        assertEquals(Grouping(top = false, bottom = false, newDay = false), groupingOf(list, 3))
        assertEquals(Grouping(top = false, bottom = false, newDay = true), groupingOf(list, 4))
    }
}
