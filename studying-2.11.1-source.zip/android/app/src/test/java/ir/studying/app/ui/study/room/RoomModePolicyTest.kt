package ir.studying.app.ui.study.room

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RoomModePolicyTest {
    @Test fun missingPreferenceUsesClassic() { assertFalse(RoomModePolicy.use3D()) }
    @Test fun explicitClassicIsPreserved() { assertFalse(RoomModePolicy.use3D(false)) }
    @Test fun explicitThreeDIsPreserved() { assertTrue(RoomModePolicy.use3D(true)) }
    @Test fun unsupportedOverridesThreeD() { assertFalse(RoomModePolicy.use3D(true, true)) }
    @Test fun explicitRetryAllowsThreeDAgain() { assertTrue(RoomModePolicy.use3D(true, false)) }
}
