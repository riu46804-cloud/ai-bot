#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Builds the 3D emoji pack for Studying.

Source : https://github.com/microsoft/fluentui-emoji  (MIT, Microsoft)
Why    : a large, consistent 3D emoji set whose licence allows shipping it
         inside a commercial app, so reactions, big-emoji messages and the
         app's own UI no longer depend on each phone maker's emoji font.

What it does
  1. scans app/src/main for every emoji the app really uses,
  2. adds a curated set (all smileys, common hands, study/celebration
     objects and the Telegram-style reaction set),
  3. downloads the Fluent Emoji repository once (or reads --from DIR),
  4. writes small lossy WebP renders into res/drawable-nodpi named
     ic3d_<codepoints>.webp, which core/Icon3D.kt finds at runtime.

Run it from the android/ project root with a network connection:

    python3 tools/fetch_3d_icons.py            # download + build
    python3 tools/fetch_3d_icons.py --from /path/to/fluentui-emoji-main

Needs Pillow (pip install pillow). Anything missing simply falls back to
the plain emoji glyph at runtime, so a partial pack is harmless.
"""

import argparse
import io
import json
import os
import re
import shutil
import sys
import tarfile
import tempfile
import urllib.request

TARBALL = "https://codeload.github.com/microsoft/fluentui-emoji/tar.gz/refs/heads/main"
SRC_DIRS = [os.path.join("app", "src", "main", "java"), os.path.join("app", "src", "main", "res", "values")]
OUT_DIR = os.path.join("app", "src", "main", "res", "drawable-nodpi")
SIZE = 160          # px — sharp up to ~52dp on xxhdpi
LARGE_SIZE = 256    # px — for the few hero renders shown big
QUALITY = 80

# Shown large somewhere in the app (hero cards, celebrations).
LARGE = "🔥🏆🎉🧠📚👥🎯⚡🌱🌙☀️🗂️✨"

# Telegram-style reactions (quick row first, then the expanded grid).
REACTIONS = ("❤️ 👍 👎 😂 🔥 🍓 🍌 🖕 😢 🤯 💯 🙏 "
             "🥰 👏 😁 🤔 😱 🤬 🎉 🤩 🤮 💩 👌 🕊️ 🤡 🥱 🥴 😍 🐳 ❤️‍🔥 🌚 🌭 🤣 ⚡ 🏆 💔 🤨 😐 "
             "🍾 💋 😈 😴 😭 🤓 👻 🧑‍💻 👀 🎃 🙈 😇 😨 🤝 ✍️ 🤗 🫡 🎅 🎄 ☃️ 💅 🤪 🗿 🆒 💘 🙉 🦄 😘 💊 🙊 😎 👾 🤷 😡")

# Everyday picks for the in-chat emoji panel beyond the smileys group.
CURATED = (
    # hands & people
    "👍 👎 👏 🙌 🙏 👌 🤌 ✌️ 🤞 🫰 🤟 🤘 🤙 👋 🤝 💪 ✍️ 👀 🫶 👊 ✊ 🤛 🤜 ✋ 🖐️ 👆 👇 👈 👉 ☝️ 🫵 🤲 "
    "🧠 🫀 🤷 🙋 🙆 🙅 🤦 🙇 💁 🧑‍🎓 🧑‍🏫 🧑‍💻 🧑‍🔬 🏃 🧘 💃 🕺 🫂 "
    # celebration & symbols
    "🎉 🎊 🎁 🎈 🎂 ✨ ⭐ 🌟 💫 ⚡ 🔥 💯 ✅ ☑️ ✔️ ❌ ❎ ❗ ❓ ‼️ ⁉️ 💤 💥 💢 💦 💨 🕳️ 💬 💭 🗯️ 🔔 🔕 📣 📢 "
    "🎯 🏆 🥇 🥈 🥉 🏅 🎖️ 👑 💎 💰 🪙 🔑 🗝️ 🔒 🔓 🛡️ ⚔️ 🧭 ⏰ ⏳ ⌛ ⏱️ ⏲️ 🕰️ 📅 📆 🗓️ "
    # study
    "📚 📖 📕 📗 📘 📙 📓 📔 📒 📝 ✏️ 🖊️ 🖋️ 🖍️ 📌 📍 📎 🖇️ 📐 📏 🧮 🗂️ 📁 📂 🗃️ 🗒️ 📋 📊 📈 📉 "
    "💡 🔦 🔬 🔭 🧪 🧫 🧬 ⚗️ 🩺 💊 🧲 🌡️ 🖥️ 💻 ⌨️ 🖱️ 📱 ☎️ 🎧 🎤 🎵 🎶 🎹 🎸 🎻 🥁 🎬 📷 📸 🎨 🧩 ♟️ 🎲 🎮 "
    "🔤 🔡 🔠 🔢 #️⃣ ➕ ➖ ✖️ ➗ 🟰 ♾️ "
    # nature & weather
    "🌍 🌎 🌏 🌈 ☀️ 🌤️ ⛅ 🌥️ 🌦️ 🌧️ ⛈️ 🌩️ ❄️ ☃️ ⛄ 🌊 🌙 🌛 🌜 🌚 🌝 🌞 🪐 ⭐ 🌠 🌌 🌅 🌄 🌇 🌆 🌃 🏙️ "
    "🌱 🌿 ☘️ 🍀 🌵 🌴 🌳 🌲 🍁 🍂 🍃 🌸 🌺 🌻 🌹 🥀 🌷 💐 🌼 🍄 "
    "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦉 🦄 🐝 🦋 🐞 🐢 🐍 🐙 🐬 🐳 🐋 🦈 🕊️ 🦅 🦖 "
    # food
    "☕ 🍵 🧋 🥤 🧃 🥛 🍕 🍔 🍟 🌭 🥪 🌮 🍿 🍩 🍪 🍫 🍬 🍭 🧁 🍰 🎂 🍦 🍨 🍓 🍒 🍎 🍏 🍊 🍋 🍌 🍉 🍇 🍑 🥭 🍍 🥥 🥑 🍉 🍞 🧀 🍳 🥗 🍚 🍜 🍝 🍲 "
    # travel & places & activities
    "🚀 ✈️ 🚗 🚕 🚌 🚲 🛴 🚂 ⛵ 🏠 🏡 🏫 🏛️ 🕌 🏔️ 🏕️ 🏖️ 🗿 🎡 🎢 ⚽ 🏀 🏐 🎾 🏓 🏸 ⛳ 🥊 🏋️ 🚴 🏊 ⛷️ "
    # misc
    "🤖 👾 👻 💀 ☠️ 👽 🤡 💩 🎃 🎄 🎅 🧊 🪄 🔮 🧿 🪬 🗡️ 💣 🧨 🪅 🪩 🛎️ 🧸 🪁 📦 ✉️ 📩 📨 💌 🏷️ 🔗 ⚙️ 🛠️ 🔧 🔨 🧯 🚨 🚦 🆒 🆕 🆗 🆘 ⛔ 🚫 ⚠️ 🔞 "
    "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❤️‍🔥 ❤️‍🩹 💕 💞 💓 💗 💖 💘 💝 💟 ❣️"
)

EMOJI_RE = re.compile(
    "(?:[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\u2300-\u23FF\u2190-\u21FF\u2934\u2935"
    "\u3030\u303D\u3297\u3299\u203C\u2049\u2122\u2139\u24C2\u25AA-\u25FE#*0-9]\uFE0F?\u20E3?"
    "(?:\u200D[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\u2300-\u23FF]\uFE0F?)*)"
)


def key_of(emoji):
    return "_".join("%x" % ord(ch) for ch in emoji if ord(ch) not in (0xFE0F, 0x200D))


def emojis_in(text):
    out = []
    for m in EMOJI_RE.finditer(text):
        e = m.group(0)
        if e and not e.isdigit() and e not in "#*":
            out.append(e)
    return out


def scan_sources():
    found = set()
    esc = re.compile(r"\\u([0-9a-fA-F]{4})")
    for root_dir in SRC_DIRS:
        for root, _, files in os.walk(root_dir):
            for f in files:
                if not f.endswith((".kt", ".xml")):
                    continue
                with open(os.path.join(root, f), encoding="utf-8") as fh:
                    text = fh.read()
                # Kotlin "\uD83D\uDCDA" escapes -> real characters
                text = esc.sub(lambda m: chr(int(m.group(1), 16)), text)
                text = text.encode("utf-16", "surrogatepass").decode("utf-16")
                found.update(emojis_in(text))
    return found


def build_index(assets):
    idx = {}
    for d in sorted(os.listdir(assets)):
        meta = os.path.join(assets, d, "metadata.json")
        if not os.path.exists(meta):
            continue
        with open(meta, encoding="utf-8") as fh:
            m = json.load(fh)
        pngs = []
        for sub in (os.path.join(assets, d, "3D"), os.path.join(assets, d, "Default", "3D")):
            if os.path.isdir(sub):
                pngs = [os.path.join(sub, p) for p in os.listdir(sub) if p.endswith(".png")]
                if pngs:
                    break
        if not pngs:
            continue
        uni = [p for p in m.get("unicode", "").replace("-", " ").split() if p not in ("fe0f", "200d")]
        idx["_".join(uni)] = {"png": pngs[0], "group": m.get("group", "")}
    return idx


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="src", help="already extracted fluentui-emoji-main directory")
    args = ap.parse_args()
    try:
        from PIL import Image
    except ImportError:
        sys.exit("Pillow is required: pip install pillow")

    tmp = None
    root = args.src
    if not root:
        tmp = tempfile.mkdtemp()
        print("downloading Fluent Emoji …")
        data = urllib.request.urlopen(TARBALL).read()
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
            members = [m for m in tar.getmembers() if m.name.endswith("metadata.json") or "/3D/" in m.name]
            tar.extractall(tmp, members=members)
        root = os.path.join(tmp, os.listdir(tmp)[0])
    idx = build_index(os.path.join(root, "assets"))

    wanted = set(scan_sources())
    wanted.update(emojis_in(REACTIONS))
    wanted.update(emojis_in(CURATED))
    keys = {key_of(e) for e in wanted}
    keys.update(k for k, v in idx.items() if v["group"] == "Smileys & Emotion")
    large = {key_of(e) for e in emojis_in(LARGE)}

    os.makedirs(OUT_DIR, exist_ok=True)
    for f in os.listdir(OUT_DIR):
        if f.startswith("ic3d_"):
            os.remove(os.path.join(OUT_DIR, f))
    written, missing, total = 0, [], 0
    for k in sorted(keys):
        v = idx.get(k)
        if not v:
            missing.append(k)
            continue
        size = LARGE_SIZE if k in large else SIZE
        im = Image.open(v["png"]).convert("RGBA").resize((size, size), Image.LANCZOS)
        out = os.path.join(OUT_DIR, "ic3d_%s.webp" % k)
        im.save(out, "WEBP", quality=QUALITY, method=4)
        total += os.path.getsize(out)
        written += 1
    print("wrote %d renders (%.0f KB) to %s" % (written, total / 1024, OUT_DIR))
    if missing:
        print("not in Fluent (falls back to the glyph):", " ".join(missing))
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
