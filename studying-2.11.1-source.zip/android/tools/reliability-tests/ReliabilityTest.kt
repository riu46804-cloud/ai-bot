package ir.studying.app.core

import androidx.datastore.preferences.core.stringPreferencesKey
import ir.studying.app.App
import ir.studying.app.player.Chrono
import ir.studying.app.player.Pomodoro
import ir.studying.app.data.StudyHistory
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.json.JSONObject

@OptIn(ExperimentalCoroutinesApi::class)
class ReliabilityTest {
    @Before fun reset() = runBlocking {
        Dispatchers.setMain(StandardTestDispatcher())
        Store.init(App.instance)
        Store.durableStudyEdit { it.clear() }
        Store.saveSession("token-alice", "alice")
        Pomodoro.reset()
        Offline.clear()
        StudyHistory.invalidate()
        Api.handler = { _, _, _ -> "{\"ok\":true}" }
    }
    private suspend fun rows() = Offline.decode(Store.getString("offline_study_queue"))

    @Test fun concurrentAddsAndUidOnlyDedupe() = runBlocking {
        coroutineScope { (1..80).map { i -> async(Dispatchers.IO) { Offline.add(25, 1, "uid-$i", 1000L) } }.awaitAll() }
        assertEquals(80, rows().size) // Same minutes/course/time are independent intentional records.
        assertFalse(Offline.add(25, 1, "uid-1", 1000L))
        assertEquals(80, rows().size)
    }

    @Test fun noSilentEvictionAboveOldCap() = runBlocking {
        repeat(205) { Offline.add(1, 1, "row-$it") }
        assertEquals(205, rows().size)
        assertEquals("row-0", rows().first().uid)
    }

    @Test fun ackDoesNotOverwriteConcurrentEnqueueOrResurrectDelete() = runBlocking {
        Offline.add(25, 1, "first")
        Offline.add(30, 1, "deleted")
        val entered = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>()
        Api.handler = { _, _, _ -> entered.complete(Unit); release.await(); "{\"ok\":true}" }
        val flush = async { Offline.flush() }
        entered.await()
        Offline.add(45, 1, "new")
        Offline.remove("deleted")
        release.complete(Unit)
        assertEquals(1, flush.await())
        assertEquals(listOf("new"), rows().map { it.uid })
    }

    @Test fun cancellationAndAmbiguousSuccessKeepOriginalUid() = runBlocking {
        Offline.add(25, 1, "retry")
        val entered = CompletableDeferred<Unit>()
        Api.handler = { _, _, _ -> entered.complete(Unit); awaitCancellation() }
        val job = launch { Offline.flush() }
        entered.await(); job.cancelAndJoin()
        assertEquals("retry", rows().single().uid)
        Api.handler = { _, _, _ -> "<html>proxy login</html>" }
        assertEquals(0, Offline.flush())
        assertEquals("retry", rows().single().uid)
        Api.handler = { _, body, _ -> assertEquals("retry", body!!.getString("client_uid")); "{\"ok\":true}" }
        assertEquals(1, Offline.flush())
        assertTrue(rows().isEmpty())
    }

    @Test fun retryStopsOnRateLimitAndRetainsValidationFailure() = runBlocking {
        Offline.add(25, 1, "one"); Offline.add(30, 1, "two")
        var calls = 0
        Api.handler = { _, _, _ -> calls++; throw ApiException("rate limit", 429) }
        assertEquals(0, Offline.flush()); assertEquals(1, calls)
        assertEquals(2, rows().size); assertTrue(Offline.hasRetryable())
        Api.handler = { _, _, _ -> throw ApiException("invalid", 422) }
        assertEquals(0, Offline.flush()); assertEquals(2, rows().size)
        assertTrue(rows().all { it.rejected }); assertFalse(Offline.hasRetryable())
        assertFalse(Offline.isPermanent(ApiException("legacy error", 200)))
        Api.handler = { _, _, _ -> "{\"ok\":true}" }
        assertEquals(2, Offline.flush(retryRejected = true))
    }

    @Test fun queueOwnershipAndLate401AreIsolated() = runBlocking {
        Offline.add(25, 1, "alice-part")
        Store.saveSession("token-bob", "bob")
        assertEquals(0, Offline.refresh())
        assertEquals(0, Offline.flush())
        Offline.add(25, 1, "alice-part") // Same UID is only a duplicate within an owner.
        Store.clearSession(expectedToken = "token-alice")
        assertEquals("bob", Store.username)
        assertEquals("token-bob", Store.token)
        Api.handler = { _, _, session -> assertEquals("bob", session.username); "{\"ok\":true}" }
        assertEquals(1, Offline.flush())
        assertEquals("alice", rows().single().user)
    }

    @Test fun accountSwitchDuringReplayCannotCreditTheNewUser() = runBlocking {
        Offline.add(25, 1, "alice-inflight")
        val entered = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>()
        Api.handler = { _, _, session ->
            assertEquals("alice", session.username)
            entered.complete(Unit); release.await(); "{\"ok\":true}"
        }
        val flush = async { Offline.flush() }
        entered.await()
        Store.saveSession("token-bob", "bob")
        Offline.add(30, 2, "bob-new")
        release.complete(Unit)
        assertEquals(1, flush.await())
        assertEquals("bob", rows().single().user)
        assertEquals("bob-new", rows().single().uid)
    }

    @Test fun chronoConsumptionAndOutboxAreOneCommittedTransition() = runBlocking {
        val ended = System.currentTimeMillis() - 60_000
        Store.saveTimer(TimerPersist(false, 0, 25 * 60_000L, 7, ended))
        assertTrue(Offline.record(25, 7, Offline.Source.CHRONO, "clock"))
        assertEquals(0L, Store.timer.value.accumMs)
        assertEquals(ended, rows().single().at)
        assertEquals(25, rows().single().minutes)
        // A stale repeat tap cannot consume the same timer again.
        assertTrue(runCatching { Offline.record(25, 7, Offline.Source.CHRONO, "clock-2") }.isFailure)
        assertEquals(1, rows().size)
    }

    @Test fun roomRegistrationPreservesBothTimersEvenWhenNetworkWouldFail() = runBlocking {
        Store.saveTimer(TimerPersist(false, 0, 10 * 60_000L, 1))
        Store.savePomodoro(PomodoroPersist(phase = "WORK", remainingSec = 20 * 60),
            listOf(StudyPending.Block(50, 1000)))
        Pomodoro.restore(App.instance)
        Api.handler = { _, _, _ -> throw ApiException("offline", 503) }
        var called = false
        ir.studying.app.ui.study.room.StudyRoomViewModel().logMinutes(65, 1) { error ->
            assertNull(error); called = true
        }
        assertTrue(called)
        assertEquals(65, rows().sumOf { it.minutes })
        assertEquals(0L, Store.timer.value.accumMs)
        assertEquals(0, StudyPending.minutes.value)
        assertEquals("IDLE", Store.pomodoro.value.phase)
    }

    @Test fun chronoStartIsIdempotentAndLongElapsedClampsNotZero() {
        val start = System.currentTimeMillis() - Chrono.CAP_MS - 60_000
        Store.saveTimer(TimerPersist(true, start, 0, 1))
        Chrono.start()
        assertEquals(start, Store.timer.value.startEpochMs)
        assertEquals(Chrono.CAP_MS, Chrono.elapsedMs())
        Chrono.pause()
        assertEquals(Chrono.CAP_MS, Store.timer.value.accumMs)
        Store.init(App.instance) // Worker re-init must not reset live state.
        assertEquals(Chrono.CAP_MS, Store.timer.value.accumMs)
    }

    @Test fun pomodoroRestoreBanksWithTransitionAndDoesNotDoubleCredit() = runBlocking {
        val now = System.currentTimeMillis()
        Store.savePomodoro(PomodoroPersist(phase = "WORK", running = true,
            endEpochMs = now - 60_000, remainingSec = 1, workMin = 25),
            listOf(StudyPending.Block(50, now - 90 * 60_000)))
        Pomodoro.restore(App.instance)
        assertEquals(75, StudyPending.minutes.value)
        assertEquals("BREAK", Store.pomodoro.value.phase)
        Pomodoro.restore(App.instance)
        StudyPending.load()
        assertEquals(75, StudyPending.minutes.value)
        assertEquals(2, StudyPending.read(Store.readStudyStrings()).size)
    }

    @Test fun bankDatesSurviveRegistrationAcrossTehranMidnight() = runBlocking {
        val before = java.time.Instant.parse("2026-01-01T20:29:59Z").toEpochMilli()
        val after = before + 2000
        Store.savePomodoro(PomodoroPersist(phase = "BREAK", remainingSec = 300),
            listOf(StudyPending.Block(25, before), StudyPending.Block(50, after)))
        Pomodoro.restore(App.instance)
        Offline.record(75, 4, Offline.Source.POMODORO, "bank")
        assertEquals(listOf(25, 50), rows().map { it.minutes })
        assertEquals(listOf("2026-01-01 23:59:59", "2026-01-02 00:00:01"), rows().map { Offline.stamp(it.at) })
        assertEquals(0, StudyPending.minutes.value)
        assertEquals("IDLE", Store.pomodoro.value.phase)
        assertEquals(Pomodoro.Phase.IDLE, Pomodoro.state.value.phase)
    }

    @Test fun malformedOutboxFailsClosedWithoutConsumingTimer() = runBlocking {
        Store.putString("offline_study_queue", "corrupt")
        Store.saveTimer(TimerPersist(false, 0, 25 * 60_000L, 1))
        assertTrue(runCatching { Offline.record(25, 1, Offline.Source.CHRONO) }.isFailure)
        assertEquals("corrupt", Store.getString("offline_study_queue"))
        assertEquals(25 * 60_000L, Store.timer.value.accumMs)
        Store.putString("offline_study_queue", null)
    }

    @Test fun cacheScopesOwnerAndTehranDay() = runBlocking {
        Cache.put(Cache.STUDY_TODAY, "alice-value", "alice", "2026-01-01")
        repeat(100) { if (Cache.get(Cache.STUDY_TODAY, owner = "alice", day = "2026-01-01") == null) delay(10) }
        assertEquals("alice-value", Cache.get(Cache.STUDY_TODAY, owner = "alice", day = "2026-01-01"))
        assertNull(Cache.get(Cache.STUDY_TODAY, owner = "bob", day = "2026-01-01"))
        assertNull(Cache.get(Cache.STUDY_TODAY, owner = "alice", day = "2026-01-02"))
        Store.putString("cache_study_today", "${System.currentTimeMillis()}|unsafe-legacy")
        assertNull(Cache.get(Cache.STUDY_TODAY, owner = "bob", day = "2026-01-01"))
    }

    @Test fun switchingAccountArchivesInterruptedWorkAndRestoresOwner() {
        Store.saveTimer(TimerPersist(false, 0, 60_000, 1))
        Store.savePomodoro(PomodoroPersist(), listOf(StudyPending.Block(25, 1000)))
        Store.clearSession(expectedToken = "token-alice") // Expiry preserves ownership and work.
        assertEquals(25, StudyPending.minutes.value)
        Store.saveSession("token-bob", "bob")
        assertEquals(0L, Store.timer.value.accumMs)
        assertEquals(0, StudyPending.minutes.value)
        Store.saveSession("token-alice-2", "alice")
        assertEquals(60_000L, Store.timer.value.accumMs)
        assertEquals(25, StudyPending.minutes.value)
    }

    @Test fun explicitLogoutPreservesOutboxAndPausedChronoOnlyForOwner() = runBlocking {
        Offline.add(25, 7, "unsent-alice", 1000)
        val originalQueue = Store.getString("offline_study_queue")
        Store.saveTimer(TimerPersist(true, System.currentTimeMillis() - 60_000, 30_000, 7))
        Store.savePomodoro(PomodoroPersist(), listOf(StudyPending.Block(50, 1234)))
        Store.clearSession(explicitSignOut = true)
        assertNull(Store.token); assertNull(Store.username)
        assertFalse(Chrono.running); assertFalse(Pomodoro.state.value.running)
        assertEquals(0L, Store.timer.value.accumMs)
        assertEquals(0, StudyPending.minutes.value)
        assertEquals(originalQueue, Store.getString("offline_study_queue"))
        assertEquals(0, Offline.flush())
        Store.saveSession("bob-token", "bob")
        assertEquals(0, Offline.refresh()); assertEquals(0, Offline.flush())
        assertEquals(0L, Store.timer.value.accumMs)
        assertEquals(0, StudyPending.minutes.value)
        Store.clearSession(explicitSignOut = true)
        Store.saveSession("alice-new", "alice")
        assertFalse(Chrono.running)
        assertTrue(Store.timer.value.accumMs in 90_000L..100_000L)
        assertEquals(7, Store.timer.value.courseId)
        assertEquals(listOf(StudyPending.Block(50, 1234)), StudyPending.read(Store.readStudyStrings()))
        assertEquals(1, Offline.refresh())
    }

    @Test fun explicitLogoutPausesFocusWithoutCountingSignedOutTime() {
        Store.savePomodoro(PomodoroPersist(phase = "WORK", running = true,
            endEpochMs = System.currentTimeMillis() + 600_000, remainingSec = 600, workMin = 50),
            listOf(StudyPending.Block(25, 1000)))
        Pomodoro.restore(App.instance)
        Store.clearSession(explicitSignOut = true)
        assertFalse(Pomodoro.state.value.running)
        Store.saveSession("alice-new", "alice")
        assertFalse(Pomodoro.state.value.running)
        assertEquals("WORK", Store.pomodoro.value.phase)
        assertTrue(Store.pomodoro.value.remainingSec in 590..600)
        assertEquals(50, Store.pomodoro.value.workMin)
        assertEquals(25, StudyPending.minutes.value)
    }

    @Test fun unknownLegacyOwnerIsRetainedButNeverAssignedToNextLogin() = runBlocking {
        Store.clearSession(explicitSignOut = true)
        Store.saveTimer(TimerPersist(false, 0, 123_000, 9))
        Store.savePomodoro(PomodoroPersist(), listOf(StudyPending.Block(25, 1000)))
        val raw = "[{\"id\":\"legacy\",\"uid\":\"legacy\",\"minutes\":25,\"courseId\":1,\"at\":1000}]"
        Store.putString("offline_study_queue", raw)
        Store.saveSession("bob-token", "bob")
        assertEquals(0L, Store.timer.value.accumMs)
        assertEquals(0, StudyPending.minutes.value)
        assertEquals(0, Offline.flush())
        assertEquals(raw, Store.getString("offline_study_queue"))
        assertTrue(Store.readStudyStrings().asMap().any { (key, value) ->
            key.name.startsWith("study_unowned_") && value.toString().contains("123000")
        })
    }

    @Test fun staleExplicitLogoutCannotClearNewAccountOrPauseItsTimer() {
        Store.saveSession("bob-token", "bob")
        Chrono.start()
        Store.clearSession(explicitSignOut = true, expectedToken = "token-alice")
        assertEquals("bob-token", Store.token)
        assertTrue(Chrono.running)
    }

    @Test fun tehranDateAndTimestampParsingIgnoreDeviceTimezone() = runBlocking {
        val original = java.util.TimeZone.getDefault()
        try {
            java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("America/Los_Angeles"))
            val epoch = java.time.Instant.parse("2026-01-01T20:30:01Z").toEpochMilli()
            assertEquals("2026-01-02", Fmt.isoOf(java.util.Date(epoch)))
            assertEquals(epoch, Fmt.parseMysql("2026-01-02 00:00:01")!!.time)
            assertEquals(Jalali.fromGregorian(2026, 1, 2), Jalali.fromDate(java.util.Date(epoch)))
            coroutineScope { (1..100).map { async(Dispatchers.Default) {
                assertEquals(epoch, Fmt.parseMysql("2026-01-02 00:00:01")!!.time)
            } }.awaitAll() }
            assertEquals(-1, IranTime.daysAgoOf("2026-02-30"))
            assertEquals(-1, IranTime.daysAgoOf("2026-01-01junk"))
        } finally { java.util.TimeZone.setDefault(original) }
    }

    @Test fun historyDoesNotCacheNetworkFailureAsZeroOrLeakAcrossUsers() = runBlocking {
        var calls = 0
        Api.handler = { _, _, _ -> calls++; throw ApiException("offline", 503) }
        assertTrue(runCatching { StudyHistory.day(2) }.isFailure)
        Api.handler = { _, _, _ -> calls++; "{\"total_minutes\":25,\"courses\":[],\"sessions\":[]}" }
        assertEquals(25, StudyHistory.day(2).totalMinutes)
        val afterLoad = calls
        assertEquals(25, StudyHistory.day(2).totalMinutes)
        assertEquals(afterLoad, calls)
        Store.saveSession("token-bob", "bob")
        Api.handler = { _, _, _ -> "{\"total_minutes\":50,\"courses\":[],\"sessions\":[]}" }
        assertEquals(50, StudyHistory.day(2).totalMinutes)
    }
}
