package ir.studying.app.core

import ir.studying.app.App
import ir.studying.app.player.Pomodoro
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*

/** Separate JVMs read the same real DataStore file, not an in-memory persistence fake. */
object RestartProbe {
    @OptIn(ExperimentalCoroutinesApi::class)
    @JvmStatic fun main(args: Array<String>): Unit = runBlocking {
        Dispatchers.setMain(StandardTestDispatcher())
        Store.init(App.instance)
        if (args.single() == "write") {
            Store.saveSession("local-test-token", "restart-user")
            Store.saveTimer(TimerPersist(false, 0, 12 * 60_000L, 3))
            Offline.record(12, 3, Offline.Source.CHRONO, "survives-death")
            Store.savePomodoro(PomodoroPersist(phase = "WORK", running = true,
                endEpochMs = System.currentTimeMillis() - 60_000, remainingSec = 1),
                listOf(StudyPending.Block(50, System.currentTimeMillis() - 100_000)))
        } else {
            check(Store.username == "restart-user")
            check(Store.timer.value.accumMs == 0L)
            check(Offline.decode(Store.getString("offline_study_queue")).single().uid == "survives-death")
            Pomodoro.restore(App.instance)
            StudyPending.load()
            check(StudyPending.minutes.value == 75)
            check(Store.pomodoro.value.phase == "BREAK")
        }
        println("Restart probe ${args.single()}: PASS")
        // Intentionally no graceful DataStore/timer shutdown; each transition must already be durable.
        System.out.flush()
        Runtime.getRuntime().halt(0)
    }
}
