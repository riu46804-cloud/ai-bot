"""Compile production reliability code against a real JVM DataStore, replacing Android/UI/network boundaries.
Run setup.py once, then run.py. No request to the app API is possible in this harness.
"""
from pathlib import Path
import subprocess, os
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
CACHE=Path(os.environ.get('RELIABILITY_CACHE', str(HERE.parent/'.reliability-cache')))
JAVA=Path(os.environ['JAVA_HOME'])/'bin/java' if os.environ.get('JAVA_HOME') else next(CACHE.glob('zulu*/bin/java'))
CP=os.pathsep.join(str(p) for p in CACHE.glob('*.jar') if p.name not in ('android.jar', 'tests.jar', 'api-check.jar'))
SRC=ROOT/'app/src/main/java/ir/studying/app'
STUBS={
'Context.kt': '''package android.content
open class Context { val applicationContext: Context get() = this }
''',
'MediaPlayer.kt': '''package android.media
import android.content.Context
class MediaPlayer {
 companion object { fun create(c: Context, id: Int): MediaPlayer? = null }
 fun setOnCompletionListener(f: (MediaPlayer) -> Unit) {}
 fun release() {}; fun start() {}
}
''',
'App.kt': '''package ir.studying.app
object App { val instance = android.content.Context() }
object R { object raw { const val chime = 1 } }
''',
'AndroidDataStore.kt': '''package androidx.datastore.preferences
import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.core.DataStore
import kotlin.properties.ReadOnlyProperty
import java.io.File
object TestDisk {
 val file = File(System.getProperty("test.disk"))
 val store: DataStore<Preferences> = PreferenceDataStoreFactory.create(produceFile = { file })
}
fun preferencesDataStore(name: String): ReadOnlyProperty<Context, DataStore<Preferences>> =
 ReadOnlyProperty { _, _ -> TestDisk.store }
''',
'Notify.kt': '''package ir.studying.app.notify
import android.content.Context
object StudyNotifier { fun sync(c: Context) {} }
object PomodoroAlarm { fun cancel(c: Context) {}; fun schedule(c: Context, at: Long) {} }
object SyncWorker { fun kick(c: Context) {} }
''',
'AutoPost.kt': '''package ir.studying.app.core
object AutoPost { suspend fun afterStudySaved(goal: String) {} }
''',
'RoomPrefs.kt': '''package ir.studying.app.ui.study.room
object RoomPrefs { val goal = kotlinx.coroutines.flow.MutableStateFlow("") }
object RoomState { const val IDLE = "idle"; const val STUDYING = "studying"; const val SLEEPING = "sleeping" }
''',
'AppSnack.kt': '''package ir.studying.app.ui.components
object AppSnack { fun show(s: String, long: Boolean = false) {} }
''',
'Widget.kt': '''package ir.studying.app.widget
object StudyWidget { fun refresh(c: android.content.Context) {} }
''',
'Lifecycle.kt': '''package androidx.lifecycle
open class ViewModel { protected open fun onCleared() {} }
val ViewModel.viewModelScope: kotlinx.coroutines.CoroutineScope get() = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main)
''',
'Api.kt': '''package ir.studying.app.core
import org.json.JSONObject
import org.json.JSONArray
class ApiException(message: String, val code: Int = 0): Exception(message)
fun humanizeError(e: Throwable): String = e.message ?: "error"
object Api {
 var handler: suspend (String, JSONObject?, SessionState) -> String = { _, _, _ -> "{\\"ok\\":true}" }
 suspend fun postForSession(action: String, body: JSONObject, session: SessionState): String = handler(action, body, session)
 suspend fun get(action: String, vararg query: Pair<String,String>): String = handler(action, null, Store.session.value)
 suspend fun post(action: String, body: JSONObject = JSONObject(), vararg query: Pair<String,String>): String = handler(action, body, Store.session.value)
 suspend fun delete(action: String, vararg query: Pair<String,String>): String = handler(action, null, Store.session.value)
 fun obj(s: String) = JSONObject(s)
 fun arr(s: String) = JSONArray(s)
}
'''
}
stubdir=CACHE/'stubs'; stubdir.mkdir(exist_ok=True)
for name, content in STUBS.items(): (stubdir/name).write_text(content)
files=[SRC/'core'/f'{n}.kt' for n in ['Store','StudyPending','Offline','Cache','Goals','IranTime','Jalali','Json','RefreshBus']]
files += [SRC/'player'/f'{n}.kt' for n in ['Chrono','Pomodoro']]
files += list((SRC/'data').glob('*.kt'))
files += [SRC/'ui/home/HomeViewModel.kt',SRC/'ui/study/StudyViewModel.kt',
 SRC/'ui/study/room/StudyRoomViewModel.kt', SRC/'ui/study/room/RoomModels.kt']
files += list(stubdir.glob('*.kt'))
files += list((ROOT/'app/src/test/java/ir/studying/app/core').glob('*.kt'))
files += [HERE/'ReliabilityTest.kt', HERE/'RestartProbe.kt']
compiler=[str(JAVA),'-cp',CP,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-cp',CP]
subprocess.run(compiler+['-d',str(CACHE/'tests.jar')]+list(map(str,files)),check=True)
# Compile the real HTTP implementation separately with real OkHttp and the already-compiled application types.
subprocess.run(compiler[:-1]+[CP+os.pathsep+str(CACHE/'tests.jar'),'-d',str(CACHE/'api-check.jar'),str(SRC/'core/Api.kt'),str(SRC/'core/Json.kt'),str(SRC/'notify/SyncWorker.kt')],check=True)
disk=CACHE/'test.preferences_pb'
if disk.exists(): disk.unlink()
subprocess.run([str(JAVA),'-Dtest.disk='+str(disk),'-cp',str(CACHE/'tests.jar')+os.pathsep+CP,
 'org.junit.runner.JUnitCore','ir.studying.app.core.ReliabilityTest','ir.studying.app.core.IranTimeTest',
 'ir.studying.app.core.JalaliTest','ir.studying.app.core.GoalsMathTest'],check=True)
restart_disk=CACHE/'restart.preferences_pb'
if restart_disk.exists(): restart_disk.unlink()
for mode in ('write','read','read'):
 subprocess.run([str(JAVA),'-Dtest.disk='+str(restart_disk),'-cp',str(CACHE/'tests.jar')+os.pathsep+CP,
  'ir.studying.app.core.RestartProbe',mode],check=True)
