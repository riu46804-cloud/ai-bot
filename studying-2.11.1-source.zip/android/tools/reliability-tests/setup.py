from pathlib import Path
import urllib.request, json, concurrent.futures, tarfile
BASE=Path(__file__).resolve().parent.parent/'.reliability-cache'
BASE.mkdir(exist_ok=True)
M='https://repo.maven.apache.org/maven2/'
G='https://dl.google.com/dl/android/maven2/'
artifacts={
'compiler.jar': M+'org/jetbrains/kotlin/kotlin-compiler-embeddable/2.0.21/kotlin-compiler-embeddable-2.0.21.jar',
'stdlib.jar': M+'org/jetbrains/kotlin/kotlin-stdlib/2.0.21/kotlin-stdlib-2.0.21.jar',
'script.jar': M+'org/jetbrains/kotlin/kotlin-script-runtime/2.0.21/kotlin-script-runtime-2.0.21.jar',
'reflect.jar': M+'org/jetbrains/kotlin/kotlin-reflect/1.6.10/kotlin-reflect-1.6.10.jar',
'daemon.jar': M+'org/jetbrains/kotlin/kotlin-daemon-embeddable/2.0.21/kotlin-daemon-embeddable-2.0.21.jar',
'annotations.jar': M+'org/jetbrains/annotations/13.0/annotations-13.0.jar',
'coroutines.jar': M+'org/jetbrains/kotlinx/kotlinx-coroutines-core-jvm/1.8.1/kotlinx-coroutines-core-jvm-1.8.1.jar',
'coroutines-test.jar': M+'org/jetbrains/kotlinx/kotlinx-coroutines-test-jvm/1.8.1/kotlinx-coroutines-test-jvm-1.8.1.jar',
'json.jar': M+'org/json/json/20240303/json-20240303.jar',
'junit.jar': M+'junit/junit/4.13.2/junit-4.13.2.jar',
'hamcrest.jar': M+'org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar',
'trove.jar': M+'org/jetbrains/intellij/deps/trove4j/1.0.20200330/trove4j-1.0.20200330.jar',
'preferences.jar': G+'androidx/datastore/datastore-preferences-core-jvm/1.1.1/datastore-preferences-core-jvm-1.1.1.jar',
'datastore.jar': G+'androidx/datastore/datastore-core-jvm/1.1.1/datastore-core-jvm-1.1.1.jar',
'datastore-okio.jar': G+'androidx/datastore/datastore-core-okio-jvm/1.1.1/datastore-core-okio-jvm-1.1.1.jar',
'okio.jar': M+'com/squareup/okio/okio-jvm/3.9.0/okio-jvm-3.9.0.jar',
'okhttp.jar': M+'com/squareup/okhttp3/okhttp/4.12.0/okhttp-4.12.0.jar',
'work.aar': G+'androidx/work/work-runtime/2.9.1/work-runtime-2.9.1.aar',
'future.jar': M+'com/google/guava/listenablefuture/1.0/listenablefuture-1.0.jar',
'android.jar': M+'com/google/android/android/4.1.1.4/android-4.1.1.4.jar',
}
def download(item):
 name,url=item; dest=BASE/name
 if not dest.exists(): urllib.request.urlretrieve(url,dest)
 print('Ready:', name)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: list(pool.map(download,artifacts.items()))
import zipfile
with zipfile.ZipFile(BASE/'work.aar') as archive:
 (BASE/'work.jar').write_bytes(archive.read('classes.jar'))
if not list(BASE.glob('zulu*/bin/java')):
 u='https://api.azul.com/metadata/v1/zulu/packages/?java_version=17&os=linux&arch=x86_64&archive_type=tar.gz&java_package_type=jre&latest=true&release_status=ga'
 packages=json.load(urllib.request.urlopen(u))
 package=next(p for p in packages if 'crac' not in p['name'] and 'musl' not in p['name'] and 'fx' not in p['name'])
 dest=BASE/'jre.tar.gz'; urllib.request.urlretrieve(package['download_url'],dest)
 with tarfile.open(dest) as t:
  for m in t.getmembers():
   if not (BASE/m.name).resolve().is_relative_to(BASE): raise ValueError('Unsafe archive path')
  t.extractall(BASE)
 dest.unlink()
print('Local JVM compiler ready. No app API contacted.')
