// Read-only browser regression harness. No npm dependencies; Node >=22 + Chromium.
// node /tmp/ember-room3d-modal-regression.cjs [--proposed-fix]
// ROOT and CHROME can override the defaults below. --proposed-fix changes only the in-memory JS.
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { spawn } = require('node:child_process');
const assert = require('node:assert/strict');
const ROOT = process.env.ROOT || path.resolve(__dirname, '../android/app/src/main/assets/room3d');
const CHROME = process.env.CHROME || '/home/vercel-sandbox/.cache/puppeteer/chrome/linux-157.0.8103.38/chrome-linux64/chrome';
const patched = process.argv.includes('--proposed-fix');
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'ember-r3-test-'));
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const chrome = spawn(CHROME, ['--headless', '--no-sandbox', '--disable-dev-shm-usage', '--remote-debugging-port=9231', '--user-data-dir=' + profile, 'about:blank'], {stdio:'ignore'});
  let ws;
  try {
    let targets;
    for (let i=0;i<100;i++) { try { targets = await (await fetch('http://127.0.0.1:9231/json')).json(); if(targets.length)break; } catch {} await sleep(50); }
    assert.ok(targets?.length, 'Chromium CDP must start');
    ws = new WebSocket(targets[0].webSocketDebuggerUrl);
    await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j});
    let seq=0; const pending=new Map();
    ws.onmessage=e=>{const o=JSON.parse(e.data); if(o.id){pending.get(o.id)(o);pending.delete(o.id)}};
    const send=(method,params={})=>new Promise((r,j)=>{const id=++seq;pending.set(id,o=>o.error?j(Error(JSON.stringify(o.error))):r(o.result));ws.send(JSON.stringify({id,method,params}))});
    const ev=async expression=>{const o=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(o.exceptionDetails)throw Error(JSON.stringify(o.exceptionDetails));return o.result.value};
    const source=name=>fs.readFileSync(path.join(ROOT,name),'utf8');
    await send('Emulation.setDeviceMetricsOverride',{width:400,height:800,deviceScaleFactor:1,mobile:true});
    await send('Emulation.setTouchEmulationEnabled',{enabled:true});
    await ev(`document.head.innerHTML='<meta name="viewport" content="width=device-width,initial-scale=1">'; document.body.innerHTML='<div id="app"><canvas id="cv"></canvas><button id="dock">dock</button><div id="modals"></div></div>';var style=document.createElement('style');style.textContent=${JSON.stringify(source('room3d.css')+'#cv{position:absolute;inset:0;width:100%;height:100%}#dock{position:absolute;top:20px;left:20px;z-index:2}')};document.head.appendChild(style);window.events=[];['pointerdown','pointerup','mousedown','mouseup','click'].forEach(t=>document.addEventListener(t,e=>events.push([t,e.target.id||e.target.className]),true));`);
    await ev(source('r3-util.js'));
    await ev(`var R3=window.R3;R3.sfx={play:()=>{}};var W=R3.world={SPECIES_EMOJI:{cat:'cat'},isAmbient:()=>false,focusMe:()=>{},previewHat:()=>{},person:()=>({id:'42',name:'Friend',kind:'cat',state:'idle',minutes:0})};R3.game={modalChanged:v=>events.push(['modal',v]),r3:()=>null,catalog:()=>null};`);
    let hud=source('r3-hud.js');
    if(patched){const old="wrap.addEventListener('click', function (e) { if (e.target === wrap) { R3.sfx.play('tap'); H.close(id); } });";assert.ok(hud.includes(old));hud=hud.replace(old,`var backdropPressed = false;
    wrap.addEventListener('pointerdown', function(e) { backdropPressed = e.target === wrap; });
    wrap.addEventListener('pointercancel', function() { backdropPressed = false; });
    wrap.addEventListener('click', function(e) { var dismiss = e.target === wrap && backdropPressed; backdropPressed = false; if (dismiss) { R3.sfx.play('tap'); H.close(id); } });`);}
    await ev(hud);
    const main=source('r3-main.js'), world=source('r3-world.js');
    const onPick=main.slice(main.indexOf('  function onPick(type, id)'),main.indexOf('  /* ================================================================ راه‌اندازی */'));
    const gestures=world.slice(world.indexOf('  function onDown(e)'),world.indexOf('  function findPick(o)'));
    // Use production gesture recognition + production main dispatch + complete HUD.
    // Stub only rendering/raycast selection: geometry is unrelated to the dismissal bug.
    await ev(`var H=R3.hud,cam={idle:0,uZoom:1,uYaw:0,uPitch:0,focusOn:false},ptrs={},gesture=null;window.pickType='boss';${onPick};function pick(x,y){events.push(['pick',window.pickType]);onPick(window.pickType,'42')} ${gestures};var cv=document.getElementById('cv');cv.addEventListener('pointerdown',onDown);cv.addEventListener('pointermove',onMove);cv.addEventListener('pointerup',e=>{events.push(['gesture',!!ptrs[e.pointerId],ptrs[e.pointerId]?performance.now()-ptrs[e.pointerId].t:null]);onUp(e)});cv.addEventListener('pointercancel',e=>{delete ptrs[e.pointerId];gesture=null});R3.tap(document.getElementById('dock'),()=>H.openBattle());`);
    const tap=async(x,y)=>{await send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});await send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sleep(30)};
    const reset=async()=>{await ev(`while(H.closeTop()){};events=[]`);await sleep(260)};
    const count=()=>ev('H.modalCount()');
    for(const type of ['boss','me','avatar']){
      await reset();await ev(`window.pickType=${JSON.stringify(type)}`);await tap(100,200);
      const trace=await ev('events');assert.equal(await count(),1,`${type}: opening touch must not dismiss its new modal. Trace: ${JSON.stringify(trace)}`);
      await sleep(360);
      const rect=await ev(`(()=>{const r=document.querySelector('.sheet').getBoundingClientRect();return {x:r.left+30,y:r.top+65}})()`);
      await tap(rect.x,rect.y);assert.equal(await count(),1,`${type}: sheet content stays open`);
      await tap(5,5);assert.equal(await count(),0,`${type}: subsequent genuine backdrop gesture closes`);
      console.log('PASS touch open / sheet / backdrop:',type);
    }
    await reset();await tap(35,35);assert.equal(await count(),1,'HUD click opening stays open');console.log('PASS HUD click open');
    await sleep(360);const close=await ev(`(()=>{const r=document.querySelector('.sh-x').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2}})()`);await tap(close.x,close.y);assert.equal(await count(),0,'X closes');console.log('PASS close button');
    await reset();await ev(`window.pickType='boss'`);await send('Input.dispatchMouseEvent',{type:'mousePressed',x:100,y:200,button:'left',clickCount:1});await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:100,y:200,button:'left',clickCount:1});assert.equal(await count(),1,'mouse open stays open');assert.equal(await ev('H.closeTop()'),true);assert.equal(await count(),0,'closeTop/Back closes');console.log('PASS mouse and Back');
    await reset();await send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:100,y:200}]});await send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:160,y:250}]});await send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert.equal(await count(),0,'drag must not pick');console.log('PASS drag does not pick');
    await send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:100,y:200}]});await send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});assert.equal(await count(),0,'cancel must not pick');console.log('PASS cancel does not pick');
    console.log('ALL PASS',patched?'(proposed fix injected in memory)':'(source unchanged)');
  } finally {
    if(ws)ws.close();const exited=new Promise(r=>chrome.once('exit',r));chrome.kill();await Promise.race([exited,sleep(2000)]);fs.rmSync(profile,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
