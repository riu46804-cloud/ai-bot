"""Native ICU parser regression, not an Android device/UI test.
Run where libicui18n is installed. Reads the pattern from actual Kotlin source.
"""
import ctypes
import ctypes.util
import json
from pathlib import Path
import re

library = ctypes.util.find_library('icui18n')
if not library:
    raise RuntimeError('Native ICU is required for this regression check')
icu = ctypes.CDLL(library)
suffix_match = re.search(r'\.so\.(\d+)', library)
suffix = '_' + suffix_match.group(1) if suffix_match else ''
open_regex = getattr(icu, 'uregex_open' + suffix)
close_regex = getattr(icu, 'uregex_close' + suffix)
class ParseError(ctypes.Structure):
    _fields_ = [('line', ctypes.c_int32), ('offset', ctypes.c_int32),
                ('pre', ctypes.c_uint16 * 16), ('post', ctypes.c_uint16 * 16)]
open_regex.argtypes = [ctypes.POINTER(ctypes.c_uint16), ctypes.c_int32,
                      ctypes.c_uint32, ctypes.POINTER(ParseError), ctypes.POINTER(ctypes.c_int32)]
open_regex.restype = ctypes.c_void_p
close_regex.argtypes = [ctypes.c_void_p]
def compile_status(pattern):
    raw = pattern.encode('utf-16-le')
    chars = (ctypes.c_uint16 * (len(raw)//2)).from_buffer_copy(raw)
    status = ctypes.c_int32(0)
    error = ParseError()
    compiled = open_regex(chars, len(raw)//2, 0, ctypes.byref(error), ctypes.byref(status))
    if compiled:
        close_regex(compiled)
    return status.value
root = Path(__file__).resolve().parents[1]
source = root / 'android/app/src/main/java/ir/studying/app/core/FlashcardLogic.kt'
literal = re.search(r'private val clozeRx = Regex\(("(?:\\.|[^"\\])*")\)', source.read_text()).group(1)
actual = json.loads(literal)
old = r'\{\{(.+?)}}'
old_status = compile_status(old)
actual_status = compile_status(actual)
assert old_status > 0, ('Old Android-incompatible pattern should fail', old_status)
assert actual_status <= 0, ('Fixed source pattern should compile', actual_status)
print(json.dumps({'parser': library, 'old_pattern_error': old_status,
                  'fixed_source_pattern_status': actual_status,
                  'result': 'PASS', 'scope': 'native ICU parser, no Android UI/device test'}, indent=2))
